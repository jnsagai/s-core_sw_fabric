<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — narrowly scoped deviation / false-positive drafts (`deviation_drafts`) review draft

**Document type:** review draft — actual-source inspection + recording of the named GCC syntax
failure + narrowly scoped **deviation / false-positive proposals** bound to exact rule, exact
finding and exact source hash, each with rationale / alternatives / risk / compensating checks /
review-and-expiry triggers + obligations status.

**Date:** 2026-10-03
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version handling in
socom* (issue #84)
**Run / branch:** `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ`
**Verified baseline commit:** `f8a196c3b16d5172d898394ab99b0ed81346d63d`
(`.llm_tmp/context/source-manifest.json:3`)
**Status:** **local, unprotected, scoped.** **No engineering acceptance exists. Human reviews are
unanswered. Full native runtime tests are pending.** **No deviation and no risk decision is made,
accepted, or proposed as accepted here** — every entry below is a **draft for human disposition**.
`.llm_tmp/context/obligations/authority.json` records `engineering_acceptance: pending`,
`human_reviews: unanswered`, `safety_class: unknown`; every `source-index.json` entry is
`native_acceptance: not_inferred`.

> **Tool / write boundary observed.** This iteration used only `read_file`, `grep`, `glob`, and
> `write_file`. No `shell`, no `edit_file`, no delegation, no web access, no approval, no publishing,
> and no engineering acceptance was performed. The task's explicit final sentence — *"This is a
> review draft: only that report may be written."* — is the operative write boundary: **exactly one
> file was written — this report**
> (`/workspace/.llm_tmp/overnight/reports/deviation_drafts.md`). No source, build, test, config,
> `NOTICE`, `LICENSE`, `REUSE.toml`, prior-report, host-validation, or obligation-collection file
> was created, edited, or deleted. Every file under `.llm_tmp/overnight/prior-reports/` (including
> the earlier `prior-reports/deviation_drafts.md`) and every earlier file under
> `.llm_tmp/overnight/reports/` was preserved unchanged.
>
> **Source-correction instruction vs. review-draft boundary (recorded, not silently resolved).**
> The task records *"a measured GCC syntax failure: an extra closing brace in
> `score/socom/impl/service_identifier.hpp` at line 39"* and directs *"Inspect and correct the
> actual source before expanding tests"*, while its final sentence says *"This is a review draft:
> only that report may be written."* Direct inspection of the **actual** working tree (§2) shows the
> header is **already brace-balanced**, line `:39` is blank, and the retained focused **GCC and
> Clang** compiles both exit `0` (§2.2). There is no unmatched brace to remove. The final sentence
> forbids a source write in any case. The conflict is recorded for human disposition (§10) and **no
> source was edited and no test was expanded** (the draft's suites already exist on disk).
>
> **Non-satisfaction rule applied throughout.** A successful obligation-collection node means the
> results were **retained**, not that the checks **passed**. Missing tools, unknown applicability,
> incomplete extraction (focused translation units; dependency findings retained), an inactive/draft
> rule mapping, a non-running analyzer, unclassified findings, and unanswered human reviews are
> **not** treated as satisfied. A tool that produced **no** finding because it did not run is
> recorded as *"not run"*, never as *"clean"*. No finding is suppressed, dropped, or silently
> filtered anywhere in this draft.

---

## 0. Summary

1. **The recorded GCC syntax failure is not present in the actual source (§2).**
   `score/socom/impl/service_identifier.hpp` is a 40-line, brace-balanced header: openers at `:19`
   (`namespace score::socom {`) and `:29` (`struct Service_instance_identifier final {`); closers at
   `:32` (`};`) and `:38` (`}  // namespace score::socom`); `:39` blank; `:40` `#endif`. Net brace
   balance `0`. The retained **focused GCC** and **focused Clang** compiles both exit `0` with empty
   stderr, and the host measurement compiles the same translation unit at `exit 0` (§2.2). Removing a
   brace would *create* syntax failure. **No correction was applied — none is required, and the
   write boundary forbids a source write.** This is recorded as **FP-1**.
2. **This draft re-binds every disposition to the hash family the tools actually measured (§1.2).**
   The obligation `source_hashes` blocks and the host `validation/measurement.json` agree on one
   revision (e.g. header `bdce3fcb…`); the context snapshot `candidate-files.json` records a
   *different* revision (header `96b33a1f…`). Both are stated, and each register entry names which
   binding it uses. **No re-hash was possible under the read-only boundary.**
3. **All retained findings are either dependency artifacts, gtest-macro-expansion artifacts,
   test-only/out-of-slice constructs, or produced by a tool that did not run. Nine narrowly scoped
   dispositions are drafted — DD-1 … DD-9 — plus the stale-defect record FP-1 (§3).** Each is bound
   to an exact rule id, an exact finding location, and a source sha256, and each is **DRAFT /
   NOT ACCEPTED**. No severity class (Critical/High/Medium/Low) is assigned: that classification
   belongs to the Quality Manager together with a committer
   (`gd_req__verification_sca_classification`), and no such classification exists.
4. **The current run supersedes one older item.** The earlier `prior-reports/deviation_drafts.md`
   drafted a Clang `-Wdeprecated-declarations` deviation (its DD-8) from a *different* run whose
   `clang-compile` exited `1`. In the retained artifact read here, **all eight `compiler_diagnostics`
   commands exit `0`** and `clang-compile.stderr` is empty. DD-8 is therefore retained only as a
   conditional, historical record and is **not** an active finding of this run (§3.8).
5. **No rule applicability is asserted.** `misra_mapping.rst` is `:status: draft` with its
   `csv-table` commented out and no `_assets/misra_2023.csv` present (`glob` finds none). The only
   in-evidence rule identifiers are the licensed CodeQL coding-standards pack's own annotations;
   using them is a **methodological substitution** a reviewer must accept (§1.5, §5).
6. **No obligation is satisfied (§6).** `authority.json` is pending; the safety class is `unknown`;
   `misra_mapping.rst` and `inspection_checklist.rst` are drafts; clang-tidy did not run; TSan is an
   environment failure; integration/docs/traceability/performance legs fail; coverage is below the
   platform goal; `full_native_tests: not_executed`; human reviews are unanswered.

---

## 1. Binding, scope, and evidence read this iteration

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` — *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:2-4` |
| State | `open`, **0 comments**, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` (unchanged) | `.llm_tmp/context/issue-snapshot.json:19-20` |
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**: service-instance identifier = `service id + major + minor + instance id`; service
identifier = `service id + major`; FindService = `service id + major + optional<minor> +
optional<instance>`; and the proposal to *"exclude the minor version and make it a property of the
service instance"*. There is no comment and no acceptance record. Binding is **by baseline commit**,
not by run HEAD.

### 1.2 The bounded slice and the two hash families

The changed implementation is `Service_instance_identifier { Service_interface_identifier interface;
Service_instance instance; }` (`score/socom/impl/service_identifier.hpp:29-32`) and its single
operator, which orders by `(instance, service id, major)` with `minor` deliberately excluded
(`score/socom/impl/service_identifier.cpp:20-30`), matching the minor-ignoring `Service_database`
record index (`score/socom/impl/runtime_impl.hpp:116-134`).

**Family A — tool/host measured revision.** These hashes come from the `source_hashes` blocks of the
retained obligation artifacts and are **identical** to the host `validation/measurement.json`
`source_hashes`. They are the revisions the analyzers/compilers actually saw, so they are the
**primary binding for every finding-based disposition below**.

| Path (repo-relative) | Measured sha256 (Family A) |
|----------------------|----------------------------|
| `score/socom/impl/service_identifier.hpp` | `bdce3fcbc3cd78a8ecaece1ea36107d464011ab81c9bc39932d0be617befaea9` |
| `score/socom/impl/service_identifier.cpp` | `3c12b3f1dd3f1fa66cdf43766f374d7d067637bf8f11aba604c4e2688351f11a` |
| `score/socom/test/unit/service_identifier_tests.cpp` | `de79767c4653feca7b5b2fcf93f5a791bcc64ae4b554dc2ef35a8756536391e6` |
| `score/socom/test/unit/runtime_tests.cpp` | `9a2d6a154683a2b7ff9d51b7241e4fb74c1a8ef483895830cb409a8f5a1d3127` |
| `score/socom/BUILD` | `68f4645a21e495fac43929fb125f7ba0b9e29fc84c0401fdb95238ffb7fd2cc8` |
| `score/socom/test/unit/BUILD` | `e909151e822370bebe8d59b86369bddeb4d6cacfa02f10061bf6e134671ff9d4` |
| `score/socom/impl/string_registry.cpp` (out of slice) | `f486e72a96429fea4b06f505b96b4fa00aa831a6834959169e409200e8ee8fbb` |
| `score/socom/string_registry.hpp` (out of slice) | `909ca6a47b1e7bb76bc05f3f05144ee6c80350fe4643df61d5efe4ef5f38693f` |
| `score/socom/registry_string_view.hpp` (out of slice) | `6640b529ea626c50944e1afe6240f84ac02551901c5a12ca846ea1ba37f18647` |
| `score/socom/service_interface_identifier.hpp` (public) | `b3c1f1a61fe91d8b6adb3a02dd745eb6c60fec0bfb78f581571fc6a88b972782` |

Sources: `obligations/codeql_misra/result.json:126-127,141,145,173,188-190`;
`obligations/compiler_diagnostics/result.json:127,190`;
`validation/measurement.json:1208-1216,1528-1531`.

**Family B — context snapshot revision.** `.llm_tmp/context/candidate-files.json` records a
**different** sha256 for every candidate file. This is the snapshot the task binds the write set to,
and the "cancelled draft" is described here.

| Path (repo-relative) | Snapshot sha256 (Family B) | Baseline git blob |
|----------------------|----------------------------|-------------------|
| `score/socom/BUILD` | `dee826163ac5e6336d51a293136b424696c2884aa1b2592395e1e06423c0ba44` | `3477ea0851fdcd82ec6ea9d71424013cbdf41962` |
| `score/socom/impl/service_identifier.cpp` | `d766902e4bda5306095a6e5326ea91d28df3a6e1ef4e77dc9ba47556ed559a9a` | `6c7e7a4e22355242009fe20dada2a9a0d0c7a9c7` |
| `score/socom/impl/service_identifier.hpp` | `96b33a1fee4d54577ae9bc46c313409a0d59336f76df85ef1925ffebdd1a2119` | `c8bae7908da9f087c518934f7b9f8d86db9a20ec` |
| `score/socom/test/unit/BUILD` | `9b3c5b341211e2c387858fd1fe5c669a6a422b6e8b5e80fce35ba22c61186799` | `3c03a7b14286051f97fa5022206564bd63645171` |
| `score/socom/test/unit/runtime_tests.cpp` | `5e35e24d0abcfa361b5a5283a005b307b86026a970464a3423be7c6eed66631e` | `8ecf5ab726db8bf994c960045d6fd7fdf84d7395` |
| `score/socom/test/unit/service_identifier_tests.cpp` | `45d073998108df76c8f4534508d65f02cead28aa568cd5c45b5a3d8a4fd36a25` | *(null — manifest expects a **new** file)* |

Source: `.llm_tmp/context/candidate-files.json:1-25`.

**Hash-reconciliation caveat (as in `reports/misra_manual_review.md` MF-11).** Family A and Family B
differ. The tools therefore analyzed a revision that may not be byte-identical to the snapshot the
task binds. Because no hashing utility is permitted, the working tree was not re-hashed. The direct
source reads (§2) are authoritative for **content**; every finding-bound proposal names the
**Family A** hash it derives from, and each entry's re-review trigger fires on **any** hash change in
**either** family.

### 1.3 Pinned obligation sources and authority (read this iteration)

All nine `.llm_tmp/context/obligations/source-index.json` entries were read with `authority.json`:

| id | Pinned file | Status used here |
|----|-------------|------------------|
| `coding_guidelines` | `coding_guidelines.rst` | `:status: valid`; **MISRA C++:2023 with C++17**; `Result`-based error handling |
| `code_analysis` | `code_analysis.rst` | `:status: valid`; MISRA/ISO 26262 SCA; mapping required; **unaddressed MISRA finding must be justified and documented in source** (`:51`) |
| `misra_mapping` | `misra_mapping.rst` | **`:status: draft`**; `csv-table` commented out; `_assets/misra_2023.csv` absent |
| `verification_plan` | `verification_plan.rst` | `:status: valid`; criteria 1–9 (static-analysis critical/high freedom; 100 % compiler warnings/errors freedom) |
| `development_plan` | `development_plan.rst` | `:status: valid`; C++17, GCC host, QCC target, Bazel |
| `tool_management` | `tool_management.rst` | `:status: valid`; tools identified/evaluated/qualified by a human |
| `verification_process` | `verification_process.rst` | `:status: valid`; **`gd_req__verification_sca_classification`** (Critical/High/Medium/Low by tool suggestion or QM+committer) |
| `verification_guideline` | `verification_guideline.rst` | `:status: valid`; traceability, independence, documented results |
| `inspection_checklist` | `inspection_checklist.rst` | **`:status: draft`**; blank `IMPL_01_01`…`IMPL_03_02` |

Authority (`.llm_tmp/context/obligations/authority.json`): `codeql_scope: "Public Apache-2.0
eclipse-score/inc_someip_gateway; no upload"`, `engineering_acceptance: pending`,
`human_reviews: unanswered`, `safety_class: unknown`. Every `source-index.json` entry is
`native_acceptance: not_inferred`. The pinned platform documents carry `:safety: ASIL_B`, but that
attribute is **not** an authorized selection of this slice's class and is **not** inferred as one.

### 1.4 Retained host feedback and obligation artifacts read this iteration

- **`validation/check-result` = `0`** — a collector/retention marker, **not** a pass marker.
- **`validation/measurement.json`** — `check_ref: check_conversion_tests`, `status: completed`,
  `mode: ubsan`, `changed_paths = ["score/socom/test/unit/service_identifier_tests.cpp"]`,
  `origin: local_unprotected_measurement`, `initiator: Fabro host hook`,
  `engineering_acceptance: pending`, `full_native_tests: not_executed`, compiler
  `/usr/bin/x86_64-linux-gnu-g++-12` (sha256 `88315fd2…`). `baseline_with_agent_tests`
  **91 tests / 33 failures / compile 0**; `candidate` **91 tests / 0 failures / compile 0**
  (`:2045-2058`). `after.json` = 91 / 0; `before.json` = 91 / 33. This is the red→green capture for
  the key change.
- **`obligations/*/result.json` (25 checks)** — statuses re-read here:
  `compiler_diagnostics` **completed** (all 8 commands exit `0`; limits *"Focused executable only;
  GCC 12.3 / Clang 19 differ from native toolchain pins"*, *"GoogleTest compiled separately with
  warnings retained; -Werror on target and tests"*);
  `focused_cppcheck` **findings_or_execution_failure** (exit `2`; limit *"Optional complementary
  checks; no inferred MISRA rule coverage"*);
  `focused_clang_tidy` **findings_or_execution_failure** (`--verify-config` exit `1`; blocker
  *"Native analyzer configuration incompatible; no replacement called MISRA"*);
  `codeql_security` **findings_or_execution_failure** (create/analyze exit `0`; `blockers: []`;
  focused-extraction limit);
  `codeql_misra` **findings_or_execution_failure** (create/analyze exit `0`; blockers *"MISRA
  applicability/mapping draft and incomplete"*, *"Default suite omits manual/audit obligations"*,
  *"Compiled query qualification and human deviations pending"*; focused-extraction limit);
  `focused_asan_lsan` **completed** (focused pass; 91/91);
  `focused_tsan` **findings_or_execution_failure** (tests exit `66`;
  `FATAL: ThreadSanitizer: unexpected memory mapping`);
  `focused_memcheck` **completed** (exit `0`);
  `focused_coverage` **completed** (36/36 line = 100 %; 11/14 branch = 78.6 %; `complete_target_scope:
  false`);
  `native_build` **completed**, `native_tests` **completed** (build-only), `native_sanitizers`
  **completed** (build-only), `native_tsan` **completed** (build-only), `native_coverage`
  **completed** (threshold 73, *not* platform acceptance);
  `cross_compilation` **completed_with_blockers** (x86 and arm exit `0`; QNX SDK blocker);
  `native_integration` **findings_or_execution_failure** (exit `1`);
  `native_lint` **findings_or_execution_failure** (clang-tidy exit `124` timeout);
  `native_docs` **findings_or_execution_failure** (`//:docs` exit `2`);
  `native_traceability` **findings_or_execution_failure** (docs exit `2`; traceability gate exit `1`);
  `native_performance` **findings_or_execution_failure** (timeouts);
  `format_precommit` **findings_or_execution_failure**;
  `secret_dependency_checks` **findings_or_execution_failure**;
  `process_checks` **completed_with_blockers** (metadata inventory: `runtime_tests.cpp` 33 macros,
  `service_identifier_tests.cpp` 91 macros; both with `DerivationTechnique` + `Description`);
  `rework_progress` **completed** (`source_changed_this_round: false`, `rework_requested: false`);
  `tool_assurance` **completed_with_blockers**. **Retention ≠ passing.**

### 1.5 Prior reports read and preserved

`.llm_tmp/overnight/prior-reports/` — **38 files**, all preserved; the direct predecessor is
`prior-reports/deviation_drafts.md` (read in full; it is bound to run
`01M3YRJEGXNY6CB81T7TKW774B` and is **superseded where its readings differ from the artifacts read
here**, per §3.8 and §1.4). Also read: `prior-reports/finding_classification.md`,
`misra_applicability.md`, `misra_manual_review.md`, `tool_findings_repair.md`, `scope.md`,
`invariants.md`, `key_fix.md`, `reproducer.md`, `ordering_tests.md`, `conversion_tests.md`,
`lifetime_review.md`, `concurrency_review.md`, `test_metadata.md`, `verification_report_draft.md`,
`independent_review_handoff.md`, `evidence_inventory.md`, `review_packet.md`.

`.llm_tmp/overnight/reports/` — read and preserved (not modified):
`scope.md`, `api_review.md`, `bazel_plan.md`, `callsites.md`, `compatibility.md`,
`concurrency_review.md`, `conversion_tests.md`, `coverage_review.md`, `coverage_tests_repair.md`,
`finding_classification.md`, `invariants.md`, `key_fix.md`, `lifetime_review.md`,
`lifetime_tests.md`, `misra_applicability.md`, `misra_manual_review.md`, `ordering_tests.md`,
`repair_conversion_tests.md`, `reproducer.md`, `runtime_disabled.md`, `runtime_enabled.md`,
`test_metadata.md`, `tool_findings_repair.md`, `unit_matrix.md`, `analyzer_plan.md`. This document
adds `deviation_drafts.md` to `reports/`; no prior report was overwritten.

### 1.6 Host addendum (task context, not acceptance)

The task states measurements are **local, unprotected and scoped**; full native runtime tests and
human reviews remain pending; a successful collection node means results were **retained**, not that
checks passed; missing tools, unknown applicability, incomplete extraction and unanswered human
reviews are **not** satisfied obligations. There is **no authority here to invent native links,
select a safety class, accept risk/deviations, or answer the independent human gate.** This draft
honours all of that.

---

## 2. The recorded GCC syntax failure — inspection of the actual source

### 2.1 Finding (direct `read_file` this iteration)

`score/socom/impl/service_identifier.hpp` read from the working tree is **brace-balanced** (40
lines):

| Line | Content | Role |
|------|---------|------|
| 14–15 | `#ifndef SRC_SOCOM_SRC_SERVICE_IDENTIFIER` / `#define …` | include guard |
| 17 | `#include "score/socom/service_interface_identifier.hpp"` | include |
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 21–28 | doc comment | states `minor` is intentionally not part of the identity |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 30–31 | `Service_interface_identifier interface;` / `Service_instance instance;` | members |
| 32 | `};` | closes the struct |
| 34–36 | `/// \cond` / `bool operator<(…)` / `/// \endcond` | single out-of-line declaration |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`) and two closers (`:32`, `:38`): net brace balance `0`. There is **no
third, unmatched closing brace**, and line `:39` contains no text. The sibling
`score/socom/impl/service_identifier.cpp` uses the same nested form (braces at `:18`, `:32`) and is
balanced. `glob **/service_identifier*` resolves exactly three paths
(`impl/service_identifier.cpp`, `impl/service_identifier.hpp`,
`test/unit/service_identifier_tests.cpp`); there is **no second, differently-braced copy** and no
leftover `.orig`/`.rej`/`.bak` file in this checkout.

### 2.2 Independent corroboration from the retained artifacts

- `obligations/compiler_diagnostics/result.json`: focused **GCC** `gcc-compile` exit `0` (`:1152`)
  and `gcc-tests` exit `0` (`:1174`); focused **Clang** `clang-compile` exit `0` (`:1274`) and
  `clang-tests` exit `0` (`:1296`); `blockers: []` (`:1052`); `status: completed` (`:1299`).
- `validation/measurement.json`: the host compiled the flagged translation unit through
  `g++-12 -std=c++17 -Wall -Wextra -Werror -fsanitize=undefined -fno-sanitize-recover=all` at
  `compile_exit 0` and ran 91 / 0 (`:2045-2058`).
- A surviving unmatched `}` in a header compiled into that translation unit would have failed these
  compiles, not passed them.

### 2.3 Disposition

The described defect is a **stale, pre-correction description** matching the earliest prior reports
(which quote the old split-form close `}  // namespace socom` + `}  // namespace score`). The
`reproducer` iteration corrected it to the nested form, and the retained compiles and the actual
source both show the balanced form. Applying the historical repair would be a no-op at best;
deleting a brace would **create** the reported defect. **No source edit was made**, both because no
defect is present and because the write boundary forbids a source write. Minimal historical repair,
retained **for reference only** (not applied):

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

---

## 3. Draft dispositions register

All entries are **proposals only**. "Type" distinguishes a **tool/dependency false positive** (no
authored code violates the rule) from a **requested deviation** (authored or out-of-slice code does
implicate the rule, and an authorized exception or in-source justification is requested). **No class
(Critical/High/Medium/Low) is assigned**: `gd_req__verification_sca_classification` requires the
Quality Manager together with a committer, and `authority.json` records that decision pending. Every
status is **DRAFT — NOT ACCEPTED**. Rule identifiers are the licensed CodeQL coding-standards pack's
own query ids/annotations, **not** an S-CORE applicability decision (`misra_mapping.rst` is draft).

### 3.1 Register at a glance

| Id | Type (proposed) | Tool / rule | Exact finding (representative) | Bound source hash (Family A) | Status |
|----|-----------------|-------------|--------------------------------|------------------------------|--------|
| DD-1 | False positive (gtest macro artifact); deviation alternative | CodeQL MISRA **6.5.1** `cpp/misra/external-linkage-not-declared-in-header-file-misra` | `service_identifier_tests.cpp` startLine **2181**, startColumn **8**, endColumn **89** (`codeql_misra/result.json:1165-1182`), repeated at every `TEST_F` line | `de79767c…` | DRAFT / pending |
| DD-2 | False positive (gtest macro artifact) | CodeQL MISRA **9.3.1** `cpp/misra/switch-body-compound-condition` | `service_identifier_tests.cpp` (macro-expanded body; the rule fires in the same artifact, e.g. block around `result.json:7949-10274`) | `de79767c…` | DRAFT / pending |
| DD-2b | False positive (gtest macro artifact) | CodeQL MISRA **6.7.2** `cpp/misra/global-variable-used` | `service_identifier_tests.cpp` `TEST_F` registration expansion | `de79767c…` | DRAFT / pending |
| DD-2c | False positive (gtest macro artifact / type alias) | CodeQL MISRA **6.9.2** `cpp/misra/avoid-standard-integer-type-names` | `service_identifier_tests.cpp` (fixture/defaulted-body artifact) | `de79767c…` | DRAFT / pending |
| DD-3a | False positive (gtest macro artifact) | CodeQL MISRA **7.0.1** `cpp/misra/no-conversion-from-bool` | `service_identifier_tests.cpp` (assertion machinery expanded from `EXPECT_*`/`ASSERT_*`) | `de79767c…` | DRAFT / pending |
| DD-3b | **Deviation requested** (out of slice) | CodeQL MISRA **7.0.1** `cpp/misra/no-conversion-from-bool` | `score/socom/impl/string_registry.cpp` startLine **28, 42, 45, 59, 62** (returned `std::pair<…, bool>` insert flags) | `f486e72a…` | DRAFT / pending |
| DD-4 | **Deviation requested** (out of slice) | CodeQL MISRA **21.6.1** `cpp/misra/dynamic-memory-should-not-be-used` | `score/socom/string_registry.hpp` startLine **37** (class member container) | `909ca6a4…` | DRAFT / pending |
| DD-5 | **Deviation requested** (out of slice) | CodeQL MISRA **6.7.1** `cpp/misra/local-variable-static-storage-duration` | `score/socom/impl/string_registry.cpp` startLine **66** and **71** (function-local `static` registries) | `f486e72a…` | DRAFT / pending |
| DD-6 | False positive in effect (RAII side effect) / deviation | CodeQL MISRA **0.1.1** `cpp/misra/unnecessary-write-to-local-object` | `score/socom/impl/string_registry.cpp` startLine **35** col 46-54 and **23** col 46-54 (`std::lock_guard` locals) | `f486e72a…` | DRAFT / pending |
| DD-7 | **Deviation requested** (performance style; no MISRA rule) | Cppcheck `passedByValue` (`severity="performance"`, `cwe="398"`) | `registry_string_view.hpp:127,134,141,148,155,162,173`; `service_interface_identifier.hpp:37,41,48,99,105,113` (19 findings) | `6640b529…`, `b3c1f1a6…` | DRAFT / pending |
| DD-8 | False positive (dependency/toolchain) — **historical, not present in this run** | Clang `-Wdeprecated-declarations` under `-Werror` | libstdc++-12 `stl_tempbuf.h:263` via googletest `gtest.cc` (earlier run only) | *(dependency; not candidate source)* | DRAFT / conditional |
| DD-9 | False positive (dependency) | CodeQL security suite (`cpp/…`), 32 findings | every `uri` under `.llm_tmp/googletest/**`; none under `score/` | *(dependency; not candidate source)* | DRAFT / pending |
| FP-1 | **Not reproducible / stale defect** | "GCC syntax failure — extra `}` at `service_identifier.hpp:39`" | header brace census + GCC/Clang/host compiles exit `0` | `bdce3fcb…` (measured) / `96b33a1f…` (snapshot) | DRAFT / pending |

---

### DD-1 — MISRA 6.5.1 external-linkage finding on the gtest `TEST_F` expansion

- **Type (proposed):** false positive as to the *authored* test body, with a deviation alternative
  (the synthesised registration entities genuinely exist, so if the tool has no macro-aware mode a
  formal deviation may be the only honest disposition).
- **Exact rule:** MISRA C++:2023 rule **6.5.1**, CodeQL query
  `cpp/misra/external-linkage-not-declared-in-header-file-misra` (`level: null`).
- **Exact finding (directly re-confirmed this iteration):** top-level finding at
  `obligations/codeql_misra/result.json:1164-1183` — `uri:
  score/socom/test/unit/service_identifier_tests.cpp`, `startLine 2181`, `startColumn 8`,
  `endColumn 89`; the block then repeats at every `TEST_F` line (`result.json:1185`…`:2987`, roughly
  one entry per test macro).
- **Bound source hash:** `service_identifier_tests.cpp` = `de79767c…` (Family A).
- **Rationale:** the flagged locations are the `TEST_F` macro-expansion lines. googletest synthesises
  externally-linked test-registration entities whose declarations are not in a header; these cannot
  be declared in a header without patching the framework. The file's authored helpers are `static`
  members of the fixture, so the finding is not about authored code.
- **Alternatives:** (a) macro-aware CodeQL query / gtest-aware baseline; (b) restart/`TEST`-style or
  anonymous-namespace wrapping (not viable without breaking gtest registration); (c) a formal,
  time-boxed deviation scoped to the macro-expanded lines; (d) leave unaccepted (current state).
- **Risk if accepted as-is:** a real external-linkage violation introduced *outside* the macro in the
  same file would be masked if the disposition were applied file-wide.
- **Compensating checks:** keep the finding retained and counted; restrict the disposition to
  macro-expanded `TEST_F` lines only; manual review of any non-macro symbol added to the file; run a
  **full-target** extraction (not the focused executable) before closure.
- **Review / expiry triggers:** (i) the test-file hash changes in either family; (ii) a macro-aware
  tool is adopted; (iii) `misra_mapping.rst` becomes `valid` and maps 6.5.1 to a tool; (iv) the
  safety class is selected; (v) 12 months from any approval.
- **Status:** **DRAFT — NOT ACCEPTED.**

### DD-2 — MISRA 9.3.1 switch-body finding on the gtest macro expansion

- **Type (proposed):** false positive as to the authored body (macro/defaulted-body artifact).
- **Exact rule:** MISRA C++:2023 rule **9.3.1**, CodeQL query
  `cpp/misra/switch-body-compound-condition` (`level: null`).
- **Exact finding:** the rule is present in the retained artifact and fires both in
  `.llm_tmp/googletest/**` (first occurrence `result.json:7366-7384`,
  `gtest/internal/gtest-port.h:1169`) and on `score/socom/test/unit/service_identifier_tests.cpp`
  (the test-file URI reappears inside this rule block, e.g. `result.json:7949-10274`). The flagged
  regions are not authored `switch` statements; they are framework-generated compound conditions in
  the macro-expanded body (as recorded in `reports/misra_applicability.md`).
- **Bound source hash:** `service_identifier_tests.cpp` = `de79767c…` (Family A).
- **Rationale / alternatives / risk / compensating checks / triggers:** as DD-1. Additionally,
  confirm by hand that no authored `switch` with a compound body exists in the six candidate paths
  (none was found on inspection).
- **Status:** **DRAFT — NOT ACCEPTED.**

### DD-2b — MISRA 6.7.2 global-variable-used on the gtest expansion

- **Type (proposed):** false positive (macro artifact — the gtest registration objects).
- **Exact rule:** MISRA C++:2023 rule **6.7.2**, query `cpp/misra/global-variable-used`
  (`level: null`).
- **Exact finding:** the rule block in `codeql_misra/result.json` contains
  `score/socom/test/unit/service_identifier_tests.cpp` entries (e.g. around
  `result.json:6831-7191`); the flag tracks the `TEST_F` registration expansion, not an authored
  global.
- **Bound source hash:** `service_identifier_tests.cpp` = `de79767c…` (Family A).
- **Rationale / alternatives / risk / compensating checks / triggers:** as DD-1.
- **Status:** **DRAFT — NOT ACCEPTED.**

### DD-2c — MISRA 6.9.2 avoid-standard-integer-type-names on the test file

- **Type (proposed):** false positive (framework/defaulted-body artifact).
- **Exact rule:** MISRA C++:2023 rule **6.9.2**, query
  `cpp/misra/avoid-standard-integer-type-names` (`level: null`).
- **Exact finding:** reported on `score/socom/test/unit/service_identifier_tests.cpp` in the
  retained focused extraction (macro-expanded lines).
- **Bound source hash:** `service_identifier_tests.cpp` = `de79767c…` (Family A).
- **Rationale:** the flagged type names arise in the expanded registration/assertion machinery, not
  in an authored declaration; the same rule also fires on `service_interface_identifier.hpp:187`
  (out of slice, separate disposition).
- **Alternatives / risk / compensating checks / triggers:** as DD-1.
- **Status:** **DRAFT — NOT ACCEPTED.**

### DD-3a — MISRA 7.0.1 no-conversion-from-bool on the gtest test file

- **Type (proposed):** false positive (macro artifact).
- **Exact rule:** MISRA C++:2023 rule **7.0.1**, CodeQL query
  `cpp/misra/no-conversion-from-bool` (`level: null`).
- **Exact finding:** the rule block begins at `codeql_misra/result.json:76217-76235` on
  `gtest-assertion-result.cc:54` and the `service_identifier_tests.cpp` URI recurs within the same
  block. The test body does not perform a bool-to-non-bool conversion; the query matches framework
  assertion machinery expanded from `EXPECT_*`/`ASSERT_*`.
- **Bound source hash:** `service_identifier_tests.cpp` = `de79767c…` (Family A).
- **Alternatives / risk / compensating checks / triggers:** as DD-1.
- **Status:** **DRAFT — NOT ACCEPTED.**

### DD-3b — MISRA 7.0.1 no-conversion-from-bool in `string_registry.cpp` (out of slice)

- **Type (proposed):** **deviation requested** (repository production code, outside the six writable
  candidate paths).
- **Exact rule:** MISRA C++:2023 rule **7.0.1**, query `cpp/misra/no-conversion-from-bool`.
- **Exact finding:** `score/socom/impl/string_registry.cpp` at startLine **28** (col 68-74), **42**
  (col 72-78), **45** (col 79-84), **59** (col 72-78), **62** (col 79-84) — the `bool` second
  element of the returned `std::pair<Registry_string_view, bool>` insert results.
- **Bound source hash:** `string_registry.cpp` = `f486e72a…` (Family A).
- **Rationale:** the `bool` is a returned "newly inserted" flag in a deliberate `std::pair` API
  (`string_registry.hpp` documents it). If the rule is read as prohibiting the pattern, a formal
  deviation or an in-source justification per `code_analysis.rst:51` is required; **none exists
  today**, and adding one is outside this review's write boundary.
- **Alternatives:** refactor the return type (API change across callers, out of slice); in-source
  justification citing `code_analysis.rst:51`; formal deviation with time box.
- **Risk if accepted:** normalizes a bool-encoding pattern the coding guideline may intend to forbid
  and could weaken the `Result`-based error model if extended to error paths.
- **Compensating checks:** confirm the flag is consumed by callers/tests; keep the finding retained;
  ensure no new bool-encoded *error* paths are introduced; verify callers.
- **Review / expiry triggers:** `string_registry.{cpp,hpp}` hash change; activated MISRA mapping;
  `inspection_checklist` completion; safety-class selection; time-box expiry.
- **Status:** **DRAFT — NOT ACCEPTED.**

### DD-4 — MISRA 21.6.1 dynamic memory in `string_registry.hpp` (out of slice)

- **Type (proposed):** **deviation requested** (repository production code, outside the six paths).
- **Exact rule:** MISRA C++:2023 rule **21.6.1**, query
  `cpp/misra/dynamic-memory-should-not-be-used`.
- **Exact finding:** `score/socom/string_registry.hpp` startLine **37**, col 7-8 (the
  `class String_registry final`); the query also fires in the test file and in
  `.llm_tmp/googletest/**`.
- **Bound source hash:** `string_registry.hpp` = `909ca6a4…` (Family A).
- **Rationale:** the class deliberately owns interning containers (`std::unordered_set` +
  `std::forward_list<std::string>`) whose node-address stability the registration key's
  `Registry_string_view` members rely on. The dynamic allocation is a design property of the
  registry, not an authored defect introduced by this slice.
- **Alternatives:** fixed-capacity arena / `std::array` pool (substantial redesign); in-source
  justification; formal deviation.
- **Risk if accepted:** normalizes dynamic allocation in an ASIL-relevant component, and any
  replacement may affect the lifetime contract that the key's non-owning views depend on.
- **Compensating checks:** focused ASan/LSan/UBSan pass (91/91); TSan (native) exit `0`; review the
  registry lifetime contract (`registry_string_view.hpp`); confirm no unchecked allocation-failure
  path is introduced.
- **Review / expiry triggers:** any change to registry storage; activated mapping; selection of a
  class that forbids dynamic memory; time-box expiry.
- **Status:** **DRAFT — NOT ACCEPTED.**

### DD-5 — MISRA 6.7.1 function-local static storage duration (out of slice)

- **Type (proposed):** **deviation requested** (repository production code, outside the six paths).
- **Exact rule:** MISRA C++:2023 rule **6.7.1**, query
  `cpp/misra/local-variable-static-storage-duration`.
- **Exact finding:** `score/socom/impl/string_registry.cpp` startLine **71** col 28-36 and **66**
  col 28-36 (the two `static String_registry registry;` singletons in
  `service_id_registry()` / `instance_id_registry()`).
- **Bound source hash:** `string_registry.cpp` = `f486e72a…` (Family A).
- **Rationale:** function-local statics give the process-wide registries a stable, lazily-initialized
  lifetime that avoids the static-initialization-order fiasco; the append-only design depends on
  that lifetime. Deliberate design, outside the slice.
- **Alternatives:** redesign toward explicit ownership in `Runtime`; in-source justification; formal
  deviation.
- **Risk if accepted:** residual static-destruction-order hazard for any view outliving the registry
  (recorded as MF-8 in `reports/misra_manual_review.md`); not newly introduced here.
- **Compensating checks:** lifetime review; confirm all keys die before the registries; focused
  ASan/LSan pass; add an ordered-shutdown regression before closure.
- **Review / expiry triggers:** lifetime-contract change; activated mapping; safety-class selection;
  time-box expiry.
- **Status:** **DRAFT — NOT ACCEPTED.**

### DD-6 — MISRA 0.1.1 unnecessary write to local object (out of slice)

- **Type (proposed):** false positive in effect (the "write" is an RAII side effect), with a
  deviation alternative.
- **Exact rule:** MISRA C++:2023 rule **0.1.1**, query `cpp/misra/unnecessary-write-to-local-object`.
- **Exact finding:** `score/socom/impl/string_registry.cpp` startLine **35** col 46-54 and **23**
  col 46-54 (the `std::lock_guard<std::mutex> const locked{m_mutex};` locals; the query also fires
  broadly in `.llm_tmp/googletest/**`).
- **Bound source hash:** `string_registry.cpp` = `f486e72a…` (Family A).
- **Rationale:** the local's value is never read because its *purpose* is the constructor/destructor
  side effect (lock/unlock); the object is not dead code. This is the classic RAII false positive.
- **Alternatives:** none that preserve RAII; if the tool cannot be configured, a formal deviation
  (`[[maybe_unused]]`/`std::ignore` do not change the query result).
- **Risk if accepted:** none material for this pattern; the guard is required for the concurrency
  contract.
- **Compensating checks:** confirm both guards lock the same mutex used by all registry accessors;
  concurrency review; native TSan exit `0`; focused TSan recorded as an environment failure (not
  clean).
- **Review / expiry triggers:** tool-version change; activated mapping; source change; time-box
  expiry.
- **Status:** **DRAFT — NOT ACCEPTED.**

### DD-7 — Cppcheck `passedByValue` on view/value parameters (out of slice)

- **Type (proposed):** **deviation requested** (performance style; no MISRA rule; out-of-scope
  headers).
- **Exact rule/finding:** cppcheck id `passedByValue`, `severity="performance"`, `cwe="398"`
  (`obligations/focused_cppcheck/cppcheck.stderr`; command at `result.json:1053-1082`, exit `2`;
  limit *"Optional complementary checks; no inferred MISRA rule coverage"*, `:1086-1088`), 19
  findings:
  - `score/socom/registry_string_view.hpp` `:127` (lhs col 48, rhs col 74), `:134` (48/74),
    `:141` (47/73), `:148` (48/74), `:155` (47/73), `:162` (48/74), `:173` (v col 72) — 13 findings;
  - `score/socom/service_interface_identifier.hpp` `:37` (col 34), `:41` (48), `:48` (39), `:99`
    (37), `:105` (51), `:113` (51) — 6 findings (`new_id`).
- **Bound source hashes:** `registry_string_view.hpp` = `6640b529…`;
  `service_interface_identifier.hpp` = `b3c1f1a6…` (Family A).
- **Rationale:** the flagged types are small, cheap-to-copy view/value wrappers; passing by value is
  intentional and consistent with the codebase style. Cppcheck's performance suggestion is not a
  MISRA rule and has no S-CORE mapping; the run is a complementary check with the recorded limit
  *"no inferred MISRA rule coverage"*.
- **Alternatives:** change parameters to `const&` (API churn in out-of-slice public headers, potential
  ABI concern); adopt a cppcheck baseline/suppression file; formal deviation.
- **Risk if accepted:** a small size/perf regression if a parameter type later becomes expensive to
  copy; the by-value copies are part of the current public signatures.
- **Compensating checks:** `static_assert(sizeof(...))` bounds if accepted; benchmark before/after a
  signature change; retain the findings.
- **Review / expiry triggers:** parameter-type size change; public-API refactor; CI adopts cppcheck;
  time-box expiry.
- **Status:** **DRAFT — NOT ACCEPTED.**

### DD-8 — Clang `-Wdeprecated-declarations` dependency error (historical; not present in this run)

- **Type (proposed):** false positive as to the candidate source — dependency/toolchain. **Conditional
  record only.**
- **Exact finding (earlier run, retained in `prior-reports/`):** `clang-compile.stderr` —
  libstdc++-12 `bits/stl_tempbuf.h:263` `'get_temporary_buffer<testing::TestInfo *>' is deprecated
  [-Werror,-Wdeprecated-declarations]`, instantiated from `.llm_tmp/googletest/googletest/src/gtest.cc`
  via `std::stable_sort`; `clang-compile` exit `1`.
- **Bound source:** libstdc++-12 + vendored googletest (not among the candidate source hashes).
- **Current run status (this checkout):** `obligations/compiler_diagnostics/result.json` records
  `clang-compile` exit `0` (`:1274`) and `clang-tests` exit `0` (`:1296`) with empty stderr;
  `status: completed` (`:1299`). The earlier reading is **superseded by the retained artifact for
  this checkout**; there is no active Clang defect to disposition here.
- **Alternatives if it recurs:** suppress `-Wdeprecated-declarations` for the vendored gtest TU only;
  update googletest/libstdc++; keep vendored gtest out of the warnings-as-errors target; record a
  dependent deviation.
- **Risk if accepted (when it recurs):** a real deprecation elsewhere in the same TU could be masked
  if suppression is too broad.
- **Compensating checks:** GCC and Clang focused TUs clean in this run; any suppression must be
  scoped to the gtest TU; keep the Clang leg recorded until dispositioned.
- **Review / expiry triggers:** any non-zero `clang-compile`; toolchain-pin change; googletest
  update; warnings-as-errors policy change; time-box expiry.
- **Status:** **DRAFT — CONDITIONAL / NOT ACTIVE IN THE CURRENT ARTIFACT.**

### DD-9 — CodeQL security findings (all dependency)

- **Type (proposed):** false positive as to the deliverable — dependency.
- **Exact findings:** `obligations/codeql_security/result.json` (create/analyze exit `0`,
  `blockers: []` at `:1052`, `status: findings_or_execution_failure` at `:1113`) retains 32 findings
  under rule ids `cpp/fixme-comment`, `cpp/commented-out-code`, `cpp/large-parameter`,
  `cpp/equality-on-floats`, `cpp/unused-static-function`, `cpp/unused-static-variable`,
  `cpp/rule-of-two`, `cpp/include-non-header`, `cpp/trivial-switch`, `cpp/loop-variable-changed`,
  `cpp/path-injection`. `level` is `null` on all; every `uri` is under `.llm_tmp/googletest/**`
  (no `score/` finding URI).
- **Bound source:** vendored googletest (dependency; not candidate source).
- **Rationale:** the findings concern third-party test-framework code linked into the focused
  extraction; the artifact's own limit is *"Focused linked executable, not full target extraction;
  dependency findings retained"*. They do not implicate the deliverable.
- **Alternatives:** exclude `.llm_tmp/**`/vendored deps from the *deliverable* register while retaining
  them in the raw artifact (proposed); full-target extraction.
- **Risk if accepted:** a genuine security finding in project code could be missed if the
  dependency-only scope were misapplied; mitigate by asserting the `uri` predicate.
- **Compensating checks:** assert every finding `uri` starts with `.llm_tmp/`; re-run a full-target
  extraction before closure; keep counts.
- **Review / expiry triggers:** any finding with a `score/**` uri; extraction-scope change; time-box
  expiry.
- **Status:** **DRAFT — NOT ACCEPTED.**

### FP-1 — Recorded GCC syntax failure is not reproducible (stale defect)

- **Type:** not-reproducible / stale-defect record (not a deviation).
- **Claim:** "measured GCC syntax failure: an extra closing brace in
  `score/socom/impl/service_identifier.hpp` at line 39".
- **Bound source hash:** measured revision `bdce3fcb…` (Family A); context snapshot revision
  `96b33a1f…` (Family B).
- **Evidence:** §2 brace census (four brace lines `:19,:29,:32,:38`; `:39` blank); retained focused
  `gcc-compile` exit `0` (`compiler_diagnostics/result.json:1152`); focused `clang-compile` exit `0`
  (`:1274`); host `compile_exit 0` with `-Werror -fsanitize=undefined`
  (`validation/measurement.json:2046,2053`).
- **Proposed disposition:** close as not reproducible for the hashes above; retain the minimal repair
  (§2.3) for the event the imbalance reappears. If a distinct "cancelled draft" revision still
  carries the extra brace, it is not the file in this checkout and must be located and corrected by
  an authorized iteration.
- **Risk:** if a different revision with the defect is later merged, this record would not apply —
  hence the dual-hash binding and the re-check trigger.
- **Compensating checks:** re-inspect the brace census whenever either header hash changes; the
  native GCC build must compile the header before any closure.
- **Review / expiry triggers:** header hash change in either family; a fresh, checksum-bound GCC
  failure report; time-box expiry.
- **Status:** **DRAFT — NOT ACCEPTED (recorded as a stale, non-reproducible claim).**

---

## 4. Items deliberately NOT proposed as deviations

- **Repairing the `.clang-tidy` configuration (G1/G2).** `focused_clang_tidy` shows
  `--verify-config` exit `1` with 15 "unknown check" texts and the blocker *"Native analyzer
  configuration incompatible; no replacement called MISRA"* (`result.json:1052-1055`); the native
  `//:clang-tidy.check` leg timed out (exit `124`, `native_lint`). This is a **tooling false-negative
  risk / blocker**, not a false positive and not a deviation. It requires an authorized config change
  before clang-tidy can speak to this slice. **Zero clang-tidy findings on the changed units is "not
  run", never "clean".**
- **Activating `misra_mapping.rst` or suppressing CodeQL queries.** Not a deviation; an authorized
  process/tooling change outside the write boundary. The mapping is `:status: draft` with no CSV, so
  no rule is mapped in-repo and **which** rules apply to this slice is unresolved.
- **The `duplicate_service` doc-comment narrowing (MF-3)** and **the comparator not declared
  `noexcept` (MF-2)** from `reports/misra_manual_review.md`. Advisory source-level review items, not
  tool-rule deviations; each requires an authorized source change and a build/test cycle this review
  cannot run.
- **The wider issue #84 restructure** (public `Service_identifier = id + major`, minor as an instance
  property, FindService wildcard, config `0xFFFFFFFF` narrowing). Unaccepted design questions, not in
  scope and not a deviation.

---

## 5. What is explicitly *not* claimed

- No MISRA C++:2023 compliance, no rule applicability, and no authorized Critical/High/Medium/Low
  classification is claimed. The rule numbers cited above are the **licensed CodeQL coding-standards
  pack's own annotations**, read from the retained focused extraction, **not** an S-CORE mapping
  decision (`misra_mapping.rst` is `:status: draft` with the `csv-table` commented out and no
  `_assets/misra_2023.csv`).
- Identifier-only tests are **not** platform validation; no fuzzy technique is claimed (no harness,
  no measurement); no native requirement identifiers are invented.
- The measurements are **local, unprotected and scoped**: the host capture executed 91 key tests in
  one identifier translation unit and never compiled `runtime_tests.cpp`; `full_native_tests` is
  `not_executed`; no Bazel test **execution** of the full tree is recorded (the native test legs are
  build-only).
- The **hash-family drift** (§1.2) means the tool-measured revision may not be byte-identical to the
  context snapshot; this draft binds findings to the measured family and fires re-review on any change
  in either family.

---

## 6. Obligations status (none satisfied)

### 6.1 Pinned state

All nine pinned sources were read with `authority.json` (§1.3). Every `source-index.json` entry is
`native_acceptance: not_inferred`. `engineering_acceptance: pending`, `human_reviews: unanswered`,
`safety_class: unknown`.

### 6.2 Status for this slice

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| MISRA C++:2023 rule→tool mapping | `misra_mapping.rst`; `code_analysis.rst` | **DRAFT / INACTIVE** — no CSV, table commented out; all rules unmapped in-repo |
| Static code analysis executed, findings classified | `code_analysis.rst`; `verification_process.rst` (`gd_req__verification_sca_classification`) | **NOT SATISFIED** — clang-tidy not run (config rejected / timeout); CodeQL focused+incomplete; cppcheck out of scope; **no authorized class** |
| Freedom from SCA critical/high (criterion 8) | `verification_plan.rst` | **NOT MEASURED** — no authorized classification |
| Freedom from compiler warnings & errors (criterion 9, 100 %) | `verification_plan.rst` | **PARTIAL / LOCAL** — focused GCC and Clang `-Werror` exit `0`; host `-Werror` compile 0; not a full-tree warnings-as-errors run |
| Unit/component testing executed, results recorded | `verification_plan.rst`; `verification_guideline.rst` | **PARTIAL, SCOPED** — 91 identifier tests / 0 failures (local host capture); `runtime_tests.cpp` (33 macros) never compiled/executed by any retained artifact |
| Sanitizers / concurrency | `code_analysis.rst` | **PARTIAL / BLOCKED** — focused ASan/LSan/UBSan pass; native sanitizer/TSan legs build-only; focused TSan exit `66` environment failure |
| Structural statement / branch coverage goals | `verification_plan.rst` | **NOT MEASURED TO GOAL** — focused 100 % line / 78.6 % branch; native threshold 73 is not platform 85/100 |
| Manual/audit MISRA + inspection checklist | `inspection_checklist.rst` (draft) | **NOT DONE** — draft, blank template |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** — clang-tidy unusable; docs/traceability/perf legs failing; tool-chain pins not demonstrated |
| Linking tests to requirements (record properties) | `verification_process.rst` | **PARTIAL / NOT DONE** — `DerivationTechnique`/`Description` set; `TestType`/`Verifies` unset (no invented identifiers) |
| External-component AoUs verified | `verification_process.rst` (`gd_req__verification_external_aou`) | **NOT SATISFIED** — no integration/static verdict; no AoU register |
| Independence of verification / review | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Deviation / risk acceptance | `authority.json` | **NONE** — every entry in §3 is a draft |
| Native acceptance | `source-index.json` | **`not_inferred` for every entry** |
| Obligation-collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **RETAINED, NOT PASSING** — several `findings_or_execution_failure` / `completed_with_blockers` |

**Explicit non-satisfaction statement.** The invalid clang-tidy configuration and native timeout,
the focused/incomplete CodeQL extraction, the non-MISRA cppcheck scope, the draft MISRA mapping, the
focused TSan environment failure, the integration/docs/traceability/performance gaps, the below-goal
branch coverage, the unselected safety class, and the unanswered human reviews mean **none of the
checked obligations may be treated as satisfied**. A retained collection result proves *retention*,
not passing. **No entry in this draft is an accepted deviation.**

---

## 7. Measurement and validation status

- **Tools used:** `read_file`, `grep`, `glob`, `write_file` only. No `shell`, delegation, web,
  approval, publishing, or engineering acceptance.
- **Measurements executed by this iteration: none.** Every statement above is a direct source read, a
  reading of a retained artifact under `.llm_tmp/overnight/`, a prior-report reading explicitly
  labelled as such, or an explicitly-labelled logical consequence.
- **Test inventory (read, not run):** `service_identifier_tests.cpp` = **91 `TEST_F`**
  (`:168`…`:2181`, matching `process_checks/result.json:1074`); `runtime_tests.cpp` = **33 macros**
  (1 `TEST` + 31 `TEST_F` + 1 `TEST_P`, matching `process_checks/result.json:1065`). The focused
  minor-only regression `RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError`
  is at `runtime_tests.cpp:402-431`.
- **Regression target (source-derived; host capture is red→green):** on the working key the
  minor-only key cases collapse to one set element and the runtime regression returns
  `Construction_error::duplicate_service`; the retained baseline is red (33 failures) and the
  candidate green (0).
- **Scope:** local, unprotected, scoped. Full native runtime tests and human reviews remain pending.
- **Reproduction path for a later authorized iteration (not executed here):**

  ```bash
  bazel test //score/socom/test/unit:socom_test
  bazel test //score/socom/test/unit:socom_test --test_filter='ServiceInstanceIdentifierTest.*'
  bazel test //score/socom/test/unit:socom_test --test_filter='RuntimeTest.*'
  # after an authorized .clang-tidy repair:
  bazel --batch run //:clang-tidy.check
  # full-target CodeQL (not the focused executable):
  codeql database create db --language=cpp --command=<build>
  codeql database analyze db misra-cpp-default.qls --format=sarif-latest
  ```

---

## 8. Notice preservation

- No source, build, test, config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was created, edited, or
  deleted by this iteration; **only this report was written.**
- `score/socom/impl/service_identifier.hpp` retains its Apache-2.0/SPDX header (`:1-12`) and was left
  unchanged because it is already brace-balanced (§2). The sibling `service_identifier.cpp`,
  `service_interface_identifier.hpp`, `registry_string_view.hpp`, `string_registry.{hpp,cpp}`, both
  `BUILD` files, `runtime_tests.cpp`, and `service_identifier_tests.cpp` likewise retain their
  Apache-2.0 / SPDX headers.
- All 38 files under `.llm_tmp/overnight/prior-reports/` and every earlier file under
  `.llm_tmp/overnight/reports/` (including `prior-reports/deviation_drafts.md`) were preserved
  unchanged; the host-validation and obligation-collection artifacts were read only and left
  unmodified.
- This report itself carries the Apache-2.0 header. **No licensed MISRA rule text is reproduced**;
  only native rule/query identifiers, tool query ids, source hashes, and file locations are cited.

---

## 9. Pending human review checklist

- [ ] **Confirm FP-1 (§2):** the recorded "extra `}` at `service_identifier.hpp:39`" is not present
      for measured hash `bdce3fcb…` or snapshot hash `96b33a1f…`; the focused GCC/Clang compiles and
      the host `-Werror -fsanitize=undefined` compile all exit `0`. If a distinct cancelled-draft
      revision still carries the brace, locate and correct it by an authorized iteration.
- [ ] **Resolve the instruction conflict:** "inspect and correct the actual source" vs. "only that
      report may be written"; confirm that inspection-only (no source write) was intended.
- [ ] **Reconcile the hash families (§1.2):** confirm which revision the tool artifacts and the host
      measurement correspond to relative to `candidate-files.json`; re-hash when a hashing tool is
      available, and re-open any disposition whose bound hash changes.
- [ ] **Adjudicate DD-1 / DD-2 / DD-2b / DD-2c / DD-3a** as gtest `TEST_F` macro artifacts (false
      positives or a time-boxed formal deviation) scoped to the exact lines and the
      `de79767c…` hash — not file-wide suppressions. Do not patch the test framework or silently
      suppress the rules.
- [ ] **Adjudicate DD-3b / DD-4 / DD-5 / DD-6 / DD-7** (out-of-slice production constructs) via a
      formal deviation **or** an in-source justification per `code_analysis.rst:51` **or** a
      refactor; none is accepted today.
- [ ] **Decide DD-8:** treat the Clang deprecation error as superseded by the current exit-`0`
      artifact, or record a conditional dependency deviation should it recur.
- [ ] **Disposition DD-9** (dependency security findings) so they do not inflate the deliverable's
      finding set; scope precisely by the `uri` predicate.
- [ ] **Complete and activate the MISRA mapping** (`misra_mapping.rst`): supply
      `_assets/misra_2023.csv`, uncomment the `csv-table`, and raise `:status` to `valid` by an
      authorized change. Confirm the use of the licensed CodeQL pack's internal annotations as
      evidence (methodological substitution).
- [ ] **Repair and run clang-tidy** (`.clang-tidy` config rejected; native leg timed out) and
      record whether it produces findings; do not report "clean" for a run that did not complete.
- [ ] **Complete the mandated SCA classification** (`gd_req__verification_sca_classification`) by the
      Quality Manager together with a committer; treat this draft's rule ids as inputs only.
- [ ] **Run a full-target CodeQL extraction** (not the focused executable) including
      `runtime_tests.cpp`, and qualify the compiled queries.
- [ ] **Fill the implementation inspection checklist** `IMPL_02_01` / `IMPL_02_02`
      (`inspection_checklist.rst`, currently draft/blank) using this draft as input.
- [ ] **Refresh the measurement:** run `bazel test //score/socom/test/unit:socom_test` (and the
      broader `//score/...` set) so `runtime_tests.cpp` and all 91 key cases are compiled and
      executed; do not re-report the focused 91-test host artifact as whole-tree coverage.
- [ ] **Provide a TSan-capable environment or an accepted exclusion**, and stabilize the QNX
      integration / docs / traceability / performance legs.
- [ ] **Select the safety class**, schedule independent human review (approver ≠ author), and record
      engineering acceptance; no deviation is valid before that.
- [ ] **Keep the wider #84 public `Service_interface_identifier` restructure, FindService wildcard
      handling, and the config minor-wildcard narrowing out of this bounded slice** until separately
      accepted.

---

*End of deviation-drafts review draft. Local, unprotected, scoped. No engineering acceptance;
human reviews unanswered; full native runtime tests pending. No deviation or risk decision is made
or proposed as made here. No MISRA C++:2023 compliance is claimed and no rule applicability is
asserted.*
