<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — tool-findings repair (duplicate-server registration key)

**Document type:** repair report (tool diagnostics read from the actual collected
artifacts + actual-source inspection + no-defect determination + remaining-findings
record)
**Date:** 2026-10-02
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version
handling in socom* (issue #84)
**Run:** branch `fabro/run/01M3YRJEGXNY6CB81T7TKW774B`
**Status:** local, unprotected, scoped. **No engineering acceptance exists. Human
reviews are unanswered. Full native runtime tests are pending.** Every statement
below is either a direct reading of the working tree / retained tool artifacts, or an
explicitly-labelled logical consequence. Nothing here is published, reviewed,
accepted, or a full native run.

> **Tool / write boundary actually observed.** This iteration used only `read_file`,
> `grep`, `glob`, and `write_file`. No `shell`, no delegation, no web access, no
> approval, no publishing, and no engineering acceptance. Of the six writable
> candidate source paths plus this report, **this iteration wrote exactly one file —
> this report.** No source, build, test, config, `NOTICE`, `LICENSE`, or `REUSE.toml`
> file was created, edited, or deleted. Every prior report under
> `.llm_tmp/overnight/prior-reports/` and every earlier report under
> `.llm_tmp/overnight/reports/` was preserved unchanged.
>
> **Why no source edit was made, even though the six paths were writable.** The task
> records "a measured GCC syntax failure: an extra closing brace in
> `score/socom/impl/service_identifier.hpp` at line 39" and directs "Inspect and
> correct the actual source before expanding tests". The *actual* collected GCC tool
> result for the candidate (`.llm_tmp/overnight/obligations/compiler_diagnostics/`)
> is `gcc-compile` **exit 0** with empty stderr, followed by `gcc-tests` **exit 0**
> with **85/85** passing (`.llm_tmp/overnight/validation/after.json`). The header read
> directly from the working tree is brace-balanced with line 39 blank. Removing a brace
> from a balanced header would *create* a syntax error. There is therefore no safe
> source correction for the described defect, and the correct action is the no-op plus
> this explanation. The remaining tool findings are likewise outside the six paths or
> are gtest-macro/infrastructure artifacts; §5–§6 record them rather than suppress
> them or patch dependencies.

---

## 1. Binding and scope

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` | `.llm_tmp/context/issue-snapshot.json:2-4` |
| Title | *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:3` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` | `.llm_tmp/context/issue-snapshot.json:19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an
accepted obligation**: service-instance identifier = `service id + major + minor +
instance id`; service identifier = `service id + major`; FindService = `service id +
major + optional<minor> + optional<instance>`. There is **no comment and no acceptance
record** in the snapshot.

### 1.2 Verified baseline and the only writable source paths

| Item | Value | Source |
|------|-------|--------|
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |

The six candidate source paths (`.llm_tmp/context/candidate-files.json:1-25`), the only
source paths this iteration was permitted to change:

1. `score/socom/BUILD`
2. `score/socom/impl/service_identifier.cpp`
3. `score/socom/impl/service_identifier.hpp`
4. `score/socom/test/unit/BUILD`
5. `score/socom/test/unit/runtime_tests.cpp`
6. `score/socom/test/unit/service_identifier_tests.cpp`

`glob **/service_identifier.hpp` returns exactly one path
(`score/socom/impl/service_identifier.hpp`), so there is no second, differently-braced
copy of the header in this checkout.

### 1.3 Prior reports, host feedback, and obligation-collection results read

- `.llm_tmp/overnight/prior-reports/` — 12 files, read and preserved: `callsites.md`,
  `conversion_tests.md`, `invariants.md`, `key_fix.md`, `lifetime_tests.md`,
  `ordering_tests.md`, `reproducer.md`, `runtime_disabled.md`, `runtime_enabled.md`,
  `scope.md`, `test_metadata.md`, `unit_matrix.md`.
- `.llm_tmp/overnight/reports/` — 12 earlier reports, read and preserved.
- `.llm_tmp/overnight/validation/` — **present this iteration**: `check-result` = `0`;
  `measurement.json` (`origin: local_unprotected_measurement`,
  `initiator: Fabro host hook`, `engineering_acceptance: pending`,
  `full_native_tests: not_executed`, compiler `/usr/bin/x86_64-linux-gnu-g++-12`);
  `before-*` / `after-*` command, stdout, stderr and JSON captures.
- `.llm_tmp/overnight/obligations/*/result.json` and per-command captures — **present
  this iteration** (24 checks), including the raw `*.stderr` / `*.stdout` for compiler,
  cppcheck, sanitizer, clang-tidy and CodeQL runs.

Per the task rule, a successful collection node means results were **retained**, not
that checks **passed**; and missing tools, unknown applicability, incomplete extraction
and unanswered human reviews are **not** treated as satisfied obligations.

---

## 2. The recorded GCC syntax failure — inspection of the actual source

### 2.1 Finding

`score/socom/impl/service_identifier.hpp` read from the working tree is
**brace-balanced** (40 lines):

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`) and two closers (`:32`, `:38`) give a net brace balance of
`0`. There is no third, unmatched closing brace and line 39 contains no text. This
matches the *later* prior reports (`scope.md`, `key_fix.md`, `reproducer.md`): the
`reproducer` iteration applied the correction and left line 39 blank in place of the
removed brace. The task's "extra closing brace … at line 39" is a **stale,
pre-correction description** that matches the *earliest* prior reports, whose lines
38–39 were the split form `}  // namespace socom` + `}  // namespace score`.

### 2.2 Independent tool corroboration (retained artifacts)

- `.llm_tmp/overnight/obligations/compiler_diagnostics/gcc-compile.stderr` and
  `.stdout` are **empty**, and `result.json` records the `gcc-compile` command with
  `"exit_code": 0`. A surviving extra closing brace would make this compile fail.
- `.llm_tmp/overnight/obligations/compiler_diagnostics/gcc-tests.stderr` is empty and
  the command is `"exit_code": 0`.
- `.llm_tmp/overnight/validation/after-compile.stderr` and `before-compile.stderr` are
  both empty; `.llm_tmp/overnight/validation/after.json` records `"tests": 85,
  "failures": 0`, and `measurement.json` records `candidate.compile_exit = 0`.
- The collected source hash for `service_identifier.hpp` in the obligation runs is
  `bdce3fcb…` (`obligations/compiler_diagnostics/result.json:127`), while the initial
  context snapshot recorded `96b33a1f…` (`.llm_tmp/context/candidate-files.json:11`).
  The file therefore evolved between the context snapshot and the tool runs (comment
  text / namespace form), but the tool-measured revision is the balanced one, and the
  working tree read this iteration is balanced as well.

### 2.3 Disposition

**No correction was applied, and none is required.** Applying the minimal historical
repair

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

to the already-balanced, already-nested file would be a no-op at best and a
compilation break at worst. No test was expanded either: the test suites already on
disk (85 key cases; 33 runtime cases) compile and pass under GCC in the retained
captures, and there is no reported source defect to gate the expansion on.

---

## 3. Original tool diagnostics read this iteration

All paths are relative to `/workspace`. "In-scope?" asks whether the flagged location
is one of the six writable candidate paths.

| Tool / check | Raw artifact read | Result | In-scope location? |
|--------------|-------------------|--------|--------------------|
| GCC compile + tests | `obligations/compiler_diagnostics/gcc-compile.stderr`, `gcc-tests.stderr`, `result.json` | compile exit 0; tests exit 0 | yes (clean) |
| Clang compile | `obligations/compiler_diagnostics/clang-compile.stderr` | exit 1 (dependency deprecation) | **no** |
| cppcheck | `obligations/focused_cppcheck/cppcheck.stdout`, `cppcheck.stderr` | exit 2; 19 `passedByValue` findings | **no** |
| clang-tidy | `obligations/focused_clang_tidy/native-config.stderr` | exit 1 (config verify) | **no** |
| CodeQL security | `obligations/codeql_security/result.json` (`findings`) | findings only in `.llm_tmp/googletest/` | **no** |
| CodeQL MISRA | `obligations/codeql_misra/result.json` (`findings`), `analyze.stderr` | googletest + gtest-macro findings | partly (macro artifact only) |
| ASan/LSan/UBSan | `obligations/focused_asan_lsan/result.json`, `tests.stderr` | compile 0; tests 0 | yes (pass) |
| TSan | `obligations/focused_tsan/tests.stderr` | `FATAL: ThreadSanitizer: unexpected memory mapping` | **no** (environment) |
| memcheck | `obligations/focused_memcheck/result.json` | exit 127 (valgrind unavailable) | n/a |
| coverage | `obligations/focused_coverage/coverage-summary.json` | 77.8 % line / 64.3 % branch | partially |
| native build/tests/integration/lint/docs/traceability/sanitizers/tsan/coverage/performance, cross-compilation, format/pre-commit | `obligations/native_*/result.json`, `format_precommit/result.json` | exit 127 (`/tmp/s-core-001/bin/bazel` missing) | n/a |
| secret/dependency scan | `obligations/secret_dependency_checks/result.json` | gitleaks unavailable; lock/SBOM retained | n/a |
| process checks | `obligations/process_checks/result.json` | `completed_with_blockers`; metadata inventory retained | yes (metadata only) |
| host validation | `validation/check-result` (`0`), `validation/measurement.json`, `validation/after.json` | candidate **85 tests / 0 failures / compile 0**; `baseline_with_agent_tests` **85 / 28 / compile 0**; `full_native_tests: not_executed` | yes |

---

## 4. Concrete source-defect assessment (per tool)

### 4.1 Compiler — GCC (clean; the named defect is absent)

`gcc-compile.stderr` is empty and exit code is 0; `gcc-tests.stderr` is empty and exit
code is 0. The retained host validation adds **85 tests / 0 failures** for the
candidate (`.llm_tmp/overnight/validation/after.json:2-3`) and **28 failures** for
`baseline_with_agent_tests` (`measurement.json:2045-2051`) with `compile_exit = 0` in
both — i.e. the red-to-green transition is the *key change*, not a syntax fix. **No
in-scope compiler defect. No correction.**

### 4.2 Compiler — Clang (blocked by a dependency, outside the six paths)

`clang-compile.stderr:4` reports:

```
/usr/lib/gcc/x86_64-linux-gnu/12/../../../../include/c++/12/bits/stl_tempbuf.h:263:8:
error: 'get_temporary_buffer<testing::TestInfo *>' is deprecated [-Werror,-Wdeprecated-declarations]
```

The instantiation is reached from `.llm_tmp/googletest/googletest/src/gtest.cc:3068`
via `std::stable_sort`, i.e. from the *googletest dependency plus libstdc++ 12* under
`-Werror`, not from the candidate source. Fixing it would require patching googletest
or suppressing `-Wdeprecated-declarations` — both prohibited ("Do not suppress rules or
fix dependencies/infrastructure outside the six paths"). **Remaining finding; blocker;
no in-scope correction.**

### 4.3 Analyzer — cppcheck (findings are in headers outside the six paths)

`cppcheck.stderr` exit 2; `cppcheck.stdout` shows the two files checked are
`score/socom/impl/service_identifier.cpp` and `score/socom/impl/string_registry.cpp`.
The 19 findings are all `id="passedByValue"` (`severity="performance"`), and every one
of their `<location>`s is in an **included header outside the six paths**:

- `score/socom/registry_string_view.hpp` lines 127, 134, 141, 148, 155, 162 (lhs/rhs)
  and 173 (`v`) — 13 findings;
- `score/socom/service_interface_identifier.hpp` lines 37, 41, 48, 99, 105, 113
  (`new_id`) — 6 findings.

`file0` is the candidate `.cpp`, but the flagged declarations are not there. These are
performance style suggestions on small view/value types, are not correctness defects,
and lie outside the writable paths. **Remaining finding (out of scope); no correction.**

### 4.4 Analyzer — clang-tidy (config blocker, no run)

`focused_clang_tidy/native-config.stderr` shows `clang-tidy --verify-config` rejecting
the repository `.clang-tidy` with 15 "unknown check" warnings (e.g.
`bugprone-use-after-move`, `modernize-type-traits`, `modernize-use-integer-sign-comparison`).
The retained result's blocker is *"Native analyzer configuration incompatible; no
replacement called MISRA"* (`focused_clang_tidy/result.json:236`). This is a tool/config
mismatch outside the six paths; the repo config must not be edited here and no rule may
be suppressed. **Remaining finding; blocker; no in-scope correction.**

### 4.5 Analyzer — CodeQL security (dependency only)

Every finding in `codeql_security/result.json` (lines 302–937: `cpp/fixme-comment`,
`cpp/commented-out-code`, `cpp/path-injection`, …) has a `uri` under
`.llm_tmp/googletest/…`. The retained limit is *"Focused linked executable, not full
target extraction; dependency findings retained"* (`:940`). **No finding in any of the
six candidate paths; no correction.**

### 4.6 Analyzer — CodeQL MISRA (gtest-macro artifact; mapping draft)

`codeql_misra/result.json` findings are of two kinds:

- `cpp/misra/copy-and-move-assignments-shall-handle-self-assignment` — located in
  `.llm_tmp/googletest/googletest/include/gtest/internal/gtest-filepath.h` (dependency).
- `cpp/misra/external-linkage-not-declared-in-header-file-misra` — located in
  `score/socom/test/unit/service_identifier_tests.cpp` at many `TEST_F` lines
  (e.g. `:1929`, `:1882`, `:1851`, …). This is the **`TEST_F` macro expansion**: gtest
  synthesizes an externally-linked test-registration object/function whose declaration
  is not in a header. It is an artifact of the test framework, not of the authored test
  body; there is **no finding in `service_identifier.cpp`, `service_identifier.hpp` or
  `runtime_tests.cpp`** (those appear only in the `source_hashes` block).

The collector's own blockers are *"MISRA applicability/mapping draft and incomplete",
"Default suite omits manual/audit obligations", "Compiled query qualification and human
deviations pending"* (`:235-238`), and `misra_mapping.rst` is `:status: draft`. A safe
in-source fix would require editing the test framework or suppressing the rule — both
prohibited — or an accepted human deviation, which is unavailable. **Remaining finding;
needs human deviation; no in-scope correction.**

### 4.7 Sanitizers — ASan/LSan/UBSan pass; TSan environment failure

- `focused_asan_lsan`: compile exit 0 and tests exit 0
  (`obligations/focused_asan_lsan/result.json:274,298`), stderr empty. **Pass (focused
  identifier scope only).**
- `focused_tsan`: compile exit 0, tests exit **66**, stderr
  `FATAL: ThreadSanitizer: unexpected memory mapping 0x…`. This is the well-known
  TSan/ASLR kernel-mmapping incompatibility, not a reported data race; the focused
  identifier tests are single-threaded. **Remaining environment blocker; no source
  correction.**
- `focused_memcheck`: exit 127, `/tmp/score-someip84-obligation-tools/usr/bin/valgrind`
  missing. **Tool unavailable; blocker.**

### 4.8 Native / cross / perf / format checks (bazel and other tools unavailable)

`native_build`, `native_tests`, `native_integration`, `native_lint`, `native_docs`,
`native_traceability`, `native_sanitizers`, `native_tsan`, `native_coverage`,
`native_performance`, `cross_compilation`, and `format_precommit` all fail with
`[Errno 2] No such file or directory: '/tmp/s-core-001/bin/bazel'` (exit 127), and
`secret_dependency_checks` shows `gitleaks` unavailable. These are **unavailable-tool
blockers**, not source defects. Per the task rule they remain blockers and are not
treated as satisfied.

### 4.9 Coverage (measured, below the platform goals)

`focused_coverage/coverage-summary.json` (focused `service_identifier.cpp` +
`string_registry.cpp` executable only): overall **28/36 lines = 77.8 %**, **9/14
branches = 64.3 %**; `service_identifier.cpp` 3/3 lines (100 %) and 1/2 branches
(50 %); `string_registry.cpp` 25/33 lines (75.8 %) and 8/12 branches (66.7 %). Below the
platform QM 85 % / safety 100 % goals, and this is not full native coverage. **Not
satisfied; coverage is not a source defect and no in-scope correction follows.**

### 4.10 Process / traceability metadata

`process_checks/result.json` records `completed_with_blockers` with a metadata
inventory: `runtime_tests.cpp` 33 test macros and `service_identifier_tests.cpp` 85
test macros, each carrying `DerivationTechnique` and `Description` record properties
(no `TestType`/`Verifies`, deliberately, because no verified native requirement
identifier exists and inventing one is prohibited). **Metadata present; traceability
linkage and `TestType` not established.**

---

## 5. Conclusion on source corrections

**No safe in-scope source correction is supported by any of the retained diagnostics.**
Specifically:

1. The named GCC syntax failure is **not present**; the header is brace-balanced and
   GCC compiles the candidate with exit 0 and runs 85/85 tests green (§2, §4.1).
2. Every concrete analyzer/sanitizer/security finding either points outside the six
   candidate paths (`registry_string_view.hpp`, `service_interface_identifier.hpp`,
   `.llm_tmp/googletest/**`) or is an unavoidable gtest-macro expansion artifact on the
   test file (§4.3, §4.5, §4.6).
3. Where an in-scope location is flagged (the `TEST_F` `external-linkage` MISRA hits),
   the only "fixes" available are suppressing the rule, editing the test framework, or
   an accepted human deviation — all of which are prohibited or unavailable here.
4. The remaining checks are blocked by missing tools (`bazel`, `valgrind`, `gitleaks`)
   or a tool/config or kernel-environment incompatibility (clang-tidy config, TSan
   mmapping), none of which is a candidate-source defect.

Accordingly this iteration changed the six candidate paths **not at all**, and wrote
only this report.

---

## 6. Obligations status (none satisfied)

### 6.1 Pinned state

`authority.json`: `engineering_acceptance: pending`, `human_reviews: unanswered`,
`safety_class: unknown`, `codeql_scope: Public Apache-2.0 eclipse-score/inc_someip_gateway;
no upload`. Every entry of `source-index.json` is `native_acceptance: not_inferred`.
All nine pinned sources in `.llm_tmp/context/obligations/` were read this iteration
(`coding_guidelines`, `code_analysis`, `misra_mapping` [draft], `verification_plan`,
`development_plan`, `tool_management`, `verification_process`, `verification_guideline`,
`inspection_checklist` [draft]).

### 6.2 Per-obligation status for this slice

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Freedom from compiler warnings & errors (100 %) | `verification_plan.rst` (criterion 9) | **PARTIAL** — GCC focused compile clean (exit 0) and 85/85 tests; Clang blocked on a googletest/libstdc++ deprecation under `-Werror` (§4.2) |
| Static code analysis (clang-tidy / CodeQL), findings classified | `code_analysis.rst`; `verification_process.rst` (SCA classification) | **NOT SATISFIED** — clang-tidy config blocker; cppcheck findings out of scope; CodeQL security dependency-only; CodeQL MISRA applicability draft + gtest-macro hits needing human deviation |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` (draft) | **UNKNOWN** — mapping draft, human deviations pending |
| Structural statement / branch coverage goals | `verification_plan.rst` (criteria 1–2) | **NOT MEASURED to goal** — focused 77.8 % line / 64.3 % branch, below platform 85/100 |
| Unit/component testing executed, results recorded | `verification_plan.rst` (criteria 6–7) | **PARTIAL** — focused 85/85 green (retained capture); full native `socom_test` not executed |
| Interface / requirements-based / resource / fault-injection test types | `verification_process.rst` | **NOT PERFORMED / applicability not inferred** — no harness |
| Boundary / equivalence derivation | `verification_process.rst` | **SOURCE-ONLY** — cases exist; only the focused TU was executed |
| Fuzzy testing technique | `verification_plan.rst` | **NOT EXECUTED / NOT CLAIMED** |
| Linking tests to requirements (record properties) | `verification_process.rst` (`gd_req__verification_link_tests_cpp`) | **PARTIAL** — `DerivationTechnique`/`Description` recorded; `TestType`/`Verifies` absent (no invented identifiers) |
| Independence of verification / review by a different committer | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Implementation inspection checklist IMPL_01…IMPL_03 | `inspection_checklist.rst` (draft) | **NOT FILLED** |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED for this slice** — bazel, valgrind, gitleaks, clang-format, pre-commit, reuse unavailable; clang-tidy config rejected |
| Obligation collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **RETAINED, NOT PASSING** — 24 checks present; most blockers above |
| Native acceptance | `source-index.json` | **not_inferred** for every entry |

**Explicit non-satisfaction statement.** Missing tools, the unknown safety class and
un-inferred applicability, the incomplete extraction (focused TU only, dependency
findings retained), the below-goal focused coverage, and the unanswered human reviews
mean **none of the checked obligations may be treated as satisfied**. A retained
collection result shows *retention*, not passing.

---

## 7. Measurement and validation status

- **Tools:** `read_file`, `grep`, `glob`, `write_file` only. No `shell`, delegation,
  web, approval, publishing, or engineering acceptance.
- **Measurements executed this iteration:** none. All results above are readings of the
  retained tool artifacts and of the working tree.
- **Scope of the retained runs:** the compile/analyze/sanitize runs cover the **focused
  identifier translation unit** (`service_identifier.cpp` + `string_registry.cpp` +
  `service_identifier_tests.cpp`); they do **not** compile `runtime_tests.cpp` or the
  full `socom_test` / `//score/...` targets. Full native runtime tests are
  `not_executed` (`validation/measurement.json:2042`).
- **Scope statement:** local, unprotected, scoped. This report is not acceptance,
  review, publication, or a full native run.
- **Reproduction path for a later, permitted iteration (not executed here):**

  ```bash
  bazel test //score/socom/test/unit:socom_test
  bazel test //score/socom/test/unit:socom_test --test_filter='ServiceInstanceIdentifierTest.*'
  bazel test //score/socom/test/unit:socom_test \
      --test_filter='RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError'
  ```

---

## 8. Notice preservation

- No source, build, test, config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was
  created, edited, or deleted by this iteration; only this report was written.
- Every Apache-2.0 / SPDX header on the six candidate paths is intact; the flagged
  header `score/socom/impl/service_identifier.hpp` retains its header (`:1-12`) and was
  left unchanged (§2).
- All 12 files under `.llm_tmp/overnight/prior-reports/` and the 12 earlier files under
  `.llm_tmp/overnight/reports/` were preserved unchanged.
- This report itself carries the Apache-2.0 header.

---

## 9. Pending human review checklist

- [ ] **Confirm §2**: the header is brace-balanced (nested close at `:38`, line 39
      blank); the recorded "extra closing brace at line 39" is stale and no correction
      is required. If a different "cancelled draft" revision still carries the brace,
      locate that revision and authorize its correction; it is not this checkout.
- [ ] **Accept or deviate the Clang blocker** (§4.2): a googletest/libstdc++ 12
      `-Wdeprecated-declarations` error under `-Werror`, outside the six paths. Decide
      whether the native toolchain pins avoid it; do not suppress the warning in-repo
      without an accepted deviation.
- [ ] **Disposition the cppcheck `passedByValue` findings** (§4.3): they are in
      `registry_string_view.hpp` and `service_interface_identifier.hpp`, out of scope;
      confirm they are acceptable performance style noise or open a separate change.
- [ ] **Restore a working clang-tidy configuration / tool version** (§4.4) so a real run
      can be collected; do not edit the repo `.clang-tidy` inside this slice.
- [ ] **Disposition the CodeQL MISRA `external-linkage` findings** on
      `service_identifier_tests.cpp` (§4.6): confirm they are gtest-macro artifacts and
      record an accepted deviation, or provide tooling that models the macro; do not
      suppress the rule silently.
- [ ] **Provide TSan-capable environment or accepted exclusion** (§4.7), and supply
      `valgrind` / `gitleaks` / `bazel` to convert the remaining blockers into results.
- [ ] **Run the full native suite** (`//score/...` and the integration/QEMU set) and
      record results, including `runtime_tests.cpp`; schedule independent human review
      (`gd_req__verification_independence`).
- [ ] **Supply native requirement/interface identifiers** for traceability links, or
      record applicability as unresolved (no invented links).
- [ ] **Confirm the bounded key decision** (minor excluded; identity `(instance, service
      id, major)`) and the open design questions remain as recorded in the prior
      reports, and keep the wider #84 public restructure out of this slice.
