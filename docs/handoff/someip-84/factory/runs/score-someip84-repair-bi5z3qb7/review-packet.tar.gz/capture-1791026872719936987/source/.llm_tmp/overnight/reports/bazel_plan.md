<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — native Bazel validation plan (`bazel_plan`) review draft

**Document type:** review draft — actual-source inspection + BUILD-change check + exact native Bazel
validation plan + retained-artifact status + pending-execution record.
**Date:** 2026-10-03
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version handling in socom* (issue #84)
**Run / branch:** `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ`
**Verified baseline commit:** `f8a196c3b16d5172d898394ab99b0ed81346d63d` (`.llm_tmp/context/source-manifest.json:3`)
**Status:** local, unprotected, scoped. **No engineering acceptance exists. Human reviews are
unanswered. Full native runtime tests remain pending.** Nothing here is published, reviewed, accepted,
or an engineering-accepted native run.

> **Tool / write boundary actually observed.** This iteration used only `read_file`, `grep`, `glob`, and
> `write_file`. No `shell`, no delegation, no web access, no approval, no publishing, and no engineering
> acceptance was performed. The task's final, explicit sentence — *"This is a review draft: only that
> report may be written."* — governs the write boundary, and the allowed tool list does not include an
> editing tool. Accordingly **exactly one file was written — this report**
> (`/workspace/.llm_tmp/overnight/reports/bazel_plan.md`). No source, build, test, config, `NOTICE`,
> `LICENSE`, or `REUSE.toml` file was created, edited, or deleted, and every prior report was preserved.
>
> **Instruction conflict, recorded rather than silently resolved.** The task also says *"Inspect and
> correct the actual source before expanding tests."* That instruction cannot be executed by this
> iteration for two independent reasons: (1) the write boundary permits only this report; and (2) on the
> facts there is nothing to correct — the file the task names is **brace-balanced**, line 39 is blank,
> and the retained host artifact records its focused GCC compile `exit 0` with an **empty** `stderr`
> (§2). The task's "cancelled draft" therefore does not describe this checkout. The conflict is moot on
> the facts and is carried to the human reviewer in §8.
>
> **Non-satisfaction rule applied throughout.** A successful obligation-collection node means results
> were **retained**, not that checks **passed or were accepted**. Missing tools, unknown applicability,
> incomplete extraction, a draft rule mapping, and unanswered human reviews are **not** treated as
> satisfied obligations. A tool that produced no finding because it did not run is recorded as *"not
> run"*, never as *"clean."*

---

## 0. Summary

1. **This checkout differs materially from what earlier reports recorded.** Earlier drafts
   (e.g. `prior-reports/bazel_plan.md`) describe `.llm_tmp/overnight/validation/` and
   `.llm_tmp/overnight/obligations/*/result.json` as **absent** and every `native_*` leg as
   `exit 127` with `'/tmp/s-core-001/bin/bazel'` missing. **In this checkout both trees are present**
   with populated `result.json` files (§1.5, §5). The measured exit codes are real, retained, local,
   unprotected, scoped results — but they are **not** engineering acceptance.
2. **Flagged syntax failure — inspected; not present.** `score/socom/impl/service_identifier.hpp` is a
   40-line, brace-balanced header (openers `:19`, `:29`; closers `:32`, `:38`; line `:39` blank;
   `:40` = `#endif`). The retained focused compiler artifact shows the header compile as part of the
   focused translation unit with `g++-12 -std=c++17 -Wall -Wextra -Werror` at **`exit 0`** and **empty
   stderr**; no `error:` is recorded in any retained stderr. **No correction is required in this tree,
   and none was applied** (the write boundary forbade a source write in any case). The described defect
   matches the pre-correction split-close form recorded by the earliest prior reports, not this tree
   (§2).
3. **BUILD changes — checked and consistent.** Relative to the pinned baseline blobs,
   `score/socom/BUILD` now exposes the `testonly` `impl_service_identifier` library to
   `//score/socom/test/unit:__pkg__`, and `score/socom/test/unit/BUILD` now depends on it. `socom_test`
   collects `*.cpp` via `glob`, so the new `service_identifier_tests.cpp` and the existing
   `runtime_tests.cpp` are picked up with no further edit. **No BUILD change is required** (§3).
4. **Exact native Bazel validation plan prepared from pinned repository configuration.** The plan in §4
   fixes Bazel `8.6.0`, the registries/toolchains from `.bazelrc`, the coverage/static-analysis
   imports, and the exact target/config/feature invocations — including the focused filters that isolate
   this slice and the warnings-as-errors evidence the default `.bazelrc` disables.
5. **Execution is unavailable to this iteration and is marked pending.** No `shell` is available here,
   so nothing was built, tested, or measured by this iteration. The retained artifacts are prior host
   captures (§5).
6. **No obligation is satisfied or accepted.** `authority.json` records
   `engineering_acceptance: pending`, `human_reviews: unanswered`, `safety_class: unknown`; every
   `source-index.json` entry is `native_acceptance: not_inferred`. Retained failures/timeouts/blockers
   (native lint timeout `124`, docs `2`/traceability `1`, integration `1`, performance `124`,
   clang-tidy config `1`, cppcheck `2`, gitleaks `1`, reuse `1`, CodeQL MISRA blockers, cross-compilation
   QNX blocker) are **unresolved**; even the retained `exit 0` legs are **not** accepted and the
   `native_tests` leg only **built** tests (`--build_tests_only`) (§5, §6).

---

## 1. Binding to the verified baseline, prior reports, host feedback, obligations

### 1.1 Issue of record

| Item | Value | Source |
|------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` — *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:2-4` |
| State | `open`, 0 comments, no milestone / assignee / labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` (unchanged) | `.llm_tmp/context/issue-snapshot.json:19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted obligation**.
It proposes `service identifier = service id + major`, `service-instance identifier = service id + major
+ minor + instance`, `FindService = service id + major + optional<minor> + optional<instance>`, and to
*"exclude the minor version and make it a property of the service instance."* There is **no comment and
no acceptance record**, so none of it is binding. Binding is **by baseline commit**, not by run HEAD.

### 1.2 In-scope candidate files (the slice)

From `.llm_tmp/context/candidate-files.json:1-25` (baseline blobs cross-checked against the `files`
array of `.llm_tmp/context/source-manifest.json`):

| File (repo-relative) | Baseline git blob | Candidate-snapshot sha256 | Working-tree state read this iteration |
|----------------------|-------------------|---------------------------|----------------------------------------|
| `score/socom/BUILD` | `3477ea0851fdcd82ec6ea9d71424013cbdf41962` | `dee82616…` | `socom` library + `testonly` `impl_service_identifier` (`:24-54`) |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e22355242009fe20dada2a9a0d0c7a9c7` | `d766902e…` | `operator<` identity `(instance, service id, major)`, `minor` excluded (`:20-30`) |
| `score/socom/impl/service_identifier.hpp` | `c8bae7908da9f087c518934f7b9f8d86db9a20ec` | `96b33a1f…` | **brace-balanced**, 40 lines, `:39` blank (§2) |
| `score/socom/test/unit/BUILD` | `3c03a7b14286051f97fa5022206564bd63645171` | `9b3c5b34…` | `socom_test` globs `*.cpp`; key dep wired (`:16-29`) |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab726db8bf994c960045d6fd7fdf84d7395` | `5e35e24d…` | **33 macros** (1 `TEST` + 31 `TEST_F` + 1 `TEST_P`); minor-only regression `:402-431` |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(none — `null`; manifest expects a new file)* | `45d07399…` | **91 `TEST_F`** under `ServiceInstanceIdentifierTest` (`:168`…`:2181`) |

**Hash drift, recorded not resolved.** The obligation collectors and the host measurement captured the
tree by their own `source_hashes`, which differ from the candidate-snapshot hashes above — e.g. the
retained runs record `score/socom/impl/service_identifier.hpp` = `bdce3fcb…` and
`score/socom/test/unit/service_identifier_tests.cpp` = `de79767c…`, whereas the candidate snapshot
records `96b33a1f…` and `45d07399…`. No hashing tool is available to this iteration, so the working tree
was **not** re-hashed; the direct source reads in §2–§4 are authoritative for *content* here. The
`de79767c…` test-file hash is the one shared by the retained focused host measurement, the `process_checks`
metadata inventory (91 macros), and the obligation `source_hashes`, i.e. the current 91-case file is the
one those runs saw.

`glob **/service_identifier.hpp` returns exactly one path, so there is no second, differently-braced
copy of the header in this checkout; `glob **/service_identifier*` returns exactly three paths
(`impl/service_identifier.cpp`, `impl/service_identifier.hpp`, `test/unit/service_identifier_tests.cpp`).

### 1.3 Prior reports read and preserved

- `.llm_tmp/overnight/prior-reports/` — 38 files present, all preserved (`scope.md`, `invariants.md`,
  `callsites.md`, `reproducer.md`, `key_fix.md`, `unit_matrix.md`, `ordering_tests.md`,
  `conversion_tests.md`, `runtime_disabled.md`, `runtime_enabled.md`, `lifetime_tests.md`,
  `test_metadata.md`, `bazel_plan.md`, `native_build_review.md`, `analyzer_plan.md`,
  `tool_assurance_review.md`, `security_review.md`, `misra_*`, `finding_classification.md`,
  `review_packet.md`, `verification_report_draft.md`, and the remainder).
- `.llm_tmp/overnight/reports/` — read, not modified: `scope.md`, `reproducer.md`, `key_fix.md`,
  `callsites.md`, `invariants.md`, `api_review.md`, `compatibility.md`, `concurrency_review.md`,
  `conversion_tests.md`, `coverage_tests_repair.md`, `lifetime_review.md`, `lifetime_tests.md`,
  `ordering_tests.md`, `repair_conversion_tests.md`, `runtime_disabled.md`, `runtime_enabled.md`,
  `test_metadata.md`, `tool_findings_repair.md`, `unit_matrix.md`. **No `reports/bazel_plan.md` existed
  before this write** (only `prior-reports/bazel_plan.md` did), so this report is an addition, not an
  overwrite.

Derived sequence (from the preserved reports): `scope.md`/`invariants.md` bounded the slice and
identified the key-vs-index identity gap → `callsites.md` mapped call sites → `reproducer.md` recorded
the header brace correction and the focused red regression → `key_fix.md`/`unit_matrix.md` /
`ordering_tests.md`/`conversion_tests.md` expanded the key suite → `runtime_*`/`lifetime_tests.md`
added runtime regressions → `test_metadata.md` recorded properties → later host iterations classified
findings and repaired tools.

### 1.4 Host validation feedback (`.llm_tmp/overnight/validation/`) — **present in this checkout**

| Artifact | Content (read this iteration) |
|----------|-------------------------------|
| `check-result` | `0` (collector success marker only) |
| `before-compile.command.json` | focused identifier TU `g++-12 -std=c++17 -Wall -Wextra -Werror`; `exit_code: 0` |
| `before-compile.stderr` | **empty** |
| `before-test.command.json` / `before.json` | baseline candidate binary; `exit_code: 1`; `tests: 91`, `failures: 33` |
| `after-compile.command.json` | same focused TU **plus** `-fsanitize=undefined -fno-sanitize-recover=all`; `exit_code: 0` |
| `after-compile.stderr` | **empty** (no `error:` recorded) |
| `after-test.command.json` / `after-test.stdout` | candidate binary `--gtest_output=json:…`; `exit_code: 0`; 91/0 |
| `measurement.json` | `check_ref: check_conversion_tests`, `mode: ubsan`, `origin: local_unprotected_measurement`, `initiator: Fabro host hook`, `engineering_acceptance: pending`, `full_native_tests: not_executed`, `changed_paths: ["score/socom/test/unit/service_identifier_tests.cpp"]`, compiler `/usr/bin/x86_64-linux-gnu-g++-12`; `baseline_with_agent_tests` **91 tests / 33 failures / compile_exit 0**; `candidate` **91 tests / 0 failures / compile_exit 0** |

**Scope and freshness.** The retained measurement compiles **only** the focused identifier translation
unit (`service_identifier.cpp` + `string_registry.cpp` + `service_identifier_tests.cpp`) plus googletest.
It does **not** compile or run `runtime_tests.cpp`, and it is **not** a Bazel run. Its `91` tests match
the current file's **91 `TEST_F`** cases (verified this iteration by `grep`;
`process_checks` records `test_macros: 91`), so the measurement is *not* stale in size — but it remains
scoped to the key TU and is not a native Bazel result.

### 1.5 Pinned obligation sources, authority, and retained obligation results

All nine entries of `.llm_tmp/context/obligations/source-index.json` are present in
`.llm_tmp/context/obligations/`, together with `authority.json`. Every entry is
`"native_acceptance": "not_inferred"` (pinned, applicability not inferred).

**Authority record** (`.llm_tmp/context/obligations/authority.json`): `engineering_acceptance: pending`,
`human_reviews: unanswered`, `safety_class: unknown`, `codeql_scope: "Public Apache-2.0
eclipse-score/inc_someip_gateway; no upload"`, instruction *"Restart the failed queue for one complete
pass through all obligations"*.

**Retained obligation results — present in this checkout.** `.llm_tmp/overnight/obligations/*/result.json`
now exists for all 25 collectors. They are `origin: local_unprotected_measurement` with
`engineering_acceptance: pending`, and most carry a `check_ref: recollect_*` plus a `reused_from` path on
the host run directory — i.e. they are **retained/recollected prior host captures**, not fresh executions
of this iteration. §5 records their commands, exit codes, and statuses.

---

## 2. The flagged syntax failure: inspection of the actual source and correction status

### 2.1 Finding (direct `read_file` this iteration)

`score/socom/impl/service_identifier.hpp` is **brace-balanced** and 40 lines:

| Line | Content | Role |
|------|---------|------|
| 14–15 | `#ifndef SRC_SOCOM_SRC_SERVICE_IDENTIFIER` / `#define …` | include guard |
| 17 | `#include "score/socom/service_interface_identifier.hpp"` | include |
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 30–31 | `Service_interface_identifier interface;` / `Service_instance instance;` | members |
| 32 | `};` | closes the struct |
| 35 | `bool operator<(…);` (inside `/// \cond`) | declaration |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`) and two closers (`:32`, `:38`): net brace balance `0`. There is **no third,
unmatched closing brace**, and line 39 contains no text. The sibling `score/socom/impl/service_identifier.cpp`
uses the same nested form and is balanced (braces at `:18`, `:20`, `:30`, `:32`).

### 2.2 Corroboration from the retained host artifacts

- `validation/before-compile.stderr` and `validation/after-compile.stderr` are **empty**;
  `before-compile.command.json` and `after-compile.command.json` both record **`exit_code: 0`** for the
  focused translation unit that includes this header.
- `obligations/compiler_diagnostics/result.json` records `gcc-compile` (with `-Werror`) `exit 0`,
  `gcc-tests` `exit 0`, `clang-compile` `exit 0`, `clang-tests` `exit 0` — status `completed` — with the
  limit *"Focused executable only; GCC 12.3 / Clang 19 differ from native toolchain pins."*
- No retained `stderr` records an `error:` for this header.

A surviving extra closing brace would have failed these focused compiles. The task's *"extra closing
brace … at line 39"* therefore matches the earliest prior reports (which quote the old split-form
`}  // namespace socom` + `}  // namespace score`), **not** this checkout. The `reproducer` iteration
applied the correction; the removed brace left line 39 blank, exactly as observed here.

### 2.3 Minimal historical repair (reference only; NOT applied)

Should the imbalance ever reappear, the minimal correction — matching the sibling `.cpp` and the nested
form — is:

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

Applying this to the already-balanced file is a no-op; deleting a brace would *create* the reported
defect. Because the explicit write boundary ("only that report may be written") permits no source write,
this iteration does not touch the source irrespective of the finding. **If the "cancelled draft" is a
distinct revision that still carries the extra brace, it is not the file in this checkout and must be
located and corrected by an authorized iteration.**

### 2.4 Why it would matter if present

The header is compiled into `//score/socom:socom` (`score/socom/BUILD:24-41`; `srcs` globs
`impl/**/*.cpp` and `impl/**/*.hpp`) and re-exposed `testonly` through `//score/socom:impl_service_identifier`
(`score/socom/BUILD:46-54`), consumed by `//score/socom/test/unit:socom_test`
(`score/socom/test/unit/BUILD:23-29`). A syntax error there would fail the library and the whole
`socom_test` target, contradicting quality criterion 9 (*freedom from compiler warnings & errors, 100 %*).
That is **not a blocker in this tree** — a static balance reading plus a retained scoped compile, not a
native Bazel measurement.

---

## 3. BUILD change check

### 3.1 Current wiring (read this iteration)

**`score/socom/BUILD`** (baseline blob `3477ea08…`):

- `cc_library(name = "socom")` — `srcs = glob(["impl/**/*.cpp", "impl/**/*.hpp"])`, `hdrs = [":headers"]`,
  `defines = ["WITH_SOCOM_DEADLOCK_DETECTION=1"]`, `features = COMPILER_WARNING_FEATURES`, public
  visibility, deps on `@score_baselibs//score/language/futurecpp`, `…//score/mw/log`, `…//score/result`
  (`:24-41`). The internal key header is therefore part of the compiled library.
- **Change vs. baseline:** `cc_library(name = "impl_service_identifier", testonly = True,
  hdrs = ["impl/service_identifier.hpp"], visibility = ["//score/socom/test/unit:__pkg__"],
  deps = [":socom"])` (`:46-54`), with the comment at `:43-45` documenting the exposure.

**`score/socom/test/unit/BUILD`** (baseline blob `3c03a7b1…`):

- `cc_test(name = "socom_test", size = "small", srcs = glob(include = ["*.cpp"]), linkstatic = True,
  tags = ["unit"], visibility = ["//tests/integration_test:__pkg__"], deps = [":impl_service_identifier",
  "//score/socom:mock", "//score/socom/test/framework:socom_test_framework", "@googletest//:gtest",
  "@googletest//:gtest_main"])` (`:16-29`).
- **Change vs. baseline:** the dep `//score/socom:impl_service_identifier` is present so the test
  translation units can include `score/socom/impl/service_identifier.hpp`. The `*.cpp` glob collects both
  `service_identifier_tests.cpp` (new; no baseline blob) and `runtime_tests.cpp` **without any further
  BUILD edit**.

**Top-level `BUILD`:** the `unit_tests` `test_suite` explicitly lists `//score/socom/test/unit:socom_test`
(`:52-59`); `use_format_targets(...)`, `use_clang_tidy_targets()` and `use_ruff_targets()` create the
format/lint entry points (`:32-39`, `:118-120`). No change required there.

### 3.2 Consistency conclusion

- The `testonly` header exposure is scoped to `//score/socom/test/unit:__pkg__` — the only consumer — so
  no public/visibility surface changed and no notice surface changed.
- Both current test files are inside the `*.cpp` glob; no new `srcs` entry is needed.
- **No BUILD change is required for the current slice.** This is a static consistency check, not a build.
  The only authoritative confirmation that the loaded `BUILD`/`MODULE` graph resolves and that the new
  header exposure is accepted is a real `bazel build` / `bazel query` run (§4); the retained
  `native_build` result records `build --jobs=2 //...` at `exit 0` (§5), but that is a retained local
  capture, not acceptance, and it was not executed by this iteration.

---

## 4. Exact native Bazel validation plan (from pinned repository configuration)

### 4.1 Pinned configuration

| Item | Value | Source |
|------|-------|--------|
| Bazel version | **8.6.0** | `.bazelversion:1`; collector env `USE_BAZEL_VERSION=8.6.0` |
| Registries | `https://raw.githubusercontent.com/eclipse-score/bazel_registry/main/`, `https://bcr.bazel.build` | `.bazelrc:111-112` |
| Default test output | `--test_output=errors` | `.bazelrc:108` |
| Strict action env | `build --incompatible_strict_action_env` | `.bazelrc:109` |
| Default warning feature | `common --features=-treat_warnings_as_errors` | `.bazelrc:117` |
| Toolchains / platforms | `@score_linux_x86_64_ext4_toolchain//:ext4-x86_64-linux`, `@score_gcc_x86_64_toolchain//:all`; `_toolchain_common` host platform `@score_bazel_platforms//:x86_64-linux` | `.bazelrc:44-71` |
| Integration (QEMU) | `--config=qemu-integration` → linux-sandbox strategy + `--run_under=@score_itf//scripts:run_under_qemu` | `.bazelrc:73-85` |
| Performance | `--config=perf-tests` (`//tests/benchmarks:setup_network`, `--define=perf_tests=true`, `opt`); `--config=perf-tests-flamegraphs` | `.bazelrc:88-106` |
| Coverage | `coverage --config=llvm_cov`; `--combined_report=lcov`, `--instrumentation_filter=^//score[/:]`, LLVM toolchain, `//tools/coverage:reporter_wrapper` | `coverage.bazelrc:22-68` |
| Static analysis | `test --config=clang-tidy` (aspect `//tools/lint:linters.bzl%clang_tidy`, fail-on-violation); `build --config=ruff`; entry points `//:clang-tidy.check`, `//:ruff.check`, `//:format.check` | `static_analysis.bazelrc:20-42`; `BUILD:118-120` |
| Sandbox mounts | `test --sandbox_tmpfs_path=/dev/shm`, `test --sandbox_tmpfs_path=/tmp` | `.bazelrc:124-126` |
| Collector wrapper flags | `--batch`, `--output_user_root=<run>/bazel-cache`, `--jobs=2` | every `obligations/*/result.json` `commands[].argv` |
| Collector env | `PATH=<tools>/bin:…`, `HOME`, `TMPDIR`, `BAZELISK_HOME`, `USE_BAZEL_VERSION=8.6.0`, `PRE_COMMIT_HOME`, `XDG_CACHE_HOME`, `LANG=C.UTF-8`, `LD_LIBRARY_PATH`, `VALGRIND_LIB` | e.g. `obligations/native_build/result.json:1066-1075` |
| Bazel binary in retained native workspace | `<run>/score-someip84-tools-…/bin/bazel` (host path recorded in `tool_assurance.tool_inventory`) | `obligations/tool_assurance/result.json:1408-1411` |

`socom_test` is `size = "small"`, `linkstatic = True`, tagged `unit`
(`score/socom/test/unit/BUILD:16-22`), so the standard `bazel test` strategy applies.

### 4.2 Ordered plan (exact invocations; to be executed by an authorized iteration with `bazel` available)

Stage 1 — graph and compile only (fastest; catches the recorded syntax-failure class and BUILD breakage):

```bash
# 1a. confirm the BUILD graph loads and the new test file is collected
bazel --batch --output_user_root=<run>/bazel-cache query 'tests(//score/socom/test/unit:all)'
bazel --batch --output_user_root=<run>/bazel-cache build --jobs=2 \
    //score/socom:socom //score/socom:impl_service_identifier

# 1b. full compile of everything (the retained native_build collector command)
bazel --batch --output_user_root=<run>/bazel-cache build --jobs=2 //...
```

Stage 2 — focused unit tests for this slice on the default host toolchain:

```bash
# 2a. whole socom unit test target (collects service_identifier_tests.cpp + runtime_tests.cpp)
bazel --batch --output_user_root=<run>/bazel-cache test --jobs=2 //score/socom/test/unit:socom_test

# 2b. key-level identity/ordering matrix only
bazel --batch --output_user_root=<run>/bazel-cache test --jobs=2 \
    //score/socom/test/unit:socom_test --test_filter='ServiceInstanceIdentifierTest.*'

# 2c. the runtime-level minor-only duplicate regression
bazel --batch --output_user_root=<run>/bazel-cache test --jobs=2 \
    //score/socom/test/unit:socom_test \
    --test_filter='RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError'

# 2d. all runtime-level cases
bazel --batch --output_user_root=<run>/bazel-cache test --jobs=2 \
    //score/socom/test/unit:socom_test --test_filter='RuntimeTest.*'

# 2e. aggregate unit/component suites (the retained native_traceability step)
bazel --batch --output_user_root=<run>/bazel-cache test --jobs=2 //:unit_tests //:component_tests
```

Stage 3 — full native suite as pinned by the collectors:

```bash
# 3a. all tests, build-only (the retained native_tests collector command; NOTE: builds, does not run)
bazel --batch --output_user_root=<run>/bazel-cache test --jobs=2 //... --build_tests_only

# 3b. warnings-as-errors evidence for criterion 9 (explicit; the default .bazelrc disables it)
bazel --batch --output_user_root=<run>/bazel-cache build --jobs=2 \
    --features=treat_warnings_as_errors //score/socom/...
```

Stage 4 — coverage (criteria 1–2; platform goals 85 % QM / 100 % safety per
`verification_plan.rst` criterion tables):

```bash
# 4a. coverage collection (the retained native_coverage collector command)
bazel --batch --output_user_root=<run>/bazel-cache coverage --jobs=2 //... --build_tests_only

# 4b. HTML/report generation
bazel --batch --output_user_root=<run>/bazel-cache run --jobs=2 \
    @score_coverage//:generate_coverage_html -- --archive-dir <run>/coverage
```

Note: the retained coverage collector env sets `COVERAGE_THRESHOLD=73`
(`obligations/native_coverage/result.json:1077`) — the **repository CI threshold**, not the platform
85 %/100 % acceptance; a 73 % pass must not be reported as platform-goal satisfaction (the result itself
records the same limit, `:1117-1119`).

Stage 5 — static analysis (`code_analysis.rst`):

```bash
bazel --batch --output_user_root=<run>/bazel-cache run --jobs=2 //:clang-tidy.check
bazel --batch --output_user_root=<run>/bazel-cache run --jobs=2 //:ruff.check
# alternative aspect form if the run targets are unavailable:
# bazel --batch --output_user_root=<run>/bazel-cache test --config=clang-tidy //score/socom/...
```

Stage 6 — sanitizers and concurrency (TSAN):

```bash
# ASan + LSan + UBSan (the retained native_sanitizers collector command)
bazel --batch --output_user_root=<run>/bazel-cache test --jobs=2 //score/... //tests/... \
    --build_tests_only --features=asan --features=lsan --features=ubsan_clang

# ThreadSanitizer (the retained native_tsan collector command)
bazel --batch --output_user_root=<run>/bazel-cache test --jobs=2 //score/... //tests/... \
    --build_tests_only --features=tsan
```

Stage 7 — cross-compilation (architecture coverage):

```bash
bazel --batch --output_user_root=<run>/bazel-cache build --jobs=2 --config=x86_64-linux  //score/... //tests/...
bazel --batch --output_user_root=<run>/bazel-cache build --jobs=2 --config=aarch64-linux //score/... //tests/...
# QNX configs (x86_64-qnx / aarch64-qnx) exist in .bazelrc:59-69 and require the QNX toolchains/credentials.
```

Stage 8 — integration (QEMU) and docs/traceability/performance/format:

```bash
# QEMU integration (retained native_integration command; prerequisites recorded: kvm present, /usr/bin/qemu-system-x86_64)
bazel --batch --output_user_root=<run>/bazel-cache test --jobs=2 --config=qemu-integration \
    //quality/... //tests/integration_test/...

# docs / traceability (retained native_docs, native_traceability commands)
bazel --batch --output_user_root=<run>/bazel-cache run --jobs=2 //:docs
bazel --batch --output_user_root=<run>/bazel-cache run --jobs=2 //:traceability_gate -- \
    --metrics-json <run>/native-workspace/_build/metrics.json --need-type=comp_req

# performance (retained native_performance commands)
bazel --batch --output_user_root=<run>/bazel-cache test --jobs=2 --config=perf-tests \
    //tests/benchmarks/... --build_tests_only
bazel --batch --output_user_root=<run>/bazel-cache test --jobs=2 --config=perf-tests-flamegraphs \
    //tests/benchmarks/... --build_tests_only

# format / pre-commit / reuse / module hygiene (retained format_precommit commands)
bazel --batch --output_user_root=<run>/bazel-cache test --jobs=2 //:format.check
pre-commit run --all-files
reuse lint
bazel --batch --output_user_root=<run>/bazel-cache mod tidy
bazel --batch --output_user_root=<run>/bazel-cache mod deps --lockfile_mode=error
```

### 4.3 Expected outcome for this slice (source-derived, not measured here)

On the current key (`minor` excluded; identity `(instance, service id, major)`,
`score/socom/impl/service_identifier.cpp:28-29`), the minor-only key cases collapse a `std::set` to one
element and case 2c returns `Construction_error::duplicate_service`. On a key that includes `minor`,
those focused cases fail and 2c would construct a second connector instead of returning the error. These
are `std::set` / strict-weak-ordering consequences, **not observed results**. Current inventories:
`service_identifier_tests.cpp` = **91 `TEST_F`**; `runtime_tests.cpp` = **31 `TEST_F` + 1 `TEST` +
1 `TEST_P`** (33 macros; `process_checks` metadata inventory agrees).

The retained host measurement (§1.4) already shows, on the focused key TU only: baseline-of-record key
`91 / 33` red → candidate `91 / 0` green with `mode: ubsan`, `exit 0`. That is scoped local evidence and
must not be presented as the native Bazel result of Stage 2.

### 4.4 Non-Bazel focused variants (retained, not a substitute)

The pinned collectors also define focused, non-Bazel variants whose exact `argv` is retained in the
corresponding `obligations/*/result.json`: `compiler_diagnostics` (gcc/clang diagnostics),
`focused_coverage` (gcovr), `focused_asan_lsan`, `focused_memcheck` (valgrind), `focused_tsan`,
`focused_cppcheck`, `focused_clang_tidy` (config verification), `codeql_security`, `codeql_misra`,
`secret_dependency_checks`, `process_checks`, `tool_assurance`, `format_precommit`, `rework_progress`.
None substitutes for the native `bazel` plan above, because the focused C++ variants cover only the
focused identifier TU and the CodeQL variants extract a focused linked executable.

---

## 5. Execution status: unavailable to this iteration (pending), retained artifacts recorded

### 5.1 This iteration's execution

**Unavailable / pending.** This iteration has no `shell`, so it executed **no** build, test, coverage,
sanitizer, CodeQL, integration, cross-compilation, performance, or Bazel command. Everything measured in
§1.4/§5.2 was produced by earlier host runs and merely read here. Per the task, execution of the §4 plan
is marked **pending / unavailable**.

### 5.2 Retained obligation results present in this checkout (read this iteration)

`origin: local_unprotected_measurement`, `engineering_acceptance: pending`. "Retained" ≠ "passed";
"exit 0" is a local, unprotected capture, not acceptance.

| Obligation | Exact command (retained `argv`) | Exit | Recorded status |
|------------|--------------------------------|------|-----------------|
| `native_build` | `build --jobs=2 //...` | `0` | completed |
| `native_tests` | `test --jobs=2 //... --build_tests_only` (**builds; does not run**) | `0` | completed |
| `native_coverage` | `coverage --jobs=2 //... --build_tests_only`; `run @score_coverage//:generate_coverage_html` | `0`; `0` | completed (limit: CI threshold 73 ≠ platform 85/100) |
| `native_lint` | `run //:clang-tidy.check`; `run //:ruff.check` | `124` (timeout); `0` | findings_or_execution_failure |
| `native_sanitizers` | `test //score/... //tests/... --build_tests_only --features=asan --features=lsan --features=ubsan_clang` | `0` | completed |
| `native_tsan` | `test //score/... //tests/... --build_tests_only --features=tsan` | `0` | completed |
| `cross_compilation` | `build --config=x86_64-linux`; `build --config=aarch64-linux` | `0`; `0` | completed_with_blockers (QNX SDK/credential not configured) |
| `native_integration` | `test --config=qemu-integration //quality/... //tests/integration_test/...` | `1` | findings_or_execution_failure (kvm present; qemu present) |
| `native_docs` | `run //:docs` | `2` | findings_or_execution_failure |
| `native_traceability` | `test //:unit_tests //:component_tests`; `run //:docs`; `run //:traceability_gate … --need-type=comp_req` | `0`; `2`; `1` | findings_or_execution_failure |
| `native_performance` | `test --config=perf-tests //tests/benchmarks/...`; `--config=perf-tests-flamegraphs` | `124`; `124` | findings_or_execution_failure |
| `compiler_diagnostics` | focused gcc/clang compile + tests (`-Werror`) | `0`,`0`,`0`,`0` | completed (limit: GCC 12.3 / Clang 19 ≠ native pins) |
| `focused_coverage` | focused gcc `--coverage` + tests + `gcovr` | `0`,`0`,`0` | completed; line **100 %**, branch **78.6 %**, `complete_target_scope: false`, `safety_class: unknown_requires_authorized_selection` |
| `focused_asan_lsan` | focused `-fsanitize=address,leak,undefined -fno-sanitize-recover=all` | `0`,`0` | completed |
| `focused_memcheck` | focused build + `valgrind --tool=memcheck --leak-check=full --error-exitcode=42` | `0`,`0` | completed |
| `focused_tsan` | focused `-fsanitize=thread` compile; tests | `0`; `66` | findings |
| `focused_cppcheck` | `cppcheck --enable=warning,style,performance,portability --error-exitcode=2 …` | `2` | findings_or_execution_failure (limit: no inferred MISRA coverage) |
| `focused_clang_tidy` | `clang-tidy --verify-config --config-file=.clang-tidy` | `1` | findings_or_execution_failure (blocker: native analyzer config incompatible; no replacement called MISRA) |
| `codeql_security` | `codeql database create` + `analyze … cpp-security-and-quality.qls` | `0`; `0` | findings_or_execution_failure (blockers `[]`; findings retained; scope Public Apache-2.0 only) |
| `codeql_misra` | `codeql database create` + `analyze … misra-cpp-default.qls` | `0`; `0` | findings_or_execution_failure (blockers: MISRA applicability/mapping draft & incomplete; default suite omits manual/audit obligations; compiled-query qualification and human deviations pending) |
| `secret_dependency_checks` | `gitleaks dir <src> --redact=100 --report-format=json …` | `1` | findings_or_execution_failure (blocker: no adopted vuln DB; inventory ≠ vulnerability scan) |
| `format_precommit` | `git init`; `git add --all`; `test //:format.check`; `pre-commit run --all-files`; `reuse lint`; `mod tidy`; `mod deps --lockfile_mode=error` | `0`,`0`,`124`,`0`,`1`,`0`,`0` | findings_or_execution_failure (limit: mutations only in disposable copy) |
| `process_checks` | (no commands; lexical metadata inventory) | — | completed_with_blockers (metadata cannot prove semantic requirement coverage; safety/QM applicability & tailoring unknown; independent inspection/acceptance required; external AoU + full integration need scoped review) |
| `tool_assurance` | 15 × `<tool> version/--version` | all `0` | completed_with_blockers; every inventoried tool **available** (bazel, clang++, clang-tidy, codeql, gcov-12, gcovr, cppcheck, clang-format, pre-commit, reuse, qemu-system-x86_64, perf, valgrind, gitleaks) |
| `rework_progress` | (no commands) | — | completed; `source_changed_this_round: false`, `rework_requested: false`, stop reason *"One complete pass requested; unresolved findings stay pending"* |

**Reading of §5.2.** The earlier reports' blanket claim of `exit 127` / missing `bazel` is **superseded
in this checkout**: `bazel` was available to those host runs and the build/test-build/coverage/
sanitizer-build/TSAN-build/x86_64+aarch64 cross-build legs reported `exit 0`. That does **not** make any
obligation accepted: the results are local/unprotected/scoped, several sibling legs failed or timed out,
`native_tests` only built tests (`--build_tests_only`), coverage used the CI threshold (73) not the
platform goals, the focused coverage is out of full target scope with an unknown safety class, and the
authority record still says `engineering_acceptance: pending` / `human_reviews: unanswered`.

---

## 6. Obligations status (none satisfied or accepted)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Freedom from compiler warnings & errors (100 %) | `verification_plan.rst` criterion 9 | **NOT ACCEPTED / NOT MEASURED natively** — header brace-balanced by inspection (§2); retained focused gcc/clang compiles `exit 0` with empty stderr; retained `native_build //...` `exit 0`; no Bazel warnings-as-errors evidence captured (3b not run) and no acceptance |
| Structural statement / branch coverage goals | `verification_plan.rst` criteria 1–2 | **NOT MEASURED at goal** — retained native coverage used threshold 73; focused TU 100 % line / 78.6 % branch, out of full target scope, safety class unknown |
| Unit/component tests executed and recorded | `verification_plan.rst` criteria 6–7; `verification_guideline.rst` | **NOT ACCEPTED** — retained `native_tests` only *built* tests; retained `native_traceability` `//:unit_tests //:component_tests` `exit 0` is a retained local capture; retained host run covers only the focused key TU and excludes `runtime_tests.cpp` |
| Test execution via pinned Bazel build system | `verification_plan.rst`; `development_plan.rst` | **PENDING in this iteration** — no `shell`; retained Bazel results are local/unprotected captures |
| Static code analysis (clang-tidy / CodeQL), findings classified | `code_analysis.rst`; `verification_process.rst` (SCA classification) | **NOT ACCEPTED** — retained `native_lint` clang-tidy timed out (`124`); focused clang-tidy config rejected (`1`); CodeQL MISRA blockers (draft mapping); CodeQL security findings retained but unclassified by an authorized reviewer |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` | **UNKNOWN — NOT CLAIMED** — mapping `:status: draft`; CodeQL MISRA default suite omits manual/audit obligations |
| Sanitizer / concurrency checks | `code_analysis.rst`; `verification_process.rst` | **NOT ACCEPTED** — retained sanitizer/TSAN legs build-only `exit 0`; focused TSAN tests `66`; focused ASan/LSan and memcheck `exit 0` (scoped) |
| Cross-compilation (x86_64/aarch64) | `development_plan.rst` | **PARTIAL / NOT ACCEPTED** — retained x86_64+aarch64 builds `exit 0`; QNX blocker; scoped |
| Integration (QEMU) | `verification_process.rst` | **FAILED (retained)** — `exit 1` despite kvm/qemu present; not rerun here |
| Docs / traceability gates | `verification_process.rst` (`gd_req__verification_link_tests_cpp`) | **FAILED (retained)** — docs `2`, traceability gate `1`; record properties `DerivationTechnique`/`Description` present, `TestType`/`Verifies` deliberately unset (no invented links) |
| Performance | `verification_plan.rst` | **FAILED (retained)** — `exit 124` (timeout) both configs; not rerun here |
| Secret / dependency checks | `tool_management.rst`; `code_analysis.rst` | **FAILED (retained)** — gitleaks `exit 1`; no vuln DB; inventory only |
| Format / pre-commit / reuse | `contributing.md`; repository config | **FAILED (retained)** — format `124`, reuse lint `1`; pre-commit `0` |
| Independence of verification / review by a different committer | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED for acceptance** — every tool is now inventoried as available (`tool_assurance`), but evaluation/qualification and release decision are human acts and remain pending |
| Native acceptance | `.llm_tmp/context/obligations/source-index.json` | **`not_inferred` for every entry** |

**Explicit non-satisfaction statement.** The retained local results — including the `exit 0` legs — the
unknown safety class and un-inferred applicability, the incomplete extraction of host artifacts, the
draft MISRA mapping, and the unanswered human reviews mean **none of the checked obligations may be
treated as satisfied or accepted**. In particular, `check-result: 0` and any `exit_code: 0` are
collection/measurement artefacts, not engineering acceptance; and the task's own execution of the §4
plan is unavailable and marked **pending**.

---

## 7. Notice preservation

- No source, build, test, config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was created, edited, or
  deleted by this iteration; only this report was written. Every existing Apache-2.0 / SPDX notice
  header is untouched, and all 38 `prior-reports/` files plus the existing `reports/` files were
  preserved.
- The header the task flagged (`score/socom/impl/service_identifier.hpp`) was inspected and left
  unchanged because it is already brace-balanced and otherwise well-formed (§2). The sibling
  `service_identifier.cpp`, both BUILD files, and both candidate test files likewise retain their
  Apache-2.0 / SPDX headers.
- This report carries the Apache-2.0 header.
- The duplicate key remains an `impl/`-only type; the `testonly`
  `//score/socom:impl_service_identifier` library exposes it to `//score/socom/test/unit` only, so no
  public header or notice surface changed.

---

## 8. Pending human review checklist

- [ ] **Confirm the §2 inspection**: `score/socom/impl/service_identifier.hpp` is already brace-balanced
      (single nested close `}  // namespace score::socom`; line 39 blank), and the retained focused
      compile is `exit 0` with empty stderr — so the recorded syntax failure is stale / refers to a
      different revision, and no source correction is required in this checkout. If the "cancelled
      draft" is a distinct revision that still carries the extra brace, locate it and authorize its
      correction; no such file exists here.
- [ ] **Resolve the instruction conflict** (correct-the-source vs. review-draft-only-report) and confirm
      that writing only this report was the intended outcome.
- [ ] **Confirm the BUILD-change check in §3** — the `testonly impl_service_identifier` exposure and the
      `socom_test` dependency — and confirm no further BUILD edit is needed for the 91-case
      `service_identifier_tests.cpp` / 33-macro `runtime_tests.cpp`.
- [ ] **Reconcile the retained-result change** from earlier drafts: `.llm_tmp/overnight/validation/` and
      `.llm_tmp/overnight/obligations/*/result.json` are now present, several native legs report
      `exit 0`, and the earlier `exit 127`/missing-bazel claim is superseded. Confirm which of the
      retained results, if any, may be promoted, and re-run them against the exact current tree hashes
      under §4.
- [ ] **Confirm and resource the native Bazel plan in §4** (Bazel 8.6.0; targets/configs; focused
      `--test_filter` cases 2b–2d; warnings-as-errors evidence 3b; coverage threshold 73 vs. platform
      85 %/100 %; sanitizers; TSAN; cross-compilation incl. QNX credentials; QEMU integration;
      docs/traceability; performance; format/`reuse`), and restore `bazel` for this iteration's
      environment so the plan can execute.
- [ ] **Address the retained failures** — `native_lint` clang-tidy timeout, `native_docs` /
      `native_traceability` failure, `native_integration` `exit 1`, `native_performance` timeout,
      `focused_clang_tidy` config rejection, `focused_cppcheck`, gitleaks, `reuse lint`, and the CodeQL
      MISRA blockers — before treating any leg as closed.
- [ ] **Run the full native suite**, including `runtime_tests.cpp`, record pass/fail and coverage at the
      platform goals, and schedule independent human review (the approver must differ from the author,
      per `gd_req__verification_independence`).
- [ ] **Select a safety class** via the authorized role; do not infer the slice's class from the
      `:safety: ASIL_B` attribute on the pinned platform documents or from the retained focused coverage
      record (`safety_class: unknown_requires_authorized_selection`).
- [ ] **Do not treat** retained focused host measurements, `check-result: 0`, any `exit_code: 0`, or the
      now-available tool inventory as satisfied obligations; keep `native_acceptance: not_inferred`,
      `engineering_acceptance: pending`, `human_reviews: unanswered`, and `safety_class: unknown`.

---

*End of native Bazel validation plan review draft. Local, unprotected, scoped. No engineering
acceptance; human reviews unanswered; full native runtime tests pending. Every statement is a local
reading of the working tree, a retained-artifact reading, or an explicitly-labelled logical
consequence — none is acceptance, review approval, publication, or a full native run.*
