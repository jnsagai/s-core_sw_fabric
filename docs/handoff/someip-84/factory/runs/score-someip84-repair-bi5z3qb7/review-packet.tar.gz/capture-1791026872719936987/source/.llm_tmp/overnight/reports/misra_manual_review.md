<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — manual coding-guideline inspection of the changed duplicate-server registration-key implementation (`misra_manual_review`)

**Document type:** review draft — actual-source manual inspection of the changed implementation against the pinned C++ coding guideline; initialization / lifetimes / conversions / ordering / error handling / concurrency; verified-identifier register; evidence; unresolved manual obligations; obligations status.

**Date:** 2026-10-03
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version handling in socom* (issue #84)
**Run / branch:** `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ`
**Verified baseline commit:** `f8a196c3b16d5172d898394ab99b0ed81346d63d` (`.llm_tmp/context/source-manifest.json:3`)
**Status:** **local, unprotected, scoped. No engineering acceptance exists. Human reviews are unanswered. Full native runtime tests are pending.** Every statement below is either a direct static reading of this checkout, a reading of a retained artifact under `.llm_tmp/overnight/`, or an explicitly-labelled logical consequence. Nothing here is published, reviewed, accepted, or a full native run. **No MISRA C++:2023 compliance is claimed, and no MISRA rule identifier is asserted to "apply" to this slice in the process sense** (§6, §8). Human inspection remains pending (§11).

> **Tool / write boundary observed.** This iteration used only `read_file`, `grep`, `glob`, and `write_file`. No `shell`, no `edit_file`, no delegation, no web access, no approval, no publishing, and no engineering acceptance was performed. The task's final sentence says *"This is a review draft: only that report may be written."* **Exactly one file was written — this report** (`/workspace/.llm_tmp/overnight/reports/misra_manual_review.md`). No source, build, test, config, `NOTICE`, `LICENSE`, `REUSE.toml`, prior-report, host-validation, or obligation-collection artifact was created, edited, or deleted. Every prior report under `.llm_tmp/overnight/prior-reports/` and every earlier report under `.llm_tmp/overnight/reports/` was preserved unchanged.
>
> **Source-correction instruction vs. review-draft boundary (recorded, not silently resolved).** The task records *"a measured GCC syntax failure: an extra closing brace in `score/socom/impl/service_identifier.hpp` at line 39"* and directs *"Inspect and correct the actual source before expanding tests"*, while the final sentence says *"This is a review draft: only that report may be written."* Direct inspection of the *actual* working tree (§2) shows the header is **already brace-balanced**; line 39 is blank and line 40 is `#endif`. There is no unmatched brace to remove. The review-draft sentence forbids a source write in any case. The two instructions conflict; the conflict is recorded for the human reviewer (§11) and **no source was edited**. No test was expanded either — the draft's suites already exist on disk and are read, not run (§5.2, §9).
>
> **Non-satisfaction rule applied throughout.** A successful obligation-collection node means the results were **retained**, not that the checks **passed**. Missing tools, unknown applicability, incomplete extraction, an inactive/draft rule mapping, a blank inspection checklist, unclassified findings, and unanswered human reviews are **not** treated as satisfied. A tool that did not run is recorded as *"not run"*, never as *"clean"*.

---

## 0. Summary

1. **The changed implementation is the registration-key type and its single comparator, and the manual inspection finds no confirmed safety-relevant defect in the six named topics.** The changed constructs are `Service_instance_identifier` (`score/socom/impl/service_identifier.hpp:29-32`) and its `operator<` (`score/socom/impl/service_identifier.cpp:20-30`). The comparator orders by `(instance, service id, major)` and deliberately excludes `minor` (`service_identifier.cpp:28-29`).
2. **The recorded syntax failure is not present in the actual source** (§2). The header is 40 lines and brace-balanced (braces at `:19`, `:29`, `:32`, `:38`; line `:39` blank; `:40` `#endif`). **No correction was applied and none is required**; the review-draft boundary forbade a source write in any case.
3. **Initialization is safe and compile-enforced** (§4.1). The key is an aggregate of two class-typed members declared `interface` then `instance`; the sole production use aggregate-initializes both (`runtime_impl.cpp:443`); neither member type is default-constructible, so there is no path to an indeterminate member.
4. **Lifetimes are non-owning but valid under the registry contract** (§4.2). The key stores two `Registry_string_view`s into process-wide, append-only `String_registry` function-local statics (`string_registry.cpp:65-73`); the key-erasing `Final_action` guards with a `weak_ptr` lock (`runtime_impl.cpp:456-463`). The residual static-destruction-order hazard is recorded, not resolved.
5. **No conversion or narrowing is performed by the changed code** (§4.3). The comparator reads one `std::uint16_t` and two `Registry_string_view`s through `std::tie`; no casts, no arithmetic, no width change. (The out-of-slice config `uint32 → uint16` narrowing is untouched; only the identifier tests exercise it.)
6. **Ordering is a valid strict weak ordering** (§4.4): lexicographic `std::tie` over three components, each carrying a strict weak order. One latent consistency dependency is that `Registry_string_view::operator<` is content-based (`registry_string_view.hpp:141-143`) while `operator==` is pointer-based (`:127-129`); they coincide only because `String_registry` interns by content.
7. **Error handling is `Result`-based and leak-free on the failure path** (§4.5): `duplicate_service` is returned (`runtime_impl.cpp:451-452`), consistent with `coding_guidelines.rst:117-129`; `is_valid(callbacks)` runs before the key insert, so a `callback_missing` return does not reserve a key. Two manual findings: the comparator is not declared `noexcept` though it cannot throw (MF-2), and the `duplicate_service` documentation is now narrower than the key it guards (MF-3).
8. **Concurrency is lock-disciplined** (§4.6): the comparator is a pure read invoked only under the key mutex; the registry views it reads are immutable-by-append. The cross-lock single-server invariant (key identity == record index identity) is the property this change establishes; the teardown-declaration-order fragility is a related, unmodified hazard.
9. **No obligation is satisfied** (§8). `misra_mapping.rst` is `:status: draft` with a commented-out table and no CSV; `inspection_checklist.rst` is `:status: draft` and blank; `authority.json` records `engineering_acceptance: pending`, `human_reviews: unanswered`, `safety_class: unknown`; every `source-index.json` entry is `native_acceptance: not_inferred`. The retained CodeQL MISRA extraction carries its own blockers.
10. **The retained measurements are scoped and, on the changed files, possibly on a different revision** (§7, §9). The host identifier measurement covers only `service_identifier_tests.cpp` (91 tests / 0 failures); `runtime_tests.cpp` (33 macros) is not compiled or executed by any retained artifact. The CodeQL MISRA extraction records source hashes for `service_identifier.{cpp,hpp}` that **differ** from the candidate-set hashes, so its "no finding in the changed files" reading does not automatically transfer to the tree read here.

---

## 1. Binding, evidence, and prior work

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` — *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:2-4` |
| State | `open`, **0 comments**, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` (unchanged) | `.llm_tmp/context/issue-snapshot.json:19-20` |
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted obligation**: service-instance identifier = `service id + major + minor + instance id`; service identifier = `service id + major`; FindService = `service id + major + optional<minor> + optional<instance>`; and the proposal to *"exclude the minor version and make it a property of the service instance"*. There is **no comment and no acceptance record**, so none of it is binding. Binding is **by baseline commit**, not by run HEAD.

### 1.2 Candidate set (the only writable source paths)

From `.llm_tmp/context/candidate-files.json:1-25`:

1. `score/socom/BUILD` — baseline blob `3477ea0851fdcd82ec6ea9d71424013cbdf41962`
2. `score/socom/impl/service_identifier.cpp` — baseline blob `6c7e7a4e22355242009fe20dada2a9a0d0c7a9c7`
3. `score/socom/impl/service_identifier.hpp` — baseline blob `c8bae7908da9f087c518934f7b9f8d86db9a20ec`
4. `score/socom/test/unit/BUILD` — baseline blob `3c03a7b14286051f97fa5022206564bd63645171`
5. `score/socom/test/unit/runtime_tests.cpp` — baseline blob `8ecf5ab726db8bf994c960045d6fd7fdf84d7395`
6. `score/socom/test/unit/service_identifier_tests.cpp` — baseline blob `null` (the manifest expects a **new** file)

`glob **/service_identifier.h*` returns exactly one header path, so there is **no second, differently-braced copy** in this checkout; `glob **/final_action*` and the file reads below were used to ground the lifetime/concurrency analysis.

**Hash-reconciliation caveat.** No hashing tool is permitted in this task, so I did **not** re-hash the working tree. The candidate-set hashes above differ from the hashes recorded in the retained CodeQL MISRA artifact (`codeql_misra/result.json:126-127`: `service_identifier.cpp` = `3c12b3f1…`, `service_identifier.hpp` = `bdce3fcb…`) and from the codeql result's hash for the identifier test file (`:190`: `de79767c…`, matching `process_checks/result.json:1073`). The **direct source reads** in §2–§5 are therefore authoritative for *this* report; the retained tool readings refer to the revision *they* extracted, which may not be byte-identical to the tree read here.

### 1.3 Pinned obligation sources and authority (all read this iteration)

All nine entries of `.llm_tmp/context/obligations/source-index.json` are present with `.llm_tmp/context/obligations/authority.json`:

| id | pinned `path` (`.llm_tmp/context/obligations/*.rst`) | status |
|----|------|--------|
| `coding_guidelines` | `coding_guidelines.rst` | `:status: valid`; **MISRA C++:2023, C++17** (`:30-36`, `:74`); `doc__cpp_coding_guidelines` (`:19`); `:safety: ASIL_B` (`:22`) |
| `code_analysis` | `code_analysis.rst` | `:status: valid`; MISRA/ISO 26262-based SCA; mapping + in-source justification required |
| `misra_mapping` | `misra_mapping.rst` | **`:status: draft`** (`:20`); its only content is a `csv-table` **inside an RST comment** referencing `_assets/misra_2023.csv` (`:26-31`) |
| `verification_plan` | `verification_plan.rst` | `:status: valid`; quality criteria 1–9 |
| `development_plan` | `development_plan.rst` | `:status: valid`; C++17, GCC host, QCC target, Bazel |
| `tool_management` | `tool_management.rst` | `:status: valid`; identify / evaluate / qualify |
| `verification_process` | `verification_process.rst` | `:status: valid`; SCA classification, test links |
| `verification_guideline` | `verification_guideline.rst` | `:status: valid`; traceability, independence, documented results |
| `inspection_checklist` | `inspection_checklist.rst` | **`:status: draft`** (`:17`); blank `IMPL_01_01`…`IMPL_03_02`, incl. `IMPL_02_01`/`IMPL_02_02` (`:97-108`) |

Every `source-index.json` entry is `"native_acceptance": "not_inferred"`.

**Authority record** (`.llm_tmp/context/obligations/authority.json:1-7`): `engineering_acceptance: pending`; `human_reviews: unanswered`; `safety_class: unknown`; `codeql_scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload"`; instruction *"Restart the failed queue for one complete pass through all obligations"*.

**Safety-class note (recorded, not resolved).** The pinned platform documents carry `:safety: ASIL_B`, while `authority.json` records `safety_class: unknown` and no authorized selection exists. The document attribute is **not** a selection of the slice's safety class and must not be inferred as one.

### 1.4 Prior reports read and preserved

`.llm_tmp/overnight/prior-reports/` — 38 files present, all preserved. Directly relevant and read: `misra_manual_review.md` (the earlier manual review), `misra_applicability.md`, `key_fix.md`, `scope.md`, `invariants.md`, `callsites.md`, `reproducer.md`, `unit_matrix.md`, `ordering_tests.md`, `conversion_tests.md`, `runtime_disabled.md`, `runtime_enabled.md`, `lifetime_tests.md`, `lifetime_review.md`, `concurrency_review.md`, `test_metadata.md`, `tool_findings_repair.md`, `finding_classification.md`, `tool_assurance_review.md`.

`.llm_tmp/overnight/reports/` — read, not modified: `scope.md`, `key_fix.md`, `misra_applicability.md`, `callsites.md`, `invariants.md`, `reproducer.md`, `ordering_tests.md`, `conversion_tests.md`, `lifetime_review.md`, `lifetime_tests.md`, `concurrency_review.md`, `runtime_disabled.md`, `runtime_enabled.md`, `unit_matrix.md`, `test_metadata.md`, `coverage_review.md`, `coverage_tests_repair.md`, `analyzer_plan.md`, `tool_findings_repair.md`, `api_review.md`, `bazel_plan.md`, `compatibility.md`. This document adds `misra_manual_review.md`.

Derived sequence across the preserved reports: `scope.md` (bounded the slice; identified the key/index identity gap) → `invariants.md` (I-1…I-16) → `callsites.md` → `reproducer.md` (header brace correction + focused red regression) → `key_fix.md`/`unit_matrix.md` (drop `minor` from the ordering; expand key tests) → `ordering_tests.md`/`conversion_tests.md` → `runtime_disabled.md`/`runtime_enabled.md`/`lifetime_tests.md` → `test_metadata.md` → later host-side iterations (`coverage_review.md`, `finding_classification.md`, `misra_applicability.md`, `misra_manual_review.md`, `tool_findings_repair.md`) → review artifacts.

### 1.5 Host feedback and obligation-collection results available *in this* checkout

Unlike the earliest `scope.md` revision (which recorded them absent), both are present now:

- **`.llm_tmp/overnight/validation/`** — `check-result` = `0`; `measurement.json` (`check_ref: check_conversion_tests`, `mode: ubsan`, `origin: local_unprotected_measurement`, `initiator: Fabro host hook`, `engineering_acceptance: pending`, `full_native_tests: not_executed`); `changed_paths` = **only** `score/socom/test/unit/service_identifier_tests.cpp` (`measurement.json:5-7`); `baseline_with_agent_tests` = 91 tests / 33 failures / compile 0; `candidate` = 91 tests / 0 failures / compile 0. `after.json` = 91 tests / 0 failures, all in `ServiceInstanceIdentifierTest`. **Scope caveat:** only the identifier suite is measured; `runtime_tests.cpp` (33 macros) is **not** compiled or executed by this measurement.
- **`.llm_tmp/overnight/obligations/`** — 25 checks retained, each `origin: local_unprotected_measurement`, `engineering_acceptance: pending`. **Retention is not passing.** Relevant statuses: `compiler_diagnostics` `completed` with focused GCC/Clang legs and the limit *"Focused executable only; GCC 12.3 / Clang 19 differ from native toolchain pins"* (`result.json:1299-1304`); `codeql_misra` `findings_or_execution_failure` with three blockers (`:1052-1056`); `focused_clang_tidy` `findings_or_execution_failure`, blocker *"Native analyzer configuration incompatible; no replacement called MISRA"* (`:1052-1053`); `focused_cppcheck` `findings_or_execution_failure`, limit *"Optional complementary checks; no inferred MISRA rule coverage"* (`:1084-1088`); `tool_assurance` `completed_with_blockers` (`:1052-1056`, `:1389`); `cross_compilation` `completed_with_blockers`, blocker *"QNX SDK entitlement and target execution not configured; no credential acquired"* (`:1052-1054`); `process_checks` `completed_with_blockers`, blockers incl. *"Lexical metadata inventory cannot prove semantic requirement coverage"* and *"Safety/QM applicability and approved tailoring unknown"* (`:1052-1057`); `native_integration`, `native_lint`, `native_traceability`, `native_docs`, `native_performance`, `focused_tsan`, `codeql_security`, `secret_dependency_checks`, `format_precommit` all `findings_or_execution_failure`.

**Decisive scope caveat.** Every retained code measurement compiles a **focused** translation unit only (`service_identifier.cpp` + `string_registry.cpp` + `service_identifier_tests.cpp` + vendored googletest). **`runtime_tests.cpp` is not compiled or executed by any retained artifact.** A retained green marker is therefore **not** evidence for the runtime path this report inspects.

### 1.6 Host addendum (task context, not acceptance)

The host addendum (available as quoted by prior reports) states it is *"task context, not engineering acceptance or an approved tailoring decision"*; it requires that unknown applicability and unexecuted checks stay explicit, that identifier-only tests not be labelled platform validation, that no fuzzy technique be claimed without a measurement, and that there is **no authority to invent native links, select a safety classification, accept risk/deviations, or answer the independent human gate.** This report honours that.

---

## 2. Premise: the recorded syntax failure

### 2.1 Finding (re-verified this iteration by direct `read_file` + `grep`)

`score/socom/impl/service_identifier.hpp` is **brace-balanced**. A `grep` for `[{}]` returns exactly four brace-bearing lines:

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace (nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`) and two closers (`:32`, `:38`) give net brace balance `0`. There is **no third, unmatched closing brace**, and line 39 contains no text at all. The sibling `score/socom/impl/service_identifier.cpp` uses the same nested form (braces at `:18`, `:32`) and is balanced. The task's *"extra closing brace … at line 39"* is therefore a **stale, pre-correction description** that matches the earliest prior reports (which quote the split-form close `}  // namespace socom` + `}  // namespace score`); the `reproducer` iteration applied the correction and left line 39 blank.

### 2.2 Minimal historical repair (reference only; NOT applied)

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

Applying this to the already-balanced file would be a no-op at best; deleting a brace to "fix" the file would *create* the reported defect. **No source was edited**, both because the defect is not present and because the review-draft boundary forbids a write. No test was expanded, because the draft's suites already exist on disk (§5.2) and were read, not run. If a distinct "cancelled draft" revision still carries the brace, it is not the file in this checkout and must be located and corrected by an authorized iteration.

### 2.3 Repository convention (evidence)

The tree uses two internally consistent namespace styles: **nested open + single close** (`namespace score::socom {` … one `}  // namespace score::socom`) in the public `service_interface_identifier.hpp` (`:25`/`:164`), `error.hpp`, and the key header; and **split open + double close** in `impl/runtime_impl.hpp` (`:32-33`/`:232-233`). `impl/service_identifier.{hpp,cpp}` follow the nested form consistently and are balanced.

---

## 3. What "manual coding-guideline inspection" means here (and its limits)

### 3.1 Method

`coding_guidelines.rst` (`:status: valid`) selects **MISRA C++:2023 designed for C++17** (`:30-36`) and C++17 as the project standard (`:74`); it additionally requires error handling through `score::Result`, avoidance of exceptions, and aborts only as a last resort (`:117-129`). Because the in-repo **MISRA rule→tool mapping is a draft with no active CSV** (`misra_mapping.rst:20`, `:26-31`; `glob **/_assets/**` returns nothing in this checkout), this report cannot and does not state that a numbered MISRA rule "applies to the deliverable" in the process sense. It performs a **manual, construct-by-construct inspection** of the changed implementation against the six named topics, records the source construct and its evidence, and marks each outcome as one of:

- **OK (static):** correct by direct reading; reasoning given.
- **INVARIANT to preserve:** correct today only because of a stated precondition.
- **MANUAL FINDING:** a concrete, actionable item for the author/reviewer (no severity is asserted as accepted — no authorized SCA classification exists).
- **UNRESOLVED:** cannot be closed without a tool run, native test, or human decision.

### 3.2 The changed implementation (exact constructs)

`score/socom/impl/service_identifier.hpp:29-36`:

```cpp
struct Service_instance_identifier final {
    Service_interface_identifier interface;
    Service_instance instance;
};

/// \cond
bool operator<(Service_instance_identifier const& lhs, Service_instance_identifier const& rhs);
/// \endcond
```

`score/socom/impl/service_identifier.cpp:20-30`:

```cpp
bool operator<(Service_instance_identifier const& lhs, Service_instance_identifier const& rhs) {
    return std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major) <
           std::tie(rhs.instance, rhs.interface.id, rhs.interface.version.major);
}
```

The type is used as the element type of `std::set<Service_instance_identifier>` inside `Mutexed_variable` (`runtime_impl.hpp:50-56`), inserted under a dedicated mutex and erased by a `Final_action` constructed in `make_server_connector` (`runtime_impl.cpp:443`, `:449-454`, `:456-463`).

---

## 4. Manual inspection by topic

All line references are readings of this working tree. Each sub-section states the construct, the inspection, and the disposition.

### 4.1 Initialization

**Constructs.** The key is an aggregate of two class-typed members declared `interface` then `instance`; no user-declared constructors, no default member initializers, no base classes, public members (`service_identifier.hpp:29-32`). The sole production construction is `Service_instance_identifier const identifier{configuration.get_interface(), instance};` (`runtime_impl.cpp:443`).

**Inspection.**
- The aggregate initializer supplies both members in declaration order, so neither member is left uninitialized; `Service_interface_identifier` requires an id and a `Version` and `Service_instance` requires an id, and both are supplied.
- Neither member type has a default constructor (`service_interface_identifier.hpp:37,41,48,53,99,105,113,121`), so the key is **not default-constructible**; `Service_instance_identifier x;` does not compile. This removes the usual "indeterminate member" hazard by construction.
- No static-storage-duration object is introduced by the changed code, so there is no initialization-order fiasco in the key itself. (The two `String_registry` singletons are function-local statics in `string_registry.cpp:65-73` — pre-existing, not part of the changed key; the licensed pack flags that pattern, §6.)
- The comparator's `std::tie` temporaries are reference tuples bound to members of the arguments; they are value-initialized by the call and outlive only the comparison expression.

**Disposition:** **OK (static).** No initialization defect in the changed code.

### 4.2 Lifetimes

**Constructs.** The key stores `Registry_string_view`s (non-owning, via `interface.id` and `instance.id`). `Registry_string_view` explicitly documents *"It is the programmer's responsibility to ensure that Registry_string_view does not outlive the String_registry it is referring to"* (`registry_string_view.hpp:25-30`). The set is owned by `Runtime_impl` via `std::shared_ptr<Service_identifiers> m_service_identifiers` (`runtime_impl.hpp:228-229`); `Final_action` captures a **copy** of the identifier and a `weak_ptr` to the set (`runtime_impl.cpp:456-463`).

**Inspection.**
- The referenced registries are function-local statics with program duration (`string_registry.cpp:65-73`) and entries are only added, never erased: `emplace`/`emplace_front`/`insert` (`:26`, `:39-40`, `:56-57`); there is no `erase`/`clear`. `m_dynamic_allocated` is a `std::forward_list<std::string>` (`string_registry.hpp:76`), whose node addresses are stable across later `emplace_front`, and the `std::unordered_set<std::string_view>` (`:75`) holds views into those stable strings, so rehashing does not invalidate the viewed characters. A key that lives no longer than the process keeps valid views.
- The key-erasing `Final_action` executes after `Runtime_impl` may already be gone; it first attempts `identifiers.lock()` and skips the erase when the `weak_ptr` is expired (`runtime_impl.cpp:458-462`), so no comparison/`erase` runs against a destroyed set.
- **Residual hazard (recording only):** if a key outlives the registry itself (e.g. an object with static storage duration destroyed after the function-local statics), the captured views dangle. This is the documented contract, unchanged by the key edit; no retained test covers it.
- The related `lifetime_review.md` CE-1 (an **enabled** connector outliving the `Runtime` resets a `Registration` whose `Final_action` captures a `Service_record` inside the destroyed `Runtime_impl`) is about the server registration, not the key; it is unaffected by this comparator change and remains a pending human decision.
- **Note on `runtime_impl.cpp:1021` domain:** the runtime test `ConnectorDestroyedAfterRuntimeDoesNotCrash` (`runtime_tests.cpp:1021`) purports to exercise the `weak_ptr` guard, but like all runtime tests it is **not executed by any retained artifact** (§9) — the guard's behaviour is a source reading, not an observed result.

**Disposition:** **INVARIANT to preserve** (registry outlives key) + **UNRESOLVED** (program-exit/static-destruction ordering is not tested or decided).

### 4.3 Conversions

**Constructs.** The comparator reads `lhs.interface.version.major`, whose type is `std::uint16_t` (`service_interface_identifier.hpp:83`), plus two `Registry_string_view`s, through `std::tie` (`service_identifier.cpp:28-29`). `Registry_string_view::operator<` delegates to `std::string_view::operator<` (`registry_string_view.hpp:141-143`).

**Inspection.**
- There is **no explicit or implicit narrowing, cast, or arithmetic** in the changed code. The `std::uint16_t` member is compared as an integer; the only promotion is the value-preserving integer promotion performed by the built-in `<`. No signed/unsigned mixing (all three components are non-negative unsigned or string views).
- No `reinterpret_cast`, no C-style cast, no boolean-as-integer conversion. (The only `reinterpret_cast` in the wider file set is the pointer hash in `registry_string_view.hpp:192`, which carries an in-source `NOLINTNEXTLINE` and prose justification at `:188-191`.)
- `minor` is stored but never converted or compared by the changed code; the config `uint32 → uint16` narrowing lives outside this slice and is only exercised by the identifier tests (e.g. `ConvertedConfigMinorNarrowingBoundariesCollapseAndDistinguish`, `service_identifier_tests.cpp:2103`).

**Disposition:** **OK (static).** No conversion defect in the changed code.

### 4.4 Ordering

**Constructs.** `operator<` uses lexicographic `std::tie` over `(instance, service id, major)` (`service_identifier.cpp:28-29`). `Service_instance::operator<` delegates to `Registry_string_view::operator<` (`service_interface_identifier.hpp:69-71`); `Registry_string_view::operator<` is **content**-based (`registry_string_view.hpp:141-143`), whereas its `operator==` is **pointer**-based (`:127-129`) and its `std::hash` hashes the data pointer (`:186-193`). `std::set` uniqueness is `!(a<b) && !(b<a)`.

**Inspection.**
- The comparator induces a **strict weak ordering**: lexicographic comparison of three components, each of which is a strict weak order (`std::string_view::<` on interned content; `std::uint16_t::<` on an integer). Transitivity and anti-symmetry hold; the retained identifier suite asserts these properties (source only, §5.2).
- The identity is exactly `(instance, service id, major)`, so two configurations differing **only** in `minor` are equivalent under `<` and collapse in the `std::set`. This is the intended behaviour (issue #84's "service identifier = service id + major") and matches the minor-ignoring record index (§4.6).
- **MF-1 (latent consistency dependency).** The ordering relies on `String_registry` guaranteeing that equal text yields the same pointer (interning, `string_registry.cpp:26`, `:37-45`). If interning were broken, content-based `<` and pointer-based `==`/`hash` could disagree. Recorded as an **INVARIANT to preserve**, not a confirmed defect.
- **MF-4 (design note).** The key is ordering-only: there is no `operator==`/`std::hash` for `Service_instance_identifier` (`service_identifier.hpp:29-35`). That is sufficient for `std::set`; any future equality/hash container use must keep the identity `(instance, id, major)` to stay consistent with the record index.
- The comparator's declaration is visible to the `std::set` instantiation because `runtime_impl.hpp:30` includes `service_identifier.hpp`; the single definition is linked from `service_identifier.cpp` (external linkage, declared in a header), so the *declared-in-header* pattern is satisfied for this symbol. The CodeQL query `cpp/misra/external-linkage-not-declared-in-header-file-misra` fires in the extraction only on the `TEST_F` macro expansion in the test file (§6, §7).

**Disposition:** **OK (static)** for strict-weak-ordering/identity; **INVARIANT** (MF-1); **design note** (MF-4).

### 4.5 Error handling

**Constructs.** `make_server_connector` validates callbacks, then inserts the key and returns `MakeUnexpected(Construction_error::duplicate_service)` when the insert fails (`runtime_impl.cpp:440-467`); the comparator returns `bool`. `Final_action::execute` wraps the stored functor in `try { … } catch (...) {}` and is `noexcept` (`final_action.hpp:53`, `:58-67`).

**Inspection.**
- `coding_guidelines.rst:117-129` requires error handling through `score::Result`, discourages value-encoded errors, and treats aborts as a last resort. The duplicate path returns a typed `Result` error rather than aborting — **consistent** with the guideline.
- **No key leak on the error path:** `is_valid(callbacks)` is evaluated **before** the key insert (`runtime_impl.cpp:445-447` before `:449`), so a `callback_missing` return does not reserve a key.
- The comparator cannot signal failure and must not; it performs no allocation and no I/O.
- **MF-2 — comparator is not declared `noexcept`.** The declaration (`service_identifier.hpp:35`) and definition (`service_identifier.cpp:20`) omit `noexcept`, even though every operation involved (`std::string_view` comparison, `std::uint16_t` comparison, `std::tuple::operator<`) is non-throwing in C++17. The comparator is invoked by `std::set::insert` from a `noexcept` function (`make_server_connector … noexcept`, `runtime_impl.cpp:442`), so a throw would terminate. Marking it `noexcept` would express the non-throwing contract and match the sibling `Registry_string_view::operator<` (`noexcept`, `registry_string_view.hpp:141`). (`Service_instance::operator<` at `service_interface_identifier.hpp:69` is likewise not `noexcept`.) **Not applied** (review-only). This is a manual finding, not a confirmed rule violation.
- **MF-3 — error/documentation narrower than behaviour.** `Construction_error::duplicate_service` is commented *"Service identifier already exists"* (`error.hpp:55`), and the public `Runtime::make_server_connector` doc says duplicates are judged by *"the configuration.interface and instance parameters"* (`runtime.hpp:171-178`). The key now also collapses two configurations differing only in `minor` and ignores `minor` entirely. The comments are misleading relative to the current identity. Documentation-only; a fix would be a separate authorized change.
- `is_interface_compatible` (`runtime_impl.cpp:138-146`) remains a defensive check and is not part of the key; correctness relies on the record narrowing the interface first, as its comment states.

**Disposition:** **OK (static)** for `Result`-based propagation and leak-freedom; **MANUAL FINDINGS** MF-2, MF-3.

### 4.6 Concurrency

**Constructs.** The comparator is called from `std::set<Service_instance_identifier>` operations inside `make_server_connector` under the key mutex (`m_service_identifiers->mutex`, `runtime_impl.cpp:450`) and in the erase `Final_action` under the same mutex (`:460`). The views it reads point into the `String_registry` guarded by its own mutex (`string_registry.cpp:23`, `:35`, `:49`).

**Inspection (static).**
- The comparator is a **pure read of its arguments and of immutable registry data**; it takes no lock and mutates nothing. In production it is only ever invoked under the key mutex, so all `set` mutations (`insert` at `:451`, `erase` at `:461`) are serialized.
- **Registry reads are race-free by append-only design:** existing entries are never erased or mutated, and the storage that holds the characters (`std::forward_list` nodes) is stable across later `emplace_front` (`string_registry.cpp:39`, `:56`; `string_registry.hpp:76`). Two threads comparing different entries read disjoint, immutable character buffers.
- **Publication:** `m_service_identifiers` is initialized at `Runtime_impl` construction and never reassigned (`runtime_impl.hpp:228-229`); concurrent reads of the `shared_ptr` are safe under the factory-publication contract (prior `concurrency_review.md` AS-5/RC-4). Not changed by this slice.
- **MF-5 (cross-lock invariant).** `Service_record` holds a single `std::optional` server (`m_server`, `runtime_impl.hpp:95`) and `register_server_connector` asserts `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)` under the runtime mutex (`runtime_impl.cpp:369`) before `m_server.emplace(...)` (`:371`). That assert stays unreachable **only because** the key-guarded identity `(instance, id, major)` equals the record index identity `(id, major, instance)` (`Minor_version_ignoring_key_equal`/`_hash`, `runtime_impl.hpp:116-134`) and the key is held continuously from construction to destruction. The changed comparator is what establishes this; a future re-finer key would re-open the path. This is the main concurrency property to preserve.
- **MF-6 — teardown-declaration-order fragility (related, unmodified).** `Impl` declares `m_registration` (`server_connector_impl.hpp:162`) before `m_final_action` (`:163`), so the key-erasing `Final_action` is destroyed before the server registration; correctness depends on `~Impl(){ disable(); }` having already reset `m_registration`. This is `lifetime_review.md` CE-4 / `concurrency_review.md` RCC-4, not introduced here, but directly relevant to the key's lifetime contract and left to human disposition.
- **Not measured.** No retained sanitizer/TSan artifact exercises the changed unit's runtime path: `focused_tsan` is `findings_or_execution_failure`, and the `native_*` sanitizer/TSan legs are environment-limited. The static reading is therefore **not** a race-detector result.

**Disposition:** **OK (static)** for lock discipline and pure-read comparator; **INVARIANT** MF-5; recorded hazard MF-6; **UNRESOLVED** (no TSAN/stress measurement).

---

## 5. Findings register

Severity is deliberately **not** assigned an accepted class: `verification_process.rst` requires SCA findings to be classified by the quality manager together with a committer (`gd_req__verification_sca_classification`), and no such authorized classification exists. The column is a review aid only.

| Id | Topic | Finding | Evidence | Disposition |
|----|-------|---------|----------|-------------|
| MF-1 | Ordering | `<` is content-based while `==`/`hash` are pointer-based; consistency relies on `String_registry` interning | `registry_string_view.hpp:127-129,141-143,186-193`; `string_registry.cpp:26,37-45` | INVARIANT to preserve |
| MF-2 | Error handling | Comparator not declared `noexcept` although it cannot throw and is called from a `noexcept` function | `service_identifier.hpp:35`; `service_identifier.cpp:20`; `runtime_impl.cpp:442,451` | MANUAL FINDING |
| MF-3 | Error handling | `duplicate_service` comment and `Runtime::make_server_connector` doc are narrower than the actual key semantics | `error.hpp:55`; `runtime.hpp:171-178`; `service_identifier.cpp:28-29` | MANUAL FINDING |
| MF-4 | Ordering | Key is ordering-only: no `operator==`/`std::hash`; future equality-container use would need them | `service_identifier.hpp:29-35` | Design note |
| MF-5 | Concurrency | Single-server assert is safe only while key identity == record index identity | `runtime_impl.cpp:369,371`; `service_identifier.cpp:28-29`; `runtime_impl.hpp:116-134` | INVARIANT to preserve |
| MF-6 | Concurrency/lifetime | Key-erase `Final_action` declared after `m_registration`, so erase-before-unregister order is implicit | `server_connector_impl.hpp:162-163`; `runtime_impl.cpp:456-463` | Recorded hazard (CE-4/RCC-4) |
| MF-7 | Initialization | Key is a non-default-constructible aggregate; production init supplies both members | `service_identifier.hpp:29-32`; `runtime_impl.cpp:443` | OK (static) |
| MF-8 | Lifetimes | Views must not outlive the registry; static-destruction-order path untested | `registry_string_view.hpp:25-30`; `string_registry.cpp:65-73`; `runtime_impl.cpp:456-463` | UNRESOLVED |
| MF-9 | Traceability | `DerivationTechnique`/`Description` recorded; `TestType`/`Verifies` unset (no verified identifiers) | `service_identifier_tests.cpp:42-65`; `runtime_tests.cpp:264-267` | UNRESOLVED (human) |
| MF-10 | Measurement | No retained artifact compiles `runtime_tests.cpp`; the identifier measurement covers only `service_identifier_tests.cpp` and is host-local | `process_checks/result.json:1065,1074`; `validation/measurement.json:5-7`; `validation/after.json` | UNRESOLVED |
| MF-11 | Reconciliation | Retained CodeQL MISRA source hashes for the changed files differ from the candidate-set hashes; the extraction may be a different revision | `codeql_misra/result.json:126-127`; `candidate-files.json:6-12` | UNRESOLVED |

---

## 6. Verified guideline identifiers (and what is NOT verified)

Per the task instruction, guideline identifiers are cited **only where verified** this iteration.

1. **No S-CORE MISRA rule is verified as mapped.** `misra_mapping.rst` is `:status: draft` and its only content is a commented-out `csv-table` referencing an absent `_assets/misra_2023.csv` (`:20`, `:26-31`). There is therefore **no S-CORE-authorized statement that any MISRA C++:2023 rule is covered by any tool**, and this report asserts none. Which rules "apply" to this slice is **unresolved** (also because `safety_class: unknown`).

2. **The only verified rule identifiers are the licensed CodeQL coding-standards pack's own annotations, and only for findings that actually fired in the retained focused extraction.** I confirmed the following directly in `codeql_misra/result.json` (`rule_id` fields) and matched the numeric pack directory against `codeql_misra/analyze.stderr` query loads. The numeric MISRA identifiers are the **pack's internal directory names**, not an S-CORE applicability decision:

   | MISRA rule dir (pack annotation) | CodeQL query id | Location(s) confirmed in the retained extraction |
   |----------------------------------|-----------------|---------------------------------------------------|
   | `RULE-6-5-1` | `cpp/misra/external-linkage-not-declared-in-header-file-misra` | `score/socom/test/unit/service_identifier_tests.cpp` (gtest `TEST_F` macro expansion, e.g. `:2181`) |
   | `RULE-15-8-1` | `cpp/misra/copy-and-move-assignments-shall-handle-self-assignment` | `.llm_tmp/googletest/.../gtest-filepath.h` (dependency) |
   | `RULE-5-10-1` | `cpp/misra/poorly-formed-identifier` | `score/socom/service_interface_identifier.hpp` (e.g. `:172`), `score/socom/registry_string_view.hpp` (`:187`) |
   | `RULE-8-2-5` | `cpp/misra/reinterpret-cast-shall-not-be-used` | `score/socom/registry_string_view.hpp:192` (has in-source `NOLINTNEXTLINE` + justification `:188-191`) |
   | `RULE-21-6-1` | `cpp/misra/dynamic-memory-should-not-be-used` | `score/socom/string_registry.hpp:37` |
   | `RULE-6-7-1` | `cpp/misra/local-variable-static-storage-duration` | `score/socom/impl/string_registry.cpp:66,71` |

   (Additional query ids reported by the retained `prior-reports/misra_applicability.md` — `cpp/misra/no-conversion-from-bool`, `cpp/misra/unnecessary-write-to-local-object`, `cpp/misra/avoid-standard-integer-type-names`, `cpp/misra/implicit-declaration-of-copy-constructor`, `cpp/misra/no-pointer-to-integral-cast`, `cpp/misra/global-variable-used`, `cpp/misra/switch-body-compound-condition` — were not individually re-verified line-by-line this iteration; the first four were re-confirmed present, the others remain as reported.)

3. **The changed implementation files are clean in that extraction.** `grep` of `codeql_misra/result.json` shows `score/socom/impl/service_identifier.cpp` and `.hpp` appear **only** in `source_hashes` (`:126-127`) and in **no** `artifactLocation.uri` of any finding. This is "no finding in a focused, incomplete extraction", **not** a compliance statement — and, per §1.2/MF-11, the extraction's recorded hashes differ from the candidate-set hashes, so it may not correspond to the tree read here.

4. **Rule statements are not reproduced.** The MISRA C++:2023 rule text is licensed; this report cites identifiers, query ids, and locations only, and does not reproduce rule text or rationale.

5. **`coding_guidelines.rst` document facts cited** (not numbered rules): MISRA C++:2023 with C++17 (`:30-36`, `:74`); `score::Result` error handling, avoid throwing, aborts last resort (`:117-129`). The document id is `doc__cpp_coding_guidelines`, `:safety: ASIL_B`.

The blank, draft `inspection_checklist.rst` (`:status: draft`) defines the intended manual-inspection slots `IMPL_02_01` (static/dynamic analysis verified) and `IMPL_02_02` (manual checks derived from the coding guideline find no safety-critical error) (`:97-108`). This report is **input** to that inspection, not a filled checklist; `IMPL_02_02` remains **unfilled** and its "no safety-critical error" judgement is a human responsibility.

---

## 7. Tool evidence read (and why none of it satisfies a MISRA obligation)

| Check | Retained result | Reading |
|-------|-----------------|---------|
| CodeQL MISRA | `codeql_misra/result.json` | database-create and analyze exit 0; SARIF exported; status `findings_or_execution_failure` (`:1117`); blockers: *"MISRA applicability/mapping draft and incomplete"*, *"Default suite omits manual/audit obligations"*, *"Compiled query qualification and human deviations pending"* (`:1052-1056`); limit: *"Focused linked executable, not full target extraction; dependency findings retained"* |
| CodeQL security | `codeql_security/result.json` | `findings_or_execution_failure` (`:1113`); blockers `[]`; per prior reports all locations under `.llm_tmp/googletest/**` |
| clang-tidy (focused) | `focused_clang_tidy/result.json` | `findings_or_execution_failure` (`:1080`); blocker *"Native analyzer configuration incompatible; no replacement called MISRA"* (`:1052-1053`); **no TU analysis, not "clean"** |
| cppcheck (focused) | `focused_cppcheck/result.json` | `findings_or_execution_failure` (`:1084`); limit *"Optional complementary checks; no inferred MISRA rule coverage"* (`:1086-1088`) |
| GCC/Clang focused diagnostics | `compiler_diagnostics/result.json` | `completed` (`:1299`); limits *"Focused executable only; GCC 12.3 / Clang 19 differ from native toolchain pins"* and *"-Werror on target and tests"* (`:1301-1304`) |
| tool assurance | `tool_assurance/result.json` | `completed_with_blockers` (`:1389`); blockers incl. *"Tool confidence evaluation, qualification where applicable, and acceptance require authorized humans"* (`:1052-1056`) |
| cross compilation | `cross_compilation/result.json` | `completed_with_blockers` (`:1113`); blocker *"QNX SDK entitlement and target execution not configured; no credential acquired"* (`:1052-1054`) |
| process checks | `process_checks/result.json` | `completed_with_blockers` (`:1059`); blockers incl. *"Lexical metadata inventory cannot prove semantic requirement coverage"*, *"Safety/QM applicability and approved tailoring unknown"* (`:1052-1057`) |
| native / sanitizer / tsan / memcheck / format | `native_*/result.json`, `focused_*san*`, `focused_tsan`, `focused_memcheck`, `format_precommit` | environment-limited or `findings_or_execution_failure`; **not a MISRA measurement of the changed comparator** |
| host validation | `validation/check-result` = `0`; `validation/measurement.json` | identifier TU only; candidate 91/0; `full_native_tests: not_executed`; `runtime_tests.cpp` not executed |

None of these is a MISRA-rule measurement of the changed comparator, and none covers `runtime_tests.cpp`.

---

## 8. Obligations status (none satisfied)

### 8.1 Pinned state

All nine pinned sources in `.llm_tmp/context/obligations/` were read this iteration (§1.3); every `source-index.json` entry is `"native_acceptance": "not_inferred"`. `authority.json` records `engineering_acceptance: pending`, `human_reviews: unanswered`, `safety_class: unknown`, `codeql_scope: Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload`.

### 8.2 Status for this slice

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` (draft) | **UNKNOWN — NOT CLAIMED**; mapping inactive, no S-CORE rule↔tool linkage |
| MISRA rule→tool mapping | `misra_mapping.rst`; `code_analysis.rst` | **DRAFT / INACTIVE** — no CSV, table commented out |
| Manual coding-guideline inspection (`IMPL_02_02`) | `inspection_checklist.rst` (draft) | **DRAFTED HERE AS INPUT; NOT A FILLED/ACCEPTED INSPECTION**; human judgement pending |
| Static/dynamic analysis verified (`IMPL_02_01`) | `inspection_checklist.rst` | **NOT DONE** — CodeQL focused+draft; clang-tidy config-blocked; no authorized finding classification |
| SCA finding classification (Critical/High/Medium/Low) | `verification_process.rst` (`gd_req__verification_sca_classification`) | **NOT DONE** — no authorized owner |
| Freedom from compiler warnings & errors (100 %, criterion 9) | `verification_plan.rst` | **PARTIAL / NOT SATISFIED** — focused GCC legs green; no Bazel build; `runtime_tests.cpp` uncompiled |
| Unit/component testing executed, results recorded | `verification_plan.rst`; `verification_guideline.rst` | **PARTIAL, SCOPED** — 91 identifier tests / 0 failures in a local unprotected host run (`validation/after.json`); runtime suite (33 macros) not executed |
| Boundary/equivalence derivation | `verification_process.rst` | **SOURCE-ONLY** — cases exist (§4); not executed here |
| Linking tests to requirements (record properties) | `verification_process.rst` (`gd_req__verification_link_tests_cpp`) | **PARTIAL** — `DerivationTechnique`/`Description` set; `TestType`/`Verifies` unset (no invented identifiers) |
| Interface / requirements-based / resource / fault-injection test types | `verification_process.rst`; `verification_plan.rst` | **NOT PERFORMED / applicability not inferred** — no harness; identifier tests must not be labelled platform validation |
| Fuzzy testing technique | `verification_plan.rst` | **NOT EXECUTED / NOT CLAIMED** — no harness and no measurement |
| External-component AoUs verified | `verification_process.rst` (`gd_req__verification_external_aou`) | **NOT SATISFIED** — no integration/static verdict; no AoU register |
| Independence of verification / review | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** for this slice |
| Native acceptance | `source-index.json` | **`not_inferred` for every entry** |
| Obligation-collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **RETAINED, NOT PASSED** — several `findings_or_execution_failure` / `completed_with_blockers` |

**Explicit non-satisfaction statement.** Missing tools, the unknown safety class and un-inferred applicability, the draft/inactive rule mapping, the blank inspection checklist, the focused/incomplete CodeQL extraction, the never-compiled runtime suite, and the unanswered human reviews mean **none of the checked obligations may be treated as satisfied**. A retained collection node proves *retention*, not passing. In particular: the CodeQL "no finding in the changed files" reading is **not** a compliance result (§6.3, MF-11), and the host 91/0 identifier run is **not** coverage of `runtime_tests.cpp` or of the full `//score/...` tree (§9, MF-10).

---

## 9. Measurement and validation status

- **Tools:** `read_file`, `grep`, `glob`, `write_file` only. No `shell`, delegation, web, approval, publishing, or engineering acceptance.
- **Measurements executed by this iteration: none.** No build, no `bazel test`, no runtime. The brace census (§2), the source-construct inspection (§3–§5), and the strict-weak-ordering / leak-freedom / lock-discipline statements are static readings or explicitly-labelled logical consequences.
- **Test inventory (read, not run):** `service_identifier_tests.cpp` — **91 `TEST_F`** under `ServiceInstanceIdentifierTest` (`:168`…`:2181`, counted this iteration by `grep`; matches `process_checks/result.json:1074`); `runtime_tests.cpp` — **33 macros** (1 `TEST` at `:239`, 31 `TEST_F` `:279`…`:1253`, 1 `TEST_P` at `:1311`; matches `process_checks/result.json:1065`). The focused minor-only regression `RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError` is present at `runtime_tests.cpp:402-431`.
- **Retained host measurement (scoped):** `validation/measurement.json` and `validation/after.json` cover **only** `service_identifier_tests.cpp`: candidate 91 tests / 0 failures; `baseline_with_agent_tests` 91 tests / 33 failures; `full_native_tests: not_executed`; `origin: local_unprotected_measurement`; `engineering_acceptance: pending`. This is a **local, unprotected, scoped** capture, not an acceptance.
- **Regression target (source-derived, not executed):** on the working-tree key the minor-only key tests collapse to one set element (`service_identifier_tests.cpp:174`, `:182`, `:192`, `:203`, `:1321`) and the runtime regression returns `Construction_error::duplicate_service` (`runtime_tests.cpp:402-431`). On a key that includes `minor` both focused checks would fail. These expectations are source-derived, not measured.
- **Scope:** local, unprotected, scoped. Full native runtime tests and human review remain pending.
- **Reproduction path for a later, permitted iteration (not executed here):**

  ```bash
  bazel test //score/socom/test/unit:socom_test
  bazel test //score/socom/test/unit:socom_test --test_filter='ServiceInstanceIdentifierTest.*'
  bazel test //score/socom/test/unit:socom_test --test_filter='RuntimeTest.*'
  # static analysis (tool-dependent, after fixing the .clang-tidy config):
  codeql database create db --language=cpp --command=<build>
  codeql database analyze db misra-cpp-default.qls --format=sarif-latest
  ```

- **No correction was needed for the recorded syntax failure** (§2), and **no test was expanded** in this iteration.

---

## 10. Notice preservation

- No source, build, test, config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was created, edited, or deleted by this iteration; **only this report was written.**
- All Apache-2.0 / SPDX headers on the files read are untouched: `service_identifier.hpp:1-12` and `service_identifier.cpp:1-12` (2025 copyright); `service_identifier_tests.cpp:1-12` (2025 copyright); `runtime_tests.cpp`; `runtime_impl.{hpp,cpp}`; `service_interface_identifier.hpp:1-12`; `registry_string_view.hpp:1-12` (2026 copyright); `string_registry.{hpp,cpp}`; `final_action.hpp`; `error.hpp`; `runtime.hpp`; `server_connector_impl.hpp`; and both `BUILD` files.
- All 38 files under `.llm_tmp/overnight/prior-reports/` and every earlier file under `.llm_tmp/overnight/reports/` were preserved unchanged; this document is an additional `reports/` entry. The host-validation and obligation-collection artifacts were read only and left unmodified.
- This report itself carries the Apache-2.0 header. **No licensed MISRA rule text is reproduced** (§6.4).

---

## 11. Pending human review checklist

- [ ] **Resolve the instruction conflict (§2):** the recorded "extra closing brace at line 39" is not present in this checkout and the review-draft boundary forbade a source write; confirm that writing only this report was intended, and locate/correct any distinct "cancelled draft" revision that still carries the brace.
- [ ] **Adopt or reject the manual findings:** MF-2 (add `noexcept` to the comparator, and consider `Service_instance::operator<`), MF-3 (update the `duplicate_service` comment and the `Runtime::make_server_connector` doc to match the minor-ignoring key) — both require an authorized source change and a build/test cycle this review cannot run.
- [ ] **Confirm the invariants:** MF-1 (content-based `<` vs pointer-based `==`/`hash`; interning precondition) and MF-5 (key identity must stay equal to the record index identity so the single-server assert stays unreachable).
- [ ] **Adjudicate the recorded hazards:** MF-6 / CE-4 / RCC-4 (declare `m_final_action` before `m_registration`, or express the erase-after-unregister order) and MF-8 (static-destruction-order path for the non-owning views).
- [ ] **Reconcile MF-11 / §1.2:** confirm whether the retained CodeQL MISRA extraction corresponds to the current revision of `service_identifier.{cpp,hpp}`; the recorded hashes differ from the candidate-set hashes.
- [ ] **Complete and activate the MISRA mapping** (`misra_mapping.rst`): supply `_assets/misra_2023.csv`, uncomment the table, and raise `:status` to `valid` by an authorized change; until then no rule applicability can be stated. Confirm the use of the licensed CodeQL pack's internal annotations as evidence (methodological substitution).
- [ ] **Fill the implementation inspection checklist** `IMPL_02_01` / `IMPL_02_02` (`inspection_checklist.rst`, currently draft/blank) using this report as input, and record the SCA finding classification per `gd_req__verification_sca_classification`.
- [ ] **Repair and run the analyzers:** fix the `.clang-tidy` configuration (`--verify-config` rejected; blocker *"Native analyzer configuration incompatible; no replacement called MISRA"*) and run a **full-target** CodeQL extraction (not a focused executable) that includes `runtime_tests.cpp`; qualify the compiled queries and disposition the retained findings in `string_registry.cpp`/`string_registry.hpp`, `service_interface_identifier.hpp`, `registry_string_view.hpp`, and the gtest-macro hits.
- [ ] **Refresh the measurements:** run `bazel test //score/socom/test/unit:socom_test` (and the broader `//score/...` set) so `runtime_tests.cpp` and the full identifier suite are actually compiled and executed natively; do not re-report the focused 91-test host artifact as coverage of the whole tree.
- [ ] **Supply traceability metadata** (`TestType`/`Verifies`) where verified native identifiers exist — no invented links — or record the applicability as unresolved.
- [ ] **Select the safety class**, schedule independent human review (approver ≠ author, `gd_req__verification_independence`), and record engineering acceptance; no compliance claim may be made before that.
- [ ] **Keep the wider #84 public `Service_interface_identifier` restructure, FindService wildcard handling, and the config minor-wildcard narrowing out of this bounded slice** until separately accepted.

---

*End of review draft. Local, unprotected, scoped. No engineering acceptance; human reviews unanswered; full native runtime tests pending. No MISRA C++:2023 compliance is claimed and no rule applicability is asserted. Human inspection of the changed implementation remains pending.*
