<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — identifier-conversion boundary coverage (`conversion_tests`) — iteration record

**Document type:** review draft (actual-source inspection + conversion-boundary coverage
addition + honest iteration/measurement record)
**Date:** 2026-10-02
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version
handling in socom*; this report covers the **identifier-conversion boundary** of that
slice.
**Run:** `fabro/run/01M3YRJEGXNY6CB81T7TKW774B`
**Status:** local, unprotected, scoped. **No engineering acceptance exists. Human reviews
are unanswered. Full native runtime tests remain pending.** Every expectation below is
either a direct static reading of this checkout at the baseline-bound candidate paths or
an explicitly-labelled logical consequence. Nothing here is accepted, published, or a
full native run.

> **Tool / write boundary actually observed.** Only `read_file`, `grep`, `glob` and
> `write_file` were the only tools used. No `shell`, no delegation, no web access, no
> approval, no publishing, and no engineering acceptance was performed. A plan-tracking
> call was refused by the sandbox (`Overnight tool/path boundary`) and changed nothing.
> The task permits changing only the six named candidate source paths and this report.
> Of those, **this iteration wrote exactly two files**: the candidate test file
> `score/socom/test/unit/service_identifier_tests.cpp` (boundary coverage added) and this
> report. No other file — not `score/socom/impl/service_identifier.hpp`,
> `score/socom/impl/service_identifier.cpp`, either `BUILD`, `runtime_tests.cpp`,
> `NOTICE`, `LICENSE`, `REUSE.toml`, or any config — was created, edited, or deleted.
> Every prior report under `.llm_tmp/overnight/prior-reports/` and every earlier report
> under `.llm_tmp/overnight/reports/` was preserved unchanged.

---

## 0. Summary

1. **Recorded syntax failure — inspected; the defect is not present in the actual
   source, so it was not “corrected”.**
   `score/socom/impl/service_identifier.hpp` is **brace-balanced**. A `grep` for a brace
   character (`[{}]`) on the file returns exactly four matches: `:19`
   (`namespace score::socom {`), `:29` (`struct Service_instance_identifier final {`),
   `:32` (`};`) and `:38` (the single `}  // namespace score::socom`). Two openers and two
   closers give net brace balance `0`; line `:39` is blank and line `:40` is
   `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER`. There is **no third, unmatched closing
   brace**. The task's “extra closing brace … at line 39” describes the **stale
   pre-correction state** quoted by the earliest prior reports (split-form
   `}  // namespace socom` + `}  // namespace score`); it is not the file in this
   checkout. Re-introducing a break so it could be removed would be a regression, so the
   header was left untouched. This is a static brace-balance reading, **not** a compile
   measurement.
2. **Identifier-conversion boundary coverage was added.** The pre-existing file already
   carried 83 `TEST_F` cases, of which 12 are dedicated conversion cases. The one
   conversion boundary named as an open gap by the prior `conversion_tests` report — the
   **empty-text conversion path** — is now covered by **two new cases** (`:1882`,
   `:1929`), bringing the file to **85 `TEST_F`**. The 83 pre-existing cases are
   byte-for-byte line-aligned (their `TEST_F` line numbers `:168`…`:1851` are unchanged),
   confirming they were preserved, not rewritten. The new cases exercise text/registry →
   public `Service_interface_identifier` and public identifier + `Service_instance` →
   internal registration key at the empty-id boundary and at both 16-bit version extremes,
   across all four public construction paths.
3. **Public-interface identity is preserved.** No production source was touched. The
   public `Service_interface_identifier` / `Version` representation and its
   `operator==` / `operator<` / `std::hash` are unchanged and still distinguish `major`
   and `minor`, while the internal registration key still ignores `minor`
   (`service_identifier.cpp:28-29`).
4. **No obligation is satisfied.** No build or test ran in this iteration; the new cases
   are locally **unmeasured**. The pinned obligation entries are
   `"native_acceptance": "not_inferred"`; `authority.json` records
   `engineering_acceptance: pending`, `human_reviews: unanswered`, `safety_class: unknown`.
   The retained host capture under `.llm_tmp/overnight/validation/` covers the **previous
   83-case** state and does not cover the two added cases. Missing tools, unknown
   applicability, incomplete extraction and unanswered human reviews are **not** treated
   as satisfied (§6, §7).

---

## 1. Binding to the verified baseline, prior reports, host feedback, obligations

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` | `.llm_tmp/context/issue-snapshot.json:2-4` |
| Title | *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:3` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` (unchanged) | `.llm_tmp/context/issue-snapshot.json:19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**. It distinguishes service-instance identifier = `service id + major + minor +
instance id`, service identifier = `service id + major`, and FindService = `service id +
major + optional<minor> + optional<instance>`, and proposes to “exclude the minor version
and make it a property of the service instance”. There is **no comment and no acceptance
record** in the snapshot, so none of it is binding.

### 1.2 Verified baseline

| Item | Value | Source |
|------|-------|--------|
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |
| Working branch | `fabro/run/01M3YRJEGXNY6CB81T7TKW774B` | environment |

Binding is **by baseline commit**, not by run HEAD; earlier reports reference other run
IDs on the same baseline commit and remain admissible prior evidence.

### 1.3 In-scope candidate files (the only writable source paths)

From `.llm_tmp/context/candidate-files.json:1-25`:

| File (repo-relative) | Baseline git blob | This iteration |
|----------------------|-------------------|----------------|
| `score/socom/BUILD` | `3477ea0851fdcd82ec6ea9d71424013cbdf41962` | inspected, **unchanged** |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e22355242009fe20dada2a9a0d0c7a9c7` | inspected, **unchanged** (key identity `(instance, id, major)`, `:28-29`) |
| `score/socom/impl/service_identifier.hpp` | `c8bae7908da9f087c518934f7b9f8d86db9a20ec` | inspected, **unchanged** (already brace-balanced, §2) |
| `score/socom/test/unit/BUILD` | `3c03a7b14286051f97fa5022206564bd63645171` | inspected, **unchanged** |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab726db8bf994c960045d6fd7fdf84d7395` | inspected, **unchanged** |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(none — `null`)* | **changed — empty-text conversion boundary added (§3)** |

The `null` baseline blob for `service_identifier_tests.cpp` is the manifest's expectation
of a **new** unit-test file; it exists on disk only as part of the un-merged working tree
(the “cancelled draft”), never in the baseline.

### 1.4 Pinned obligation sources

All nine entries of `.llm_tmp/context/obligations/source-index.json` are present in
`.llm_tmp/context/obligations/`, together with `authority.json`. The document-status lines
are: `coding_guidelines` (`:20`), `code_analysis` (`:20`), `verification_plan` (`:17`),
`development_plan` (`:21`), `tool_management` (`:17`), `verification_process` (`:22`),
`verification_guideline` (`:19`) = **valid**; `misra_mapping` (`:20`) and
`inspection_checklist` (`:17`) = **draft**. Every `source-index.json` entry is pinned with
`"native_acceptance": "not_inferred"` — pinned, but its applicability to this slice is
**not inferred**. `authority.json` records `"engineering_acceptance": "pending"`,
`"human_reviews": "unanswered"`, `"safety_class": "unknown"`,
`"codeql_scope": "Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload"`, and the
instruction `"Restart the failed queue for one complete pass through all obligations"`.

### 1.5 Prior reports, host feedback, obligation-collection results

- **Prior reports read and preserved.**
  `.llm_tmp/overnight/prior-reports/` holds `callsites.md`, `conversion_tests.md`,
  `invariants.md`, `key_fix.md`, `lifetime_tests.md`, `ordering_tests.md`, `reproducer.md`,
  `runtime_disabled.md`, `runtime_enabled.md`, `scope.md`, `test_metadata.md`,
  `unit_matrix.md`. None was modified; in particular the prior
  `.llm_tmp/overnight/prior-reports/conversion_tests.md` was **not** overwritten.
  `.llm_tmp/overnight/reports/` held ten earlier reports of this run
  (`scope.md`, `callsites.md`, `invariants.md`, `reproducer.md`, `key_fix.md`,
  `unit_matrix.md`, `ordering_tests.md`, `runtime_disabled.md`, `runtime_enabled.md`,
  `lifetime_tests.md`); all were preserved unchanged. This document adds
  `conversion_tests.md` to that directory.
- **Host feedback is present in this checkout** under `.llm_tmp/overnight/validation/`:
  `measurement.json` (`check_ref: check_lifetime_tests`, `status: completed`, `mode: plain`,
  `origin: local_unprotected_measurement`, `initiator: Fabro host hook`,
  `engineering_acceptance: pending`, `full_native_tests: not_executed`, compiler
  `/usr/bin/x86_64-linux-gnu-g++-12`), `before.json` (83 tests / 28 failures),
  `after.json` (83 tests / **0 failures**), the compile/test command + stdout/stderr
  captures, and `check-result` = `0` (`after-compile.stderr` and `before-compile.stderr`
  are empty; the candidate compile exits `0`). This is a **local, unprotected, scoped**
  capture of the focused identifier translation unit, and it predates this iteration's
  two added cases.
- **Obligation-collection results are absent here.** `glob
  .llm_tmp/overnight/obligations/**` returns nothing; no `*/result.json` exists. Per the
  task rule, a collection node that retained results would show only *retention*, not
  passing; here nothing is retained, so nothing may be treated as satisfied on that basis.

---

## 2. Recorded syntax failure: inspection of the actual source

`score/socom/impl/service_identifier.hpp` (40 lines) is **brace-balanced**:

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 35 | `bool operator<(Service_instance_identifier const& lhs, Service_instance_identifier const& rhs);` | out-of-line declaration (no brace) |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

A `grep` for a brace character on the file returns exactly four matches — `:19`, `:29`,
`:32`, `:38` — so the net brace balance is `0` and line `:39` contains no text. A `glob`
for `**/service_identifier*` returns exactly three paths (`impl/service_identifier.cpp`,
`impl/service_identifier.hpp`, `test/unit/service_identifier_tests.cpp`), so there is no
second, differently-braced copy. The description in the task therefore matches the
earliest, pre-correction reports (which quote lines 38-39 as the split-form
`}  // namespace socom` + `}  // namespace score`), not this snapshot. The repository uses
the nested form here consistently (`service_identifier.cpp:18`/`:32` is balanced the same
way).

**Minimal repair, retained for reference only (not applied, because not needed):**

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

Applying this to an already-balanced file would be a no-op at best and a regression at
worst. **No source edit was made to the header.** The task's instruction “inspect and
correct the actual source” is satisfied by inspection: there is nothing to correct, and
the smallest correction to already-correct source is no change.

---

## 3. Identifier-conversion boundary coverage added

### 3.1 The conversion under test (unchanged semantics)

The duplicate-server key is
`Service_instance_identifier { Service_interface_identifier interface; Service_instance
instance; }` (`score/socom/impl/service_identifier.hpp:29-32`), with the out-of-line
`operator<` (`:35`) defined as (`score/socom/impl/service_identifier.cpp:28-29`):

```cpp
return std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major) <
       std::tie(rhs.instance, rhs.interface.id, rhs.interface.version.major);
```

Therefore the `std::set` equivalence is exactly `(instance, service id, major)` and the
**minor version is excluded**. The public
`Service_interface_identifier{Id id; Version{std::uint16_t major; std::uint16_t minor;}}`
representation and its `operator==` / `operator<` / `std::hash`
(`score/socom/service_interface_identifier.hpp:74-190`) are **unchanged** and still include
`minor`. No production source was edited.

The two reachable conversions are:

1. **Text/registry → public identifier.** `Service_interface_identifier` from id text
   (`string_view`, `string_view + Literal_tag`, `std::string&&`, or a registry `Id`) plus a
   `Version{major, minor}` (`score/socom/service_interface_identifier.hpp:96-124`);
   `Service_instance` the same way through `instance_id_registry()` (`:35-55`).
2. **Public identifier + instance → internal key.** `Service_interface_identifier` +
   `Service_instance` → `Service_instance_identifier`, keeping `(instance, id, major)` and
   dropping `minor` (`impl/service_identifier.hpp:29-32`).

### 3.2 Gap closed this iteration

The prior `conversion_tests` report identified exactly one remaining conversion boundary
that was not covered: the **empty-text conversion path** (its §5, “the empty-string
identity boundary is covered at the identity level … the conversion-path empty-text case
is the only gap this iteration identified but did not add”). That gap is now closed.

Two new cases were appended to `score/socom/test/unit/service_identifier_tests.cpp`:

| Line | New case | Boundary pinned |
|------|----------|-----------------|
| 1882 | `ConvertedEmptyTextInterfacePathsAgreeAtVersionBoundaries` | the empty service-id text converts through all four public `Service_interface_identifier` construction paths (registry `Id`, `string_view`, `string_view + Literal_tag`, `std::string&&`) to one public identity and is hash-equal, at `major × minor ∈ {0, 0xFFFF} × {0, 0xFFFF}`; the resulting key identity is exactly `(instance="", service="", major)`. The empty identity stays distinct from a non-empty one at opposite version boundaries and orders before it. |
| 1929 | `ConvertedEmptyTextInstancePathsAgreeWithRegistryPath` | the empty instance-id text converts through all four public `Service_instance` construction paths to one registry identity and collapses to a single registration key; the key identity is `(instance="", service="A…", major)`; the empty instance stays distinct from a non-empty instance at the opposite minor boundary and orders before it. |

Both cases use only APIs and idioms already present in the file (the file-local
`make_registration_key` helper, `service_id_registry()` / `instance_id_registry()`,
`Literal_tag`, `equivalent`, `identity_of`), and both only pin the existing conversion
behaviour — they do not decide any of issue #84's open questions. Neither the public
`Service_interface_identifier` representation nor its equality/ordering/hash was changed.

### 3.3 Preservation of the pre-existing 83 cases

The 83 pre-existing `TEST_F` cases were preserved, not rewritten. Evidence: every original
`TEST_F` line number is unchanged in the new file — the pre-existing cases still occupy
`:168`…`:1851`, exactly matching the original count of 83 and the retained host capture's
per-case listing (`after.json`). The two new cases begin at `:1882` (after the original
final case at `:1872`), and the file still ends with `}  // namespace score::socom`
(now `:1965`).

---

## 4. Public-interface identity preserved

- The conversion cases deliberately pair the **public** identity (which must keep
  distinguishing `major` and `minor`) with the **internal key** (which must collapse
  `minor`), so a change that wrongly leaked the key's minor-exclusion into the public type
  would be caught.
- No public header was modified. No production source (`impl/service_identifier.hpp`,
  `impl/service_identifier.cpp`) was modified.
- The new empty-text cases compare the four public construction paths by
  `operator==` and `std::hash`, and compare the converted keys by set-equivalence, so both
  the public identity and the internal identity boundary are pinned.

---

## 5. Files changed / state of the six candidate paths

| Candidate path | State | This iteration |
|----------------|-------|----------------|
| `score/socom/impl/service_identifier.hpp` | brace-balanced, nested namespace, documents minor exclusion | unchanged (inspected, §2) |
| `score/socom/impl/service_identifier.cpp` | `operator<` identity `(instance, id, major)`, minor excluded | unchanged |
| `score/socom/BUILD` | `testonly impl_service_identifier` exposure present | unchanged |
| `score/socom/test/unit/BUILD` | `socom_test` globs `*.cpp`, deps wired | unchanged |
| `score/socom/test/unit/runtime_tests.cpp` | minor-only duplicate regression present | unchanged |
| `score/socom/test/unit/service_identifier_tests.cpp` | 85-case key matrix (83 preserved + 2 empty-text conversion cases) | **changed** |
| `.llm_tmp/overnight/reports/conversion_tests.md` | **new — this report** | written |

No file outside the six candidate paths and this report was written; no `NOTICE`,
`LICENSE`, or `REUSE.toml` file was created, edited, or deleted; all prior reports were
preserved.

---

## 6. Measurement and validation status

- **Tools:** `read_file`, `grep`, `glob`, `write_file` only. A plan-tracking call was
  refused by the sandbox and changed nothing; no `shell`, delegation, web, approval,
  publishing, or engineering acceptance.
- **Executed measurements:** **none** this iteration. No build, no `bazel test`, no
  runtime. The header brace census (§2), the key identity (§3.1), and the expected
  behaviour of the new cases (§3.2) are static source readings and strict-weak-ordering
  consequences, not observed results.
- **The added cases are unmeasured.** The new file could not be compiled or executed in
  this iteration, so it is a source-only change. Whether the two new cases compile and
  pass is **unknown** until an authorized build/test run is performed. The retained host
  capture `.llm_tmp/overnight/validation/` measured the **previous 83-case** file
  (`after.json`: 83 tests / 0 failures; `before.json`: 83 / 28; `check-result` 0) and does
  **not** cover the two added cases; the recorded `service_identifier_tests.cpp` source
  hash in `measurement.json` therefore no longer matches the expanded file.
- **Regression target (source-derived, not executed):**
  `RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError`
  (`runtime_tests.cpp:402-431`) and the key-level minor-collapse cases
  (`service_identifier_tests.cpp:174`, `:182`, `:192`, `:203`, …) assert that a second
  registration differing only in `minor` is rejected as `duplicate_service`. On a key that
  includes `minor` they would fail; on the working-tree key they should pass. This is a
  `std::set` / strict-weak-ordering consequence, not an observed result.
- **Scope:** local, unprotected, scoped. This is a bounded coverage/verification record,
  not an accepted engineering decision. Full native runtime tests and human review remain
  pending.
- **Reproduction path for a later, permitted iteration (not executed here):**

  ```bash
  bazel test //score/socom/test/unit:socom_test
  # focused key-level, including the new empty-text conversion cases:
  bazel test //score/socom/test/unit:socom_test --test_filter='ServiceInstanceIdentifierTest.*'
  bazel test //score/socom/test/unit:socom_test --test_filter='ServiceInstanceIdentifierTest.ConvertedEmptyText*'
  ```

  Expected on the corrected key: the empty-text construction paths agree and hash-equal,
  the four converted empty-text keys collapse to one set element, and the empty identity
  orders before a non-empty one. These expectations are source-derived, not measured.

---

## 7. Obligations status (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Freedom from compiler warnings & errors (100 %) | `verification_plan.rst` (criterion 9) | **NOT MEASURED** — header is brace-balanced by inspection (§2), but nothing was compiled in this iteration; the added cases are unbuilt |
| Static code analysis (clang-tidy / CodeQL), findings classified | `code_analysis.rst`; `verification_process.rst` (`gd_req__verification_sca_classification`) | **NOT PERFORMED** — no tool, no build |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` (`:status: draft`) | **UNKNOWN** — mapping is draft; not applied |
| Structural statement / branch coverage goals | `verification_plan.rst` (criteria 1-2) | **NOT MEASURED** — no execution; retained coverage is out of this checkout |
| Unit/component testing executed, results recorded | `verification_plan.rst` (criteria 6-7); `verification_guideline.rst` | **PARTIAL / NOT COVERING THIS CHANGE** — retained focused host run is 83/83 green for the previous identifier TU; the two added cases and the runtime suite are unmeasured |
| Interface / requirements-based / resource / fault-injection test types | `verification_process.rst`; `verification_plan.rst` | **NOT PERFORMED / applicability not inferred** — identifier-only tests must not be labelled platform validation |
| Boundary / equivalence derivation | `verification_process.rst` | **SOURCE-ONLY (+ host-measured for the previous identifier TU)** — cases exist (§3); the new ones were not executed |
| Fuzzy testing technique | `verification_plan.rst` | **NOT EXECUTED / NOT CLAIMED** — no harness, no measurement |
| Linking tests to requirements (record properties) | `verification_process.rst` (`gd_req__verification_link_tests_cpp`) | **PARTIAL / NOT DONE** — `DerivationTechnique`/`Description` recorded in `SetUp()`; `TestType` and `Verifies` left unset (no verified native identifier; inventing one is prohibited) |
| Independence of verification / review by a different committer | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Implementation inspection checklist IMPL_01…IMPL_03 | `inspection_checklist.rst` (`:status: draft`) | **NOT FILLED** — draft template, no inspection |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** for this slice; no tool run here |
| Obligation collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **ABSENT in this checkout** — directory not present |
| Native acceptance | `source-index.json` | **not_inferred** for every entry |

**Explicit non-satisfaction statement.** Missing tools, the unknown safety class and
un-inferred applicability, the incomplete extraction of host artifacts, the absent
obligation-collection results, the unmeasured new cases, and the unanswered human reviews
mean **none of the checked obligations may be treated as satisfied**. A collection node
that retained results would only show *retention*, not passing; here there are no retained
results at all. In particular, the absence of
`.llm_tmp/overnight/obligations/*/result.json` is **not** evidence that the corresponding
checks passed, and the retained 83-case host capture is **not** evidence for the two new
cases.

---

## 8. Notice preservation

- Only `.llm_tmp/overnight/reports/conversion_tests.md` (this report) and the candidate
  test file `score/socom/test/unit/service_identifier_tests.cpp` were written. No other
  candidate source path, `NOTICE`, `LICENSE`, `REUSE.toml`, config, BUILD, or prior-report
  file was created, edited, or deleted.
- `score/socom/test/unit/service_identifier_tests.cpp` retains its Apache-2.0 / SPDX
  header (lines 1-12). Every other existing Apache-2.0 / notice header is untouched; this
  report carries the Apache-2.0 header.
- The prior `.llm_tmp/overnight/prior-reports/conversion_tests.md` was **not** overwritten.
- The duplicate key remains an `impl/`-only type; the `testonly`
  `//score/socom:impl_service_identifier` library exposes it to
  `//score/socom/test/unit` only, so no public header or notice surface changed.

---

## 9. Pending human review checklist

- [ ] **Confirm §2:** the header is already brace-balanced (single nested close
      `}  // namespace score::socom`; line 39 blank), so the recorded syntax failure is
      stale and no source edit is required. Confirm the no-op was the intended outcome.
- [ ] **Review the two added conversion cases (§3.2)** and confirm the empty-text boundary
      is the coverage that was wanted, and that it is acceptable that the file now has 85
      cases.
- [ ] **Compile and run** `bazel test //score/socom/test/unit:socom_test` (including the
      new `ConvertedEmptyText*` cases) since this iteration had no compiler; record the
      result. Do not infer passing from the retained 83-case capture.
- [ ] **Confirm the existing 12 conversion cases plus the two new ones** are the wanted
      identifier-conversion boundary coverage, and that the public
      `Service_interface_identifier` identity is correctly left unchanged.
- [ ] **Supply the missing obligation results** (`.llm_tmp/overnight/obligations/*/result.json`)
      and resolve `engineering_acceptance: pending` / `human_reviews: unanswered`.
- [ ] **Keep the #84 public `Service_interface_identifier` restructure, FindService
      wildcard handling, and the config minor-wildcard narrowing out of this bounded slice**
      until separately accepted, and do not present the identifier-only tests as platform
      validation or claim an unmeasured fuzzy technique.
