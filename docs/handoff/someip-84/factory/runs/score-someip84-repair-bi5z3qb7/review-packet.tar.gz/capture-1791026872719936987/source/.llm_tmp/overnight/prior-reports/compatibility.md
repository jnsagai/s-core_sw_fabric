<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — exact-major / minimum-minor compatibility review against the changed registration key

**Document type:** review draft (actual-source inspection + syntax-failure reconciliation +
exact-major/minimum-minor compatibility analysis against the changed duplicate-server
registration key + untested-path register + discovery-semantics preservation + obligations status)
**Date:** 2026-10-02
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version handling in
socom* (issue #84)
**Run:** `fabro/run/01M3YRJEGXNY6CB81T7TKW774B`
**Status:** local, unprotected, scoped. **No engineering acceptance exists. Human reviews are
unanswered. Full native runtime tests remain pending.** Every statement below is either a direct
static reading of this checkout at the baseline-bound candidate paths, or an explicitly-labelled
logical consequence, or a record of an artifact that is present under `.llm_tmp/overnight/`.
Nothing here is published, reviewed, accepted, or a full native run.

> **Tool / write boundary observed.** This iteration used only `read_file`, `grep`, `glob`, and
> `write_file` (no `shell`, no `edit_file`, no delegation, no web access, no approval, no
> publishing, no engineering acceptance). The task's explicit final sentence —
> *"This is a review draft: only that report may be written."* — is the operative write boundary.
> Accordingly, **exactly one file was written: this report**
> (`/workspace/.llm_tmp/overnight/reports/compatibility.md`). No source, build, test, config,
> `NOTICE`, `LICENSE`, `REUSE.toml`, or prior-report file was created, edited, or deleted.
>
> **The recorded syntax failure is not present in the actual source (re-verified).** The task
> records *"a measured GCC syntax failure: an extra closing brace in
> `score/socom/impl/service_identifier.hpp` at line 39."* Direct `read_file` + `grep` on the
> current working tree show the header is **brace-balanced**: the only brace-bearing lines are
> `:19` (`namespace score::socom {`) and `:29` (`struct Service_instance_identifier final {`) as
> openers, and `:32` (`};`) and `:38` (`}  // namespace score::socom`) as closers. Line `:39` is
> **empty** and `:40` is `#endif`. Two openers, two closers, net balance `0`; there is no third,
> unmatched closing brace (§2). The only compile failure retained by this run is a **clang**
> `-Werror` failure originating in **googletest/`<bits/stl_tempbuf.h>`** (a vendored dependency
> outside the six candidate paths), not in the header. The GCC focused compile of the same
> translation unit exits `0` with empty `stderr`. Applying a "repair" to the already-balanced file
> would be a no-op at best and a regression at worst, so **no source write was made and none is
> required.** The minimal historical repair is retained in §2.4 for reference only.

---

## 0. Summary

1. **Recorded syntax failure — inspected; not present in the actual source (§2).**
   `score/socom/impl/service_identifier.hpp` is brace-balanced (four brace-bearing lines:
   `:19`, `:29`, `:32`, `:38`; `:39` blank). The GCC host measurement and the GCC obligation
   collection both compile this header as a transitive include with `-Wall -Wextra -Werror` and exit
   `0` with empty `stderr`; the only recorded compile failure is clang's googletest/libstdc++
   `-Wdeprecated-declarations` error, a dependency issue outside the candidate paths. **No source
   edit was made.**
2. **The changed key is exactly `(instance, service id, major)`; `minor` is excluded (§3).**
   `score/socom/impl/service_identifier.cpp:28-29` orders by
   `std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major)`. This now matches the
   deliberately minor-ignoring `Service_database` index (`runtime_impl.hpp:116-134`), so any two
   configurations resolving to the same `Service_record` also collide in the key set and the second
   server connector is rejected with `Construction_error::duplicate_service`
   (`runtime_impl.cpp:443`, `:449-454`).
3. **Exact-major compatibility is preserved and consistent with the changed key (§4).** `major`
   remains an identity component of the key *and* is still required to match exactly in
   `is_interface_compatible` (`runtime_impl.cpp:144`). Two servers that differ in `major` are
   distinct keys and may coexist; a client/server pair that differs in `major` does not bind. The
   key change neither relaxes nor strengthens exact-major.
4. **Minimum-minor compatibility is preserved and unrelated to the changed key (§5).** The
   `client.minor <= server.minor` rule lives in `is_minor_version_compatible`
   (`runtime_impl.cpp:133-136`) and is applied only at client bind / server connect
   (`:505-517`, `:534-544`). It is **not** encoded in the key. Excluding `minor` from the duplicate
   key does not alter the minimum-minor relation; it only makes the duplicate-server gate as coarse
   as the record index, so the single-server precondition
   `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)` (`:369`) can no longer be reached via a
   minor-only pair of server constructions.
5. **Untested paths identified (§6).** The Bazel/native obligations could not run (`bazel` absent,
   exit `127`), so `//score/socom/test/unit:socom_test` — which contains `runtime_tests.cpp`,
   `interface_compatibility_tests.cpp`, and `client_tests.cpp` — was **never executed**. The only
   executed suite is the focused identifier translation unit (`service_identifier_tests.cpp`,
   85 cases). The `is_interface_compatible` ASSERT branches, the un-called
   `Service_database::get_instances`, client-side minor duplicates, and the config/wildcard
   narrowing remain unexercised.
6. **Discovery semantics were not changed (§7).** The key set `m_service_identifiers` is used only
   in `Runtime_impl::make_server_connector` (insert at `:451`, erase at `:461`). The
   `Service_database` minor-ignoring index (`runtime_impl.hpp:116-134`), `get_record`
   (`runtime_impl.cpp:313-324`), `bridge_service_requests` (`:561-575`), and
   `get_bridge_reported_instances` (`:595-612`) are untouched. Future work must keep it so.
7. **No obligation is satisfied (§8).** The host artifacts are now **present** under
   `.llm_tmp/overnight/validation/` and `.llm_tmp/overnight/obligations/`, but per the task rule a
   successful collection node means results were *retained*, not that checks *passed*. Several
   checks failed or are blocked (native `bazel` obligations exit `127`, clang blocked on a
   dependency, tsan `-11`/`66`, valgrind/gitleaks unavailable, clang-tidy config blocker), the
   safety class is unknown, applicability is `not_inferred`, and human reviews are unanswered.

---

## 1. Binding to the baseline, prior reports, host feedback, and obligations

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` | `.llm_tmp/context/issue-snapshot.json:2-4` |
| Title | *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:3` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` (unchanged) | `.llm_tmp/context/issue-snapshot.json:19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**. It distinguishes: service-instance identifier = `service id + major + minor +
instance id`; service identifier = `service id + major`; FindService = `service id + major +
optional<minor> + optional<instance>`; and proposes to "exclude the minor version and make it a
property of the service instance to be able to better compare and index compatible service
instances." The FindService `major = FF` AUTOSAR case is called theoretically possible but not
useful. There is **no comment and no acceptance record** in the snapshot, so none of it is binding.

### 1.2 Verified baseline

| Item | Value | Source |
|------|-------|--------|
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |
| Branch | `fabro/run/01M3YRJEGXNY6CB81T7TKW774B` | environment |
| Latest run commit | `fabro(01M3YRJEGXNY6CB81T7TKW774B): node_6ea11f155d1527d342eaf02e (success)` | environment |

Binding is **by baseline commit**, not by run HEAD. Earlier reports reference other run IDs on the
same baseline commit (`01M3YGTGYFEN406VDEVVTJTRWV`, `01M3XZAQ65TTE35XSGXC4JAMAH`,
`01M3XT7NQ04S4MTFRMTT2401XK`, `01M3WX09X84XFM5X08QY2944DF`, and before them
`01M3WSTF1DAJA248NQ5QQGQG52`/`a282596` and `01M3WWRQWT262FTYS52X80YPTP`/`e12e7cb`), so all of them
describe the same baseline and remain admissible prior evidence.

### 1.3 In-scope candidate files (`.llm_tmp/context/candidate-files.json:1-25`)

| File (repo-relative) | Baseline git blob | Baseline present | Working tree (read this iteration) |
|----------------------|-------------------|------------------|------------------------------------|
| `score/socom/BUILD` | `3477ea0851fdcd82ec6ea9d71424013cbdf41962` | yes | `socom` lib (`:24-41`); `testonly` `impl_service_identifier` (`:46-54`) |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e22355242009fe20dada2a9a0d0c7a9c7` | yes | key identity `(instance, id, major)`; `minor` excluded (`:28-29`) |
| `score/socom/impl/service_identifier.hpp` | `c8bae7908da9f087c518934f7b9f8d86db9a20ec` | yes | brace-balanced, 40 lines, `:39` blank (§2) |
| `score/socom/test/unit/BUILD` | `3c03a7b14286051f97fa5022206564bd63645171` | yes | `socom_test` globs `*.cpp`; deps wired (`:16-29`) |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab726db8bf994c960045d6fd7fdf84d7395` | yes | 31 `TEST_F` + 1 `TEST` + 1 `TEST_P`; minor-only regression `:402-431` |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(none — `null`)* | **no** (manifest expects a **new** file) | 85-case `TEST_F` matrix present (`:168`…`:2012`) |

The `null` baseline blob for `service_identifier_tests.cpp` is the manifest's expectation of a
**new** unit-test file; it exists on disk only as part of the un-merged working tree (the
"cancelled draft"), never in the baseline. `glob` over `**/service_identifier.hpp` returns exactly
one path, so there is no second, differently-braced copy of the header in this checkout.

> **Content-hash caution.** `candidate-files.json` also declares a `sha256` per candidate. For the
> header it declares `96b33a1f…`; the host measurement
> (`.llm_tmp/overnight/validation/measurement.json` and
> `.llm_tmp/overnight/obligations/compiler_diagnostics/result.json`) records the working-tree header
> as `bdce3fcbc3cd78a8ecaece1ea36107d464011ab81c9bc39932d0be617befaea9`. These differ, i.e. the
> working tree has moved relative to the context snapshot that describes the "cancelled draft".
> Therefore the context snapshot's description of a brace defect cannot be assumed to describe the
> current file; the **direct read of the actual file is authoritative** here, and it shows a
> balanced header. (No hashing tool is available in this task; this is quoted from the artifacts.)

### 1.4 Pinned obligation sources read this iteration

All nine entries of `.llm_tmp/context/obligations/source-index.json` were read from
`.llm_tmp/context/obligations/`, together with `authority.json`. Every entry is pinned with
`"native_acceptance": "not_inferred"` — pinned, but its applicability to this slice is **not
inferred**.

| id | repository @ commit | status note |
|----|---------------------|-------------|
| `coding_guidelines` | `score` @ `e2373d82…` | `:status: valid`; MISRA C++:2023 with C++17 |
| `code_analysis` | `score` @ `e2373d82…` | `:status: valid`; clang-tidy + gcc/clang warnings + Coverity; sanitizers; gcov/gcovr |
| `misra_mapping` | `score` @ `e2373d82…` | **`:status: draft`**; rule table commented out |
| `verification_plan` | `score` @ `e2373d82…` | `:status: valid`; TestType/DerivationTechnique tables; quality criteria 1–9 (criterion 9 = freedom from compiler warnings & errors, 100 %) |
| `development_plan` | `score` @ `e2373d82…` | `:status: valid`; C++17, GCC host compiler, QCC target, Bazel |
| `tool_management` | `score` @ `e2373d82…` | `:status: valid`; tools must be identified / evaluated / qualified |
| `verification_process` | `process_description` @ `98d1d5f4…` | `:status: valid`; `gd_req__verification_link_tests*`, `gd_req__verification_independence`, `gd_req__verification_checks_extended`, `gd_req__verification_sca_classification` |
| `verification_guideline` | `process_description` @ `98d1d5f4…` | `:status: valid`; traceability, independence, documented results |
| `inspection_checklist` | `module_template` @ `c4d4ad09…` | **`:status: draft`**; blank IMPL_01_01…IMPL_03_02 template |

`authority.json` records `"engineering_acceptance": "pending"`, `"human_reviews": "unanswered"`,
`"safety_class": "unknown"`, `"codeql_scope": "Public Apache-2.0 eclipse-score/inc_someip_gateway;
no upload"`, and the instruction `"Restart the failed queue for one complete pass through all
obligations"`.

### 1.5 Prior reports, host feedback, and obligation-collection results (all present this iteration)

- **Prior reports read and preserved** under `.llm_tmp/overnight/reports/`: `callsites.md`,
  `conversion_tests.md`, `coverage_tests_repair.md`, `invariants.md`, `key_fix.md`,
  `lifetime_tests.md`, `ordering_tests.md`, `reproducer.md`, `runtime_disabled.md`,
  `runtime_enabled.md`, `scope.md`, `test_metadata.md`, `tool_findings_repair.md`, `unit_matrix.md`.
  All are preserved unchanged; this document adds `compatibility.md` only. (A separate
  `.llm_tmp/overnight/prior-reports/` directory is referenced by those reports; where it is quoted
  below its content is reproduced as *quoted evidence*, not as this iteration's measurement.)

- **Host validation feedback is now present** under `.llm_tmp/overnight/validation/`:
  - `check-result` = `0`.
  - `measurement.json`: `check_ref: check_conversion_tests`, `mode: ubsan`,
    `changed_paths: ["score/socom/test/unit/service_identifier_tests.cpp"]`,
    `origin: local_unprotected_measurement`, `initiator: Fabro host hook`,
    `engineering_acceptance: pending`, `full_native_tests: not_executed`,
    compiler `/usr/bin/x86_64-linux-gnu-g++-12` (`sha256 88315fd2…`),
    `baseline_with_agent_tests` = **85 tests / 28 failures / compile exit 0 / test exit 1**,
    `candidate` = **85 tests / 0 failures / compile exit 0 / test exit 0**.
  - `before.json` = 85 tests / 28 failures; `after.json` = 85 tests / 0 failures.
  - `after-compile.command.json` / `before-compile.command.json`: GCC `-std=c++17 -Wall -Wextra
    -Werror -pthread` over `service_identifier.cpp` + `string_registry.cpp` +
    `service_identifier_tests.cpp` + googletest, exit `0`, empty `stderr`.
  - `after-test.command.json` / `before-test.command.json`: test-binary runs; exit `0` (after).
  - **Scope caveat:** the measurement compiles **only the focused identifier translation unit**. It
    does **not** compile `runtime_tests.cpp`, `interface_compatibility_tests.cpp`, or
    `client_tests.cpp`, and it is not a Bazel build of `socom_test` or `//score/...`.
  - `changed_paths` names only the test file; the before/after distinction (28 failures vs 0) is the
    registration-key implementation difference (`service_identifier.cpp`, measured hash
    `3c12b3f1…`), which demonstrates that the expanded key tests are red on the baseline key and
    green on the changed key.

- **Obligation-collection results are now present** under `.llm_tmp/overnight/obligations/`
  (`*/result.json`, `*/collection-result`, and command/stdout/stderr artifacts). Per the task rule,
  a successful collection node means results were **retained**, not that checks **passed**. The
  retained statuses relevant to this slice include:
  - `compiler_diagnostics`: GCC focused compile+tests exit `0`; **clang exit `1`** due to
    googletest/`<bits/stl_tempbuf.h>` `-Wdeprecated-declarations` under `-Werror`;
    `status: findings_or_execution_failure`.
  - `focused_asan_lsan`: exit `0` (completed).
  - `focused_coverage`: `service_identifier.cpp` 100 % line / 78.6 % branch (an earlier capture:
    77.8 % / 64.3 %); platform goals `QM 85`, `safety 100`; `safety_class:
    unknown_requires_authorized_selection`; `complete_target_scope: false`.
  - `focused_tsan`: exit `66` (one capture) / `-11` (another) — failed.
  - `focused_memcheck`: valgrind binary absent (`/tmp/score-someip84-obligation-tools/usr/bin/valgrind`),
    exit `127`.
  - `focused_clang_tidy`: exit `1` (config blocker).
  - `focused_cppcheck`: exit `2`.
  - `codeql_security` / `codeql_misra`: scan completed; findings retained include googletest
    dependency hits; MISRA limits note a focused linked executable, not full target extraction, and
    the rule mapping is a draft.
  - `native_build`, `native_tests`, `native_integration`, `native_sanitizers`, `native_tsan`,
    `native_lint`, `native_docs`, `native_traceability`, `native_coverage`, `native_performance`,
    `cross_compilation`, `format_precommit`: exit `127` — `bazel` absent
    (`[Errno 2] No such file or directory: '/tmp/s-core-001/bin/bazel'`).
  - `secret_dependency_checks`: ran (lock `sha256 c90b245b…`); `process_checks`:
    `completed_with_blockers`; `rework_progress`: `completed`, `source_changed_this_round: true`,
    `rework_requested: false`; `tool_assurance`: `valgrind`/`gitleaks` unavailable.

### 1.6 Host addendum (task context, not acceptance)

The host addendum (available in this checkout only as quoted by prior reports) states it "is task
context, not engineering acceptance or an approved tailoring decision." It asks the review to cover
the `verification_process` test types (fault injection, interface, requirements, resource) and
derivation techniques (requirements/design/boundary/equivalence/fuzzy/error-guessing/explorative);
to keep unknown applicability and unexecuted applicable checks explicit; to **not** label
identifier-only tests as full platform validation and **not** to claim a fuzzy technique without a
measurement; to permit concrete missing boundary/equivalence regression cases within the six source
paths; and to record that there is **no authority to invent native links, select a safety
classification, accept risk/deviations, or answer the independent human gate.** This report honours
that in §4–§8.

---

## 2. The recorded syntax failure: inspection of the actual source

### 2.1 Finding (re-verified this iteration by direct `read_file` + `grep`)

`score/socom/impl/service_identifier.hpp` is **brace-balanced**. It is exactly 40 lines; `grep` for
`[{}]` on the file returns exactly four matches, and `grep` for `namespace` returns exactly two:

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 21–28 | doc comment | documents that `minor` is intentionally not part of the identity |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 35 | `bool operator<(…)` | declaration of the single operator (no brace) |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`) and two closers (`:32`, `:38`): net brace balance `0`. There is **no
third, unmatched closing brace**, and line `:39` contains no text at all. The task's "extra closing
brace … at line 39" therefore matches a **stale, pre-correction** description. The `reproducer`
iteration records the correction; every later report records the header as already balanced — which
is what the actual source shows here.

### 2.2 Measured corroboration (artifacts present this iteration; neither is acceptance)

- `validation/after-compile.command.json` and `validation/before-compile.command.json` both compile
  the header (as a transitive include of `service_identifier.cpp` and
  `service_identifier_tests.cpp`) with `g++-12 -std=c++17 -Wall -Wextra -Werror`, **exit `0`,
  empty `stderr`**.
- `obligations/compiler_diagnostics/gcc-compile.command.json` likewise exits `0` with empty
  `stderr`; `gcc-tests` exits `0` (85 cases).
- The **only** non-zero compiler exit in the retained artifacts is
  `obligations/compiler_diagnostics/clang-compile.stderr`: `clang++ 19` fails with
  `'get_temporary_buffer<testing::TestInfo *>' is deprecated [-Werror,-Wdeprecated-declarations]`
  originating in `/usr/lib/gcc/.../include/c++/12/bits/stl_tempbuf.h:263` via googletest
  `gtest.cc`. That is a **vendored-dependency** warning promoted to an error; it is not a defect in
  the header and not in any of the six candidate paths.

### 2.3 Why it would matter if present

The header is compiled into `//score/socom:socom` (`score/socom/BUILD:24-41`; its `srcs` globs
`impl/**/*.cpp` and `impl/**/*.hpp`) and re-exposed to `//score/socom/test/unit` through the
`testonly` library `impl_service_identifier` (`score/socom/BUILD:46-54`;
`score/socom/test/unit/BUILD:24`). A syntax error there would fail the library and the whole
`socom_test` target, contradicting S-CORE quality criterion 9, "Freedom from compiler warnings &
errors, 100 %" (`verification_plan.rst`). The current tree does not have that defect, and the GCC
focused compiles in §2.2 corroborate it.

### 2.4 Minimal historical repair (retained for reference only; NOT applied)

Should the imbalance ever reappear, the minimal correction — matching the sibling `.cpp` — is:

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

Applying this to the already-balanced file would be a no-op; re-introducing a broken state merely
to "fix" it would be a regression. **No source change was made.** If the "cancelled draft" is a
different revision that still carries the extra brace (see the hash caution in §1.3), it is not the
file in this checkout and must be located and corrected by an authorized iteration; this report
records the discrepancy for human disposition rather than speculating.

---

## 3. The changed duplicate-server registration key (as-is)

All line references are readings of the current working tree at the baseline-bound candidate paths.

| Item | Site | Notes |
|------|------|-------|
| Key struct | `score/socom/impl/service_identifier.hpp:29-32` | `Service_instance_identifier{ Service_interface_identifier interface; Service_instance instance; }`; comment `:21-28` explains the minor exclusion and references the minor-ignoring index / issue #84 |
| `operator<` declaration | `score/socom/impl/service_identifier.hpp:35` (inside `\cond`/`\endcond`, `:34`/`:36`) | the **only** operator of the type; no `operator==`, no `std::hash` |
| `operator<` definition | `score/socom/impl/service_identifier.cpp:20-30` | `std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major) < std::tie(rhs.instance, rhs.interface.id, rhs.interface.version.major)` (`:28-29`); comment `:21-27` |
| Container / storage | `score/socom/impl/runtime_impl.hpp:56`, `:228-229` | `Service_identifiers = Mutexed_variable<std::set<Service_instance_identifier>>` |
| Key construction / duplicate gate | `score/socom/impl/runtime_impl.cpp:443`, `:449-454` | `Service_instance_identifier const identifier{configuration.get_interface(), instance};` then, under the key mutex, `insert(identifier).second == false ⇒ Construction_error::duplicate_service` |
| Key lifetime | `score/socom/impl/runtime_impl.cpp:456-463` | `Final_action` captures `identifier` + `weak_ptr` and erases on destruction |

`std::set` uniqueness is `!(a < b) && !(b < a)`. Therefore, on this working tree, the duplicate
server identity is exactly `(instance, service id, major)` and **`minor` is not part of it**. The
public `Service_interface_identifier` ordering/hash still include `minor`
(`service_interface_identifier.hpp:130-133`, `:140-143`, `:149-152`, `:159-162`, `:181-190`); only
the `impl/`-only key excludes it.

This is the draft's closure of the key/index gap: the `Service_database` index already ignores
`minor` via `Minor_version_ignoring_key_equal` / `Minor_version_ignoring_hash`
(`runtime_impl.hpp:116-121`, `:123-129`, `:131-134`), and `Service_record` holds a single
`std::optional` server (`runtime_impl.hpp:70`) guarded by
`SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)` (`runtime_impl.cpp:369`). With the changed key, two
server connectors that share `instance + id + major` but differ only in `minor` now collide at the
set insert rather than both resolving to the same record and reaching the single-server assert.

---

## 4. Exact-major compatibility against the changed key

**Result: preserved and consistent; no semantic change.**

- **In the key.** `major` is an identity component (`service_identifier.cpp:28-29`). Two server
  registrations that differ in `major` produce distinct keys and may coexist; the slot for one
  major does not block another. This is direction-consistent with issue #84's "service identifier =
  `service id + major`" use case.
- **In the compatibility predicate.** `is_interface_compatible` requires
  `server.version.major == client.version.major` (`runtime_impl.cpp:144`) in addition to equal
  `id`; a client/server pair with different `major` never binds (the `else` branch logs
  "minor version incompatible"; call sites `:505-517` client, `:534-544` server).
- **Key-level evidence (source, not executed here).** `KeysDifferingInMajorVersionAreDistinct`
  (`service_identifier_tests.cpp:217`), `MajorVersionBoundariesAreDistinct` (`:225`),
  `MajorVersionSweepProducesDistinctKeys` (`:235`), `AdjacentMajorVersionBoundariesAreDistinct`
  (`:246`), `MajorVersionLadderOrdersNumericallyAndDistinctly` (`:1264`),
  `MajorVersionByteBoundariesAreDistinctAndOrdered` (`:1656`),
  `MajorVersionOrderMatchesUnsignedNumericOrder` (`:1680`).
- **Runtime-level evidence (source, not executed here).**
  `ConstructDifferentMajorWhileBothConnectorsDisabledReturnsDistinctServerConnectors`
  (`runtime_tests.cpp:471`), `DestroyingOneMajorSlotKeepsOtherMajorSlotOccupied` (`:1141`).
- **Integration/C++ evidence.** `DifferentServiceInterfaceMajorVersion`
  (`client_tests.cpp:643`); `interface_compatibility_tests.cpp` `Version` instantiation, where a
  mismatching major is `Expectation::no_connect` (`:193-204`).

**Boundary note (unresolved, out of slice).** Some SOME/IP stacks use `major = 0xFF` as a wildcard,
and the config declares `service_version_major: uint8`
(`score/config/mw_someip_config.fbs:19`) versus socom's `std::uint16_t major`
(`service_interface_identifier.hpp:83`). The changed key treats `major` as an exact identity
component and does not implement any wildcard. That is deliberate for this bounded slice and is
recorded as unresolved, not as a defect.

---

## 5. Minimum-minor compatibility against the changed key

**Result: preserved; the changed key does not encode or alter the minimum-minor rule.**

- **The rule.** `is_minor_version_compatible(server, client)` is
  `client.version.minor <= server.version.minor` (`runtime_impl.cpp:133-136`); it is applied at
  client bind (`:505-517`) and server connect (`:534-544`). It is a **server-vs-client** relation,
  not a set-membership rule, and it is **not** consulted anywhere inside the key set.
- **The key.** `minor` is excluded (`service_identifier.cpp:28-29`). Excluding it makes duplicate
  detection *coarser*; it does not change `<=`. Two servers sharing `instance + id + major` but
  differing in `minor` are now the same registration key. Consequently the client's possible
  counterpart server for a given `(instance, id, major)` is unique, and the `<=` test is evaluated
  against that single server's `minor`.
- **Direction of the interaction.** On the pre-correction key (`minor` included) two such servers
  could both be constructed, but `Service_record` can hold only one (`m_server` `std::optional`,
  `runtime_impl.hpp:70`; `ASSERT(!m_server)`, `runtime_impl.cpp:369`), so the second *enable* would
  hit the assert. The key change removes that path at *construction* time and returns
  `duplicate_service`. This is a change to duplicate **registration**, not to minimum-minor
  **compatibility**.
- **Evidence (source, not executed here).**
  - `interface_compatibility_tests.cpp` `Version` instantiation (`:190-211`) covers: same
    version → connect; client `{min_major, 10}` vs server `{min_major, min_minor}` → no_connect;
    server `{min_major, 10}` vs client `{min_major, min_minor}` → connect; `max_major` mismatch →
    no_connect; `max_minor` variants; both-`max_version` → connect. Both
    `ServerCreatedBeforeClient` (`:73-89`) and `ClientCreatedBeforeServer` (`:91-123`) orders are
    parameterized.
  - `client_tests.cpp:660` `BiggerServiceInterfaceMinorVersion` (server minor smaller than the
    client's ⇒ no_connect) and `:678` `SmallerServiceInterfaceMinorVersion` (server minor larger ⇒
    connect).
  - `runtime_tests.cpp:402-431` `ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicate…`
    and the enabled variants (`:726-758`, `:832-864`, `:869-900`) exercise the key's minor
    collapse at the `Runtime::make_server_connector` entry point.

**Asymmetry worth recording.** `Service_record` also holds a single client (`m_client`,
`runtime_impl.hpp:71`), and `register_client_connector` returns `duplicate_client` when `m_client`
is already set (`runtime_impl.cpp:386-388`) — without comparing versions at all. Client duplicate
detection therefore already ignored version, including `minor`. The changed key makes the
*server-side* duplicate identity consistent with the same minor-ignoring record index; it does not
touch client duplicate detection.

---

## 6. Untested paths (explicit register)

The following paths are **not covered by any executed check** in this checkout. Most are due to the
missing native toolchain; the last two are genuine coverage gaps in the draft suite.

1. **Runtime / interface / client suites were never executed.** `//score/socom/test/unit:socom_test`
   could not be built (`bazel` absent, `native_*` obligations exit `127`). Therefore
   `runtime_tests.cpp` (including the minor-only regression `:402-431` and the enabled/lifetime
   variants), `interface_compatibility_tests.cpp` (the whole minimum-minor parameter matrix), and
   `client_tests.cpp` (`Bigger…`/`SmallerServiceInterfaceMinorVersion`) are **read, not run** here.
   The only executed suite is `service_identifier_tests.cpp` (85 cases, focused identifier TU,
   `before.json`/`after.json`).
2. **`is_interface_compatible` ASSERT branches** (`runtime_impl.cpp:508-509` client,
   `:536` server) are described in-source as defensive (`:140-142`) and are never independently
   triggered; no test forces the assert. Only the `else` minor-incompatible log branch is covered.
3. **`Service_database::get_instances`** (both overloads, `runtime_impl.cpp:326-343` and
   `:345-360`) has **no production caller** in the tree (the only reference is the self-forward at
   `:349`). This discovery helper is effectively dead / untested. It is not touched by the key.
4. **Client-side minor duplicates.** There is no test pinning that two client connectors for the
   same `(instance, id, major)` but different `minor` yield `duplicate_client` (client detection
   ignores the interface version entirely, `runtime_impl.cpp:386-388`). This is an untested
   equivalence class adjacent to the changed key.
5. **No discovery-regression test tied to the key change.** Nothing asserts that
   `get_bridge_reported_instances` / `bridge_service_requests` results are unchanged by the key
   change. (Bridge-behaviour tests such as `BridgeReceivesRequestServiceFunctionCallForUnknownService`
   and `BridgeDoesNotReceive…ForKnownService` exist, but they are not framed as key-change
   regressions and were not executed here.)
6. **Config minor wildcard / narrowing and FindService wildcard.** The `uint32 0xFFFFFFFF` minor
   wildcard (`score/config/mw_someip_config.fbs:23`) narrowed to `uint16 0xFFFF` at the
   config→socom conversions, and the FindService `major = FF` case, are unresolved and untested;
   they are explicitly out of this bounded slice.
7. **Tool-based obligations remain unestablished**: clang compile (dependency
   `-Wdeprecated-declarations`), clang-tidy (config blocker), tsan (exit `-11`/`66`), valgrind
   memcheck and gitleaks (tools absent), native coverage (not run). These are not "passing".

---

## 7. Discovery semantics (deliberately unchanged)

The changed key is a **duplicate-server registration gate only**. It must not and does not affect
service discovery:

- The key set `m_service_identifiers` is read/written only in `Runtime_impl::make_server_connector`:
  constructed at `runtime_impl.cpp:443`, inserted under the key mutex at `:449-454`, erased by the
  captured `Final_action` at `:456-463`.
- The `Service_database` record index (`Minor_version_ignoring_key_equal` /
  `Minor_version_ignoring_hash`, `runtime_impl.hpp:116-134`) and `get_record`
  (`runtime_impl.cpp:313-324`) are untouched and remain minor-ignoring.
- Bridge/discovery (`bridge_service_requests`, `runtime_impl.cpp:561-575`;
  `get_or_create_service_requests`, `:577-587`; `get_bridge_reported_instances`, `:595-612`) is
  driven by `m_service_requests` / `m_bridge_to_callbacks`, **not** by the key set, and is
  untouched.
- The public identifier's ordering/hash (still `minor`-aware,
  `service_interface_identifier.hpp:130-190`) and the IPC `Service` key (still `minor`-aware) are
  untouched.

**Recommendation carried to human review:** any future implementation in this slice must keep the
key change confined to the `std::set` duplicate gate and must not alter `Service_database`,
`get_record`, or the bridge/discovery paths, so that discovery semantics stay byte-for-byte
unchanged.

---

## 8. Obligations status (none satisfied)

### 8.1 Pinned state

All nine pinned sources were read (§1.4); every `source-index.json` entry is
`"native_acceptance": "not_inferred"`. `authority.json` records
`engineering_acceptance: pending`, `human_reviews: unanswered`, `safety_class: unknown`.

### 8.2 Status for this slice

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Freedom from compiler warnings & errors (100 %) | `verification_plan.rst` (criterion 9) | **PARTIAL, NOT SATISFIED** — GCC focused compile exit `0` with empty `stderr`; clang focused compile fails on a googletest/libstdc++ deprecation (dependency, outside candidate paths); no Bazel build |
| Static code analysis (clang-tidy / CodeQL), findings classified | `code_analysis.rst`; `verification_process.rst` (SCA classification) | **NOT SATISFIED** — clang-tidy config blocker; CodeQL security/MISRA results retained but include dependency hits and a draft rule mapping |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` | **UNKNOWN** — mapping is `:status: draft`; not applied |
| Structural statement / branch coverage goals | `verification_plan.rst` (criteria 1–2) | **NOT SATISFIED** — focused identifier coverage 100 % line / 78.6 % branch, below the 100 % safety / even the 85 % QM platform goal on branch, `safety_class: unknown`, `complete_target_scope: false`; native coverage did not run |
| Unit/component testing executed, results recorded | `verification_plan.rst` (criteria 6–7); `verification_guideline.rst` | **PARTIAL, NOT SATISFIED** — only `service_identifier_tests.cpp` executed (85/0); `socom_test` / `runtime_tests.cpp` never executed |
| Interface / requirements-based / resource / fault-injection test types | `verification_process.rst`; `verification_plan.rst` | **NOT PERFORMED / applicability not inferred** — no harness; identifier-only tests must not be labelled platform validation |
| Boundary / equivalence derivation | `verification_process.rst` | **SOURCE-ONLY / PARTIALLY EXECUTED** — key boundary/equivalence cases executed; runtime/interface equivalents only read |
| Fuzzy testing technique | `verification_plan.rst` | **NOT EXECUTED / NOT CLAIMED** — no harness and no measurement |
| Linking tests to requirements (record properties) | `verification_process.rst` (`gd_req__verification_link_tests*`) | **PARTIAL / NOT DONE** — `DerivationTechnique`/`Description` recorded (`service_identifier_tests.cpp:42-65`; `runtime_tests.cpp:264-267`); `TestType` and `Verifies` deliberately unset (no verified identifier exists; inventing one is prohibited) |
| Independence of verification / review by a different committer | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Implementation inspection checklist IMPL_01…IMPL_03 | `inspection_checklist.rst` | **NOT FILLED** — draft template, no inspection |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** — `tool_assurance` records valgrind/gitleaks unavailable |
| Obligation collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **PRESENT but retention ≠ passing** — many obligations `findings_or_execution_failure` / exit `127` |
| Native acceptance | `source-index.json` | **not_inferred** for every entry |

**Explicit non-satisfaction statement.** The unknown safety class, the un-inferred applicability,
the missing/failing native toolchain (`bazel` exit `127`), the failing or blocked focused checks
(clang, tsan, memcheck, clang-tidy, cppcheck), the incomplete extraction, and the unanswered human
reviews mean **none of the checked obligations may be treated as satisfied**. A successful
collection node means results were *retained*, not that checks *passed*; here the retained results
include explicit failures, and absence of a result would likewise not be evidence of passing.

---

## 9. Measurement and validation status

- **Tools:** `read_file`, `grep`, `glob`, `write_file` only. No `shell`, delegation, web, approval,
  publishing, or engineering acceptance.
- **Executed measurements by this iteration:** **none**. No build, no test, no runtime. Every
  correctness statement above is a static reading of the working tree at the baseline-bound
  candidate paths or an explicitly-labelled logical consequence.
- **Retained host measurements (present, scoped, unprotected):** `validation/` shows the focused
  identifier TU as `before 85/28` → `after 85/0` (GCC `-Werror`, UBSan), exit `0`/empty `stderr`.
  It does **not** cover `runtime_tests.cpp`, `interface_compatibility_tests.cpp`, `client_tests.cpp`,
  or any Bazel target. `engineering_acceptance: pending`, `full_native_tests: not_executed`.
- **Test inventory (read, not run):** `service_identifier_tests.cpp` = **85 `TEST_F`** under
  `ServiceInstanceIdentifierTest` (`:168`…`:2012`; matches `after.json`'s 85 cases);
  `runtime_tests.cpp` = **31 `TEST_F` + 1 `TEST` (`:239`) + 1 `TEST_P` (`:1311`)**.
- **Regression target (source-derived, not executed here):**
  `RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError`
  (`runtime_tests.cpp:402-431`) and the key-level minor-collapse cases
  (`service_identifier_tests.cpp:174`, `:182`, `:192`, `:203`, …) assert that a second registration
  differing only in `minor` is rejected as `duplicate_service`. On the baseline key they fail
  (28 failures in `before.json`); on the changed key the focused identifier suite passes
  (`after.json`, 85/0). The runtime variant of that regression was not executed here.
- **Scope:** local, unprotected, scoped. This draft has not been reviewed, accepted, published, or
  reproduced on a full native runtime. Unit/integration execution and human review remain pending.
- **Reproduction path for the next authorized iteration (not run here):**

  ```bash
  bazel test //score/socom/test/unit:socom_test
  # focused key-level:
  bazel test //score/socom/test/unit:socom_test --test_filter='ServiceInstanceIdentifierTest.*'
  # focused runtime regression:
  bazel test //score/socom/test/unit:socom_test \
      --test_filter='RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError'
  # minimum-minor matrix:
  bazel test //score/socom/test/unit:socom_test --test_filter='InterfaceCompatibilityTest.*'
  ```

---

## 10. Notice preservation

- **Only this report was written.** No source, build, test, config, `NOTICE`, `LICENSE`,
  `REUSE.toml`, or prior-report file was created, edited, or deleted. Every existing Apache-2.0 /
  notice header is untouched.
- The header the task flagged (`score/socom/impl/service_identifier.hpp`) was inspected and left
  **unchanged** because it is already brace-balanced and well-formed (§2). The sibling
  `service_identifier.cpp`, both BUILD files, and both candidate test files already carry their
  Apache-2.0 / SPDX headers (`service_identifier.hpp:1-12`; `service_identifier.cpp:1-12`;
  `service_identifier_tests.cpp:1-12`; `BUILD`/`test/unit/BUILD:1-12`).
- This report itself carries the Apache-2.0 header.
- The duplicate key remains an `impl/`-only type; the `testonly`
  `//score/socom:impl_service_identifier` library exposes it only to `//score/socom/test/unit`, so
  no public header or notice surface changed.

---

## 11. Pending human review checklist

- [ ] **Confirm the §2 inspection:** the header is already brace-balanced (single nested close
      `}  // namespace score::socom`; line `:39` blank), and the only retained compile failure is
      clang's googletest/libstdc++ deprecation — so the recorded syntax failure is stale and no
      source correction is required. If the "cancelled draft" (cf. the §1.3 hash caution) is a
      different revision that still carries the extra brace, locate it and authorize its
      correction; it is not the file in this checkout.
- [ ] **Resolve the instruction conflict:** the task directs correcting the source, while the actual
      source contains no defect and the explicit write boundary permits only the report. Confirm
      that a no-op plus this report is the intended outcome.
- [ ] **Confirm the bounded key decision (§3):** `minor` is **not** part of the duplicate-server
      registration key; identity is `(instance, service id, major)`; the public interface
      representation and the exact-major / minimum-minor rules are unchanged.
- [ ] **Confirm the exact-major analysis (§4):** `major` remains both a key identity component and
      an exact-equality requirement in `is_interface_compatible`; and confirm whether the `major =
      FF` / config-width wildcard question stays explicitly out of this slice.
- [ ] **Confirm the minimum-minor analysis (§5):** `client.minor <= server.minor` stays a
      client-vs-server predicate, is not encoded in the key, and the key change only prevents two
      same-`(instance, id, major)` server registrations from being constructed.
- [ ] **Confirm the untested-path register (§6):** especially that `runtime_tests.cpp` /
      `interface_compatibility_tests.cpp` / `client_tests.cpp` were not executed, and that the
      identifier-only suite must not be presented as platform validation.
- [ ] **Confirm the discovery-semantics guarantee (§7):** the key change must stay confined to the
      `std::set` duplicate gate; `Service_database`, `get_record`, and the bridge/discovery paths
      must remain untouched.
- [ ] **Do not infer passing from retained collection nodes** (§8): several obligations failed
      (native `bazel` exit `127`, clang dependency error, tsan crash, missing valgrind/gitleaks,
      clang-tidy config blocker); retention is not acceptance.
- [ ] **Run the full native suite** (`bazel test //score/socom/test/unit:socom_test` and the broader
      `//score/...` set), including `runtime_tests.cpp` and the interface-compatibility matrix,
      record results, and schedule independent human review (the approver must differ from the
      author, per `gd_req__verification_independence`).
