<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — final review packet (bounded duplicate-server registration-key slice)

**Document type:** review packet / review draft. Changed paths, test outcomes, known limits,
and the unanswered engineering decisions. **Not** an engineering acceptance, **not** a review
approval, **not** a publication, and **not** a full native run.
**Date:** 2026-10-02
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version handling in
socom* (issue #84)
**Baseline commit:** `f8a196c3b16d5172d898394ab99b0ed81346d63d`
(`.llm_tmp/context/source-manifest.json:2-3`)
**Branch / run:** `fabro/run/01M3YRJEGXNY6CB81T7TKW774B` (`.git/HEAD:1`)
**HEAD at write time:** `06af6e2` (`fabro(01M3YRJEGXNY6CB81T7TKW774B):
  node_b9e9bbdb0632ffde30be850b (success)`, `.git/logs/HEAD:90`)
**Status:** local, unprotected, scoped. **No engineering acceptance exists. Human reviews are
unanswered. Full native runtime tests remain pending.** Every statement below is either a direct
`read_file`/`grep`/`glob` reading of this checkout, a direct reading of a retained artifact under
`.llm_tmp/overnight/`, or an explicitly-labelled logical consequence.

> **Tool / write boundary actually observed.** Only `read_file`, `grep`, `glob`, and `write_file`
> were used. No `shell`, delegation, web, approval, publishing, or engineering acceptance was
> performed. The task contains two directions that conflict: it says *"Inspect and correct the
> actual source before expanding tests"* **and** *"The cancelled draft has a measured GCC syntax
> failure: an extra closing brace in `score/socom/impl/service_identifier.hpp` at line 39"*, but
> its explicit, more specific final sentence says *"This is a review draft: only that report may be
> written."* Following that explicit write boundary, **exactly one file was written — this report**
> (`.llm_tmp/overnight/reports/review_packet.md`). No source, build, test, config, `NOTICE`,
> `LICENSE`, or `REUSE.toml` file was created, edited, or deleted.
>
> **The instruction conflict is moot on the facts.** Direct inspection of the *actual* checkout
> shows `score/socom/impl/service_identifier.hpp` is **brace-balanced** and line 39 is **empty**
> (§2). There is no unmatched closing brace to remove. Deleting a brace that does not exist, or
> re-introducing the historical split form, would at best be a no-op and at worst a regression.
> The five present candidate source paths and the un-merged test file are already in the drafted
> state; nothing needed a source write, and the write boundary forbade one in any case. All prior
> reports were read and preserved unchanged.
>
> **Non-satisfaction rule applied throughout.** A successful obligation-collection node means the
> results were **retained**, not that the checks **passed**. Missing tools, unknown applicability,
> incomplete extraction, an inactive/draft rule mapping, and unanswered human reviews are **not**
> treated as satisfied. A tool that produced **no** finding because it **did not run** is recorded
> as *"not run"*, never as *"clean"*. No AI-authored report and no green focused run counts as
> human approval.

---

## 1. Scope, binding, and sources read

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` | `.llm_tmp/context/issue-snapshot.json:2-4` |
| Title | *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:3` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG`, created/updated `2026-04-14T13:23:24Z` | `.llm_tmp/context/issue-snapshot.json:8,19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**. It distinguishes *service-instance identifier* = `service id + major + minor +
instance id`; *service identifier* = `service id + major`; *FindService* = `service id + major +
optional<minor> + optional<instance>`; and proposes to "exclude the minor version and make it a
property of the service instance". There is **no comment and no acceptance record**, so none of it
is binding.

### 1.2 Bounded candidate paths (the only writable source paths)

From `.llm_tmp/context/candidate-files.json`:

1. `score/socom/BUILD` (baseline blob `3477ea08…`)
2. `score/socom/impl/service_identifier.cpp` (baseline blob `6c7e7a4e…`)
3. `score/socom/impl/service_identifier.hpp` (baseline blob `c8bae790…`)
4. `score/socom/test/unit/BUILD` (baseline blob `3c03a7b1…`)
5. `score/socom/test/unit/runtime_tests.cpp` (baseline blob `8ecf5ab7…`)
6. `score/socom/test/unit/service_identifier_tests.cpp` — baseline blob **`null`**; the manifest
   expects a **new** file (the un-merged working-tree file, referred to in the task as the
   "cancelled draft").

`glob **/service_identifier.hpp` returns exactly one path, so there is no second,
differently-braced copy in this checkout. `glob **/*.{orig,rej,bak}`-style leftovers were not
found by the prior reports; no such file is present here.

### 1.3 Pinned obligation sources and authority

All nine entries of `.llm_tmp/context/obligations/source-index.json` are present together with
`authority.json`. Every entry is pinned `"native_acceptance": "not_inferred"` — pinned, but its
applicability to this slice is **not inferred**.

| id | status note |
|----|-------------|
| `coding_guidelines` | `:status: valid`; MISRA C++:2023 with C++17; `score::Result` error model |
| `code_analysis` | `:status: valid`; clang-tidy + GCC/Clang warnings + Coverity; sanitizers; gcov/gcovr |
| `misra_mapping` | **`:status: draft`** — rule table commented out; **no rule applicability asserted** |
| `verification_plan` | `:status: valid`; quality criteria 1–9 (criterion 9 = freedom from compiler warnings & errors, 100 %) |
| `development_plan` | `:status: valid`; C++17, GCC host compiler, QCC target, Bazel |
| `tool_management` | `:status: valid`; tools identified → evaluated → qualified → released/rejected by a human |
| `verification_process` | `:status: valid`; `gd_req__verification_link_tests(_cpp)`, `_independence`, `_checks(_extended)`, `_external_aou`, `_sca_classification` |
| `verification_guideline` | `:status: valid`; traceability, independence, documented results |
| `inspection_checklist` | **`:status: draft`** — blank IMPL_01_01…IMPL_03_02 template |

**Authority record** (`.llm_tmp/context/obligations/authority.json`):
`engineering_acceptance: pending`; `human_reviews: unanswered`; `safety_class: unknown`;
`codeql_scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload"`; instruction
*"Restart the failed queue for one complete pass through all obligations"*.

### 1.4 Prior reports read and preserved

`.llm_tmp/overnight/reports/` was read (not modified): `analyzer_plan.md`, `api_review.md`,
`bazel_plan.md`, `callsites.md`, `compatibility.md`, `concurrency_review.md`, `conversion_tests.md`,
`coverage_review.md`, `coverage_tests_repair.md`, `cross_target_review.md`,
`design_inspection_draft.md`, `deviation_drafts.md`, `evidence_inventory.md`,
`finding_classification.md`, `independent_review_handoff.md`, `integration_aou_review.md`,
`invariants.md`, `key_fix.md`, `lifetime_review.md`, `lifetime_tests.md`, `misra_applicability.md`,
`misra_manual_review.md`, `native_build_review.md`, `ordering_tests.md`, `performance_review.md`,
`reproducer.md`, `runtime_disabled.md`, `runtime_enabled.md`, `sanitizer_review.md`, `scope.md`,
`security_review.md`, `test_metadata.md`, `tool_assurance_review.md`, `tool_findings_repair.md`,
`traceability_review.md`, `unit_matrix.md`, `verification_report_draft.md`. This packet adds
`review_packet.md`; nothing was overwritten. Prior reports under
`.llm_tmp/overnight/prior-reports/` and host artifacts under `.llm_tmp/overnight/validation/` and
`.llm_tmp/overnight/obligations/` were read only and preserved.

### 1.5 Host validation and obligation-collection artifacts (present, read)

- `.llm_tmp/overnight/validation/check-result` = `0`; `measurement.json` (`origin:
  local_unprotected_measurement`, `initiator: Fabro host hook`, `mode: ubsan`, `engineering_acceptance:
  pending`, `full_native_tests: not_executed`, `check_ref: check_conversion_tests`, compiler
  `/usr/bin/x86_64-linux-gnu-g++-12`). `baseline_with_agent_tests` = **85 tests / 28 failures /
  compile exit 0**; `candidate` = **85 tests / 0 failures / compile exit 0**. `before.json` = 85/28;
  `after.json` = 85/0 (all in `ServiceInstanceIdentifierTest`). `after-compile.stderr` is empty;
  compile exit 0.
- `.llm_tmp/overnight/obligations/*/result.json` — **25** checks retained. Representative statuses
  are cited in §4.2. Per the task rule, **retention ≠ passing**.

---

## 2. The recorded GCC syntax failure — inspection of the actual source

### 2.1 Finding (direct `read_file` + `grep` this iteration)

`score/socom/impl/service_identifier.hpp` is **brace-balanced**. It is 40 lines; `grep '[{}]'`
returns exactly four brace-bearing lines and `grep 'namespace'` returns exactly two:

| Line | Content | Role |
|------|---------|------|
| 14 | `#ifndef SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard begin |
| 17 | `#include "score/socom/service_interface_identifier.hpp"` | include |
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 21–28 | doc comment | states `minor` is intentionally not part of the identity |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 30–31 | `Service_interface_identifier interface;` / `Service_instance instance;` | members |
| 32 | `};` | closes the struct |
| 34–36 | `/// \cond` / `bool operator<(…)` / `/// \endcond` | the single operator declaration |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`) and two closers (`:32`, `:38`) give net brace balance `0`. There is
**no third, unmatched closing brace**, and line 39 contains no text. The sibling
`impl/service_identifier.cpp` uses the same nested form (brace lines `:18`, `:20`, `:30`, `:32`).
`impl/runtime_impl.hpp` uses the split `namespace score { namespace socom {` form
(`:32-33` / `:232-233`), which is the style the earliest prior reports quoted for the *old*
`service_identifier.hpp` state.

### 2.2 Disposition

The described defect is a **stale, pre-correction description**. It matches the earliest prior
reports, which quote lines 38–39 as the old split form `}  // namespace socom` + `}  // namespace
score`. The `reproducer` iteration applied the correction and left line 39 blank, which is what the
actual source shows today. **No correction was applied and none is required.** The minimal
historical repair is retained in §2.3 for reference only.

### 2.3 Minimal historical repair (reference only; NOT applied)

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

Applying this to the already-balanced file would be a no-op; deleting a brace would *create* the
reported defect.

### 2.4 Independent corroboration (retained, not re-measured here)

- `.llm_tmp/overnight/validation/after-compile.command.json` compiles
  `score/socom/impl/service_identifier.cpp` (which includes this header) with
  `g++-12 -std=c++17 -Wall -Wextra -Werror`; `exit 0`, `after-compile.stderr` empty.
- `.llm_tmp/overnight/obligations/compiler_diagnostics/result.json`: `gcc-compile` **exit 0**
  (`:238-271`), `gcc-tests` **exit 0** (`:273-293`). The only non-zero compiler result is
  `clang-compile` **exit 1** (`:296-329`), a googletest/libstdc++ `-Wdeprecated-declarations`
  dependency diagnostic reached through `.llm_tmp/googletest/**`, **outside the six candidate
  paths**.

A genuine unmatched brace would have failed every focused GCC compile. These are scoped,
unprotected, focused runs — corroboration, **not** a full native build.

### 2.5 Why it would matter if present

The header is compiled into `//score/socom:socom` (`score/socom/BUILD`, whose `srcs` glob selects
`impl/**`) and re-exposed to `//score/socom/test/unit` only through the `testonly` library
`impl_service_identifier`. A syntax error would fail that library and the whole `socom_test`
target, contradicting quality criterion 9 (`verification_plan.rst`). It is not a blocker in the
current tree; that is a static brace-balance reading corroborated by focused compiles, **not** a
full native criterion-9 measurement.

---

## 3. Changed paths and current state of the bounded slice

### 3.1 This iteration

**Wrote exactly one file — this report.** No candidate source path was changed. Reason: the
recorded syntax defect is absent (§2) and the draft's key correction and tests are already present
(§3.2), so the smallest correct change was **no change**; independently, the explicit write
boundary ("only that report may be written") forbade a source write.

### 3.2 State of the six candidate paths (direct readings)

| Candidate path | Current state | This iteration |
|----------------|---------------|----------------|
| `score/socom/impl/service_identifier.hpp` | brace-balanced, 40 lines, nested namespace; line 39 empty; documents minor exclusion (`:21-28`) | unchanged (verified) |
| `score/socom/impl/service_identifier.cpp` | `operator<` orders by `(instance, service id, major)`, `minor` excluded (`:28-29`); explanatory comment (`:21-27`) | unchanged |
| `score/socom/BUILD` | `socom` library + `testonly` `impl_service_identifier` exposure present | unchanged |
| `score/socom/test/unit/BUILD` | `socom_test` globs `*.cpp`; deps wired | unchanged |
| `score/socom/test/unit/runtime_tests.cpp` | 33 test macros = 1 `TEST` + 31 `TEST_F` + 1 `TEST_P`; minor-only duplicate regression at `:402-431`; metadata helper `:264-267` | unchanged |
| `score/socom/test/unit/service_identifier_tests.cpp` | **87 `TEST_F`** under `ServiceInstanceIdentifierTest` (`:168`…`:2012`); `SetUp()` records `DerivationTechnique` + `Description` (`:42-65`) | unchanged |

Key facts (source-derived):

- **Key identity is `(instance, service id, major)`; `minor` is excluded.** `std::set` uniqueness is
  `!(a<b) && !(b<a)`.
- **Record index ignores `minor`.** `Service_database` groups by `id + major` via
  `Minor_version_ignoring_key_equal` / `Minor_version_ignoring_hash`
  (`score/socom/impl/runtime_impl.hpp`). The removed gap (invariant I-11): on the baseline key
  (`minor` included) two connectors sharing `id + major + instance` but differing only in `minor`
  both passed the duplicate gate but resolved to the same `Service_record`, reaching
  `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)` on enable. The working-tree key is now as coarse as
  the record index, so the second registration is rejected as
  `Construction_error::duplicate_service` at the key insert.
- **Compatibility rules are separate from identity and unchanged.** Exact-major and
  `client.minor <= server.minor` remain in `is_interface_compatible` / `is_minor_version_compatible`
  (`runtime_impl.cpp`), not in the key. The public `Service_interface_identifier` type remains
  minor-aware.
- **No `operator==`/`std::hash` for the key**; `operator<` remains the single ordering rule. The key
  is `impl/`-only via the `testonly` library.

### 3.3 Wider #84 items deliberately out of this bounded slice

Public `Service_interface_identifier` restructure / moving `minor` onto `Service_instance`,
FindService wildcard (`major = FF`) handling, and the config `0xFFFFFFFF` minor narrowing. These
remain deferred and are not implemented here.

---

## 4. Test outcomes (retained evidence; scope-limited)

> **Scope caveat carried through this section.** Every retained code measurement compiles only the
> focused identifier translation unit (`service_identifier.cpp` + `string_registry.cpp` +
> `service_identifier_tests.cpp` + vendored googletest). **`runtime_tests.cpp` is not compiled or
> executed by any retained artifact.** The retained measurement executed **85** cases while the
> current `service_identifier_tests.cpp` has **87** `TEST_F`, so even the identifier measurement is
> **stale by two cases**.

### 4.1 Host validation (`.llm_tmp/overnight/validation/`)

| Artifact | Result | Limit |
|----------|--------|-------|
| `measurement.json` (`check_conversion_tests`, `mode: ubsan`) | `baseline_with_agent_tests` 85 tests / 28 failures / compile 0; `candidate` 85 tests / 0 failures / compile 0 | focused identifier TU; stale by two cases; never Bazel/native; `full_native_tests: not_executed` |
| `before.json` / `after.json` | 85/28 red baseline (minor-aware key) → 85/0 green candidate | same scope/staleness |
| `after-compile.stderr` | empty; compile exit 0 | focused TU only |
| `check-result` | `0` | collector success marker only |

### 4.2 Obligation-collection results (`25` retained; retention ≠ passing)

| Check | Retained status | Reading |
|-------|-----------------|---------|
| `compiler_diagnostics` | `findings_or_execution_failure`; `gcc-compile` exit 0, `gcc-tests` exit 0; **`clang-compile` exit 1** | Clang branch of criterion 9 blocked by a googletest/libstdc++ `-Wdeprecated-declarations` dependency; focused scope |
| `focused_coverage` | `completed`; line **36/36 = 100 %**, branch **11/14 = 78.6 %**; `complete_target_scope: false`; `safety_class: unknown_requires_authorized_selection` | **branch below both platform goals** (QM 85 / safety 100); no deviation accepted |
| `focused_asan_lsan` | `completed`; ASan/LSan/UBSan exit 0 | focused single-threaded identifier scope only |
| `focused_tsan` | `findings_or_execution_failure`; tests exit `-11` (SIGSEGV) | environment failure; **not** a clean race result |
| `focused_memcheck` | `findings_or_execution_failure`; exit 127 | `valgrind` unavailable |
| `focused_cppcheck` | `findings_or_execution_failure`; exit 2; `passedByValue` findings | locations in headers **outside** the candidate paths |
| `focused_clang_tidy` | `findings_or_execution_failure`; `--verify-config` exit 1 (unknown checks) | **no analysis ran → "not run", never "clean"** |
| `codeql_security` | `findings_or_execution_failure`; findings under `.llm_tmp/googletest/**`; `level: null` | focused linked executable; dependency-only |
| `codeql_misra` | `findings_or_execution_failure`; dominated by googletest / gtest `TEST_F` macro expansion and out-of-slice files; `level: null` | mapping `:status: draft`; **no MISRA compliance claim possible** |
| `native_build`, `native_tests`, `native_coverage`, `native_lint`, `native_sanitizers`, `native_tsan`, `native_integration`, `native_docs`, `native_performance`, `native_traceability`, `cross_compilation`, `format_precommit` | `findings_or_execution_failure`; **exit 127** (`[Errno 2] … '/tmp/s-core-001/bin/bazel'`; some tools absent) | **no native build/test/coverage/QEMU/cross/trace/format run** |
| `secret_dependency_checks` | `findings_or_execution_failure`; gitleaks exit 127; 29-dep inventory + `lock_sha256 c90b245b…`; blocker "dependency inventory is not a vulnerability scan" | secret scan **not run**; no CVE mapping |
| `tool_assurance` | retained; `bazel`, `valgrind`, `gitleaks`, `clang-format`, `pre-commit`, `reuse` unavailable | tool execution ≠ qualification |
| `process_checks` | `completed_with_blockers`; blockers: lexical inventory cannot prove semantic requirement coverage; safety/QM applicability and approved tailoring unknown; independent inspection/acceptance required; external AoU and full integration verification require scoped review | directly names this human gate |
| `rework_progress` | `completed`; `source_changed_this_round: true`; `rework_requested: false`; stop reason *"One complete pass requested; unresolved findings stay pending"* | one pass; nothing resolved |

### 4.3 Test inventory (read, not run here)

- `score/socom/test/unit/service_identifier_tests.cpp`: **87 `TEST_F`** under
  `ServiceInstanceIdentifierTest` (`:168`…`:2012`), including the minor-collapse cases
  (`KeysDifferingOnlyInMinorVersionAreDuplicates` `:174`, `MinorVersionBoundariesAreDuplicates`
  `:182`, `AllMinorVersionsCollapseToSingleKey` `:192`, `MinorHighBitVariantsAreEquivalent` `:203`,
  `MinorVersionNeverAffectsOrdering` `:430`, `SetFindLocatesMinorVariantAndCountsItOnce` `:1034`,
  `StdSetCollapsesFiveMinorVariantsOfEveryIdentity` `:1321`) plus strict-weak-ordering and
  equivalence property checks over deterministic domains.
- `score/socom/test/unit/runtime_tests.cpp`: 33 macros (1 `TEST` + 31 `TEST_F` + 1 `TEST_P`),
  including `ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError` (`:402-431`)
  which drives the real `Runtime::make_server_connector()` path and expects
  `Construction_error::duplicate_service` for a second registration differing only in `minor`.
- Both suites were executed green **only in focused host/collector runs** (GCC 87/0 per
  `compiler_diagnostics`; ASan/LSan/UBSan exit 0). `runtime_tests.cpp` has **never** been compiled
  or executed by any retained artifact. The host `measurement.json` executed the earlier 85-case
  state.

---

## 5. Known limits

1. **No native build/test has run.** `bazel` is missing (`/tmp/s-core-001/bin/bazel` absent), so all
   `native_*`, `cross_compilation`, QEMU integration, docs, traceability, performance and
   format/pre-commit legs exited 127. No Bazel target (`//score/socom/test/unit:socom_test`,
   `//score/...`) was built or tested in this checkout.
2. **`runtime_tests.cpp` is unexecuted.** The runtime-level minor-only regression and the
   slot-isolation/lifetime cases are source-only in this checkout.
3. **The retained identifier measurement is stale and scoped:** 85 executed vs 87 on disk; focused
   translation unit only; not a platform or interface test.
4. **Branch coverage is below goal:** 11/14 = 78.6 % vs QM 85 % / safety 100 %; no deviation
   accepted; `safety_class` unknown, so no goal level is even selectable yet.
5. **Clang leg blocked** by a dependency deprecation; **clang-tidy did not run** (config rejected);
   **cppcheck findings are out of scope**; **CodeQL is focused/dependency-only**; **TSan did not
   produce a usable result** (SIGSEGV); **memcheck, gitleaks, clang-format, pre-commit, reuse are
   unavailable**. None of these may be reported as clean.
6. **MISRA C++:2023 compliance is unknown/not claimed** — `misra_mapping.rst` is `:status: draft`;
   no numbered rule is asserted to apply.
7. **Traceability is incomplete** — no `comp_req__socom__*` and no `:reqtype: Interface` need
   exists; `TestType` and the `PartiallyVerifies`/`FullyVerifies` links are deliberately unset
   because inventing identifiers is prohibited.
8. **Tool qualification is not established** (missing tools; collector-vs-pin version drift; no Tool
   Verification Report).
9. **No safety classification, SCA finding classification, risk acceptance, deviation, or FMEA/DFA
   disposition exists.**
10. **All human reviews are unanswered**; the author/reviewer/approver roles are unfilled.

---

## 6. Unanswered engineering decisions

These are decisions only a named authorized human may make; they are recorded, not answered.

### 6.1 Bounded-slice semantics

1. **Minor in the duplicate key, or not?** The draft excludes `minor` (consistent with
   `Service_database` and #84). If the key must keep `minor`, the `Service_database` index must stop
   ignoring minor (or registration must tolerate replacement) to remove the assert/UB path. Which is
   authoritative?
2. **Two servers, one `id + major + instance`, different minor.** Reject as duplicate, let the later
   replace the earlier, or allow both with negotiation? The code cannot express the last option
   (`m_server` is a single `std::optional`).
3. **Status of `ASSERT(!m_server)`.** Genuine invariant (so the duplicate gate must cover every
   collision the record index can produce) or defensive check that should tolerate re-registration?
4. **Scope of the #84 restructure.** Introduce `Service_identifier = id + major` plus
   minor-as-instance-property (public API change), or keep `Service_interface_identifier{major,
   minor}` and only fix the internal key? This packet assumes the latter.
5. **Version widths and wildcard.** socom uses `uint16` major/minor; the SOME/IP config declares
   `service_version_major: uint8` and `service_version_minor: uint32 = 0xFFFFFFFF`, narrowed by
   unchecked `static_cast<uint16_t>` at several sites. Under the coarsened key, a wildcard-derived
   `0xFFFF` server and a concrete-minor server now collide. How is the wildcard mapped?
6. **Ordering vs identity.** Is a total order (`operator<`) meaningful here, or should the internal
   key be an equality/hash key?
7. **Error semantics.** Should a minor-only collision report `duplicate_service`, or a more specific
   error? The `error.hpp` comment ("Service identifier already exists") is narrower than the key.
8. **Documentation/contract.** `Runtime::make_server_connector`'s doc says duplicates are judged by
   "the configuration.interface and instance parameters", but public `operator==` includes `minor`
   while the key does not. Authorize a documentation correction?
9. **Design-doc traceability.** No design element in `score/socom/docs/design/` records the key,
   its minor-excluding identity, or duplicate rejection. Is intentionally-undocumented acceptable?
10. **Runtime regression acceptance.** Confirm the minor-only duplicate regression and the
    slot-isolation/lifetime cases are wanted, and that the public
    `Runtime::make_server_connector()` path is acceptable.

### 6.2 Process and role gates

- **Author/approver separation** (`gd_req__verification_independence`): approver must differ from
  author; all roles are **unfilled**.
- **Safety classification / ASIL-QM selection** (safety manager + project lead): **unanswered**.
- **Security assessment acceptance** (security manager): **unanswered**.
- **SCA finding classification Critical/High/Medium/Low** (quality manager + committer): **unanswered**.
- **Implementation inspection IMPL_01_01…IMPL_03_02** (content responsible + reviewer + moderator):
  **unfilled** (checklist is a blank draft).
- **Tool impact / error-detection / TCL + qualification** and **Tool Verification Report
  released/rejected**: **unanswered / pending**.
- **Deviation / false-positive register** (DD-1…DD-9, FP-1 in `independent_review_handoff.md`,
  including the stale "extra `}` at `service_identifier.hpp:39`" item FP-1): **draft / not accepted**.
- **Requirement/interface links and `TestType`** (requirements owner + reviewer + committer):
  **unanswered**; no `comp_req__socom__*` or interface need exists.
- **Integration/release decision** against quality criteria 1–9 (project lead + quality manager):
  **not taken** (branch shortfall and unexecuted runtime suite noted).
- **Instruction conflict** ("inspect and correct the actual source" vs. "only that report may be
  written"): **unanswered**; this packet resolved it by reporting only, on the facts that the source
  is already correct and the write boundary forbids a source write.

---

## 7. Pending human review checklist

- [ ] **Confirm §2:** `service_identifier.hpp` is brace-balanced (braces at `:19`, `:29`, `:32`,
      `:38`; line 39 empty; net balance 0). The recorded "extra closing brace at line 39" is stale or
      refers to a different revision; confirm no source correction is required in this checkout.
- [ ] **Resolve the instruction conflict** (correct-source vs. report-only) and confirm that
      inspection-only was the intended outcome given the source is already correct.
- [ ] **Confirm the bounded key decision:** `minor` is **not** part of the duplicate-server
      registration key (identity `(instance, service id, major)`); the public interface and the
      exact-major / minimum-minor rules are unchanged.
- [ ] **Confirm `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)`** is the authoritative single-server
      invariant, so the key must be at least as coarse as the record index.
- [ ] **Confirm the test coverage** (87 key `TEST_F`; 33 runtime macros) and that identifier/key
      tests are **not** platform validation and no fuzzy technique is claimed.
- [ ] **Supply native requirement/interface identifiers** (no invented links) or record approved
      tailoring; complete `TestType`/`DerivationTechnique`/`Description` per
      `gd_req__verification_link_tests_cpp`.
- [ ] **Restore tools and run the full native suite** (`bazel build //score/...`,
      `bazel test //score/...`, `bazel test //score/socom/test/unit:socom_test`), including
      `runtime_tests.cpp`; refresh the stale focused measurement.
- [ ] **Run the focused key and runtime regressions**:
      `--test_filter='ServiceInstanceIdentifierTest.*'` and
      `--test_filter='RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError'`.
- [ ] **Complete the MISRA mapping / inspection checklist / SCA classification / tool qualification**
      and the deviation register as authorized humans.
- [ ] **Select a safety class, assign the independent reviewer/approver (≠ author), record
      engineering acceptance, and take the release decision.** Do not upload (codeql_scope: no
      upload).

---

## 8. Notice preservation

- Only this report was written. No source, build, test, config, `NOTICE`, `LICENSE`, or
  `REUSE.toml` file was created, edited, or deleted.
- The flagged header `score/socom/impl/service_identifier.hpp` was inspected and left unchanged
  because it is already brace-balanced and well-formed; it retains its Apache-2.0/SPDX header
  (`:1-12`). The sibling `service_identifier.cpp`, both `BUILD` files, and both candidate test files
  retain their Apache-2.0/SPDX headers.
- All prior reports under `.llm_tmp/overnight/prior-reports/`, all earlier files under
  `.llm_tmp/overnight/reports/`, and all host/obligation artifacts under
  `.llm_tmp/overnight/validation/` and `.llm_tmp/overnight/obligations/` were read only and are
  preserved unchanged.
- This report itself carries the Apache-2.0 header.
- No licensed MISRA rule text is reproduced; only native rule/query identifiers, source hashes, and
  file locations are cited.

---

## 9. What this packet explicitly does NOT claim

- No engineering acceptance, review approval, publication, or upload.
- No MISRA C++:2023 compliance and no assertion that any numbered rule applies (mapping is draft).
- No safety-class / ASIL / QM selection, no FMEA/DFA acceptance, no risk acceptance, no deviation.
- No claim that identifier-only / key-level tests are platform, feature, or interface validation,
  and no fuzzy-testing claim.
- No invented native requirement or interface identifiers.
- No claim that clang-tidy, the native Bazel suite, TSan, memcheck, clang-format, pre-commit, reuse,
  gitleaks, QEMU integration, cross-compilation, coverage-to-goal, or the docs/traceability gate
  passed — each is blocked, failed, or did not run.
- No statement that the wider #84 public `Service_interface_identifier` restructure, FindService
  wildcard handling, or config minor-wildcard narrowing is in scope.

---

*End of review packet. Local, unprotected, scoped. No engineering acceptance; human reviews
unanswered; full native runtime tests pending; no MISRA compliance, safety classification, tool
qualification, deviation, or risk acceptance is claimed, and this packet does not act as the
independent reviewer.*
