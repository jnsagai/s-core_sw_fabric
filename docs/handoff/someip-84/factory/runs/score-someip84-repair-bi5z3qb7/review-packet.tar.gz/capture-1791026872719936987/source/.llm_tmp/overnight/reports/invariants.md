<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — duplicate-server registration-key invariants derived from source (review draft)

**Document type:** review draft — actual-source inspection + source-derived registration-key
invariants + explicit separation of unaccepted public-interface proposals + obligations status.

**Date:** 2026-10-03
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling inside *Revise version handling in
socom* (issue #84)
**Run / branch:** `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ`; HEAD `b7d55bb`
(`fabro(01M3ZRSDK2XQAF1H48VWTPKQNZ): start (success)`). Completed stages in this run:
`node_3752dc1af9e2f3b0ee1454f2` (success) and `node_51f7ccb6b2715b106cf242f4` (success).
**Verified baseline commit:** `f8a196c3b16d5172d898394ab99b0ed81346d63d`
(`.llm_tmp/context/source-manifest.json:3`).
**Status:** **local, unprotected, scoped.** No engineering acceptance exists. Human reviews are
unanswered. Full native runtime tests are pending. Nothing in this document is acceptance, review,
publication, or a full native run.

> **Tool / write boundary observed.** This iteration used only `read_file`, `grep`, `glob`, and
> `write_file`. No `shell`, no `edit_file`, no delegation, no web access, no approval, no publishing,
> and no engineering acceptance was performed. The task text says to *"Inspect and correct the actual
> source before expanding tests"*, while its explicit, more specific final sentence says *"This is a
> review draft: only that report may be written."* Following that explicit write boundary, **exactly
> one file was written — this report** (`/workspace/.llm_tmp/overnight/reports/invariants.md`). No
> source, build, test, config, `NOTICE`, `LICENSE`, `REUSE.toml`, or prior-report file was created,
> edited, or deleted, and no test was expanded. All prior reports were read and preserved.
>
> **The conflict is moot on the facts: the described syntax failure is NOT present in the actual
> source.** The task records *"a measured GCC syntax failure: an extra closing brace in
> `score/socom/impl/service_identifier.hpp` at line 39."* Direct `read_file` on the current working
> tree (§2) shows the header is **already brace-balanced**: the only brace-bearing lines are `:19`
> (`namespace score::socom {`) and `:29` (`struct Service_instance_identifier final {`) as openers,
> and `:32` (`};`) and `:38` (`}  // namespace score::socom`) as closers. Line `:39` is **blank**;
> line `:40` is `#endif`. Two openers, two closers, net balance `0`; there is no third, unmatched
> closing brace, so there is **no actual source to correct**. Applying a repair to an already-balanced
> file would be a no-op at best and a regression at worst. The write boundary forbade a source write
> in any case, and `edit_file` is not in the permitted tool set. No test was expanded because the
> draft's suites already exist on disk (§4, §8).
>
> **Non-satisfaction rule applied throughout.** A successful obligation-collection node means results
> were **retained**, not that checks **passed**. Missing tools, unknown applicability, incomplete
> extraction, a draft rule mapping, an inactive mapping, and unanswered human reviews are **not**
> treated as satisfied. A tool that produced **no** finding because it **did not run** is recorded as
> *"not run"*, never as *"clean"*. Every unexecuted applicable check and every unaccepted deviation
> remains a **blocker** (§7, §8).

---

## 0. Summary

1. **Recorded syntax failure re-inspected; not present in the actual source.** The flagged header is
   brace-balanced (braces only at `:19`, `:29`, `:32`, `:38`; line `:39` blank; `:40` `#endif`). No
   source correction was applied — none is required, and the write boundary forbids source writes.
   The described defect is a **stale, pre-correction description** consistent with the earliest prior
   reports; the `reproducer` iteration already records the header as balanced (§2).
2. **Existing registration-key invariants re-derived from the actual source (§4).** Fifteen
   invariants R-1 … R-15 are stated with source evidence, a falsifier, and a working-tree/baseline
   contrast. The duplicate key is
   `Service_instance_identifier { Service_interface_identifier interface; Service_instance instance; }`.
   Its only operator, `operator<`, orders by `(instance, service id, major)`, so on this working tree
   the **minor version is not part of the key identity**
   (`score/socom/impl/service_identifier.cpp:28-29`), matching the deliberately minor-ignoring
   `Service_database` record index (`score/socom/impl/runtime_impl.hpp:116-134`).
3. **The minor-excluding key is the working-tree draft, not accepted baseline behaviour.** The
   committed baseline is reported by `prior-reports/invariants.md` I-4 (a per-run record; the baseline
   blob is not re-readable here) to have ordered by `std::tie(lhs.instance, lhs.interface)`, i.e. with
   `minor` **included**. Neither the draft change nor the wider issue #84 restructure is accepted
   (§5).
4. **Issue #84's public-interface proposal is neither implemented nor accepted (§5).** "service
   identifier = `id + major`", moving `minor` onto the service instance, FindService
   `optional<minor>`/`optional<instance>`, and the `major = FF` wildcard are **proposals only**. The
   public `Service_interface_identifier{Id id; Version{major, minor}}` type is unchanged, and the
   full version is still used by its ordering/hash and by the IPC key (R-13).
5. **Draft tests exist but are not natively run here (§4, §8).** `service_identifier_tests.cpp` has
   **87 `TEST_F`** under `ServiceInstanceIdentifierTest` (`:168`…`:2012`, verified this iteration by
   `grep`); `runtime_tests.cpp` has **33 macros** (1 `TEST` + 31 `TEST_F` + 1 `TEST_P`,
   `:239`…`:1311`), including the minor-only duplicate regression `:402-431`. `runtime_tests.cpp`
   has **never** been compiled or executed by any artifact available in this checkout.
6. **No obligation is satisfied (§7).** No build, no test ran here. Pinned entries are
   `native_acceptance: not_inferred`; `authority.json` records `engineering_acceptance: pending`,
   `human_reviews: unanswered`, `safety_class: unknown`. `.llm_tmp/overnight/validation/` and
   `.llm_tmp/overnight/**/result.json` are **absent from this checkout**; prior reports only *retain
   summaries* of them, which is retention, not passing.

---

## 1. Binding to the baseline, issue, prior reports, host feedback, and obligations

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` | `.llm_tmp/context/issue-snapshot.json:2-4` |
| Title | *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:3` |
| State | `open`, **0 comments**, no milestone / assignee / labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` (unchanged) | `.llm_tmp/context/issue-snapshot.json:19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**. It distinguishes three use cases — *service-instance identifier* =
`service id + major + minor + instance id`; *service identifier* = `service id + major`; *FindService*
= `service id + major + optional<minor> + optional<instance>` — and proposes to *"exclude the minor
version and make it a property of the service instance to be able to better compare and index
compatible service instances."* It notes the FindService `major = FF` AUTOSAR case as theoretically
possible but not useful. There is **no comment and no acceptance record** in the snapshot, so none of
the proposal is binding. Binding is **by baseline commit**, not by run HEAD.

### 1.2 Verified baseline and current tree

| Item | Value | Source |
|------|-------|--------|
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |
| Current branch | `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ` | run environment |
| Current HEAD | `b7d55bb` — `fabro(01M3ZRSDK2XQAF1H48VWTPKQNZ): start (success)` | run environment |
| Completed stages | `node_3752dc1af9e2f3b0ee1454f2`, `node_51f7ccb6b2715b106cf242f4` | task context |

Binding is **by baseline commit `f8a196c3…`**, not by run HEAD. Earlier reports reference other run
IDs on the same baseline commit (`01M3YRJEGXNY6CB81T7TKW774B`, `01M3YGTGYFEN406VDEVVTJTRWV`,
`01M3XZAQ65TTE35XSGXC4JAMAH`, and others), so they describe the same baseline and remain admissible
prior evidence for this slice. The candidate-set hashes in `.llm_tmp/context/candidate-files.json` and
those quoted by the prior reports differ from each other (prior reports record tool-measured
post-rework hashes); no hashing tool is available in this task, so the current working tree was
**not** re-hashed. The direct source reads in §2–§4 are authoritative for this report.

### 1.3 In-scope candidate files (`.llm_tmp/context/candidate-files.json`)

| File (repo-relative) | Baseline git blob | Baseline present | Current working tree (read this iteration) |
|----------------------|-------------------|------------------|--------------------------------------------|
| `score/socom/BUILD` | `3477ea0851fdcd82ec6ea9d71424013cbdf41962` | yes | `headers` glob `*.hpp` `:17-22`; `socom` lib `:24-41`; `testonly` `impl_service_identifier` exposure `:46-54` |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e22355242009fe20dada2a9a0d0c7a9c7` | yes | key identity `(instance, service id, major)`; `minor` excluded (`:28-29`) |
| `score/socom/impl/service_identifier.hpp` | `c8bae7908da9f087c518934f7b9f8d86db9a20ec` | yes | **brace-balanced**, 40 lines; line `:39` blank (§2) |
| `score/socom/test/unit/BUILD` | `3c03a7b14286051f97fa5022206564bd63645171` | yes | `socom_test` globs `*.cpp`; deps wired (`:16-29`) |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab726db8bf994c960045d6fd7fdf84d7395` | yes | **33 macros** (1 `TEST` + 31 `TEST_F` + 1 `TEST_P`); minor-only regression `:402-431` |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(none — `null`)* | **no** (manifest expects a **new** file) | **87 `TEST_F`** matrix; `SetUp()` metadata `:42-65` |

The `null` baseline blob is the manifest's expectation of a **new** unit-test file; it exists on disk
only in the un-merged working tree (the task's *"cancelled draft"*), never in the baseline. The five
present baseline blobs also appear in the `files` array of `.llm_tmp/context/source-manifest.json`,
binding the candidate set to the baseline commit. `glob **/service_identifier*` returns exactly the
three paths (`impl/service_identifier.cpp`, `impl/service_identifier.hpp`,
`test/unit/service_identifier_tests.cpp`), so there is **no second, differently-braced copy** of the
header in this checkout.

### 1.4 Pinned obligation sources and authority (all read this iteration)

All nine entries of `.llm_tmp/context/obligations/source-index.json` were read from
`.llm_tmp/context/obligations/`, together with `authority.json`. Every entry is pinned
`"native_acceptance": "not_inferred"` — pinned, but its applicability to this slice is **not
inferred**. The `:status:`/`:safety:` attributes were re-read this iteration:

| id | file | status / safety (re-read) |
|----|------|---------------------------|
| `coding_guidelines` | `coding_guidelines.rst` | `:status: valid` (`:20`), `:safety: ASIL_B` (`:22`); MISRA C++:2023 with C++17 |
| `code_analysis` | `code_analysis.rst` | `:status: valid` (`:20`), `:safety: ASIL_B` (`:22`); clang-tidy + gcc/clang warnings + Coverity; sanitizers; gcov/gcovr |
| `misra_mapping` | `misra_mapping.rst` | **`:status: draft`** (`:20`), `:safety: ASIL_B` (`:22`); the rule table is not a valid obligation |
| `verification_plan` | `verification_plan.rst` | `:status: valid` (`:17`), `:safety: ASIL_B` (`:19`); quality criteria incl. freedom from compiler warnings & errors |
| `development_plan` | `development_plan.rst` | `:status: valid` (`:21`), `:safety: ASIL_B` (`:23`); C++17, GCC host compiler, QCC target, Bazel |
| `tool_management` | `tool_management.rst` | `:status: valid` (`:17`), `:safety: ASIL_B` (`:19`); tools identified / evaluated / qualified / released-or-rejected by a human |
| `verification_process` | `verification_process.rst` | `:status: valid` (`:22`); `gd_req__verification_link_tests` (`:21`), `_link_tests_cpp` (`:57`), `_independence` (`:142`), `_reporting` (`:155`), `_checks` (`:179`), `_checks_extended` (`:199`), `_external_aou` (`:215`), `_sca_classification` (`:229`), `_ci_reference_execution` (`:251`) |
| `verification_guideline` | `verification_guideline.rst` | `:status: valid` (`:19`); traceability, independence, documented results |
| `inspection_checklist` | `inspection_checklist.rst` | **`:status: draft`** (`:17`), `:safety: ASIL_B` (`:19`); blank `IMPL_01_01`…`IMPL_03_02` template |

**Authority record** (`.llm_tmp/context/obligations/authority.json`):

| Field | Value |
|-------|-------|
| `engineering_acceptance` | **pending** |
| `human_reviews` | **unanswered** |
| `safety_class` | **unknown** |
| `codeql_scope` | `Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload` |
| `instruction` | *"Restart the failed queue for one complete pass through all obligations"* |

**Safety-class note (recorded, not resolved).** The pinned platform documents carry
`:safety: ASIL_B`, while `authority.json` records `safety_class: unknown` and no authorized selection
exists. The document attribute is **not** a selection of the slice's safety class and must not be
inferred as one; the QM-vs-safety goal split remains unselectable until an authorized human decides it.

### 1.5 Prior reports, host feedback, and obligation-collection results available in *this* checkout

- **`.llm_tmp/overnight/prior-reports/` — 38 files present**, all read/cross-checked and preserved:
  `analyzer_plan.md`, `api_review.md`, `bazel_plan.md`, `callsites.md`, `compatibility.md`,
  `concurrency_review.md`, `conversion_tests.md`, `coverage_review.md`, `coverage_tests_repair.md`,
  `cross_target_review.md`, `design_inspection_draft.md`, `deviation_drafts.md`,
  `evidence_inventory.md`, `finding_classification.md`, `independent_review_handoff.md`,
  `integration_aou_review.md`, `invariants.md`, `key_fix.md`, `lifetime_review.md`, `lifetime_tests.md`,
  `misra_applicability.md`, `misra_manual_review.md`, `native_build_review.md`, `ordering_tests.md`,
  `performance_review.md`, `reproducer.md`, `review_packet.md`, `runtime_disabled.md`,
  `runtime_enabled.md`, `sanitizer_review.md`, `scope.md`, `security_review.md`, `test_metadata.md`,
  `tool_assurance_review.md`, `tool_findings_repair.md`, `traceability_review.md`, `unit_matrix.md`,
  `verification_report_draft.md`.
- **`.llm_tmp/overnight/reports/`** held `scope.md` and `callsites.md` before this write; this document
  adds `invariants.md`. Earlier reports call their own `reports/` tree the home of same-named files; in
  this checkout that corpus is physically consolidated under `prior-reports/`.
- **`.llm_tmp/overnight/validation/`** returned **no** `glob` matches (`glob
  .llm_tmp/overnight/**/*` lists no `validation/` entry). The "latest host feedback" is therefore
  **absent from this checkout**. Prior reports record its intended content (`check-result` = `0`;
  `measurement.json` with `origin: local_unprotected_measurement`, `initiator: Fabro host hook`,
  `mode: ubsan`, `engineering_acceptance: pending`, `full_native_tests: not_executed`, compiler
  `/usr/bin/x86_64-linux-gnu-g++-12`; a focused identifier-TU red/green record). **The artifacts
  themselves are not present here**, so this report does not treat any host check as passed.
- **`.llm_tmp/overnight/obligations/*/result.json`** returned **no** `glob` matches; `glob
  **/result.json` across the whole workspace returned **nothing**. The directory is absent from this
  checkout. Prior reports summarize collector rows (focused GCC green; clang blocked on a
  googletest/libstdc++ deprecation; clang-tidy config rejected / not run; branch coverage below goal;
  TSan SIGSEGV; memcheck absent; native/`bazel` legs exit 127/`No space left on device`). Those are
  **readings of missing artifacts**, retained by the reports only; **retention ≠ passing**, and absence
  here is **not** evidence that the checks passed.

### 1.6 Derived sequence of the preserved reports (all on baseline `f8a196c3…`)

`scope.md` (bounded the slice; identified the key/index identity gap) → `invariants.md` (I-1…I-16) →
`callsites.md` → `reproducer.md` (key-level regression, test-only header exposure, and the header
brace correction that left line 39 blank) → `key_fix.md` / `unit_matrix.md` (drop `minor` from the
ordering; expand key tests) → `ordering_tests.md` / `conversion_tests.md` → `runtime_disabled.md`,
`runtime_enabled.md`, `lifetime_tests.md` (runtime regressions, never natively executed) →
`test_metadata.md` → later host-side iterations (`coverage_review.md`, `coverage_tests_repair.md`,
`finding_classification.md`, `misra_applicability.md`, `misra_manual_review.md`,
`tool_findings_repair.md`) → review artifacts (`design_inspection_draft.md`, `deviation_drafts.md`,
`security_review.md`, `tool_assurance_review.md`, `integration_aou_review.md`,
`traceability_review.md`, `evidence_inventory.md`, `independent_review_handoff.md`,
`review_packet.md`, `verification_report_draft.md`). The `repair_unit_matrix.md` and a host addendum
`obligation-addendum.md` are referenced by some reports but are **not present** in this checkout.

---

## 2. The recorded syntax failure: inspection of the actual source

### 2.1 Finding (re-verified this iteration by direct `read_file`)

`score/socom/impl/service_identifier.hpp` is **brace-balanced**. It is exactly 40 lines:

| Line | Content | Role |
|------|---------|------|
| 14 | `#ifndef SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard begin |
| 15 | `#define SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard define |
| 17 | `#include "score/socom/service_interface_identifier.hpp"` | include |
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 21–28 | doc comment | states `minor` is intentionally not part of the identity |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 30 | `Service_interface_identifier interface;` | member |
| 31 | `Service_instance instance;` | member |
| 32 | `};` | closes the struct |
| 34 | `/// \cond` | doc guard |
| 35 | `bool operator<(Service_instance_identifier const& lhs, Service_instance_identifier const& rhs);` | the single operator declaration |
| 36 | `/// \endcond` | doc guard |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`) and two closers (`:32`, `:38`): net brace balance is `0`. There is **no
third, unmatched closing brace**, and line 39 contains no text at all. The sibling
`score/socom/impl/service_identifier.cpp` uses the same nested form (`:18` / `:32`) and is balanced.
The task's *"extra closing brace … at line 39"* therefore matches a **stale, pre-correction
description** — the earliest prior reports quote lines 38–39 as the split-form
`}  // namespace socom` + `}  // namespace score`. The `reproducer` iteration records the correction;
every later prior report records the header as already balanced — which is what the actual source
shows in this checkout today.

### 2.2 Disposition and the write-boundary conflict

**No correction was applied, and none is required.** The instruction's precondition ("inspect and
correct the actual source before expanding tests") is satisfied without a source write: there is
nothing to correct, and the explicit write boundary ("only that report may be written") would have
forbidden the write in any case. If the *"cancelled draft"* is a different revision that still
carries the extra brace, it is **not** the file in this checkout and must be located and corrected by
an authorized iteration; this report records the discrepancy for human disposition rather than
speculating. No test was expanded, because the draft's suites already exist on disk (§4, §8).

### 2.3 Minimal historical repair (reference only; NOT applied)

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

Applying this to the already-balanced file would be a no-op; deleting a brace would *create* the
reported defect.

### 2.4 Why it would matter if present

The header is compiled into `//score/socom:socom` (`score/socom/BUILD:24-41`; its `srcs` globs
`impl/**/*.cpp`, `impl/**/*.hpp`) and re-exposed to `//score/socom/test/unit` through the `testonly`
library `impl_service_identifier` (`score/socom/BUILD:46-54`; consumed at
`score/socom/test/unit/BUILD:24`). A syntax error there would fail the library and the whole
`socom_test` target, contradicting S-CORE quality criterion 9, "Freedom from compiler warnings &
errors, 100 %" (`verification_plan.rst`). It is **not** a blocker in the current tree; that is a
static brace-balance reading, **not** a compile measurement, and no GCC measurement is reproduced
here.

---

## 3. Source of truth for the key (working tree)

All line numbers are readings of the working tree at the baseline-bound candidate paths.

| Artifact | Location |
|----------|----------|
| Key struct `Service_instance_identifier` | `score/socom/impl/service_identifier.hpp:29-32` |
| Struct documentation comment (draft wording) | `score/socom/impl/service_identifier.hpp:21-28` |
| Key `operator<` declaration (only operator; `\cond`-hidden) | `score/socom/impl/service_identifier.hpp:34-36` |
| Key `operator<` definition | `score/socom/impl/service_identifier.cpp:20-30` |
| Ordering rationale comment (draft wording) | `score/socom/impl/service_identifier.cpp:21-27` |
| Set alias / storage | `score/socom/impl/runtime_impl.hpp:56`, `:228-229` |
| Key mutex (`Mutexed_variable`) | `score/socom/impl/runtime_impl.hpp:50-54` |
| Include of the key header | `score/socom/impl/runtime_impl.hpp:30` |
| Key construction / insert / duplicate rejection | `score/socom/impl/runtime_impl.cpp:443`, `:449-454` |
| Erasure final action | `score/socom/impl/runtime_impl.cpp:456-463` |
| Connector construction | `score/socom/impl/runtime_impl.cpp:465-466` |
| Record index (minor-ignoring) | `score/socom/impl/runtime_impl.hpp:116-134`; `runtime_impl.cpp:313-324` |
| Server record registration / single-server assert | `score/socom/impl/runtime_impl.cpp:366-382` (assert `:369`, emplace `:371`) |
| Client record registration / `duplicate_client` | `score/socom/impl/runtime_impl.cpp:384-399` |
| Server / client `register_connector` | `score/socom/impl/runtime_impl.cpp:526-551`, `:492-524` |
| Compatibility predicates | `score/socom/impl/runtime_impl.cpp:133-146` |
| Public `make_server_connector` contract | `score/socom/runtime.hpp:170-178` |
| Error enum | `score/socom/error.hpp:53-58` (`duplicate_service` `:55`) |
| Public identifier type/operators/hash | `score/socom/service_interface_identifier.hpp:28-190` |
| Config version fields (someip) | `score/config/mw_someip_config.fbs` (per prior reports: major `:19`, minor `:23`) |
| Build placement | `score/socom/BUILD:17-41`, `:46-54`; `score/socom/test/unit/BUILD:16-29` |

The two comments `impl/service_identifier.hpp:21-28` and `impl/service_identifier.cpp:21-27` are
documentation written by the working-tree draft; they describe the draft's intended semantics and
are **not** acceptance of those semantics.

---

## 4. Derived registration-key invariants (working tree, with baseline contrast)

Each invariant is a statement the source enforces (or its immediate logical consequence), with
evidence and a falsifier. "Baseline" is the committed blob of §1.3; "working tree" is the on-disk
draft. All are **static readings**, not observed behaviour; compilation/execution status is recorded
in §8.

### R-1 — The key is a composite of the full interface identifier and the instance

**Statement.** The duplicate key type is
`Service_instance_identifier { Service_interface_identifier interface; Service_instance instance; }`.
There is no normalization, projection, or minor-stripping at the type boundary; the stored `interface`
retains `version.minor`.

**Evidence.** `impl/service_identifier.hpp:29-32`. `Service_interface_identifier` is
`{ Id id; Version version; }` with `Version{major, minor}`, each a `std::uint16_t`
(`service_interface_identifier.hpp:74-124`; fields `:91,94`; `major` `:83`, `minor` `:87`).

**Falsifier.** Any construction that rewrites `version.minor` before the key is formed.

**Working tree vs baseline.** Same.

### R-2 — The key equivalence is exactly `(instance, service id, major)`; `minor` is excluded

**Statement.** Under the key's only ordering, two `Service_instance_identifier` values are equivalent
(neither less than the other) **iff** they agree on `instance`, `interface.id`, and
`interface.version.major`; `interface.version.minor` is not compared. `std::set` uniqueness is
`!(a<b) && !(b<a)`, so minor-only variants collapse to one key.

**Evidence.** `impl/service_identifier.cpp:28-29`:
`std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major) < std::tie(rhs.instance,
rhs.interface.id, rhs.interface.version.major)`. Test expectations that exercise this collapse:
`service_identifier_tests.cpp:174` (`KeysDifferingOnlyInMinorVersionAreDuplicates`), `:182`
(`MinorVersionBoundariesAreDuplicates`), `:192`, `:203`.

**Falsifier.** A `minor` compared by `operator<` (or an equivalence based on
`Service_interface_identifier::operator<`, which compares `(id, version)` including minor at
`service_interface_identifier.hpp:159-162`).

**Working tree vs baseline.** **Differs by prior report.** `prior-reports/invariants.md` I-4 records
the baseline ordering as `std::tie(lhs.instance, lhs.interface)`, delegating to
`Service_interface_identifier::operator<`, hence including `minor`. The baseline blob is not in this
checkout, so that contrast is a **prior-report reading, not re-read here**.

### R-3 — `operator<` is the sole comparison/identity operator for the key

**Statement.** `Service_instance_identifier` declares exactly one operator, the free `operator<`;
there is no `operator==`, no member comparison, and no `std::hash<Service_instance_identifier>`
specialization. Identity is expressed only through strict-weak equivalence.

**Evidence.** `impl/service_identifier.hpp:34-36` (declaration under `\cond`/`\endcond`);
`impl/service_identifier.cpp:20-30` (definition); no other operator or hash for the type in the
working tree.

**Falsifier.** A declared `operator==`, a `std::hash` specialization, or a second ordering.

**Working tree vs baseline.** Same.

### R-4 — The type's only role is the duplicate-server registration key

**Statement.** `Service_instance_identifier` is used solely as the duplicate-server registration key.
Its only production construction site is `make_server_connector`, and its only production consumer is
the `Service_identifiers` set.

**Evidence.** `runtime_impl.hpp:56` (`using Service_identifiers =
Mutexed_variable<std::set<Service_instance_identifier>>`); `runtime_impl.hpp:30` (include);
`runtime_impl.cpp:443` (the single production construction); `runtime_impl.hpp:228-229`
(`m_service_identifiers`). It is not in the public `headers` filegroup
(`score/socom/BUILD:17-22`, glob `*.hpp`); see R-14.

**Falsifier.** A second production consumer or a public signature exposing the type.

**Working tree vs baseline.** Same (the build wiring adds a test-only surface but no public surface;
see R-14).

### R-5 — Insertion is serialized under a dedicated mutex; a failed insert maps to `duplicate_service`

**Statement.** `make_server_connector` constructs the key, then, under `m_service_identifiers->mutex`,
attempts `insert`. If the insert reports that the element already existed (`insert(...).second ==
false`), construction returns `Construction_error::duplicate_service` and **no connector is
constructed** (the set insert precedes the `SC_impl` creation). The callback-validity check precedes
the insert.

**Evidence.** `runtime_impl.cpp:443` (construct), `:445-447` (`callback_missing`), `:449-454` (lock
`:450`, insert `:451`, error `:452`), `:465-466` (connector constructed only after a successful
insert). Error name: `error.hpp:55`.

**Falsifier.** A duplicate path that still constructs a connector, or a check that does not use the
set insert result.

**Working tree vs baseline.** Same (the duplicate gate is value-based and unaffected by the
equivalence change).

### R-6 — The key is held for the connector's whole lifetime (disabled state included) and erased on destruction

**Statement.** The key is inserted at construction, before the connector can be enabled, and a
`Final_action` capturing the identifier and a weak pointer to the set erases it when the connector is
destroyed. A disabled connector therefore still holds its key.

**Evidence.** `runtime_impl.cpp:456-463` (`Final_action` erasing under the key mutex); `:465-466`
(the action is passed into `SC_impl`). Contrary-to-fact corroboration in the tests: the disabled
duplicate regression at `runtime_tests.cpp:440` states that two disabled connectors for the same key
collide because the insert happens at construction.

**Falsifier.** A key retained after connector destruction, or erased while a connector lives.

**Working tree vs baseline.** Same (the erasure is value-based and unaffected by the equivalence
change).

### R-7 — The key set is an independent synchronization domain

**Statement.** The key set has its own mutex (inside `Mutexed_variable`), separate from
`m_runtime_mutex`, `Service_database`, and the bridge maps.

**Evidence.** `Mutexed_variable` embeds `std::mutex mutex` beside `T data` (`runtime_impl.hpp:50-54`);
`Service_identifiers` uses it (`:56`); insertion locks `m_service_identifiers->mutex`
(`runtime_impl.cpp:450`), distinct from `m_runtime_mutex` used at `:529` and by `Service_database`
(`runtime_impl.hpp:136-137`, `:220-221`). Storage is a `shared_ptr` (`runtime_impl.hpp:228-229`).

**Falsifier.** One mutex reused for both the set and `Service_database`, or storage aliasing.

**Working tree vs baseline.** Same.

### R-8 — The record index ignores the minor version

**Statement.** The record map `Service_database::m_service_records` keys records by `(id, major)` and
deliberately ignores `minor`; within one record the instance is the inner key.

**Evidence.** `Minor_version_ignoring_key_equal` compares `id` and `major` only
(`runtime_impl.hpp:116-121`; `:119`); `Minor_version_ignoring_hash` hashes `id` and `major` only
(`:123-129`; `:127`); `Service_interfaces` is parameterized with both (`:131-134`); `get_record` does
`find` then `emplace` (`runtime_impl.cpp:313-324`), reached at `:496` (client) and `:530` (server).

**Falsifier.** A record map using the full-version hash/equality, or an inner key other than
`Service_instance`.

**Working tree vs baseline.** Same.

### R-9 — Working-tree key equivalence coincides with record identity (for a fixed instance)

**Statement (working tree).** For a fixed instance, the key equivalence is `(instance, id, major)` and
the record index identity is `(id, major)` crossed with the instance — so within an instance the two
coincide: any two configurations resolving to the same `Service_record` also collide in the key. This
is the source-level closure of the reported baseline gap.

**Statement (baseline, per prior report).** The baseline key included `minor` and was therefore
**strictly finer** than record identity: two configurations differing only in `minor` produced
distinct keys but resolved to one record (`prior-reports/invariants.md` I-11).

**Evidence.** R-2 (working tree) vs R-8. This is a source-level relationship, not a measured runtime
result.

**Falsifier.** A key coarser/finer than the record index again.

**Status.** The draft's closure is unaccepted and unmeasured (§5.2, §8).

### R-10 — At most one enabled server per record (asserted)

**Statement.** `Service_record` holds a single `std::optional` server. Registering a server connector
when the record already has one is a violated precondition, guarded by
`SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)`. In builds where the assert does not terminate, the
follow-on `m_server.emplace` silently replaces the existing value.

**Evidence.** `using Server = std::optional<Interfaced_server>` (`runtime_impl.hpp:70`); assert and
`m_server.emplace` at `runtime_impl.cpp:369-371`; `is_available()` is `m_server.has_value()`
(`runtime_impl.hpp:91`); the enable path reaches the server `register_connector` at
`runtime_impl.cpp:530-531`.

**Falsifier.** A record that can hold two servers, or a path that registers a server without the
assert.

**Working tree vs baseline.** Same. The termination behaviour of `SCORE_LANGUAGE_FUTURECPP_ASSERT`
lives in an external dependency (`score_baselibs`/`futurecpp`) and is **not** determined here.

### R-11 — Compatibility is a separate predicate from key identity

**Statement.** `is_interface_compatible` is a server-vs-client relation (equal `id`, equal `major`,
`client.minor <= server.minor`). It is evaluated when a server or client is enabled and is *not* the
set-membership rule. No compatibility predicate is invoked inside the key set.

**Evidence.** `is_minor_version_compatible` (`client.version.minor <= server.version.minor`) and
`is_interface_compatible` (`runtime_impl.cpp:133-146`); call sites at `:505-517` (client bind) and
`:534-544` (server connect).

**Falsifier.** Use of `is_interface_compatible` as the set comparator, or a key that encodes `<=`
minor semantics.

**Working tree vs baseline.** Same.

### R-12 — The key input carries the full configured version

**Statement.** The key is built from `configuration.get_interface()` plus the instance straight from
the API call; the configuration type retains the full `Service_interface_identifier`, including
`minor`. The working-tree key simply does not *compare* `minor`.

**Evidence.** `runtime_impl.cpp:443` (`configuration.get_interface()`);
`Server_service_interface_definition` stores a `Service_interface_definition` whose `interface` is a
full identifier (`service_interface_definition.hpp:65`, `:105`). No narrowing happens at the key site.
Upstream, config → socom construction narrows `uint32` minor to `uint16`, e.g.
`score/someipd/impl/remote_network_service.cpp:42-45` (`{service_version_major(),
static_cast<uint16_t>(service_version_minor())}`), per the prior call-site map.

**Falsifier.** A configuration type that projects away `minor` before `get_interface()`.

**Working tree vs baseline.** Same (the baseline additionally compared the retained `minor`).

### R-13 — Distinct version-aware equivalences coexist on purpose

**Statement.** Besides the minor-ignoring record index (R-8), the full version remains in the public
`Service_interface_identifier` ordering/hash and in the IPC binding key. There is no single global
version-equivalence.

**Evidence.** Public `Service_interface_identifier::operator==`/`operator<` compare `(id, version)`
(`service_interface_identifier.hpp:149-152`, `:159-162`); `Version::operator<` compares
`(major, minor)` (`:140-143`); `std::hash<Service_interface_identifier>` mixes `major` and `minor`
(`:181-190`, `:186-187`); `Interfaces_instances =
std::unordered_map<Service_interface_identifier, Instances>` uses the full hash/equality
(`runtime_impl.hpp:99-100`). The IPC `Service` key keeps the full version:
`score/gateway_ipc_binding/impl/gateway_ipc_binding.cpp:32-35` (`operator==` includes `version.minor`)
and `:37-43` (`Service_hash` mixes `minor`), per the prior call-site map.

**Falsifier.** A change that forces one global version equivalence across key, record index, and IPC.

**Working tree vs baseline.** Same. **Cross-boundary observation (static, not a defect claim):**
#84's "service identifier = `id + major`" is realized *only* at the internal key/index level; the
public interface and IPC layers still distinguish minors.

### R-14 — The key is internal, with no public/ABI exposure

**Statement.** `Service_instance_identifier` is compiled into `//score/socom:socom` only through the
`impl/**` source glob; it is not part of the public `headers` filegroup, and it is exposed to the test
package only through a `testonly` library.

**Evidence.** `score/socom/BUILD:17-22` lists public `headers` as `glob(["*.hpp"])`; the library `srcs`
glob is `impl/**/*.cpp` + `impl/**/*.hpp` (`:24-30`). The key header lives at
`impl/service_identifier.hpp`. The test-only `impl_service_identifier` library (`:46-54`) exposes it
to `//score/socom/test/unit:__pkg__` only, and `score/socom/test/unit/BUILD:24` depends on it.

**Falsifier.** Promoting the key into a public `*.hpp` header or exposing it through a public
signature.

**Working tree vs baseline.** Same (the build wiring adds a test-only surface but no public surface).

### R-15 — Status invariant: none of R-1 … R-14 is measured or accepted

**Statement.** R-1 … R-14 are source readings of the working-tree draft at the baseline-bound
candidate paths. They are **not** observed behaviour, and the R-2/R-9 minor-excluding key is an
**unaccepted** local change. No build or test was run in this iteration; the header compiles only in
the sense that it is brace-balanced by inspection (§2).

**Evidence.** No `shell`/build/test available in this task; the `.llm_tmp/overnight/validation/` and
`.llm_tmp/overnight/**/result.json` artifacts are absent (§1.5); authority is
`engineering_acceptance: pending`, `human_reviews: unanswered`, `safety_class: unknown` (§7).

**Falsifier.** A successful compile and test run of `//score/socom/test/unit:socom_test` (pending), and
an acceptance record for the minor-exclusion decision.

**Working tree vs baseline.** Not applicable (status statement).

---

## 5. Explicitly unaccepted — proposals and draft claims, not invariants

The following are recorded so they are **not** mistaken for existing accepted behaviour or accepted
engineering decisions. This is the separation the task asks for: §4's R-1 … R-14 describe the
unmodified public interface plus the internal draft key change; §5's items are *not* source-enforced
accepted invariants.

### 5.1 Issue #84 body (open, 0 comments) — design proposal only

The reporter proposes (`.llm_tmp/context/issue-snapshot.json:5`):

- three identity use cases: service-instance identifier = `service id + major + minor + instance id`;
  service identifier = `service id + major`; FindService = `service id + major + optional<minor> +
  optional<instance>`;
- "exclude the minor version and make it a property of the service instance to be able to better
  compare and index compatible service instances";
- FindService `major = FF` (AUTOSAR) as theoretically possible but not useful.

**Status: unaccepted.** In particular the public type still exposes
`Service_interface_identifier{Id id; Version{major, minor}}` (`service_interface_identifier.hpp:74-124`)
and the full version is still used in the ordering/hash and the IPC key (R-13). **This is the
"unaccepted public-interface proposal" that must be kept separate from the derived invariants:**
moving `minor` onto `Service_instance` would change the public type, whereas R-1 … R-14 describe the
unmodified public interface plus the internal draft key change.

### 5.2 The working tree's minor-excluding `operator<` (local, unaccepted)

`impl/service_identifier.cpp:28-29` excludes `minor`; the header and `.cpp` comments
(`impl/service_identifier.hpp:21-28`, `impl/service_identifier.cpp:21-27`) document it as aligning with
the `Service_database` index and issue #84. This is a **local, unaccepted implementation change** —
the R-2/R-9 "working tree" column. It differs from the baseline ordering reported by
`prior-reports/invariants.md` I-4 (which included `minor`). It must be confirmed by human review
before it can be regarded as correct; it is not an invariant of the committed baseline.

### 5.3 FindService wildcard and config version widths

The SOME/IP config declares `service_version_major: uint8` and
`service_version_minor: uint32 = 0xFFFFFFFF` (the SOME/IP "accept any minor" wildcard), while socom
uses `std::uint16_t major` / `std::uint16_t minor` (`service_interface_identifier.hpp:83,87`), so
config→socom conversions narrow `uint32→uint16` via `static_cast<uint16_t>(...)` (e.g.
`score/someipd/impl/remote_network_service.cpp:42-45`), turning `0xFFFFFFFF` into `0xFFFF`. How the
wildcard maps into the key is an open design proposal, not part of the current key invariants (R-2 uses
whatever concrete `minor` was passed). Wildcard / `major = FF` handling is out of this slice.

### 5.4 Candidate new test file and its asserted semantics

`.llm_tmp/context/candidate-files.json:22-25` records `service_identifier_tests.cpp` with
`baseline_git_blob: null`, and the baseline `source-manifest.json` contains no such path. The file
exists on disk with **87 `TEST_F` cases** (verified this iteration by `grep`; `:168`…`:2012`) under
`ServiceInstanceIdentifierTest`, and asserts the working-tree minor-excluding semantics. It is **not**
in the baseline, has **not** been executed by any measurement present in this checkout, and its
metadata (`service_identifier_tests.cpp:42-65`) records only `DerivationTechnique` and `Description`.
Treating it as required coverage is a manifest expectation / draft proposal, not an existing accepted
invariant.

### 5.5 Error semantics for a minor-only collision

`Construction_error::duplicate_service` is commented only "Service identifier already exists"
(`error.hpp:55`). Whether a collision caused solely by a differing `minor` should report
`duplicate_service`, a more specific error, or supersede is unresolved and unaccepted. The public
`make_server_connector` doc (`runtime.hpp:170-178`) speaks of duplicates judged by *"the
configuration.interface and instance parameters"*, while the public `operator==` includes `minor` but
the registration key does not.

### 5.6 The wider #84 restructure

Introducing `Service_identifier = id + major` (plus `minor` as a service-instance property) is a large
public API change. It is explicitly **not** proposed as done here; only the internal key was touched
by the draft.

---

## 6. Claims deliberately NOT made

- The identifier-only tests are **not** presented as platform validation, interface testing,
  requirements-based testing, resource testing, or fault-injection testing. No such harness exists in
  this workspace.
- **No fuzzy-testing technique is claimed**: no fuzz harness and no measurement.
- No native requirement/interface identifiers are invented. The test record properties deliberately set
  only `DerivationTechnique` and `Description` (`service_identifier_tests.cpp:42-65`;
  `runtime_tests.cpp:264-267`); `TestType` and the `Verifies`/`PartiallyVerifies`/`FullyVerifies` links
  are left unset, because no verified native requirement/interface identity exists for this slice.
- No safety classification is selected (`authority.json` `safety_class: unknown`).
- No risk or deviation is accepted, and the independent human gate is not answered.

---

## 7. Obligations status (none satisfied)

### 7.1 Pinned state

All nine pinned sources in `.llm_tmp/context/obligations/` were read this iteration (§1.4); every
`source-index.json` entry is `"native_acceptance": "not_inferred"`. `authority.json` records
`engineering_acceptance: pending`, `human_reviews: unanswered`, `safety_class: unknown`,
`codeql_scope: Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload`, and the instruction
*"Restart the failed queue for one complete pass through all obligations"*.

### 7.2 Status for this slice (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Freedom from compiler warnings & errors (100 %) | `verification_plan.rst` (criterion 9) | **NOT MEASURED** — header is brace-balanced by inspection (§2), but nothing was compiled; no host artifact is present |
| Static code analysis (clang-tidy / CodeQL), findings classified | `code_analysis.rst`; `verification_process.rst` (`gd_req__verification_sca_classification`, `:229`) | **NOT PERFORMED** — no tool, no build; a prior clang-tidy attempt was blocked on configuration; CodeQL MISRA applicability unestablished (draft mapping) |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` | **UNKNOWN** — mapping is `:status: draft`; not applied |
| Structural statement / branch coverage goals | `verification_plan.rst` (criteria 1–2) | **NOT MEASURED** — no test execution in this iteration; prior coverage readings are out of this checkout and below platform goals |
| Unit/component testing executed, results recorded | `verification_plan.rst` (criteria 6–7); `verification_guideline.rst` | **NOT EXECUTED** — 0 tests run this iteration; the prior key-TU run is stale and excludes `runtime_tests.cpp` |
| Interface / requirements-based / resource / fault-injection test types | `verification_process.rst`; `verification_plan.rst` | **NOT PERFORMED / applicability not inferred** — no harness; identifier-only tests must not be labelled platform validation |
| Boundary / equivalence derivation | `verification_process.rst` (derivation methods) | **SOURCE-ONLY** — cases exist in source (§4, §8) but were not executed |
| Fuzzy testing technique | `verification_plan.rst` | **NOT EXECUTED / NOT CLAIMED** — no harness and no measurement |
| Linking tests to requirements (record properties) | `verification_process.rst` (`gd_req__verification_link_tests_cpp`, `:57`) | **PARTIAL / NOT DONE** — `DerivationTechnique`/`Description` recorded; `TestType` and `Verifies` cannot be set without inventing identifiers |
| External-component AoUs verified | `verification_process.rst` (`gd_req__verification_external_aou`, `:215`) | **NOT SATISFIED** — no integration/static verdict; no AoU register |
| Independence of verification / review by a different committer | `verification_process.rst` (`gd_req__verification_independence`, `:142`) | **NOT DONE** — human reviews unanswered |
| Implementation inspection checklist IMPL_01…IMPL_03 | `inspection_checklist.rst` | **NOT FILLED** — draft template, no inspection |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** for this slice; no tool run here |
| Obligation collection results retained | `.llm_tmp/overnight/**/result.json` | **ABSENT in this checkout** — no `result.json` present |
| Native acceptance | `source-index.json` | **`not_inferred` for every entry** |

**Explicit non-satisfaction statement.** Missing tools (no `shell`/build/test in this task), the
unknown safety class and un-inferred applicability, the incomplete extraction of host artifacts, the
absent obligation-collection results, and the unanswered human reviews mean **none of the checked
obligations may be treated as satisfied**. A collection node that retained results would only show
*retention*, not passing; here the results are not present at all. In particular, the absence of
`.llm_tmp/overnight/validation/` and `.llm_tmp/overnight/**/result.json` is **not** evidence that the
corresponding checks passed.

---

## 8. Measurement and validation status

- **Tools:** `read_file`, `grep`, `glob`, `write_file` only. No `shell`, delegation, web, approval,
  publishing, or engineering acceptance.
- **Executed measurements:** **none** this iteration. No build, no `bazel test`, no runtime. Every
  statement is a static reading of the working tree at the baseline-bound candidate paths, or an
  explicitly-labelled logical consequence (e.g. the R-9 equivalence and the expected red/green
  behaviour).
- **Test inventory (read, not run):** `score/socom/test/unit/service_identifier_tests.cpp` has **87
  `TEST_F`** cases under `ServiceInstanceIdentifierTest` (verified this iteration by `grep`;
  `:168`…`:2012`), with metadata in `SetUp()` (`:42-65`):
  `DerivationTechnique = "boundary-values,equivalence-classes"` and a `Description`; `TestType` and the
  certificate links are deliberately unset. `score/socom/test/unit/runtime_tests.cpp` has **33
  macros**: 1 `TEST` at `:239`, **31 `TEST_F`** `:279`…`:1253`, 1 `TEST_P` at `:1311`; the shared
  metadata helper `record_registration_key_metadata` is at `:264-267`
  (`DerivationTechnique = "design-analysis,equivalence-classes"`). None of these were executed here.
- **Regression target (source-derived, not executed):**
  `RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError`
  (`runtime_tests.cpp:402-431`) and the key-level minor-collapse cases
  (`service_identifier_tests.cpp:174`, `:182`, `:192`, `:203`, …) assert that a second registration
  differing only in `minor` is rejected as `duplicate_service`. On a key that includes `minor` they
  would fail; on the working-tree key they should pass. This is a `std::set`/strict-weak-ordering
  consequence, not an observed result. Both connectors in the runtime regression remain disabled, so
  the duplicate is rejected at construction and never reaches the single-server
  `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)` path.
- **Key/index identity reading.** `Runtime_impl::make_server_connector` builds
  `Service_instance_identifier const identifier{configuration.get_interface(), instance}`
  (`runtime_impl.cpp:443`), inserts it under the key mutex (`:449-454`), and returns
  `Construction_error::duplicate_service` when `insert(...).second` is false (`:451-452`); a
  `Final_action` erases it (`:456-463`). The record index ignores minor via
  `Minor_version_ignoring_key_equal` / `Minor_version_ignoring_hash` (`runtime_impl.hpp:116-134`),
  consumed by `get_record`. The working-tree key (`minor` excluded) is as coarse as that index. This is
  a **source-derived reading, not a reproduced runtime result**.
- **Scope:** local, unprotected, scoped. This draft has not been reviewed, accepted, published, or
  reproduced on a full native runtime. Unit/integration execution and human review remain pending.
- **Reproduction path for the next authorized iteration (not run here):**

  ```bash
  bazel build //score/...
  bazel test //score/...
  bazel test //score/socom/test/unit:socom_test
  # focused key-level:
  bazel test //score/socom/test/unit:socom_test --test_filter='ServiceInstanceIdentifierTest.*'
  # focused runtime regression:
  bazel test //score/socom/test/unit:socom_test \
      --test_filter='RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError'
  # integration / cross / docs / traceability (per the pinned plans)
  bazel test --config=qemu-integration //tests/integration_test/...
  ```

- **No correction was needed for the recorded syntax failure** (§2), and **no test was expanded** in
  this iteration. The draft's 87-case key suite and 33-case runtime suite are as described above but
  remain natively unmeasured in this checkout; the only host runs recorded by prior reports are absent
  here and cover the key translation unit only.

---

## 9. Notice preservation

- No source, build, test, config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was created, edited, or
  deleted by this iteration; only this report was written. Every existing Apache-2.0 / notice header is
  untouched, and all 38 prior-report files under `.llm_tmp/overnight/prior-reports/` plus
  `.llm_tmp/overnight/reports/scope.md` and `.llm_tmp/overnight/reports/callsites.md` were preserved.
- The header that the task flagged (`score/socom/impl/service_identifier.hpp`) was inspected and left
  unchanged because it is already brace-balanced and otherwise well-formed (§2). The sibling
  `service_identifier.cpp`, both BUILD files, and both candidate test files likewise retain their
  Apache-2.0 / SPDX headers (`:1-12`).
- This report itself carries the Apache-2.0 header. No licensed MISRA rule text is reproduced; only
  native rule/query identifiers, file locations, and prior-report readings are cited.
- Any future implementation in this slice must carry the Apache-2.0 header on new files, including
  `service_identifier_tests.cpp`, per `.github/instructions/code-style.md` and `REUSE.toml`.

---

## 10. Pending human review checklist

- [ ] **Confirm the §2 source inspection:** the header is already brace-balanced (braces at `:19`,
      `:29`, `:32`, `:38`; line `:39` blank; single nested close `}  // namespace score::socom`), so
      the recorded syntax failure is stale and no correction is required. If the *"cancelled draft"* is
      a different revision that still carries the extra brace, locate it and authorize its correction;
      it is not the file in this checkout.
- [ ] **Resolve the instruction conflict:** was a review-only iteration intended (report only, as done
      here), or was source correction expected? The write boundary forbade the latter, and it was moot
      because no defect was present; `edit_file` was not in the permitted tool set.
- [ ] **Confirm the derived invariants R-1 … R-15** against the working tree at baseline
      `f8a196c3…`, and decide **R-2/R-9**: should the registration key keep `minor` (reported baseline)
      or ignore it (working tree)? Keep §5.2's draft change separate from accepted behaviour until then.
- [ ] **Confirm R-10:** is `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)` a hard invariant (so the key
      must cover every collision the record index can produce) or a defensive check tolerating
      re-registration?
- [ ] **Keep §5 proposals separate from the invariants** (issue #84 public restructure, FindService
      wildcard, config `0xFFFFFFFF` minor narrowing, the new test file and its asserted semantics,
      error semantics) until an acceptance record exists; do **not** present identifier-only tests as
      platform validation or claim an unmeasured fuzzy technique.
- [ ] **Supply the missing artifacts** (`.llm_tmp/overnight/**/result.json` and
      `.llm_tmp/overnight/validation/`) into this checkout; do not infer passing from absence or from
      prior reports' retained summaries.
- [ ] **Select a safety class** via the authorized role; do not infer the slice's class from the
      `:safety: ASIL_B` attribute on the pinned platform documents (§1.4).
- [ ] **Run the full native suite** (`bazel test //score/socom/test/unit:socom_test` and the broader
      `//score/...` set), including `runtime_tests.cpp`, record results, and schedule independent human
      review (the approver must differ from the author, per `gd_req__verification_independence`).

---

*End of registration-key invariants review draft. Local, unprotected, scoped. No engineering
acceptance; human reviews unanswered; full native runtime tests pending. Every statement is a local
reading of the working tree, a prior report's recorded reading, or an explicitly-labelled logical
consequence — none is acceptance, review approval, publication, or a full native run.*
