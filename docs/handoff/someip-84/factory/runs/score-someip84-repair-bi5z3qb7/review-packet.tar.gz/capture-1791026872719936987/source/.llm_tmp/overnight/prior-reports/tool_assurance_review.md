<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — tool assurance review (duplicate-server registration key)

**Document type:** review draft — tool identification register, exact
versions/configuration/digests, tool-impact & error-detection question sheet,
confidence/qualification evidence inventory, and non-satisfaction record
**Date:** 2026-10-02
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version handling in
socom* (issue #84)
**Run:** branch `fabro/run/01M3YRJEGXNY6CB81T7TKW774B`
**Status:** local, unprotected, scoped. **No engineering acceptance exists. Human reviews are
unanswered. Full native runtime tests remain pending.** Tool *execution* is not tool
*qualification*: everything below is an identification/evaluation **draft for owner decision**,
never an accepted result.

> **Tool / write boundary actually observed.** This iteration used only `read_file`, `grep`,
> `glob`, and `write_file`. No `shell`, no delegation, no web access, no approval, no publishing,
> and no engineering acceptance. The task's explicit final sentence — *"This is a review draft:
> only that report may be written."* — governs the write boundary; accordingly **exactly one file
> was written — this report.** No source, build, test, config, `NOTICE`, `LICENSE`, `REUSE.toml`,
> or prior-report file was created, edited, or deleted. Every prior report under
> `.llm_tmp/overnight/prior-reports/` and every earlier file under `.llm_tmp/overnight/reports/`
> was preserved unchanged.

> **Instruction conflict, recorded not silently resolved.** The task also says *"Inspect and
> correct the actual source before expanding tests."* §2 shows the named file
> (`score/socom/impl/service_identifier.hpp`) is already brace-balanced and line 39 is blank, so
> there is nothing to correct on the facts; and the write boundary permits only this report, so a
> source write is not permitted in any case. No test was expanded. The conflict is carried to the
> human reviewer (§14).

> **Non-satisfaction rule applied throughout.** A successful obligation-collection node means the
> results were **retained**, not that the checks **passed**. Missing tools, unknown applicability,
> incomplete extraction, and unanswered human reviews are **not** treated as satisfied. Tool
> execution alone does not qualify any tool; owner acceptance stays pending.

---

## 0. Summary

1. **Tool identification is possible only for a mixed set of *collector-sandbox* tools and
   *repository-pinned* tools, and the two sets disagree on versions.** The collector ran and
   hashed GCC 12.3.0, Clang/Clang-Tidy 19.1.7, CodeQL 2.21.4, gcov 12.3.0, gcovr 5.0,
   cppcheck 2.7, QEMU 6.2.0 and perf 6.8.12 (§3). The repository pins a different toolchain:
   LLVM `22.1.7` via `toolchains_llvm 1.8.0`, GCC `12.2.0` via `score_bazel_cpp_toolchains 1.0.3`,
   QCC `12.2.0`/SDP `8.0.4`, Bazel `8.6.0`, GoogleTest `1.18.0` (§5). **This drift is itself a
   tool-assurance finding:** the repo-pinned clang-tidy was never the binary used to judge the
   repo `.clang-tidy`, and the host GCC minor differs from the pinned one.
2. **Eight tools that the pinned process/verification sources rely on are absent** from the
   collector environment: Bazel, Valgrind (two paths), gitleaks, clang-format, pre-commit, reuse
   (§4). Every `native_*`, `cross_compilation` and `format_precommit` obligation therefore exits
   `127`; their obligation status is *unavailable*, not *pass*.
3. **The only analyzers that ran to completion produced no in-scope finding**, and the remaining
   analyzers did not run at all: clang-tidy 19.1.7 rejected the repo `.clang-tidy`
   (`--verify-config` exit 1, 15 warnings) so it analyzed **nothing**; cppcheck flagged only
   headers outside the six candidate paths; CodeQL security flagged only vendored googletest;
   CodeQL MISRA is a focused, draft-mapping run whose in-scope hits are the gtest `TEST_F` macro
   expansion (§8, §11).
4. **No tool has a Tool Verification Report, an impact rating, an error-detection rating, a
   confidence level, or a qualification argument in the retained evidence.** `tool_management.rst`
   requires each tool to be identified, evaluated and — when TCL is LOW — qualified and then
   *released* by an authorized human. §9 and §10 draft the questions; they are deliberately left
   **unanswered**, because the safety class is `unknown`, `human_reviews: unanswered`, and
   `engineering_acceptance: pending` (§1.4).
5. **The bounded slice's own compiled artifact is clean under the collector's GCC** (focused
   compile exit 0, 85/85 focused tests green) but that is a single, scoped, non-native
   measurement and it is stale by two cases relative to the current tree (§2, §6). It does not
   qualify GCC, gtest, Bazel, or any analyzer.
6. **No obligation in this slice is satisfied.** Every `source-index.json` entry is
   `native_acceptance: not_inferred`; the retained tool results are scoped/blocked; the
   qualification and release steps are human-only and pending (§13).

---

## 1. Binding, sources read, host feedback

### 1.1 Issue and baseline

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` — *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:2-4` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG`, created/updated `2026-04-14T13:23:24Z` | `.llm_tmp/context/issue-snapshot.json:8,19-20` |
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |

The issue body is a **design proposal, not an accepted obligation** (`.llm_tmp/context/issue-snapshot.json:5`).
Binding is by baseline commit, not by run HEAD.

### 1.2 Bounded slice and the six candidate paths

The bounded slice is the **duplicate-server registration key**: `Service_instance_identifier`
identity is `(instance, service id, major)` and `minor` is deliberately excluded, matching the
minor-ignoring `Service_database` index. Directly read this iteration:

- `score/socom/impl/service_identifier.hpp:29-32` — `Service_instance_identifier{interface, instance}`;
  out-of-line `operator<` declaration at `:35`.
- `score/socom/impl/service_identifier.cpp:20-30` — `operator<` over
  `std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major)`.

Six candidate paths are named by `.llm_tmp/context/candidate-files.json:1-25`:
`score/socom/BUILD`, `score/socom/impl/service_identifier.cpp`,
`score/socom/impl/service_identifier.hpp`, `score/socom/test/unit/BUILD`,
`score/socom/test/unit/runtime_tests.cpp`, `score/socom/test/unit/service_identifier_tests.cpp`.
`glob **/service_identifier.hpp` returns exactly one path.

### 1.3 Prior reports read and preserved

`.llm_tmp/overnight/prior-reports/` (12 files) and `.llm_tmp/overnight/reports/` (24 files,
before this one) were read/grepped and preserved. The most relevant to tool assurance are
`tool_findings_repair.md` (per-tool diagnostics vs. the candidate paths), `analyzer_plan.md`
(native analyzer configuration + changed-unit exposure), and `bazel_plan.md` (pinned native
invocations and the unavailable-Bazel table). Their conclusions are consistent with this draft:
no executed native Bazel measurement, clang-tidy never ran, and no qualification exists.

### 1.4 Authority / pinned process sources

`authority.json`: `engineering_acceptance: pending`, `human_reviews: unanswered`,
`safety_class: unknown`, `codeql_scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway; no
upload"`. Every `source-index.json` entry is `native_acceptance: not_inferred`. Pinned sources
read include `tool_management.rst` (the 3-step identification → evaluation → qualification →
approval process), `code_analysis.rst` (static/dynamic tool set), `verification_plan.rst`
(quality criteria 8–9, tools list), `development_plan.rst` (SW development tools),
`verification_process.rst` (SCA classification), and `inspection_checklist.rst` (draft).
`misra_mapping.rst` and `inspection_checklist.rst` are `:status: draft`.

### 1.5 Host feedback under `.llm_tmp/overnight/validation/` (present, scoped, stale)

| Artifact | Content |
|----------|---------|
| `check-result` | `0` — collector success marker only |
| `before.json` | `ServiceInstanceIdentifierTest`: 85 tests / 28 failures |
| `after.json` | 85 tests / 0 failures |
| `measurement.json` | `check_ref: check_conversion_tests`, `mode: ubsan`, `origin: local_unprotected_measurement`, `initiator: Fabro host hook`, `engineering_acceptance: pending`, `full_native_tests: not_executed`, compiler `/usr/bin/x86_64-linux-gnu-g++-12` (`compiler_sha256: 88315fd2…`); `baseline_with_agent_tests` 85/28/compile 0; `candidate` 85/0/compile 0 (`:2039-2058`); `changed_paths: ["score/socom/test/unit/service_identifier_tests.cpp"]` (`:5-7`); config digests at `:8-2037` |

The measurement is **stale** against the current tree (the current `service_identifier_tests.cpp`
is hashed `4df2c63c…` with 87 test macros in the latest `process_checks` inventory, versus 85 in
the measurement) and compiles only the focused identifier translation unit — not
`runtime_tests.cpp`, not Bazel. `after-test.stdout` reports `[ PASSED ] 85 tests.`

---

## 2. The recorded GCC syntax failure — inspection of the actual source

**Finding: the described defect is not present in this checkout; no correction is required, and
none is permitted here.**

`score/socom/impl/service_identifier.hpp` (read directly this iteration) is 40 lines and
brace-balanced:

| Line | Content | Role |
|------|---------|------|
| 14–15 | `#ifndef SRC_SOCOM_SRC_SERVICE_IDENTIFIER` / `#define …` | include guard |
| 17 | `#include "score/socom/service_interface_identifier.hpp"` | include |
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 30–31 | `Service_interface_identifier interface;` / `Service_instance instance;` | members |
| 32 | `};` | closes the struct |
| 35 | `bool operator<(…);` (inside `/// \cond`) | declaration |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`) and two closers (`:32`, `:38`) give net brace balance `0`. Retrieval
from the retained tool artifacts corroborates a compiling unit:

- `obligations/compiler_diagnostics/gcc-compile.stderr` is **empty** and the recorded command
  `gcc-compile` is `"exit_code": 0` with `gcc-tests` also `0` — a surviving extra closing brace
  would have failed this compile.
- `validation/after-compile.stderr` and `validation/before-compile.stderr` are empty; the
  compiler is the collector GCC at sha `88315fd2…`.

The description matches the **earliest** prior reports, which quote the old split form
`}  // namespace socom` + `}  // namespace score`. Applying the historical repair to the already
nested, balanced file would be a no-op at best and a compile break at worst. Because the write
boundary permits only this report, no source edit was made. **Tool-assurance consequence:** the
collector GCC is the *error-detection mechanism* that would have caught this class of defect, and
in the retained run it reports clean — but the retained compile is focused and non-native (§6), so
the detection claim is scoped.

---

## 3. Tool identification register — tools present in the collector environment

Values below are read verbatim from `obligations/tool_assurance/result.json` (`tool_inventory`
`:442-523`; `commands` `:240-439`; `collector_identity` `:214-234`) and the matching
`version-*.stdout`. `sha256` is the hash of the resolved executable recorded by the collector.

| # | Tool | Purpose (pinned source) | Path (collector) | Version (verbatim) | sha256 | Available |
|---|------|-------------------------|------------------|--------------------|--------|-----------|
| T1 | GCC / g++ | Host C++ compiler, linker, warnings, sanitizers, unit-test binaries (`development_plan.rst:160-163`) | `/usr/bin/x86_64-linux-gnu-g++-12` | `12.3.0` (Ubuntu 12.3.0-1ubuntu1~22.04.3) | `88315fd2d961a1f4e4070b104d7bd4c7670df19d9949409879ba269466c196d3` | yes |
| T2 | Clang / clang++ | Second compiler for warning coverage (`code_analysis.rst:38-49`) | `/home/jefferson/.local/share/s-core-tools/llvm-19.1.7/usr/lib/llvm-19/bin/clang++` | `Ubuntu clang version 19.1.7` | `7969846391c1fe04f816c26bd7d6a09171e9330378c9ec8fd6c841dafec66faa` | yes |
| T3 | clang-tidy | Static analysis / MISRA (`code_analysis.rst:37,43-47`; `development_plan.rst:169-171`) | `…/llvm-19.1.7/usr/lib/llvm-19/bin/clang-tidy` | `Ubuntu LLVM version 19.1.7` | `5f733fae7fdb5ac7122ea1e8fcfb4723a7cbf68b5d779f2f8ead6eb276c03f0c` | yes (ran, but config rejected — §8.4) |
| T4 | CodeQL CLI | Static security analysis (`code_analysis.rst`; `development_plan.rst:173-198`) | `/home/jefferson/.local/share/s-core-tools/codeql-2.21.4/codeql/codeql` | `2.21.4` | `d38df35e9275fce177e76cc6d4b5fc031ba7e9be4e7d224d0be7d6b7d0a21cc1` | yes |
| T5 | CodeQL coding-standards pack | MISRA query pack (`code_analysis.rst:32`) | `…/codeql-coding-standards-2.61.0/qlpack.yml` | `2.61.0` (pack) | `3d06c897dd580a60bd8435bab198e411e9556236a7ee11bb16ff78c853bebd03` | yes |
| T6 | CodeQL MISRA suite | MISRA CPP default query suite | `…/codeql-coding-standards-2.61.0/codeql-suites/misra-cpp-default.qls` | — (suite) | `8b41feb7188bde80cbb9ad57c643db6e2f95e02bae347171479114dc60c3626e` | yes |
| T7 | gcov | Statement/branch coverage collection (`verification_plan.rst:552-561`) | `/usr/bin/gcov-12` | `12.3.0` | `dcaf103b28775592ac023067bf7af4c1f4e2e7605e8d4fd65600e0b0f7e2dbe4` | yes |
| T8 | gcovr | Coverage report aggregation (`verification_plan.rst:552-555`) | `/usr/bin/gcovr` | `5.0` | `59cd3edebe1a6e9a8df26b0ffc01906c444758c58411214ff0e466c8170cfbb0` | yes |
| T9 | cppcheck | Complementary static analysis | `/usr/bin/cppcheck` | `2.7` | `d2268c85b26850db5f36f7a3a7a2ae0106377810f4f93988bf4ab636481b4d89` | yes (findings out of scope — §8.5) |
| T10 | QEMU system | Integration test emulation (`native_integration` prerequisites) | `/usr/bin/qemu-system-x86_64` | `6.2.0` (Debian 1:6.2+dfsg-2ubuntu6.31) | `55862c768c21fa7d3e72ca1b24797d8ab5b406eb5ef4c9ab9c2280f4e0b8f330` | yes |
| T11 | perf | Resource/performance measurement (`native_performance`) | `/usr/bin/perf` | `6.8.12` | `2d0953085bf720a25efbe24f853e97d27b1f12f18a398255ff82cbafde254dad` | yes |

### 3.1 Collector harness (the tool that produced every obligation artifact)

| Item | Path (collector run dir) | sha256 |
|------|--------------------------|--------|
| `collect_obligations.py` | `…/score-someip84-factory-2fekt_ew/collect_obligations.py` | `cef00d1425b9dbc167d0f1b394e31028eec1697d5c826508d71945ea410f9c34` |
| `obligations.py` | `…/obligations.py` | `252a8521fdd5b7225daf37597933bd868fc4d69ec2a80755e619d3272577e467` |
| `storage.py` | `…/storage.py` | `87cec0494fac266a12527ec4799e5b8caec3d8ac65e4b7da49636292f42bb851` |
| `workspace_transfer.py` | `…/workspace_transfer.py` | `b1e9577072d7ec5027461a1f335f38300d0bba05daefa736d21a86bb4c557ca1` |

These are the tools whose malfunction (a mis-snapshotted tree, a mis-parsed exit code, an
incomplete extraction) would silently corrupt every retained result. They are **not** in the
repository and have no Tool Verification Report.

### 3.2 Test framework and other declared dependencies (identification, not execution)

| Item | Version | Source |
|------|---------|--------|
| GoogleTest (`@googletest`) | `1.18.0` | `MODULE.bazel:59` |
| google_benchmark | `1.9.5` | `MODULE.bazel:61` |
| Bazel | `8.6.0` | `.bazelversion:1`; `USE_BAZEL_VERSION=8.6.0` |
| `toolchains_llvm` (pins LLVM) | `1.8.0`, toolchain `llvm_version = 22.1.7` | `MODULE.bazel:165,185` |
| `score_bazel_cpp_toolchains` (pins GCC/QCC) | `1.0.3`, GCC `12.2.0`, QCC `12.2.0`/SDP `8.0.4` | `MODULE.bazel:83,87-148` |
| `aspect_rules_lint` (clang-tidy aspect) | `2.7.2` | `MODULE.bazel.lock` dependency inventory |
| `score_tooling` / `score_coverage` | `2.1.1` / `0.2.0` | `MODULE.bazel:198-199` |
| Python toolchain | CPython `3.12` (with a `3.8.20` single-version override) | `MODULE.bazel:25-36` |

---

## 4. Missing-tool register (unavailable obligations)

From `obligations/tool_assurance/result.json:459-522`, the following were probed and reported
`available: false, sha256: null`:

| Tool | Probed path | Consequence |
|------|-------------|-------------|
| Bazel | `/tmp/s-core-001/bin/bazel` | All `native_build`, `native_tests`, `native_integration`, `native_lint`, `native_docs`, `native_traceability`, `native_sanitizers`, `native_tsan`, `native_coverage`, `native_performance`, `cross_compilation`, `format_precommit` exit `127` (`[Errno 2] No such file or directory: '/tmp/s-core-001/bin/bazel'`) |
| Valgrind | `/usr/bin/valgrind` **and** `/tmp/score-someip84-obligation-tools/usr/bin/valgrind` | `focused_memcheck` exit `127`; Memcheck complement unavailable |
| gitleaks | `/tmp/score-someip84-obligation-tools/bin/gitleaks` | Secret scan unavailable (`secret_dependency_checks` retains only the dependency inventory) |
| clang-format | `/tmp/score-someip84-obligation-tools/bin/clang-format` | Format evidence unavailable |
| pre-commit | `/tmp/score-someip84-obligation-tools/bin/pre-commit` | Pre-commit evidence unavailable |
| reuse | `/tmp/score-someip84-obligation-tools/bin/reuse` | REUSE/licence evidence unavailable |

**Rule applied:** absent tools are **not** satisfied obligations. Each row above is a *blocker*,
not a *pass*, and none may be re-interpreted as "no finding".

---

## 5. Repository-pinned tool configuration vs. collector-observed tools (drift)

This is the central tool-assurance finding of this review: **the tools that judged the code are
not the tools the repository pins.**

| Function | Repository pin | Collector-observed | Drift / significance |
|----------|----------------|--------------------|----------------------|
| C++ compiler (host) | GCC `12.2.0` (`MODULE.bazel:100`) | GCC `12.3.0` (`version-0.stdout`) | Minor drift; collector notes *"GCC 12.3 / Clang 19 differ from native toolchain pins"* (`compiler_diagnostics/result.json:334-336`) |
| C++ compiler (2nd) / tidy | LLVM `22.1.7` (`MODULE.bazel:185`) | Clang / clang-tidy `19.1.7` (`version-1/2.stdout`) | **Major drift** — the `.clang-tidy` verdict was produced by a three-major-versions-older binary than the pinned one; "unknown check" results cannot be transferred to the pinned tool |
| Target compiler | QCC `12.2.0`, SDP `8.0.4` (`MODULE.bazel:117-148`) | not present | Cross/QNX obligations exit `127`; target warnings/sanitizers unmeasured |
| Build system | Bazel `8.6.0` (`.bazelversion:1`) | absent | No native build/test/coverage/analyzer run |
| Coverage | `score_coverage 0.2.0` + LLVM source coverage (`coverage.bazelrc`); documented gcov/gcovr | gcov `12.3.0` + gcovr `5.0` (focused TU only) | Methodology differs (gcov on host GCC vs LLVM instrumentation); figures not comparable to a native coverage run |
| Static analysis (security) | "GitHub CodeQL" in CI (`development_plan.rst:138,173-198`) | local CodeQL `2.21.4`, public Apache-2.0 repo, **no upload** (`authority.json`) | Documented CI tool ≠ collector tool; no CI scanning receipt retained |
| Static analysis (Coverity) | Named in `code_analysis.rst:41,47` | not installed / not adopted | Explicit `tool_assurance` blocker: *"Coverity not installed/adopted here; reconcile guideline/development-plan discrepancy"* (`tool_assurance/result.json:237`) |

The drift matters because a tool's identity is *name + version + configuration*, independent of
location (`tool_management.rst:67`). A verdict from LLVM 19.1.7 is not evidence about the LLVM
22.1.7 tool the repository will use on the reference environment.

### 5.1 Configuration digests actually snapshotted

From `validation/measurement.json` `source_hashes` `:8-2037` (third tuple element is the file
mode, decimal `420` = `0o644`):

| Configuration file | sha256 |
|--------------------|--------|
| `.bazelversion` | `4a0dcdd04283b2bb2122080f03d0058cf6ad7a98731afab1530d59a7f3737dfe` |
| `.bazelrc` | `3e377eee390155ccd7f47d104a75b516c6cb23bf81261bfb26a18bd5eedc2931` |
| `.clang-tidy` | `0b655840f7e72ea394afb9df41a2ec50a0a8525a0a3d7ddff0b95879d6075be0` |
| `.clang-format` | `9c0ec2489877fcb41446602f1674bdacda2646e512e15fe143647b03de465cf5` |
| `tools/lint/linters.bzl` | `4155f398de558f0581706e8270d7b809794d55de8234c9abaeec719fa7d62dc0` |

The tool-facing configs are the repository's; the executing binaries are the collector's — hence
the drift in §5. Note `.clang-tidy` here is **286 lines** with a `Checks: >` folded block scalar
containing `#` comment lines (`.clang-tidy:16-162`), which is the root cause of the
`--verify-config` rejection (§8.4).

---

## 6. Exact collector invocations and readiness

`tool_assurance/result.json:240-439` records only **nine** version queries (`version-0,1,2,4,5,6,
7,11,12`). Labels 3, 8, 9, 10 are absent because the corresponding binaries were unavailable.
Representative exact argv (verbatim from the result):

- `version-0`: `["/usr/bin/x86_64-linux-gnu-g++-12", "--version"]`, exit 0.
- `version-1`: `["/home/jefferson/.local/share/s-core-tools/llvm-19.1.7/usr/lib/llvm-19/bin/clang++", "--version"]`, exit 0.
- `version-2`: `["…/clang-tidy", "--version"]`, exit 0.
- `version-4`: `["…/codeql-2.21.4/codeql/codeql", "version"]`, exit 0.
- `version-5`/`version-6`/`version-7`: `gcov-12` / `gcovr` / `cppcheck` `--version`, exit 0.
- `version-11`/`version-12`: `qemu-system-x86_64` / `perf` `--version`, exit 0.

The focused compile/test commands (from `compiler_diagnostics/result.json:236-330`) are e.g.
`g++-12 -std=c++17 -Wall -Wextra -Werror -pthread -I. … service_identifier.cpp string_registry.cpp
service_identifier_tests.cpp .llm_tmp/googletest/…/gtest-all.cc …/gtest_main.cc -o …/gcc`. This is
a **focused translation unit**, not a Bazel target; it does not include `runtime_tests.cpp`.

---

## 7. Tool-impact and error-detection questions (draft; for authorized humans)

`tool_management.rst:84-123` prescribes the ISO 26262-style sequence: **step 1** tool impact
(YES if a malfunction/threat could violate a safety or security requirement), **step 2** tool
error detection (NO if the malfunction cannot be guaranteed to be detected or prevented), **step
3** TCL = LOW when impact YES *and* detection NO; LOW requires qualification. The following is a
**draft question sheet — no answer is asserted**, because the safety class is `unknown` and the
relevant human roles are unanswered.

| Tool | Step 1 — could a malfunction/threat violate a safety or security requirement? | Step 2 — could that malfunction be detected or prevented by other measures? | Draft TCL (unconfirmed) |
|------|--------------------------------------------------------------------------------|-----------------------------------------------------------------------------|--------------------------|
| T1 GCC 12.3.0 | Candidate YES: a miscompilation or a swallowed warning could ship an incorrect binary past criterion 9. Decide against the `unknown` safety class. | Candidate partial: focused tests + analyzers + coverage; but the only retained measurement is one scoped TU, and its tests derive from the same source. No independent oracle retained. | Candidate LOW → qualification likely needed |
| T2 Clang 19.1.7 | Candidate YES (same class as T1). | Same as T1; additionally the only retained clang run *failed* on a dependency deprecation under `-Werror`, so it provides no compiled artifact. | Candidate LOW |
| T3 clang-tidy 19.1.7 | Candidate YES: undetected MISRA/defect classes could violate coding/safety requirements. | Candidate NO: no complementary rule engine covers the same rules; the run produced **zero** findings because the config was rejected. | Candidate LOW → qualification/deviations |
| T4–T6 CodeQL 2.21.4 + pack 2.61.0 | Candidate YES: security/MISRA findings could be missed. | Candidate partial: the collector itself records *"Compiled query qualification and human deviations pending"* and a draft mapping; extraction is focused. | Candidate LOW/unresolved |
| T7/T8 gcov 12.3.0 / gcovr 5.0 | Candidate YES: under-reported coverage could hide untested safety code. | Candidate partial: the platform goals are independently stated (85 %/100 %); tool could under/over-count branch coverage; the focused run measured only two files. | Candidate LOW/unresolved |
| T9 cppcheck 2.7 | Candidate YES if used as evidence; it is a complementary tool. | Candidate partial: overlaps compilers/tidy. Findings were all out-of-scope headers. | Unresolved (adoption intent unclear) |
| Bazel 8.6.0 | Candidate YES: an incorrectly hermetic build could mask defects or produce non-reproducible artifacts. | Candidate partial: hermeticity is the point, but every native obligation is unexecuted here. | Unresolved |
| GoogleTest 1.18.0 | Candidate YES: a test-framework defect could pass a failing behavior. | Candidate partial: tests are reviewed, but no independent oracle; the gtest `TEST_F` macro also pollutes the MISRA analysis. | Unresolved |
| QEMU 6.2.0 | Candidate YES for integration claims on emulated hardware. | Candidate partial: emulation ≠ reference hardware. | Unresolved |
| perf 6.8.12 | Candidate YES for resource-usage claims. | Candidate partial: environment-dependent. | Unresolved |
| Collector harness (§3.1) | Candidate YES: a mis-snapshot/mis-parse would corrupt all retained results. | Candidate NO other than re-running and cross-checking hashes. | Candidate LOW → verify |
| Valgrind / gitleaks / clang-format / pre-commit / reuse | Not evaluable — tools absent. | n/a | **Unresolved; cannot be qualified without the tool** |

**Explicit caution.** These are *draft candidate* judgments for orientation only. They are **not**
impact ratings, not error-detection determinations, not confidence levels, and not qualifications.
Only the authorized roles (safety/security/quality manager and committers, per
`verification_process.rst:246` and the `inspection_checklist.rst` role table) may set them.

---

## 8. Analyzer/tool-by-tool evidence inventory (what was actually retained)

### 8.1 GCC (T1) — focused, clean, non-native

`compiler_diagnostics/result.json`: `gcc-compile` exit `0` (`:271`), `gcc-tests` exit `0`
(`:293`); `gcc-compile.stderr` and `gcc-tests.stderr` empty. Host measurement
(`validation/after.json`): 85 tests / 0 failures, compile exit 0. **Scope:** focused identifier TU,
not `runtime_tests.cpp`, not Bazel; stale by two cases. Evidences nothing about GCC qualification.

### 8.2 Clang (T2) — blocked by a dependency

`compiler_diagnostics/clang-compile.stderr:4` is the sole retained compile error:
`error: 'get_temporary_buffer<testing::TestInfo *>' is deprecated
[-Werror,-Wdeprecated-declarations]`, instantiated from the vendored
`.llm_tmp/googletest/googletest/src/gtest.cc:3068` via `std::stable_sort`. It is a
googletest/libstdc++ 12 interaction under `-Werror`, **not** a candidate-source defect; the only
available "fixes" (patch the dependency or suppress the warning) are out of scope and prohibited.
The clang branch of criterion 9 is therefore unmet.

### 8.3 CodeQL security (T4) — dependency-only, focused extraction

`codeql_security/result.json`: `database-create` and `analyze` commands exit `0` and `blockers: []`
(`:235`) but `status: findings_or_execution_failure`; every finding's `uri` is under
`.llm_tmp/googletest/…`. Self-declared limit: *"Focused linked executable, not full target
extraction; dependency findings retained."* No in-scope finding. Not a full-target result.

### 8.4 clang-tidy (T3) — did not run (config rejected)

`focused_clang_tidy/native-config.stderr` records exit 1 with 15 `--verify-config` warnings, e.g.
`unknown check '# --- autosar-severity-one --- bugprone-use-after-move'`,
`unknown check 'clang-analyzer-alpha.security.ArrayBoundV2'`,
`unknown check 'modernize-use-integer-sign-comparison'`, and
`unknown check option 'modernize-use-integer-sign-comparison.IncludeStyle'`. Retained blocker:
*"Native analyzer configuration incompatible; no replacement called MISRA"*
(`focused_clang_tidy/result.json:236`). Because `--verify-config` failed, **zero** translation
units were analyzed. That is **"not run", never "clean".** Two contributing causes: (a) the
`Checks: >` folded block scalar folds `#` comments into check names; (b) genuine version drift
between clang-tidy 19.1.7 (collector) and the pinned LLVM 22.1.7 (§5). Both require an authorized
fix outside the candidate paths; suppressing checks is prohibited.

### 8.5 cppcheck (T9) — findings outside the candidate paths

`focused_cppcheck` exit `2`. All 19 findings are `id="passedByValue"` (severity `performance`)
located in included headers outside the six candidate paths
(`score/socom/registry_string_view.hpp` ×13; `score/socom/service_interface_identifier.hpp` ×6).
They are style/performance noise, not correctness defects; disposition is pending.

### 8.6 Sanitizers — ASan/LSan/UBSan pass; TSan environment failure; Valgrind absent

- `focused_asan_lsan`: compile exit `0`, tests exit `0` (`result.json`), stderr empty — focused
  identifier scope only.
- `focused_tsan`: compile exit `0`, tests exit `66` in one collection and `-11` in another;
  stderr `FATAL: ThreadSanitizer: unexpected memory mapping`. This is the known
  TSan/kernel-ASLR incompatibility, not a reported data race; the focused identifier tests are
  single-threaded. Environment blocker.
- `focused_memcheck`: exit `127`, Valgrind missing (see §4).

### 8.7 Coverage (T7/T8) — below platform goals, focused scope

`focused_coverage/result.json:339-358`: over `service_identifier.cpp` + `string_registry.cpp`,
line `36/36 = 100 %`, branch `11/14 = 78.6 %`, `complete_target_scope: false`,
`safety_class: "unknown_requires_authorized_selection"`, platform goals `QM 85 / safety 100`.
Branch coverage is below even the QM goal; the `native_coverage` collector's
`COVERAGE_THRESHOLD=73` is explicitly *"Repository CI threshold 73 is not platform 85/100
line-and-branch acceptance"*. An older collection retained `77.8 % / 64.3 %`.

### 8.8 CodeQL MISRA (T5/T6) — draft mapping; in-scope hits are gtest macros

`codeql_misra/result.json` blockers (`:236-238`): *"MISRA applicability/mapping draft and
incomplete"*, *"Default suite omits manual/audit obligations"*, *"Compiled query qualification and
human deviations pending"*. Findings are (a) `…self-assignment` in
`.llm_tmp/googletest/…/gtest-filepath.h` (dependency) and (b)
`external-linkage-not-declared-in-header-file-misra` on `service_identifier_tests.cpp` `TEST_F`
lines — the gtest `TEST_F` macro expansion, not the authored bodies. `misra_mapping.rst` is
`:status: draft`. **No MISRA C++:2023 compliance can be claimed.**

### 8.9 Secret/dependency scan — inventory only, no scan

`secret_dependency_checks/result.json` blocker (`:236`): *"No adopted vulnerability
database/ecosystem mapping or GitHub dependency scan receipt; dependency inventory is not a
vulnerability scan"*. `gitleaks` unavailable. A dependency inventory and
`lock_sha256: c90b245bc0f8aadea595e2d3bc618325e064b371d88544bcb787b1afb28564b6` (`:387`) were
retained. Not a scan result.

### 8.10 Process / metadata

`process_checks/result.json`: `completed_with_blockers`; metadata inventory shows
`runtime_tests.cpp` 33 test macros and `service_identifier_tests.cpp` 87 test macros, each with
`DerivationTechnique` and `Description`; `TestType`/`Verifies` deliberately unset (no invented
requirement IDs). Blockers: *"Lexical metadata inventory cannot prove semantic requirement
coverage"*, *"Safety/QM applicability and approved tailoring unknown"*, *"Independent inspection
and acceptance required"*.

---

## 9. Confidence / qualification evidence inventory (what exists vs. what is required)

`tool_management.rst` defines the work product as a **Tool Verification Report** per tool, using
the template `gd_temp__tool_management_verif_rpt_template`, checked with
`gd_chklst__tool_cr_review`, and advanced through statuses `identified → evaluated → qualified →
released` (or `rejected`). The following inventory maps what this run has against each stage.

| Stage (tool_management.rst) | Required evidence | Present in this slice? |
|-----------------------------|-------------------|------------------------|
| Identification | name/UID + version + location; configuration per `doc__config_mgt_plan` | **Partial.** Present for the 11 collector tools (§3) and 6 missing tools (§4); repository pins captured (§5). No per-tool UID/report file. |
| Evaluation | tool impact (Y/N), tool error detection (Y/N), TCL (HIGH/LOW) | **Absent.** Only draft *questions* here (§7); no authorized rating. Safety class `unknown` blocks the judgment. |
| Qualification (if TCL LOW) | tool requirements, malfunction/threat analysis, safety/security measures, test cases, test report; report updated to `qualified` | **Absent.** No requirement set, no malfunction analysis, no qualification test report. |
| Approval | authorized human releases (`released`) or rejects (`rejected`) | **Absent/pending.** `engineering_acceptance: pending`, `human_reviews: unanswered`. |

### 9.1 Positive evidence that does exist (for a later report)

- Exact tool executables and sha256 digests (T1–T11, §3).
- Exact versions for 9 of the probed tools (§3, §6).
- Repository toolchain pins and dependency versions (§3.2, §5).
- Snapshotted configuration digests for `.bazelversion`, `.bazelrc`, `.clang-tidy`,
  `.clang-format`, `tools/lint/linters.bzl` (§5.1).
- Collector-harness script digests (§3.1).
- Retained, scoped execution records for GCC, clang, clang-tidy (config-verify), cppcheck, CodeQL
  security/MISRA, ASan/LSan/UBSan, TSan, gcov/gcovr, QEMU prerequisites and perf version.

### 9.2 Gaps that preclude any qualification claim

- No tool requirement, malfunction/threat analysis, or qualification test report for any tool.
- No error-detection argument (nothing proves a malfunction would be caught).
- Version drift between collector and pinned toolchain (§5).
- Absent tools (Bazel, Valgrind, gitleaks, clang-format, pre-commit, reuse) and absent Coverity.
- Unknown safety class → the applicable rigor/acceptance level is unselected.
- Unanswered human reviews → no independence, no approval.

**Statement.** Tool *execution* (or non-execution) does **not** qualify any tool. Owner acceptance
stays pending; nothing here may be marked `qualified` or `released`.

---

## 10. Tool-impact and error-detection question sheet (step-by-step, to be completed by owners)

For each tool, the authorized evaluator must answer, on the record:

1. **Purpose & usage** in the S-CORE context for this slice (which obligation does it serve?).
2. **Malfunction/threat list** for that tool and usage.
3. **Step 1 (impact):** based on those malfunctions/threats, could any safety or security
   requirement be violated? (YES/NO). If NO, TCL = HIGH.
4. **Step 2 (error detection):** can each such malfunction be detected or prevented by other
   means (tests, reviews, independent tools, tool self-checks)? (YES/NO).
5. **Step 3 (TCL):** LOW iff impact YES and detection NO; otherwise HIGH.
6. If LOW: produce the qualification (requirements, malfunction analysis, measures, tests, report)
   and update the Tool Verification Report to `qualified`.
7. **Approval:** authorized human sets `released` (or `rejected`).

Applicability note: for **QM** parts `verification_plan.rst:209-211` permits reduced rigor, but the
safety class here is `unknown`, so the reduced-rigor route is not yet selectable. The tools that
touch criterion 8 (static-analysis closure) and criterion 9 (warnings/errors) are the highest
priority: T1–T6 and Bazel.

---

## 11. Observed findings that touch (or appear to touch) the bounded slice

| Tool | Finding | On a candidate path? | Tool-assurance reading |
|------|---------|----------------------|------------------------|
| GCC 12.3.0 | compile exit 0; tests exit 0 (85/85 retained) | yes (clean) | confirms no syntax defect (§2); focused only |
| Clang 19.1.7 | googletest/libstdc++ `-Wdeprecated-declarations` under `-Werror` | no (dependency) | blocks the clang branch of criterion 9 |
| clang-tidy 19.1.7 | none produced (`--verify-config` exit 1) | n/a | **not run**; version/config drift (§5, §8.4) |
| cppcheck 2.7 | 19 `passedByValue` | no (headers) | out-of-scope style noise |
| CodeQL security 2.21.4 | 32 findings, all under `.llm_tmp/googletest/…` | no | dependency-only; focused extraction |
| CodeQL MISRA 2.61.0 | self-assignment (gtest dep) + `external-linkage` on `TEST_F` lines | macro artifact | needs human deviation / macro-aware tooling |
| ASan/LSan/UBSan | focused tests exit 0 | yes (pass, focused) | single-threaded identifier scope |
| TSan | `unexpected memory mapping` | n/a | environment/kernel blocker |
| gcovr 5.0 | 100 % line / 78.6 % branch, two files | partial | below QM/safety branch goal; focused |
| Valgrind / gitleaks | tool absent | n/a | blocker |

No finding points into `service_identifier.cpp`, `service_identifier.hpp`, or the author-written
test bodies; the only in-scope-looking MISRA hits are the gtest macro expansion.

---

## 12. Notice, licence and write-surface preservation

- No source, build, test, config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was created, edited,
  or deleted by this iteration; **only this report was written.**
- The flagged header `score/socom/impl/service_identifier.hpp` was inspected and left unchanged
  because it is already balanced and well-formed (§2); its Apache-2.0 / SPDX header (`:1-12`) is
  intact, as are those of the sibling `.cpp`, both BUILD files, and both candidate test files.
- All 12 files under `.llm_tmp/overnight/prior-reports/` and all 24 earlier files under
  `.llm_tmp/overnight/reports/` were preserved unchanged; this document is the 25th `reports/`
  entry.
- This report itself carries the Apache-2.0 header.

---

## 13. Obligations status for the tool-assurance slice (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Tools identified (name/UID + version + configuration) | `tool_management.rst:64-81` | **PARTIAL/DRAFT** — 11 present + 6 absent identified with versions/digests (§3–§5); no per-tool verification-report work product |
| Tool impact determined | `tool_management.rst:92-104` | **NOT DONE** — only draft questions (§7); safety class `unknown` |
| Tool error detection determined | `tool_management.rst:108-114` | **NOT DONE** |
| Tool confidence level / qualification where required | `tool_management.rst:116-147` | **NOT DONE** — no requirements, malfunction analysis, or qualification tests |
| Tool Verification Report released/rejected | `tool_management.rst:149-156` | **PENDING** — owner acceptance outstanding |
| Freedom from static-analysis findings (critical/high) | `verification_plan.rst:329-331`; criterion 8 | **NOT SATISFIED** — clang-tidy not run; CodeQL focused/dependency-only; cppcheck out of scope; no classification/closure |
| Freedom from compiler warnings & errors 100 % | `verification_plan.rst:332-335`; criterion 9 | **NOT MEASURED (native)** — focused GCC clean; clang blocked; default build disables warnings-as-errors (`.bazelrc:117`) |
| Coverage goals (85 % QM / 100 % safety) | `verification_plan.rst:300-307` | **NOT MEASURED to goal** — focused 100 % line / 78.6 % branch; `complete_target_scope: false` |
| Unit/component tests executed & recorded | `verification_plan.rst:320-327` | **PARTIAL/STALE** — focused 85/85 retained; `runtime_tests.cpp` and native `socom_test` not run |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` (draft) | **UNKNOWN — NOT CLAIMED** |
| Secret/vulnerability scanning | `code_analysis.rst`; dependency hygiene | **NOT SATISFIED** — gitleaks absent; inventory is not a scan |
| Independence of verification / review | `verification_process.rst:141-152` | **NOT DONE** — human reviews unanswered |
| Native acceptance | `.llm_tmp/context/obligations/source-index.json` | **`not_inferred`** for every entry |

**Explicit non-satisfaction statement.** Missing tools, the collector-vs-pinned version drift, the
un-inferred applicability, the incomplete/focused extraction, the unknown safety class, and the
unanswered human reviews mean **none of the checked obligations may be treated as satisfied**. A
retained collection result shows *retention*, not passing, and tool execution does not qualify a
tool.

---

## 14. Pending human review checklist (owner acceptance required)

- [ ] **Confirm §2**: `service_identifier.hpp` is brace-balanced (brace lines `:19,:29,:32,:38`;
      line 39 blank). The recorded "extra closing brace at line 39" is stale / refers to a
      different revision. No source correction is required in this checkout; resolve the
      "correct-the-source vs. review-draft-only" instruction conflict for the record.
- [ ] **Accept or reject the collector-vs-pinned tool drift (§5)**: decision needed on whether
      clang/clang-tidy 19.1.7 evidence is admissible for the LLVM `22.1.7` pin, and whether the
      GCC 12.2.0/12.3.0 minor difference is acceptable.
- [ ] **Repair the `.clang-tidy` `Checks: >` folded block** and re-evaluate the two identifiers
      absent from the pinned LLVM version, via an authorized change; do not suppress checks in this
      slice.
- [ ] **Reconcile the Coverity discrepancy** (`code_analysis.rst` names it; `development_plan.rst`
      tool list does not; it is not installed): adopt, tailor-out with rationale, or remove.
- [ ] **Locate or provide** the documented "GitHub CodeQL" CI integration vs. the local,
      no-upload CodeQL 2.21.4 collector run (§5).
- [ ] **Complete the tool-impact / error-detection / TCL evaluation (§7, §10)** for T1–T11 and the
      collector harness, and qualify where TCL is LOW, using
      `gd_temp__tool_management_verif_rpt_template` and `gd_chklst__tool_cr_review`.
- [ ] **Restore the missing tools** (Bazel at `/tmp/s-core-001/bin/bazel`, Valgrind, gitleaks,
      clang-format, pre-commit, reuse) so the `native_*`, `cross_compilation`, `format_precommit`,
      `focused_memcheck` and secret-scan obligations can produce real results.
- [ ] **Provide TSan-capable environment or an accepted exclusion**, and re-run the focused
      sanitizer set on the current tree (87 cases, hash `4df2c63c…`).
- [ ] **Run the full native suite** (`//score/...` including `runtime_tests.cpp`, plus the
      integration/QEMU set) and record pass/fail and coverage against the platform goals; do not
      report the 73 threshold as acceptance.
- [ ] **Disposition** the cppcheck `passedByValue` findings and the CodeQL MISRA gtest-macro hits
      (accepted deviation or macro-aware tooling) — outside the bounded slice.
- [ ] **Keep the wider #84 public `Service_interface_identifier` restructure, FindService wildcard
      and config minor-wildcard narrowing out of this bounded slice** until separately accepted,
      and do not present the identifier-only tests as platform validation.

---

## 15. Method and truthfulness statement

- **Tools used:** `read_file`, `grep`, `glob`, `write_file` only. No `shell`, delegation, web,
  approval, publishing, or engineering acceptance.
- **Measurements executed this iteration:** none. Every number is a reading of the retained
  collector/validation artifacts or of the working tree; expected behaviours are labelled as
  source-derived.
- **Scope:** local, unprotected, scoped. The retained compile/analyze/sanitize/coverage runs cover
  the focused identifier translation unit only; full native runtime tests are `not_executed`
  (`validation/measurement.json:2042`).
- **Truthfulness:** no finding is suppressed or reclassified; absent tools and rejected configs
  are recorded as blocked, not as clean passes; no invented requirement identifiers or
  qualifications appear.
