<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — cross-target review (`cross_target_review`, refreshed)

**Document type:** review draft (x86_64/aarch64 Linux cross-build result review +
documented QNX/toolchain obligations + S-CORE-vs-integrator boundary + actual-source
inspection + obligations status).

**Date:** 2026-10-03
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version
handling in socom* (issue #84)
**Run / branch:** `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ`; current HEAD `fc8c760`
(`fabro(01M3ZRSDK2XQAF1H48VWTPKQNZ): node_fbd3fac249c4bb138b35aa00 (success)`, per the
run environment and `.git/logs/HEAD:84`). At least 84 stages of this run have been
committed; one recorded stage committed earlier in the run failed
(`node_752868eb24b56f82737549dd`, `.git/logs/HEAD:15`), and the latest supplied
completed stages include `node_fbd3fac249c4bb138b35aa00`.
**Verified baseline commit:** `f8a196c3b16d5172d898394ab99b0ed81346d63d`
(`.llm_tmp/context/source-manifest.json:3`).
**Status:** **local, unprotected, scoped.** No engineering acceptance exists. Human
reviews are unanswered. Full native runtime tests are pending. Nothing in this document
is acceptance, review approval, publication, or a full native run.

> **Tool / write boundary actually observed.** Only `read_file`, `grep`, `glob`, and
> `write_file` were used. No `shell`, no delegation, no web access, no approval, no
> publishing, and no engineering acceptance was performed. The task's explicit final
> sentence — *"This is a review draft: only that report may be written."* — is the
> controlling write boundary. A single `update_plan` invocation was refused by the
> environment ("Overnight tool/path boundary"); it produced no output and no change.
> Accordingly **exactly one file was written: this report**
> (`/workspace/.llm_tmp/overnight/reports/cross_target_review.md`). No source, build,
> test, config, `NOTICE`, `LICENSE`, `REUSE.toml`, host-validation, or prior-report
> file was created, edited, or deleted. Every earlier report under
> `.llm_tmp/overnight/reports/` and every file under `.llm_tmp/overnight/prior-reports/`
> was preserved unchanged — including the earlier `cross_target_review.md` under
> `prior-reports/`, which this document does **not** overwrite.
>
> **The recorded GCC syntax failure is not present in the actual source
> (re-verified this iteration).** The task records *"a measured GCC syntax failure: an
> extra closing brace in `score/socom/impl/service_identifier.hpp` at line 39"* and
> directs *"Inspect and correct the actual source before expanding tests."* Direct
> `read_file` on the current working tree (§2) shows the header is **brace-balanced**:
> openers at `:19` (`namespace score::socom {`) and `:29`
> (`struct Service_instance_identifier final {`); closers at `:32` (`};`) and `:38`
> (`}  // namespace score::socom`). Line `:39` is **empty**; `:40` is the `#endif`. Two
> openers, two closers, net balance `0`; a dedicated `grep` for `{` returns only `:19`
> and `:29`, and for `}` only `:32` and `:38`. There is no unmatched closing brace to
> remove, so applying the recorded repair would be a no-op at best and a compile break at
> worst. **No source write was made and none is required.** The conflict between "correct
> the actual source" and "only that report may be written" is recorded for human
> disposition (§2.3, §11).
>
> **Non-satisfaction rule applied throughout.** A successful obligation-collection node
> means the results were **retained**, not that the checks **passed**. Missing tools,
> unknown applicability, incomplete extraction, ungranted SDK entitlements, and
> unanswered human reviews are **not** treated as satisfied. A check that produced **no**
> finding because it **did not run** is recorded as *"not run"*, never as *"clean"*. In
> particular, *no QNX credential was acquired and no qualification is inferred anywhere
> in this report*.

---

## 0. Summary

1. **The x86_64-linux and aarch64-linux cross-builds succeeded (this is the material
   change from the earlier cross-target draft).** The retained `cross_compilation`
   collector ran exactly two builds —
   `bazel build --config=x86_64-linux //score/... //tests/...` and
   `bazel build --config=aarch64-linux //score/... //tests/...` — and **both exited `0`**.
   Their captured stderr each ends with `INFO: Build completed successfully`
   (`x86.stderr:8567`, `1526 total actions`; `arm.stderr:347`, `1147 total actions`), and
   a `grep` of the two legs for `ERROR:`/`Build did NOT complete`/`FAILED TO BUILD`
   returns nothing. The check status is `completed_with_blockers`; the only retained
   blocker is QNX-related (§3).
   **This supersedes the earlier reading** in
   `.llm_tmp/overnight/prior-reports/cross_target_review.md` §3, which recorded both legs
   at `exit 127` (`'/tmp/s-core-001/bin/bazel'` missing). The `bazel` driver is now present
   (`obligations/tool_assurance/result.json` `tool_inventory`), and the collectors were
   recollected (`check_ref: recollect_cross_compilation`). Both legs remain **build-only**:
   no cross-target test was executed.
2. **The `cross_compilation` blocker names QNX, although the commands it ran are
   Linux-only.** The retained `blockers` array is
   `["QNX SDK entitlement and target execution not configured; no credential acquired"]`,
   while the two recorded commands use `--config=x86_64-linux` and
   `--config=aarch64-linux`. QNX was not attempted by this collector at all, and its
   entitlement remains an untested blocker (§3.4, §5).
3. **QNX is a *documented but unexecuted* obligation.** The repository documents a full
   QNX path — CI workflow `build_and_test_qnx.yml` (reusable
   `eclipse-score/cicd-workflows/.../qnx-build.yml@8d80e8df… # v.0.0.3`, matrix
   `x86_64-qnx`/`aarch64-qnx`, targets `//score/... //tests/...`, test targets
   `//quality/... //tests/integration_test/...`), the credential helper
   `.github/tools/qnx_credential_helper.py`, `SCORE_QNX_LICENSE`/`SCORE_QNX_USER`/
   `SCORE_QNX_PASSWORD` secrets, `.bazelrc` `x86_64-qnx`/`aarch64-qnx` configs, QCC +
   imagefs toolchains referenced from `MODULE.bazel`, and QNX-specific patches under
   `third_party/`. **None of it executed in this run**, because no QNX SDK
   entitlement/credentials were configured (§5).
4. **The bounded slice is Level-1-only; target/platform integration is the integrator's
   obligation.** S-CORE's verification plan defines three levels and states the
   *"integration of the platform on a target device and the respective verification and
   validation should be considered by the distributor of the platform"*, with S-CORE
   running reference-hardware tests only "as a starting point" and *"The reference
   hardware is not yet decided."* The duplicate-server registration-key change is a
   `socom` internal identity change with unit tests; it has no feature requirement, no
   platform test, and no target execution (§6).
5. **No obligation is satisfied.** Every `source-index.json` entry is
   `native_acceptance: not_inferred`; `authority.json` records
   `engineering_acceptance: pending`, `human_reviews: unanswered`,
   `safety_class: unknown`. The retained obligation results are scoped: the Linux
   cross-builds are green but build-only, the QNX legs were never run, and the native
   test/sanitizer legs were built with `--build_tests_only` (§8).

---

## 1. Binding to the baseline, issue, prior reports, and retained host artifacts

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` — *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:2-4` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` (unchanged) | `.llm_tmp/context/issue-snapshot.json:19-20` |
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |
| Branch | `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ` | run environment |
| Current HEAD | `fc8c760` — `node_fbd3fac249c4bb138b35aa00 (success)` | `.git/logs/HEAD:84` |

The issue body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an
accepted obligation**. It distinguishes service-instance identifier = `service id + major
+ minor + instance id`, service identifier = `service id + major`, FindService =
`service id + major + optional<minor> + optional<instance>`, and proposes to exclude
`minor` and make it a property of the service instance. The FindService `major = FF`
AUTOSAR case is called theoretically possible but not useful. There is no comment and no
acceptance record, so none of the proposal binds this review. Binding is **by baseline
commit**, not by run HEAD.

### 1.2 In-scope candidate files

From `.llm_tmp/context/candidate-files.json:1-25`:

| File (repo-relative) | Baseline git blob | Baseline present | Working-tree state read this iteration |
|----------------------|-------------------|------------------|----------------------------------------|
| `score/socom/BUILD` | `3477ea0851fdcd82ec6ea9d71424013cbdf41962` | yes | `socom` library + `testonly` `impl_service_identifier` exposure |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e22355242009fe20dada2a9a0d0c7a9c7` | yes | order key `(instance, service id, major)`; `minor` excluded (`:28-29`) |
| `score/socom/impl/service_identifier.hpp` | `c8bae7908da9f087c518934f7b9f8d86db9a20ec` | yes | brace-balanced, 40 lines, `:39` blank (§2) |
| `score/socom/test/unit/BUILD` | `3c03a7b14286051f97fa5022206564bd63645171` | yes | `socom_test` globs `*.cpp` |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab726db8bf994c960045d6fd7fdf84d7395` | yes | 33 test macros (`process_checks/result.json`) |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(none — `null`)* | no (manifest expects a new file) | 91 test macros (`process_checks/result.json`) |

The `null` baseline blob is the manifest's expectation of a **new** unit-test file; it
exists only in the un-merged working tree (the "cancelled draft").

**Working-tree drift is recorded, not reconstructed.** The candidate-snapshot hashes in
`candidate-files.json` differ from the hashes the obligation collectors recorded for the
tree they snapshotted: e.g. `service_identifier.cpp` candidate `d766902e…` vs collector
`3c12b3f1…`; `service_identifier.hpp` candidate `96b33a1f…` vs collector `bdce3fcb…`;
`service_identifier_tests.cpp` candidate `45d07399…` vs collector `4df2c63c…`/`de79767c…`
(`candidate-files.json:6-25`; `obligations/cross_compilation/result.json:126-127,190`).
A hash is not a content diff; the drift is flagged so the candidate set is not mistaken
for the collector's tree. No hashing tool was available in this task.

### 1.3 Prior reports read and preserved

`.llm_tmp/overnight/prior-reports/` contains **38 files**, all preserved unchanged. For
this cross-target review the most load-bearing earlier reports are:

- `prior-reports/cross_target_review.md` — the earlier cross-target draft on the same
  baseline; its §3 recorded both Linux cross legs at `exit 127`. This document updates
  that finding and does not overwrite the earlier file.
- `prior-reports/bazel_plan.md` — the native/cross-target invocation plan, including
  Stage 7 (`--config=x86_64-linux`, `--config=aarch64-linux`).
- `prior-reports/native_build_review.md` — native-build/toolchain identity.
- `prior-reports/integration_aou_review.md` — the S-CORE-vs-integrator split and the
  external-AoU review.
- `prior-reports/compatibility.md`, `prior-reports/scope.md`,
  `prior-reports/reproducer.md`, `prior-reports/key_fix.md` — the bounded slice, the
  brace reconciliation, and the key semantics.

`.llm_tmp/overnight/reports/` was read, not modified; this document adds
`cross_target_review.md` to it.

### 1.4 Retained host validation and obligation-collection results (present, scoped)

`.llm_tmp/overnight/validation/`:

| Artifact | Content (retained) |
|----------|--------------------|
| `check-result` | `0` (collector retention marker only) |
| `measurement.json` (`:2039-2059`) | `origin: local_unprotected_measurement`, `initiator: Fabro host hook`, `engineering_acceptance: pending`, `full_native_tests: not_executed`, compiler `/usr/bin/x86_64-linux-gnu-g++-12`, `baseline_with_agent_tests` **91 tests / 33 failures / compile exit 0 / test exit 1**, `candidate` **91 tests / 0 failures / compile exit 0 / test exit 0** |
| `before-compile.stderr` / `after-compile.stderr` | empty (no recorded syntax failure) |

This is the **focused host identifier translation unit only**
(`service_identifier.cpp` + `string_registry.cpp` + `service_identifier_tests.cpp`, plus
googletest). It is not a Bazel build, does not compile `runtime_tests.cpp`, and does not
touch any cross target.

`.llm_tmp/overnight/obligations/` retains the full check set. **Retention is not
passing.** The cross-target-relevant ones read this iteration:

| Check | Retained status | Cross-target relevance |
|-------|-----------------|------------------------|
| `cross_compilation` | `completed_with_blockers`; both legs `exit 0`; blocker *"QNX SDK entitlement and target execution not configured; no credential acquired"* | **Direct subject of this review** (§3) |
| `native_build` | `completed`; `exit 0` | Native build green |
| `native_tests` | `completed`; `exit 0`, but argv is `bazel test //... --build_tests_only` | **Tests built, not executed** |
| `native_integration` | `findings_or_execution_failure`; qemu command `exit 1`; prereqs `kvm_exists: true`, `qemu: /usr/bin/qemu-system-x86_64` | No QEMU/target execution |
| `native_coverage` | `exit 0` with `COVERAGE_THRESHOLD: 73` | Repository CI threshold, not the platform 85/100 goal |
| `compiler_diagnostics` | `completed`; focused GCC **and** Clang `-Werror` legs `exit 0`; limits: *focused executable only; GCC 12.3 / Clang 19 differ from native toolchain pins* | Host-only, focused TU |
| `tool_assurance` | `completed_with_blockers`; blockers: tool confidence/qualification requires authorized humans; Coverity not installed/adopted; memcheck optional | Tool qualification unestablished |
| `process_checks` | `completed_with_blockers`; inventory: `runtime_tests.cpp` 33 macros, `service_identifier_tests.cpp` 91 macros, each with only `DerivationTechnique`/`Description` | Metadata, not semantic coverage |

### 1.5 Pinned obligation sources and authority

All nine entries of `.llm_tmp/context/obligations/source-index.json` are present with
`authority.json`; every entry is `"native_acceptance": "not_inferred"`.
`authority.json` records:

| Field | Value |
|-------|-------|
| `codeql_scope` | Public Apache-2.0 `eclipse-score/inc_someip_gateway`; **no upload** |
| `engineering_acceptance` | **pending** |
| `human_reviews` | **unanswered** |
| `safety_class` | **unknown** |
| `instruction` | "Restart the failed queue for one complete pass through all obligations" |

`misra_mapping` and `inspection_checklist` are `:status: draft`; the others are
`:status: valid`. Cross-target-relevant pinned content read this iteration:
`development_plan.rst:165-167` (GCC host compiler; *"QCC the qualify-able
compiler/linker from Blackberry offered together with its Posix conform Operating System
QNX is planned to be used for target compilation"*);
`verification_plan.rst:64-67` and `:145-150` (integrator/distributor split; reference
hardware as an optional starting point) and `:590-610` (POSIX simulation environments on
aarch64/x86_64 with **QNX and Linux** flavours; *"The reference hardware is not yet
decided."*). This document treats QCC as *planned*, never as qualified.

---

## 2. Actual-source state of the bounded slice (inspection only)

### 2.1 The recorded syntax failure is not present

`score/socom/impl/service_identifier.hpp` is 40 lines and **brace-balanced**:

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace (C++17 nested form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`), two closers (`:32`, `:38`): net balance `0`. A dedicated
`grep` for `{` returns only `:19` and `:29`; for `}` only `:32` and `:38`. The "extra
closing brace … at line 39" matches the **stale, pre-correction** description in the
earliest prior reports (which quoted the split form `}  // namespace socom` +
`}  // namespace score`); the `reproducer` iteration applied the correction and left line
39 blank. The sibling `impl/service_identifier.cpp` uses the same nested form and is
balanced. Retained corroboration: `compiler_diagnostics` focused GCC **and** Clang
`-Werror` legs `exit 0` (`obligations/compiler_diagnostics/result.json`,
`status: completed`); `validation/after-compile.stderr` empty.

### 2.2 The registration key is present and minimal

`score/socom/impl/service_identifier.cpp:20-30` orders by
`std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major)`, so the
duplicate-server identity is `(instance, service id, major)` and **`minor` is excluded**,
matching the deliberately minor-ignoring `Service_database` index. The public
`Service_interface_identifier{Id, Version{major, minor}}` representation and the
exact-major / `client.minor <= server.minor` compatibility rules are unchanged and are
not part of the key. The key type is `impl/`-only, reached only through the `testonly`
`//score/socom:impl_service_identifier` library. This slice is unit-level only and has
no target-specific code path — so a cross-build pass or failure cannot, on its own,
prove or refute the key behaviour.

### 2.3 Disposition

Because the actual source is already correct and the write boundary permits only this
report, **no source edit was made**. If the "cancelled draft" is a *distinct* revision
that still carries an extra brace, it is not the file in this checkout; it would have to
be located and corrected by an authorized iteration. The conflict between "correct the
actual source" and "only that report may be written" is carried to the human reviewer
(§11) rather than silently resolved. No test was expanded; the draft suites already exist
(§1.4).

---

## 3. x86_64/aarch64 Linux cross-build results

### 3.1 Exact retained invocation and outcome (recollected)

From `obligations/cross_compilation/result.json:1055-1111` (and the per-leg command files
`x86.command.json`, `arm.command.json`):

| Leg | argv (abridged) | cwd | timeout | exit | captured tail |
|-----|-----------------|-----|---------|------|---------------|
| `x86` | `<tools>/bin/bazel --batch --output_user_root=<run>/bazel-cache build --jobs=2 --config=x86_64-linux //score/... //tests/...` | `<run>/native-workspace` | 390 s | **0** | `x86.stderr:8567` — `INFO: Build completed successfully, 1526 total actions` |
| `arm` | `<tools>/bin/bazel --batch --output_user_root=<run>/bazel-cache build --jobs=2 --config=aarch64-linux //score/... //tests/...` | `<run>/native-workspace` | 390 s | **0** | `arm.stderr:347` — `INFO: Build completed successfully, 1147 total actions` |

`check_ref: recollect_cross_compilation`; `origin: local_unprotected_measurement`;
`engineering_acceptance: pending`; `status: completed_with_blockers`;
`blockers: ["QNX SDK entitlement and target execution not configured; no credential
acquired"]` (`result.json:1052-1054,1113`). A `grep` of both legs for `ERROR:` /
`Build did NOT complete` / `FAILED TO BUILD` returns nothing. The captured stderr does
contain non-fatal dependency warnings (e.g. `-Wdeprecated-declarations` from the
`flatbuffers` **host tool** build and a deprecation warning from
`score/mw/com/runtime.cpp` in the aarch64 leg); these are warnings, not errors, and the
builds completed.

> **Update vs. the earlier draft.** `prior-reports/cross_target_review.md` §3 recorded
> both legs at `exit 127` with `[Errno 2] No such file or directory:
> '/tmp/s-core-001/bin/bazel'`. That was an **unavailable-driver blocker** at the time.
> The recollected artifact now shows a present `bazel`
> (`obligations/tool_assurance/result.json` `tool_inventory`, `available: true`) and both
> legs exiting `0`. The earlier `exit 127` reading remains a true record of the earlier
> collector run; it has simply been superseded for the current tree.

### 3.2 What this does and does not establish

- **Establishes:** `//score/...` and `//tests/...` **compile** for the
  `x86_64-linux` and `aarch64-linux` Bazel configs in this run, and the collectors
  retained real compiler/Bazel output (`Build completed successfully`). That is a genuine
  build pass for the two Linux target configs.
- **Does not establish:** that any cross-target **test executed** (both legs are
  `bazel build`, and the CI workflow likewise only builds — §4); that the aarch64
  **binaries run** on aarch64 hardware/emulation; that the registration-key behaviour is
  exercised at target level; or that QNX builds.
- The two legs are still **local, unprotected, and scoped**: `engineering_acceptance:
  pending`, and the run is not an independent verification. Per the non-satisfaction
  rule, a retained collection node proves *retention*, not acceptance.

### 3.3 What the repository intends these legs to do

`.github/workflows/build_and_test_cross_compilation.yml:17-50` runs a matrix
`bazel-config: ["x86_64-linux", "aarch64-linux"]` on `ubuntu-24.04` and executes
`bazel build --config <config> //score/... //tests/...` (`:44-47`). It carries two open
TODOs: build all targets `//...` "once python toolchain issue is resolved" (`:45-46`) and
*"Run tests on QEMU"* (`:50`). So even in CI the cross legs are **build-only**; they do
not run the cross-target tests, and they do not cover QNX. The retained collector matches
this intent.

### 3.4 The Linux/QNX coupling in the recorded blocker

The retained blocker text names QNX entitlement, but the two commands are Linux-only.
The accurate reading is:

1. the **Linux** legs **passed the build** in this recollected run; and
2. **QNX** was not attempted by this collector, so its entitlement/SDK status is an
   *additional, independently unverified* blocker unrelated to the two Linux legs.

Both halves matter: the Linux cross-builds are green but build-only, and QNX requires a
separate, credentialed path (§5). Neither may be reported as full cross-target
verification.

---

## 4. Documented cross-target configuration (for a later authorized run)

Read directly from `.bazelrc:27-85`:

| Config | Platform | Toolchains | `TARGET_ARCH` |
|--------|----------|------------|---------------|
| `x86_64-linux` | `@score_bazel_platforms//:x86_64-linux` | `@score_gcc_x86_64_toolchain//:all` | `x86_64` |
| `aarch64-linux` | `@score_bazel_platforms//:aarch64-linux-gcc_12.2.0-posix` | `@score_gcc_aarch64_toolchain//:all` | `aarch64` |
| `x86_64-qnx` | `@score_bazel_platforms//:x86_64-qnx-sdp_8.0.0-posix` | `@score_qcc_x86_64_toolchain//:all`, `@score_qnx_x86_64_ifs_toolchain//:all` | `x86_64` |
| `aarch64-qnx` | `@score_bazel_platforms//:aarch64-qnx-sdp_8.0.0-posix` | `@score_qcc_aarch64_toolchain//:all`, `@score_qnx_aarch64_ifs_toolchain//:all` | `aarch64` |

- `common:_toolchain_common` pins the host to `x86_64-linux` and adds
  `@score_gcc_x86_64_toolchain` (`.bazelrc:44-46`).
- `common --credential_helper=*.qnx.com=%workspace%/.github/tools/qnx_credential_helper.py`
  (`.bazelrc:71`).
- `test:qemu-integration` and `test:x86_64-qnx`/`test:aarch64-qnx` force the
  linux-sandbox strategy for `*integration_test*` rules and run under
  `@score_itf//scripts:run_under_qemu` (`.bazelrc:79-85`).

Bazel version is pinned to `8.6.0` (`USE_BAZEL_VERSION` in every collector env). The
intended cross-target commands (from `prior-reports/bazel_plan.md` §4.2 Stage 7, matching
the collector argv) are:

```bash
bazel build --config=x86_64-linux  //score/... //tests/...   # retained: exit 0 (2026-10-03)
bazel build --config=aarch64-linux //score/... //tests/...   # retained: exit 0 (2026-10-03)
# QNX (requires entitlement + credentials; NOT attempted and NOT to be attempted without authorization):
bazel build --config=x86_64-qnx    //score/... //tests/...
bazel build --config=aarch64-qnx   //score/... //tests/...
```

The QNX toolchain lines above are **declare-in-Bazel** facts; whether the QCC/SDP packages
can actually be fetched depends on the QNX entitlement, which is not configured here.

---

## 5. Documented QNX obligations (unexecuted; entitlement is a hard blocker)

### 5.1 What is documented

| Obligation / artifact | Location | Content |
|-----------------------|----------|---------|
| QNX CI job | `.github/workflows/build_and_test_qnx.yml:17-40` | Reusable `eclipse-score/cicd-workflows/.github/workflows/qnx-build.yml@8d80e8df… # v.0.0.3`; matrix `x86_64-qnx`/`aarch64-qnx`; build `//score/... //tests/...`; test `//quality/... //tests/integration_test/...`; `credential-helper: ".github/tools/qnx_credential_helper.py"` |
| QNX secrets | same file, `:37-40` | `score-qnx-license` ← `secrets.SCORE_QNX_LICENSE`; `score-qnx-user` ← `SCORE_QNX_USER`; `score-qnx-password` ← `SCORE_QNX_PASSWORD` |
| Bazel configs | `.bazelrc:59-71,82-85` | `x86_64-qnx`/`aarch64-qnx` platforms + QCC/imagefs toolchains; `test:*qnx` run under QEMU |
| Credential helper | `.github/tools/qnx_credential_helper.py` | Reads `SCORE_QNX_USER`/`SCORE_QNX_PASSWORD` (or `.netrc`), logs into `https://www.qnx.com`, returns the `myQNX` cookie for `*.qnx.com` downloads |
| Toolchains | `MODULE.bazel` (QCC SDP / QNX IFS imagefs toolchains) | Declared in Bazel; not fetched here |
| QNX patches | `third_party/*qnx*.patch`, `third_party/score_baselibs/restore_qnx8_poll_workaround.patch` | QNX-specific patches to dependencies/tooling |
| Target compiler | `.llm_tmp/context/obligations/development_plan.rst:165-167` | "QCC the qualify-able compiler/linker from Blackberry … is **planned** to be used for target compilation" |

### 5.2 Why this is a blocker, not a status

- **The entitlement is not configured.** `cross_compilation/result.json:1052-1054`
  records *"QNX SDK entitlement and target execution not configured; no credential
  acquired"*. No QNX artifact, log, or target result is retained anywhere in
  `.llm_tmp/overnight/obligations/`.
- **The QNX legs were never attempted** by the obligation collector (only the two Linux
  configs appear in `commands[]`). The QNX workflow is a *CI-only* path that requires
  repository secrets this workspace does not hold.
- **No credential was acquired and none may be.** This review does **not** read
  `.netrc`, set `SCORE_QNX_*`, invoke `qnx_credential_helper.py`, contact `qnx.com`, or
  otherwise obtain access. It performs no download and no target execution.
- **No qualification is inferred.** QCC being "qualify-able" and "planned"
  (`development_plan.rst:165-167`) is not a tool-qualification record; the
  `tool_assurance` check is `completed_with_blockers` with tool confidence/qualification
  explicitly reserved to authorized humans and Coverity not adopted. Tool qualification
  is unestablished.
- **Target execution is absent.** No QNX image was built, no QEMU QNX boot was observed,
  and (separately) the Linux QEMU leg `native_integration` exited `1` despite
  `kvm_exists: true` and `qemu: /usr/bin/qemu-system-x86_64`.

### 5.3 QNX obligation status

| QNX item | Status here |
|----------|-------------|
| QNX SDK entitlement | **NOT CONFIGURED / unknown** — no credential acquired; do not infer |
| QNX toolchain availability (QCC/SDP) | **NOT VERIFIED** — declared in `MODULE.bazel`, never fetched |
| `x86_64-qnx` build | **NOT RUN** |
| `aarch64-qnx` build | **NOT RUN** |
| QNX integration tests (`//quality/...`) | **NOT RUN** |
| QNX8 QEMU target execution | **NOT RUN** |
| QNX-specific patches applied/validated | **NOT VERIFIED** |
| QCC tool qualification | **NOT ESTABLISHED** — "planned" only |

---

## 6. Integrator obligations and the S-CORE boundary

### 6.1 The three verification levels

`verification_plan.rst:124-150` defines:

1. **Software unit / component verification** — based on detailed design, component
   architecture, component requirements.
2. **Software integration verification (feature level)** — based on feature
   architecture and feature requirements.
3. **Software platform verification (Platform Integration Testing)** — on reference
   hardware, based on stakeholder requirements.

The bounded registration-key slice is a `socom`-internal identity change exercised only
at Level 1 (unit tests). There is no feature requirement and no feature/platform test
for version handling in this checkout.

### 6.2 The explicit integrator split

- `verification_plan.rst:64-67`: *"The integration of the platform on a target device
  and the respective verification and validation should be considered by the distributor
  of the platform. On target integration tests that are running on a reference hardware
  in context of this project can be taken as a starting point."*
- `verification_plan.rst:145-150`: *"The full Platform Integration Testing will be
  executed by the integrator. S-CORE project only executes tests on reference hardware.
  These tests serve as an optional base for the integrator … S-CORE will implement
  Platform Integration Tests for stakeholder requirements for demonstration, but these
  are not intended to completely covering all stakeholder requirements."*
- `verification_plan.rst:590-610`: the POSIX simulation environment covers aarch64 and
  x86_64 with **QNX and Linux** flavours, and *"The reference hardware is not yet
  decided."* The referenced AoUs `aou_req__platform__testing` and
  `aou_req__platform__test_completion` are cited but **not defined in this checkout**.

### 6.3 S-CORE reference vs final-product integrator obligations

| Obligation | Owner | Status here |
|------------|-------|-------------|
| Cross-build x86_64/aarch64 Linux (`//score/... //tests/...`) | S-CORE reference CI | **BUILD PASS (local, unprotected, build-only)** — both legs `exit 0` (§3) |
| Cross-target test execution (QEMU/Linux or target) | S-CORE reference CI | **NOT RUN** — the cross legs are `bazel build` only |
| QNX x86_64/aarch64 build + integration tests | S-CORE reference CI (entitlement-gated) | **NOT RUN / entitlement blocker** (§5) |
| QEMU POSIX-target integration tests | S-CORE reference CI | **NOT RUN** — `native_integration` exit `1` |
| Reference-hardware platform tests | S-CORE (optional base) | **NOT RUN / reference hardware not decided** |
| External-component AoU verification (`gd_req__verification_external_aou`, `verification_process.rst`) | S-CORE process automation | **NOT SATISFIED** — no integration test or static-analysis verdict |
| CI reference-integration execution (`gd_req__verification_ci_reference_execution`) | S-CORE | **NOT SATISFIED / applicability TODO** in the pinned requirement itself |
| Full platform integration + validation on the final target device | **Integrator / distributor** | **OUT OF PROJECT SCOPE**; unknown and not inferable here |

**Conclusion.** The QNX and final-product target obligations cannot be satisfied from
this workspace: the entitlement is not configured, no credential may be acquired, and
target execution is unavailable. They are recorded as **pending/blocked**, never as
passed, and no qualification claim is made.

---

## 7. What a later authorized iteration would need

This is a plan, not an executed measurement. It is retained so the gaps are actionable.

1. **Run the cross-target tests, not only the builds.** The Linux legs now build green;
   the missing step is executing the cross-built test binaries (the CI workflow's own
   TODO is *"Run tests on QEMU"*, `build_and_test_cross_compilation.yml:50`).
2. **Reconcile the working-tree drift** (§1.2) and the test-macro counts
   (91 key tests / 33 runtime macros, `process_checks`) before trusting any re-run.
3. **Obtain an authorized QNX SDK entitlement** through the approved secret/credential
   channel — this review must not and does not do so. Only after an entitled CI/env
   exists may the `x86_64-qnx`/`aarch64-qnx` builds and `//quality/...
   //tests/integration_test/...` runs be attempted.
4. **Target execution** on QNX (QEMU imagefs or reference hardware) remains the
   integrator's obligation; S-CORE provides only the reference base.
5. **Do not** report the retained build-only cross legs, the focused host identifier run,
   or `check-result: 0` as cross-target *verification* success.

---

## 8. Obligations status (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Cross-compilation x86_64-linux | `development_plan.rst`; `.bazelrc:49-52` | **BUILD PASS, NOT VERIFIED** — `exit 0`, `Build completed successfully`; retention ≠ acceptance; no test executed |
| Cross-compilation aarch64-linux | `development_plan.rst`; `.bazelrc:54-57` | **BUILD PASS, NOT VERIFIED** — `exit 0`, `Build completed successfully`; retention ≠ acceptance; no test executed |
| QNX x86_64/aarch64 build + test | `development_plan.rst:165-167`; `.github/workflows/build_and_test_qnx.yml` | **NOT RUN / SDK entitlement blocker**; no credential acquired |
| Target/QNX execution | `verification_plan.rst:590-610` | **NOT RUN** — target execution not configured; integrator-owned |
| Platform Integration Testing / reference hardware | `verification_plan.rst:138-150,590-610` | **NOT RUN** — reference hardware not decided; full scope is the integrator's |
| External-component AoU verification | `verification_process.rst` (`gd_req__verification_external_aou`) | **NOT SATISFIED** — no integration/static-analysis verdict |
| CI reference integration execution | `verification_process.rst` (`gd_req__verification_ci_reference_execution`) | **NOT SATISFIED / open TODO** |
| Freedom from compiler warnings & errors (100 %) | `verification_plan.rst` (criterion 9) | **NOT SATISFIED cross-target** — focused GCC/Clang host TU clean; dependency deprecation warnings appear in the cross builds; no symbol/target-level measurement |
| Unit/component tests executed and recorded | `verification_plan.rst` | **NOT EXECUTED under Bazel** — `native_tests` uses `--build_tests_only`; focused host TU only (`full_native_tests: not_executed`) |
| Integration (QEMU) | `verification_process.rst` | **NOT RUN** — `native_integration` exit `1` despite kvm/qemu present |
| Structural statement / branch coverage goals | `verification_plan.rst` | **NOT SATISFIED** — native coverage used the CI threshold 73, not the platform 85/100 goal |
| Tool identification/evaluation/qualification | `tool_management.rst` | **NOT ESTABLISHED** — `tool_assurance` `completed_with_blockers`; QCC "planned" only |
| Independence of verification / review | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Native acceptance | `.llm_tmp/context/obligations/source-index.json` | **`not_inferred` for every entry** |

**Explicit non-satisfaction statement.** The ungranted QNX SDK entitlement, the absent
target execution, the non-running QEMU leg, the build-only cross/native test legs, the
unknown safety class and un-inferred applicability, the incomplete extraction of host
artifacts, and the unanswered human reviews mean **none of the checked obligations may be
treated as satisfied**. The newly green Linux cross-builds are a real build pass but are
*local, unprotected, scoped, and build-only*; they are **not** independent verification,
acceptance, or a full native runtime pass.

---

## 9. Measurement and validation status

- **Tools used:** `read_file`, `grep`, `glob`, `write_file` only. No `shell`, delegation,
  web, approval, publishing, or engineering acceptance. **No QNX credential was acquired;
  no network access to `qnx.com` was made.**
- **Executed measurements by this iteration:** **none**. No build, no test, no daemon,
  no QEMU, no cross compile, no target execution.
- **Retained cross-target-relevant measurements (scoped, unprotected):**
  `cross_compilation` — **both legs `exit 0`, `Build completed successfully`** (x86: 1526
  actions; arm: 1147 actions, 381.5 s elapsed); `native_build` — `exit 0`;
  `native_tests` — `exit 0` with `--build_tests_only` (built, not executed);
  `native_integration` — `exit 1`; focused host identifier TU — 91 tests 0 failures
  (candidate) vs 91/33 (baseline), compile exit `0`; `full_native_tests: not_executed`.
- **Test inventory (read, not run):** `service_identifier_tests.cpp` = **91** test
  macros; `runtime_tests.cpp` = **33** test macros (per `process_checks/result.json`).
- **Scope:** local, unprotected, scoped. No QNX artifact exists; the QNX entitlement and
  target execution remain blockers; full native runtime tests and human review remain
  pending.

---

## 10. Notice preservation

- **Only this report was written.** No source, build, test, config, `NOTICE`,
  `LICENSE`, `REUSE.toml`, host-validation, or prior-report file was created, edited, or
  deleted. All `reports/` and `prior-reports/` files were preserved unchanged.
- The header the task flagged (`score/socom/impl/service_identifier.hpp`) retains its
  Apache-2.0/SPDX comment and was left unchanged because it is already balanced (§2). The
  sibling `service_identifier.cpp`, both BUILD files, and both candidate test files
  retain their Apache-2.0/SPDX headers; the workflow files, `.bazelrc`, and the pinned
  obligation documents read here also carry Apache-2.0/SPDX notices.
- The duplicate key remains an `impl/`-only type exposed only through the `testonly`
  `//score/socom:impl_service_identifier` library, so no public header or notice surface
  changed.
- This report itself carries the Apache-2.0 header. No licensed QNX/SOME/IP/AUTOSAR text
  is reproduced; only repository-relative file locations and native identifiers are
  cited.

---

## 11. Pending human review checklist

- [ ] **Confirm §2:** `service_identifier.hpp` is brace-balanced (brace lines
      `:19,:29,:32,:38`; line 39 blank; net balance 0); the recorded "extra closing
      brace at line 39" is stale or refers to a different revision. No correction is
      required in this checkout. If a distinct "cancelled draft" revision still carries
      the brace, locate and correct it by an authorized iteration.
- [ ] **Resolve the instruction conflict:** "Inspect and correct the actual source"
      vs. "this is a review draft: only that report may be written". Confirm that writing
      only this report, with a no-op on already-correct source, is intended.
- [ ] **Confirm the cross-build update (§3):** the earlier `exit 127` reading is
      superseded by the recollected `exit 0` / `Build completed successfully` result for
      both `x86_64-linux` and `aarch64-linux`; and confirm these remain build-only and
      local/unprotected.
- [ ] **Decide the QNX path:** provide an authorized QNX SDK entitlement/credentials
      through the approved channel and run `build_and_test_qnx.yml`'s matrix, or record
      an approved deferral/tailoring. **Do not** treat the declared QCC/SDP toolchains or
      the "qualify-able" language as a qualification.
- [ ] **Confirm the S-CORE/integrator split for this slice (§6):** the bounded slice is
      Level-1-only; full platform integration and target-device validation remain the
      integrator's obligation; the reference hardware is not yet decided and the
      referenced platform AoUs are not defined in this checkout.
- [ ] **Reconcile the drift and staleness:** candidate-snapshot vs. collector hashes
      (§1.2) and the test-macro counts, then re-run the focused host validation on the
      current tree.
- [ ] **Do not infer passing from retained collection nodes:** the Linux cross-builds now
      pass but execute nothing at target level; the QEMU leg failed; the QNX legs were
      never attempted; `check-result: 0` is a retention marker only.
- [ ] **Keep the wider #84 public `Service_interface_identifier` restructure, FindService
      wildcard handling, and the config minor-wildcard narrowing out of this bounded
      slice**, and do not present identifier-only tests as platform/target validation.
- [ ] **Schedule independent human review** (approver ≠ author, per
      `gd_req__verification_independence`) and record engineering acceptance; no
      compliance or qualification claim may be made before that.

---

*End of cross-target review draft (refreshed). Local, unprotected, scoped. No engineering
acceptance; human reviews unanswered; full native runtime tests pending; x86_64/aarch64
Linux cross-builds succeeded but are build-only and unverified at target level; QNX SDK
entitlement unknown and no credential acquired; no target execution performed; no
qualification inferred.*
