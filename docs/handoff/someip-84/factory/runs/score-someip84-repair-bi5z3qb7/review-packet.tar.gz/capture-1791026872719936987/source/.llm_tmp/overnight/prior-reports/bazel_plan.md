<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — native Bazel validation plan (`bazel_plan`) review draft

**Document type:** review draft (actual-source inspection + BUILD-change check + exact native Bazel
validation plan + pending-execution status)
**Date:** 2026-10-02
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version handling in socom*
**Run:** `fabro/run/01M3YRJEGXNY6CB81T7TKW774B`
**Status:** local, unprotected, scoped. **No engineering acceptance exists. Human reviews are
unanswered. Full native runtime tests remain pending.** Every statement below is a static reading of
the working tree at the baseline-bound candidate paths, a reading of the retained local/unprotected
host artifacts under `.llm_tmp/overnight/`, or an explicitly-labelled logical consequence. Nothing
here is published, reviewed, accepted, or a full native run.

> **Tool / write boundary actually observed.** This iteration used only `read_file`, `grep`, `glob`,
> and `write_file`. No `shell`, no delegation, no web access, no approval, no publishing, and no
> engineering acceptance was performed. The task's final, explicit sentence — *"This is a review
> draft: only that report may be written"* — governs the write boundary. It also lists exactly four
> allowed tools and does **not** include an editing tool. Accordingly **exactly one file was written —
> this report.** No source, build, test, config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was created,
> edited, or deleted. All prior reports are preserved.
>
> **Instruction conflict, recorded rather than silently resolved.** The task also says *"Inspect and
> correct the actual source before expanding tests."* That instruction cannot be executed by this
> iteration for two independent reasons: (1) the write boundary permits only this report, and (2) on
> the facts there is nothing to correct — the file the task names is **already brace-balanced** and
> line 39 is blank (§2). The minimal repair is retained in §2.3 for reference only. The conflict is
> therefore moot; it is carried to the human reviewer in §8.

---

## 0. Summary

1. **Flagged syntax failure — inspected; not present in the actual source.** The task records "a
   measured GCC syntax failure: an extra closing brace in
   `score/socom/impl/service_identifier.hpp` at line 39". Direct inspection of the actual working tree
   shows a 40-line, brace-balanced header: openers at `:19` (`namespace score::socom {`) and `:29`
   (`struct Service_instance_identifier final {`), closers at `:32` (`};`) and `:38`
   (`}  // namespace score::socom`); `:39` is empty and `:40` is `#endif` (§2). Net brace balance is
   `0`. No file matching `**/service_identifier.hpp` other than this one exists in the checkout. The
   described defect is a stale, pre-correction description; no correction was applied, and none is
   required.
2. **BUILD changes — checked and consistent.** Relative to the pinned baseline blobs,
   `score/socom/BUILD` now defines the `testonly` library `impl_service_identifier` exposing
   `impl/service_identifier.hpp` to `//score/socom/test/unit:__pkg__`, and
   `score/socom/test/unit/BUILD` now depends on it. `socom_test` collects `srcs =
   glob(include = ["*.cpp"])`, so both `service_identifier_tests.cpp` and `runtime_tests.cpp` are
   picked up automatically. The wiring is internally consistent; **no BUILD change is required** for
   the current test files (§3).
3. **Exact native Bazel validation plan prepared from the pinned repository configuration.** The plan
   in §4 fixes the Bazel version (`8.6.0`), the registry/toolchain configuration from `.bazelrc`, the
   coverage and static-analysis imports, and the exact target/config/feature invocations that the
   pinned obligation collectors use. **Execution is pending / unavailable in this task** because every
   `native_*` and `cross_compilation` collector invocation terminated `exit_code 127`,
   `[Errno 2] No such file or directory: '/tmp/s-core-001/bin/bazel'` (§5).
4. **No obligation is satisfied.** The retained host validation is scoped to the focused identifier
   translation unit only, is stale by two test cases relative to the current source, and does not
   compile or run `runtime_tests.cpp`; the native `bazel` obligations all failed to start. Missing
   tools, unknown applicability, incomplete extraction, and unanswered human reviews are **not**
   treated as satisfied (§5, §6).

---

## 1. Binding to the verified baseline, prior reports, host feedback, obligations

### 1.1 Issue and baseline

| Item | Value | Source |
|------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` — *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:2-4` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |
| Branch | `fabro/run/01M3YRJEGXNY6CB81T7TKW774B` | environment |

The issue body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**. Binding is **by baseline commit**, not by run HEAD; earlier reports on the same baseline
remain admissible prior evidence.

### 1.2 In-scope candidate files (baseline blobs vs. recorded working-tree hashes)

From `.llm_tmp/context/candidate-files.json` (baseline blobs confirmed against
`.llm_tmp/context/source-manifest.json`):

| File (repo-relative) | Baseline git blob | Baseline sha256 (candidate-files) | Working-tree sha256 (obligation result `source_hashes`) |
|----------------------|-------------------|------------------------------------|--------------------------------------------------------|
| `score/socom/BUILD` | `3477ea08…` (`source-manifest.json:1148`) | `dee82616…` | `68f4645a…` (differs → changed) |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e…` | `d766902e…` | `3c12b3f1…` (differs) |
| `score/socom/impl/service_identifier.hpp` | `c8bae790…` | `96b33a1f…` | `bdce3fcb…` (differs) |
| `score/socom/test/unit/BUILD` | `3c03a7b1…` (`source-manifest.json:1646`) | `9b3c5b34…` | `e909151e…` (differs) |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab7…` | `5e35e24d…` | `9a2d6a15…` (differs) |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(none — `null`; manifest expects a new file)* | `45d07399…` | `4df2c63c…` (differs) |

The working-tree hashes in the last column are the obligation collectors' record of the tree they
snapshotted (`compiler_diagnostics`, `native_build`, `rework_progress` `source_hashes`). They differ
from the candidate-snapshot hashes, i.e. the working tree has **drifted** from the draft the
candidate set describes. A hash is not a content diff; the drift is not independently reconstructed
here (no hashing/shell tool), and it is flagged so no one mistakes the candidate set for the current
tree. `glob **/service_identifier.hpp` returns exactly one path.

### 1.3 Prior reports read and preserved

`.llm_tmp/overnight/reports/` (18 files, all preserved) and `.llm_tmp/overnight/prior-reports/`
(12 files, all preserved) were read/grepped. The build-and-test context in them is consistent: every
prior report records **no executed `bazel` measurement** and the same proposed focused commands
(e.g. `reports/scope.md:530-536`, `reports/key_fix.md:582-588`, `reports/runtime_enabled.md:260-272`,
`reports/coverage_tests_repair.md:337-339`, `prior-reports/unit_matrix.md:422-429`). The
`reports/` additions since the earlier drafts (`api_review.md`, `compatibility.md`,
`concurrency_review.md`, `coverage_tests_repair.md`, `lifetime_review.md`, `tool_findings_repair.md`)
reach the same conclusion: `bazel` is absent (`reports/api_review.md:220`,
`reports/compatibility.md:244-245`, `reports/tool_findings_repair.md:194,296-301`).

### 1.4 Host validation feedback (`.llm_tmp/overnight/validation/`) — present, scoped, stale

| Artifact | Content |
|----------|---------|
| `check-result` | `0` (collector success marker only) |
| `before-compile.command.json` / `before-test.command.json` | `g++-12 -std=c++17 -Wall -Wextra -Werror` focused identifier TU; run before; exit 0 / exit 1 |
| `after-compile.command.json` | same, plus `-fsanitize=undefined -fno-sanitize-recover=all`; exit 0 |
| `after-test.command.json` | candidate binary `--gtest_output=json:…`; exit 0 |
| `before.json` | `ServiceInstanceIdentifierTest`: **85 tests, 28 failures** |
| `after.json` | `ServiceInstanceIdentifierTest`: **85 tests, 0 failures** |
| `after-test.stdout` | `[==========] 85 tests from 1 test suite ran.` … `[  PASSED  ] 85 tests.` |
| `measurement.json` | `check_ref: check_conversion_tests`, `mode: ubsan`, `origin: local_unprotected_measurement`, `initiator: Fabro host hook`, `engineering_acceptance: pending`, `full_native_tests: not_executed`, `changed_paths: ["score/socom/test/unit/service_identifier_tests.cpp"]`, compiler `/usr/bin/x86_64-linux-gnu-g++-12`; `baseline_with_agent_tests`: 85/28; `candidate`: 85/0 |

**Scope and staleness.** The retained measurement compiles **only** the focused identifier
translation unit (`service_identifier.cpp` + `string_registry.cpp` + `service_identifier_tests.cpp`)
plus googletest — it does **not** compile or run `runtime_tests.cpp`, and it is **not** a Bazel run.
`after-compile.stderr` and `before-compile.stderr` are empty, i.e. the retained run recorded **no**
syntax failure. The measurement's `changed_paths` and 85-test inventory are also stale: the current
`service_identifier_tests.cpp` carries **87 `TEST_F`** cases (last two at `:1982` and `:2012`), two
more than the 85 measured. `source_changed_this_round: true` in
`obligations/rework_progress/result.json` records that drift.

### 1.5 Pinned obligation sources read this iteration

All nine entries of `.llm_tmp/context/obligations/source-index.json` are present in
`.llm_tmp/context/obligations/`, together with `authority.json`. Every entry is
`"native_acceptance": "not_inferred"`. `authority.json` records `engineering_acceptance: pending`,
`human_reviews: unanswered`, `safety_class: unknown`, `codeql_scope: "Public Apache-2.0
eclipse-score/inc_someip_gateway; no upload"`, and the instruction "Restart the failed queue for one
complete pass through all obligations". The `misra_mapping` and `inspection_checklist` sources are
`:status: draft`; the others are `:status: valid`. Relevant quality criteria are in
`verification_plan.rst` (criteria 1–2: line/branch coverage 85 % QM / 100 % safety, `:300-307`;
criteria 6–7: 100 % executed/passed, `:320-327`; criterion 8: static-analysis closure, `:329-331`;
criterion 9: freedom from compiler warnings & errors, 100 %, `:332-335`). `verification_plan.rst`
also names Bazel as the main build environment (`:542-545`) and GoogleTest for C++ units
(`:547-550`).

---

## 2. The flagged syntax failure: inspection of the actual source and correction status

### 2.1 Finding (direct `read_file` this iteration)

`score/socom/impl/service_identifier.hpp` is **brace-balanced** and 40 lines:

| Line | Content | Role |
|------|---------|------|
| 14–15 | `#ifndef SRC_SOCOM_SRC_SERVICE_IDENTIFIER` / `#define …` | include guard |
| 17 | `#include "score/socom/service_interface_identifier.hpp"` | include |
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 30–31 | `Service_interface_identifier interface;` / `Service_instance instance;` | members |
| 32 | `};` | closes the struct |
| 35 | `bool operator<(…);` (inside `/// \cond`) | declaration |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`) and two closers (`:32`, `:38`): net brace balance `0`. There is **no
third, unmatched closing brace**, and line 39 contains no text. The sibling
`score/socom/impl/service_identifier.cpp` uses the same nested form and is balanced (brace-bearing
lines `:18`, `:20`, `:30`, `:32`). `grep` over the checkout found **no** recorded `error:` in the
retained validation stderr files; the only recorded compile error in the retained artifacts is the
clang/tooling dependency warning in `reports/tool_findings_repair.md:218`
(`'get_temporary_buffer<testing::TestInfo *>' is deprecated [-Werror,-Wdeprecated-declarations]`),
which is outside the six candidate paths.

The task's description matches the **earliest** prior reports, which quote the old split-form double
close (`}  // namespace socom` + `}  // namespace score`). The `reproducer` iteration applied the
correction; its write left line 39 blank in place of the removed brace, which is exactly the state
observed here (`prior-reports/reproducer.md` §2; `reports/reproducer.md` §2; `reports/key_fix.md` §2).

### 2.2 Why it would matter if present

The header is compiled into `//score/socom:socom` (`score/socom/BUILD:24-41`; `srcs` globs
`impl/**/*.cpp` and `impl/**/*.hpp`) and is re-exposed `testonly` through
`//score/socom:impl_service_identifier` (`score/socom/BUILD:43-54`), consumed by
`//score/socom/test/unit:socom_test` (`score/socom/test/unit/BUILD:23-29`). A syntax error there
would fail the library and the whole `socom_test` target, contradicting quality criterion 9. It is
**not** a blocker in the current tree.

### 2.3 Minimal repair (retained for reference only; not applied because not needed and not permitted)

Should the imbalance ever reappear, the minimal correction — matching the sibling `.cpp` — is:

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

Applying this to the already-balanced file would be a no-op; re-introducing a broken state merely to
"fix" it would be a regression. Because the write boundary permits only this report, this iteration
does not touch the source irrespective of the finding. If the "cancelled draft" is a *different*
revision that still carries the extra brace, it is not the file in this checkout; it must be located
and corrected by an authorized iteration.

---

## 3. BUILD change check

### 3.1 Current wiring (read this iteration)

**`score/socom/BUILD`** (baseline blob `3477ea08…`, size 1520; current file 70 lines):

- `cc_library(name = "socom")` — `srcs = glob(["impl/**/*.cpp", "impl/**/*.hpp"])`,
  `hdrs = [":headers"]`, `features = COMPILER_WARNING_FEATURES`, deps on
  `@score_baselibs//score/language/futurecpp`, `…//score/mw/log`, `…//score/result`
  (`score/socom/BUILD:17-41`). The internal key header is therefore part of the compiled library.
- **New vs. baseline:** `cc_library(name = "impl_service_identifier", testonly = True,
  hdrs = ["impl/service_identifier.hpp"], visibility = ["//score/socom/test/unit:__pkg__"],
  deps = [":socom"])` (`score/socom/BUILD:43-54`). This is the change that lets the unit test include
  the otherwise-private `impl/` header; the comment at `:43-45` documents exactly that.

**`score/socom/test/unit/BUILD`** (baseline blob `3c03a7b1…`, size 983; current file 30 lines):

- `cc_test(name = "socom_test", size = "small", srcs = glob(include = ["*.cpp"]),
  linkstatic = True, tags = ["unit"], visibility = ["//tests/integration_test:__pkg__"],
  deps = ["//score/socom:impl_service_identifier", "//score/socom:mock",
  "//score/socom/test/framework:socom_test_framework", "@googletest//:gtest",
  "@googletest//:gtest_main"])` (`score/socom/test/unit/BUILD:16-29`).
- **Change vs. baseline:** the dep `//score/socom:impl_service_identifier` is present so the test
  translation units can include `score/socom/impl/service_identifier.hpp`. The `*.cpp` glob means
  `service_identifier_tests.cpp` (new file, no baseline blob) and `runtime_tests.cpp` are collected
  **without any further BUILD edit**.

**Top-level `BUILD`:** the `unit_tests` aggregate `test_suite` explicitly lists
`//score/socom/test/unit:socom_test` (`BUILD:52-59`), and `use_clang_tidy_targets()` /
`use_ruff_targets()` create the lint entry points (`BUILD:118-120`). No change required there.

### 3.2 Consistency conclusion

- The `testonly` header exposure is correctly scoped to `//score/socom/test/unit:__pkg__` — the only
  consumer — so no public/visibility surface changed and no notice surface changed.
- Both current test files are inside the `*.cpp` glob; no new `srcs` entry is needed.
- **No BUILD change is required for the current slice.** The recorded working-tree hashes differ from
  the candidate-snapshot hashes (§1.2), so the only authoritative confirmation that the loaded
  `BUILD`/`MODULE` graph resolves is a real `bazel build` / `bazel query` run (§4), which is
  unavailable here (§5). This is a static consistency check, not a build.

---

## 4. Exact native Bazel validation plan (from pinned repository configuration)

### 4.1 Pinned configuration

| Item | Value | Source |
|------|-------|--------|
| Bazel version | **8.6.0** | `.bazelversion:1`; collector env `USE_BAZEL_VERSION=8.6.0` |
| Registries | `https://raw.githubusercontent.com/eclipse-score/bazel_registry/main/`, `https://bcr.bazel.build` | `.bazelrc:111-112` |
| Default test output | `--test_output=errors` | `.bazelrc:108` |
| Strict action env | `build --incompatible_strict_action_env` | `.bazelrc:109` |
| Default warning feature | `common --features=-treat_warnings_as_errors` | `.bazelrc:117` |
| Toolchains / platforms | extra toolchains `@score_linux_x86_64_ext4_toolchain`, `@score_gcc_x86_64_toolchain`; `_toolchain_common` host platform `@score_bazel_platforms//:x86_64-linux` | `.bazelrc:44-71` |
| Integration (QEMU) | `--config=qemu-integration` → linux-sandbox strategy + `--run_under=@score_itf//scripts:run_under_qemu` | `.bazelrc:73-85` |
| Performance | `--config=perf-tests` (`//tests/benchmarks:setup_network`, `--define=perf_tests=true`, `opt`); `--config=perf-tests-flamegraphs` | `.bazelrc:93-106` |
| Coverage | `coverage --config=llvm_cov`; `--combined_report=lcov`, `--instrumentation_filter=^//score[/:]`, LLVM toolchain, `//tools/coverage:reporter_wrapper` | `coverage.bazelrc:22-68` |
| Static analysis | `test --config=clang-tidy` (aspect `//tools/lint:linters.bzl%clang_tidy`, fail-on-violation); `--config=ruff` | `static_analysis.bazelrc:20-42`; `BUILD:118-120` |
| Collector wrapper flags | `--batch`, `--output_user_root=<run>/bazel-cache`, `--jobs=2` | every `obligations/*/result.json` `commands[].argv` |
| Collector env | `PATH=/tmp/score-someip84-obligation-tools/bin:/tmp/s-core-001/bin:/usr/local/bin:/usr/bin:/bin`, `HOME`, `TMPDIR`, `BAZELISK_HOME`, `USE_BAZEL_VERSION=8.6.0`, `PRE_COMMIT_HOME`, `XDG_CACHE_HOME`, `LANG=C.UTF-8`, `LD_LIBRARY_PATH` | e.g. `obligations/native_build/result.json:247-259` |
| Bazel binary in pinned native workspace | `/tmp/s-core-001/bin/bazel` | collector `argv[0]` |

The package `socom_test` is `size = "small"`, `linkstatic = True`, tagged `unit`
(`score/socom/test/unit/BUILD:16-22`), so the standard `bazel test` strategy applies (with
`--sandbox_tmpfs_path=/dev/shm` and `=/tmp`, `.bazelrc:124-126`).

### 4.2 Ordered plan

Stage 1 — graph and compile only (fastest, catches the recorded syntax-failure class and BUILD breakage):

```bash
# 1a. confirm the BUILD graph loads and the new test file is collected
bazel --batch --output_user_root=<run>/bazel-cache query 'tests(//score/socom/test/unit:all)'
bazel --batch --output_user_root=<run>/bazel-cache build --jobs=2 //score/socom:socom //score/socom:impl_service_identifier

# 1b. full compile of everything (the native_build collector command)
bazel --batch --output_user_root=<run>/bazel-cache build --jobs=2 //...
```

Stage 2 — focused unit tests for this slice on the default host toolchain:

```bash
# 2a. whole socom unit test target (collects service_identifier_tests.cpp + runtime_tests.cpp)
bazel --batch --output_user_root=<run>/bazel-cache test --jobs=2 //score/socom/test/unit:socom_test

# 2b. key-level identity/ordering matrix only
bazel --batch --output_user_root=<run>/bazel-cache test --jobs=2 \
    //score/socom/test/unit:socom_test --test_filter='ServiceInstanceIdentifierTest.*'

# 2c. the runtime-level minor-only duplicate regression
bazel --batch --output_user_root=<run>/bazel-cache test --jobs=2 \
    //score/socom/test/unit:socom_test \
    --test_filter='RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError'

# 2d. all runtime-level cases
bazel --batch --output_user_root=<run>/bazel-cache test --jobs=2 \
    //score/socom/test/unit:socom_test --test_filter='RuntimeTest.*'

# 2e. aggregate unit suite (native_traceability unit/component step)
bazel --batch --output_user_root=<run>/bazel-cache test --jobs=2 //:unit_tests //:component_tests
```

Stage 3 — full native suite as pinned by the collectors:

```bash
# 3a. all tests, build-only (native_tests)
bazel --batch --output_user_root=<run>/bazel-cache test --jobs=2 //... --build_tests_only

# 3b. warnings-as-errors evidence for criterion 9 (explicit; the default .bazelrc disables it)
bazel --batch --output_user_root=<run>/bazel-cache build --jobs=2 \
    --features=treat_warnings_as_errors //score/socom/...
```

Stage 4 — coverage (criterion 1–2; platform goals 85 % QM / 100 % safety per `verification_plan.rst:300-307`):

```bash
# 4a. coverage collection (native_coverage)
bazel --batch --output_user_root=<run>/bazel-cache coverage --jobs=2 //... --build_tests_only

# 4b. HTML/report generation
bazel --batch --output_user_root=<run>/bazel-cache run --jobs=2 \
    @score_coverage//:generate_coverage_html -- --archive-dir <run>/coverage
```

Note: the collector env for coverage sets `COVERAGE_THRESHOLD=73`
(`obligations/native_coverage/result.json:260`), which is the **repository CI threshold**, not the
platform 85 %/100 % acceptance in `verification_plan.rst`; a 73 % pass must not be reported as
platform-goal satisfaction.

Stage 5 — static analysis (criterion 8; `code_analysis.rst`):

```bash
bazel --batch --output_user_root=<run>/bazel-cache run --jobs=2 //:clang-tidy.check
bazel --batch --output_user_root=<run>/bazel-cache run --jobs=2 //:ruff.check
# alternative aspect form if the run targets are unavailable:
# bazel --batch --output_user_root=<run>/bazel-cache test --config=clang-tidy //score/socom/...
```

Stage 6 — sanitizers and concurrency (TSAN):

```bash
# ASan + LSan + UBSan (native_sanitizers)
bazel --batch --output_user_root=<run>/bazel-cache test --jobs=2 //score/... //tests/... \
    --build_tests_only --features=asan --features=lsan --features=ubsan_clang

# ThreadSanitizer (native_tsan)
bazel --batch --output_user_root=<run>/bazel-cache test --jobs=2 //score/... //tests/... \
    --build_tests_only --features=tsan
```

Stage 7 — cross-compilation (architecture coverage):

```bash
bazel --batch --output_user_root=<run>/bazel-cache build --jobs=2 --config=x86_64-linux  //score/... //tests/...
bazel --batch --output_user_root=<run>/bazel-cache build --jobs=2 --config=aarch64-linux //score/... //tests/...
# QNX configs (x86_64-qnx / aarch64-qnx) exist in .bazelrc:59-69 and require the QNX toolchains.
```

Stage 8 — integration (QEMU) and docs/traceability/performance:

```bash
# QEMU integration (native_integration; prerequisites recorded: kvm present, /usr/bin/qemu-system-x86_64)
bazel --batch --output_user_root=<run>/bazel-cache test --jobs=2 --config=qemu-integration \
    //quality/... //tests/integration_test/...

# docs / traceability (native_docs, native_traceability)
bazel --batch --output_user_root=<run>/bazel-cache run --jobs=2 //:docs
bazel --batch --output_user_root=<run>/bazel-cache run --jobs=2 //:traceability_gate -- \
    --metrics-json <run>/native-workspace/_build/metrics.json --need-type=comp_req

# performance (native_performance)
bazel --batch --output_user_root=<run>/bazel-cache test --jobs=2 --config=perf-tests \
    //tests/benchmarks/... --build_tests_only
bazel --batch --output_user_root=<run>/bazel-cache test --jobs=2 --config=perf-tests-flamegraphs \
    //tests/benchmarks/... --build_tests_only
```

### 4.3 Expected outcome for this slice (source-derived, not measured)

On the current key (`minor` excluded; identity `(instance, service id, major)`,
`score/socom/impl/service_identifier.cpp:20-30`), the minor-only key cases collapse a `std::set` to
one element and case 2c returns `Construction_error::duplicate_service`. On a key that includes
`minor`, those focused cases fail and 2c would construct a second connector instead of returning the
error. These are `std::set`/strict-weak-ordering consequences, not observed results. Expected counts
per the current tree: 87 `TEST_F` in `service_identifier_tests.cpp`; 31 `TEST_F` + 1 `TEST` + 1
`TEST_P` in `runtime_tests.cpp`.

### 4.4 Optional focused reproduction path

The pinned collectors also define focused, non-Bazel variants (retained, not run here): gcc/clang
diagnostics (`compiler_diagnostics`), focused coverage via `gcovr` (`focused_coverage`), focused
sanitizers/valgrind/cppcheck (`focused_asan_lsan`, `focused_memcheck`, `focused_tsan`,
`focused_cppcheck`), and clang-tidy config verification (`focused_clang_tidy`). Their exact argv is
retained in the corresponding `obligations/*/result.json` `commands[]` for a later authorized run.
None of these substitutes for the native `bazel` plan above, because they cover only the focused
identifier TU.

---

## 5. Unavailable-execution status (pending)

| Collector obligation | Exact invocation | Recorded result | Status |
|----------------------|------------------|-----------------|--------|
| `native_build` | `build --jobs=2 //...` | exit `127`, `'/tmp/s-core-001/bin/bazel'` missing | **PENDING / UNAVAILABLE** |
| `native_tests` | `test --jobs=2 //... --build_tests_only` | exit `127` | **PENDING / UNAVAILABLE** |
| `native_coverage` | `coverage --jobs=2 //... --build_tests_only` + report | exit `127` | **PENDING / UNAVAILABLE** |
| `native_lint` | `run //:clang-tidy.check`, `run //:ruff.check` | exit `127` | **PENDING / UNAVAILABLE** |
| `native_sanitizers` | `test //score/... //tests/... --build_tests_only --features=asan --features=lsan --features=ubsan_clang` | exit `127` | **PENDING / UNAVAILABLE** |
| `native_tsan` | `test //score/... //tests/... --build_tests_only --features=tsan` | exit `127` | **PENDING / UNAVAILABLE** |
| `cross_compilation` | `build --config=x86_64-linux` / `--config=aarch64-linux` | exit `127` | **PENDING / UNAVAILABLE** |
| `native_integration` | `test --config=qemu-integration //quality/... //tests/integration_test/...` | exit `127` (kvm/qemu present) | **PENDING / UNAVAILABLE** |
| `native_docs` / `native_traceability` | `run //:docs`; `test //:unit_tests //:component_tests`; `run //:traceability_gate …` | exit `127` | **PENDING / UNAVAILABLE** |
| `native_performance` | `test --config=perf-tests` / `--config=perf-tests-flamegraphs //tests/benchmarks/...` | exit `127` | **PENDING / UNAVAILABLE** |

All of the above record `"status": "findings_or_execution_failure"` and
`[Errno 2] No such file or directory: '/tmp/s-core-001/bin/bazel'`. **A successful collection node
means results were retained, not that checks passed.** Absent tools are not satisfied obligations.

Retained focused measurements, which are *not* native Bazel results:

- `compiler_diagnostics`: gcc focused compile + tests **exit 0**; clang focused compile **exit 1**
  (googletest/libstdc++ `-Wdeprecated-declarations` dependency error outside the candidate paths)
  (`obligations/compiler_diagnostics/result.json:236-330`).
- `focused_coverage`: line **100 %** / branch **78.6 %** over
  `score/socom/impl/service_identifier.cpp` + `string_registry.cpp`, `complete_target_scope: false`,
  `safety_class: unknown_requires_authorized_selection` (`obligations/focused_coverage/result.json:339-357`).
- `focused_asan_lsan`: **completed / exit 0**; `focused_tsan`: findings (exit `66`/`-11`);
  `focused_memcheck`: valgrind missing (exit `127`); `focused_cppcheck`: exit `2`
  (`obligations/focused_*`).
- Host validation `after.json`: focused identifier TU **85 / 0**; `full_native_tests: not_executed`
  (§1.4). Stale by two cases relative to the current 87-case file.

---

## 6. Obligations status (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Freedom from compiler warnings & errors (100 %) | `verification_plan.rst:332-335` (criterion 9) | **NOT MEASURED** — header brace-balanced by inspection (§2); gcc focused compile exit 0, but no `bazel build`; clang focused compile blocked on a dependency |
| Structural statement / branch coverage goals | `verification_plan.rst:300-307` (criteria 1–2) | **NOT MEASURED** — no Bazel coverage run; focused TU 100 % line / 78.6 % branch, below the 100 % safety goal and out of full target scope |
| Unit/component tests executed and recorded | `verification_plan.rst:320-327`; `verification_guideline.rst` | **NOT EXECUTED under Bazel** — `native_tests` exit 127; retained host run covers only the focused identifier TU and excludes `runtime_tests.cpp` |
| Test execution via pinned Bazel build system | `verification_plan.rst:542-545`; `development_plan.rst` | **PENDING** — `bazel` absent (all `native_*`/`cross_compilation` exit 127) |
| Static code analysis (clang-tidy / CodeQL), findings classified | `code_analysis.rst`; `verification_process.rst` | **NOT PERFORMED natively** — `native_lint` exit 127; focused clang-tidy config blocker; CodeQL MISRA applicability unestablished (draft mapping) |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` | **UNKNOWN** — mapping `:status: draft` |
| Sanitizer / concurrency checks | `code_analysis.rst`; `verification_process.rst` | **NOT PERFORMED natively** — `native_sanitizers`/`native_tsan` exit 127; focused TSAN environment failure |
| Cross-compilation (x86_64/aarch64) | `development_plan.rst` | **PENDING** — exit 127 |
| Integration (QEMU) | `verification_process.rst` | **PENDING** — exit 127 despite kvm/qemu present |
| Docs / traceability gates | `verification_process.rst` (`gd_req__verification_link_tests_cpp`) | **PENDING** — exit 127; record properties `DerivationTechnique`/`Description` present, `TestType`/`Verifies` deliberately unset (no invented links) |
| Independence of verification / review by a different committer | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** for this slice — `bazel`, `valgrind`, `gitleaks`, `clang-format`, `pre-commit`, `reuse` unavailable |
| Native acceptance | `.llm_tmp/context/obligations/source-index.json` | **`not_inferred`** for every entry |

**Explicit non-satisfaction statement.** Missing tools (no `bazel`/`shell` in this task), the unknown
safety class and un-inferred applicability, the incomplete extraction of host artifacts, the absent
native results, and the unanswered human reviews mean **none of the checked obligations may be
treated as satisfied**. In particular, the retained focused host run and `check-result: 0` are
retention/collection markers only; they are not a native Bazel pass and they are scoped and stale
(§1.4, §5).

---

## 7. Notice preservation

- No source, build, test, config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was created, edited, or
  deleted by this iteration; only this report was written. Every existing Apache-2.0 / SPDX header is
  untouched, and all 18 `reports/` files and all 12 `prior-reports/` files were preserved.
- The header the task flagged (`score/socom/impl/service_identifier.hpp`) was inspected and left
  unchanged because it is already brace-balanced and otherwise well-formed (§2). The sibling
  `service_identifier.cpp`, both BUILD files, and both candidate test files likewise retain their
  Apache-2.0 / SPDX headers.
- This report carries the Apache-2.0 header.
- The duplicate key remains an `impl/`-only type; the `testonly`
  `//score/socom:impl_service_identifier` library exposes it to `//score/socom/test/unit` only, so no
  public header or notice surface changed.

---

## 8. Pending human review checklist

- [ ] **Confirm the §2 inspection** that `score/socom/impl/service_identifier.hpp` is already
      brace-balanced (single nested close `}  // namespace score::socom`; line 39 blank), so the
      recorded syntax failure is stale / refers to a different revision, and no source correction is
      required in this checkout. If the "cancelled draft" is a distinct revision that still carries
      the extra brace, locate it and authorize its correction; no such file exists here.
- [ ] **Resolve the instruction conflict** (correct-the-source vs. review-draft-only-report) and
      confirm that writing only this report was the intended outcome.
- [ ] **Confirm the BUILD-change check in §3** — the `testonly impl_service_identifier` exposure and
      the `socom_test` dependency — and confirm no further BUILD edit is needed for the new
      `service_identifier_tests.cpp` / updated `runtime_tests.cpp`.
- [ ] **Confirm and resource the native Bazel plan in §4** (Bazel 8.6.0; targets and configs;
      warnings-as-errors evidence; coverage threshold vs. platform 85 %/100 %; sanitizers; TSAN;
      cross-compilation; QEMU integration; docs/traceability), and restore `bazel` at the pinned
      `/tmp/s-core-001/bin/bazel` so the plan can execute.
- [ ] **Reconcile the working-tree drift** recorded in §1.2 (candidate-snapshot hashes vs.
      obligation `source_hashes`) and the two test cases added after the retained 85-test
      measurement (current file has 87 `TEST_F`), then re-run the host validation on the current tree.
- [ ] **Run the full native suite**, including `runtime_tests.cpp`, record pass/fail and coverage, and
      schedule independent human review (approver must differ from the author, per
      `gd_req__verification_independence`).
- [ ] **Do not treat** the retained focused host measurements, `check-result: 0`, or missing tools as
      satisfied obligations; keep `native_acceptance: not_inferred`, `engineering_acceptance:
      pending`, `human_reviews: unanswered`, and `safety_class: unknown`.
