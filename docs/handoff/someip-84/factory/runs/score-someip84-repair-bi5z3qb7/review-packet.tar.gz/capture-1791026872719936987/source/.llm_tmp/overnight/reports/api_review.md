<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — ABI / API review of the bounded duplicate-server registration-key slice

**Document type:** review draft (actual-source inspection + ABI/API effect review +
minor-version-representation review + retained public-identifier design questions + obligations
status).

**Date:** 2026-10-03
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version handling in
socom* (issue #84)
**Run / branch:** `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ`; current HEAD `68284d3`
(`fabro(01M3ZRSDK2XQAF1H48VWTPKQNZ): node_c98fbf153206ff550918a772 (success)`, per the run
environment). Earlier stages of this run are `.git/logs/HEAD:1-12` (`b7d55bb` start → `95fe5f9` →
`8e1610e` → `a31f5fc` → `5722740` → …).
**Verified baseline commit:** `f8a196c3b16d5172d898394ab99b0ed81346d63d`
(`.llm_tmp/context/source-manifest.json:3`).
**Status:** **local, unprotected, scoped.** No engineering acceptance exists. Human reviews are
unanswered. Full native runtime test execution is pending. Nothing in this document is acceptance,
review approval, publication, or a full native run.

> **Tool / write boundary actually observed.** Only `read_file`, `grep`, `glob`, and `write_file`
> were used. No `shell`, no delegation, no web access, no approval, no publishing, and no
> engineering acceptance was performed. The task's operative final sentence — *"This is a review
> draft: only that report may be written."* — is the controlling write boundary, and it resolves the
> task's other direction ("Inspect and correct the actual source before expanding tests") in favour
> of **inspection only**. Accordingly **exactly one file was written: this report**
> (`/workspace/.llm_tmp/overnight/reports/api_review.md`). No source, build, test, config, `NOTICE`,
> `LICENSE`, `REUSE.toml`, or prior-report file was created, edited, or deleted.
>
> **The recorded GCC syntax failure is not present in the actual source (re-verified this
> iteration).** The task records *"a measured GCC syntax failure: an extra closing brace in
> `score/socom/impl/service_identifier.hpp` at line 39."* Direct `read_file` + `grep` on the current
> working tree (§2) show the header is **brace-balanced**: openers at `:19`
> (`namespace score::socom {`) and `:29` (`struct Service_instance_identifier final {`); closers at
> `:32` (`};`) and `:38` (`}  // namespace score::socom`). Line `:39` is **empty**; `:40` is
> `#endif`. Two openers, two closers, net balance `0`. There is no third, unmatched closing brace,
> so there is no actual source to correct; applying the recorded repair would be a no-op at best and
> a regression at worst. Consistently, the retained host artifacts under
> `.llm_tmp/overnight/obligations/compiler_diagnostics/result.json` now show **both** the focused GCC
> (`gcc-compile`, `gcc-tests`) and focused Clang (`clang-compile`, `clang-tests`) legs exiting `0`
> with `-Werror`. **No source write was made and none is required.**

---

## 0. Summary

1. **The change is ABI-neutral and confined to an `impl/`-only type.** The duplicate-server key
   `Service_instance_identifier` is not part of the public header surface
   (`score/socom/BUILD:17-22` exposes only top-level `*.hpp` via the `headers` filegroup; the key
   lives at `impl/service_identifier.hpp` and is re-exported only through the `testonly` target
   `//score/socom:impl_service_identifier`, `score/socom/BUILD:46-54`, visible to
   `//score/socom/test/unit:__pkg__`). Its layout is unchanged
   (`impl/service_identifier.hpp:29-32`), its only operator keeps the same signature (declaration
   `impl/service_identifier.hpp:35`; definition `impl/service_identifier.cpp:20`), and there is
   still no `operator==`/`std::hash` for it. Only the **behaviour** of `operator<` changed (the
   minor version is excluded): identity is now `(instance, service id, major)`
   (`impl/service_identifier.cpp:28-29`). There is no public symbol or layout change, so the bounded
   change introduces no source-level ABI break.
2. **The public API surface is byte-for-byte unchanged.**
   `Service_interface_identifier` / `::Version{major: uint16, minor: uint16}`
   (`service_interface_identifier.hpp:73-124`, `:80-88`), its inline `operator==`/`operator<`
   (`:130-162`) and its `std::hash` (`:181-190`) are untouched and still **minor-aware**.
   `Service_interface_definition` keeps the same members
   (`service_interface_definition.hpp:42-68`) and its `operator<` still delegates to
   `interface < interface` (`impl/service_interface_definition.cpp:37-39`), i.e. minor-aware. The
   IPC wire struct `gateway_ipc_binding::Service` still carries the full public `Version`
   (`gateway_ipc_binding.hpp:82`). **No IPC / wire-protocol change.**
3. **The observable API-behaviour change is at the duplicate gate.** With the minor-excluding key,
   two `Runtime::make_server_connector` calls that share `(instance, service id, major)` but differ
   only in `minor` now collide in the key set and the second returns
   `Construction_error::duplicate_service` (`impl/runtime_impl.cpp:449-454`), instead of both being
   constructed and the second *enable* reaching the single-server assert
   (`SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)`, `impl/runtime_impl.cpp:369`). This is a
   behaviour/contract change for callers of a **public** virtual method — recorded, not yet
   accepted.
4. **A documentation/contract wording gap exists.** `Runtime::make_server_connector`'s doc says a
   duplicate is judged by *"the configuration.interface and instance parameters"*
   (`runtime.hpp:170-178`), but `Service_interface_identifier::operator==` includes `minor`
   (`service_interface_identifier.hpp:149-152`) while the registration key does **not**. The two
   notions of "same service" (public identifier equality vs registration key identity) now diverge
   for minor-only differences. Recorded as a review item (§4.3); not silently "fixed" (the write
   boundary permits only this report).
5. **Minor-version representation is inconsistent across layers and is the real open question.**
   Public/`socom` stores `uint16 major` + `uint16 minor`; the SOME/IP config declares
   `service_version_major: uint8` (`score/config/mw_someip_config.fbs:19`) and
   `service_version_minor: uint32 = 0xFFFFFFFF` (a wildcard, `:23`). Config→socom construction
   narrows the minor with `static_cast<std::uint16_t>(...)` at five sites
   (`score/someipd/impl/remote_network_service.cpp:45`,
   `score/someipd/impl/local_network_service.cpp:49`,
   `score/gatewayd/impl/local_service_instance.cpp:49`,
   `score/gatewayd/impl/remote_service_instance.cpp:92`,
   `score/gatewayd/main.cpp:232`), turning `0xFFFFFFFF` into `0xFFFF` with no range or wildcard
   check. The wildcard is asymmetric in the current compatibility predicate
   (`client.version.minor <= server.version.minor`, `impl/runtime_impl.cpp:133-136`). Combined with
   the new minor-ignoring key, a wildcard-derived `0xFFFF` server and a specific-minor server for
   the same `(instance, id, major)` now **collide as duplicates**. This is a
   representation/semantics question for human review (§5).
6. **The future public identifier redesign stays a human design question (§6).** The issue #84 body
   is an unaccepted proposal (`.llm_tmp/context/issue-snapshot.json:5`): service identifier
   `= id + major`; moving `minor` onto the service instance; FindService
   `optional<minor>`/`optional<instance>`; the `major = FF` AUTOSAR wildcard. Implementing any of it
   would change the public type, the compatibility semantics, and the IPC wire layout, i.e. a
   designed, versioned API/ABI change — out of this bounded slice and deferred to human disposition.
   `.llm_tmp/context/obligations/authority.json` records `engineering_acceptance: pending`,
   `human_reviews: unanswered`, `safety_class: unknown`.
7. **No obligation is satisfied.** The host artifacts are present under
   `.llm_tmp/overnight/validation/` and `.llm_tmp/overnight/obligations/`, but per the task rule a
   successful collection node means results were *retained*, not that checks *passed*. The retained
   picture is mixed: native `bazel build //...` and `cross_compilation` exited `0`; the native test
   legs use `--build_tests_only` (compiled, not executed); native integration (qemu) exited `1`;
   focused TSan tests exited `66`; clang-tidy exited `1` (config); cppcheck exited `2`; CodeQL and
   the secret/dependency scan retained findings; tool assurance is `completed_with_blockers`.
   Applicability is `not_inferred` for every pinned source, the safety class is unknown, and human
   reviews are unanswered.

---

## 1. Binding to the baseline, prior reports, host feedback, and pinned obligations

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` | `.llm_tmp/context/issue-snapshot.json:2-4` |
| Title | *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:3` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` (unchanged) | `.llm_tmp/context/issue-snapshot.json:19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**. It distinguishes three identity use cases — service-instance identifier
`= service id + major + minor + instance id`; service identifier `= service id + major`; FindService
`= service id + major + optional<minor> + optional<instance>` — proposes to "exclude the minor
version and make it a property of the service instance", and calls the FindService `major = FF`
AUTOSAR case theoretically possible but not useful. There is **no comment and no acceptance record**,
so none of it is binding.

### 1.2 Verified baseline, run, and candidate set

| Item | Value | Source |
|------|-------|--------|
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |
| Branch | `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ` | run environment |
| Current HEAD | `68284d3` — `node_c98fbf153206ff550918a772 (success)` | run environment |
| Candidate set | 6 paths | `.llm_tmp/context/candidate-files.json:1-25` |

The six candidate paths (the only writable source paths) are: `score/socom/BUILD`,
`score/socom/impl/service_identifier.cpp`, `score/socom/impl/service_identifier.hpp`,
`score/socom/test/unit/BUILD`, `score/socom/test/unit/runtime_tests.cpp`, and
`score/socom/test/unit/service_identifier_tests.cpp`. Binding is **by baseline commit
`f8a196c3…`**, not by run HEAD. `glob **/service_identifier*` returns exactly three paths
(`impl/service_identifier.cpp`, `impl/service_identifier.hpp`, `test/unit/service_identifier_tests.cpp`),
so there is no second, differently-braced copy of the header.

> **Content-hash caution.** The context snapshot's declared hashes differ from the host-measured
> working tree (e.g. `service_identifier.hpp` context `96b33a1f…`
> (`.llm_tmp/context/candidate-files.json:11`) vs host `bdce3fcb…`
> (`.llm_tmp/overnight/obligations/compiler_diagnostics/result.json:127`); `service_identifier.cpp`
> host `3c12b3f1…` (`:126`); `runtime_tests.cpp` host `9a2d6a15…` (`:188`);
> `service_identifier_tests.cpp` host `de79767c…` (`:190`)). The working tree has moved relative to
> the snapshot, so the snapshot's *description* of a brace defect cannot be assumed to describe the
> current file; the **direct read of the actual file is authoritative** and shows a balanced header
> (§2). No hashing tool is available in this task, so these values are quoted from the artifacts, not
> independently recomputed.

### 1.3 Prior reports read and preserved

- `.llm_tmp/overnight/prior-reports/` — **38 files present**, all preserved. This iteration read
  `api_review.md` (the earlier review on the same baseline) directly, and cross-checked the
  remainder: `reproducer.md`, `key_fix.md`, `invariants.md`, `scope.md`, `callsites.md`,
  `compatibility.md`, `concurrency_review.md`, `lifetime_review.md`, `tool_findings_repair.md`,
  `unit_matrix.md`, `ordering_tests.md`, `conversion_tests.md`, `runtime_disabled.md`,
  `runtime_enabled.md`, `test_metadata.md`, and the rest by name/inventory.
- `.llm_tmp/overnight/reports/` — read, not modified: `callsites.md`, `compatibility.md`,
  `concurrency_review.md`, `conversion_tests.md`, `coverage_tests_repair.md`, `invariants.md`,
  `key_fix.md`, `lifetime_review.md`, `lifetime_tests.md`, `ordering_tests.md`, `reproducer.md`,
  `runtime_disabled.md`, `runtime_enabled.md`, `scope.md`, `test_metadata.md`,
  `tool_findings_repair.md`, `unit_matrix.md`. This document adds `api_review.md`.

Derived sequence across the preserved reports: `scope.md` (bounded the slice) → `invariants.md`
(I-4 baseline key included `minor`; I-9 record index ignores it; I-11 the resulting gap) →
`callsites.md` (call-site map) → `reproducer.md` (header brace correction + focused red regression) →
`key_fix.md` / `unit_matrix.md` (drop `minor` from the key ordering) → `ordering_tests.md`
(property tests) → `runtime_disabled.md` / `runtime_enabled.md` / `lifetime_tests.md` (runtime
regressions) → `conversion_tests.md` (conversion boundaries) → `test_metadata.md` → the earlier
`api_review.md` (ABI/API review) → `compatibility.md` / `concurrency_review.md` / `lifetime_review.md`.

### 1.4 Latest host feedback and obligation-collection results (present this iteration)

Host feedback under `.llm_tmp/overnight/validation/` is **present**:

- `check-result` = `0`.
- `measurement.json` (`:2039-2059`): `check_ref: check_conversion_tests`, `mode: ubsan`,
  `changed_paths: ["score/socom/test/unit/service_identifier_tests.cpp"]`,
  `origin: local_unprotected_measurement`, `initiator: Fabro host hook`,
  `engineering_acceptance: pending`, `full_native_tests: not_executed`, compiler
  `/usr/bin/x86_64-linux-gnu-g++-12` (`sha256 88315fd2…`),
  `baseline_with_agent_tests` = **91 tests / 33 failures / compile exit 0 / test exit 1**,
  `candidate` = **91 tests / 0 failures / compile exit 0 / test exit 0**.
- `before.json` = 91 tests / 33 failures; `after.json` = 91 tests / 0 failures (all under
  `ServiceInstanceIdentifierTest`).
- `after-compile.command.json` / `before-compile.command.json`: `g++-12 -std=c++17 -Wall -Wextra
  -Werror -pthread -fsanitize=undefined -fno-sanitize-recover=all` over `service_identifier.cpp` +
  `string_registry.cpp` + `service_identifier_tests.cpp` + googletest, exit `0`;
  `after-compile.stderr` is empty.
- **Scope caveat:** the measurement compiles **only the focused identifier translation unit** and
  runs the identifier tests. It does **not** compile `runtime_tests.cpp`,
  `interface_compatibility_tests.cpp`, `client_tests.cpp`, or any Bazel target. The before/after
  red→green transition is the registration-key implementation difference (`service_identifier.cpp`),
  not a syntax fix.

Obligation-collection results under `.llm_tmp/overnight/obligations/` are **present** (25 checks).
Per the task rule, retention is not passing. Statuses relevant to this slice (read this iteration):

| Check | Retained status / evidence |
|-------|----------------------------|
| `compiler_diagnostics` | `completed`; focused `gcc-gtest-0/1`, `gcc-compile`, `gcc-tests` **and** `clang-gtest-0/1`, `clang-compile`, `clang-tests` all exit `0` with `-Werror`; limits: focused executable only, GCC 12.3 / Clang 19 differ from native pins |
| `native_build` | `completed`; `bazel build //...` exit `0` |
| `native_tests` | `completed`; `bazel test //... --build_tests_only` exit `0` — **tests built, not executed** |
| `native_sanitizers` | `completed`; `bazel test //score/... //tests/... --build_tests_only --features=asan,lsan,ubsan_clang` exit `0` — **built, not executed** |
| `native_tsan` | `completed`; `bazel test … --build_tests_only` exit `0` — **built, not executed** |
| `native_coverage` | `completed`; exit `0` with `COVERAGE_THRESHOLD: 73`; limit: repository CI threshold 73 is not the platform 85/100 line-and-branch goal |
| `cross_compilation` | `completed_with_blockers`; x86_64-linux and aarch64-linux `bazel build //score/... //tests/...` both exit `0` |
| `native_integration` | `findings_or_execution_failure`; `bazel test --config=qemu-integration //quality/... //tests/integration_test/...` exit `1` (qemu/kvm present) |
| `native_lint`, `native_docs`, `native_traceability`, `native_performance`, `format_precommit` | `findings_or_execution_failure` |
| `focused_coverage` | `completed`; 36/36 line = 100 %, 11/14 branch = 78.6 %, `safety_class: unknown_requires_authorized_selection`, `complete_target_scope: false` |
| `focused_asan_lsan`, `focused_memcheck` | `completed`; focused identifier TU only, exit `0` |
| `focused_tsan` | `findings_or_execution_failure`; build exit `0`, tests exit `66` |
| `focused_clang_tidy` | `findings_or_execution_failure`; `--verify-config` exit `1` (config blocker) |
| `focused_cppcheck` | `findings_or_execution_failure`; exit `2` (`--error-exitcode=2`) |
| `codeql_security`, `codeql_misra` | `findings_or_execution_failure`; scans completed, dependency/gtest-macro findings retained; MISRA mapping is `:status: draft` |
| `secret_dependency_checks` | `findings_or_execution_failure`; gitleaks scan exit `1` |
| `tool_assurance` | `completed_with_blockers`; blockers include *"Tool confidence evaluation, qualification … require authorized humans"*, *"Coverity not installed/adopted here"*, *"Memcheck is an optional complement"* |
| `process_checks` | `completed_with_blockers`; metadata inventory: `runtime_tests.cpp` 33 test macros, `service_identifier_tests.cpp` **91** test macros, each with `DerivationTechnique`/`Description` only |
| `rework_progress` | `completed`; `source_changed_this_round: false`, `rework_requested: false`, stop reason *"One complete pass requested; unresolved findings stay pending"* |

Two important reading rules for the table: (a) the `native_tests` / `native_sanitizers` /
`native_tsan` legs pass `--build_tests_only`, so a zero exit means the test targets were **compiled**,
not that tests were **executed** — this matches `full_native_tests: not_executed`; (b) the retained
native integration run **actually executed** qemu tests and exited `1`.

### 1.5 Pinned obligation sources and authority

All nine entries of `.llm_tmp/context/obligations/source-index.json` were read from
`.llm_tmp/context/obligations/`, together with `authority.json`. Every entry is
`"native_acceptance": "not_inferred"` — pinned, but its applicability to this slice is **not
inferred**.

| id | pinned path | pinned commit | status note |
|----|-------------|---------------|-------------|
| `coding_guidelines` | `docs/contribute/development/cpp/coding_guidelines.rst` | `e2373d82…` | MISRA C++:2023 with C++17 |
| `code_analysis` | `docs/contribute/development/cpp/code_analysis.rst` | `e2373d82…` | clang-tidy + gcc/clang warnings + Coverity; sanitizers; gcov/gcovr |
| `misra_mapping` | `docs/contribute/development/cpp/misra_2023_rule_mapping.rst` | `e2373d82…` | **`:status: draft`** — rule table not a valid obligation |
| `verification_plan` | `docs/platform_management_plan/software_verification.rst` | `e2373d82…` | quality criteria incl. criterion 9 "Freedom from compiler warnings & errors" |
| `development_plan` | `docs/platform_management_plan/software_development.rst` | `e2373d82…` | C++17, GCC host compiler, QCC target, Bazel |
| `tool_management` | `docs/platform_management_plan/tool_management.rst` | `e2373d82…` | tools identified / evaluated / qualified by a human |
| `verification_process` | `process/.../verification_process_reqs.rst` | `98d1d5f4…` | `gd_req__verification_link_tests_cpp`, `_independence`, `_checks_extended`, `_external_aou`, `_sca_classification` |
| `verification_guideline` | `process/.../verification_guideline.rst` | `98d1d5f4…` | traceability, independence, documented results |
| `inspection_checklist` | `score/component_example/docs/detailed_design/chklst_impl_inspection.rst` | `c4d4ad09…` | **`:status: draft`** — blank IMPL template |

**Authority record** (`.llm_tmp/context/obligations/authority.json:1-7`): `engineering_acceptance:
pending`; `human_reviews: unanswered`; `safety_class: unknown`; `codeql_scope: "Public Apache-2.0
eclipse-score/inc_someip_gateway; no upload"`; instruction *"Restart the failed queue for one
complete pass through all obligations"*.

**Safety-class note (recorded, not resolved).** The pinned platform documents carry `:safety: ASIL_B`,
while `authority.json` records `safety_class: unknown`, and `focused_coverage/result.json` records
`safety_class: unknown_requires_authorized_selection`. The document attribute is **not** a selection
of this slice's safety class and must not be inferred as one.

### 1.6 Host addendum (task context, not acceptance)

The host addendum (available only as quoted by prior reports) states it "is task context, not
engineering acceptance or an approved tailoring decision." It asks the review to cover the
`verification_process` test types and derivation techniques; to keep unknown applicability and
unexecuted applicable checks explicit; to **not** label identifier-only tests as full platform
validation and **not** to claim a fuzzy technique without a measurement; and to record that there is
**no authority to invent native links, select a safety classification, accept risk/deviations, or
answer the independent human gate.** This report honours that in §5–§8.

---

## 2. Premise: the recorded GCC syntax failure (inspection of the actual source)

### 2.1 Finding (direct `read_file` + `grep`, this iteration)

`score/socom/impl/service_identifier.hpp` is **brace-balanced** and 40 lines. A `grep` for `{}` on the
file returns exactly four matches:

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`) and two closers (`:32`, `:38`) mean net brace balance `0`. There is **no
third, unmatched closing brace**, and line `:39` contains no text. A `grep` for `namespace socom`
(the split-form closer the defect implies) finds **no match** in this header. The task's "extra
closing brace … at line 39" matches a **stale, pre-correction description** consistent with the
earliest prior reports (which quote lines 38-39 as the split form `}  // namespace socom` +
`}  // namespace score`); the `reproducer` iteration applied the correction and left line 39 blank,
exactly as observed here. The sibling `.cpp` uses the same nested form
(`impl/service_identifier.cpp:18`, `:32`).

### 2.2 Retained measured corroboration (retained, not acceptance)

- `.llm_tmp/overnight/validation/after-compile.command.json` (and `before-compile.command.json`)
  compile the header as a transitive include with `g++-12 -std=c++17 -Wall -Wextra -Werror -pthread
  -fsanitize=undefined -fno-sanitize-recover=all`, exit `0`; `after-compile.stderr` is empty.
- `.llm_tmp/overnight/obligations/compiler_diagnostics/result.json` now shows the **focused GCC and
  focused Clang** legs all exiting `0` (`gcc-compile`, `gcc-tests`, `clang-compile`, `clang-tests`),
  each with `-Werror`. This is a change from the earlier prior `api_review.md`, which recorded a
  nonzero clang exit from a vendored googletest/libstdc++ deprecation; that dependency warning is no
  longer present in the retained run.
- `validation/after.json` = 91/91 `ServiceInstanceIdentifierTest` cases passing.

A genuine unmatched brace would make these compiles fail; they do not. This is scoped/unprotected and
is **not** a full native test execution.

### 2.3 Minimal historical repair (retained for reference only; not applied)

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

Applying this to the already-balanced file is a no-op at best and a regression at worst. **No source
was edited.** The write boundary permits only this report. If the "cancelled draft" is a different
revision that still carries the extra brace (cf. the §1.2 hash caution), it is not the file in this
checkout and must be located and corrected by an authorized iteration; this report records the
discrepancy for human disposition rather than speculating. `glob **/service_identifier*` returns no
second copy, and `glob` over patch/reject artefacts returns only unrelated `third_party/*.patch`
files.

### 2.4 Why it would matter if present

The header is compiled into `//score/socom:socom` (`score/socom/BUILD:24-41`; its `srcs` globs
`impl/**/*.cpp` and `impl/**/*.hpp`) and re-exposed to `//score/socom/test/unit` through the
`testonly` library `impl_service_identifier` (`score/socom/BUILD:46-54`;
`score/socom/test/unit/BUILD:24`). A syntax error there would fail the library and the whole
`socom_test` target, contradicting S-CORE quality criterion 9, "Freedom from compiler warnings &
errors, 100 %" (`verification_plan.rst`). The current balanced state removes that blocker at the
source level; that is **not** a compile measurement of the changed key by this report (§8).

---

## 3. ABI review

### 3.1 Public vs internal surface (what ABI even means for this change)

| Surface | Location | Public? | Changed by this draft? |
|---------|----------|---------|------------------------|
| `Service_instance_identifier` (registration key) | `score/socom/impl/service_identifier.hpp:29-32` | **No** — `impl/` type, not in the public `headers` filegroup (`score/socom/BUILD:17-22`); re-exported only by `testonly` `impl_service_identifier` (`:46-54`) to `//score/socom/test/unit:__pkg__` | Definition of `operator<` only (behaviour) |
| `operator<` for the key | declaration `impl/service_identifier.hpp:35`; definition `impl/service_identifier.cpp:20-30` | **No** | Body/behaviour only; same signature |
| `Service_interface_identifier` / `::Version` | `score/socom/service_interface_identifier.hpp:73-124` | **Yes** — top-level `*.hpp` | **Unchanged** |
| `Service_interface_definition` / `Server_service_interface_definition` | `score/socom/service_interface_definition.hpp:42-106` | **Yes** | **Unchanged** |
| `Runtime` (incl. `make_server_connector`) | `score/socom/runtime.hpp:118-216` | **Yes** | Declaration unchanged; **behaviour** of the duplicate gate changes |
| `gateway_ipc_binding::Service` / message structs | `score/gateway_ipc_binding/gateway_ipc_binding.hpp:82` | **Yes** (IPC wire) | **Unchanged** |

Build-placement evidence for the internal key: the public `headers` filegroup is `glob(["*.hpp"])`
(`score/socom/BUILD:17-22`), while the library `srcs` glob is `impl/**/*.cpp` + `impl/**/*.hpp`
(`:24-30`). The key therefore does not appear on any installed/public include path; it reaches only
the test package through the explicit `testonly` crate.

### 3.2 Symbol- and layout-level assessment (source-level; no ABI tool available)

- **Layout unchanged.** `Service_instance_identifier` is still exactly
  `{ Service_interface_identifier interface; Service_instance instance; }`
  (`impl/service_identifier.hpp:29-32`); its fields, their order, and their types are identical.
  `Service_instance` (`service_interface_identifier.hpp:28-55`) is likewise unchanged.
- **Signature unchanged.** The one free operator keeps the same declaration
  (`impl/service_identifier.hpp:34-36`) and definition signature
  (`impl/service_identifier.cpp:20-21`); the return type and parameter list are identical, so the
  mangled symbol `operator<(Service_instance_identifier const&, Service_instance_identifier const&)`
  is unchanged. Only the function body changed.
- **No new external symbols.** No `operator==`, no `std::hash<Service_instance_identifier>`, and no
  new member was introduced; the set still uses only `operator<` for both ordering and uniqueness.
- **No public header/layout change** on `Service_interface_identifier`, `Service_interface_definition`,
  `Runtime`, or the IPC binding (§3.1). The public `Version` is still `std::uint16_t major;
  std::uint16_t minor;` and its `operator==` / `operator<` / `std::hash` still include `minor`
  (`service_interface_identifier.hpp:130-190`).
- **IPC wire unchanged.** The wire struct embeds the public `Version` value
  (`gateway_ipc_binding.hpp:82`); since the public `Version` is unchanged and the key is not on the
  wire, there is no wire-layout change.

**Conclusion (source-level):** the bounded change is confined to the behaviour of an `impl/`-only
type and introduces **no public ABI break** (no removed/changed public symbol, no layout change, no
vtable change). This is a static reading; no symbol-table dump, `abi-compliance-checker`,
`abi-dumper`, or equivalent ABI diff was run, and no such tool is available in this task (§7.2).

---

## 4. API-behaviour review

### 4.1 The one observable behaviour change (source-derived)

| Aspect | Pre-correction (baseline key = `minor` inclusive) | Current key = `(instance, id, major)` |
|--------|---------------------------------------------------|----------------------------------------|
| Two `make_server_connector` calls sharing `(instance, id, major)` but differing only in `minor` | distinct keys → both constructed | same key → second returns `duplicate_service` |
| Duplicate detection timing | second reaches `Service_record::register_server_connector` on enable; hits `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)` | second rejected at construction (`impl/runtime_impl.cpp:449-454`) |
| Error value | none at construction; assert on enable | `Construction_error::duplicate_service` at construction |

The current gate is at `impl/runtime_impl.cpp:449-454`:
`Service_instance_identifier const identifier{configuration.get_interface(), instance};`
(`:443`), then under the key mutex `insert(identifier).second` false ⇒
`MakeUnexpected(Construction_error::duplicate_service)` (`:451-452`). The single-server precondition
`SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)` is still asserted (`:369`) and `m_server.emplace(...)`
follows (`:371`).

The change is **strictly safer** for the single-server precondition and closes the I-11 gap, but it
is not an accepted behaviour change. `SCORE_LANGUAGE_FUTURECPP_ASSERT`'s terminate-vs-compiled-out
semantics live in `score_baselibs` and are **not determined in this checkout**, so the exact
pre-change outcome remains unknown.

### 4.2 Call-site impact (behaviour only, no signature change)

Existing in-repo consumers call the public `Runtime::make_server_connector` and are affected only in
the duplicate case:

- `score/someipd/impl/remote_network_service.cpp:42-53`
- `score/someipd/impl/local_network_service.cpp:49` (same construction pattern)
- `score/gatewayd/main.cpp:229-239` and `score/gatewayd/impl/{local,remote}_service_instance.cpp`
- `score/gateway_ipc_binding/**` constructs socom identifiers from the IPC `Service` struct

None of these was compiled or run by this report; the impact is a source reading. The retained
`cross_compilation` and `native_build` legs did compile the repository at exit `0` (§1.4), but that
is a retained, scoped measurement, not this report's own execution.

### 4.3 Diverging notions of "same service" (documentation/contract gap)

There are now several distinct equivalence notions, most of which are minor-aware while the
registration key is minor-blind:

| Notion | Definition | Includes `minor`? | Site |
|--------|-----------|-------------------|------|
| Public identifier equality | `(id, major, minor)` | **Yes** | `service_interface_identifier.hpp:149-152`, `:159-162`, `:181-190` |
| Configuration equality | delegates to identifier `<` | **Yes** | `impl/service_interface_definition.cpp:37-39` |
| Duplicate-server registration key | `(instance, id, major)` | **No** | `impl/service_identifier.cpp:28-29` |
| `Service_database` record index | `(id, major)` + instance | **No** | `impl/runtime_impl.hpp:116-134` |
| IPC wire `Service` | embeds public `Version` | **Yes** | `gateway_ipc_binding.hpp:82` |

Consequences and review items:

1. **Doc wording is now imprecise.** `Runtime::make_server_connector` says a duplicate exists if
   *"a service defined by the configuration.interface and instance parameters is already
   registered"* (`runtime.hpp:170-178`). Because `configuration.interface`
   (`Service_interface_identifier`) equality is minor-aware while the gate is minor-blind, the doc
   text no longer matches the implementation for minor-only differences. It should be reworded to
   state that the identity is `(instance, service id, major)` and that `minor` is a compatibility
   property, not an identity component. This is a **documentation** change to a **public** header and
   would require source-write authorization; recorded, not applied.
2. **Client-side duplicate detection is already version-blind** (`register_client_connector` returns
   `duplicate_client` when `m_client` is set, without comparing versions,
   `impl/runtime_impl.cpp:384-388`). The draft makes server-side detection *consistent* with the
   client side and with the record index; before the draft the server side was the outlier. This
   supports the direction but does not make it accepted.
3. **Error specificity.** `Construction_error::duplicate_service` is commented only "Service
   identifier already exists" (`error.hpp:55`). Whether a collision caused solely by a differing
   `minor` should be `duplicate_service`, a more specific error, or supersede the existing connector
   is unresolved and is an API-design question for the owner of #84.

### 4.4 API surface that is explicitly unchanged

- No public header was added, removed, or edited.
- No public function signature, default argument, `noexcept` specification, or `virtual` set changed.
- No new public type, alias, operator, or specialisation was introduced.
- The `impl/`-only key still has exactly one operator and no equality/hash, so no new external symbol
  family (e.g. `operator==` or `std::hash`) was added.

---

## 5. Minor-version representation review

### 5.1 Representation across layers

| Layer | Type | Width / default | Site |
|-------|------|-----------------|------|
| Public socom `Version` | `std::uint16_t major; std::uint16_t minor;` | 16 / 16 | `service_interface_identifier.hpp:80-88` |
| IPC wire `Service` | `Service_interface_identifier::Version version;` | 16 / 16 | `gateway_ipc_binding.hpp:82` |
| SOME/IP config `ServiceType` | `service_version_major: uint8` | 8 | `score/config/mw_someip_config.fbs:19` |
| SOME/IP config `ServiceType` | `service_version_minor: uint32 = 0xFFFFFFFF` | 32, wildcard default | `score/config/mw_someip_config.fbs:23` |
| JSON samples | `"service_version_minor": 0` | concrete | `score/config/mw_someip_config.json:7`, `:25`, `:87` |

### 5.2 Narrowing / widening sites (no range or wildcard check)

Config→socom construction performs an unchecked narrowing:

- `score/someipd/impl/remote_network_service.cpp:44-45`
  (`{service_version_major(), static_cast<uint16_t>(service_version_minor())}`)
- `score/someipd/impl/local_network_service.cpp:49`
- `score/gatewayd/impl/local_service_instance.cpp:49`
- `score/gatewayd/impl/remote_service_instance.cpp:91-92`
- `score/gatewayd/main.cpp:231-232`

`service_version_minor` is `uint32` defaulting to the SOME/IP wildcard `0xFFFFFFFF`; the cast yields
`0xFFFF` and silently truncates any value `> 0xFFFF`. `service_version_major` is `uint8` widened
losslessly into `uint16`. This mirrors `invariants.md` §5.3 and is pinned in source by
`ConvertedKeyRetainsConfigWidthMajorBoundaries` (`service_identifier_tests.cpp:1590`) and
`ConvertedConfigMinorNarrowingBoundariesCollapseAndDistinguish` (`:2103`). Those cases are
**executed** by the retained 91/91 focused run (§1.4), but the run is scoped to the identifier TU
only.

### 5.3 Wildcard semantics are asymmetric today

Compatibility is `client.version.minor <= server.version.minor`
(`is_minor_version_compatible`, `impl/runtime_impl.cpp:133-136`), applied at client bind
(`:505-517`) and server connect (`:534-544`). A server configured with minor `0xFFFF` (the narrowed
wildcard) accepts every client minor `<= 0xFFFF`; a **client** configured with `0xFFFF` would instead
require the server's minor to be exactly `0xFFFF`. So the wildcard behaves like "accept any" only on
the server side; there is no explicit wildcard flag, only the arithmetic relation. This is a
representation-semantics gap, not a defect claim.

### 5.4 Interaction between the narrowed wildcard and the new minor-ignoring key (review item)

Because the registration key now ignores `minor` (`impl/service_identifier.cpp:28-29`), a server whose
configured minor narrowed to `0xFFFF` (from config `0xFFFFFFFF`) and a server with a concrete minor
(e.g. `3`) for the same `(instance, id, major)` now produce the **same** registration key and the
second is rejected as `duplicate_service`. On the reported baseline (minor included) they were
distinct keys. This is a real behavioural consequence at the intersection of the bounded key change
and the unaccepted wildcard representation:

- If `0xFFFF` is to mean "accept any minor", the duplicate gate may need to treat wildcard and
  concrete minors specially, or the wildcard should be resolved earlier (before key construction).
- If `0xFFFF` is just a coarse concrete minor, the collision is consistent with the minor-ignoring
  record index but should be documented to callers.

Either way this is **design input for the owner of #84**, not something this review may decide. It is
recorded as unresolved and out of the bounded slice.

### 5.5 Tests bearing on minor representation (present; executed only in the scoped focused run)

- `PublicIdentifierIdentityDistinguishesMajorAndMinorBoundaries`
  (`service_identifier_tests.cpp:784`) pins that the public identity stays `(id, major, minor)`.
- `ConvertedKeyRetainsInstanceServiceIdMajorAndStoresMinor` (`:813`) pins that the key stores the
  full public version but compares only `(instance, id, major)`.
- `ConvertedKeyCollapsesConfigMinorsThatNarrowAlike` (`:884`) pins that distinct config minors
  narrowing to the same 16-bit value collapse.
- `ConvertedKeyRetainsConfigWidthMajorBoundaries` (`:1590`) pins lossless widening of the 8-bit
  config major.
- Runtime-level: `ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError`
  (`runtime_tests.cpp:402-431`) pins the `duplicate_service` result on the real registration path.

The runtime-level case is **not** executed by the retained focused measurement (which compiles only
`service_identifier.cpp` + `string_registry.cpp` + `service_identifier_tests.cpp`), so the runtime
behaviour in §4.1 remains source-derived, not observed.

---

## 6. Future public identifier redesign — retained human design questions

The following are **proposals only** (`.llm_tmp/context/issue-snapshot.json:5`, 0 comments) and are
explicitly **not** implemented or endorsed by this bounded slice. They are retained here so they are
not mistaken for accepted behaviour, and are handed to human review as design questions:

1. **Move `minor` out of `Service_interface_identifier`.** The issue proposes making `minor` "a
   property of the service instance". That would change the public struct
   (`service_interface_identifier.hpp:73-124`) and therefore its layout, its inline
   `operator==`/`operator<`/`std::hash` (`:130-190`), and every public consumer that stores or
   compares it (IPC `Service`, `Service_interface_definition`, `Service_database`,
   `gateway_ipc_binding`). This is a designed, versioned **API/ABI change**, not a key tweak.
2. **Define the "service identifier" as `id + major`.** The draft already realizes this *only*
   internally (key/record index); the public and IPC layers still distinguish minors. Deciding
   whether the public identity should also drop `minor` — and how to migrate the IPC wire struct —
   is a human design question with compatibility impact.
3. **FindService `optional<minor>` / `optional<instance>` and the `major = FF` wildcard.** Neither
   exists today; introducing either would touch discovery semantics (`get_bridge_reported_instances`,
   `bridge_service_requests`, `impl/runtime_impl.cpp:553-612`) and the `Service_database` lookup. Out
   of scope and unaccepted.
4. **Wildcard representation.** Decide whether the config `uint32 0xFFFFFFFF` wildcard is resolved to
   a concrete `uint16` before key construction, carried as a distinct flag, or rejected with an error
   when non-representable (§5.3-5.4). Resolving this changes the API contract of the config→socom
   conversion sites listed in §5.2.
5. **Error semantics for a minor-only collision.** Whether `duplicate_service` should remain the
   result, become a dedicated error, or supersede is an API-contract decision (`error.hpp:55`).
6. **Config→socom conversion validation.** Whether the unchecked `static_cast<uint16_t>` narrowings
   should gain range checks or wildcard handling is a public behaviour change to conversion entry
   points and must be authorized separately.

**Recommendation to reviewers:** keep the bounded slice to the `impl/`-only key correction and the
associated tests; do not implement items 1-6 in this slice. If any of them proceeds, it must be
treated as a public API/ABI change with its own compatibility, migration (including the IPC wire
layout) and verification plan.

---

## 7. Verification evidence and gaps

### 7.1 ABI/API evidence used (direct reads this iteration)

- Public headers and the `impl/` key: `service_interface_identifier.hpp`,
  `service_interface_definition.hpp`, `impl/service_interface_definition.cpp`, `runtime.hpp`,
  `impl/runtime_impl.hpp`, `impl/runtime_impl.cpp`, `impl/service_identifier.{hpp,cpp}`,
  `error.hpp`, `gateway_ipc_binding.hpp`.
- Build-placement evidence: `score/socom/BUILD`, `score/socom/test/unit/BUILD`.
- Config representation evidence: `score/config/mw_someip_config.fbs`,
  `score/config/mw_someip_config.json`, and the narrowing sites in §5.2.
- Test evidence: `service_identifier_tests.cpp` (header/`SetUp`/cases), `runtime_tests.cpp:400-431`.
- Host/obligation artifacts: `.llm_tmp/overnight/validation/{check-result,measurement.json,before.json,
  after.json,after-compile.command.json,after-compile.stderr}` and
  `.llm_tmp/overnight/obligations/*/result.json` (as listed in §1.4).

### 7.2 What is NOT established

- No symbol-table dump, `abi-compliance-checker`/`abi-dumper`, or equivalent ABI diff was run by this
  report; no such tool was invoked in this task.
- No full public-header compile by this report: the focused measurement compiles only
  `service_identifier.cpp` + `string_registry.cpp` + `service_identifier_tests.cpp` plus googletest.
  `runtime_tests.cpp`, `interface_compatibility_tests.cpp`, `client_tests.cpp`, the IPC binding, and
  the gateway daemons were **not** compiled by the focused measurement.
- No runtime/interaction test was executed by this report, so the §4.1 duplicate-gate behaviour and
  the §5.4 wildcard/key collision are source-derived, not observed.
- `SCORE_LANGUAGE_FUTURECPP_ASSERT` semantics (terminate vs compiled out) are external
  (`score_baselibs`) and unknown, so the pre-change outcome of the single-server precondition is not
  determined.

### 7.3 Test inventory and scope (read, not run by this report)

- `score/socom/test/unit/service_identifier_tests.cpp`: **91 `TEST_F`** under
  `ServiceInstanceIdentifierTest` (counted this iteration by `grep`; `:168` … `:2181`), consistent
  with `process_checks/result.json` (`test_macros: 91`) and `validation/after.json` (91 tests). The
  file carries the Apache-2.0 header (`:1-12`) and records only `DerivationTechnique` and
  `Description` (`:42-65`); `TestType` and `Verifies` links are deliberately unset because no
  verified native requirement identifier exists for this slice.
- `score/socom/test/unit/runtime_tests.cpp`: 33 test macros (`process_checks/result.json`), comprising
  the minor-only duplicate regression `ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError`
  (`:402-431`) among the others. Never executed by the focused identifier measurement.
- The retained focused capture covers only `ServiceInstanceIdentifierTest`; it does not exercise the
  public `Runtime` API, the interface-compatibility matrix, or the IPC layer.

### 7.4 Reproduction path for a later, authorized iteration (not run here)

```bash
bazel build //score/...
bazel test //score/socom/test/unit:socom_test
# focused key-level:
bazel test //score/socom/test/unit:socom_test --test_filter='ServiceInstanceIdentifierTest.*'
# focused runtime regression:
bazel test //score/socom/test/unit:socom_test \
    --test_filter='RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError'
# cross / integration (per the pinned plans)
bazel test --config=qemu-integration //tests/integration_test/...
```

An ABI check would additionally require building the public consumer targets and comparing symbol
tables/public header layouts, which no tool in this task can do.

---

## 8. Obligations status (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Freedom from compiler warnings & errors (100 %) | `verification_plan.rst` (criterion 9) | **PARTIAL, NOT SATISFIED** — focused GCC **and** Clang `-Werror` legs exit `0` (retained); full native toolchain pins and a symbol-level build were not exercised by this report |
| Static code analysis (clang-tidy / CodeQL), findings classified | `code_analysis.rst`; `verification_process.rst` (SCA classification) | **NOT SATISFIED** — clang-tidy `--verify-config` exit `1`; cppcheck exit `2`; CodeQL scans completed but retained dependency/gtest-macro findings; MISRA mapping is `:status: draft` |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` (`:status: draft`) | **UNKNOWN — NOT CLAIMED** — mapping is draft; not applied |
| Structural statement / branch coverage goals | `verification_plan.rst` (criteria 1-2) | **NOT SATISFIED** — focused coverage 100 % line / 78.6 % branch, `complete_target_scope: false`, `safety_class: unknown_requires_authorized_selection`; below the 100 % safety / 85 % QM branch goal; native coverage used the repository CI threshold 73, not the platform goal |
| Unit/component testing executed, results recorded | `verification_plan.rst` (criteria 6-7); `verification_guideline.rst` | **PARTIAL** — retained focused identifier run is 91/91 (green), but the native test legs are `--build_tests_only` (compiled, not executed) and `full_native_tests: not_executed`; `runtime_tests.cpp` was never executed |
| Interface / requirements / resource / fault-injection test types | `verification_process.rst`; `verification_plan.rst` | **NOT PERFORMED / applicability not inferred** — no harness; identifier-only tests must not be labelled platform validation |
| Boundary / equivalence derivation | `verification_process.rst` | **SOURCE-ONLY + scoped execution** — cases exist and the focused identifier TU executed, but runtime/public/IPC paths were not |
| Fuzzy testing technique | `verification_plan.rst` | **NOT EXECUTED / NOT CLAIMED** — no harness, no measurement |
| Linking tests to requirements (record properties) | `verification_process.rst` (`gd_req__verification_link_tests_cpp`) | **PARTIAL / NOT DONE** — `DerivationTechnique`/`Description` recorded (`service_identifier_tests.cpp:42-65`; `runtime_tests.cpp` metadata helper); `TestType`/`Verifies` deliberately unset (no verified identifier exists; inventing one is prohibited) |
| Independence of verification / review | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Implementation inspection checklist IMPL_01…IMPL_03 | `inspection_checklist.rst` (`:status: draft`) | **NOT FILLED** |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** — `tool_assurance` is `completed_with_blockers` (tool-confidence evaluation, Coverity non-adoption, memcheck optionality all require authorized humans) |
| External-component AoUs verified | `verification_process.rst` (`gd_req__verification_external_aou`) | **NOT SATISFIED** — native integration run exited `1`; no AoU register |
| Obligation collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **PRESENT but retention ≠ passing** — `native_integration`/`native_lint`/`native_docs`/`native_traceability`/`native_performance`/`format_precommit`/`focused_clang_tidy`/`focused_cppcheck`/`focused_tsan`/`codeql_*`/`secret_dependency_checks` are `findings_or_execution_failure`; `tool_assurance`/`cross_compilation`/`process_checks` are `completed_with_blockers` |
| Native acceptance | `source-index.json` | **`not_inferred` for every entry** |

**Explicit non-satisfaction statement.** The unknown safety class and un-inferred applicability, the
incomplete execution (focused identifier TU only; native test legs built but not run), the failing or
blocked checks (`native_integration` exit `1`, focused TSan tests exit `66`, clang-tidy exit `1`,
cppcheck exit `2`, cppcheck/CodeQL/secret findings retained, tool-assurance blockers), the
below-goal coverage, and the unanswered human reviews mean **none of the checked obligations may be
treated as satisfied**. A successful collection node proves *retention*, not passing. In particular,
`native_build`/`cross_compilation` exiting `0` and the focused 91/91 run being green are **not**
independent verification, acceptance, or a full native runtime pass.

---

## 9. Measurement and validation status

- **Tools:** `read_file`, `grep`, `glob`, `write_file` only. No `shell`, delegation, web, approval,
  publishing, or engineering acceptance.
- **Executed measurements by this iteration:** **none**. No build, no test, no runtime. Every ABI/API
  statement above is a static reading of the working tree at the baseline-bound candidate paths, an
  explicitly-labelled logical consequence, or a record of a retained artifact.
- **Retained host measurements (present, scoped, unprotected):** focused identifier TU is
  `before 91/33` → `after 91/0` (GCC `-Werror` + UBSan per `measurement.json`), compile exit `0`,
  empty `stderr`; focused GCC **and** Clang `-Werror` legs exit `0`; `native_build` exit `0`;
  `cross_compilation` x86/arm exit `0`; native test/sanitizer/tsan legs built with
  `--build_tests_only`; native coverage used CI threshold 73; `native_integration` exit `1`. The
  focused measurement covers **no** public consumer, `runtime_tests.cpp`, or executed Bazel test.
- **Scope:** local, unprotected, scoped. This draft has not been reviewed, accepted, published, or
  reproduced on a full native runtime. Unit/integration execution and human review remain pending.

---

## 10. Notice preservation

- **Only this report was written.** No source, build, test, config, `NOTICE`, `LICENSE`,
  `REUSE.toml`, or prior-report file was created, edited, or deleted. Every existing Apache-2.0/SPDX
  header on every file read remains untouched, and all `.llm_tmp/overnight/prior-reports/` and the
  existing `.llm_tmp/overnight/reports/` files were preserved.
- The header the task flagged (`score/socom/impl/service_identifier.hpp`) was inspected and left
  unchanged because it is already brace-balanced and well-formed (§2).
- The key remains an `impl/`-only type exposed only through the `testonly`
  `//score/socom:impl_service_identifier` library; **no public notice or header surface changed**.
- No licensed MISRA rule text is reproduced; only native rule/query identifiers, file locations, and
  prior-report readings are cited.
- This report itself carries the Apache-2.0 header.

---

## 11. Pending human review checklist

- [ ] **Confirm §2:** the header is already brace-balanced (nested close at `:38`; line `:39` blank),
  the focused GCC and Clang compiles exit `0`, and the recorded "extra closing brace at line 39" is
  stale; if a different "cancelled draft" revision still carries the brace, locate it and authorize
  its correction (it is not this checkout).
- [ ] **Resolve the instruction conflict:** the task directs correcting the source, while the actual
  source contains no defect and the explicit write boundary permits only this report. Confirm that
  inspection-only plus this report is the intended outcome.
- [ ] **Ratify the §3 ABI conclusion:** the bounded change is confined to an `impl/`-only type and is
  source-level ABI-neutral; confirm no public header/layout/symbol change is expected, and authorize
  an ABI-checker run on a real Bazel build before release (not possible in this task).
- [ ] **Decide the §4.1 API-behaviour change:** `Runtime::make_server_connector` now returns
  `duplicate_service` for a minor-only collision instead of constructing a second connector. Confirm
  this is the intended contract and that `SCORE_LANGUAGE_FUTURECPP_ASSERT` semantics make the
  pre-change path safe or that the change is required.
- [ ] **Authorize the §4.3 documentation correction** to `runtime.hpp:170-178` (state identity =
  `(instance, service id, major)`; `minor` is a compatibility property) — a public-header edit that
  this review could not apply.
- [ ] **Resolve the §5 minor-representation questions:** the `uint32 0xFFFFFFFF` config wildcard
  narrowed by `static_cast<uint16_t>` at five sites, the asymmetric server-side wildcard, and the
  §5.4 collision between a wildcard-narrowed `0xFFFF` server and a concrete-minor server under the new
  key. Adjudicate representation, validation and error semantics.
- [ ] **Keep the §6 public identifier redesign as a design question:** service identifier
  `= id + major`, moving `minor` onto the instance, FindService `optional<minor>`/`optional<instance>`,
  `major = FF` wildcard, and the IPC wire migration. Do not implement in this bounded slice; if
  pursued, treat as a versioned public API/ABI change with its own compatibility and verification
  plan.
- [ ] **Confirm the §7.3 scope/staleness:** the retained measurement covers only the identifier TU
  (91 cases), `runtime_tests.cpp` was never executed, and no public/runtime/IPC consumer was
  exercised by it.
- [ ] **Do not infer passing from retained collection nodes** (§8): `native_*` test legs are
  build-only, `native_integration` exited `1`, focused TSan tests exited `66`, clang-tidy/cppcheck are
  blocked or finding, CodeQL/secret retained findings, tool assurance has blockers, coverage is scoped
  and below the platform goal, and applicability is `not_inferred`.
- [ ] **Run the full native suite** (`bazel test //score/socom/test/unit:socom_test` and the broader
  `//score/...` set, including `runtime_tests.cpp` and the interface-compatibility matrix), record
  the results, and schedule independent human review (approver ≠ author, per
  `gd_req__verification_independence`).
- [ ] **Select a safety class** via the authorized role; do not infer the slice's class from the
  `:safety: ASIL_B` attribute on the pinned platform documents.

---

*End of ABI/API review draft. Local, unprotected, scoped. No engineering acceptance; human reviews
unanswered; full native runtime tests pending. Every statement is a local reading of the working tree,
a prior report's recorded reading, a record of a retained artifact, or an explicitly-labelled logical
consequence — none is acceptance, review approval, publication, or a full native run.*
