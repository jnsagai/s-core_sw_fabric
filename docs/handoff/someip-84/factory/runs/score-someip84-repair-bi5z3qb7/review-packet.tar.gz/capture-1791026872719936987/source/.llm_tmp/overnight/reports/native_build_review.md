<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — native build and full-test review (`native_build_review`)

**Document type:** review draft (native Bazel build/test review + actual-source inspection +
toolchain/target identity register + separation of measured results from unavailable
dependencies and platform/configuration gaps + obligations status).

**Date:** 2026-10-03
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling inside *Revise version handling in
socom* (issue #84)
**Run / branch:** `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ`
**Verified baseline commit:** `f8a196c3b16d5172d898394ab99b0ed81346d63d`
(`.llm_tmp/context/source-manifest.json:3`)
**Status:** **local, unprotected, scoped.** No engineering acceptance exists. Human reviews are
unanswered. Full native runtime tests remain pending. Nothing in this document is acceptance,
review, publication, or a full native run.

> **Tool / write boundary observed.** This iteration used only `read_file`, `grep`, `glob`, and
> `write_file`. No `shell`, no delegation, no web access, no approval, no publishing, and no
> engineering acceptance was performed. The task's explicit final sentence — *"This is a review
> draft: only that report may be written"* — was followed: **exactly one file was written, this
> report** (`/workspace/.llm_tmp/overnight/reports/native_build_review.md`). No source, build, test,
> config, `NOTICE`, `LICENSE`, `REUSE.toml`, host-validation, or prior-report file was created,
> edited, or deleted. Every report under `.llm_tmp/overnight/reports/` and every file under
> `.llm_tmp/overnight/prior-reports/` was preserved unchanged.
>
> **Instruction conflict, recorded not silently resolved.** The task records *"the cancelled draft
> has a measured GCC syntax failure: an extra closing brace in
> `score/socom/impl/service_identifier.hpp` at line 39"* and directs *"Inspect and correct the
> actual source before expanding tests."* Direct inspection of the **actual** source (§2) shows the
> header is **already brace-balanced** and line 39 is blank; the retained focused GCC/Clang
> `-Werror` compiles exit `0`, and the Bazel build of `//...` exits `0`. There is no unmatched brace
> to remove. The task's own final sentence forbids a source write in any case. **No source was
> edited and no test was expanded.** The conflict is recorded for the human reviewer (§11).

> **Non-satisfaction rule applied throughout.** A successful obligation-collection node means the
> results were **retained**, not that the checks **passed**. Missing tools, unknown applicability,
> incomplete extraction, unanswered human reviews, and checks that only *built* a target without
> *executing* it are **not** treated as satisfied. In particular, a tool that produced **no** finding
> because it **did not run** (or did not complete) is recorded as *"not run"*, never as *"clean"*;
> and a leg that succeeded only because it was build-only is recorded as *"built, not executed"*.

---

## 0. Summary

1. **The recorded GCC syntax failure is not present in the actual source (§2).**
   `score/socom/impl/service_identifier.hpp` is a 40-line, brace-balanced header. A direct `grep`
   for `[{}]` returns exactly four brace-bearing lines — `:19` (`namespace score::socom {`), `:29`
   (`struct Service_instance_identifier final {`), `:32` (`};`), `:38`
   (`}  // namespace score::socom`) — two openers, two closers, net balance `0`; line `:39` is blank
   and `:40` is `#endif`. The retained focused **GCC** (`g++-12 -Werror`) and **Clang** 19
   (`-Werror`) compiles both exit `0` (`compiler_diagnostics/result.json`), and the native Bazel
   build of `//...` exits `0` (§3). **No correction is required or applied.**
2. **The native Bazel build actually ran and succeeded (§3).** Unlike the earlier
   `prior-reports/native_build_review.md` iteration — which recorded every native leg as an
   unavailable-tool blocker (`bazel` missing at `/tmp/s-core-001/bin/bazel`, exit `127`) — the
   retained obligation artifacts in this checkout show a provisioned tool workspace with **Bazel
   8.6.0**. `native_build` ran `bazel build --jobs=2 //...` and exited **0** with `status:
   completed` and `blockers: []`.
3. **The unit/component test suite actually executed and passed, but only via `//:unit_tests`
   `//:component_tests` (§4).** `native_traceability`'s `unit-component-tests` leg ran
   `bazel test //:unit_tests //:component_tests` (exit **0**) and its retained stdout records
   `//score/socom/test/unit:socom_test PASSED in 1.4s` and
   `Executed 4 out of 4 tests: 4 tests pass.` This is the strongest genuine full-ish native test
   execution available: `socom_test` globs **every** `score/socom/test/unit/*.cpp`, including the
   issue-#84 suites. It is **not** `bazel test //...` execution.
4. **`native_tests` itself was build-only (§4.1).** The leg ran
   `bazel test --jobs=2 //... --build_tests_only` (exit 0): it found and built **29 test targets**
   ("20 / 29 tests"; `Build completed successfully, 22 total actions`) but its retained stdout has
   **no** `Executed N out of N tests` summary. Built ≠ executed. The sanitizer and TSan Bazel legs
   (`native_sanitizers`, `native_tsan`) are likewise `--build_tests_only` and only built.
5. **The only executed red-to-green evidence for the key change is the focused GCC/UBSan
   measurement (§7).** `validation/measurement.json` records
   `baseline_with_agent_tests {compile 0, test exit 1, 91 tests, 33 failures}` and
   `candidate {compile 0, test exit 0, 91 tests, 0 failures}` on the focused translation unit only
   (`service_identifier.cpp` + `string_registry.cpp` + `service_identifier_tests.cpp` + vendored
   googletest; candidate adds `-fsanitize=undefined -fno-sanitize-recover=all`). It is genuine but
   scoped, and **not** a Bazel build or run.
6. **Several legs genuinely ran but did not pass, or did not run at all (§6).** `native_docs`
   (`//:docs`) exit `2`; `native_traceability`'s `docs` exit `2` and `traceability_gate` exit `1`;
   `native_integration` (`--config=qemu-integration`) exit `1` with KVM/QEMU present;
   `native_performance` benchmarks/profiling both exit `124` (timeout); `native_lint` clang-tidy
   exit `124` (timeout) though `ruff` exit `0`; `format_precommit` `format.check` exit `124` and
   `reuse lint` exit `1`; `focused_clang_tidy` `--verify-config` exit `1`;
   `focused_tsan` execution exit `66`; `cross_compilation` carries a QNX entitlement blocker.
   `gitleaks` ran (exit `1`) and its retained findings are in the tool artifacts
   (`.llm_tmp/overnight/obligations/**/result.json`) and `quality/.../init_x86_64.build`, **not**
   in the six candidate paths.
7. **Criterion 9 is not satisfied by the default native build.** `.bazelrc:117` sets
   `common --features=-treat_warnings_as_errors`, so the default Bazel build tolerates warnings;
   only the focused GCC/Clang host compiles used `-Werror`.
8. **No obligation is satisfied (§10).** Every `source-index.json` entry is
   `native_acceptance: not_inferred`; `authority.json` records
   `engineering_acceptance: pending`, `human_reviews: unanswered`, `safety_class: unknown`.

---

## 1. Binding, scope, and evidence

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` — *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:2-4` |
| State | `open`, **0 comments**, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` (unchanged) | `.llm_tmp/context/issue-snapshot.json:19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**: service-instance identifier = `service id + major + minor + instance id`; service
identifier = `service id + major`; FindService = `service id + major + optional<minor> +
optional<instance>`; plus a proposal to exclude `minor` from identity. There is no comment and no
acceptance record, so none of it is binding.

### 1.2 Baseline and changed-file identity

Binding is **by baseline commit `f8a196c3…`**, not by run HEAD.

| Candidate path | Baseline git blob (`source-manifest.json`) | `candidate-files.json` sha256 | `native_build` measured working-tree sha256 | Direct read this iteration |
|----------------|--------------------------------------------|-------------------------------|--------------------------------------------|----------------------------|
| `score/socom/BUILD` | `3477ea0851fdcd82ec6ea9d71424013cbdf41962` | `dee826163ac5e6336d51a293136b424696c2884aa1b2592395e1e06423c0ba44` | `68f4645a21e495fac43929fb125f7ba0b9e29fc84c0401fdb95238ffb7fd2cc8` | `testonly impl_service_identifier` exposure present (`:46-54`) |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e22355242009fe20dada2a9a0d0c7a9c7` | `d766902e4bda5306095a6e5326ea91d28df3a6e1ef4e77dc9ba47556ed559a9a` | `3c12b3f1dd3f1fa66cdf43766f374d7d067637bf8f11aba604c4e2688351f11a` | key identity `(instance, id, major)`; `minor` excluded (`:20-30`) |
| `score/socom/impl/service_identifier.hpp` | `c8bae7908da9f087c518934f7b9f8d86db9a20ec` | `96b33a1fee4d54577ae9bc46c313409a0d59336f76df85ef1925ffebdd1a2119` | `bdce3fcbc3cd78a8ecaece1ea36107d464011ab81c9bc39932d0be617befaea9` | **brace-balanced**, 40 lines; `:39` blank (§2) |
| `score/socom/test/unit/BUILD` | `3c03a7b14286051f97fa5022206564bd63645171` | `9b3c5b341211e2c387858fd1fe5c669a6a422b6e8b5e80fce35ba22c61186799` | `e909151e822370bebe8d59b86369bddeb4d6cacfa02f10061bf6e134671ff9d4` | `socom_test` globs `*.cpp`; deps wired (`:16-29`) |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab726db8bf994c960045d6fd7fdf84d7395` | `5e35e24d0abcfa361b5a5283a005b307b86026a970464a3423be7c6eed66631e` | `9a2d6a154683a2b7ff9d51b7241e4fb74c1a8ef483895830cb409a8f5a1d3127` | **33 test macros** (`process_checks`); minor-only regression `:402-431` |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(none — `null`)* | `45d073998108df76c8f4534508d65f02cead28aa568cd5c45b5a3d8a4fd36a25` | `de79767c4653feca7b5b2fcf93f5a791bcc64ae4b554dc2ef35a8756536391e6` | **91 test macros** (`process_checks`); metadata `SetUp()` |

The `null` baseline blob is the manifest's expectation of a **new** unit-test file; it exists on
disk only in the un-merged working tree (the task's "cancelled draft"). Five of the six candidate
paths have a baseline blob that is **different** from the working tree, i.e. the working tree
carries the agent's changes; the harness-recorded `candidate-files.json` hash and the
native-workspace-measured hash differ for the same paths (the two captures are different copies).
No hashing tool was available in this iteration, so the working tree was **not** re-hashed; the
direct reads in §2–§4 are authoritative for this report.

### 1.3 Evidence read this iteration

- `.llm_tmp/context/`: `issue-snapshot.json`, `candidate-files.json`, `source-manifest.json`,
  `obligations/authority.json`, `obligations/source-index.json`.
- `.llm_tmp/overnight/validation/`: `check-result` (`0`), `measurement.json`, `before.json`,
  `after.json`, `before/after-compile.*`, `before/after-test.*`.
- `.llm_tmp/overnight/obligations/*/result.json` and companion logs: `native_build`, `native_tests`,
  `native_traceability`, `native_docs`, `native_lint`, `native_coverage`, `native_sanitizers`,
  `native_tsan`, `native_integration`, `native_performance`, `cross_compilation`,
  `compiler_diagnostics`, `format_precommit`, `secret_dependency_checks`, `tool_assurance`,
  `process_checks`, `rework_progress`, `focused_asan_lsan`, `focused_tsan`, `focused_memcheck`,
  `focused_coverage`, `focused_clang_tidy`, `focused_cppcheck`.
- `.llm_tmp/overnight/reports/` (read, preserved) and `.llm_tmp/overnight/prior-reports/` (read,
  preserved), including `scope.md`, `key_fix.md`, `reproducer.md`, `invariants.md`, and
  `prior-reports/native_build_review.md`.

Per the task rule, a successful collection node means results were **retained**, not that checks
**passed**.

### 1.4 Pinned authority and obligation sources

`authority.json`: `engineering_acceptance: pending`, `human_reviews: unanswered`,
`safety_class: unknown`, `codeql_scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway; no
upload"`, instruction *"Restart the failed queue for one complete pass through all obligations"*.
Every entry of `source-index.json` is `"native_acceptance": "not_inferred"` (all nine:
`coding_guidelines`, `code_analysis`, `misra_mapping` *[draft]*, `verification_plan`,
`development_plan`, `tool_management`, `verification_process`, `verification_guideline`,
`inspection_checklist` *[draft]*).

---

## 2. Actual-source inspection of the recorded syntax failure

### 2.1 Verdict: the header is brace-balanced

`score/socom/impl/service_identifier.hpp`, read directly this iteration. A `grep` for `[{}]` on
the file returns exactly four lines:

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`) and two closers (`:32`, `:38`) give net brace balance `0`. Line 39
contains no text. A `glob **/service_identifier.hpp` returns exactly one path, so there is no
second, differently-braced copy in this checkout. The sibling `score/socom/impl/service_identifier.cpp`
uses the same nested form (`:18` / `:32`) and is balanced.

### 2.2 Measured corroboration

- `obligations/compiler_diagnostics/result.json` records `gcc-compile` (g++-12,
  `-std=c++17 -Wall -Wextra -Werror -pthread -I.`) with `"exit_code": 0`, followed by
  `gcc-tests` `"exit_code": 0`; **and** `clang-compile` (Clang 19, same `-Werror` flags) with
  `"exit_code": 0`, followed by `clang-tests` `"exit_code": 0` (8 commands, all exit 0).
  Limits recorded: *"Focused executable only; GCC 12.3 / Clang 19 differ from native toolchain
  pins"*.
- `obligations/native_build/result.json`: `bazel build --jobs=2 //...` exit `0` (§3). A surviving
  extra closing brace would break the build and the focused compiles.
- `validation/before-compile.stderr` and `validation/after-compile.stderr` are both empty.

### 2.3 Disposition

The described defect is a **stale, pre-correction description**. The preserved reports
(`prior-reports/reproducer.md` §2, `reports/scope.md` §2, `reports/key_fix.md` §2) record that the
earliest reports quoted lines 38–39 as the split-form `}  // namespace socom` + `}  // namespace
score`, and that the correction left line 39 blank — exactly the state observed here. Applying the
historical repair to the already-balanced file would be a no-op at best and a compile break at
worst. **No correction is applied; none is required.** Consistent with the write boundary, no test
was expanded either. If the *"cancelled draft"* is a distinct revision that still carries the
brace, it is not the file in this checkout and must be located and corrected by an authorized
iteration.

---

## 3. Native Bazel build (actual result)

`obligations/native_build/result.json` / `build.command.json`:

| Field | Value |
|-------|-------|
| `check` / `check_ref` | `native_build` / `recollect_native_build` |
| Command | `bazel --batch --output_user_root=<cache> build --jobs=2 //...` |
| cwd | `…/native-workspace` |
| Environment | `USE_BAZEL_VERSION=8.6.0`, `BAZELISK_HOME=…`, `PATH=…/score-someip84-tools-…/bin:…` |
| `exit_code` | **0** |
| `status` / `blockers` | `completed` / **`[]`** |
| Origin / acceptance | `local_unprotected_measurement` / `engineering_acceptance: pending` |
| `reused_from` | earlier `native_build-1790996172620510467/result.json` |

`build.stderr` is empty. `build.stdout` records the analysis of **153 targets** and reproduces
warning text only from third-party `external/flatbuffers+` (GCC-12 `-Wdeprecated-declarations` on
`std::get_temporary_buffer`, 8 warnings) — **no `ERROR` and no `BUILD FAILED`**. The stored stdout
is truncated mid-warning stream, so the final `INFO: Build completed successfully` line is not in
the retained capture; the authoritative success record is the `exit_code: 0` and
`status: completed` in `result.json`.

**Reading:** the Bazel graph, `MODULE.bazel` dependency resolution, and the pinned
`@score_bazel_cpp_toolchains` / `toolchains_llvm` toolchain now resolve and build on the host
target. This supersedes the earlier `prior-reports/native_build_review.md` §4.1, which recorded
`bazel` as missing (exit 127). It is a **local, unprotected** measurement, not acceptance.

---

## 4. Native test results — what executed versus what was only built

### 4.1 `native_tests` — build-only

`obligations/native_tests/result.json` / `tests.command.json`:

| Field | Value |
|-------|-------|
| Command | `bazel --batch --output_user_root=<cache> test --jobs=2 //... --build_tests_only` |
| `exit_code` | **0** |
| `status` / `blockers` | `completed` / **`[]`** |
| Origin | `local_unprotected_measurement` |

`tests.stdout` (complete, 40 lines) ends:

```
[1,540 / 1,573] Testing //score/gateway_ipc_binding/test:gateway_ipc_binding_test; 3s linux-sandbox
…
[1,573 / 1,574] 20 / 29 tests; Testing //:python_requirements.test; 4s local
INFO: Found 29 test targets...
INFO: Elapsed time: 74.693s, Critical Path: 6.82s
INFO: 22 processes: 1574 action cache hit, 35 linux-sandbox, 2 local.
INFO: Build completed successfully, 22 total actions
```

There is **no** `Executed N out of N tests` / `N tests pass` summary. Consistent with
`--build_tests_only`, this leg **built** the 29 test targets (including `socom_test`, whose glob
covers `runtime_tests.cpp` and `service_identifier_tests.cpp`) without producing an executed-test
result. **Built ≠ executed.**

### 4.2 `native_traceability` `unit-component-tests` — actually executed, passed

`obligations/native_traceability/result.json` and `unit-component-tests.stdout`:

| Field | Value |
|-------|-------|
| Command | `bazel --batch --output_user_root=<cache> test --jobs=2 //:unit_tests //:component_tests` |
| `exit_code` | **0** |

`unit-component-tests.stdout` (complete, 6 lines):

```
//score/gateway_ipc_binding/test:gateway_ipc_binding_test                PASSED in 3.3s
//score/serializer:null_serializer_test                                  PASSED in 0.0s
//score/socom/test/stress:socom_stress_test                              PASSED in 7.2s
//score/socom/test/unit:socom_test                                       PASSED in 1.4s

Executed 4 out of 4 tests: 4 tests pass.
```

**Reading:** `//score/socom/test/unit:socom_test` — the single `cc_test` that globs **every**
`score/socom/test/unit/*.cpp`, i.e. the 91-case key suite **and** the 33-macro
`runtime_tests.cpp` including the minor-only duplicate regression — **executed and passed**. This
is the strongest genuine native test execution available in this checkout. It is still **not**
`bazel test //...` (only the two aggregate test suites ran), and it does not replace the sanitizer,
integration, or cross-target runs.

The same `native_traceability` result is `status: findings_or_execution_failure` overall: its
`docs` leg (`bazel run //:docs`) exits `2` and its `traceability` leg
(`bazel run //:traceability_gate -- --need-type=comp_req`) exits `1`. Those are real failures of
the documentation/traceability checks, not of `socom_test`.

### 4.3 Focused red-to-green measurement (`validation/`)

`validation/confirmation` artifacts, `measurement.json` end fields and `before.json`/`after.json`:

| Artifact | Tests | Failures | Disabled | Errors | Compile exit | Test exit |
|----------|-------|----------|----------|--------|--------------|-----------|
| `before.json` (`baseline_with_agent_tests`) | 91 | **33** | 0 | 0 | 0 | 1 |
| `after.json` (`candidate`) | 91 | **0** | 0 | 0 | 0 | 0 |

`measurement.json`: `check_ref: check_conversion_tests`, `mode: ubsan`, `status: completed`,
`changed_paths: ["score/socom/test/unit/service_identifier_tests.cpp"]`,
`origin: local_unprotected_measurement`, `initiator: Fabro host hook`,
`engineering_acceptance: pending`, `full_native_tests: not_executed`,
`compiler: /usr/bin/x86_64-linux-gnu-g++-12`,
`compiler_sha256: 88315fd2d961a1f4e4070b104d7bd4c7670df19d9949409879ba269466c196d3`. `check-result`
is `0`.

The compile/run command (`validation/after-compile.command.json`, `after-test.command.json`)
compiled **only** `score/socom/impl/service_identifier.cpp` + `score/socom/impl/string_registry.cpp`
+ `score/socom/test/unit/service_identifier_tests.cpp` + vendored googletest
(`gtest-all.cc`, `gtest_main.cc`) with `g++-12 -std=c++17 -Wall -Wextra -Werror -pthread`; the
candidate adds `-fsanitize=undefined -fno-sanitize-recover=all`. `after-compile.stderr` and
`after-test.stderr` are both empty.

**Interpretation (measured, scoped):** the corrected key turns the focused baseline red state
(33/91 failures) green (0/91) in a sanitizer-enabled focused binary. It does **not** compile or run
`runtime_tests.cpp`, the full `socom_test` glob, or any Bazel target.

### 4.4 Other focused results actually executed

| Check | Command (focused TU) | Result | Status |
|-------|----------------------|--------|--------|
| `focused_asan_lsan` | g++-12 ASan/LSan/UBSan executable + tests | compile 0, tests 0 | `completed` |
| `focused_memcheck` | g++-12 `-g` + `valgrind --tool=memcheck --leak-check=full --error-exitcode=42` | compile 0, memcheck **0** | `completed` |
| `focused_tsan` | g++-12 `-fsanitize=thread` executable + tests | compile 0, tests **66** | `findings_or_execution_failure` |
| `focused_coverage` | g++-12 `--coverage` + `gcovr` | compile 0, tests 0, gcovr 0 | `completed` |
| `focused_clang_tidy` | `clang-tidy --verify-config --config-file=.clang-tidy` | **1** | `findings_or_execution_failure` |
| `focused_cppcheck` | `cppcheck` focused run | findings | `findings_or_execution_failure` |

`focused_coverage` measured `score/socom/impl/service_identifier.cpp` +
`score/socom/impl/string_registry.cpp`: `line_total 36`, `line_covered 36` (**100.0 %**),
`branch_total 14`, `branch_covered 11` (**78.6 %**), `platform_goals {QM: 85, safety: 100}`,
`safety_class: unknown_requires_authorized_selection`, `complete_target_scope: false`. Line goal
met; **branch goal not met**, and the scope is a focused executable, not the native target.

`focused_tsan` compile exits 0 but execution exits `66` (a non-zero TSan result); it is **not** a
pass. `focused_clang_tidy` produced zero findings because the configuration was rejected — record
it as *"not run"*, never *"clean"*.

---

## 5. Selected toolchain and target identity register

Identities recorded by the retained artifacts (`tool_assurance` `version-*.stdout`; each
obligation `result.json` environment):

| Role | Identity | Available | Notes |
|------|----------|-----------|-------|
| Bazel driver | `/…/score-someip84-tools-…/bin/bazel`, `bazel 8.6.0` (`USE_BAZEL_VERSION=8.6.0`) | **yes** | previously missing; `.bazelversion` = `8.6.0` |
| Host C++ compiler (focused) | `/usr/bin/x86_64-linux-gnu-g++-12`, sha256 `88315fd2…c196d3` | yes | used with `-Werror` in focused legs |
| Clang compiler | `…/llvm-19.1.7/…/clang++` | yes | used with `-Werror` in `compiler_diagnostics` |
| clang-tidy | `…/llvm-19.1.7/…/clang-tidy` | yes (incompatible config) | `--verify-config` rejects `.clang-tidy` |
| CodeQL | `…/codeql-2.21.4/codeql/codeql` | yes | used by `codeql_security` / `codeql_misra` |
| gcov / gcovr | `/usr/bin/gcov-12`, `/usr/bin/gcovr` | yes | `focused_coverage` |
| valgrind | `/…/score-someip84-tools-…/bin/valgrind` | yes | `focused_memcheck` exit 0 |
| gitleaks | `/…/score-someip84-tools-…/bin/gitleaks` | yes | ran, exit 1 (findings, §6.4) |
| pre-commit / reuse | `/…/bin/pre-commit`, `/…/bin/reuse` | yes | pre-commit 0; reuse lint 1 |
| QEMU | `/usr/bin/qemu-system-x86_64`, `kvm_exists: true` | yes | prerequisites present, integration run still exit 1 |
| Coverity | — | **no** | `tool_assurance` blocker |

Native target/config identities exercised (or attempted) by the collected legs: `//...`,
`//score/...`, `//tests/...`, `//:unit_tests`, `//:component_tests`, `//:docs`,
`//:traceability_gate`, `//:clang-tidy.check`, `//:ruff.check`, `//:format.check`,
`//tests/benchmarks/...`, `//quality/...`, `//tests/integration_test/...`; configs `x86_64-linux`,
`aarch64-linux`, `qemu-integration`, `perf-tests`, `perf-tests-flamegraphs`; features
`asan`, `lsan`, `ubsan_clang`, `tsan`; coverage env `COVERAGE_THRESHOLD=73`.

**Tool *identification* is not tool *qualification*.** `tool_assurance`'s blockers are explicit:
*"Tool confidence evaluation, qualification where applicable, and acceptance require authorized
humans"*, *"Coverity not installed/adopted here; reconcile guideline/development-plan
discrepancy"*, *"Memcheck is an optional complement, not a universal process mandate"*.

---

## 6. Separation: actual results, unavailable dependencies, platform/config gaps

### 6.1 Genuine results that ran and succeeded (local, unprotected, scoped)

- `native_build`: `bazel build //...` exit **0**, `status: completed`, `blockers: []`.
- `native_tests`: `bazel test //... --build_tests_only` exit **0** (built 29 test targets).
- `native_traceability` `unit-component-tests`: `bazel test //:unit_tests //:component_tests`
  exit **0**; `socom_test PASSED`; `Executed 4 out of 4 tests: 4 tests pass.`
- `compiler_diagnostics`: GCC `-Werror` and Clang 19 `-Werror` focused compile+tests, all exit **0**.
- `cross_compilation`: `bazel build --config=x86_64-linux //score/... //tests/...` exit **0**;
  `--config=aarch64-linux` same, exit **0** (`status: completed_with_blockers`).
- `native_sanitizers`: `bazel test //score/... //tests/... --build_tests_only
  --features=asan --features=lsan --features=ubsan_clang` exit **0** (built).
- `native_tsan`: `bazel test //score/... //tests/... --build_tests_only --features=tsan` exit **0**
  (built).
- `native_coverage`: `bazel coverage //... --build_tests_only` (env `COVERAGE_THRESHOLD=73`) exit
  **0**; report exit **0**.
- Focused `validation` measurement: candidate 91/91, 0 failures (vs baseline 33 failures); UBSan.
- `focused_asan_lsan`, `focused_memcheck`: compile+tests/memcheck exit **0**.
- `format_precommit`: `git-init`, `git-add`, `pre-commit`, `bazel mod tidy`, lockfile all exit **0**.

### 6.2 Genuine runs that did **not** pass

| Check | Command | Exit | Class |
|-------|---------|------|-------|
| `native_docs` | `bazel run //:docs` | **2** | documentation build failure |
| `native_traceability` `docs` | `bazel run //:docs` | **2** | documentation build failure |
| `native_traceability` `traceability` | `//:traceability_gate -- --need-type=comp_req` | **1** | traceability gate failure |
| `native_integration` | `bazel test --config=qemu-integration //quality/... //tests/integration_test/...` | **1** | integration failure (KVM/QEMU present) |
| `native_performance` `benchmarks` | `bazel test --config=perf-tests //tests/benchmarks/... --build_tests_only` | **124** | timeout |
| `native_performance` `profiling` | `--config=perf-tests-flamegraphs` same | **124** | timeout |
| `native_lint` `clang-tidy` | `bazel run //:clang-tidy.check` | **124** | timeout |
| `format_precommit` `format` | `bazel test //:format.check` | **124** | timeout |
| `format_precommit` `reuse` | `reuse lint` | **1** | license/reuse lint failure |
| `focused_clang_tidy` | `clang-tidy --verify-config` | **1** | configuration rejected |
| `focused_tsan` | TSan executable | **66** | execution failure |
| `secret_dependency_checks` | `gitleaks dir …` | **1** | findings (see §6.4) |

These are **failures to pass**, not missing tools. `native_lint` overall is
`findings_or_execution_failure`: `ruff.check` exits `0` but `clang-tidy.check` times out, so static
analysis has **not** produced a verdict.

### 6.3 Unavailable dependencies / platform and configuration gaps

- **QNX entitlement.** `cross_compilation` `blockers`: *"QNX SDK entitlement and target execution
  not configured; no credential acquired"*. Host `x86_64`/`aarch64` builds succeed, but the QNX
  target build/execution is a platform gap.
- **clang-tidy configuration.** `focused_clang_tidy` blocker: *"Native analyzer configuration
  incompatible; no replacement called MISRA"*; the native `//:clang-tidy.check` leg additionally
  times out. No analyzer verdict exists.
- **Coverity.** Not installed/adopted (`tool_assurance` blocker).
- **`native_coverage` threshold semantics.** Limit: *"Repository CI threshold 73 is not platform
  85/100 line-and-branch acceptance"*. The focused branch result (78.6 %) is below the safety goal
  anyway.
- **`format_precommit` scope.** Limit: *"Formatting/pre-commit mutations occur only in this
  disposable collector copy"*.
- **Bazel warnings posture.** `.bazelrc:117` sets `common --features=-treat_warnings_as_errors`;
  the default native build therefore does **not** enforce criterion 9's 100 % warning freedom.
- **Incomplete extraction.** The stored `native_build/build.stdout` is truncated before its final
  summary line, so the build is evidenced by `exit_code: 0` / `status: completed` rather than by a
  retained `Build completed successfully` line.
- **Compiled-vs-pinned toolchain.** `compiler_diagnostics` limit: *"Focused executable only; GCC
  12.3 / Clang 19 differ from native toolchain pins"*.
- **Human review.** `authority.json`: `human_reviews: unanswered`, `safety_class: unknown`; no
  authorized safety-class selection exists.

### 6.4 Secret scan findings

`secret_dependency_checks` ran `gitleaks` (exit **1**). The retained `secret-findings.json`
entries are `generic-api-key` matches against hash strings inside
`.llm_tmp/overnight/obligations/**/result.json` (the tool's own artifacts) plus one `private-key`
match in `quality/integration_testing/environments/qnx8_qemu/init_x86_64.build`. **None** are in
the six candidate paths. Blocker recorded: *"No adopted vulnerability database/ecosystem mapping or
GitHub dependency scan receipt; dependency inventory is not a vulnerability scan"*. The dependency
inventory (e.g. `googletest 1.18.0`, `rules_cc 0.2.22`, `score_bazel_cpp_toolchains 1.0.3`,
`toolchains_llvm 1.8.0`) is **not** a vulnerability result. This is recorded as a finding to
disposition, not as "clean" and not as "in-scope defect".

### 6.5 Process metadata (not build/test evidence)

- `process_checks`: `completed_with_blockers`; metadata inventory `runtime_tests.cpp` **33** test
  macros, `service_identifier_tests.cpp` **91** test macros, each carrying only
  `DerivationTechnique`/`Description`. Blockers: lexical inventory cannot prove semantic
  requirement coverage; safety/QM applicability unknown; independent inspection required; external
  AoU/full integration need scoped review.
- `rework_progress`: `completed`, `source_changed_this_round: false`, `rework_requested: false`,
  stop reason *"One complete pass requested; unresolved findings stay pending"*.

---

## 7. Why focused GCC tests cannot satisfy full Bazel readiness

1. **Different build system and scope.** The focused measurement (§4.3) is a single `g++-12`
   command line over three source files plus vendored googletest. It does **not** exercise the
   Bazel graph, `BUILD` wiring (`//score/socom:socom`, `//score/socom:impl_service_identifier`,
   `//score/socom/test/unit:socom_test`), `MODULE.bazel` resolution, or the pinned toolchains. The
   Bazel build (§3) and the executed `socom_test` (§4.2) are separate, stronger results — but the
   focused run itself is not a substitute for either.
2. **`runtime_tests.cpp` is not in the focused unit.** The focused compile covers only
   `service_identifier.cpp` + `string_registry.cpp` + `service_identifier_tests.cpp`; the runtime
   registration regression (`runtime_tests.cpp:402-431`) is covered only by the Bazel `socom_test`
   run (§4.2).
3. **Warnings posture differs.** The focused legs use `-Werror`; the default native build disables
   warnings-as-errors (`.bazelrc:117`). Criterion 9 (100 % freedom from compiler warnings/errors)
   is therefore **not** established by the default native build, only by the focused host compiles.
4. **Bazel test legs are build-only.** `native_tests`, `native_sanitizers`, and `native_tsan` all
   use `--build_tests_only`; they compile configured test targets but produce no execution result.
   The only executed unit/component result is `//:unit_tests //:component_tests` (§4.2).
5. **Sanitizer scope.** The Bazel ASan/LSan/UBSan/TSan legs only built; the focused
   ASan/LSan/UBSan binary is a narrow substitute, and the focused TSan execution failed (exit 66),
   so no concurrency verdict exists.
6. **Integration/performance/cross gaps.** QEMU integration exits 1; benchmarks/profiling time
   out; the QNX entitlement is missing. A focused host-TU pass says nothing about any of these.
7. **Coverage gap.** Even the focused coverage is below the safety branch goal (78.6 % vs 100 %)
   and `complete_target_scope` is `false`.

**Conclusion:** the focused GCC/UBSan green run is a necessary-but-insufficient precondition. It
**cannot** be reported as full Bazel readiness, native test success, or criterion-9 compliance.

---

## 8. Measurement and validation status

- **Tools used:** `read_file`, `grep`, `glob`, `write_file` only. No `shell`, delegation, web,
  approval, publishing, or engineering acceptance.
- **Measurements executed this iteration:** none. Every figure is a reading of a retained artifact
  under `.llm_tmp/overnight/` or of the working tree.
- **Genuine executed results available:** native `bazel build //...` (0); native test-target build
  (0, build-only); `bazel test //:unit_tests //:component_tests` (0, `socom_test` PASSED);
  cross `x86_64-linux`/`aarch64-linux` builds (0); focused GCC/Clang `-Werror` (0); focused
  GCC/UBSan red→green 33→0; focused ASan/LSan/UBSan, memcheck, coverage; `native_coverage` (0);
  sanitizer/TSan legs built (0).
- **Unavailable / not run / not passed:** clang-tidy analysis (config rejected; native leg
  timeout); `//:docs` (2); traceability gate (1); QEMU integration (1); benchmarks/profiling (124);
  `format.check` (124); `reuse lint` (1); focused TSan (66); QNX target (entitlement); Coverity
  (absent).
- **Scope:** local, unprotected, scoped. This is not acceptance, review, publication, or a full
  native run. `measurement.json` itself records `engineering_acceptance: pending` and
  `full_native_tests: not_executed`.
- **Reproduction path for a later, authorized iteration (not executed here):**

  ```bash
  bazel build //...
  bazel test //...                       # NOT --build_tests_only
  bazel test //score/socom/test/unit:socom_test
  bazel test --features=asan --features=lsan --features=ubsan_clang //score/... //tests/...
  bazel test --features=tsan //score/... //tests/...
  bazel coverage //... --build_tests_only
  bazel test --config=qemu-integration //quality/... //tests/integration_test/...
  bazel build --config=x86_64-linux //score/... //tests/...
  bazel build --config=aarch64-linux //score/... //tests/...
  ```

  Expected on the corrected key: the minor-only key/runtime regressions pass; on a key that
  includes `minor`, they fail. These expectations are source-derived, not measured here.

---

## 9. Obligation status (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Freedom from compiler warnings & errors (100 %, criterion 9) | `verification_plan.rst` | **NOT ESTABLISHED** — focused GCC/Clang clean with `-Werror`; default native build disables warnings-as-errors (`.bazelrc:117`) |
| Native build (`bazel build //...`) | `AGENTS.md`; `development_plan.rst` | **RAN, exit 0** (local, unprotected) — but not acceptance and not warnings-as-errors |
| Native test **execution** | `verification_plan.rst` (criteria 6–7) | **PARTIAL** — `bazel test //:unit_tests //:component_tests` executed and `socom_test` PASSED; `//...` was build-only; `full_native_tests: not_executed` |
| Native sanitizer / TSan checks | `code_analysis.rst` | **NOT EXECUTED at Bazel scope** — legs were `--build_tests_only`; focused ASan/LSan/UBSan pass is narrow; focused TSan exit 66 |
| Static code analysis run (clang-tidy / CodeQL) | `code_analysis.rst` | **NOT SATISFIED** — clang-tidy config rejected and native leg timed out; CodeQL focused/dependency-only |
| SCA findings classified Critical/High/Medium/Low | `verification_process.rst` (`gd_req__verification_sca_classification`) | **NOT DONE** — no authorized classification |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` *[draft]* | **UNKNOWN — NOT CLAIMED** |
| Statement / branch coverage goals | `verification_plan.rst` (criteria 1–2) | **NOT MET** — focused 100 % line / 78.6 % branch, `complete_target_scope: false` |
| Branch coverage goal | `verification_plan.rst` | **NOT MET** (78.6 % < 85 %/100 %) |
| Native integration / QEMU | `verification_process.rst` | **NOT PASSED** — exit 1 (KVM/QEMU present) |
| Native performance / profiling | `verification_plan.rst` | **NOT PASSED** — both legs timed out (124) |
| Cross-compilation (x86_64 / aarch64) | `development_plan.rst` | **RAN, exit 0** (both); QNX entitlement blocker remains |
| Documentation build | `verification_guideline.rst` | **NOT PASSED** — `//:docs` exit 2 |
| Traceability gate | `verification_process.rst` (`gd_req__verification_link_tests_cpp`) | **NOT PASSED** — exit 1; test records carry only `DerivationTechnique`/`Description`; `TestType`/`Verifies` unset |
| Format / pre-commit / reuse / module lock | `.pre-commit-config.yaml`; `REUSE.toml` | **PARTIAL** — pre-commit 0, module tidy/lockfile 0; `format.check` timed out (124); `reuse lint` 1 |
| Secret / dependency scan | `tool_management.rst` | **NOT SATISFIED** — gitleaks findings are out-of-scope artifacts; no vuln DB/receipt |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED for this slice** — qualification requires authorized humans; Coverity absent |
| Independence of verification / review | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Implementation inspection checklist | `inspection_checklist.rst` *[draft]* | **NOT FILLED** |
| Obligation collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **RETAINED, NOT PASSING** |
| Native acceptance | `source-index.json` | **`not_inferred` for every entry** |

**Explicit non-satisfaction statement.** The clang-tidy configuration blocker and native timeout,
the build-only sanitizer/TSan legs, the failed docs/traceability/integration/performance/reuse
checks, the below-goal branch coverage, the absent Coverity and QNX entitlement, the unknown safety
class, and the unanswered human reviews mean **none of the checked obligations may be treated as
satisfied**. A retained collection result shows *retention*, not passing; a build-only leg shows
*compilation*, not execution; a tool that produced no finding because it did not run is *not run*,
not *clean*.

---

## 10. Notice preservation

- No source, build, test, config, `NOTICE`, `LICENSE`, `REUSE.toml`, validation, or prior-report
  file was created, edited, or deleted by this iteration; **only this report was written.**
- The header the task flagged (`score/socom/impl/service_identifier.hpp`) retains its
  Apache-2.0/SPDX comment (`:1-12`) and was left unchanged because it is already balanced (§2).
  `service_identifier.cpp` (`:1-12`), both BUILD files (`score/socom/BUILD:1-12`,
  `score/socom/test/unit/BUILD:1-12`), and both candidate test files retain their
  Apache-2.0/SPDX headers.
- All files under `.llm_tmp/overnight/reports/` and `.llm_tmp/overnight/prior-reports/` were
  preserved unchanged; this document is a new `reports/` entry.
- This report itself carries the Apache-2.0 header. No licensed MISRA rule text is reproduced;
  only native rule/query identifiers and file locations are cited.

---

## 11. Pending human review checklist

- [ ] **Confirm §2:** `service_identifier.hpp` is brace-balanced (brace lines
      `:19,:29,:32,:38`; line 39 blank; net balance 0); the recorded "extra closing brace at
      line 39" is stale or refers to a different revision, and the focused GCC/Clang `-Werror`
      compiles and the Bazel `//...` build all exit 0. No source correction is required in this
      checkout. If a distinct "cancelled draft" revision still carries the brace, locate and
      correct it by an authorized iteration.
- [ ] **Resolve the instruction conflict:** "Inspect and correct the actual source" vs. "This is a
      review draft: only that report may be written"; confirm that writing only this report was
      intended and that the no-op on already-correct source is acceptable.
- [ ] **Confirm the reconciliation with `prior-reports/native_build_review.md`:** that earlier
      iteration recorded every native leg as exit 127 (missing `/tmp/s-core-001/bin/bazel`); the
      retained artifacts now show Bazel 8.6.0 with `native_build` exit 0. Treat the newer
      artifacts as the current reading and the older report as superseded evidence.
- [ ] **Confirm the build-only semantics** of `native_tests`, `native_sanitizers`, and
      `native_tsan` (`--build_tests_only`), and decide whether a true `bazel test //...` execution
      is required before any "tests pass" claim beyond the executed
      `//:unit_tests //:component_tests` (`socom_test PASSED`).
- [ ] **Restore/repair clang-tidy** (unfold the `.clang-tidy` configuration and prevent the native
      `//:clang-tidy.check` timeout) so a real static-analysis verdict exists; disposition the
      Coverity absence.
- [ ] **Enable a warnings-as-errors native build** (`.bazelrc:117` currently disables it) before
      claiming criterion-9 compliance, and record the result.
- [ ] **Reproduce/repair the failed legs:** `//:docs` (exit 2), traceability gate (exit 1), QEMU
      integration (exit 1), performance/profiling (timeouts), `format.check` (timeout),
      `reuse lint` (exit 1), focused TSan (exit 66).
- [ ] **Resolve the QNX entitlement gap** for `--config=aarch64-linux`/QNX target execution.
- [ ] **Disposition the gitleaks findings** (§6.4): they are in tool artifacts and the QNX init
      build file, not the candidate paths; record the disposition rather than treating the scan as
      clean or the paths as defective.
- [ ] **Complete the mandated SCA classification** and **activate the MISRA mapping**
      (`misra_mapping.rst` is a draft) or record applicability as unresolved.
- [ ] **Select the safety class**, record the branch-coverage decision (focused 78.6 % is below the
      safety goal), schedule independent human review (approver ≠ author per
      `gd_req__verification_independence`), and record engineering acceptance.
- [ ] **Keep the wider #84 public `Service_interface_identifier` restructure, FindService wildcard
      handling, and the config minor-wildcard narrowing out of this bounded slice** until
      separately accepted, and do not present the identifier-only tests as platform validation.

---

*End of review draft. Local, unprotected, scoped. No engineering acceptance; human reviews
unanswered; full native runtime tests pending. The native `//...` build and the executed
`//:unit_tests //:component_tests` (`socom_test` PASSED) are genuine local results but are not
acceptance and do not cover the build-only sanitizer/TSan legs, the failed docs/traceability/
integration/performance/format/reuse legs, or the missing clang-tidy/Coverity/QNX/
warnings-as-errors evidence. The focused GCC pass is not full Bazel readiness; no finding was
filtered and no authorized severity rating exists.*
