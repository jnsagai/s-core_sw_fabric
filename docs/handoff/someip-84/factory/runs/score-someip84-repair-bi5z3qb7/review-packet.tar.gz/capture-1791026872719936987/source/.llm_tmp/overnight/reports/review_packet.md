<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — final review packet (bounded duplicate-server registration-key slice)

**Document type:** review packet / review draft — changed paths, test outcomes, known limits, and
the unanswered engineering decisions. **Not** an engineering acceptance, **not** a review approval,
**not** a publication, and **not** a full native run.
**Date:** 2026-10-03
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version handling in
socom* (issue #84)
**Run / branch:** `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ`; HEAD `de4762c`
(`fabro(01M3ZRSDK2XQAF1H48VWTPKQNZ): node_b9e9bbdb0632ffde30be850b (success)`, `.git/logs/HEAD:92`)
**Verified baseline commit:** `f8a196c3b16d5172d898394ab99b0ed81346d63d`
(`.llm_tmp/context/source-manifest.json:3`)
**Status:** **local, unprotected, scoped.** No engineering acceptance exists. Human reviews are
unanswered. Full native runtime tests are pending. Nothing in this document is acceptance, review,
publication, or a full native run.

> **Tool / write boundary actually observed.** This iteration used only `read_file`, `grep`, `glob`,
> and `write_file`. No `shell`, no `edit_file`, no delegation, no web access, no approval, no
> publishing, and no engineering acceptance was performed. The task says *"Inspect and correct the
> actual source before expanding tests"* **and** *"The cancelled draft has a measured GCC syntax
> failure: an extra closing brace in `score/socom/impl/service_identifier.hpp` at line 39"*, but its
> explicit, more specific final sentence says *"This is a review draft: only that report may be
> written."* Following that explicit write boundary, **exactly one file was written — this report**
> (`/workspace/.llm_tmp/overnight/reports/review_packet.md`). **No source, build, test, config,
> `NOTICE`, `LICENSE`, or `REUSE.toml` file was created, edited, or deleted, and every prior report
> was preserved unchanged.**
>
> **The instruction conflict is moot on the facts.** Direct inspection of the *actual* checkout shows
> `score/socom/impl/service_identifier.hpp` is **brace-balanced** and line 39 is **empty** (§2).
> There is no unmatched closing brace to remove; deleting a brace that does not exist, or
> re-introducing the historical split form, would at best be a no-op and at worst a regression. The
> requested key correction and the "expanded tests" (the key matrix and the runtime suite) are
> likewise already present on disk (§3–§4), so no test was expanded. Independently, the write
> boundary forbade a source write.
>
> **Non-satisfaction rule applied throughout.** A successful obligation-collection node means the
> results were **retained**, not that the checks **passed**. Missing tools, unknown applicability,
> incomplete extraction, an inactive/draft rule mapping, and unanswered human reviews are **not**
> treated as satisfied. A tool that produced **no** finding because it **did not run** is recorded as
> *"not run"*, never as *"clean"*. No AI-authored report and no green focused run counts as human
> approval.

---

## 1. Binding, scope, and sources read

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` | `.llm_tmp/context/issue-snapshot.json:2-4` |
| Title | *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:3` |
| State | `open`, **0 comments**, no milestone / assignee / labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG`, created/updated `2026-04-14T13:23:24Z` | `.llm_tmp/context/issue-snapshot.json:8,19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**. It distinguishes *service-instance identifier* = `service id + major + minor + instance
id`; *service identifier* = `service id + major`; *FindService* = `service id + major +
optional<minor> + optional<instance>`; and proposes to "exclude the minor version and make it a
property of the service instance". There is **no comment and no acceptance record** in the snapshot,
so none of it is binding. Binding is **by baseline commit**, not by run HEAD.

### 1.2 In-scope candidate files (the only writable source paths of the broader task)

From `.llm_tmp/context/candidate-files.json:1-25`:

| File (repo-relative) | Baseline git blob | Baseline present | Context-snapshot sha256 |
|----------------------|-------------------|------------------|-------------------------|
| `score/socom/BUILD` | `3477ea0851fdcd82ec6ea9d71424013cbdf41962` | yes | `dee82616…` |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e22355242009fe20dada2a9a0d0c7a9c7` | yes | `d766902e…` |
| `score/socom/impl/service_identifier.hpp` | `c8bae7908da9f087c518934f7b9f8d86db9a20ec` | yes | `96b33a1f…` |
| `score/socom/test/unit/BUILD` | `3c03a7b14286051f97fa5022206564bd63645171` | yes | `9b3c5b34…` |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab726db8bf994c960045d6fd7fdf84d7395` | yes | `5e35e24d…` |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(none — `null`)* | **no** (manifest expects a **new** file) | `45d07399…` |

The `null` baseline blob for `service_identifier_tests.cpp` is the manifest's expectation of a **new**
unit-test file; it exists on disk only as part of the un-merged working tree (the task's
"cancelled draft"), never in the baseline. `glob **/service_identifier*` returns exactly three paths
(`impl/service_identifier.cpp`, `impl/service_identifier.hpp`, `test/unit/service_identifier_tests.cpp`),
so there is **no second, differently-braced copy** of the header in this checkout.

### 1.3 Pinned obligation sources and authority (all read)

All nine entries of `.llm_tmp/context/obligations/source-index.json` are present together with
`authority.json`. Every entry is pinned `"native_acceptance": "not_inferred"` — pinned, but its
applicability to this slice is **not inferred**.

| id | status note |
|----|-------------|
| `coding_guidelines` | `:status: valid`; MISRA C++:2023 with C++17; document carries `:safety: ASIL_B` |
| `code_analysis` | `:status: valid`; clang-tidy + GCC/Clang warnings + Coverity; ASan/LSan/TSan/UBSan/Memcheck; gcov/gcovr |
| `misra_mapping` | **`:status: draft`** — rule table not a valid obligation; **no rule applicability asserted** |
| `verification_plan` | `:status: valid`; quality criteria 1–9 (criterion 9 = freedom from compiler warnings & errors, 100 %) |
| `development_plan` | `:status: valid`; C++17, GCC host compiler, QCC target, Bazel |
| `tool_management` | `:status: valid`; tools identified → evaluated → qualified → released/rejected by a human |
| `verification_process` | `:status: valid`; `gd_req__verification_link_tests(_cpp)`, `_independence`, `_checks(_extended)`, `_external_aou`, `_sca_classification` |
| `verification_guideline` | `:status: valid`; traceability, independence, documented results |
| `inspection_checklist` | **`:status: draft`** — blank `IMPL_01_01`…`IMPL_03_02` template |

**Authority record** (`.llm_tmp/context/obligations/authority.json`):
`engineering_acceptance: pending`; `human_reviews: unanswered`; `safety_class: unknown`;
`codeql_scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload"`; instruction
*"Restart the failed queue for one complete pass through all obligations"*.

**Safety-class note (recorded, not resolved).** The pinned platform documents carry `:safety: ASIL_B`,
while `authority.json` records `safety_class: unknown` and no authorized selection exists. The document
attribute is **not** a selection of the slice's safety class and must not be inferred as one.

### 1.4 Prior reports read and preserved

- `.llm_tmp/overnight/prior-reports/` — **38 files present**, all preserved; `scope.md`,
  `invariants.md`, `callsites.md`, `reproducer.md`, `key_fix.md`, `independent_review_handoff.md`, and
  `review_packet.md` were read; the remainder were cross-checked.
- `.llm_tmp/overnight/reports/` — read, not modified: `scope.md`, `invariants.md`, `reproducer.md`,
  `key_fix.md` (the earlier nodes of this run) plus the broader set. This document adds
  `review_packet.md`.
- `.llm_tmp/overnight/validation/` and `.llm_tmp/overnight/obligations/*/result.json` — **present and
  read** this iteration (§4). They were **not** present in the earliest reports of this run; they now
  are present, and they are treated as **retained, scoped measurements**, not as passing obligations.

---

## 2. The recorded GCC syntax failure — inspection of the actual source

### 2.1 Finding (direct `read_file` + `grep` this iteration)

`score/socom/impl/service_identifier.hpp` is **brace-balanced**. It is 40 lines. `grep '[{}]'` returns
exactly four brace-bearing lines:

| Line | Content | Role |
|------|---------|------|
| 14 | `#ifndef SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard begin |
| 17 | `#include "score/socom/service_interface_identifier.hpp"` | include |
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 21–28 | doc comment | states `minor` is intentionally not part of the identity |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 30–31 | `Service_interface_identifier interface;` / `Service_instance instance;` | members |
| 32 | `};` | closes the struct |
| 34–36 | `/// \cond` / `bool operator<(…)` / `/// \endcond` | the single operator declaration |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`) and two closers (`:32`, `:38`): net brace balance is `0`. There is **no
third, unmatched closing brace**, and line 39 contains no text at all. The sibling
`impl/service_identifier.cpp` uses the same nested form and is balanced (`:18`, `:20`, `:30`, `:32`).

### 2.2 The retained host evidence does not reproduce a syntax failure

The task's "measured GCC syntax failure" is **not reproduced** by the retained host validation now
present in this checkout:

- `.llm_tmp/overnight/validation/before-compile.command.json` and `after-compile.command.json`:
  focused `g++-12 -std=c++17 -Wall -Wextra -Werror` (UBsan build) over `service_identifier.cpp` +
  `string_registry.cpp` + `service_identifier_tests.cpp` + vendored googletest, **`exit_code: 0`** for
  both. `service_identifier.cpp` includes the flagged header, so a surviving extra closing brace would
  have failed this `-Werror` compile. `after-compile.stderr` is empty.
- `.llm_tmp/overnight/validation/measurement.json` (tail, `:2045-2058`): `baseline_with_agent_tests`
  and `candidate` both record `"compile_exit": 0`.

The described defect therefore matches a **stale, pre-correction description** — the earliest prior
reports quote lines 38–39 as the split-form `}  // namespace socom` + `}  // namespace score`; the
`reproducer` iteration corrected it and left line 39 blank, which is what the actual source shows
today. It is recorded as false-positive item **FP-1** in the independent-review handoff.

### 2.3 Disposition and minimal historical repair (reference only; NOT applied)

**No correction was applied, and none is required.** If the "cancelled draft" is a *different*
revision that still carries the extra brace, it is **not** the file in this checkout and must be
located and corrected by an authorized iteration. Should the imbalance ever reappear, the minimal
correction — matching the sibling `.cpp` and the nested form — is:

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

Applying it to the already-balanced file would be a no-op; deleting a brace to "fix" the file would
*create* the reported defect.

### 2.4 Why it would matter if present

The header is compiled into `//score/socom:socom` (`score/socom/BUILD:24-41`; its `srcs` globs
`impl/**/*.cpp`, `impl/**/*.hpp`) and re-exposed to `//score/socom/test/unit` only through the
`testonly` library `impl_service_identifier` (`score/socom/BUILD:46-54`; consumed at
`score/socom/test/unit/BUILD:24`). A syntax error would fail the library and the whole `socom_test`
target, contradicting quality criterion 9 (`verification_plan.rst`). It is **not** a blocker in the
current tree. The focused compiles **corroborate** this, but they are scoped/unprotected — **not** a
full native criterion-9 measurement.

---

## 3. Changed paths

### 3.1 This iteration

**Wrote exactly one file — this report.** No candidate source path was changed. Reason: the recorded
syntax defect is absent (§2), the draft's key correction and tests are already present (§3.2, §4), and
the explicit write boundary ("only that report may be written") forbade a source write.

### 3.2 State of the six candidate paths (direct readings + retained hashes)

The "tool-measured sha256" values below are quoted from the retained
`.llm_tmp/overnight/obligations/rework_progress/result.json` `source_hashes` (and match the other
collector results). The context-snapshot values are from `.llm_tmp/context/candidate-files.json`. No
hashing tool is available in this task, so neither was recomputed here.

| Candidate path | Baseline blob | Tool-measured sha256 | Current state (read this iteration) |
|----------------|---------------|----------------------|--------------------------------------|
| `score/socom/impl/service_identifier.hpp` | `c8bae790…` | `bdce3fcbc3cd78a8ecaece1ea36107d464011ab81c9bc39932d0be617befaea9` | brace-balanced, 40 lines, nested namespace; line 39 empty; documents minor exclusion (`:21-28`) |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e…` | `3c12b3f1dd3f1fa66cdf43766f374d7d067637bf8f11aba604c4e2688351f11a` | `operator<` orders by `(instance, service id, major)`, `minor` excluded (`:28-29`); rationale comment (`:21-27`) |
| `score/socom/BUILD` | `3477ea08…` | `68f4645a21e495fac43929fb125f7ba0b9e29fc84c0401fdb95238ffb7fd2cc8` | `headers` glob `*.hpp` (`:17-22`); `socom` lib (`:24-41`); `testonly` `impl_service_identifier` exposure (`:46-54`) |
| `score/socom/test/unit/BUILD` | `3c03a7b1…` | `e909151e822370bebe8d59b86369bddeb4d6cacfa02f10061bf6e134671ff9d4` | `socom_test` globs `*.cpp`; deps wired (`:16-29`) |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab7…` | `9a2d6a154683a2b7ff9d51b7241e4fb74c1a8ef483895830cb409a8f5a1d3127` | **33 macros** (1 `TEST` + 31 `TEST_F` + 1 `TEST_P`); minor-only duplicate regression `:402-431`; metadata helper `:264-267` |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(none — new)* | `de79767c4653feca7b5b2fcf93f5a791bcc64ae4b554dc2ef35a8756536391e6` | **91 `TEST_F`** under `ServiceInstanceIdentifierTest` (`:168`…`:2181`); `SetUp()` metadata `:42-65` |

**Hash drift (recorded, not resolved).** For every candidate path the tool-measured sha256 differs
from the context-snapshot sha256 in `candidate-files.json` (e.g. header `bdce3fcb…` vs `96b33a1f…`;
test file `de79767c…` vs `45d07399…`). The snapshot's prose therefore cannot be assumed to describe
the current file, and the drift is left for human disposition. The host `measurement.json` records
`changed_paths = ["score/socom/test/unit/service_identifier_tests.cpp"]` for its
`check_conversion_tests` run — i.e. that run measured only the new key test file.

**Accumulated draft changes (per the preserved reports).** Across the earlier iterations the draft
added: the `testonly` `impl_service_identifier` exposure and test deps (both BUILD files); the
minor-excluding `operator<` and its documentation (the two `impl/service_identifier.*` files); the
runtime regressions; and the new 91-case key suite. The public
`Service_interface_identifier{Id id; Version{major, minor}}` type is **unchanged**.

### 3.3 Key facts (source-derived)

- **Key identity is `(instance, service id, major)`; `minor` is excluded.**
  `impl/service_identifier.cpp:28-29`. `std::set` uniqueness is `!(a<b) && !(b<a)`.
- **Record index ignores `minor`.** `Service_database` groups by `id + major` via
  `Minor_version_ignoring_key_equal` / `Minor_version_ignoring_hash` (`impl/runtime_impl.hpp:116-134`).
  On the pre-draft key (which included `minor`) two connectors sharing `id + major + instance` but
  differing only in `minor` both passed the duplicate gate yet resolved to the same `Service_record`,
  reaching the single-server precondition. The working-tree key is now as coarse as the record index.
- **Insertion / duplicate rejection.** `Runtime_impl::make_server_connector` builds the identifier
  (`impl/runtime_impl.cpp:443`), inserts under the key mutex (`:449-454`), and returns
  `Construction_error::duplicate_service` when `insert(...).second` is false (`:452`).
- **Single-server precondition.** `Service_record::register_server_connector` asserts
  `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)` then `m_server.emplace(...)`
  (`impl/runtime_impl.cpp:369`, `:371`). The assert's terminate-vs-compiled-out semantics live in the
  external `score_baselibs`/`futurecpp` and are **undetermined in this checkout**.
- **Compatibility is separate from identity.** `is_minor_version_compatible` = `client.minor <=
  server.minor`; `is_interface_compatible` requires equal `id`, equal `major`, then the minor rule
  (`impl/runtime_impl.cpp:133-146`). Not part of the key.
- **Key is internal.** `using Service_identifiers = Mutexed_variable<std::set<Service_instance_identifier>>`
  (`impl/runtime_impl.hpp:56`); the type is not in the public `headers` filegroup and is exposed to the
  test package only via a `testonly` library.

---

## 4. Test outcomes

> **Scope caveat carried through this section.** Every retained code measurement compiles only the
> focused identifier translation unit (`service_identifier.cpp` + `string_registry.cpp` +
> `service_identifier_tests.cpp` + vendored googletest). **`runtime_tests.cpp` is not compiled or
> executed by any retained artifact.** No Bazel/native target (`//score/socom/test/unit:socom_test`,
> `//score/...`) was built or run. `full_native_tests: not_executed`.

### 4.1 Host validation (`.llm_tmp/overnight/validation/`, present and read)

| Artifact | Result | Limit |
|----------|--------|-------|
| `measurement.json` (`check_ref: check_conversion_tests`, `mode: ubsan`) | `baseline_with_agent_tests` **91 tests / 33 failures / compile_exit 0 / test_exit 1**; `candidate` **91 tests / 0 failures / compile_exit 0 / test_exit 0**; `origin: local_unprotected_measurement`; `initiator: Fabro host hook`; `engineering_acceptance: pending`; `full_native_tests: not_executed`; compiler `/usr/bin/x86_64-linux-gnu-g++-12` (`88315fd2…`) | focused identifier TU; **never** Bazel/native; no `runtime_tests.cpp` |
| `before.json` / `after.json` | 91 tests, **33** failures → 91 tests, **0** failures (all in `ServiceInstanceIdentifierTest`) | same scope |
| `before-compile.command.json` / `after-compile.command.json` | focused `g++-12 -std=c++17 -Wall -Wextra -Werror` (UBsan) **exit 0** for both | focused TU only |
| `after-compile.stderr` | **empty** | focused TU only |
| `check-result` | `0` | collector success marker only |

The retained measurement executed **91** cases, matching the **91 `TEST_F`** present on disk
(`service_identifier_tests.cpp:168`…`:2181`, counted this iteration by `grep`) — so, unlike the
earlier 85/87 mismatch recorded by prior reports, this identifier measurement is **no longer stale by
case count**. It remains scoped to the identifier TU and does not execute the runtime suite.

### 4.2 Obligation-collection results (25 retained; retention ≠ passing)

`glob .llm_tmp/overnight/obligations/*/result.json` returns **25** files. Representative retained
statuses (read from the artifacts and the preserved reports):

| Check | Retained status | Reading |
|-------|-----------------|---------|
| `compiler_diagnostics` | `findings_or_execution_failure`; GCC compile+tests exit 0; **Clang exit 1** on `-Wdeprecated-declarations` reached through vendored gtest/libstdc++ | Clang branch of criterion 9 blocked by a dependency, outside the candidate paths |
| `focused_coverage` | `completed`; line **36/36 = 100 %**, branch **11/14 = 78.6 %**; `complete_target_scope: false`; `safety_class: unknown_requires_authorized_selection` | **branch below both platform goals** (QM 85 % / safety 100 %) |
| `focused_asan_lsan` | `completed`; ASan/LSan/UBSan exit 0 | focused single-threaded identifier scope only |
| `focused_tsan` | `findings_or_execution_failure`; tests exit `-11` (SIGSEGV) | environment failure, **not** a clean race result |
| `focused_memcheck` | `findings_or_execution_failure`; exit 127 | `valgrind` unavailable |
| `focused_cppcheck` | `findings_or_execution_failure`; exit 2; `passedByValue` findings | locations in headers **outside** the candidate paths |
| `focused_clang_tidy` | `findings_or_execution_failure`; `--verify-config` exit 1 (unknown checks) | **no analysis ran → "not run", never "clean"** |
| `codeql_security` / `codeql_misra` | `findings_or_execution_failure`; findings dominated by `.llm_tmp/googletest/**`; `level: null` | focused linked executable, dependency-only; MISRA mapping `:status: draft` → **no MISRA compliance claim possible** |
| `native_build`, `native_tests`, `native_coverage`, `native_lint`, `native_sanitizers`, `native_tsan`, `native_integration`, `native_docs`, `native_performance`, `native_traceability`, `cross_compilation`, `format_precommit` | `findings_or_execution_failure`; **exit 127** (`[Errno 2] … '/tmp/s-core-001/bin/bazel'`; some tools absent) | **no native build/test/coverage/QEMU/cross/trace/format run** |
| `secret_dependency_checks` | `findings_or_execution_failure`; gitleaks exit 127; dependency inventory retained; blocker "dependency inventory is not a vulnerability scan" | secret scan **not run**; no CVE mapping |
| `tool_assurance` | retained; `bazel`, `valgrind`, `gitleaks`, `clang-format`, `pre-commit`, `reuse` unavailable | tool execution ≠ qualification |
| `process_checks` | `completed_with_blockers`; blockers include lexical inventory cannot prove semantic requirement coverage; safety/QM applicability and approved tailoring unknown; independent inspection/acceptance required; external AoU and full integration verification require scoped review | directly names the human gate |
| `rework_progress` | `completed`; `source_changed_this_round: false`; `rework_requested: false`; stop reason *"One complete pass requested; unresolved findings stay pending"* | one pass; nothing resolved |

**Explicit non-satisfaction statement.** A successful collection node means results were **retained**,
not that checks passed. Here the retained results show explicit non-runs and failures (13 checks at
`findings_or_execution_failure`, branch coverage below goal, clang-tidy/valgrind/gitleaks/bazel
unavailable). **No obligation is satisfied**, and the absence of a native result is not evidence that
the native checks passed.

### 4.3 Test inventory (read, not run in this iteration)

- `score/socom/test/unit/service_identifier_tests.cpp`: **91 `TEST_F`** under
  `ServiceInstanceIdentifierTest` (`:168`…`:2181`), including the minor-collapse cases
  (`KeysDifferingOnlyInMinorVersionAreDuplicates` `:174`, `MinorVersionBoundariesAreDuplicates` `:182`,
  `AllMinorVersionsCollapseToSingleKey` `:192`, `MinorHighBitVariantsAreEquivalent` `:203`,
  `MinorVersionNeverAffectsOrdering` `:430`, `SetFindLocatesMinorVariantAndCountsItOnce` `:1034`,
  `StdSetCollapsesFiveMinorVariantsOfEveryIdentity` `:1321`) plus strict-weak-ordering and
  equivalence property checks over deterministic domains. `SetUp()` records only
  `DerivationTechnique = "boundary-values,equivalence-classes"` and a `Description` (`:42-65`).
- `score/socom/test/unit/runtime_tests.cpp`: **33 macros** — 1 `TEST` (`:239`), 31 `TEST_F`
  (`:279`…`:1253`), 1 `TEST_P` (`:1311`). The focused minor-only regression
  `ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError` (`:402-431`) drives the
  real `Runtime::make_server_connector()` path and expects
  `Construction_error::duplicate_service` for a second registration differing only in `minor`; both
  connectors stay disabled, so the duplicate is rejected at construction.
- The key suite was executed green only in the focused host/collector runs (91/0, UBsan exit 0).
  `runtime_tests.cpp` has **never** been compiled or executed by any retained artifact. **Nothing was
  executed in this iteration.**

---

## 5. Known limits

1. **No native build/test has run.** `bazel` is unavailable, so the `native_*`, `cross_compilation`,
   QEMU integration, docs, traceability, performance and format/pre-commit legs exited 127. No Bazel
   target was built or tested in this checkout.
2. **`runtime_tests.cpp` is unexecuted.** The runtime-level minor-only regression and the
   slot-isolation/lifetime cases are source-only in this checkout.
3. **The retained identifier measurement is scoped:** focused translation unit only (+ UBsan); it is
   current by case count (91 = 91) but is **not** a platform, interface, or full-target test and does
   not cover `runtime_tests.cpp`.
4. **Branch coverage is below goal:** 11/14 = 78.6 % vs QM 85 % / safety 100 %; no deviation
   accepted; `safety_class` unknown, so no goal level is selectable yet.
5. **Clang leg blocked** by a dependency deprecation; **clang-tidy did not run** (config rejected);
   **cppcheck findings are out of scope**; **CodeQL is focused/dependency-only**; **TSan produced no
   usable result** (SIGSEGV); **memcheck, gitleaks, clang-format, pre-commit, reuse are unavailable**.
   None may be reported as clean.
6. **MISRA C++:2023 compliance is unknown/not claimed** — `misra_mapping.rst` is `:status: draft`; no
   numbered rule is asserted to apply.
7. **Traceability is incomplete** — no `comp_req__socom__*` and no `:reqtype: Interface` need exists;
   `TestType` and the `PartiallyVerifies`/`FullyVerifies` links are deliberately unset because
   inventing identifiers is prohibited.
8. **Tool qualification is not established** (missing tools; collector-vs-pin version drift; no Tool
   Verification Report).
9. **No safety classification, SCA finding classification, risk acceptance, deviation, or FMEA/DFA
   disposition exists.** The draft deviation register (DD-1…DD-9, FP-1) is **not accepted**.
10. **All human reviews are unanswered**; the author/reviewer/approver roles are unfilled.
11. **Hash drift** between the context snapshot (`candidate-files.json`) and the tool-measured working
    tree is recorded but not resolved (§3.2).

---

## 6. Unanswered engineering decisions

These are decisions only a named authorized human may make; they are recorded, not answered.

### 6.1 Bounded-slice semantics

1. **Minor in the duplicate key, or not?** The draft excludes `minor` (consistent with
   `Service_database` and #84), so two servers sharing `id + major + instance` collide as
   `duplicate_service`. If the key must keep `minor`, the `Service_database` index must stop ignoring
   minor (or registration must tolerate replacement) to remove the assert/UB path. Which is
   authoritative?
2. **Two servers, one `id + major + instance`, different minor.** Reject as duplicate, let the later
   replace the earlier, or allow both with negotiation? The code cannot express the last option
   (`m_server` is a single `std::optional`).
3. **Status of `ASSERT(!m_server)`.** Genuine invariant (so the duplicate gate must cover every
   collision the record index can produce) or defensive check that should tolerate re-registration?
4. **Scope of the #84 restructure.** Introduce `Service_identifier = id + major` plus
   minor-as-instance-property (public API change), or keep `Service_interface_identifier{major,
   minor}` and only fix the internal key? This packet assumes the latter.
5. **Version widths and wildcard.** socom uses `uint16` major/minor; the SOME/IP config declares
   `service_version_major: uint8` and `service_version_minor: uint32 = 0xFFFFFFFF`, narrowed by
   unchecked `static_cast<uint16_t>` at several sites. Under the coarsened key, a wildcard-derived
   `0xFFFF` server and a concrete-minor server now collide. How is the wildcard mapped?
6. **Ordering vs identity.** `operator<` is used only for `std::set` membership; the key declares no
   `operator==`/hash. Is a total order meaningful, or should the internal key be an equality/hash key?
7. **Error semantics.** Should a minor-only collision report `duplicate_service`, or a more specific
   error? The `error.hpp` comment ("Service identifier already exists") is narrower than the key.
8. **Documentation/contract.** `Runtime::make_server_connector`'s doc speaks of duplicates judged by
   "the configuration.interface and instance parameters", but public `operator==` includes `minor`
   while the key does not. Authorize a documentation correction?
9. **Design-doc traceability.** No design element in `score/socom/docs/design/` records the key, its
   minor-excluding identity, or duplicate rejection; the behaviour is documented only in code
   comments. Is intentionally-undocumented acceptable?
10. **Runtime regression acceptance.** Confirm the minor-only duplicate regression and the
    slot-isolation/lifetime cases are wanted, and that the public `Runtime::make_server_connector()`
    path is acceptable — noting none has been compiled or run natively in this checkout.

### 6.2 Process and role gates

- **Author/approver separation** (`gd_req__verification_independence`): approver must differ from
  author; all roles are **unfilled**.
- **Safety classification / ASIL-QM selection** (safety manager + project lead): **unanswered**.
- **Security assessment acceptance** (security manager): **unanswered**.
- **SCA finding classification Critical/High/Medium/Low** (quality manager + committer): **unanswered**.
- **Implementation inspection IMPL_01_01…IMPL_03_02** (content responsible + reviewer + moderator):
  **unfilled** (checklist is a blank draft).
- **Tool impact / error-detection / TCL + qualification** and **Tool Verification Report
  released/rejected**: **unanswered / pending**.
- **Deviation / false-positive register** (DD-1…DD-9, FP-1, including the stale "extra `}` at
  `service_identifier.hpp:39`" item): **draft / not accepted**.
- **Requirement/interface links and `TestType`** (requirements owner + reviewer + committer):
  **unanswered**; no `comp_req__socom__*` or interface need exists.
- **Integration/release decision** against quality criteria 1–9 (project lead + quality manager):
  **not taken** (branch shortfall and unexecuted runtime suite noted).
- **Instruction conflict** ("inspect and correct the actual source" vs. "only that report may be
  written"): **unanswered**; this packet resolved it by reporting only, on the facts that the source
  is already correct and the write boundary forbids a source write.

---

## 7. Notice preservation

- **Only this report was written.** No source, build, test, config, `NOTICE`, `LICENSE`, or
  `REUSE.toml` file was created, edited, or deleted.
- The flagged header `score/socom/impl/service_identifier.hpp` was inspected and left unchanged
  because it is already brace-balanced and otherwise well-formed (§2); it retains its Apache-2.0 /
  SPDX header (`:1-12`). The sibling `service_identifier.cpp`, both `BUILD` files, and both candidate
  test files likewise retain their Apache-2.0 / SPDX headers.
- All prior reports under `.llm_tmp/overnight/prior-reports/`, all earlier files under
  `.llm_tmp/overnight/reports/`, and all host/obligation artifacts under
  `.llm_tmp/overnight/validation/` and `.llm_tmp/overnight/obligations/` were read only and are
  preserved unchanged.
- This report itself carries the Apache-2.0 header. No licensed MISRA rule text is reproduced; only
  native rule/query identifiers, source hashes, and file locations are cited.

---

## 8. Pending human review checklist

- [ ] **Confirm §2:** `service_identifier.hpp` is brace-balanced (braces at `:19`, `:29`, `:32`,
      `:38`; line 39 empty; net balance 0). The recorded "extra closing brace at line 39" is stale or
      refers to a different revision (FP-1); confirm no source correction is required in this
      checkout.
- [ ] **Resolve the instruction conflict** (correct-source vs. report-only) and confirm that
      inspection-only was the intended outcome given the source is already correct.
- [ ] **Confirm the bounded key decision:** `minor` is **not** part of the duplicate-server
      registration key (identity `(instance, service id, major)`); the public interface and the
      exact-major / minimum-minor rules are unchanged.
- [ ] **Confirm `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)`** is the authoritative single-server
      invariant, so the key must be at least as coarse as the record index.
- [ ] **Confirm the test coverage** (91 key `TEST_F`; 33 runtime macros) and that identifier/key
      tests are **not** platform validation and no fuzzy technique is claimed.
- [ ] **Dispose of the hash drift** between `candidate-files.json` and the tool-measured working tree
      (§3.2), and refresh the focused identifier measurement if the candidate file changes again.
- [ ] **Supply native requirement/interface identifiers** (no invented links) or record approved
      tailoring; complete `TestType`/`Verifies` per `gd_req__verification_link_tests_cpp`.
- [ ] **Restore tools and run the full native suite** (`bazel build //score/...`,
      `bazel test //score/...`, `bazel test //score/socom/test/unit:socom_test`), including
      `runtime_tests.cpp`.
- [ ] **Run the focused key and runtime regressions**:
      `--test_filter='ServiceInstanceIdentifierTest.*'` and
      `--test_filter='RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError'`.
- [ ] **Complete the MISRA mapping / inspection checklist / SCA classification / tool qualification**
      and the deviation register as authorized humans.
- [ ] **Select a safety class, assign the independent reviewer/approver (≠ author), record
      engineering acceptance, and take the release decision.** Do not upload (codeql_scope: no
      upload).

---

## 9. What this packet explicitly does NOT claim

- No engineering acceptance, review approval, publication, or upload.
- No MISRA C++:2023 compliance and no assertion that any numbered rule applies (mapping is draft).
- No safety-class / ASIL / QM selection, no FMEA/DFA acceptance, no risk acceptance, no deviation.
- No claim that identifier-only / key-level tests are platform, feature, or interface validation,
  and no fuzzy-testing claim.
- No invented native requirement or interface identifiers.
- No claim that clang-tidy, the native Bazel suite, TSan, memcheck, clang-format, pre-commit, reuse,
  gitleaks, QEMU integration, cross-compilation, coverage-to-goal, or the docs/traceability gate
  passed — each is blocked, failed, or did not run.
- No statement that the wider #84 public `Service_interface_identifier` restructure, FindService
  wildcard handling, or config minor-wildcard narrowing is in scope.

---

*End of review packet. Local, unprotected, scoped. No engineering acceptance; human reviews
unanswered; full native runtime tests pending; no MISRA compliance, safety classification, tool
qualification, deviation, or risk acceptance is claimed, and this packet does not act as the
independent reviewer.*
