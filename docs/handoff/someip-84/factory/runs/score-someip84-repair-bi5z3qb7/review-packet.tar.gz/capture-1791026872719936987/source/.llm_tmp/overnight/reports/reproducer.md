<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — reproducer: actual-source inspection and focused minor-only duplicate-key regression

**Document type:** review draft (actual-source inspection + focused failing-regression record)
**Date:** 2026-10-03
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version handling in socom*
**Run / branch:** `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ`; current HEAD `a31f5fc`
(`fabro(01M3ZRSDK2XQAF1H48VWTPKQNZ): node_edd8fcbae2fee64d3bbd0c31 (success)`). Earlier stages of this
run are `b7d55bb` (start), `95fe5f9` (`node_51f7ccb6b2715b106cf242f4`), and `8e1610e`
(`node_3752dc1af9e2f3b0ee1454f2`) — see `.git/logs/HEAD:1-4` and the run environment.
**Verified baseline commit:** `f8a196c3b16d5172d898394ab99b0ed81346d63d`
(`.llm_tmp/context/source-manifest.json:3`).
**Status:** local, unprotected, scoped. **No engineering acceptance exists. Human reviews are
unanswered. Full native runtime tests remain pending.** Every line quoted below is a direct static
reading of this snapshot at the baseline-bound candidate paths, or an explicitly-labelled logical
consequence. Nothing here is published, reviewed, accepted, or a full native run.

> **Tool / write boundary observed.** Only `read_file`, `grep`, `glob`, and `write_file` were used.
> No `shell`, no delegation, no web access, no approval, no publishing, and no engineering acceptance
> was performed. The task permits changing only the six named candidate source paths and this report.
> Of those, **this iteration wrote exactly one file — this report**
> (`/workspace/.llm_tmp/overnight/reports/reproducer.md`). No source, build, test, config, `NOTICE`,
> `LICENSE`, or `REUSE.toml` file was created, edited, or deleted, and every prior report was
> preserved.
>
> **Why no source edit was made, although source writes were permitted.** The task records "a
> measured GCC syntax failure: an extra closing brace in `score/socom/impl/service_identifier.hpp` at
> line 39" and directs: "Inspect and correct the actual source before expanding tests." Direct
> inspection of the *actual* snapshot shows the header is **already brace-balanced** and line 39 is
> **blank** (§2). A `grep` for a brace character on the file returns exactly four matches — `:19`,
> `:29` (openers), `:32`, `:38` (closers) — i.e. net balance `0`. The smallest correction to
> already-correct source is **no change**; deleting or adding a brace would be a no-op at best and a
> regression at worst. The described defect is a stale, pre-correction description already recorded
> by the earlier `reproducer` iteration (`prior-reports/reproducer.md`) and by this run's `scope.md`,
> `invariants.md`, and `callsites.md`.
>
> Likewise, the requested **focused failing regression for duplicate registration keys differing only
> in minor version is already present** at both the key level and the runtime level (§3). It was
> verified and retained rather than duplicated; duplicating it would add complexity without adding
> coverage. The "expanded tests" the task refers to (the key matrix and the runtime suite) are
> likewise already present.

---

## 0. Summary

1. **Recorded syntax failure — inspected; not present.** `score/socom/impl/service_identifier.hpp`
   has exactly two opening braces (`namespace score::socom {` at `:19`, `struct
   Service_instance_identifier final {` at `:29`) and two closing braces (`};` at `:32`, the single
   `}  // namespace score::socom` at `:38`). Net brace balance is `0`; `:39` is empty and `:40` is
   `#endif`. There is **no third, unmatched closing brace**, so the described repair is not
   applicable to this snapshot (§2).
2. **Focused failing regression for minor-only duplicate keys — present and verified.** Two layers
   pin the behaviour:
   - key level: `ServiceInstanceIdentifierTest.KeysDifferingOnlyInMinorVersionAreDuplicates`
     (`score/socom/test/unit/service_identifier_tests.cpp:174-180`), plus its boundary/equivalence
     variants;
   - runtime level: `RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError`
     (`score/socom/test/unit/runtime_tests.cpp:402-431`), which drives the real
     `Runtime::make_server_connector()` registration path and expects
     `Construction_error::duplicate_service` for a second registration differing only in `minor`.
   Both describe the corrected behaviour and therefore **fail** against the pre-correction key
   (where `minor` was part of the identity) and **pass** against the corrected key (`minor`
   excluded). The red/green derivation is source-based (§3.3); it was **not executed** here (§5).
3. **Key semantics in this snapshot.** `Service_instance_identifier::operator<` orders by
   `(instance, service id, major)`, so `minor` is excluded
   (`score/socom/impl/service_identifier.cpp:28-29`), matching the minor-ignoring `Service_database`
   index (`score/socom/impl/runtime_impl.hpp:116-134`).
4. **No obligation is satisfied (§4).** No tool ran beyond reading; no build, no test. The pinned
   obligation entries are `native_acceptance: not_inferred`; authority is
   `engineering_acceptance: pending`, `human_reviews: unanswered`, `safety_class: unknown`. The
   `.llm_tmp/overnight/validation/` and `.llm_tmp/overnight/obligations/` directories are **absent
   from this snapshot** (no `*/result.json`). Missing tools, unknown applicability, incomplete
   extraction, and unanswered human reviews are **not** treated as satisfied.

---

## 1. Binding to the verified baseline, prior reports, host feedback, obligations

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` | `.llm_tmp/context/issue-snapshot.json:2-4` |
| Title | *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:3` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` (unchanged) | `.llm_tmp/context/issue-snapshot.json:19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**: service-instance identifier = `service id + major + minor + instance id`; service
identifier = `service id + major`; FindService = `service id + major + optional<minor> +
optional<instance>`; and the proposal to "exclude the minor version and make it a property of the
service instance". The FindService `major = FF` AUTOSAR case is called theoretically possible but
not useful. There is **no comment and no acceptance record** in the snapshot.

### 1.2 Verified baseline

| Item | Value | Source |
|------|-------|--------|
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |
| Current branch | `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ` | environment |
| Current HEAD | `a31f5fc` — `node_edd8fcbae2fee64d3bbd0c31 (success)` | `.git/logs/HEAD:4` |

Binding is **by baseline commit**, not by run HEAD. Earlier reports reference other run IDs on the
same baseline commit (`01M3YRJEGXNY6CB81T7TKW774B`, `01M3YGTGYFEN406VDEVVTJTRWV`,
`01M3XZAQ65TTE35XSGXC4JAMAH`, `01M3XT7NQ04S4MTFRMTT2401XK`, `01M3WX09X84XFM5X08QY2944DF`, and
before them `01M3WSTF1DAJA248NQ5QQGQG52` / `a282596` and `01M3WWRQWT262FTYS52X80YPTP` / `e12e7cb`),
so all of them describe the same baseline.

### 1.3 In-scope candidate files (the only writable source paths)

From `.llm_tmp/context/candidate-files.json:1-25` (baseline blobs cross-checked against the `files`
array of `.llm_tmp/context/source-manifest.json`):

| File (repo-relative) | Baseline git blob | Baseline present | Recorded sha256 |
|----------------------|-------------------|------------------|-----------------|
| `score/socom/BUILD` | `3477ea0851fdcd82ec6ea9d71424013cbdf41962` | yes | `dee826163ac5e6336d51a293136b424696c2884aa1b2592395e1e06423c0ba44` |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e22355242009fe20dada2a9a0d0c7a9c7` | yes | `d766902e4bda5306095a6e5326ea91d28df3a6e1ef4e77dc9ba47556ed559a9a` |
| `score/socom/impl/service_identifier.hpp` | `c8bae7908da9f087c518934f7b9f8d86db9a20ec` | yes | `96b33a1fee4d54577ae9bc46c313409a0d59336f76df85ef1925ffebdd1a2119` |
| `score/socom/test/unit/BUILD` | `3c03a7b14286051f97fa5022206564bd63645171` | yes | `9b3c5b341211e2c387858fd1fe5c669a6a422b6e8b5e80fce35ba22c61186799` |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab726db8bf994c960045d6fd7fdf84d7395` | yes | `5e35e24d0abcfa361b5a5283a005b307b86026a970464a3423be7c6eed66631e` |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(none — `null`)* | no (manifest expects a new file) | `45d073998108df76c8f4534508d65f02cead28aa568cd5c45b5a3d8a4fd36a25` |

The `null` baseline blob for `service_identifier_tests.cpp` is the manifest's expectation of a **new**
unit-test file; it exists on disk only as part of the un-merged working tree (the "cancelled draft"),
never in the baseline. `glob` over `**/service_identifier*.hpp` returns **exactly one** path
(`score/socom/impl/service_identifier.hpp`) and `glob` over `**/*.{orig,rej,bak,patch,diff}` returns
only the unrelated `third_party/*.patch` files, so there is no second, differently-braced copy of the
header or a leftover patch/reject file in this snapshot. *(Note: the recorded `sha256` values are from
the manifest; no local hash tool was available to independently recompute them, so they are quoted,
not re-measured.)*

### 1.4 Prior reports read and preserved

- `.llm_tmp/overnight/prior-reports/` — **38 files present**, all preserved; `reproducer.md`,
  `key_fix.md`, `invariants.md`, `unit_matrix.md`, `scope.md`, and `callsites.md` were read in full
  and the rest cross-checked:
  `analyzer_plan.md`, `api_review.md`, `bazel_plan.md`, `callsites.md`, `compatibility.md`,
  `concurrency_review.md`, `conversion_tests.md`, `coverage_review.md`, `coverage_tests_repair.md`,
  `cross_target_review.md`, `design_inspection_draft.md`, `deviation_drafts.md`,
  `evidence_inventory.md`, `finding_classification.md`, `independent_review_handoff.md`,
  `integration_aou_review.md`, `invariants.md`, `key_fix.md`, `lifetime_review.md`,
  `lifetime_tests.md`, `misra_applicability.md`, `misra_manual_review.md`, `native_build_review.md`,
  `ordering_tests.md`, `performance_review.md`, `reproducer.md`, `review_packet.md`,
  `runtime_disabled.md`, `runtime_enabled.md`, `sanitizer_review.md`, `scope.md`, `security_review.md`,
  `test_metadata.md`, `tool_assurance_review.md`, `tool_findings_repair.md`, `traceability_review.md`,
  `unit_matrix.md`, `verification_report_draft.md`.
- `.llm_tmp/overnight/reports/` — read, not modified: `scope.md`, `invariants.md`, `callsites.md`
  (the three earlier nodes of this run). This document adds `reproducer.md`.

Derived sequence across the preserved reports: `scope.md` (bounded the slice) → `invariants.md`
(I-4 baseline key included `minor`; I-9 record index ignores `minor`; I-11 the resulting gap) →
`callsites.md` (call-site map) → `reproducer.md` (header brace correction + focused red regression) →
`key_fix.md` / `unit_matrix.md` (drop `minor`; expand the key tests) → `ordering_tests.md`
(property tests) → `runtime_disabled.md` / `runtime_enabled.md` / `lifetime_tests.md` (runtime
regressions) → `conversion_tests.md` (conversion boundaries) → `test_metadata.md` (record
properties). Note that `unit_matrix.md`, `runtime_disabled.md`, and `runtime_enabled.md` each record
editing a candidate test file (so the 87-case key suite and 31-case runtime `TEST_F` suite current on
disk are the accumulated product of those iterations, not new tests of this one).

### 1.5 Host validation feedback and obligation-collection results

- **Host feedback under `.llm_tmp/overnight/validation/`: absent from this snapshot.** `glob` over
  `.llm_tmp/overnight/validation/**` returns **nothing**; there is no `validation/` directory and no
  host feedback to reconcile against.
- **Obligation-collection results under `.llm_tmp/overnight/obligations/`: absent from this
  snapshot.** `glob` over `.llm_tmp/overnight/obligations/**` returns nothing and `glob` over
  `**/result.json` returns nothing. Earlier reports *retain summaries* of host artifacts
  (`check-result: 0`; `measurement.json` `origin: local_unprotected_measurement`,
  `initiator: Fabro host hook`, `mode: ubsan`, `engineering_acceptance: pending`,
  `full_native_tests: not_executed`, `check_ref: check_conversion_tests`; candidate 46 tests /
  0 failures / compile exit 0; `baseline_with_agent_tests` 46 / 15 / exit 0), but **a successful
  collection node means results were retained, not that checks passed, and here nothing is retained
  at all.**
- Those retained summaries are also **scoped and stale**: they compiled only the focused identifier
  translation unit (`service_identifier.cpp` + `string_registry.cpp` +
  `service_identifier_tests.cpp`) with `g++-12 -std=c++17 -Wall -Wextra -Werror`; they did **not**
  compile `runtime_tests.cpp` or the full `socom_test` / `//score/...` targets, and the recorded
  `service_identifier_tests.cpp` hash predates the later expansions (the current file has 87 `TEST_F`
  cases, §3.1).

### 1.6 Host addendum (task context, not acceptance)

`prior-reports/obligation-addendum.md` (present only as quoted by the other prior reports) states it
"is task context, not engineering acceptance or an approved tailoring decision". It asks the review
to cover the `verification_process.rst` test types and derivation techniques; to keep the review
artifacts distinguishing configured module tests from any absent fuzz/fault-injection harness or full
feature/platform reference-hardware tests; to leave unknown applicability and unexecuted checks
explicit; to **not** label identifier-only tests as full platform validation and **not** to claim a
fuzzy technique without a measurement; to permit concrete missing boundary/equivalence regression
cases within the six source paths; and to record that there is **no authority to invent native links,
select a safety classification, accept risk/deviations, or answer the independent human gate.** This
report honours that in §3.4 and §4.

---

## 2. The recorded syntax failure: inspection of the actual source

### 2.1 Finding (re-verified this iteration by direct `read_file` + `grep`)

`score/socom/impl/service_identifier.hpp` is **brace-balanced**. It is 40 lines. A `grep` for the
brace character class on the file returned exactly four matches:

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`) and two closers (`:32`, `:38`) mean net brace balance `0`. There is **no
third, unmatched closing brace**, and line 39 contains no text at all. A dedicated `grep` for `{`
returns only `:19` and `:29`; a dedicated `grep` for `}` returns only `:32` and `:38`. The task's
"extra closing brace … at line 39" is therefore a **stale, pre-correction description** that matches
the earliest prior reports (`prior-reports/scope.md` §2, `prior-reports/invariants.md` §2,
`prior-reports/callsites.md` §2, which quote lines 38-39 as the split-form `}  // namespace socom` +
`}  // namespace score`), not this snapshot. The `prior-reports/reproducer.md` iteration is the one
that applied the correction and records it; every later report records the header as already
balanced, consistent with the direct reading above.

### 2.2 Repository convention (evidence)

The tree uses two internally-consistent styles:

- **Nested open + single close:** `namespace score::socom {` … one `}  // namespace score::socom`.
  This is the sibling `impl/service_identifier.cpp` (`:18` / `:32`), the public
  `service_interface_identifier.hpp`, and `impl/service_identifier.hpp` itself.
- **Split open + double close:** `namespace score {` + `namespace socom {` … `}  // namespace socom`
  + `}  // namespace score`. This is `impl/runtime_impl.hpp` (`:32-33` / `:232-233`). A repo-wide
  `grep` for the split-form `}  // namespace socom` finds it only in report prose (quoting the old
  state), never in a source file.

`impl/service_identifier.hpp` follows the **nested** form consistently and is balanced.

### 2.3 Minimal repair (recorded for reference; not applied because not needed)

Should the imbalance ever reappear, the minimal correction — matching the sibling `.cpp` — is:

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

Applying it to the already-balanced file would be a no-op; re-introducing a broken state merely to
"fix" it would be a regression. The include guard, the `#include`, the `struct`, its documentation
comment, and the out-of-line `operator<` declaration are otherwise well-formed.

### 2.4 Why it would matter if present

The header is compiled into `//score/socom:socom` (`score/socom/BUILD:24-41`; its `srcs` globs
`impl/**/*.cpp` and `impl/**/*.hpp`) and re-exposed to `//score/socom/test/unit` through the
`testonly` library `impl_service_identifier` (`score/socom/BUILD:46-54`;
`score/socom/test/unit/BUILD:24`). A syntax error there would fail the library and the whole
`socom_test` target, contradicting S-CORE quality criterion 9, "Freedom from compiler warnings &
errors, 100 %" (`verification_plan.rst:332-335`). It is **not** a blocker in this snapshot. This is
**not measured here** (no compile was run); the host artifacts quoted as independent corroboration by
prior reports are out of this checkout.

---

## 3. The focused failing regression for minor-only duplicate registration keys

### 3.1 Key-level regression (present)

`score/socom/test/unit/service_identifier_tests.cpp:174-180`:

```cpp
TEST_F(ServiceInstanceIdentifierTest, KeysDifferingOnlyInMinorVersionAreDuplicates) {
    std::set<Service_instance_identifier> identifiers;

    ASSERT_TRUE(identifiers.insert(make_identifier(service_id_a, 1U, 2U, instance_id_a)).second);
    EXPECT_FALSE(identifiers.insert(make_identifier(service_id_a, 1U, 3U, instance_id_a)).second);
    EXPECT_EQ(1U, identifiers.size());
}
```

This is the smallest focused reproducer: two keys that share `service id + major + instance` and
differ only in `minor` must collapse to one `std::set` element. It is complemented by
`MinorVersionBoundariesAreDuplicates` (`:182`), `AllMinorVersionsCollapseToSingleKey` (`:192`),
`MinorHighBitVariantsAreEquivalent` (`:203`), `MinorVersionNeverAffectsOrdering` (`:430`),
`SetFindLocatesMinorVariantAndCountsItOnce` (`:1034`),
`StdSetCollapsesFiveMinorVariantsOfEveryIdentity` (`:1321`), plus the strict-weak-ordering /
equivalence-class property checks over the deterministic domains (`:537`, `:563`, `:588`, `:634`,
`:662`, `:687`, `:712`, `:735`, later `:1292`, `:1321`, `:1754`, `:1777`, `:1818`, `:1851`). The whole
suite contains **87 `TEST_F`** cases under `ServiceInstanceIdentifierTest` (`:168`…`:2012`, verified
this iteration by `grep`).

### 3.2 Runtime-level regression (present, the requested focused regression)

`score/socom/test/unit/runtime_tests.cpp:402-431`:

```cpp
TEST_F(RuntimeTest, ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError) {
    record_registration_key_metadata(
        "Two connectors sharing instance, service id and major but differing only in the minor "
        "version are the same registration key, so the second construction is refused with "
        "duplicate_service (the minor version is not part of the key identity).");
    Runtime::Uptr runtime = create_runtime();

    Service_interface_identifier const interface_minor_2{
        "TestInterface", Literal_tag{}, Service_interface_identifier::Version{1U, 2U}};
    Service_interface_identifier const interface_minor_3{
        "TestInterface", Literal_tag{}, Service_interface_identifier::Version{1U, 3U}};
    Service_instance const instance{"TestInterface", Literal_tag{}};

    Server_service_interface_definition const configuration_minor_2{
        interface_minor_2, to_num_of_methods(2U), to_num_of_events(3U)};
    Server_service_interface_definition const configuration_minor_3{
        interface_minor_3, to_num_of_methods(2U), to_num_of_events(3U)};

    Server_connector_callbacks_mock callbacks;
    auto const first = runtime->make_server_connector(configuration_minor_2, instance,
                                                      create_server_callbacks(callbacks));
    ASSERT_TRUE(first.has_value());

    Server_connector_callbacks_mock callbacks_2;
    auto const second = runtime->make_server_connector(configuration_minor_3, instance,
                                                       create_server_callbacks(callbacks_2));
    score::Result<Disabled_server_connector::Uptr> const duplicate_service =
        score::MakeUnexpected(Construction_error::duplicate_service);
    EXPECT_EQ(duplicate_service, second);
}
```

It exercises the **actual registration entry point**, `Runtime::make_server_connector()`
(`score/socom/runtime.hpp:188-191`), whose implementation builds the key
(`Service_instance_identifier const identifier{configuration.get_interface(), instance};`,
`runtime_impl.cpp:443`) and inserts it under the key mutex (`runtime_impl.cpp:449-454`; insert at
`:451`), returning `Construction_error::duplicate_service` when `insert(...).second` is false
(`:452`). All helpers used are already provided by the linked test framework:
`create_runtime()` (`impl/runtime.cpp:22`; declared `runtime.hpp:221`), `to_num_of_methods` /
`to_num_of_events` (`service_interface_definition.hpp:35` and its sibling),
`create_server_callbacks(Server_connector_callbacks_mock&)`
(`score/socom/test/framework/inc/score/socom/socom_mocks.hpp:66`), and the runtime/config types. Both
connectors are constructed but never enabled, so the duplicate is rejected at construction and the
second connector never reaches `Service_record::register_server_connector()`'s single-server
precondition (`SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)`, `runtime_impl.cpp:369`).

The runtime file also carries same-configuration disabled (`:440-469`), different-major (`:471-504`),
enabled-duplicate (`:694`), lifetime/reuse (`:371`, `:986`, `:1021`), and service-id/instance/major
slot isolation (`:1253`, `:1197`, `:1141`) cases, plus the metadata helper
`record_registration_key_metadata` (`:264-267`).

> **No test was added this iteration.** The requested focused failing regression is already present
> in the candidate test files above; this iteration verified (by `read_file`/`grep`) and retained it
> rather than duplicating it. The snapshot already contains the "expanded tests" the task asks for
> after the source correction (87 `TEST_F` in `service_identifier_tests.cpp`; 31 `TEST_F` + 1 `TEST` +
> 1 `TEST_P` in `runtime_tests.cpp`, both verified this iteration by `grep`).

### 3.3 Why it is a *failing* regression (red → green, source-derived)

Both regressions describe the corrected behaviour and therefore **fail** against the pre-correction
key ordering, i.e. they are genuine failing reproducers for the defect:

- **Key level (`std::set`).** `std::set` uniqueness is `!(a<b) && !(b<a)`. With the baseline
  ordering `std::tie(lhs.instance, lhs.interface) < std::tie(rhs.instance, rhs.interface)`, which
  delegates to `Service_interface_identifier::operator<` / `Version::operator<`
  (`service_interface_identifier.hpp`) and therefore includes `minor`, two keys sharing
  `instance + id + major` and differing only in `minor` compare ordered (`2 < 3`). The second
  `insert(...)` returns `true` and the set size is `2`, so `EXPECT_FALSE(insert(...).second)` and
  `EXPECT_EQ(1U, size())` fail. With the corrected ordering the two keys are equivalent, the second
  insert returns `false`, and the size stays `1`.
- **Runtime level (`make_server_connector`).** With the baseline key, the two configurations in §3.2
  produce distinct identifiers, both pass the insert check at `runtime_impl.cpp:451`, the second call
  returns a valid connector, and `EXPECT_EQ(duplicate_service, second)` **fails**. With the corrected
  key, the second `make_server_connector` finds the key already present and returns
  `Construction_error::duplicate_service` (`runtime_impl.cpp:449-454`), so the test passes.

The failure is not merely an encoding of the assertion: it is the direct consequence of making
`minor` part of the identity while `Service_database` ignores it (prior `invariants.md` I-11), so a
minor-only difference slips past the duplicate gate and can reach the single-server
`SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)` in `Service_record::register_server_connector`
(`runtime_impl.cpp:366-371`) on enable.

> **Not observed.** No test was run in this iteration. The red/green statements above are derived
> from `std::set`/strict-weak-ordering semantics and from the source ordering, exactly as labelled.

### 3.4 Boundary / equivalence coverage versus the host addendum

- **Boundary values** in the key tests: major `0`, `1`, `0x7FFF`, `0x8000`, `0xFFFE`, `65535`;
  minor `0`, `1`, `2`, `3`, `0x7FFF`, `0x8000`, `65535`.
- **Equivalence classes**: minor-only (equivalent) versus service-id / instance / major differences
  (distinct), including combined 2x2x2 and 3x3x3 matrices and deterministic 36-key and 64-key
  domains.
- **Still absent / unknown applicability (explicit pending work):** no fuzz harness, no
  fault-injection harness, and no full feature-/platform-level reference-hardware tests exist in this
  workspace; no fuzzy technique was executed. These identifier-only tests must **not** be presented
  as platform validation. The minor-compatibility rule (`client.minor <= server.minor`) is exercised
  by other suites (`interface_compatibility_tests.cpp`, `client_tests.cpp`), not by this key slice.

### 3.5 Build wiring (no BUILD change required)

- `score/socom/BUILD:46-54` defines the `testonly` `impl_service_identifier` library exposing
  `impl/service_identifier.hpp` to `//score/socom/test/unit:__pkg__`, depending on `:socom`.
- `score/socom/test/unit/BUILD:16-29` defines `socom_test` with `srcs = glob(include = ["*.cpp"])`
  and depends on `//score/socom:impl_service_identifier`, `//score/socom:mock`,
  `//score/socom/test/framework:socom_test_framework`, and googletest.

Therefore both test files are already collected and the internal key header is visible to the test
package. Intended commands for a later, permitted execution iteration (**not executed here**):

```bash
bazel test //score/socom/test/unit:socom_test
# focused key-level:
bazel test //score/socom/test/unit:socom_test --test_filter='ServiceInstanceIdentifierTest.*'
# focused runtime regression:
bazel test //score/socom/test/unit:socom_test \
    --test_filter='RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError'
```

Expected on the pre-correction key (minor included): both focused checks **fail** as described in
§3.3. Expected on the corrected key: both **pass**.

---

## 4. Obligations status (none satisfied)

### 4.1 Pinned obligation sources read this iteration

All nine entries of `.llm_tmp/context/obligations/source-index.json` were read from
`.llm_tmp/context/obligations/`, together with `authority.json`:

| id | file | status (re-read this iteration) |
|----|------|-------------|
| `coding_guidelines` | `coding_guidelines.rst` | `:status: valid`; MISRA C++:2023 with C++17 |
| `code_analysis` | `code_analysis.rst` | `:status: valid`; clang-tidy + gcc/clang warnings + Coverity; sanitizers; gcov/gcovr |
| `misra_mapping` | `misra_mapping.rst` | **`:status: draft`**; the rule table is not a valid obligation |
| `verification_plan` | `verification_plan.rst` | `:status: valid`; TestType/DerivationTechnique tables; quality criteria 1-9 (criterion 9 "Freedom from compiler warnings & errors" at `:332-335`) |
| `development_plan` | `development_plan.rst` | `:status: valid`; C++17, GCC host compiler, QCC target, Bazel |
| `tool_management` | `tool_management.rst` | `:status: valid`; tools must be identified / evaluated / qualified |
| `verification_process` | `verification_process.rst` | `:status: valid`; `gd_req__verification_link_tests_cpp`, `gd_req__verification_independence`, checks-extended and SCA classification requirements |
| `verification_guideline` | `verification_guideline.rst` | `:status: valid`; traceability, independence, reporting |
| `inspection_checklist` | `inspection_checklist.rst` | **`:status: draft`**; blank IMPL template |

Every entry in `source-index.json` is marked `"native_acceptance": "not_inferred"` — pinned, but its
applicability to this slice is **not inferred**. `authority.json` records
`"engineering_acceptance": "pending"`, `"human_reviews": "unanswered"`, `"safety_class": "unknown"`,
`"codeql_scope": "Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload"`, and the instruction
`"Restart the failed queue for one complete pass through all obligations"`.

### 4.2 Obligation status for this slice (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Freedom from compiler warnings & errors (100 %) | `verification_plan.rst:332-335` (criterion 9) | **NOT MEASURED** — header is brace-balanced by inspection (§2), but nothing was compiled; no host artifact is present |
| Static code analysis (clang-tidy / CodeQL), findings classified | `code_analysis.rst`; `verification_process.rst` (SCA classification) | **NOT PERFORMED** — no tool, no build; prior clang-tidy attempt blocked on config; CodeQL MISRA applicability unestablished (draft mapping) |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` | **UNKNOWN** — mapping is `:status: draft`; not applied |
| Structural statement / branch coverage goals | `verification_plan.rst` (criteria 1-2) | **NOT MEASURED** — no test execution; prior coverage capture is out of this checkout |
| Unit/component testing executed, results recorded | `verification_plan.rst` (criteria 6-7); `verification_guideline.rst` | **NOT EXECUTED** — 0 tests run; the prior key-TU run is stale and excludes `runtime_tests.cpp` |
| Interface / requirements-based / resource / fault-injection test types | `verification_process.rst`; `verification_plan.rst` | **NOT PERFORMED / applicability not inferred** — no harness; identifier-only tests must not be labelled platform validation |
| Boundary / equivalence derivation | `verification_process.rst` | **SOURCE-ONLY** — cases exist (§3.4) but were not executed |
| Fuzzy testing technique | `verification_plan.rst` | **NOT EXECUTED / NOT CLAIMED** — no harness and no measurement |
| Linking tests to requirements (record properties) | `verification_process.rst` (`gd_req__verification_link_tests_cpp`) | **PARTIAL / NOT DONE** — `DerivationTechnique`/`Description` are recorded in the test sources (`service_identifier_tests.cpp:42-65`; `runtime_tests.cpp:264-267`); `TestType` and the `Verifies` links cannot be set without inventing identifiers |
| Independence of verification / review by a different committer | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Implementation inspection checklist IMPL_01…IMPL_03 | `inspection_checklist.rst` | **NOT FILLED** — draft template, no inspection |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** for this slice; no tool run here |
| Obligation collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **ABSENT in this snapshot** — directory not present |
| Native acceptance | `source-index.json` | **not_inferred** for every entry |

**Explicit non-satisfaction statement.** Missing tools (no build/test in this task), the unknown
safety class and un-inferred applicability, the incomplete extraction of host artifacts, the absent
obligation-collection results, and the unanswered human reviews mean **none of the checked
obligations may be treated as satisfied**. A collection node that retained results would only show
*retention*, not passing; here nothing is retained at all. In particular, the absence of
`.llm_tmp/overnight/validation/` and `.llm_tmp/overnight/obligations/*/result.json` is **not**
evidence that the corresponding checks passed.

---

## 5. Measurement and validation status

- **Tools:** `read_file`, `grep`, `glob`, `write_file` only. No `shell`, delegation, web, approval,
  publishing, or engineering acceptance.
- **Executed measurements:** **none** this iteration. No build, no `bazel test`, no runtime. The brace
  census (§2), the key identity (§0.3), and the expected test behaviour (§3.3) are static readings
  of the snapshot, or explicitly-labelled strict-weak-ordering consequences.
- **Test inventory (read, not run):** `score/socom/test/unit/service_identifier_tests.cpp` has
  **87 `TEST_F`** cases under `ServiceInstanceIdentifierTest` (verified this iteration by `grep`;
  `:168`…`:2012`); `score/socom/test/unit/runtime_tests.cpp` has **31 `TEST_F`** (including the
  focused minor-only regression at `:402`), plus 1 `TEST` (`RuntimeFactoryTest.DefaultConstructorWorks`
  at `:239`) and 1 `TEST_P` (`RuntimeBridgeTest.CreationOfClientsWillCallRequestServiceFunction` at
  `:1311`), all verified this iteration by `grep`.
- **Scope:** local, unprotected, scoped. This draft has not been reviewed, accepted, published, or
  reproduced on a full native runtime. Unit/integration execution and human review remain pending.
- **Source writes:** none. The recorded syntax failure is absent (§2) and the requested focused
  regression is already present (§3); the smallest correct change was therefore no change.

---

## 6. Notice preservation

- No source, build, test, config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was created, edited, or
  deleted by this iteration; only this report was written. Every existing Apache-2.0 / notice header
  is untouched, and all 38 prior-report files under `.llm_tmp/overnight/prior-reports/` and the 3
  earlier files under `.llm_tmp/overnight/reports/` were preserved.
- The header the task flagged (`score/socom/impl/service_identifier.hpp`) was inspected and left
  unchanged because it is already brace-balanced and otherwise well-formed (§2).
- This report itself carries the Apache-2.0 header.
- The duplicate key remains an `impl/`-only type; the `testonly`
  `//score/socom:impl_service_identifier` library exposes it to `//score/socom/test/unit` only, so no
  public header or notice surface changed.

---

## 7. Pending human review checklist

- [ ] **Confirm the §2 re-inspection**: the header is already brace-balanced (single nested close
      `}  // namespace score::socom`; line 39 blank), so the recorded syntax failure is stale and no
      correction is required. If the "cancelled draft" is a different revision that still carries the
      extra brace, locate it and authorize its correction; no such file exists in this checkout.
- [ ] **Resolve the instruction conflict**: the task directs correcting the source while the actual
      source contains no defect; confirm that a no-op (report only) is the intended outcome here.
- [ ] **Confirm the focused regression in §3.2**
      (`ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError`) and the key-level
      regression in §3.1 are the wanted coverage, and that using the public
      `Runtime::make_server_connector()` path (rather than a new factory entry point) is acceptable.
- [ ] **Confirm the key semantics**: `minor` is **not** part of the duplicate-server registration
      key; identity is `(instance, service id, major)`, consistent with the `Service_database` index
      and issue #84.
- [ ] **Confirm `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)`** is the authoritative single-server
      invariant, so the key must be at least as coarse as the record index.
- [ ] **Keep the #84 public `Service_interface_identifier` restructure**, FindService wildcard
      handling, and config minor-wildcard narrowing out of this bounded slice until separately
      accepted.
- [ ] **Do not treat the identifier-only tests as platform validation**; provide a fuzz /
      fault-injection harness and full feature/platform reference-hardware tests separately if
      required.
- [ ] **Supply the missing artifacts** (`.llm_tmp/overnight/obligations/*/result.json` and
      `.llm_tmp/overnight/validation/`) into this checkout; do not infer passing from absence or from
      prior reports' retained summaries.
- [ ] **Run the full native suite** (`bazel test //score/socom/test/unit:socom_test` and the broader
      `//score/...` set), including `runtime_tests.cpp`, and schedule independent human review (the
      approver must differ from the author, per `gd_req__verification_independence`).

---

*End of reproducer review draft. Local, unprotected, scoped. No engineering acceptance; human reviews
unanswered; full native runtime tests pending. Every statement is a local reading of the working tree,
a prior report's recorded reading, or an explicitly-labelled logical consequence — none is acceptance,
review approval, publication, or a full native run.*
