<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — native build and full-test review (`native_build_review`)

**Document type:** review draft (native Bazel build/test review + actual-source
inspection + toolchain/target identity register + separation of measured results
from unavailable dependencies and platform/configuration gaps + obligations status)
**Date:** 2026-10-02
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version
handling in socom* (issue #84)
**Run:** branch `fabro/run/01M3YRJEGXNY6CB81T7TKW774B`
**Status:** local, unprotected, scoped. **No engineering acceptance exists. Human
reviews are unanswered. Full native runtime tests remain pending.** Every statement
below is either a direct reading of the working tree, a direct reading of a
retained artifact under `.llm_tmp/overnight/`, or an explicitly-labelled logical
consequence. Nothing here is published, reviewed, accepted, or a full native run.

> **Tool / write boundary actually observed.** Only `read_file`, `grep`, `glob`,
> and `write_file` were used. No `shell`, delegation, web access, approval,
> publishing, or engineering acceptance was performed. **This iteration wrote
> exactly one file — this report** (`native_build_review.md`). No source, build,
> test, config, `NOTICE`, `LICENSE`, `REUSE.toml`, host-validation, or prior-report
> file was created, edited, or deleted. Every report under
> `.llm_tmp/overnight/reports/` and every file under
> `.llm_tmp/overnight/prior-reports/` was preserved unchanged.
>
> **Instruction conflict, recorded not silently resolved.** The task records *"the
> cancelled draft has a measured GCC syntax failure: an extra closing brace in
> `score/socom/impl/service_identifier.hpp` at line 39"* and directs *"Inspect and
> correct the actual source before expanding tests."* Direct inspection of the
> **actual** source (§2) shows the header is **already brace-balanced** and line 39
> is blank; the retained GCC compile exits `0`. There is no unmatched brace to
> remove. The task's own final sentence — *"This is a review draft: only that
> report may be written"* — forbids a source write in any case. **No source was
> edited and no test was expanded.** The conflict is recorded for the human
> reviewer (§11).
>
> **Non-satisfaction rule applied throughout.** A successful obligation-collection
> node means the results were **retained**, not that the checks **passed**. Missing
> tools, unknown applicability, incomplete extraction, and unanswered human
> reviews are **not** treated as satisfied. In particular, a tool that produced
> **no** finding because it **did not run** is recorded as *"not run"*, never as
> *"clean"*.

---

## 0. Summary

1. **The named GCC syntax failure is not present in the actual source (§2).**
   `score/socom/impl/service_identifier.hpp` is a 40-line, brace-balanced header.
   `grep '[{}]'` returns exactly four brace-bearing lines — `:19`
   (`namespace score::socom {`), `:29` (`struct Service_instance_identifier final {`),
   `:32` (`};`), `:38` (`}  // namespace score::socom`) — two openers, two closers,
   net balance `0`; line `:39` is blank and `:40` is `#endif`. `glob
   **/service_identifier.hpp` returns exactly one path. The retained focused **GCC**
   compile of the candidate translation unit exits `0` with empty `stderr`
   (`compiler_diagnostics/result.json` `gcc-compile` `exit_code: 0`,
   `gcc-tests` `exit_code: 0`). The described defect matches the *earliest* prior
   reports (split-form double close), not this checkout. **No correction is
   required or applied.**
2. **The native Bazel build was never executed (§4).** Every `native_*`,
   `cross_compilation`, `format_precommit`, `secret_dependency_checks`, and the
   Bazel/`pre-commit`/`reuse`/`clang-format` legs fail with `[Errno 2] No such file
   or directory: '/tmp/s-core-001/bin/bazel'` (or the corresponding missing tool),
   **exit 127**. `native_build` and `native_tests` are therefore **unavailable-tool
   blockers**, not builds and not test runs.
3. **The only executed full-ish result is a focused, single-translation-unit GCC
   run (§5).** The host measurement (`validation/measurement.json`, `before.json`,
   `after.json`) compiled **only** `service_identifier.cpp` + `string_registry.cpp` +
   `service_identifier_tests.cpp` + vendored googletest with `g++-12 -std=c++17
   -Wall -Wextra -Werror -pthread` (candidate additionally
   `-fsanitize=undefined -fno-sanitize-recover=all`). It records `baseline_with_agent_tests`
   **85 tests / 28 failures / compile 0** and `candidate` **85 tests / 0 failures /
   compile 0**. That is genuine red-to-green evidence for the key change, but it is
   **not** a Bazel build and does not compile `runtime_tests.cpp` or `//score/...`.
4. **Focused GCC tests cannot satisfy full Bazel readiness (§6).** They omit the
   Bazel graph (`//...`), the pinned toolchain/features, `runtime_tests.cpp`, the
   full `socom_test` target, sanitizer Bazel configs, integration/QEMU, coverage,
   format/lint, and the default Bazel build disables warnings-as-errors
   (`.bazelrc:117` `common --features=-treat_warnings_as_errors`).
5. **No obligation is satisfied (§9).** Every `source-index.json` entry is
   `native_acceptance: not_inferred`; `authority.json` is
   `engineering_acceptance: pending`, `human_reviews: unanswered`,
   `safety_class: unknown`.

---

## 1. Binding, scope, and evidence

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` — *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:2-4` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` | `.llm_tmp/context/issue-snapshot.json:19-20` |
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |
| Current branch | `fabro/run/01M3YRJEGXNY6CB81T7TKW774B` | environment |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an
accepted obligation**: service-instance identifier = `service id + major + minor +
instance id`; service identifier = `service id + major`; FindService = `service id +
major + optional<minor> + optional<instance>`; plus a proposal to exclude `minor`
from identity. There is no comment and no acceptance record, so none of it is
binding.

### 1.2 The six writable candidate source paths (`candidate-files.json`)

| File (repo-relative) | Baseline git blob | Baseline present | Working tree (read this iteration) |
|----------------------|-------------------|------------------|------------------------------------|
| `score/socom/BUILD` | `3477ea0851fdcd82ec6ea9d71424013cbdf41962` | yes | `socom` `cc_library` (`:24-41`) + `testonly` `impl_service_identifier` (`:46-54`) |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e22355242009fe20dada2a9a0d0c7a9c7` | yes | key identity `(instance, service id, major)`; `minor` excluded (`:28-29`) |
| `score/socom/impl/service_identifier.hpp` | `c8bae7908da9f087c518934f7b9f8d86db9a20ec` | yes | brace-balanced, 40 lines; line 39 blank (§2) |
| `score/socom/test/unit/BUILD` | `3c03a7b14286051f97fa5022206564bd63645171` | yes | `socom_test` globs `*.cpp`; deps wired (`:16-29`) |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab726db8bf994c960045d6fd7fdf84d7395` | yes | **31 `TEST_F` + 1 `TEST` + 1 `TEST_P`**; minor-only regression `:402-431` |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(none — `null`)* | **no** (manifest expects a **new** file) | **87 `TEST_F`** present; metadata `SetUp()` at `:42-65` |

The `null` baseline blob for `service_identifier_tests.cpp` is the manifest's
expectation of a **new** unit-test file; it exists on disk only as part of the
un-merged working tree (the "cancelled draft"). The five present baseline blobs
also appear in `.llm_tmp/context/source-manifest.json`, binding the candidate set
to the baseline commit.

### 1.3 Evidence read this iteration

- `.llm_tmp/context/`: `issue-snapshot.json`, `candidate-files.json`,
  `source-manifest.json`, `obligations/authority.json`, `obligations/source-index.json`.
- `.llm_tmp/overnight/validation/`: `check-result` (`0`), `measurement.json`,
  `before.json`, `after.json`, `before-*`/`after-*` command/stdout/stderr captures.
- `.llm_tmp/overnight/obligations/*/result.json`: `native_build`, `native_tests`,
  `native_lint`, `native_coverage`, `native_sanitizers`, `native_tsan`, `native_docs`,
  `native_traceability`, `native_integration`, `native_performance`,
  `cross_compilation`, `format_precommit`, `secret_dependency_checks`,
  `tool_assurance`, `process_checks`, `rework_progress`, `compiler_diagnostics`,
  `focused_asan_lsan`, `focused_tsan`, `focused_cppcheck`, `focused_clang_tidy`,
  `focused_coverage`, `focused_memcheck`, `codeql_security`, `codeql_misra`.
- `.llm_tmp/overnight/reports/` (read, preserved) and
  `.llm_tmp/overnight/prior-reports/` (read, preserved), including `scope.md`,
  `invariants.md`, `reproducer.md`, `key_fix.md`, `finding_classification.md`,
  `tool_findings_repair.md`, `coverage_review.md`, `analyzer_plan.md`.

Per the task rule, a successful collection node means results were **retained**, not
that checks **passed**.

### 1.4 Pinned authority and obligation sources

`authority.json`: `engineering_acceptance: pending`, `human_reviews: unanswered`,
`safety_class: unknown`, `codeql_scope: "Public Apache-2.0
eclipse-score/inc_someip_gateway; no upload"`, instruction *"Restart the failed
queue for one complete pass through all obligations"*. Every entry of
`source-index.json` is `"native_acceptance": "not_inferred"`. The nine pinned
sources in `.llm_tmp/context/obligations/` were read (`coding_guidelines`,
`code_analysis`, `misra_mapping` *[draft]*, `verification_plan`, `development_plan`,
`tool_management`, `verification_process`, `verification_guideline`,
`inspection_checklist` *[draft]*).

---

## 2. Actual-source inspection of the recorded syntax failure

### 2.1 Verdict: the header is brace-balanced

`score/socom/impl/service_identifier.hpp`, read directly this iteration:

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

`grep '[{}]'` on the file returns exactly `:19`, `:29`, `:32`, `:38` — two openers,
two closers, net brace balance `0`. Line 39 contains no text. `glob
**/service_identifier.hpp` returns exactly one path, so there is no second,
differently-braced copy in this checkout.

### 2.2 Tool corroboration

- `.llm_tmp/overnight/obligations/compiler_diagnostics/result.json` records the
  `gcc-compile` command (g++-12, `-std=c++17 -Wall -Wextra -Werror -pthread -I.`)
  with `"exit_code": 0`, followed by `gcc-tests` with `"exit_code": 0`.
- `.llm_tmp/overnight/validation/measurement.json` records candidate
  `compile_exit: 0`; `before.json`/`after.json` are the parsed gtest JSON of a
  compiling binary.
- `validation/before-compile.stderr` and `validation/after-compile.stderr` are both
  empty.

A surviving extra closing brace would break all of these.

### 2.3 Disposition

The described defect is a **stale, pre-correction description**. The prior reports
(`reproducer.md` §2, `scope.md` §2, `key_fix.md` §2) record that the earliest
reports quoted lines 38–39 as the split-form `}  // namespace socom` + `}  //
namespace score`, and that the correction left line 39 blank — exactly the state
observed here. Applying the historical repair to the already-balanced file would be
a no-op at best and a compile break at worst. **No correction is applied; none is
required.** Consistent with the write boundary, no test was expanded either.

---

## 3. Registration-key state (context for the build/test review)

- `Service_instance_identifier` is `{ Service_interface_identifier interface;
  Service_instance instance; }` (`service_identifier.hpp:29-32`) with one out-of-line
  `operator<` (`:35`) and no `operator==`/`std::hash`.
- `score/socom/impl/service_identifier.cpp:20-30` orders by
  `std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major) <
  std::tie(rhs.instance, rhs.interface.id, rhs.interface.version.major)`, i.e.
  **`minor` is excluded**; identity is `(instance, service id, major)`.
- The header comment (`:21-28`) and `.cpp` comment (`:21-27`) document the exclusion
  and tie it to issue #84 / the minor-ignoring `Service_database` index.
- `score/socom/BUILD` compiles `impl/**/*.cpp` + `impl/**/*.hpp` into `//score/socom:socom`
  and exposes the internal key header to tests via the `testonly`
  `//score/socom:impl_service_identifier` (`:43-54`).
- `score/socom/test/unit/BUILD:16-29` defines `cc_test(name = "socom_test")` whose
  `srcs = glob(include = ["*.cpp"])` therefore already collects the new/expanded
  test files. No BUILD change is required for them.

This is a source reading. It is **not** a compile or test result (see §5, §6).

---

## 4. Native Bazel build and test results (all unavailable-tool blockers)

All of the following attempted real Bazel (or tool) commands and were **not
executed** because the required tool binary is absent. These are **actual retained
collection results**, and they are **failures to run**, not passing checks.

### 4.1 Native Bazel checks

| Check | Attempted command (labels/config) | Exit | Status in artifact | Cause |
|-------|-----------------------------------|------|--------------------|-------|
| `native_build` | `bazel build --jobs=2 //...` | **127** | `findings_or_execution_failure` | `/tmp/s-core-001/bin/bazel` missing |
| `native_tests` | `bazel test --jobs=2 //... --build_tests_only` | **127** | `findings_or_execution_failure` | `/tmp/s-core-001/bin/bazel` missing |
| `native_lint` | `bazel run //:clang-tidy.check`; `bazel run //:ruff.check` | **127** | `findings_or_execution_failure` | `/tmp/s-core-001/bin/bazel` missing |
| `native_coverage` | `bazel coverage //... --build_tests_only` (env `COVERAGE_THRESHOLD=73`); `bazel run @score_coverage//:generate_coverage_html` | **127** | `findings_or_execution_failure` | `/tmp/s-core-001/bin/bazel` missing |
| `native_sanitizers` | `bazel test //score/... //tests/... --build_tests_only --features=asan --features=lsan --features=ubsan_clang` | **127** | `findings_or_execution_failure` | `/tmp/s-core-001/bin/bazel` missing |
| `native_tsan` | `bazel test //score/... //tests/... --build_tests_only --features=tsan` | **127** | `findings_or_execution_failure` | `/tmp/s-core-001/bin/bazel` missing |
| `native_docs` | `bazel run //:docs` | **127** | `findings_or_execution_failure` | `/tmp/s-core-001/bin/bazel` missing |
| `native_traceability` | `bazel test //:unit_tests //:component_tests`; `bazel run //:docs`; `bazel run //:traceability_gate -- --need-type=comp_req` | **127** | `findings_or_execution_failure` | `/tmp/s-core-001/bin/bazel` missing |
| `native_integration` | `bazel test --config=qemu-integration //quality/... //tests/integration_test/...` | **127** | `findings_or_execution_failure` | `/tmp/s-core-001/bin/bazel` missing |
| `native_performance` | `bazel test --config=perf-tests //tests/benchmarks/... --build_tests_only`; `--config=perf-tests-flamegraphs` | **127** | `findings_or_execution_failure` | `/tmp/s-core-001/bin/bazel` missing |
| `cross_compilation` | `bazel build --config=x86_64-linux //score/... //tests/...`; `--config=aarch64-linux` same | **127** | `findings_or_execution_failure` | `/tmp/s-core-001/bin/bazel` missing; blocker *"QNX SDK entitlement and target execution not configured; no credential acquired"* |
| `format_precommit` | `bazel test //:format.check`; `pre-commit run --all-files`; `reuse lint`; `bazel mod tidy`; `bazel mod deps --lockfile_mode=error` | **127** (format/pre-commit/reuse/mod) | `findings_or_execution_failure` | `/tmp/s-core-001/bin/bazel`, `pre-commit`, `reuse` missing; limit *"Formatting/pre-commit mutations occur only in this disposable collector copy"* |

Notes recorded in the artifacts:

- `native_coverage` carries the explicit limit *"Repository CI threshold 73 is not
  platform 85/100 line-and-branch acceptance"*.
- `native_integration` prerequisites are present (`kvm_exists: true`,
  `qemu: /usr/bin/qemu-system-x86_64`) but the Bazel command still failed on the
  missing `bazel`; prerequisites **do not** substitute for a run.
- `format_precommit`'s `git-init` and `git-add` legs actually ran (**exit 0**); the
  substantive format/pre-commit/reuse/mod legs did not.

**Disposition:** none of the native build, test, coverage, sanitizer, lint, docs,
traceability, integration, performance, cross-compilation, or format checks ran.
They are **unavailable-tool blockers**, and per the non-satisfaction rule they may
not be treated as satisfied.

### 4.2 Secret/dependency scan and tool assurance

| Check | Result | Reading |
|-------|--------|---------|
| `secret_dependency_checks` | `gitleaks` **exit 127** (missing); status `findings_or_execution_failure`; blocker *"No adopted vulnerability database/ecosystem mapping or GitHub dependency scan receipt; dependency inventory is not a vulnerability scan"*; `lock_sha256: c90b245bc0f8aadea595e2d3bc618325e064b371d88544bcb787b1afb28564b6`; 29-entry `dependency_inventory` (e.g. `googletest 1.18.0`, `rules_cc 0.2.22`, `score_baselibs 0.2.13`, `flatbuffers 25.12.19`) | **No secret scan run**; the retained lock/dependency inventory is **not** a vulnerability result |
| `tool_assurance` | status `completed_with_blockers`; version probes ran for available tools | Tools **available**: `g++-12` (`88315fd2…`), `clang++`/`clang-tidy` 19.1.7 (`7969846391…` / `5f733fae…`), `codeql` 2.21.4 (`d38df35e…`), `gcov-12`, `gcovr`, `cppcheck`, `qemu-system-x86_64`, `perf`. Tools **unavailable** (`available: false`, `sha256: null`): `/tmp/s-core-001/bin/bazel`, `clang-format`, `pre-commit`, `reuse`, `/usr/bin/valgrind`, `/tmp/score-someip84-obligation-tools/usr/bin/valgrind`, `gitleaks` |

**Disposition:** tool identity for the host compilers/analyzers is retained, but the
native driver (`bazel`), memory checker (`valgrind`), secret scanner (`gitleaks`),
and formatting/license tools (`clang-format`, `pre-commit`, `reuse`) are absent.
Tool *identification* is not tool *qualification*; `tool_management.rst` requires
identify/evaluate/qualify and no qualification decision exists for this slice.

### 4.3 Process and rework metadata

- `process_checks`: status `completed_with_blockers`; blockers *"Lexical metadata
  inventory cannot prove semantic requirement coverage"*, *"Safety/QM applicability
  and approved tailoring unknown"*, *"Independent inspection and acceptance
  required"*, *"External AoU and full integration verification require scoped
  review"*. Metadata inventory: `runtime_tests.cpp` **33 test macros**;
  `service_identifier_tests.cpp` **87 test macros**; each carries
  `DerivationTechnique` and `Description` record properties only.
- `rework_progress`: status `completed`, `source_changed_this_round: true`,
  `rework_requested: false`, stop reason *"One complete pass requested; unresolved
  findings stay pending"*; the recorded blockers list is empty.

These are process/metadata observations, not build or test evidence.

---

## 5. The focused GCC measurement (the only executed full-ish result)

### 5.1 What was actually compiled and run

`validation/after-compile.command.json` / `validation/before-compile.command.json`:

```
/usr/bin/x86_64-linux-gnu-g++-12 -std=c++17 -Wall -Wextra -Werror -pthread -I. \
  -I<snapshot>/.llm_tmp/googletest/googletest/include \
  -I<snapshot>/.llm_tmp/googletest/googletest \
  score/socom/impl/service_identifier.cpp \
  score/socom/impl/string_registry.cpp \
  score/socom/test/unit/service_identifier_tests.cpp \
  <snapshot>/.llm_tmp/googletest/googletest/src/gtest-all.cc \
  <snapshot>/.llm_tmp/googletest/googletest/src/gtest_main.cc \
  -o <...>/after            # after adds: -fsanitize=undefined -fno-sanitize-recover=all
```

and `validation/after-test.command.json` runs the resulting binary with
`--gtest_output=json:.../after.json`. `measurement.json` records
`check_ref: check_conversion_tests`, `mode: ubsan`, `status: completed`,
`changed_paths: ["score/socom/test/unit/service_identifier_tests.cpp"]`.

### 5.2 Measured results (retained, local, unprotected, scoped)

| Artifact | Tests | Failures | Disabled | Errors | Compile exit | Test exit |
|----------|-------|----------|----------|--------|--------------|-----------|
| `before.json` (`baseline_with_agent_tests`) | 85 | **28** | 0 | 0 | 0 | 1 |
| `after.json` (`candidate`) | 85 | **0** | 0 | 0 | 0 | 0 |

`measurement.json` end fields: `origin: local_unprotected_measurement`,
`initiator: Fabro host hook`, `engineering_acceptance: pending`,
`full_native_tests: not_executed`, `compiler: /usr/bin/x86_64-linux-gnu-g++-12`,
`compiler_sha256: 88315fd2d961a1f4e4070b104d7bd4c7670df19d9949409879ba269466c196d3`.

**Interpretation (measured):** the corrected key turns a focused `baseline + agent
tests` red state (28 failures) green (0 failures) in a sanitizer-enabled focused
binary. The failures in `before.json` are all minor-version-identity assertions
(e.g. `KeysDifferingOnlyInMinorVersionAreDuplicates` expecting the second insert to
return `false` but observing `true`; set sizes 2 vs 1).

### 5.3 Scope limits of the measurement (important)

1. **Focused translation unit only.** It compiled
   `service_identifier.cpp` + `string_registry.cpp` + `service_identifier_tests.cpp`
   + googletest. It did **not** compile `runtime_tests.cpp`, `client_tests.cpp`, the
   full `socom_test` glob, or any Bazel target.
2. **Stale test count.** The measured file has **85 tests**, while the current
   `service_identifier_tests.cpp` has **87 `TEST_F`** (and `process_checks` records
   **87** test macros). The two newest cases — `FreshDynamicServiceIdStringViewRegistersAndCollapses`
   (`:1982`) and `FreshDynamicServiceIdRvalueRegistersAndCollapses` (`:2012`) — are
   **not** in the measured 85-test artifact.
3. **Not the native toolchain.** It used the host `g++-12` with `-std=c++17
   -Wall -Wextra -Werror`, whereas the native build uses the pinned Bazel toolchain
   (`@score_bazel_cpp_toolchains`, `toolchains_llvm`); the obligation artifact itself
   notes *"GCC 12.3 / Clang 19 differ from native toolchain pins."*
4. **Sanitizer flags are compiler-specific**, not the Bazel sanitizer configs
   (`--features=asan/lsan/ubsan_clang`), which never ran.

**Therefore the measurement is genuine but scoped evidence of the key change, and
it is not full native build or test readiness.**

---

## 6. Why focused GCC tests cannot satisfy full Bazel readiness

This is the central separation the task asks for:

1. **Different build system.** The focused run is a single `g++-12` command line;
   the repository contract is Bazel (`AGENTS.md`: build `bazel build //score/...`,
   tests `bazel test //score/...`, integration `--config=qemu-integration`). The
   Bazel graph, `BUILD` wiring (`//score/socom:socom`,
   `//score/socom:impl_service_identifier`, `//score/socom/test/unit:socom_test`),
   `MODULE.bazel` dependency resolution, and pinned toolchains are entirely
   unexercised.
2. **Default warnings posture differs.** `.bazelrc:117` sets
   `common --features=-treat_warnings_as_errors`. The repository *default* native
   build therefore does **not** enforce freedom from warnings; criterion 9
   (*verification_plan.rst*) requires 100 % freedom from compiler warnings/errors
   and would need an explicit warnings-as-errors feature. The focused GCC run used
   `-Werror`, but only for two production TUs, not the whole target graph.
3. **Coverage/scope gap.** Runtime registration coverage (`runtime_tests.cpp`: 33
   macros) is not compiled; the runtime regression
   `ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError`
   (`runtime_tests.cpp:402-431`) has never been executed in any retained artifact.
4. **Sanitizer gap.** The Bazel sanitizer checks (`native_sanitizers`,
   `native_tsan`) did not run. The focused ASan/LSan/UBSan binary is not the Bazel
   `--features=asan/lsan/ubsan_clang` path, and the focused TSan binary crashed in
   this environment (§8), so no concurrency verdict exists.
5. **Integration/performance/cross gaps.** QEMU integration, benchmarks/profiling,
   and x86_64/aarch64 cross builds did not run (missing `bazel`; QNX entitlement
   blocker for cross targets). A focused host-TU pass says nothing about them.
6. **Coverage goal gap.** Even the focused coverage is below the platform branch
   goal (§8.3).

**Conclusion:** the focused GCC green run is a necessary-but-insufficient
precondition. It **cannot be reported as full Bazel readiness, native test
success, or criterion-9 compliance.**

---

## 7. Toolchain and target identity register

Selected identities recorded by the retained artifacts (`tool_assurance`
`tool_inventory`; `collector_identity` in each obligation `result.json`):

| Role | Identity | SHA-256 | Available |
|------|----------|---------|-----------|
| Host C++ compiler (focused) | `/usr/bin/x86_64-linux-gnu-g++-12` | `88315fd2d961a1f4e4070b104d7bd4c7670df19d9949409879ba269466c196d3` | yes |
| Clang compiler | `/home/jefferson/.local/share/s-core-tools/llvm-19.1.7/usr/lib/llvm-19/bin/clang++` | `7969846391c1fe04f816c26bd7d6a09171e9330378c9ec8fd6c841dafec66faa` | yes |
| clang-tidy | `.../llvm-19/bin/clang-tidy` | `5f733fae7fdb5ac7122ea1e8fcfb4723a7cbf68b5d779f2f8ead6eb276c03f0c` | yes |
| CodeQL | `/home/jefferson/.local/share/s-core-tools/codeql-2.21.4/codeql/codeql` | `d38df35e9275fce177e76cc6d4b5fc031ba7e9be4e7d224d0be7d6b7d0a21cc1` | yes |
| CodeQL coding standards | `.../codeql-coding-standards-2.61.0/qlpack.yml` | `3d06c897dd580a60bd8435bab198e411e9556236a7ee11bb16ff78c853bebd03` | yes |
| MISRA suite | `.../codeql-suites/misra-cpp-default.qls` | `8b41feb7188bde80cbb9ad57c643db6e2f95e02bae347171479114dc60c3626e` | yes |
| gcov | `/usr/bin/gcov-12` | `dcaf103b28775592ac023067bf7af4c1f4e2e7605e8d4fd65600e0b0f7e2dbe4` | yes |
| gcovr | `/usr/bin/gcovr` | `59cd3edebe1a6e9a8df26b0ffc01906c444758c58411214ff0e466c8170cfbb0` | yes |
| cppcheck | `/usr/bin/cppcheck` | `d2268c85b26850db5f36f7a3a7a2ae0106377810f4f93988bf4ab636481b4d89` | yes |
| QEMU | `/usr/bin/qemu-system-x86_64` | `55862c768c21fa7d3e72ca1b24797d8ab5b406eb5ef4c9ab9c2280f4e0b8f330` | yes |
| perf | `/usr/bin/perf` | `2d0953085bf720a25efbe24f853e97d27b1f12f18a398255ff82cbafde254dad` | yes |
| **Bazel driver** | `/tmp/s-core-001/bin/bazel` (env `USE_BAZEL_VERSION=8.6.0`, `BAZELISK_HOME=…/bazelisk`) | `null` | **no** |
| clang-format | `/tmp/score-someip84-obligation-tools/bin/clang-format` | `null` | **no** |
| pre-commit | `/tmp/score-someip84-obligation-tools/bin/pre-commit` | `null` | **no** |
| reuse | `/tmp/score-someip84-obligation-tools/bin/reuse` | `null` | **no** |
| valgrind | `/tmp/score-someip84-obligation-tools/usr/bin/valgrind`, `/usr/bin/valgrind` | `null` | **no** |
| gitleaks | `/tmp/score-someip84-obligation-tools/bin/gitleaks` | `null` | **no** |

**Target/config identity attempted by the (unrun) native checks:** `//...`,
`//score/...`, `//tests/...`, `//:unit_tests`, `//:component_tests`, `//:docs`,
`//:traceability_gate -- --need-type=comp_req`, `//:clang-tidy.check`,
`//:ruff.check`, `//:format.check`, `//tests/benchmarks/...`, `//quality/...`,
`//tests/integration_test/...`; configs `qemu-integration`, `x86_64-linux`,
`aarch64-linux`, `perf-tests`, `perf-tests-flamegraphs`; coverage env
`COVERAGE_THRESHOLD=73`. **None of these executed.**

---

## 8. Other retained non-Bazel results (actual results, for completeness)

These are the only checks that genuinely executed; their scopes remain focused /
environment-limited.

1. **`compiler_diagnostics`** — GCC `gcc-compile` **exit 0**, `gcc-tests` **exit 0**;
   Clang `clang-compile` **exit 1** (a dependency error:
   `'get_temporary_buffer<testing::TestInfo *>' is deprecated
   [-Werror,-Wdeprecated-declarations]` in libstdc++ 12 instantiated from
   `.llm_tmp/googletest/googletest/src/gtest.cc:3068`). Artifact limit:
   *"Focused executable only; GCC 12.3 / Clang 19 differ from native toolchain
   pins."* **GCC candidate is clean in the focused TU; the Clang blocker is a
   dependency under `-Werror`, outside the six candidate paths.**
2. **`focused_asan_lsan`** — compile **exit 0**, tests **exit 0**; status
   `completed`; limit *"Focused identifier executable; full native runtime scope
   measured separately."* **Pass, focused single-TU scope only.**
3. **`focused_tsan`** — compile **exit 0**, tests **exit -11** (SIGSEGV);
   status `findings_or_execution_failure`. **Environment failure (TSan/ASLR
   mmapping incompatibility); not a source or data-race verdict.**
4. **`focused_cppcheck`** — **exit 2**; artifact limit *"Optional complementary
   checks; no inferred MISRA rule coverage."* The 19 `passedByValue`
   (`severity=performance`) findings are located in headers **outside** the six
   candidate paths (`score/socom/registry_string_view.hpp`,
   `score/socom/service_interface_identifier.hpp`). **Not an in-scope defect.**
5. **`focused_clang_tidy`** — `--verify-config` **exit 1**; blocker *"Native
   analyzer configuration incompatible; no replacement called MISRA."*
   **clang-tidy produced zero findings because it did not run** — "not run", not
   "clean".
6. **`focused_coverage`** — status `completed`; measured on the focused executable:
   `line_total 36`, `line_covered 36` (**100.0 %**), `branch_total 14`,
   `branch_covered 11` (**78.6 %**); `platform_goals {QM: 85, safety: 100}`;
   `safety_class: unknown_requires_authorized_selection`; `complete_target_scope:
   false`. **Line goal met; branch goal not met (78.6 % < 85 %/100 %); not full
   native coverage.**
7. **`focused_memcheck`** — compile **exit 0**, memcheck **exit 127**
   (`valgrind` missing); status `findings_or_execution_failure`. **No memcheck
   result.**
8. **`codeql_security`** — status `findings_or_execution_failure`, `blockers: []`,
   `scan_runs: 1`; every retained finding's `uri` is under `.llm_tmp/googletest/**`
   (dependency); `level: null` on every finding; limit *"Focused linked executable,
   not full target extraction; dependency findings retained."* **No finding in the
   six candidate paths.**
9. **`codeql_misra`** — status `findings_or_execution_failure`; blockers *"MISRA
   applicability/mapping draft and incomplete"*, *"Default suite omits manual/audit
   obligations"*, *"Compiled query qualification and human deviations pending"*;
   database-create/analyze **exit 0**; a large findings array (deferred to the
   dedicated MISRA reports) dominated by `.llm_tmp/googletest/**` and gtest
   `TEST_F` macro-expansion hits on `service_identifier_tests.cpp`; `level: null`
   throughout. **No authorized severity rating; no in-scope production finding.**
10. **`secret_dependency_checks`** and **`tool_assurance`** — see §4.2.
11. **`process_checks`** / **`rework_progress`** — see §4.3.

None of the above is a native Bazel result, and none removes the §4 blockers.

---

## 9. Obligation status (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Native build (`bazel build //...` / `//score/...`) | `AGENTS.md`; `development_plan.rst` | **NOT RUN** — `bazel` missing (exit 127) |
| Full native test execution (`bazel test //... --build_tests_only`) | `verification_plan.rst` (criteria 6-7) | **NOT RUN** — `bazel` missing; `full_native_tests: not_executed` |
| Freedom from compiler warnings & errors (criterion 9, 100 %) | `verification_plan.rst` | **PARTIAL** — focused GCC clean (exit 0)+85/85; Clang blocked on a dependency; default Bazel build disables warnings-as-errors (`.bazelrc:117`) |
| Static code analysis run (clang-tidy / CodeQL) | `code_analysis.rst` | **NOT SATISFIED** — clang-tidy not run (config blocker); CodeQL focused/dependency-only; cppcheck out of scope |
| SCA findings classified Critical/High/Medium/Low | `verification_process.rst` (`gd_req__verification_sca_classification`) | **NOT DONE** — no tool-suggested class; no QM+committer classification |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` *[draft]* | **UNKNOWN** — mapping draft, human deviations pending |
| Statement / branch coverage goals | `verification_plan.rst` (criteria 1-2) | **NOT MET** — focused 100 % line / 78.6 % branch; below safety goal; not full scope |
| Native sanitizer checks | `code_analysis.rst` | **NOT RUN** — Bazel sanitizer legs missing; focused ASan/LSan/UBSan pass is a narrow substitute |
| Native TSan / concurrency | `code_analysis.rst` | **NOT RUN** (Bazel) / focused TSan environment crash |
| Native integration / QEMU | `verification_process.rst` | **NOT RUN** — `bazel` missing though KVM+QEMU present |
| Native performance / profiling | `verification_plan.rst` | **NOT RUN** — `bazel` missing |
| Cross-compilation (x86_64 / aarch64) | `development_plan.rst` | **NOT RUN** — `bazel` missing; QNX entitlement blocker |
| Format / pre-commit / reuse / module lock | `.pre-commit-config.yaml`; `REUSE.toml` | **NOT RUN** — tools missing |
| Secret / dependency vulnerability scan | `tool_management.rst` | **NOT RUN** — `gitleaks` missing; inventory is not a scan |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED for this slice** — native driver + several tools unavailable |
| Traceability links (`gd_req__verification_link_tests_cpp`) | `verification_process.rst` | **PARTIAL** — `DerivationTechnique`/`Description` present; `TestType`/`Verifies` deliberately unset (no invented identifiers) |
| Independence of verification / review | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Obligation collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **RETAINED, NOT PASSING** |
| Native acceptance | `source-index.json` | **`not_inferred` for every entry** |

**Explicit non-satisfaction statement.** The missing native driver (`bazel`) and
supporting tools (`valgrind`, `gitleaks`, `pre-commit`, `reuse`, `clang-format`), the
non-running clang-tidy, the focused/dependency-heavy CodeQL extraction, the
below-goal focused branch coverage, the absence of any full native test run, the
unknown safety class, and the unanswered human reviews mean **none of the checked
obligations may be treated as satisfied**. A retained collection result shows
*retention*, not passing.

---

## 10. Measurement and validation status

- **Tools used:** `read_file`, `grep`, `glob`, `write_file` only. No `shell`,
  delegation, web, approval, publishing, or engineering acceptance.
- **Measurements executed this iteration:** none. All figures are readings of
  retained artifacts and of the working tree.
- **Genuine executed results available:** focused GCC/UBSan compile+tests
  (85/85 candidate, 28/85 baseline), focused ASan/LSan/UBSan (exit 0), focused
  Clang compile (dependency error), focused coverage (100 % line / 78.6 % branch),
  CodeQL security/MISRA (focused), cppcheck (exit 2, out of scope), git-init/add in
  the format collector.
- **Unavailable / not run:** every Bazel target and config; `valgrind`; `gitleaks`;
  `pre-commit`; `reuse`; `clang-format`; clang-tidy analysis; Bazel sanitizer/TSan;
  QEMU integration; performance/profiling; cross-compilation.
- **Scope:** local, unprotected, scoped. This is not acceptance, review,
  publication, or a full native run. The focused GCC run also predates the two
  newest key tests (85 measured vs 87 in the tree).
- **Reproduction path for a later, authorized iteration (not executed here):**

  ```bash
  bazel build //score/...
  bazel test //score/...
  bazel test //score/socom/test/unit:socom_test
  bazel test --features=asan --features=lsan --features=ubsan_clang //score/...
  bazel test --features=tsan //score/...
  bazel coverage //... --build_tests_only
  bazel test --config=qemu-integration //quality/... //tests/integration_test/...
  bazel build --config=x86_64-linux //score/... //tests/...
  bazel build --config=aarch64-linux //score/... //tests/...
  ```

  Expected on the corrected key: the minor-only key/runtime regressions pass; on a
  key that includes `minor`, they fail. These expectations are source-derived, not
  measured.

---

## 11. Notice preservation

- No source, build, test, config, `NOTICE`, `LICENSE`, `REUSE.toml`, validation, or
  prior-report file was created, edited, or deleted by this iteration; **only this
  report was written.**
- The header the task flagged (`score/socom/impl/service_identifier.hpp`) retains its
  Apache-2.0/SPDX comment (`:1-12`) and was left unchanged because it is already
  balanced (§2). `service_identifier.cpp` (`:1-12`), both BUILD files (`score/socom/BUILD:1-12`,
  `score/socom/test/unit/BUILD:1-12`), and both candidate test files retain their
  Apache-2.0/SPDX headers.
- All files under `.llm_tmp/overnight/reports/` and `.llm_tmp/overnight/prior-reports/`
  were preserved unchanged; this document is a new `reports/` entry.
- This report itself carries the Apache-2.0 header. No licensed MISRA rule text is
  reproduced; only native rule/query identifiers and file locations are cited.

---

## 12. Pending human review checklist

- [ ] **Confirm §2:** `service_identifier.hpp` is brace-balanced (brace lines
      `:19,:29,:32,:38`; line 39 blank; net balance 0); the recorded "extra closing
      brace at line 39" is stale or refers to a different revision. No source
      correction is required in this checkout. If a distinct "cancelled draft"
      revision still carries the brace, locate and correct it by an authorized
      iteration.
- [ ] **Resolve the instruction conflict:** "Inspect and correct the actual source"
      vs. "this is a review draft: only that report may be written"; confirm that
      writing only this report was intended, and that the no-op on already-correct
      source is acceptable.
- [ ] **Restore the native driver and supporting tools** (`bazel` at the pinned
      `USE_BAZEL_VERSION=8.6.0`, plus `valgrind`, `gitleaks`, `pre-commit`, `reuse`,
      `clang-format`) and re-run `native_build`, `native_tests`, the sanitizer/TSan
      legs, `native_coverage`, `native_docs`, `native_traceability`,
      `native_integration`, `native_performance`, `cross_compilation`, and
      `format_precommit`.
- [ ] **Run the full native suite** `bazel test //score/...` (not the focused TU),
      including `runtime_tests.cpp`, and record results; refresh the measurement so
      it covers the current 87-macro key suite rather than the 85-test artifact.
- [ ] **Enable a warnings-as-errors native build** (`.bazelrc:117` currently
      disables it) before claiming criterion-9 compliance.
- [ ] **Disposition the Clang dependency error** (`-Wdeprecated-declarations` in
      libstdc++/googletest) and repair/run clang-tidy (unfold the `.clang-tidy`
      `Checks: >` block) so an analysis verdict exists.
- [ ] **Complete the mandated SCA classification** (QM + committer per
      `gd_req__verification_sca_classification`); treat any suggested classes as
      review aids only.
- [ ] **Complete/activate the MISRA mapping** (`misra_mapping.rst` is a draft) or
      record applicability as unresolved.
- [ ] **Select the safety class**, schedule independent human review (approver ≠
      author per `gd_req__verification_independence`), and record engineering
      acceptance; no compliance claim may be made before that.
- [ ] **Keep the wider #84 public `Service_interface_identifier` restructure,
      FindService wildcard handling, and the config minor-wildcard narrowing out of
      this bounded slice** until separately accepted, and do not present the
      identifier-only tests as platform validation.

---

*End of review draft. Local, unprotected, scoped. No engineering acceptance; human
reviews unanswered; full native runtime tests pending. The focused GCC pass is not
full Bazel readiness; every native Bazel check is an unavailable-tool blocker, not a
pass; no finding was filtered and no authorized severity rating exists.*
