<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — narrowly scoped deviation / false-positive drafts
# (`deviation_drafts`) review draft

**Document type:** review draft (actual-source inspection + recording of the named GCC syntax
failure + narrowly scoped deviation/false-positive **proposals** bound to exact rule, finding and
source hash + rationale / alternatives / risk / compensating checks / review-and-expiry triggers +
obligations status)

**Date:** 2026-10-02
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version handling in
socom* (issue #84)
**Run:** branch `fabro/run/01M3YRJEGXNY6CB81T7TKW774B`
**Status:** local, unprotected, scoped. **No engineering acceptance exists. Human reviews are
unanswered. Full native runtime tests remain pending.** **No deviation or risk decision is made or
proposed as made here** — every entry below is a *draft for human disposition*. `authority.json`
records `engineering_acceptance: pending`, `human_reviews: unanswered`, `safety_class: unknown`, and
every `source-index.json` entry is `native_acceptance: not_inferred`.

> **Tool / write boundary actually observed.** Only `read_file`, `grep`, `glob`, and `write_file`
> were available and were the only tools used. No `shell`, no delegation, no web access, no approval,
> no publishing, and no engineering acceptance was performed. The task's explicit final sentence —
> *"This is a review draft: only that report may be written."* — is the operative write boundary and
> it resolves the task's other direction (*"Inspect and correct the actual source before expanding
> tests"*) in favour of **inspection only**. Accordingly **exactly one file was written: this
> report** (`/workspace/.llm_tmp/overnight/reports/deviation_drafts.md`). No source, build, test,
> config, `NOTICE`, `LICENSE`, `REUSE.toml`, or prior-report file was created, edited, or deleted.
> Every file under `.llm_tmp/overnight/prior-reports/` (12 files), every earlier file under
> `.llm_tmp/overnight/reports/` (19 files before this one), and every retained artifact under
> `.llm_tmp/overnight/validation/` and `.llm_tmp/overnight/obligations/` was preserved unchanged.
>
> **Non-satisfaction rule applied throughout.** A successful obligation-collection node means its
> results were **retained**, not that its checks **passed**. Missing tools, unknown applicability,
> incomplete extraction, an inactive rule mapping, a non-running analyzer, and unanswered human
> reviews are **not** treated as satisfied. A tool that produced **no** finding because it **did not
> run** is recorded as *"not run"*, never as *"clean"*.

---

## 0. Summary

1. **The recorded "extra closing brace" GCC syntax failure is not present in the actual source
   (§2).** `score/socom/impl/service_identifier.hpp` is 40 lines, brace-balanced: openers `:19`
   (`namespace score::socom {`) and `:29` (`struct Service_instance_identifier final {`); closers
   `:32` (`};`) and `:38` (`}  // namespace score::socom`); `:39` blank; `:40` `#endif`. Net balance
   `0`. The retained **focused GCC** compile of the candidate translation unit exits `0` with empty
   stderr and `gcc-tests` passes **87/87**. Removing a brace from the balanced header would *create*
   a syntax error. No correction was applied because none is required **and** the write boundary
   forbids a source write; the minimal historical repair is retained in §2.4 for reference. **FP-1**
   records the stale-defect disposition bound to the header hash.
2. **Every retained finding is either a dependency artifact, a gtest-macro-expansion artifact, a
   test-only or out-of-slice production construct, or an unavailable/inactive tool.** Nine
   narrowly-scoped dispositions are drafted in §3 (**DD-1 … DD-9**) plus the stale-defect record
   (**FP-1**). Each is bound to an exact rule id, an exact finding location, and a source sha256.
3. **Each disposition has a falsifier and a re-review trigger (§3.x).** None is a blanket
   suppression; retention in the artifacts is preserved, and none removes a finding from any tool
   output.
4. **No rule applicability is asserted.** `misra_mapping.rst` is `:status: draft` with a
   commented-out table and no CSV (`glob **/_assets/**` → none), so the only in-evidence rule
   identifiers are the licensed CodeQL coding-standards pack's own annotations. The mapping is
   *unmapped for every MISRA rule* until an authorized change activates it.
5. **No obligation is satisfied (§6).** No build, test, or tool ran in this iteration. The retained
   measurements are focused, partly stale (85 executed vs **87** current key macros; `runtime_tests.cpp`
   never compiled), and several checks exited `127`/non-zero. Human reviews are unanswered.

---

## 1. Binding, scope, and evidence read this iteration

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` — *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:2-4` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |

The issue body is a **design proposal, not an accepted obligation**; it is not binding. Binding is
**by baseline commit**, not by run HEAD.

### 1.2 The bounded slice and its source hashes

The duplicate-server registration key is
`Service_instance_identifier { Service_interface_identifier interface; Service_instance instance; }`
(`score/socom/impl/service_identifier.hpp:29-32`), whose single operator orders by
`(instance, service id, major)` with `minor` deliberately excluded
(`score/socom/impl/service_identifier.cpp:28-29`), matching the minor-ignoring `Service_database`
index (`score/socom/impl/runtime_impl.hpp:116-134`). The key is `impl/`-only and re-exposed to the
test package solely via the `testonly` target `//score:socom_impl_service_identifier`.

Hashes are the **tool-measured working-tree sha256** from the retained obligation artifacts
(`.llm_tmp/overnight/obligations/*/result.json` → `source_hashes`); the context snapshot value from
`.llm_tmp/context/candidate-files.json` is shown for drift awareness.

| Path | Tool-measured sha256 (source_hashes) | Context snapshot sha256 |
|------|--------------------------------------|-------------------------|
| `score/socom/impl/service_identifier.hpp` | `bdce3fcbc3cd78a8ecaece1ea36107d464011ab81c9bc39932d0be617befaea9` | `96b33a1fee4d54577ae9bc46c313409a0d59336f76df85ef1925ffebdd1a2119` |
| `score/socom/impl/service_identifier.cpp` | `3c12b3f1dd3f1fa66cdf43766f374d7d067637bf8f11aba604c4e2688351f11a` | `d766902e4bda5306095a6e5326ea91d28df3a6e1ef4e77dc9ba47556ed559a9a` |
| `score/socom/test/unit/service_identifier_tests.cpp` | `4df2c63c4c2ea1a816898d8c33c506add3235509d85edfc51c535ab2aa1587a4` | `45d073998108df76c8f4534508d65f02cead28aa568cd5c45b5a3d8a4fd36a25` |
| `score/socom/test/unit/runtime_tests.cpp` | `9a2d6a154683a2b7ff9d51b7241e4fb74c1a8ef483895830cb409a8f5a1d3127` | `5e35e24d0abcfa361b5a5283a005b307b86026a970464a3423be7c6eed66631e` |
| `score/socom/BUILD` | `68f4645a21e495fac43929fb125f7ba0b9e29fc84c0401fdb95238ffb7fd2cc8` | `dee826163ac5e6336d51a293136b424696c2884aa1b2592395e1e06423c0ba44` |
| `score/socom/test/unit/BUILD` | `e909151e822370bebe8d59b86369bddeb4d6cacfa02f10061bf6e134671ff9d4` | `9b3c5b341211e2c387858fd1fe5c669a6a422b6e8b5e80fce35ba22c61186799` |
| `score/socom/impl/string_registry.cpp` (out of slice) | `f486e72a96429fea4b06f505b96b4fa00aa831a6834959169e409200e8ee8fbb` | — |
| `score/socom/string_registry.hpp` (out of slice) | `909ca6a47b1e7bb76bc05f3f05144ee6c80350fe4643df61d5efe4ef5f38693f` | — |
| `score/socom/registry_string_view.hpp` (out of slice) | `6640b529ea626c50944e1afe6240f84ac02551901c5a12ca846ea1ba37f18647` | — |
| `score/socom/service_interface_identifier.hpp` (public) | `b3c1f1a61fe91d8b6adb3a02dd745eb6c60fec0bfb78f581571fc6a88b972782` | — |

`glob **/service_identifier.hpp` returns exactly one path, so there is no second, differently-braced
copy of the header in this checkout.

### 1.3 Retained artifacts read this iteration

| Artifact | Key content used here |
|----------|-----------------------|
| `.llm_tmp/overnight/obligations/compiler_diagnostics/{gcc-compile.stderr,gcc-tests.json,clang-compile.stderr}` | GCC compile exit 0 (empty stderr); `gcc-tests` **87 tests / 0 failures**; Clang exit 1 (dependency deprecation) |
| `.llm_tmp/overnight/obligations/codeql_misra/result.json` | 218 queries loaded; `level: null` on every finding; exact MISRA rule/query ids and locations; `blockers` at `:235-239` |
| `.llm_tmp/overnight/obligations/codeql_security/result.json` | 32 findings, all `uri` under `.llm_tmp/googletest/**`; **no** `"uri": "score/…"` match |
| `.llm_tmp/overnight/obligations/focused_cppcheck/cppcheck.stderr` | cppcheck 2.7 XML: 19 × `passedByValue` (`severity=performance`, `cwe=398`) |
| `.llm_tmp/overnight/obligations/focused_clang_tidy/native-config.stderr` | 15 `unknown check` warnings; `--verify-config` exit 1 |
| `.llm_tmp/overnight/validation/measurement.json`, `after.json` | candidate 85/0/compile 0; `full_native_tests: not_executed`; `changed_paths` = key tests only |
| `.llm_tmp/overnight/obligations/process_checks/result.json` | metadata: key tests **87** macros, `runtime_tests.cpp` **33** macros; `completed_with_blockers` |
| `.llm_tmp/overnight/obligations/rework_progress/result.json` | `source_changed_this_round: true`, `rework_requested: false`, *"One complete pass requested; unresolved findings stay pending"* |
| `.llm_tmp/overnight/prior-reports/` (12) and `.llm_tmp/overnight/reports/` (19 before this) | prior reasoning preserved and re-used; not modified |

### 1.4 Pinned obligation sources and authority

All nine `.llm_tmp/context/obligations/source-index.json` entries are present and were read with
`authority.json`. Each is `native_acceptance: not_inferred`. `misra_mapping` is `:status: draft`
(table commented out, CSV absent) and `inspection_checklist` is `:status: draft` (blank), so
**no MISRA rule applicability and no inspection conclusion is asserted here**.

---

## 2. The recorded GCC syntax failure — inspection of the actual source

### 2.1 Finding (direct `read_file` + `grep`, this iteration)

`score/socom/impl/service_identifier.hpp` is **brace-balanced**. `grep '[{}]'` returns exactly four
brace-bearing lines:

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers, two closers, net balance `0`. `grep 'namespace'` returns only `:19` and `:38` (the
nested form, not a split `namespace socom` / `namespace score` pair). The sibling
`impl/service_identifier.cpp` uses the same nested form and is balanced (`:18`, `:20`, `:30`, `:32`).

### 2.2 Independent tool corroboration (retained artifacts)

- `compiler_diagnostics/gcc-compile.stderr` is empty; the `gcc-compile` command records
  `"exit_code": 0`. A surviving unmatched closing brace would make the compile fail.
- `compiler_diagnostics/gcc-tests.json` records **87 tests, 0 failures, 0 errors** for
  `ServiceInstanceIdentifierTest`.
- The only non-zero compiler result in the run is **Clang** `-Wdeprecated-declarations` in
  `libstdc++-12`/vendored googletest, outside the six candidate paths (§3, DD-8).

### 2.3 Why the recorded defect is not the file in this checkout

The tool-measured header hash is `bdce3fcb…` while the context snapshot recorded `96b33a1f…`; the
file therefore evolved between the snapshot and the tool runs. The tool-measured revision is the
balanced one and the working-tree read is balanced as well. The recorded defect matches the earliest
prior reports' split-form double close (`}  // namespace socom` + `}  // namespace score`), which the
earlier `reproducer` iteration corrected, leaving line 39 blank.

### 2.4 Minimal historical repair (reference only; NOT applied)

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

Applying this to the already-balanced, already-nested file would be a no-op at best and a
compilation break at worst. **No source write was made** — both because there is no defect to
correct and because the write boundary forbids it.

---

## 3. Draft dispositions register

All entries are **proposals only**. "Type" distinguishes a **tool/dependency false positive**
(no authored code violates a rule) from a **requested deviation** (authored/out-of-slice code does
implicate a rule and an authorized exception or in-source justification is requested). **No class
(Critical/High/Medium/Low) is assigned**: `gd_req__verification_sca_classification` requires the
Quality Manager together with a committer, and `authority.json` records that decision as pending.
Every status is **DRAFT — NOT ACCEPTED**.

### 3.1 Register at a glance

| Id | Type (proposed) | Tool / rule | Exact finding (representative) | Bound source hash | Status |
|----|-----------------|-------------|--------------------------------|-------------------|--------|
| DD-1 | False positive (macro artifact); deviation alternative | CodeQL MISRA **6.5.1** `cpp/misra/external-linkage-not-declared-in-header-file-misra` | `service_identifier_tests.cpp:2012` col 8-88 (+ every `TEST_F` line) | `4df2c63c…` | DRAFT / pending |
| DD-2 | False positive (macro artifact) | CodeQL MISRA **9.3.1** `cpp/misra/switch-body-compound-condition` | `service_identifier_tests.cpp` macro-expanded lines (e.g. `:531`, `:560`, `:636`, `:640`, `:672-673`) | `4df2c63c…` | DRAFT / pending |
| DD-3a | False positive (macro artifact) | CodeQL MISRA **7.0.1** `cpp/misra/no-conversion-from-bool` | `service_identifier_tests.cpp` (block starting `result.json:74643`) | `4df2c63c…` | DRAFT / pending |
| DD-3b | Deviation requested (out of slice) | CodeQL MISRA **7.0.1** `no-conversion-from-bool` | `string_registry.cpp:28,42,45,59,62` | `f486e72a…` | DRAFT / pending |
| DD-4 | Deviation requested (out of slice) | CodeQL MISRA **21.6.1** `dynamic-memory-should-not-be-used` | `string_registry.hpp:37` col 7-8 | `909ca6a4…` | DRAFT / pending |
| DD-5 | Deviation requested (out of slice) | CodeQL MISRA **6.7.1** `local-variable-static-storage-duration` | `string_registry.cpp:71` col 28-36 and `:66` col 28-36 | `f486e72a…` | DRAFT / pending |
| DD-6 | False positive (RAII side effect) / deviation | CodeQL MISRA **0.1.1** `unnecessary-write-to-local-object` | `string_registry.cpp:35` col 46-54 and `:23` col 46-54 | `f486e72a…` | DRAFT / pending |
| DD-7 | Deviation requested (performance style, out of slice) | Cppcheck `passedByValue` (`performance`, CWE 398) | `registry_string_view.hpp:127,134,141,148,155,162,173`; `service_interface_identifier.hpp:37,41,48,99,105,113` | `6640b529…`, `b3c1f1a6…` | DRAFT / pending |
| DD-8 | False positive (dependency/toolchain) | Clang `-Wdeprecated-declarations` under `-Werror` | `libstdc++-12 …/bits/stl_tempbuf.h:263` via `gtest.cc:3068` | (dependency; not candidate source) | DRAFT / pending |
| DD-9 | False positive (dependency) | CodeQL security, 32 findings | all `.llm_tmp/googletest/**`; none under `score/` | (dependency; not candidate source) | DRAFT / pending |
| FP-1 | **Not reproducible / stale defect** | "GCC syntax failure — extra `}` at `service_identifier.hpp:39`" | header brace census + GCC exit 0 | `bdce3fcb…` | DRAFT / pending |

---

### DD-1 — MISRA 6.5.1 external-linkage finding on the gtest `TEST_F` expansion

- **Type (proposed):** false positive as to the *authored* test body, with a deviation alternative
  (the synthesised entities genuinely exist, so if the tool has no macro-aware mode a formal
  deviation may be the only honest disposition).
- **Exact rule:** MISRA C++:2023 rule **6.5.1**, CodeQL query
  `cpp/misra/external-linkage-not-declared-in-header-file-misra` (level `null`).
- **Exact finding:** the top-level finding at `obligations/codeql_misra/result.json:348-364`
  (`uri: score/socom/test/unit/service_identifier_tests.cpp`, `startLine 2012`, `startColumn 8`,
  `endColumn 88`), repeated for essentially every `TEST_F` line (e.g. `:1982`, `:1929`, `:1882`,
  `:1851`, `:1818`, `:1777`, `:1754`, `:1728`, `:1702`, `:1680`, `:1656`, `:1641`, `:1625`, `:1590`,
  `:1564`, `:1531`, `:1488`, …).
- **Bound source hash:** `service_identifier_tests.cpp` =
  `4df2c63c4c2ea1a816898d8c33c506add3235509d85edfc51c535ab2aa1587a4`.
- **Rationale:** the flagged locations are the `TEST_F` macro-expansion lines; the externally-linked
  registration entities are synthesized by the googletest framework macro, not authored in the test
  body, and cannot be declared in a header without patching the framework. The candidate source file
  itself declares no external-linkage symbol in the authored region.
- **Alternatives:** (a) macro-aware CodeQL query / gtest-aware suppression; (b) `TEST`-style or
  anonymous-namespace wrapping (not possible without breaking gtest registration); (c) a formal,
  time-boxed deviation for the test-only macro artifact; (d) leave as-is, unaccepted.
- **Risk if accepted as-is:** a real external-linkage violation introduced *outside* the macro in
  the same file would be masked if the disposition is applied file-wide rather than macro-scoped.
- **Compensating checks:** keep the finding retained and counted; restrict the disposition to
  macro-expanded `TEST_F` lines only; manual review of any non-macro symbol added to the test file;
  re-run a **full-target** extraction (not the focused executable) before closure.
- **Review / expiry triggers:** (i) the test file hash changes; (ii) a macro-aware tool is adopted;
  (iii) `misra_mapping.rst` becomes `valid` and maps 6.5.1 to a tool; (iv) the safety class is
  selected; (v) 12 months from any approval.

### DD-2 — MISRA 9.3.1 switch-body finding on the gtest macro expansion

- **Type (proposed):** false positive as to the authored body (macro/defaulted-body artifact).
- **Exact rule:** MISRA C++:2023 rule **9.3.1**, CodeQL query
  `cpp/misra/switch-body-compound-condition` (level `null`).
- **Exact finding:** occurrences on `service_identifier_tests.cpp` at the macro-expanded lines cited
  by the retained analysis (e.g. `:531`, `:560`, `:636`, `:640`, `:672-673`); the query also fires
  widely in `.llm_tmp/googletest/**` (e.g. `gtest/internal/gtest-port.h:1169`, `:1713-1714`).
- **Bound source hash:** `service_identifier_tests.cpp` = `4df2c63c…`.
- **Rationale:** the flagged regions are not authored `switch` statements; they are the
  framework-generated compound conditions inside the macro-expanded test body, as the prior
  `misra_applicability.md` §7.3 records. No authored construct in the file matches the rule.
- **Alternatives:** macro-aware tooling; formal deviation for the test-file macro artifact; manual
  confirmation that no authored `switch` with a compound body exists in the six paths.
- **Risk if accepted:** same masking risk as DD-1 — an authored compound-condition `switch` added
  later could be overlooked; mitigate by scoping to the current hash and re-checking on any change.
- **Compensating checks:** retain the count; `grep` the test file for authored `switch` (none);
  manual review on change; full-target re-extraction before closure.
- **Review / expiry triggers:** as DD-1 (hash change, macro-aware tooling, activated mapping,
  safety-class selection, time-box expiry).

### DD-3a — MISRA 7.0.1 no-conversion-from-bool on the gtest test file

- **Type (proposed):** false positive (macro artifact).
- **Exact rule:** MISRA C++:2023 rule **7.0.1**, CodeQL query `cpp/misra/no-conversion-from-bool`
  (level `null`).
- **Exact finding:** occurrences on `service_identifier_tests.cpp` (top-level block beginning at
  `obligations/codeql_misra/result.json:74643`); the query also fires broadly in
  `.llm_tmp/googletest/**` (e.g. `gtest-assertion-result.cc:54`).
- **Bound source hash:** `service_identifier_tests.cpp` = `4df2c63c…`.
- **Rationale:** the test body does not perform a bool-to-non-bool conversion; the query matches
  framework assertion machinery expanded from `EXPECT_*`/`ASSERT_*` inside the macro body.
- **Alternatives:** macro-aware tooling; deviation for the macro artifact; manual confirmation.
- **Risk if accepted:** masking an authored bool conversion added later; scope to the exact hash.
- **Compensating checks / triggers:** as DD-1.

### DD-3b — MISRA 7.0.1 no-conversion-from-bool in `string_registry.cpp` (out of slice)

- **Type (proposed):** deviation requested (repository production code, outside the six writable
  candidate paths).
- **Exact rule:** MISRA C++:2023 rule **7.0.1**, query `cpp/misra/no-conversion-from-bool`.
- **Exact finding:** `score/socom/impl/string_registry.cpp` at `startLine 28` (col 68-74), `:42`
  (col 72-78), `:45` (col 79-84), `:59` (col 72-78), `:62` (col 79-84) — the `bool` second element of
  the returned `std::pair<Registry_string_view, bool>` insert results.
- **Bound source hash:** `string_registry.cpp` = `f486e72a96429fea4b06f505b96b4fa00aa831a6834959169e409200e8ee8fbb`.
- **Rationale:** the `bool` is a returned "newly inserted" flag in a deliberate `std::pair` API
  (`string_registry.hpp:46-72` documents it). If the rule is read as prohibiting the pattern, a
  formal deviation or an in-source justification per `code_analysis.rst:51` is required; **none
  exists today**, and adding one is outside this review's write boundary.
- **Alternatives:** refactor the return type (API change across callers, out of slice);
  in-source justification citing `code_analysis.rst:51`; formal deviation with time box.
- **Risk if accepted:** normalizes a bool-encoding pattern the coding guideline may intend to
  forbid; could weaken the `Result`-based error model if extended further.
- **Compensating checks:** confirm the flag is consumed (it is used by callers/tests); keep the
  finding retained; ensure no new bool-encoded *error* paths are introduced; verify callers.
- **Review / expiry triggers:** `string_registry.cpp`/`.hpp` hash change; activated MISRA mapping;
  `misra_manual_review`/inspection checklist completion; safety-class selection; time-box expiry.

### DD-4 — MISRA 21.6.1 dynamic memory in `string_registry.hpp` (out of slice)

- **Type (proposed):** deviation requested (repository production code, outside the six paths).
- **Exact rule:** MISRA C++:2023 rule **21.6.1**, query `cpp/misra/dynamic-memory-should-not-be-used`.
- **Exact finding:** `score/socom/string_registry.hpp` `startLine 37`, col 7-8 (the
  `class String_registry final`); the query also fires in the test file and in
  `.llm_tmp/googletest/**`.
- **Bound source hash:** `string_registry.hpp` = `909ca6a47b1e7bb76bc05f3f05144ee6c80350fe4643df61d5efe4ef5f38693f`.
- **Rationale:** the class deliberately owns a `std::unordered_set<std::string_view>` and a
  `std::forward_list<std::string>` to intern strings and keep node addresses stable
  (`string_registry.hpp:74-77`). The dynamic allocation is a design property of the registry, not an
  authored defect introduced by this slice.
- **Alternatives:** replace with a fixed-capacity arena/`std::array` pool (substantial redesign);
  in-source justification; formal deviation.
- **Risk if accepted:** normalizes dynamic allocation in an ASIL-relevant component; the chosen
  alternative may affect the lifetime contract that the registration key's non-owning views rely on.
- **Compensating checks:** ASan/LSan/UBSan focused run passed (87/87); TSan and memcheck not
  available/failed; review the registry lifetime contract (`registry_string_view.hpp:25-30`);
  confirm no allocation failure path is left unchecked.
- **Review / expiry triggers:** any change to registry storage; activated mapping; selection of a
  safety class that forbids dynamic memory; time-box expiry.

### DD-5 — MISRA 6.7.1 function-local static storage duration (out of slice)

- **Type (proposed):** deviation requested (repository production code, outside the six paths).
- **Exact rule:** MISRA C++:2023 rule **6.7.1**, query `cpp/misra/local-variable-static-storage-duration`.
- **Exact finding:** `score/socom/impl/string_registry.cpp` `startLine 71` col 28-36 and `:66`
  col 28-36 (the two `static String_registry registry;` singletons in
  `service_id_registry()`/`instance_id_registry()`).
- **Bound source hash:** `string_registry.cpp` = `f486e72a…`.
- **Rationale:** function-local statics give the process-wide registries a stable, lazily-initialized
  lifetime that avoids the static-initialization-order fiasco; the append-only design depends on that
  lifetime. Deliberate design, outside the slice.
- **Alternatives:** Meyers-singleton-compatible redesign; explicit ownership in `Runtime`; in-source
  justification; formal deviation.
- **Risk if accepted:** residual static-destruction-order hazard for any view outliving the registry
  (recorded as MF-8 in `misra_manual_review.md`); not newly introduced here.
- **Compensating checks:** lifetime review (`lifetime_review.md`); confirm all keys die before the
  registries; `focused_asan_lsan` pass; add an ordered-shutdown regression before closure.
- **Review / expiry triggers:** lifetime contract change; activated mapping; safety-class selection;
  time-box expiry.

### DD-6 — MISRA 0.1.1 unnecessary write to local object (out of slice)

- **Type (proposed):** false positive in effect (the "write" is an RAII side effect) with a
  deviation alternative.
- **Exact rule:** MISRA C++:2023 rule **0.1.1**, query `cpp/misra/unnecessary-write-to-local-object`.
- **Exact finding:** `score/socom/impl/string_registry.cpp` `startLine 35` col 46-54 and `:23`
  col 46-54 (the `std::lock_guard<std::mutex> const locked{m_mutex};` locals); the query also fires
  in `.llm_tmp/googletest/**` (`gtest.cc:2376`).
- **Bound source hash:** `string_registry.cpp` = `f486e72a…`.
- **Rationale:** the local's value is never read because its *purpose* is the constructor/destructor
  side effect (lock/unlock); the object is not dead code. This is the classic RAII false positive.
- **Alternatives:** none that preserve RAII; if the tool cannot be configured, a formal deviation;
  `[[maybe_unused]]`/`std::ignore` do not change the query result.
- **Risk if accepted:** none material for this pattern; the guard is required for the concurrency
  contract.
- **Compensating checks:** `grep` confirms both guards lock the same mutex used by all registry
  accessors; concurrency review (`concurrency_review.md`); TSan not available (recorded, not clean).
- **Review / expiry triggers:** tool version change; activated mapping; source change; time-box
  expiry.

### DD-7 — Cppcheck `passedByValue` on view/value parameters (out of slice)

- **Type (proposed):** deviation requested (performance style; no MISRA rule; out-of-scope headers).
- **Exact rule/finding:** cppcheck id `passedByValue`, `severity="performance"`, `cwe="398"`
  (`obligations/focused_cppcheck/cppcheck.stderr`), 19 findings:
  - `score/socom/registry_string_view.hpp` `:127` (lhs col 48, rhs col 74), `:134` (48/74),
    `:141` (47/73), `:148` (48/74), `:155` (47/73), `:162` (48/74), `:173` (v col 72) — 13 findings;
  - `score/socom/service_interface_identifier.hpp` `:37` (col 34), `:41` (48), `:48` (39), `:99` (37),
    `:105` (51), `:113` (51) — 6 findings (`new_id`).
- **Bound source hashes:** `registry_string_view.hpp` = `6640b529…`;
  `service_interface_identifier.hpp` = `b3c1f1a6…`.
- **Rationale:** the flagged types are small, cheap-to-copy view/value wrappers; passing by value is
  intentional and consistent with the codebase style. Cppcheck's performance suggestion is not a
  MISRA rule and has no S-CORE mapping; the run is a complementary check with the recorded limit
  *"no inferred MISRA rule coverage"*.
- **Alternatives:** change to `const&` (API churn in out-of-slice public headers, potential ABI
  concern); adopt a cppcheck baseline/suppression file; formal deviation.
- **Risk if accepted:** a small size/perf regression if a parameter type later becomes expensive to
  copy; the by-value copies are also part of the current public signatures.
- **Compensating checks:** `static_assert(sizeof(...))` bounds if accepted; benchmark before/after any
  change; retain the findings.
- **Review / expiry triggers:** parameter type size change; public-API refactor; CI adopts cppcheck;
  time-box expiry.

### DD-8 — Clang `-Wdeprecated-declarations` dependency error

- **Type (proposed):** false positive as to the candidate source — dependency/toolchain.
- **Exact finding:** `obligations/compiler_diagnostics/clang-compile.stderr:4` —
  `/usr/lib/gcc/x86_64-linux-gnu/12/../../../../include/c++/12/bits/stl_tempbuf.h:263:8: error:
  'get_temporary_buffer<testing::TestInfo *>' is deprecated
  [-Werror,-Wdeprecated-declarations]`, instantiated from `.llm_tmp/googletest/googletest/src/gtest.cc:3068`
  via `std::stable_sort`; `clang-compile` exit 1.
- **Bound source:** libstdc++-12 + vendored googletest (not among the candidate source hashes).
- **Rationale:** the failing code is neither in the six candidate paths nor authored here; the native
  toolchain pins may or may not raise it. It is a build-blocker under `-Werror`, not a candidate
  source defect.
- **Alternatives:** suppress `-Wdeprecated-declarations` for the vendored gtest TU only; update
  googletest/libstdc++; keep vendored gtest out of the warnings-as-errors target; record a dependent
  deviation.
- **Risk if accepted:** a real deprecation elsewhere in the same TU could be masked if suppression is
  too broad.
- **Compensating checks:** GCC focused TU is clean; scope suppression to the gtest TU; keep the
  Clang leg recorded as blocked until dispositioned.
- **Review / expiry triggers:** toolchain pin change; googletest update; warnings-as-errors policy
  change; time-box expiry.

### DD-9 — CodeQL security findings (all dependency)

- **Type (proposed):** false positive as to the deliverable — dependency.
- **Exact findings:** `obligations/codeql_security/result.json` retains 32 findings with rule ids
  `cpp/fixme-comment` (1), `cpp/commented-out-code` (7), `cpp/large-parameter` (1),
  `cpp/equality-on-floats` (2), `cpp/unused-static-function` (2), `cpp/unused-static-variable` (1),
  `cpp/rule-of-two` (1), `cpp/include-non-header` (9), `cpp/trivial-switch` (2),
  `cpp/loop-variable-changed` (2), `cpp/path-injection` (4). A `grep` for `"uri": "score/`
  in the security result returns **no match**; every finding's `uri` is under `.llm_tmp/googletest/**`.
  `level` is `null` on all.
- **Bound source:** vendored googletest (dependency; not candidate source).
- **Rationale:** the findings concern third-party test-framework code linked into the focused
  extraction; the retained artifact's own limit is *"Focused linked executable, not full target
  extraction; dependency findings retained"*. They do not implicate the deliverable.
- **Alternatives:** exclude `.llm_tmp/**`/vendored deps from the *deliverable* register while
  retaining them in the raw artifact (proposed); full-target extraction.
- **Risk if accepted:** a genuine security finding in project code could be missed if the
  dependency-only scope is misapplied; mitigate by asserting the `uri` predicate.
- **Compensating checks:** assert every finding `uri` starts with `.llm_tmp/`; re-run full-target
  before closure; keep counts.
- **Review / expiry triggers:** any finding with a `score/**` uri; extraction scope change; time-box
  expiry.

### FP-1 — Recorded GCC syntax failure is not reproducible (stale defect)

- **Type:** not-reproducible / stale-defect record (not a deviation).
- **Claim:** "measured GCC syntax failure: an extra closing brace in
  `score/socom/impl/service_identifier.hpp` at line 39".
- **Bound source hash:** `service_identifier.hpp` =
  `bdce3fcbc3cd78a8ecaece1ea36107d464011ab81c9bc39932d0be617befaea9`.
- **Evidence:** §2 brace census (four brace lines `:19,:29,:32,:38`; `:39` blank); retained
  `gcc-compile` exit 0 with empty stderr; retained `gcc-tests` **87/87**; the only non-zero compiler
  result is the Clang dependency error (DD-8).
- **Proposed disposition:** close as not reproducible for the hash above; retain the minimal repair
  (§2.4) for the event the imbalance reappears. If a distinct "cancelled draft" revision still
  carries the extra brace, it is not the file measured here and must be located and corrected by an
  authorized iteration.
- **Risk:** if a different revision with the defect is later merged, this record would not apply —
  hence the hash binding and the re-check trigger.
- **Compensating checks:** re-inspect the brace census whenever the header hash changes; the native
  GCC build must compile the header before any closure.
- **Review / expiry triggers:** header hash change; a fresh, checksum-bound GCC failure report;
  time-box expiry.

---

## 4. Items deliberately NOT proposed as deviations

- **Activating `misra_mapping.rst`** or **suppressing CodeQL queries**: not a deviation; it is an
  authorized process/tooling change and is out of the write boundary. The mapping is currently
  `:status: draft` with no CSV, so no rule is mapped in-repo.
- **Repairing the `.clang-tidy` configuration** (the `Checks: >` block folding `#` comments into
  check names; 15 unknown-check warnings; `clang-tidy` did **not run**): not a deviation and not a
  false positive — a tooling false-negative risk. It requires an authorized component change before
  clang-tidy can speak to this slice.
- **The `duplicate_service` doc-comment narrowing (MF-3)** and **the comparator not declared
  `noexcept` (MF-2)** from `misra_manual_review.md`: advisory, source-level review items, not
  tool-rule deviations. They require an authorized source change; the write boundary forbids it here.
- **The wider issue #84 restructure** (public `Service_identifier = id + major`, minor as an instance
  property, FindService wildcard, config `0xFFFFFFFF` narrowing): unaccepted design questions; not
  in scope and not a deviation.

---

## 5. What is explicitly *not* claimed

- No MISRA C++:2023 compliance, no rule applicability, and no authorized Critical/High/Medium/Low
  classification is claimed. The rule numbers cited above are the **licensed CodeQL pack's own
  annotations**, not an S-CORE mapping decision.
- Identifier-only tests are **not** platform validation; no fuzzy technique is claimed (no harness,
  no measurement); no native requirement identifiers are invented.
- The focused measurements are **scoped and stale**: the retained host capture executed **85** key
  tests and never compiled `runtime_tests.cpp` (33 macros) or any Bazel target, while the current
  test file carries **87** macros. A retained green marker is therefore not evidence for the full
  slice.

---

## 6. Obligations status (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| MISRA C++:2023 rule→tool mapping | `misra_mapping.rst`; `code_analysis.rst` | **DRAFT / INACTIVE** — no CSV, table commented out |
| Static code analysis executed, findings classified | `code_analysis.rst`; `verification_process.rst` (`gd_req__verification_sca_classification`) | **PARTIAL / NOT DONE** — CodeQL focused+incomplete; clang-tidy not run; no authorized class |
| Freedom from SCA critical/high (criterion 8) | `verification_plan.rst` | **NOT MEASURED** — no authorized classification |
| Freedom from compiler warnings & errors (criterion 9, 100 %) | `verification_plan.rst` | **PARTIAL / NOT SATISFIED** — focused GCC clean (87/87); Clang blocked by a dependency; no full targeted warnings-as-errors build |
| Unit/component testing executed, results recorded | `verification_plan.rst`; `verification_guideline.rst` | **PARTIAL, STALE** — 85 executed vs 87 on disk; `runtime_tests.cpp` never compiled |
| Sanitizers / concurrency | `code_analysis.rst` | **PARTIAL / BLOCKED** — ASan/LSan/UBSan focused pass; TSan environment failure; valgrind unavailable |
| Manual/audit MISRA + inspection checklist | `inspection_checklist.rst` | **NOT DONE** — draft, blank template |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** for this slice |
| Independence of verification / review | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Deviation / risk acceptance | `authority.json` | **NONE** — every entry in §3 is a draft |
| Native acceptance | `source-index.json` | **`not_inferred` for every entry** |

**Explicit non-satisfaction statement.** Missing tools (`bazel`, `valgrind`, `gitleaks`,
`pre-commit`, `reuse`, `clang-format`), the non-running clang-tidy, the focused/incomplete CodeQL
extraction, the draft/inactive MISRA mapping, the stale and runtime-excluding measurement, and the
unanswered human reviews mean **none of the checked obligations may be treated as satisfied**. A
retained collection result proves *retention*, not passing.

---

## 7. Notice preservation

- No source, build, test, config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was created, edited, or
  deleted by this iteration; **only this report was written**.
- `score/socom/impl/service_identifier.hpp` retains its Apache-2.0/SPDX header (`:1-12`) and was left
  unchanged because it is already balanced (§2); the sibling `.cpp`, both `BUILD` files, and both
  candidate test files retain their Apache-2.0/SPDX headers.
- All 12 files under `.llm_tmp/overnight/prior-reports/`, all 19 earlier files under
  `.llm_tmp/overnight/reports/`, and all files under `.llm_tmp/overnight/validation/` and
  `.llm_tmp/overnight/obligations/` were preserved unchanged.
- This report carries the Apache-2.0 header. No licensed MISRA rule text is reproduced; only rule
  identifiers, tool query ids, source hashes, and locations are cited.

---

## 8. Pending human review checklist

- [ ] **Confirm FP-1**: the recorded "extra `}` at line 39" is not present for header hash
      `bdce3fcb…`; confirm the minimal repair is unnecessary and, if a distinct cancelled-draft
      revision still carries the brace, locate and correct it by an authorized iteration.
- [ ] **Decide the instruction conflict**: "correct the actual source" vs "only that report may be
      written"; confirm that inspection-only was intended (no `edit_file` tool was available and the
      source required no correction).
- [ ] **Adjudicate DD-1 / DD-2 / DD-3a / DD-6** as false positives vs formal deviations, scoped to
      the exact hashes and locations above — not file-wide suppressions.
- [ ] **Adjudicate DD-3b / DD-4 / DD-5 / DD-7** (out-of-slice production constructs) via formal
      deviation **or** an in-source justification per `code_analysis.rst:51` **or** a refactor; none
      is accepted today.
- [ ] **Disposition DD-8 and DD-9** (dependency/toolchain findings) so they do not inflate the
      deliverable's finding set; scope precisely and record the toolchain decision.
- [ ] **Complete and activate the MISRA mapping** (`misra_mapping.rst`) and **repair the `.clang-tidy`
      configuration** so clang-tidy can run; then re-run a full-target CodeQL extraction including
      `runtime_tests.cpp`.
- [ ] **Complete the mandated SCA classification** (`gd_req__verification_sca_classification`) by the
      Quality Manager together with a committer.
- [ ] **Refresh the measurement**: run `bazel test //score/socom/test/unit:socom_test` (and broader
      `//score/...`) so `runtime_tests.cpp` and all 87 key cases are compiled and executed.
- [ ] **Select the safety class**, schedule independent human review (approver ≠ author), and record
      engineering acceptance; no deviation is valid before that.
- [ ] **Set and enforce review/expiry triggers** per §3; re-open any disposition whose bound hash
      changes.

---

*End of review draft. Local, unprotected, scoped. No engineering acceptance; human reviews
unanswered; full native runtime tests pending. No deviation or risk decision is made or proposed as
made here. No MISRA C++:2023 compliance is claimed and no rule applicability is asserted.*
