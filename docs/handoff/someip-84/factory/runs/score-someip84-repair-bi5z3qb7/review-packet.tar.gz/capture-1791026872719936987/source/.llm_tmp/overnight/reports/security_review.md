<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — security review of the bounded duplicate-server registration-key slice

**Document type:** review draft (measured public CodeQL security-and-quality results +
CodeQL MISRA applicability + dependency and secret-scanning applicability +
vulnerability-disposition register + changed-API exposure + extraction/licensing limits +
obligations status)

**Date:** 2026-10-03
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version
handling in socom* (issue #84)
**Run / branch:** `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ` (run environment)
**Verified baseline commit:** `f8a196c3b16d5172d898394ab99b0ed81346d63d`
(`.llm_tmp/context/source-manifest.json:3`)
**Status:** **local, unprotected, scoped.** No engineering acceptance exists. Human reviews
are unanswered. Full native runtime tests remain pending. **No security risk is accepted. No
report was uploaded.** Every statement below is either a direct static reading of this
checkout at the baseline-bound candidate paths, a direct reading of a *retained* artifact
under `.llm_tmp/overnight/`, or an explicitly-labelled logical consequence. Nothing here is
acceptance, review approval, publication, or a full native run.

> **Tool / write boundary observed.** This iteration used only `read_file`, `grep`, `glob`,
> and `write_file`. No `shell`, no delegation, no web access, no approval, no publishing, no
> upload, and no engineering acceptance was performed. The task's explicit, controlling final
> sentence — *"This is a review draft: only that report may be written."* — resolves the
> task's other direction ("Inspect and correct the actual source before expanding tests") in
> favour of **inspection only**. Accordingly **exactly one file was written: this report**
> (`/workspace/.llm_tmp/overnight/reports/security_review.md`). No source, build, test,
> config, `NOTICE`, `LICENSE`, `REUSE.toml`, or prior-report file was created, edited, or
> deleted.
>
> **The recorded GCC syntax failure is not present in the actual source (re-verified this
> iteration).** The task records *"a measured GCC syntax failure: an extra closing brace in
> `score/socom/impl/service_identifier.hpp` at line 39."* Direct `read_file` on the working
> tree (§2) shows the header is **brace-balanced**: openers at `:19`
> (`namespace score::socom {`) and `:29` (`struct Service_instance_identifier final {`);
> closers at `:32` (`};`) and `:38` (`}  // namespace score::socom`); line `:39` is **blank**;
> `:40` is `#endif`. Two openers, two closers, net balance `0`. There is no third, unmatched
> closing brace, so there is no actual source to correct; applying the recorded repair would
> be a no-op at best and a regression at worst. **No source write was made and none is
> required.**
>
> **Non-satisfaction rule applied throughout.** A successful obligation-collection node means
> the results were **retained**, not that the checks **passed**. Missing tools, unknown
> applicability, incomplete extraction, an inactive/draft rule mapping, and unanswered human
> reviews are **not** treated as satisfied. A tool that produced **no** finding because it
> **did not run** is recorded as *"not run"*, never as *"clean"*. A retained secret/dependency
> artifact is *not* evidence that no secret or vulnerability exists.

---

## 0. Summary

1. **The changed code introduces no new security-relevant exposure at the source level.**
   The bounded change is a single out-of-line comparator body,
   `operator<(Service_instance_identifier const&, Service_instance_identifier const&)`
   (`score/socom/impl/service_identifier.cpp:20-30`), whose identity is
   `(instance, service id, major)`; `minor` is deliberately excluded. It adds no new input
   path, no memory management, no parsing, no privilege boundary, no public symbol, and no
   header/wire surface (§3, §8). It is an `impl/`-only type re-exported solely through the
   `testonly` library `//score/socom:impl_service_identifier`.
2. **The measured public CodeQL security-and-quality run is dependency-only and focused.**
   CodeQL **2.21.4** with suite
   `codeql/cpp-queries@1.4.1:codeql-suites/cpp-security-and-quality.qls` completed
   `database create` and `analyze` with exit `0` (181 compiled queries); `scan_runs: 1`;
   status `findings_or_execution_failure`. It retained **32 findings, every one with a `uri`
   under `.llm_tmp/googletest/**`** (the vendored GoogleTest dependency), and **none in any of
   the six candidate paths, in `score/socom/**`, or anywhere in project code** (§4). Every
   finding carries `"level": null` — **no** Critical/High/Medium/Low suggestion.
3. **The extraction is focused and incomplete, so "no project finding" is not a clean bill.**
   The run's own limit is *"Focused linked executable, not full target extraction;
   dependency findings retained"* (`codeql_security/result.json:1756-1758`). The real attack
   surface (`score/gatewayd`, `score/gateway_ipc_binding` shared memory, `score/someipd`,
   config parsing, `runtime_tests.cpp`) was **not extracted**, so it can carry neither a
   finding nor a clean result (§4.4, §10).
4. **The CodeQL MISRA (coding-standards) run is likewise focused, and — unlike the security
   run — it does retain findings in the candidate test file.** `codeql_misra/result.json`
   records `status: findings_or_execution_failure`, suite
   `misra-cpp-default.qls` (CodeQL coding-standards **2.61.0**), and its own blockers
   *"MISRA applicability/mapping draft and incomplete"*, *"Default suite omits manual/audit
   obligations"*, *"Compiled query qualification and human deviations pending"*
   (`:1052-1056`). Findings land in (a) dependency `.llm_tmp/googletest/**`, (b) the candidate
   test file `score/socom/test/unit/service_identifier_tests.cpp` (dominated by the gtest
   `TEST_F` macro-expansion artifact `cpp/misra/external-linkage-not-declared-in-header-file-misra`),
   and (c) other repository production files outside the six candidate paths
   (`string_registry.cpp`/`string_registry.hpp`). The in-repo `misra_mapping.rst` is
   `:status: draft` with no active CSV, so **no rule applicability is established** (§5).
5. **Secret scanning DID run this time and reported 92 leaks; the finding set is almost
   entirely an artifact self-scan.** `secret_dependency_checks` invoked
   `gitleaks dir <source> --redact=100 --report-format=json`, exit `1`, `leaks found: 92`
   (`gitleaks.stderr`). **91** findings are `generic-api-key` on SHA-256 hash-map strings
   inside the collector's *own* `.llm_tmp/overnight/obligations/*/result.json` artifacts
   (self-scan contamination of the scanned source tree), and **1** finding is `private-key`
   at `quality/integration_testing/environments/qnx8_qemu/init_x86_64.build` (fingerprint
   line 410). **No secret finding is in any of the six candidate paths or in
   `score/socom/**`.** The private key is a real, pre-existing repository finding whose
   contents are **not reproduced** here; it is retained as an **open, undispositioned** item,
   not accepted (§6.1).
6. **The dependency inventory is not a vulnerability scan.** 29 direct Bazel-Module
   dependencies were enumerated with versions (`lock_sha256: c90b245b…`), and the collector
   records the decisive blocker *"No adopted vulnerability database/ecosystem mapping or
   GitHub dependency scan receipt; dependency inventory is not a vulnerability scan"*
   (`:1052-1053`). No CVE/GHSA/OSV mapping or SBOM-scanner receipt exists, so **no dependency
   vulnerability can be confirmed or cleared** (§6.2).
7. **No vulnerability can be dispositioned.** Per `gd_req__verification_sca_classification`
   (`verification_process.rst:228-248`) findings must be Critical/High/Medium/Low either by a
   tool suggestion or manually by the Quality Manager together with a committer. No tool
   supplied a class (CodeQL `level` is `null` on every finding) and no QM+committer
   classification exists (`authority.json`: `engineering_acceptance: pending`,
   `human_reviews: unanswered`). The register in §7 is **indicative only** and authorizes
   nothing. **No risk is accepted here.**
8. **The changed-API exposure is a behaviour change at a public virtual method, not an ABI or
   wire change.** `Runtime::make_server_connector` now returns
   `Construction_error::duplicate_service` earlier for a minor-only collision; the public
   identifier, its layout/operators/`std::hash`, and the IPC wire struct are unchanged, and no
   new external symbol family is added. A documentation/contract wording gap and a
   wildcard/`minor`-collapse interaction are recorded for human disposition, not fixed (§8).
9. **No obligation is satisfied.** Every `source-index.json` entry is
   `native_acceptance: not_inferred`; many retained checks are blocked or failed; the CodeQL
   extraction is focused; the MISRA mapping and inspection checklist are `:status: draft`;
   secret scanning found repository material; and human reviews are unanswered (§10).
10. **Extraction and licensing limits are preserved.** CodeQL licensing scope is *"Public
    Apache-2.0 eclipse-score/inc_someip_gateway only"* and `codeql_scope` is *"no upload"*;
    **no report, SARIF, database, or artifact was uploaded** and none will be (§9).

---

## 1. Binding, scope, and evidence read this iteration

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` — *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:2-4` |
| State | `open`, **0 comments**, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG`, created/updated `2026-04-14T13:23:24Z` | `.llm_tmp/context/issue-snapshot.json:8,19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**: service-instance identifier = `service id + major + minor + instance id`;
service identifier = `service id + major`; FindService = `service id + major +
optional<minor> + optional<instance>`; and the proposal to exclude `minor` from identity and
make it an instance property. There is **no comment and no acceptance record**, so none of it
is binding. Binding is **by baseline commit**, not by run HEAD.

### 1.2 Baseline and the six writable candidate paths

| Item | Value | Source |
|------|-------|--------|
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |
| Branch | `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ` | run environment |

The six candidate paths (`.llm_tmp/context/candidate-files.json:1-25`), the only source paths
writable in the broader task, are:

1. `score/socom/BUILD`
2. `score/socom/impl/service_identifier.cpp`
3. `score/socom/impl/service_identifier.hpp`
4. `score/socom/test/unit/BUILD`
5. `score/socom/test/unit/runtime_tests.cpp`
6. `score/socom/test/unit/service_identifier_tests.cpp` (baseline blob `null` — a **new** file)

`glob **/service_identifier*` returns exactly three paths
(`impl/service_identifier.cpp`, `impl/service_identifier.hpp`,
`test/unit/service_identifier_tests.cpp`), so there is **no second, differently-braced copy**
of the header in this checkout. The `null` baseline blob for `service_identifier_tests.cpp`
is the manifest's expectation of a **new** unit-test file; it exists on disk only in the
un-merged working tree (the task's *"cancelled draft"*), never in the baseline.

### 1.3 Changed code under review

```cpp
// score/socom/impl/service_identifier.cpp:20-30
bool operator<(Service_instance_identifier const& lhs, Service_instance_identifier const& rhs) {
    // The minor version is deliberately excluded from the registration key. ...
    return std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major) <
           std::tie(rhs.instance, rhs.interface.id, rhs.interface.version.major);
}
```

The key type is `Service_instance_identifier{ Service_interface_identifier interface;
Service_instance instance; }` (`impl/service_identifier.hpp:29-32`), an `impl/`-only type
whose only operator is this `operator<` (declaration at `:35`, hidden with `\cond`), with no
`operator==` and no `std::hash`. `std::set` uniqueness is `!(a<b) && !(b<a)`, so identity is
exactly `(instance, service id, major)` and `minor` is excluded.

### 1.4 Artifacts and prior reports read this iteration

- `.llm_tmp/context/obligations/` — all nine pinned sources plus `authority.json` and
  `source-index.json`.
- `.llm_tmp/overnight/obligations/` — in particular `codeql_security/{result.json,
  analyze.stderr}`, `codeql_misra/result.json`, `secret_dependency_checks/{result.json,
  secret-findings.json,gitleaks.stderr,gitleaks.stdout}`, `tool_assurance/result.json`,
  `compiler_diagnostics/*`, `focused_*/*`, `native_*`, `process_checks/result.json`.
- `.llm_tmp/overnight/validation/` — `check-result` (`0`), `measurement.json` (`:2039-2059`),
  `before.json`, `after.json`, the `*-compile.*` / `*-test.*` captures.
- `.llm_tmp/overnight/reports/` — read and preserved: `scope.md`, `api_review.md`,
  `key_fix.md`, `tool_findings_repair.md`, `finding_classification.md`, and the remainder by
  cross-reference. `.llm_tmp/overnight/prior-reports/` (38 files, including its own
  `security_review.md` from an earlier run) was preserved unchanged.
- Source read directly: `score/socom/impl/service_identifier.{hpp,cpp}`,
  `quality/integration_testing/environments/qnx8_qemu/init_x86_64.build` (secret location
  characterised, contents not reproduced).

Per the task rule, a successful collection node means results were **retained**, not that
checks **passed**.

### 1.5 Latest host validation feedback (present, scoped, unprotected)

- `validation/check-result` = `0` (**collector/retention marker only**).
- `validation/measurement.json` (`:2039-2059`): `check_ref: check_conversion_tests`,
  `mode: ubsan`, `changed_paths: ["score/socom/test/unit/service_identifier_tests.cpp"]`,
  `origin: local_unprotected_measurement`, `initiator: Fabro host hook`,
  `engineering_acceptance: pending`, `full_native_tests: not_executed`, compiler
  `/usr/bin/x86_64-linux-gnu-g++-12` (`sha256 88315fd2…`);
  `baseline_with_agent_tests` = **91 tests / 33 failures / compile exit 0 / test exit 1**,
  `candidate` = **91 tests / 0 failures / compile exit 0 / test exit 0**.
- The host capture compiles **only the focused identifier translation unit**
  (`service_identifier.cpp` + `string_registry.cpp` + `service_identifier_tests.cpp` plus
  vendored googletest). It does **not** compile `runtime_tests.cpp`, the IPC binding, the
  gateways, or any Bazel target, and `full_native_tests: not_executed`.

### 1.6 Pinned obligation sources and authority (all read this iteration)

Every entry of `.llm_tmp/context/obligations/source-index.json` is pinned
`"native_acceptance": "not_inferred"` — pinned, but its applicability to this slice is **not
inferred**. Relevant to this review:

| id | Pinned source | Status note |
|----|---------------|-------------|
| `coding_guidelines` | `coding_guidelines.rst` | `:status: valid`; MISRA C++:2023 with C++17 |
| `code_analysis` | `code_analysis.rst` | `:status: valid`; clang-tidy + gcc/clang warnings + Coverity; ASan/LSan/TSan/UBSan/Memcheck |
| `misra_mapping` | `misra_mapping.rst` | **`:status: draft`**; rule table commented out; no active CSV |
| `verification_plan` | `verification_plan.rst` | `:status: valid`; criterion 8 = freedom from SCA critical/high; criterion 9 = freedom from compiler warnings/errors |
| `verification_process` | `verification_process.rst` | `:status: valid`; `gd_req__verification_sca_classification` (`:228-248`), `_independence`, `_external_aou` |
| `tool_management` | `tool_management.rst` | `:status: valid`; tools identified/evaluated/qualified by a human |
| `inspection_checklist` | `inspection_checklist.rst` | **`:status: draft`**; blank IMPL template |

**Authority record** (`.llm_tmp/context/obligations/authority.json`):
`codeql_scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload"`;
`engineering_acceptance: pending`; `human_reviews: unanswered`; `safety_class: unknown`;
instruction *"Restart the failed queue for one complete pass through all obligations"*.

**Safety-class note (recorded, not resolved).** The pinned platform documents carry
`:safety: ASIL_B`, while `authority.json` records `safety_class: unknown` and no authorized
selection exists. The document attribute is **not** a selection of the slice's safety class
and must not be inferred as one. Criterion 8/9 acceptance thresholds (QM vs. safety) therefore
remain unselectable here.

---

## 2. The recorded syntax failure: inspection of the actual source

`score/socom/impl/service_identifier.hpp` read from the working tree is **brace-balanced**
and exactly 40 lines:

| Line | Content | Role |
|------|---------|------|
| 14 | `#ifndef SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard begin |
| 17 | `#include "score/socom/service_interface_identifier.hpp"` | include |
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 21–28 | doc comment | states `minor` is intentionally not part of the identity |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 30–31 | `Service_interface_identifier interface;` / `Service_instance instance;` | members |
| 32 | `};` | closes the struct |
| 34–36 | `/// \cond` / `bool operator<(…)` / `/// \endcond` | the single operator declaration |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`) and two closers (`:32`, `:38`) give a net brace balance of `0`.
There is **no third, unmatched closing brace**, and line `:39` contains no text. The sibling
`score/socom/impl/service_identifier.cpp` uses the same nested form and is balanced.

**Corroboration from the retained artifacts.** `compiler_diagnostics/result.json` records the
focused **GCC** `gcc-compile` and `gcc-tests` exit `0` and the focused **Clang**
`clang-compile` and `clang-tests` exit `0`, each with empty stderr and `blockers: []`; the
retained host validation adds candidate `compile_exit 0`. A surviving unmatched brace in a
header compiled into those translation units would have failed them.

**Disposition.** The described *"extra closing brace at line 39"* matches the **earliest**
prior reports' split-form close (`}  // namespace socom` + `}  // namespace score`), which the
`reproducer` iteration corrected; every later prior report — and the actual checkout - records
the header as balanced. Applying the historical repair to the already-balanced file would be
a no-op at best; deleting a brace would *create* the reported defect. **No correction was
applied, none is required, and the review-draft write boundary would have forbidden a source
write in any case.** This is a static brace-balance reading + retained-compile reading, **not**
a compile run by this iteration.

---

## 3. Security posture of the changed code (source reading)

| Aspect | Reading | Security consequence |
|--------|---------|----------------------|
| Input surface | none new — the comparator consumes two already-constructed value objects | no new attack input |
| Memory management | none — `std::tie` over value members; no allocation, no pointer/lifetime | no memory-safety exposure introduced |
| Type/parse/conversion | none new inside the comparator | no parsing or narrowing added here |
| Privilege/IPC/wire | unchanged — key is `impl/`-only; IPC struct untouched (§8) | no privilege-boundary or wire change |
| Concurrency | comparator is a pure, stateless `const` operation; the key set is guarded by its existing mutex (`impl/runtime_impl.hpp:56`) | no new data race |
| Failure direction | collisions are rejected earlier with `Construction_error::duplicate_service` instead of reaching a single-server `ASSERT(!m_server)` (`impl/runtime_impl.cpp:369`) | fail-safe / robustness improvement, not a weakening |

The net source-level effect on the security posture is neutral-to-positive: the change closes
a gap between the duplicate gate and the minor-ignoring `Service_database` index and adds no
externally reachable capability. This is a **source reading**; no dynamic security test ran
(§4.4, §11).

---

## 4. Measured public CodeQL security-and-quality results

### 4.1 Run identity and outcome

| Field | Value | Source |
|-------|-------|--------|
| Tool | CodeQL **2.21.4** | `codeql_security/result.json` commands |
| Suite | `codeql/cpp-queries@1.4.1:codeql-suites/cpp-security-and-quality.qls` | `result.json` `analyze` argv |
| Queries loaded | **181** | `codeql_security/analyze.stderr:1-…` |
| `database create` | exit **0**, `--language=cpp`, `--threads=1`, `--ram=6000` | `result.json` commands |
| `analyze` | exit **0**, SARIF | `result.json` commands |
| `scan_runs` | 1 | `result.json:1755` |
| Status | `findings_or_execution_failure` | `result.json:1113` |
| Licensing | *"Public Apache-2.0 eclipse-score/inc_someip_gateway only"* | `result.json:1115-1118` |
| Limit | *"Focused linked executable, not full target extraction; dependency findings retained"* | `result.json:1756-1758` |

### 4.2 The 32 retained findings — all dependency, none in candidate or project code

Every finding's `uri` is under `.llm_tmp/googletest/**` (`codeql_security/result.json`
findings array, `:1119-1754`). **No finding lands in any of the six candidate paths, in
`score/socom/**`, or anywhere in project code** (a `grep` for `"uri": "score/` returns
nothing). `level` is `null` on every finding. Counts by native rule id:

| Native rule id | Count | Scope (all dependency) |
|----------------|-------|------------------------|
| `cpp/fixme-comment` | 1 | googletest header |
| `cpp/commented-out-code` | 7 | googletest headers/sources |
| `cpp/large-parameter` | 1 | googletest header |
| `cpp/equality-on-floats` | 2 | `gtest-printers.h` |
| `cpp/unused-static-function` | 2 | `gtest.cc` |
| `cpp/unused-static-variable` | 1 | `gtest-death-test-internal.h` |
| `cpp/rule-of-two` | 1 | `gtest-port.h` |
| `cpp/include-non-header` | 9 | `gtest-all.cc` |
| `cpp/trivial-switch` | 2 | `gtest.cc` |
| `cpp/loop-variable-changed` | 2 | `gtest.cc` |
| `cpp/path-injection` | 4 | `gtest.cc` (`:5174`, `:5928`, `:6198`, `:6851`) |
| **Total** | **32** | **all under `.llm_tmp/googletest/**`** |

### 4.3 The only security-class rule (`cpp/path-injection`) is not in project code

The four `cpp/path-injection` findings are in the **vendored test-framework dependency**
(`.llm_tmp/googletest/googletest/src/gtest.cc`), reached because the focused executable links
googletest. No `cpp/path-injection` (or any other CWE-class) finding is in `score/socom/**`,
`score/gatewayd/**`, `score/gateway_ipc_binding/**`, or `score/someipd/**`. **This does not
clear project code** — those units were not extracted. It is not an accepted risk; it is a
retained dependency finding awaiting human disposition (§7, §12).

### 4.4 What this CodeQL security run does *not* cover

- The database was built from a **focused linked executable** (the identifier translation unit
  plus `string_registry` plus googletest), **not** the full target set. The IPC shared-memory
  layer, the gateway daemons, the SOME/IP stack, the config loader, and `runtime_tests.cpp`
  were **not extracted**.
- The CWE queries loaded by the suite produced **no** finding in project code largely because
  project code was largely absent from the database — not because it was proven safe.
- No dependency-vulnerability mapping, no SBOM scanner, and no provenance/qualification of
  the CodeQL pack are available (`tool_assurance/result.json`; §6.3).

**Conclusion for §4.** The public CodeQL security result is a genuine, measured,
dependency-only result with no in-scope project finding and no severity classification. Per
the non-satisfaction rule it is **retained, not passing**, and it must not be presented as a
clean security assessment of the candidate change or of the module.

---

## 5. Measured CodeQL MISRA (coding-standards) result and applicability

### 5.1 Run identity and outcome

| Field | Value | Source |
|-------|-------|--------|
| Tool / pack | CodeQL **2.21.4**; CodeQL coding-standards **2.61.0** | `codeql_misra/result.json` `analyze` argv |
| Suite | `…/codeql-coding-standards-2.61.0/codeql-suites/misra-cpp-default.qls` | `result.json:1094` |
| `database create` / `analyze` | exit **0** | `result.json` commands |
| Status | `findings_or_execution_failure` | `result.json:1117` |
| Blockers | *"MISRA applicability/mapping draft and incomplete"*, *"Default suite omits manual/audit obligations"*, *"Compiled query qualification and human deviations pending"* | `result.json:1052-1056` |
| Limit | *"Focused linked executable, not full target extraction; dependency findings retained"* | `result.json:121519-121521` |
| Licensing | *"Public Apache-2.0 eclipse-score/inc_someip_gateway only"* | `result.json:1119-1122` |

### 5.2 Findings buckets (measured locations)

- **Candidate test file** — `score/socom/test/unit/service_identifier_tests.cpp` carries many
  findings, dominated by
  `cpp/misra/external-linkage-not-declared-in-header-file-misra` at `TEST_F` lines (samples
  `:2181`, `:2150`, `:2103`, `:2060`, …; the same file has 91 `TEST_F` macros, verified by
  `grep`). This is the **`TEST_F` macro expansion**: gtest synthesises externally-linked
  registration entities whose declaration is not in a header. Other candidate-test rules seen
  in the file include `cpp/misra/switch-body-compound-condition`, `cpp/misra/no-conversion-from-bool`,
  against macro/defaulted-body artifacts.
- **Other repository production** (outside the six candidate paths) —
  `score/socom/impl/string_registry.cpp` / `score/socom/string_registry.hpp`
  (`local-variable-static-storage-duration`, `no-conversion-from-bool`,
  `unnecessary-write-to-local-object`, `dynamic-memory-should-not-be-used`).
- **Dependency** — `.llm_tmp/googletest/**`
  (`copy-and-move-assignments-shall-handle-self-assignment`, `global-variable-used`, and many
  others).
- **No finding** lands in `service_identifier.cpp`, `service_identifier.hpp`, or
  `runtime_tests.cpp` (the last because it was **not extracted**).

### 5.3 Applicability — unmapped and unresolved

`misra_mapping.rst` is `:status: draft` and its `csv-table` / `_assets/misra_2023.csv` are
inactive, so **no MISRA rule is mapped to any tool in-repo**. Consequently:

- The candidate-test findings **cannot be labelled as authored defects**; their only
  "fixes" would be suppressing the rule, editing the test framework, or an accepted human
  deviation — the first two are prohibited here and the third is unavailable. They remain
  **open, undispositioned findings**.
- The `string_registry` production findings are outside the bounded slice but inside the
  repository, and are retained.
- The default suite **omits manual/audit obligations**, and undecidable rules are not
  discharged automatically; the inspection checklist is a **draft, blank** template.
- The safety class is `unknown`, so the applicable acceptance level and the criterion-8
  thresholds are unselected.

**MISRA C++:2023 compliance for this slice is UNKNOWN and is NOT claimed.** No licensed MISRA
rule text is reproduced in this report; only native rule/query identifiers and locations are
cited.

---

## 6. Dependency and secret-scanning applicability

### 6.1 Secret scanning — ran; 92 leaks, one real repository finding

`secret_dependency_checks/result.json` records a single command,
`gitleaks dir <source> --redact=100 --report-format=json` over the run's source copy; the
command **exit code is `1`** (`result.json:1080`) and `gitleaks.stderr` reports
`leaks found: 92`. Status is `findings_or_execution_failure`. `secret-findings.json` (92
entries) divides as follows:

| # | Rule | Count | Location class | Reading |
|---|------|-------|----------------|---------|
| SEC-1 | `private-key` | **1** | `quality/integration_testing/environments/qnx8_qemu/init_x86_64.build` (fingerprint line `410`) | **Real repository finding.** An OpenSSH private key embedded in the QEMU target init build file. **Contents not reproduced here.** Pre-existing; outside the six candidate paths; **not** dispositioned or accepted. |
| SEC-2 | `generic-api-key` | **91** | `.llm_tmp/overnight/obligations/*/result.json` (the collector's own artifacts) | **Self-scan artifact.** The matches are SHA-256 hash-map *keys/values* (e.g. tool-file paths such as `…lackey-x86-linux`) in the retained result JSON, not credentials. Still retained as undispositioned. |

**Disposition.** Secret scanning is **APPLICABLE and now EXECUTED**, so this is no longer
*"not run"*; but the result **contains a repository secret finding and has not been
troughed/dispositioned**. It must **not** be recorded as *"no secrets"*. SEC-1 is a
**blocker** for a clean security statement and an **authorized human action item** (rotate/remove
the key, decide on history, or record an accepted deviation through the authorized process).
No secret value is copied into this report.

### 6.2 Dependency inventory — present, but not a vulnerability scan

The same artifact enumerates **29 direct Bazel-Module dependencies** with resolved versions
(`secret_dependency_checks/result.json:1085-1202`), including the security-relevant set:

| Dependency | Version |
|------------|---------|
| `googletest` | `1.18.0` |
| `google_benchmark` | `1.9.5` |
| `nlohmann_json` | `3.12.0.bcr.1` |
| `flatbuffers` | `25.12.19` |
| `score_baselibs` | `0.2.13` |
| `score_communication` | `0.3.0` |
| `toolchains_llvm` | `1.8.0` |
| `score_bazel_cpp_toolchains` | `1.0.3` |
| `rules_cc` | `0.2.22` |
| `rules_foreign_cc` | `0.15.1` |

…plus the remaining Bazel/Python/tooling modules. The lock digest is
`lock_sha256: c90b245bc0f8aadea595e2d3bc618325e064b371d88544bcb787b1afb28564b6`
(`:1203`). The collector's own blocker is decisive (`:1052-1053`):

> *"No adopted vulnerability database/ecosystem mapping or GitHub dependency scan receipt;
> dependency inventory is not a vulnerability scan"*

**Therefore:** the inventory establishes *what* is depended on, not whether any version is
vulnerable. There is no CVE/GHSA/OSV mapping, no `osv-scanner`/`grype`/Dependabot receipt, and
no SBOM vulnerability report. **No dependency vulnerability can be confirmed or cleared.**

### 6.3 Tool assurance relevant to security scanning

`tool_assurance/result.json` (`:1389`) is `completed_with_blockers`; its blockers include
*"Tool confidence evaluation, qualification where applicable, and acceptance require
authorized humans"*, *"Coverity not installed/adopted here; reconcile
guideline/development-plan discrepancy"*, and *"Memcheck is an optional complement, not a
universal process mandate"* (`:1052-1056`). Per `tool_management.rst`, tools must be
identified, evaluated and — where the confidence level is LOW — qualified and released by an
authorized human; **that has not happened**. Tool execution is not tool qualification.

---

## 7. Vulnerability disposition

### 7.1 The governing requirement and its status

`verification_process.rst:228-248` (`gd_req__verification_sca_classification`, `:status:
valid`) requires SCA findings to be classified **Critical / High / Medium / Low**, where *"the
actual classification shall be either provided by the tool as a suggestion or defined manually
by `rl__quality_manager` together with `rl__committer`."* `verification_plan.rst` criterion 8
requires freedom from critical/high static-analysis findings at 100 %.

- **Tool-suggested classes: none.** CodeQL security and MISRA `level` is `null` on every
  finding; cppcheck emits only `severity="performance"`; the compiler emitted no diagnostic
  this run; clang-tidy ran no analysis; sanitizers produced no finding.
- **Authorized classes: none.** No QM+committer classification exists anywhere in the
  retained artifacts; `authority.json` records `engineering_acceptance: pending`,
  `human_reviews: unanswered`, `safety_class: unknown`.

### 7.2 Vulnerability-disposition register (indicative only — authorizes nothing)

| # | Finding / topic | Tool / category | Native severity | Scope | Disposition status |
|---|-----------------|-----------------|-----------------|-------|--------------------|
| S-1 | 32 CodeQL security findings, 11 rule ids (§4.2) | CodeQL security & quality | `level: null` | googletest dependency | **Unclassified / pending** |
| S-2 | `cpp/path-injection` ×4 | CodeQL security | `level: null` | dependency (`gtest.cc`) | **Unclassified / pending** |
| M-1 | `external-linkage-not-declared-in-header-file-misra` (many) | CodeQL MISRA | `level: null` | candidate test file, `TEST_F` macro artifact | **Unclassified / pending; needs human deviation** |
| M-2 | `switch-body-compound-condition`, `no-conversion-from-bool` (candidate test) | CodeQL MISRA | `level: null` | candidate test file, macro artifact | **Unclassified / pending** |
| M-P | `string_registry.{cpp,hpp}` production rules (§5.2) | CodeQL MISRA | `level: null` | repository production, outside slice | **Unclassified / pending** |
| M-D | remaining `cpp/misra/*` dependency rule ids | CodeQL MISRA | `level: null` | googletest dependency | **Unclassified / pending** |
| SEC-1 | embedded `private-key` | gitleaks | tool default | `quality/integration_testing/environments/qnx8_qemu/init_x86_64.build` | **Open, undispositioned; not accepted** |
| SEC-2 | 91 `generic-api-key` (artifact hash-map self-scan) | gitleaks | tool default | `.llm_tmp/overnight/obligations/*/result.json` | **Retained; likely false positive; not accepted** |
| D-1 | 29-dependency inventory | dependency register | n/a | module-wide | **Not a vulnerability scan; no CVE mapping; pending** |
| T-1 | clang-tidy `--verify-config` exit 1 (config blocker) | clang-tidy | n/a | repository `.clang-tidy` | **Not run; pending** |

**Explicit statement.** There is **no authorized vulnerability disposition** for any item
above. Nothing is closed, waived, or accepted, and **this review does not accept any security
risk**. Until a Quality Manager and a committer complete
`gd_req__verification_sca_classification`, criterion 8 cannot be assessed.

---

## 8. Changed-API exposure

### 8.1 No public symbol, layout, or wire change

| Surface | Location | Public? | Changed by this slice? |
|---------|----------|---------|------------------------|
| `Service_instance_identifier` (registration key) | `impl/service_identifier.hpp:29-32` | **No** — `impl/`-only; re-exported only via `testonly` `//score/socom:impl_service_identifier` | comparator behaviour only |
| `operator<` for the key | decl `impl/service_identifier.hpp:35`; def `impl/service_identifier.cpp:20-30` | **No** | body only; same signature |
| `Service_interface_identifier` / `::Version{major, minor}` | `service_interface_identifier.hpp` | **Yes** | **unchanged**, still minor-aware `==`/`<`/`hash` |
| `Service_interface_definition` | `service_interface_definition.hpp` | **Yes** | **unchanged** |
| `Runtime` (incl. `make_server_connector`) | `runtime.hpp` | **Yes** | declaration unchanged; **duplicate-gate behaviour** changes |
| IPC wire `gateway_ipc_binding::Service` | `gateway_ipc_binding.hpp` | **Yes** (wire) | **unchanged** (still full minor-aware `Version`) |

No public header was added, removed, or edited; no signature, default argument, `noexcept`
specification, or `virtual` set changed; no new public type/alias/operator/specialisation was
introduced. The `impl/`-only key still has exactly one operator and no equality/hash, so **no
new external symbol family** is added. There is **no IPC/wire-protocol change** — a security
surface because the wire format is unchanged.

### 8.2 The observable behaviour change (public virtual method)

With the minor-excluding key, two `Runtime::make_server_connector` calls that share
`(instance, id, major)` but differ only in `minor` now collide in the key set and the second
returns `Construction_error::duplicate_service`, instead of both being constructed and the
second *enable* reaching `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)`
(`impl/runtime_impl.cpp:369`). This is a **contract change for callers of a public virtual
method** — strictly safer for the single-server precondition, but recorded, not accepted. The
assert semantics (terminate vs compiled-out) live in `score_baselibs` and are not determined
in this checkout.

### 8.3 Recorded contract/documentation gap

`Runtime::make_server_connector` documents duplicates as judged by *"the
configuration.interface and instance parameters"* (`runtime.hpp`), while
`Service_interface_identifier::operator==` includes `minor` but the registration key does not.
The doc wording is therefore imprecise for minor-only differences. This is a **public-header
documentation** change that this review could not apply (write boundary); it is recorded for
authorized follow-up.

### 8.4 Recorded wildcard/`minor`-collapse interaction

The SOME/IP config declares `service_version_minor: uint32 = 0xFFFFFFFF` (a wildcard) and it
is narrowed with unchecked `static_cast<std::uint16_t>(…)` at several conversion sites.
Because the registration key now ignores `minor`, a wildcard-narrowed `0xFFFF` server and a
concrete-minor server for the same `(instance, id, major)` now collide as duplicates, where
the reported baseline (minor included) kept them distinct. This is a
**representation/semantics question** for the owner of #84, not a defect this review may
decide; it is recorded and out of the bounded slice.

**Conclusion for §8.** The security-relevant API exposure is unchanged (no new symbol, no
layout change, no wire change); the only behavioural delta is an earlier, fail-safe duplicate
rejection at a public method, plus recorded follow-ups.

---

## 9. Extraction scope, licensing, and notice preservation

- **CodeQL scope/licensing limits preserved.** `authority.json` records
  `codeql_scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload"`, and both
  CodeQL artifacts record `licensing.scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway
  only"`. **No report, SARIF, database, or artifact was uploaded or published.**
- **Focused-extraction limit quoted verbatim and retained** for both runs:
  *"Focused linked executable, not full target extraction; dependency findings retained"*.
- **No licensed rule text reproduced.** Only public native CodeQL rule/query identifiers and
  file locations are cited; no proprietary MISRA rule statement is reproduced. No secret value
  is reproduced.
- **Only this report was written.** No source, build, test, config, `NOTICE`, `LICENSE`,
  `REUSE.toml`, or prior-report file was created, edited, or deleted. Every existing
  Apache-2.0/SPDX header is untouched, including the flagged
  `service_identifier.hpp:1-12` and its sibling `.cpp:1-12`.
- All files under `.llm_tmp/overnight/reports/` and `.llm_tmp/overnight/prior-reports/`
  (including the earlier `prior-reports/security_review.md`) were preserved unchanged; this
  document is a new `reports/` entry. This report itself carries the Apache-2.0 header.

---

## 10. Obligations status (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| SCA findings classified Critical/High/Medium/Low | `verification_process.rst:228-248` (`gd_req__verification_sca_classification`) | **NOT DONE** — no tool suggestion (`level: null`); no QM+committer classification |
| Freedom from SCA critical/high (criterion 8) | `verification_plan.rst` | **NOT MEASURED** — no authorized classification |
| Static code analysis executed (CodeQL / clang-tidy) | `code_analysis.rst` | **PARTIAL / NOT SATISFIED** — CodeQL security is focused + dependency-only; CodeQL MISRA focused with draft applicability; clang-tidy did not run |
| Vulnerability/dependency scanning | `code_analysis.rst`; `tool_management.rst` | **NOT PERFORMED** — inventory ≠ scan; no CVE mapping; no SBOM scanner receipt |
| Secret scanning | `tool_management.rst` | **EXECUTED, NOT SATISFIED** — gitleaks exit 1; SEC-1 real repository `private-key` undispositioned; SEC-2 artifact self-scan |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` (`:status: draft`) | **UNKNOWN — not applied/claimed** |
| Freedom from compiler warnings & errors (criterion 9) | `verification_plan.rst` | **PARTIAL, LOCAL** — focused GCC/Clang `-Werror` exit 0 in retained artifacts; not a native full-target run; the header is brace-balanced by inspection (§2) |
| Sanitizer / concurrency checks | `code_analysis.rst` | **PARTIAL / BLOCKED** — ASan/LSan/UBSan and memcheck focused pass; TSan environment failure |
| Unit/component testing executed, results recorded | `verification_plan.rst` | **PARTIAL, LOCAL** — focused 91/0 retained (baseline 91/33); `full_native_tests: not_executed`; `runtime_tests.cpp` never executed |
| Interface / requirements / resource / fault-injection test types | `verification_process.rst` | **NOT PERFORMED / applicability not inferred** |
| External-component AoUs verified | `verification_process.rst` (`gd_req__verification_external_aou`) | **NOT SATISFIED** — no integration/static verdict; no AoU register |
| Independence of verification / review | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Implementation inspection checklist IMPL_01…IMPL_03 | `inspection_checklist.rst` (`:status: draft`) | **NOT FILLED** |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** — `tool_assurance` `completed_with_blockers`; CodeQL packs unqualified |
| Obligation collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **RETAINED, NOT PASSING** |
| Native acceptance | `source-index.json` | **`not_inferred` for every entry** |

**Explicit non-satisfaction statement.** Missing tool qualification, the unknown safety class
and un-inferred applicability, the focused/dependency-only CodeQL extraction, the draft MISRA
mapping with unresolved candidate-test findings, the absent dependency-vulnerability mapping,
the executed-but-unsatisfied secret scan (a real repository `private-key` remains
undispositioned), and the unanswered human reviews mean **none of the checked obligations may
be treated as satisfied**. A successful collection node proves *retention*, not passing.

---

## 11. Measurement and validation status

- **Tools used:** `read_file`, `grep`, `glob`, `write_file` only. No `shell`, delegation, web,
  approval, publishing, upload, or engineering acceptance.
- **Measurements executed by this iteration:** **none.** No build, no test, no scan, no
  analysis. Every result above is a direct reading of a retained artifact or of the working
  tree.
- **Retained-run scope:** the CodeQL security and MISRA databases and the focused
  GCC/Clang compile + sanitizer runs cover the **focused identifier translation unit** (plus
  the vendored googletest); they do **not** cover `runtime_tests.cpp` or the full
  `socom_test` / `//score/...` targets. `full_native_tests: not_executed`
  (`validation/measurement.json:2042`).
- **Scope:** local, unprotected, scoped. This is a bounded security-review draft, not an
  accepted engineering decision and not full native validation.
- **Reproduction path for a later, authorized iteration (not executed here):**

  ```bash
  # full native build/test (all targets; runtime_tests.cpp was never executed)
  bazel test //score/socom/test/unit:socom_test
  bazel test //score/...
  # secret scan and dependency-vulnerability scan (rotate/remove SEC-1 first; adopt a CVE DB)
  gitleaks dir . --redact=100 --report-format=json
  # full-target CodeQL extraction (not the focused linked executable)
  codeql database create <db> --language=cpp --command='<full build>'
  codeql database analyze <db> codeql/cpp-queries:codeql-suites/cpp-security-and-quality.qls --format=sarif-latest
  codeql database analyze <db> <codeql-coding-standards>/codeql-suites/misra-cpp-default.qls --format=sarif-latest
  ```

  These are informational; none was run. Nothing may be reported as passing until an authorized
  iteration executes it and a QM+committer classifies the findings.

---

## 12. Pending human review checklist

- [ ] **Confirm §2:** `service_identifier.hpp` is brace-balanced (braces at `:19`, `:29`,
      `:32`, `:38`; line 39 blank); the recorded "extra closing brace at line 39" is stale and
      no source correction is required in this checkout. If a different "cancelled draft"
      revision still carries the brace, locate and correct it by an authorized iteration.
- [ ] **Resolve the instruction conflict:** correct-the-source vs. review-draft-only; confirm
      that writing only this report (inspection-only) was intended.
- [ ] **Complete the mandated classification** (`gd_req__verification_sca_classification`):
      have the Quality Manager together with a committer assign Critical/High/Medium/Low to the
      CodeQL security findings (S-1/S-2), the CodeQL MISRA findings (M-1/M-2/M-P/M-D), and the
      remaining items. Treat §7.2 as indicative only.
- [ ] **Disposition SEC-1 (repository `private-key`)** in
      `quality/integration_testing/environments/qnx8_qemu/init_x86_64.build` by an authorized
      process (remove/rotate, history decision, or recorded accepted deviation). Do not treat
      the secret scan as clean and do not copy the key material into reports.
- [ ] **Disposition SEC-2 (91 `generic-api-key`)** as artifact hash-map false positives (or
      re-scope the scan to exclude `.llm_tmp/overnight/obligations/**`), by an authorized
      process — not silently.
- [ ] **Adopt a dependency-vulnerability process:** an ecosystem mapping (OSV/CVE/GHSA) and/or
      a GitHub dependency-scan receipt or SBOM scanner over the 29-dependency lock
      (`lock_sha256 c90b245b…`); an inventory alone is not a vulnerability scan (§6.2).
- [ ] **Run a full-target CodeQL extraction** covering `runtime_tests.cpp` and the project
      units (gateways, IPC, SOME/IP, config) rather than the focused linked executable, and
      qualify the compiled queries (§4.4, §5).
- [ ] **Complete and activate the MISRA mapping** (`misra_mapping.rst`): supply the CSV,
      uncomment the table, and raise `:status` to `valid` by an authorized change; until then
      no rule applicability may be stated. Execute the manual/audit obligations and fill the
      draft inspection checklist.
- [ ] **Disposition the candidate-test MISRA findings (M-1/M-2)** as gtest `TEST_F` macro
      artifacts — record an accepted deviation or adopt macro-aware tooling; do not patch the
      test framework or silently suppress the rules.
- [ ] **Authorize the documentation correction** to `runtime.hpp` (state identity =
      `(instance, service id, major)`; `minor` is a compatibility property) — a public-header
      edit this review could not apply (§8.3).
- [ ] **Resolve the wildcard/`minor`-collapse interaction** (§8.4): the `uint32 0xFFFFFFFF`
      config wildcard narrowed to `0xFFFF` colliding with a concrete-minor server under the new
      key; adjudicate representation, validation and error semantics.
- [ ] **Confirm the bounded key decision:** `minor` is **not** part of the duplicate-server
      registration key; identity `(instance, service id, major)`. Keep the wider #84 public
      `Service_interface_identifier` restructure, FindService wildcard handling, and config
      minor-wildcard narrowing out of this bounded slice until separately accepted.
- [ ] **Run the full native suite** (`bazel test //score/socom/test/unit:socom_test` and the
      broader `//score/...` set), including `runtime_tests.cpp`, record results, and schedule
      independent human review (approver ≠ author, `gd_req__verification_independence`).
- [ ] **Select a safety class** via the authorized role; do not infer the slice's class from
      the `:safety: ASIL_B` attribute on the pinned platform documents (§1.6).
- [ ] **Do not upload** any report, SARIF, or database (licensing/`codeql_scope` forbids
      upload), and **do not accept** any security risk before the independent human gate.

---

*End of security-review draft. Local, unprotected, scoped. No engineering acceptance; human
reviews unanswered; full native runtime tests pending. No security risk is accepted. No report
was uploaded. The CodeQL security result is dependency-only and focused; the CodeQL MISRA
result is focused with unresolved candidate-test and production findings under a draft mapping;
the dependency inventory is not a vulnerability scan; secret scanning ran and retains a real
repository `private-key` finding; and no authorized finding classification exists.*
