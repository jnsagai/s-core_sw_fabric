<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — integration and Assumptions-of-Use (AoU) review (current checkout)

**Document type:** review draft — component/feature/platform integration review + interface-test
review + external-component Assumptions-of-Use review + QEMU result status + S-CORE reference
integration vs. final-product integrator separation + missing-requirement-link register +
obligations status.

**Date:** 2026-10-03
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling inside *Revise version handling in
socom* (issue #84)
**Run / branch:** `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ`; latest run commit per the run
environment `8c15414`
(`fabro(01M3ZRSDK2XQAF1H48VWTPKQNZ): node_1182f4d71399dfbab9f7dc6e (success)`). Earlier work of
this run referenced `b7d55bb`, `95fe5f9`, `8e1610e`, and `5722740`.
**Verified baseline commit:** `f8a196c3b16d5172d898394ab99b0ed81346d63d`
(`.llm_tmp/context/source-manifest.json:3`).
**Status: local, unprotected, scoped.** No engineering acceptance exists. Human reviews are
unanswered. The bounded slice has been built and its host unit/component tests executed under
retained host artifacts, but the target (QEMU) integration did **not** run, the traceability and
docs gates did not pass, external-component AoUs are not verified, and no requirement link exists.
Nothing in this document is acceptance, review approval, publication, or a full native run on the
reference target.

> **Tool / write boundary actually observed.** This iteration used only `read_file`, `grep`,
> `glob`, and `write_file`. No `shell`, no delegation, no web access, no approval, no publishing,
> and no engineering acceptance was performed. The task's explicit final sentence — *"This is a
> review draft: only that report may be written."* — is the operative write boundary, and it
> resolves the task's other direction ("Inspect and correct the actual source before expanding
> tests") in favour of **inspection only**. Accordingly **exactly one file was written: this
> report** (`/workspace/.llm_tmp/overnight/reports/integration_aou_review.md`). No source, build,
> test, config, `NOTICE`, `LICENSE`, `REUSE.toml`, host-validation, or prior-report file was
> created, edited, or deleted.
>
> **The recorded GCC syntax failure is not present in the actual source (re-verified).** The task
> records *"a measured GCC syntax failure: an extra closing brace in
> `score/socom/impl/service_identifier.hpp` at line 39."* Direct `read_file` + `grep` on the
> current working tree (§2) show the header is **brace-balanced**: openers at `:19`
> (`namespace score::socom {`) and `:29` (`struct Service_instance_identifier final {`); closers
> at `:32` (`};`) and `:38` (`}  // namespace score::socom`); line `:39` is **empty**; `:40` is
> `#endif`. Two openers, two closers, net balance `0`; a single `glob` for `**/service_identifier.hpp`
> returns one path. The retained host measurements also compile the whole candidate translation
> unit with `g++-12 -Werror` (exit `0`) and with `clang++-19 -Werror` (exit `0`) (§2). **No source
> write was made and none is required.** The conflict between "correct the actual source" and
> "only that report may be written" is recorded for human disposition (§2.3).
>
> **Non-satisfaction rule applied throughout.** A successful obligation-collection node means the
> results were **retained**, not that the checks **passed**. Missing tools, unknown applicability,
> incomplete extraction, non-running gates, and unanswered human reviews are **not** treated as
> satisfied. A check that produced **no** finding because it **did not run** is recorded as *"not
> run"*, never as *"clean"*.

---

## 0. Summary

1. **The bounded slice now builds and its host unit/component tests have been executed.** The
   retained `native_build` artifact records `bazel build //...` `exit_code 0`; `native_tests`
   records `bazel test //...` `exit_code 0` with the summary *"Executed 21 out of 29 tests: 21
   tests pass and 8 were skipped"*, including
   `//score/socom/test/unit:socom_test PASSED in 1.4s` (`native_tests/tests.stdout`). The eight
   skipped targets are exactly the seven QEMU integration tests and the benchmark/profiling
   targets. This is a **host Linux x86_64** result on the run's work tree, not the target and not
   acceptance. (The recorded argv for this leg also carries `--build_tests_only`; the artifact
   nevertheless prints per-target `PASSED` results and an execution summary. The argv/summary
   inconsistency is a host-side detail to confirm and is flagged, not resolved, here.)
2. **Cross-compilation of the Linux reference matrix now passes.** `cross_compilation` records
   `--config=x86_64-linux` and `--config=aarch64-linux` builds of `//score/... //tests/...`, both
   `exit_code 0`, status `completed_with_blockers`; the sole blocker is *"QNX SDK entitlement and
   target execution not configured; no credential acquired"*. The QNX leg of the target matrix was
   not exercised.
3. **QEMU (target) integration still did not run — and now for a different reason than the earlier
   report.** `native_integration` status is `findings_or_execution_failure`, qemu command
   `exit_code 1`. The failure is in the OS-image genrule:
   `@@os_images+//ubuntu_x86_64:itf-image failed: … Error: cloud-localds is not installed.`
   `qemu.stdout` records *"Executed 0 out of 6 tests: 1 fails to build and 5 were skipped"*
   (with `//tests/integration_test:test_someipd_startup FAILED TO BUILD`). The prior
   `integration_aou_review` (2026-10-02) reported `exit 127` (bazel missing); the current run has
   a working bazel and fails earlier, in image preparation, due to a missing `cloud-localds` host
   tool. **No QEMU result exists.**
4. **The changed key is packaged into the QEMU target.** `score-test-applications-pkg`
   (`tests/integration_test/BUILD:65-77`) includes `//score/socom/test/unit:socom_test`, consumed
   by `test_score_test_applications` (`:79-89`). So the platform-level path *would* exercise the
   slice's unit tests on the target; it never executed (§6).
5. **Feature and platform levels remain unverified, and level 1 is only host-measured.**
   `verification_plan.rst:121-150` defines Level 1 unit/component, Level 2 feature integration,
   and Level 3 platform integration on reference hardware. The slice has no feature requirement
   and no feature-integration test for version handling; the daemon-level integration tests are
   QEMU-only and did not run. The reference-hardware leg is optional base for the integrator; the
   full platform integration is the integrator's obligation (§3).
6. **External-component AoUs are not verified.** `gd_req__verification_external_aou`
   (`verification_process.rst:214-226`) requires external AoUs to be verified by integration
   tests or static-analysis tooling. The integration tests did not run; the static-analysis runs
   produced findings confined to vendored `.llm_tmp/googletest/**` (CodeQL security) or are
   blocked (`codeql_misra`, clang-tidy timeout, cppcheck exit 2); no `aou_req__*` register exists
   in `docs/`; and the most load-bearing AoU for the changed key — the semantics of
   `SCORE_LANGUAGE_FUTURECPP_ASSERT` — is external and undetermined in this checkout (§8).
7. **Requirement links are missing.** The only requirement tree present is
   `stkh_req__someip_gw__interoperability` (`docs/requirements/stakeholder.rst:23-35`) →
   `feat_req__tc8_conformance__conformance` + eight `comp_req__tc8_conformance__*`
   (`docs/tc8_conformance/requirements.rst:24-270`), all scoped to TC8/`someipd` wire conformance.
   `docs/requirements/feature/index.rst` and `docs/requirements/component/index.rst` are empty
   placeholders; there is **no `comp_req__socom__*`** and no interface need. The candidate tests
   deliberately record only `DerivationTechnique` and `Description` (`process_checks`
   `metadata_inventory`); `TestType` and all `PartiallyVerifies`/`FullyVerifies` links are unset.
   The traceability gate **failed to run**: `native_traceability` unit/component tests `exit 0`,
   but `//:docs` `exit 2` and `//:traceability_gate` `exit 1` with
   *"Error: unsupported schema_version None (expected '2')"* (§9).
8. **No obligation is satisfied.** Every `source-index.json` entry is `native_acceptance:
   not_inferred`; `authority.json` is `engineering_acceptance: pending`, `human_reviews:
   unanswered`, `safety_class: unknown`. The retained `process_checks` blockers include
   *"External AoU and full integration verification require scoped review"* and *"Lexical metadata
   inventory cannot prove semantic requirement coverage"* (§11, §12).

---

## 1. Binding to the baseline, issue, prior reports, host feedback, obligations

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` — *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:2-4` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` (unchanged) | `.llm_tmp/context/issue-snapshot.json:19-20` |
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**: service-instance identifier = `service id + major + minor + instance id`; service
identifier = `service id + major`; FindService = `service id + major + optional<minor> +
optional<instance>`; and a proposal to exclude `minor` from identity and make it a property of
the instance. There is **no comment and no acceptance record**, so none of it binds this review.

### 1.2 In-scope candidate files (the only writable source paths)

From `.llm_tmp/context/candidate-files.json:1-25`:

| File (repo-relative) | Baseline blob | Working-tree state read this iteration |
|----------------------|---------------|----------------------------------------|
| `score/socom/BUILD` | `3477ea08…` | `socom` library `:24-41`; `testonly` `impl_service_identifier` `:46-54` |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e…` | `operator<` identity `(instance, id, major)`; `minor` excluded (`:20-30`) |
| `score/socom/impl/service_identifier.hpp` | `c8bae790…` | brace-balanced, 40 lines, `:39` blank (§2) |
| `score/socom/test/unit/BUILD` | `3c03a7b1…` | `socom_test` globs `*.cpp`; visible to `//tests/integration_test:__pkg__` (`:22`) |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab7…` | 31 `TEST_F` + 1 `TEST` + 1 `TEST_P` (33 macros) |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(null — new file)* | **91 `TEST_F`** under `ServiceInstanceIdentifierTest` (`:168`…`:2181`) |

The `null` baseline blob for `service_identifier_tests.cpp` is the manifest's expectation of a
**new** file; it exists only in the un-merged working tree (the "cancelled draft"). The draft has
since been **expanded to 91 `TEST_F`** (`grep` this iteration; `process_checks` records
`test_macros: 91`), i.e. the "before expanding tests" precondition the task mentions is already
past — the expanded suite is present and `rework_progress` records
`source_changed_this_round: false`.

### 1.3 Prior reports read and preserved

`.llm_tmp/overnight/reports/` was read and preserved unchanged (this document is the only new
entry): `scope.md`, `invariants.md`, `callsites.md`, `reproducer.md`, `key_fix.md`,
`unit_matrix.md`, `ordering_tests.md`, `conversion_tests.md`, `runtime_disabled.md`,
`runtime_enabled.md`, `lifetime_tests.md`, `test_metadata.md`, `coverage_tests_repair.md`,
`tool_findings_repair.md`, `compatibility.md`, `api_review.md`, `concurrency_review.md`,
`lifetime_review.md`, `coverage_review.md`, `native_build_review.md`, `finding_classification.md`,
`misra_applicability.md`, `misra_manual_review.md`, `deviation_drafts.md`, `analyzer_plan.md`,
`bazel_plan.md`. `.llm_tmp/overnight/prior-reports/` (38 files, including an earlier
`integration_aou_review.md` dated 2026-10-02) was also preserved. The prior integration review's
central integration findings (QEMU not run; no requirement links; unverified external AoUs;
S-CORE vs. integrator split) still hold; its specific *tool* failure has been superseded (it
recorded `bazel` missing/`exit 127`, whereas the current run has bazel present and fails on
`cloud-localds`).

### 1.4 Host validation feedback and obligation-collection results (present in this checkout)

- `.llm_tmp/overnight/validation/` is **present**. `check-result` = `0`. `measurement.json`
  records `origin: local_unprotected_measurement`, `initiator: "Fabro host hook"`,
  `engineering_acceptance: pending`, `full_native_tests: not_executed`, compiler
  `/usr/bin/x86_64-linux-gnu-g++-12` (sha256 `88315fd2…`), and a focused identifier-TU red→green
  pair: `baseline_with_agent_tests` `{compile_exit 0, test_exit 1, tests 91, failures 33}` vs.
  `candidate` `{compile_exit 0, test_exit 0, tests 91, failures 0, disabled 0}`. `after.json` is
  the candidate gtest JSON; `after-test.command.json` is the candidate run with `exit_code 0`.
- `.llm_tmp/overnight/obligations/` retains 25 checks. **Retention is not passing.** The ones
  that bear on integration/AoU are tabulated in §1.4.1; full details in §4–§12.

#### 1.4.1 Retained obligation status (integration/AoU-relevant)

| Check | Retained status / key record | Integration/AoU relevance |
|-------|------------------------------|---------------------------|
| `native_build` | `completed`; `bazel build //...` exit 0 | Host build of the whole tree passes |
| `native_tests` | `completed`; `bazel test //...` exit 0; *"Executed 21 out of 29 tests: 21 tests pass and 8 were skipped"*; `socom_test` PASSED | **Level-1 host tests executed**; 8 QEMU/benchmark targets skipped |
| `native_sanitizers` | `completed`; exit 0; stdout *"Executed 19 out of 27 tests: 19 pass and 8 were skipped"* incl. `socom_test` PASSED | Host ASan/LSan/UBSan leg; includes `--build_tests_only` in argv (flagged) |
| `native_tsan` | `completed`; exit 0; *"Executed 5 out of 27 tests: 19 tests pass and 8 were skipped"* (rest cached) | Host TSan leg; includes `--build_tests_only` in argv (flagged) |
| `cross_compilation` | `completed_with_blockers`; x86 exit 0, arm exit 0; blocker *"QNX SDK entitlement and target execution not configured; no credential acquired"* | Linux reference cross-builds pass; QNX not exercised |
| `native_integration` | `findings_or_execution_failure`; exit 1; `cloud-localds` missing; 0/6 tests; `test_someipd_startup` FAILED TO BUILD | **QEMU integration NOT run** (§6) |
| `native_coverage` | `completed`; coverage/report exit 0 | Host instrumentation leg completed (see `focused_coverage` for numbers) |
| `focused_coverage` | `completed`; `service_identifier.cpp` + `string_registry.cpp`: 100 % line (36/36), **78.6 %** branch (11/14) | Below the 85/100 platform branch goal; focused scope only |
| `compiler_diagnostics` | `completed`; gcc and clang compile/tests all exit 0 (focused identifier TU, `-Werror`) | Criterion-9 evidence, focused; no full-project warning census |
| `focused_asan_lsan` | `completed`; compile 0, tests exit 0 | Focused TU only |
| `focused_memcheck` | `completed`; compile 0, valgrind memcheck exit 0 | Focused TU only; optional complement (tool_assurance blocker) |
| `focused_tsan` | `findings_or_execution_failure`; compile 0, **tests exit 66** | Focused TSan run **failed** |
| `focused_cppcheck` | `findings_or_execution_failure`; exit 2 | Complementary, not MISRA coverage (limit recorded) |
| `focused_clang_tidy` | `findings_or_execution_failure`; `--verify-config` exit 1 (unknown checks) | clang-tidy **not run** (config blocker) |
| `native_lint` | `findings_or_execution_failure`; clang-tidy `exit 124` (timeout), ruff exit 0 | clang-tidy analysis **timed out** |
| `native_docs` | `findings_or_execution_failure`; `//:docs` exit 2 (Sphinx; no git remote; *"Tests missing all properties"*) | Docs gate **failed** |
| `native_traceability` | `findings_or_execution_failure`; unit/component tests exit 0; `//:docs` exit 2; `//:traceability_gate` exit 1 (*"unsupported schema_version None (expected '2')"*) | **Traceability gate failed to run** |
| `codeql_security` | `findings_or_execution_failure`; scan exit 0; all listed findings under `.llm_tmp/googletest/**` | No candidate-path security verdict; dependency findings retained |
| `codeql_misra` | `findings_or_execution_failure`; blockers: *MISRA applicability/mapping draft and incomplete*; *Default suite omits manual/audit obligations*; *Compiled query qualification and human deviations pending* | MISRA not established |
| `secret_dependency_checks` | `findings_or_execution_failure`; gitleaks exit 1; blocker *"No adopted vulnerability database/ecosystem mapping or GitHub dependency scan receipt"* | Secret scan found items incl. a `private-key` in `quality/integration_testing/environments/qnx8_qemu/init_x86_64.build` and many FP from `.llm_tmp` artifacts |
| `format_precommit` | `findings_or_execution_failure`; format timeout (124), **reuse lint exit 1**, pre-commit/module-tidy/lockfile exit 0 | Notices: 387/389 files covered; see §14 |
| `tool_assurance` | `completed_with_blockers`; tools inventoried; blockers: human qualification/acceptance required; Coverity not installed/adopted; memcheck optional | Tool qualification unestablished |
| `process_checks` | `completed_with_blockers`; blockers incl. *"External AoU and full integration verification require scoped review"*, *"Lexical metadata inventory cannot prove semantic requirement coverage"*, *"Safety/QM applicability and approved tailoring unknown"*, *"Independent inspection and acceptance required"*; inventory `runtime_tests.cpp` 33 macros, `service_identifier_tests.cpp` 91 macros, each only `DerivationTechnique`+`Description` | Directly names this review; confirms missing links (§9) |
| `rework_progress` | `completed`; `source_changed_this_round: false`; `rework_requested: false`; *"One complete pass requested; unresolved findings stay pending"* | No source change this round |

### 1.5 Pinned obligation sources and authority (read this iteration)

All nine entries of `.llm_tmp/context/obligations/source-index.json` and `authority.json` are
present. Every source-index entry is `"native_acceptance": "not_inferred"`. `authority.json`
records `engineering_acceptance: pending`, `human_reviews: unanswered`, `safety_class: unknown`,
`codeql_scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload"`, and the
instruction *"Restart the failed queue for one complete pass through all obligations"*.
`misra_mapping.rst` and `inspection_checklist.rst` are `:status: draft`. The requirements most
load-bearing for this review, read directly this iteration, are:

- `gd_req__verification_checks` (`verification_process.rst:178-196`) — `TestType` and
  `DerivationTechnique` shall be set; a `Partially/FullyVerifies` link in a Component Integration
  Test or Unit Test shall link to at least one Component Requirement.
- `gd_req__verification_checks_extended` (`:198-212`) — `requirements-based` requires a
  requirement link; `interface-test` requires an interface link.
- `gd_req__verification_external_aou` (`:214-226`) — *"External components AoUs shall be verified
  by integration tests or static analysis tooling."*
- `gd_req__verification_independence` (`:141-152`) — the approver shall differ from the author.
- `gd_req__verification_ci_reference_execution` (`:250-264`) — regular CI reference integration;
  carries an open alignment TODO to `eclipse-score/reference_integration#190`.
- `verification_plan.rst` — verification scope/constraints (`:61-67`), the three integration
  levels and the S-CORE/integrator split (`:121-150`).

---

## 2. The recorded syntax failure: inspection of the actual source

### 2.1 Finding (re-verified by direct `read_file` + `grep`)

`score/socom/impl/service_identifier.hpp` is **brace-balanced**. It is 40 lines:

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

The sibling `score/socom/impl/service_identifier.cpp` uses the same nested form and is balanced.
There is no third, unmatched closing brace, and `glob **/service_identifier.hpp` returns exactly
one path, so there is no second, differently-braced copy in this checkout.

### 2.2 Measured corroboration present this iteration (retained, not acceptance)

- `compiler_diagnostics` records a focused identity-TU compile with
  `g++-12 -std=c++17 -Wall -Wextra -Werror` `exit_code 0` and with
  `clang++-19 … -Werror` `exit_code 0`; both focused test executables exit 0.
- `validation/measurement.json` records candidate `compile_exit: 0`; `after-compile.stderr` is
  empty; the focused candidate run is `test_exit: 0` over 91 tests.
- A surviving unmatched brace would have broken every one of these. This is still a **focused**
  reading plus broad host builds (`native_build` exit 0); it is **not** a full target build.

### 2.3 Disposition and instruction conflict

Applying the historical repair to the already-balanced file would be a no-op at best and a
compile break at worst. **No source change was made** (`rework_progress`:
`source_changed_this_round: false`). The task contains a genuine conflict — it directs correcting
the source while its explicit final sentence permits only this report to be written — and on the
facts there is nothing to correct. Both the conflict and the stale description are recorded for
human disposition rather than silently resolved.

---

## 3. What "integration" means here, and the S-CORE / integrator split

### 3.1 The three levels (from the pinned plan)

`verification_plan.rst:121-150` defines:

| Level | Basis | Who executes |
|-------|-------|--------------|
| 1. Software unit + component verification | detailed design, component architecture, component requirements | S-CORE (unit + component tests) |
| 2. Software (feature) integration verification | feature architecture, feature requirements | S-CORE (feature integration tests) |
| 3. Software platform integration testing | stakeholder requirements, on reference hardware | S-CORE runs reference-hardware tests as an *optional base*; **"The full Platform Integration Testing will be executed by the integrator"** (`:145`) |

### 3.2 Reference integration vs. final-product integrator obligations

- **S-CORE reference obligation:** provide regular CI reference integration
  (`gd_req__verification_ci_reference_execution`), provide Platform Integration Tests on
  reference hardware as a reusable starting point, and maintain the POSIX-target simulation
  environments (`verification_plan.rst:590-608` as cited by prior reports).
- **Final-product integrator obligation (out of project scope):** *"The integration of the
  platform on a target device and the respective verification and validation should be considered
  by the distributor of the platform. On target integration tests that are running on a reference
  hardware in context of this project can be taken as a starting point."*
  (`verification_plan.rst:64-67`). The platform AoUs it derives from
  (`aou_req__platform__testing`, `aou_req__platform__test_completion`) are not defined in this
  checkout.

This review keeps the two apart everywhere. The bounded key change is a `socom`-internal identity
change; its verification evidence currently lives at Level 1 (host) only.

---

## 4. Level 1 — unit / component integration (host)

**Status: executed and passing on the host, retained, scoped, not acceptance.** The retained
`native_tests` artifact ran `bazel test --jobs=2 //...` and records (stdout):

```
Executed 21 out of 29 tests: 21 tests pass and 8 were skipped.
```

with, among others, `//score/socom/test/unit:socom_test PASSED in 1.4s` and
`//score/socom/test/unit:socom_test` again PASSED under the sanitizer leg
(`native_sanitizers`, `socom_test PASSED in 0.6s`) and the TSan leg. `native_build` records
`bazel build //...` exit 0.

The focused host measurement that isolates the changed key is the `validation/measurement.json`
red→green pair: the same identifier TU fails 33 of 91 tests against the pre-correction behaviour
and passes 91/91 against the candidate work tree. This is the slice's clearest Level-1 evidence
and shows the key correction is a real behavioural change (minor-only duplicates now collapse),
not merely a test-only edit.

**Caveats (must not be dropped):**
- The host leg is **Linux x86_64**; it is not the reference target and not the final product.
- The recorded `--build_tests_only` argv vs. the printed execution summary is an inconsistency to
  confirm with the host tooling (the artifact clearly prints per-target runtimes and PASSED
  results).
- `focused_tsan` failed (exit 66); clang-tidy timed out; cppcheck exited 2; coverage branch is
  78.6 % — so "Level 1 is clean" is **not** established across tools.
- No human review; results are local and unprotected.

---

## 5. Level 2 — feature integration

**Status: not performed; no feature requirement or feature-integration test exists for this
slice.** The feature identifier space in `docs/requirements/feature/index.rst` is an empty
placeholder; the only feature requirement present is
`feat_req__tc8_conformance__conformance`, which scopes TC8 wire conformance of `someipd`, not
`socom` version handling. Cross-component integration for the gateway daemons
(`gatewayd` ↔ `someipd` over `socom`, and the IPC binding) exists only as QEMU integration tests
(§6), which did not run. Therefore Level 2 is **not established** for the duplicate-server
registration key.

---

## 6. Level 3 — platform integration and QEMU results

**Status: not run.** Details, in order of failure:

1. **Image preparation failed.** `native_integration` qemu command (`bazel test --config=qemu-integration
   //quality/... //tests/integration_test/...`) is `exit_code 1`. `qemu.stderr` ends with:
   `ERROR: … @@os_images+//ubuntu_x86_64:itf-image failed: (Exit 1): bash failed …`
   `Error: cloud-localds is not installed. Please install it to proceed.`
   `ERROR: Build did NOT complete successfully`.
2. **Zero integration tests executed.** `qemu.stdout` records
   `Executed 0 out of 6 tests: 1 fails to build and 5 were skipped.` with
   `//tests/integration_test:test_someipd_startup FAILED TO BUILD` and the other five
   `NO STATUS`.
3. **Prerequisites checked were incomplete.** `native_integration/result.json` records
   `prerequisites: {kvm_exists: true, qemu: /usr/bin/qemu-system-x86_64}` — no `cloud-localds`
   check; the missing host tool is the immediate blocker. KVM/QEMU availability is **not** a run.
4. **The changed key would have been exercised on the target.** `tests/integration_test/BUILD:65-77`
   packages `//score/socom/test/unit:socom_test` into `score-test-applications-pkg`, and
   `test_score_test_applications` (`:79-89`) runs it in QEMU. So a successful QEMU leg is the
   S-CORE reference path for this slice's component tests; it did not execute.
5. **Daemon/SD/TC8 integration unverified.** `test_tcpdump`, `test_gateway_startup`,
   `test_someipd_startup`, `test_someipd_sends_someip-sd_message`, and
   `test_someipd_started_by_test` all remained unexecuted. There is no daemon-startup observation,
   no SOME/IP-SD capture, and no TC8 result.
6. **No reference hardware.** The plan's reference-hardware leg is not exercised; the final-product
   integration remains the integrator's obligation (§3).

---

## 7. Interface-test review

- `score/socom/test/unit/interface_compatibility_tests.cpp` exists (parameterised `TEST_P`
  instantiations over `Identifier` and `Version`) and is compiled into `socom_test`
  (`score/socom/test/unit/BUILD:16-29`, `srcs = glob(["*.cpp"])`), which PASSED on the host.
- However, `gd_req__verification_checks_extended` requires that an **`interface-test`** `TestType`
  link to at least one interface, and `gd_req__verification_checks` requires `TestType` and
  `DerivationTechnique` to be set. The candidate tests record only `DerivationTechnique` and
  `Description` (`process_checks` inventory); no `TestType` is set and no interface need exists in
  `docs/`. The `interface_compatibility_tests.cpp` file carries no interface-test metadata.
- The changed key's compatibility semantics (exact-major, `client.minor <= server.minor`,
  `runtime_impl.cpp:133-146`) and the minor-ignoring `Service_database` index
  (`runtime_impl.hpp:116-134`) are exercised by other suites, but this slice provides **no
  interface test** and no interface link, so the interface-test method is **not satisfied**.

---

## 8. External-component Assumptions-of-Use (AoU) review

### 8.1 The obligation

`gd_req__verification_external_aou` (`verification_process.rst:214-226`): *"External components
AoUs shall be verified by integration tests or static analysis tooling."* This is a platform-wide
process obligation; the platform AoUs it derives from are not defined in this checkout.

### 8.2 External components actually pulled in (from `MODULE.bazel`, read this iteration)

| External component | Version / pin | AoU surface the gateway relies on |
|--------------------|---------------|-----------------------------------|
| `vsomeip` | `3.6.1`, patched `vsomeip-qnx8.patch`, `vsomeip-no-werror.patch` (`MODULE.bazel:303-316`) | SOME/IP stack; interface-version/minor handling, eventgroups, thread-safety, QNX-patched behaviour |
| `score_baselibs` | `0.2.13`, patched `restore_qnx8_poll_workaround.patch` (`:249-256`) | `futurecpp` (`SCORE_LANGUAGE_FUTURECPP_ASSERT`), `mw/log`, `result`, `message_passing`; **assert semantics**, QNX8 poll workaround |
| `score_communication` / `mw::com` | `0.3.0`, git override `d609be92…` (`:239-244`) | `gatewayd` proxy/skeleton, `InitializeRuntime`; find-service lifecycle, shared-memory contract |
| `flatbuffers` | `25.12.19` (`:269`) | config schema/accessors; default `service_version_minor = 0xFFFFFFFF`, `service_version_major: uint8` (`score/config/mw_someip_config.fbs:19-23`) |
| `boost` | `1.87.0`, patched `boost-asio_qnx.patch` (`:287-301`) | transitive via vsomeip; QNX asio behaviour |
| `rules_foreign_cc` | `0.15.1`, patched (`:275-283`) | builds vsomeip; network/`proc_self_cwd` patches |
| `googletest` | `1.18.0` (`:59`) | unit tests; the only host compiler warning previously observed on this TU |
| LLVM toolchain | `22.1.7` (`:165-193`) | Bazel C++ toolchain; sanitizer features |
| QNX SDP toolchains / imagefs | QCC 12.2.0, SDP 8.0.4 (`:117-157`, `:342-363`) | target build/run; SDK entitlement/credentials |
| `score_itf`, `os_images`, `score_rules_imagefs` | git overrides (`:321-363`) | QEMU target execution; image/`/opt` mount, QEMU ping timeout |

### 8.3 Are the AoUs verified here?

**No.** Concretely:

1. **No integration test ran** that would verify any AoU — the QEMU leg did not execute (§6).
2. **No static-analysis tool produced a candidate-path AoU verdict.** `codeql_security` findings
   are confined to vendored `.llm_tmp/googletest/**` (rules include `cpp/fixme-comment`,
   `cpp/commented-out-code`, `cpp/path-injection`, `cpp/rule-of-two`,
   `cpp/equality-on-floats`); `codeql_misra` is blocked on a draft/incomplete mapping and
   unqualified compiled queries; `focused_clang_tidy` failed `--verify-config` (unknown checks);
   `focused_cppcheck` exited 2 (complementary, no MISRA coverage inferred).
3. **The most load-bearing AoU for the changed key is undetermined.** The semantics of
   `SCORE_LANGUAGE_FUTURECPP_ASSERT` (terminate vs. compiled-out) at the single-server site
   `Service_record::register_server_connector` (`score/socom/impl/runtime_impl.cpp:366-371`, assert
   at `:369`) depend on external `score_baselibs` behaviour. The key change removes the minor-only
   reachability of that site, but the **AoU itself remains unverified**.
4. **The FlatBuffers wildcard default is an unverified external-schema AoU.**
   `service_version_minor` defaults to `0xFFFFFFFF` (`mw_someip_config.fbs:23`) and is narrowed to
   `uint16_t` by the config consumers; no integration test verifies the resulting collision
   behaviour under the coarsened key.
5. **No AoU requirement register exists.** `docs/requirements/component/index.rst:26-27` documents
   the `aou_req__<component>__<title>` naming scheme but defines no AoU; no platform
   `aou_req__platform__*` is present.

### 8.4 Disposition

`gd_req__verification_external_aou` is **not satisfied** for this slice: external AoUs are neither
integration-tested nor statically analysed, the platform AoU requirements it derives from are
absent, and the module does not define AoU requirements for the components it assumes. This is an
explicit pending item for the human gate and process owner, not a finding this review may close.

---

## 9. Missing requirement links

### 9.1 Requirement hierarchy actually present

`docs/requirements/index.rst:28-50` defines the three-level hierarchy (stakeholder → feature →
component). The checkout contains:

| Level | Present | Coverage relevant to this slice |
|-------|---------|--------------------------------|
| Stakeholder | `stkh_req__someip_gw__interoperability` (`docs/requirements/stakeholder.rst:23-35`) | SOME/IP wire interoperability; not `socom` identity |
| Feature | `feat_req__tc8_conformance__conformance` (`docs/tc8_conformance/requirements.rst:24-39`) | TC8 wire conformance of `someipd`; not `socom` |
| Component | eight `comp_req__tc8_conformance__*` (`docs/tc8_conformance/requirements.rst:55-270`) | TC8 SD/message/event conformance; not `socom` |
| Component/Feature indices | `docs/requirements/component/index.rst:15-36`, `docs/requirements/feature/index.rst:15-32` | **empty placeholders** |
| AoU | none defined | naming scheme only (`component/index.rst:26-27`) |

### 9.2 Consequence

- **No `comp_req__socom__*` exists** for the duplicate-server registration key, the minor-version
  exclusion, or the exact-major / minimum-minor rules, and no `:reqtype: Interface` need exists.
  There is therefore **no requirement or interface to link** the tests to.
- `gd_req__verification_checks` (`verification_process.rst:196`) requires a Unit Test's
  `Partially/FullyVerifies` link (when set) to point at a Component Requirement. Because no such
  requirement exists and inventing one is prohibited, the candidate tests set no `TestType` and no
  link. The candidate file states this explicitly
  (`service_identifier_tests.cpp:57-64`).
- The traceability gates did **not** run: `native_traceability` `unit-component-tests` exit 0, but
  `//:docs` exit 2 and `//:traceability_gate` exit 1 with
  *"Error: unsupported schema_version None (expected '2')"* (`traceability.stderr`).
- `native_docs` itself failed (`exit 2`) with a Sphinx extension error because no git remote is
  set in the sandbox, and the docs "Tests missing all properties" list includes the TC8 tests and
  NullSerializer tests — i.e. the docs/traceability evidence path is currently non-functional in
  this environment.
- `process_checks` records the limitation verbatim: *"Lexical metadata inventory cannot prove
  semantic requirement coverage"*, and lists `runtime_tests.cpp` (33 macros) and
  `service_identifier_tests.cpp` (91 macros) with only `DerivationTechnique` + `Description`.

**Bottom line:** the bounded slice has **no requirement links**, no requirement to link to, and no
traceability execution. The human gate must disposition this — author the `socom` component
requirement(s) and interface need and link the tests, or record an approved tailoring/deviation.
This review may not invent the identifiers.

---

## 10. Test-metadata status (from `process_checks`)

| File | `test_macros` | Recorded properties | Missing |
|------|---------------|---------------------|---------|
| `score/socom/test/unit/runtime_tests.cpp` | 33 | `DerivationTechnique`, `Description` | `TestType`, `Partially/FullyVerifies` |
| `score/socom/test/unit/service_identifier_tests.cpp` | 91 | `DerivationTechnique`, `Description` | `TestType`, `Partially/FullyVerifies` |

`service_identifier_tests.cpp` records `DerivationTechnique = "boundary-values,equivalence-classes"`
and a description, and deliberately withholds `TestType`/links for lack of a native identifier
(`:42-65`). `runtime_tests.cpp` uses a shared metadata helper with
`DerivationTechnique = "design-analysis,equivalence-classes"` (prior-report reading; the
`process_checks` inventory confirms the property set). This is consistent with
`gd_req__verification_link_tests_cpp` but does not satisfy `gd_req__verification_checks` /
`_checks_extended` for `TestType`/link requirements.

---

## 11. Integration / AoU findings register

Each finding is local, scoped, and unaccepted. None is a closed defect.

| # | Finding | Evidence | Status |
|---|---------|----------|--------|
| I-1 | Level-1 host tests executed and passed, incl. `socom_test`; focused red→green over the changed key | `native_tests/tests.stdout`; `validation/measurement.json` (91/33 → 91/0) | **PASS (host, scoped, unprotected)** |
| I-2 | QEMU target integration did not run; image genrule blocked by missing `cloud-localds`; 0/6 tests; `test_someipd_startup` fails to build | `native_integration/qemu.stderr`, `qemu.stdout`, `result.json` (exit 1) | **NOT RUN** |
| I-3 | No QEMU/daemon/SD/TC8 observation on the target, so a `duplicate_service` at the daemon boundary is unverified | `tests/integration_test/BUILD:79-163`; §6 | **UNVERIFIED** |
| I-4 | Feature (Level 2) integration not performed; no feature requirement/test for version handling | `docs/requirements/feature/index.rst`; `verification_plan.rst:133-137` | **NOT PERFORMED** |
| I-5 | Reference-hardware platform leg not exercised; final-product integration is the integrator's obligation | `verification_plan.rst:64-67,145-150` | **NOT RUN / out of project scope** |
| I-6 | Interface-test method not satisfied: no `TestType`, no interface link | `verification_process.rst:198-212`; `process_checks` inventory | **NOT SATISFIED** |
| I-7 | External-component AoUs unverified by integration test or static analysis; no `aou_req__*` register; assert-semantics and FlatBuffers-wildcard AoUs open | §8; `MODULE.bazel`; `mw_someip_config.fbs:19-23` | **NOT SATISFIED** |
| I-8 | `SCORE_LANGUAGE_FUTURECPP_ASSERT` semantics (external `score_baselibs`) undetermined; single-server invariant at `runtime_impl.cpp:369` rests on it | `runtime_impl.cpp:366-371`; prior `api_review` reading | **UNRESOLVED AoU** |
| I-9 | No `comp_req__socom__*` / interface need; traceability gate failed (`unsupported schema_version None`); docs gate failed | §9; `native_traceability`; `native_docs` | **MISSING LINKS / NOT RUN** |
| I-10 | Config minor wildcard `0xFFFFFFFF` narrows to `0xFFFF` and now collides with a concrete minor under the coarsened key | `mw_someip_config.fbs:19-23`; `service_identifier.cpp:28-29` | **UNRESOLVED design input** |
| I-11 | Design-doc drift: `Runtime::make_server_connector` doc says duplicates are judged by "configuration.interface and instance", but the key ignores `minor` while public `operator==` includes it | `runtime.hpp:170-178`; `service_interface_identifier.hpp`; `service_identifier.cpp:28-29` | **DOC/CODE DRIFT** |
| I-12 | `focused_tsan` failed (exit 66); clang-tidy timed out; cppcheck exit 2; branch coverage 78.6 % | §1.4.1 | **NOT CLEAN** |
| I-13 | `secret_dependency_checks` gitleaks found a `private-key` in `quality/integration_testing/environments/qnx8_qemu/init_x86_64.build` plus many `.llm_tmp` artifact false positives; no vulnerability DB adopted | `secret_dependency_checks/secret-findings.json`; blocker | **FINDINGS / unclassified** |
| I-14 | Two non-candidate files lack REUSE copyright/license metadata (`.bazel_config`, `third_party/score_baselibs/restore_qnx8_poll_workaround.patch`); candidate files carry headers | `format_precommit/reuse.stdout` | **NOTICES: candidate OK, repo 387/389** |
| I-15 | `codeql_misra` blocked (draft/incomplete mapping, manual/audit suite omitted, unqualified queries); `native_lint` clang-tidy timed out | `codeql_misra/result.json`; `native_lint/result.json` | **NOT ESTABLISHED** |

---

## 12. Obligations status

### 12.1 Pinned state

All nine pinned sources read; every `source-index.json` entry is
`"native_acceptance": "not_inferred"`. `authority.json`: `engineering_acceptance: pending`,
`human_reviews: unanswered`, `safety_class: unknown`.

### 12.2 Status for this slice

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Component (Level 1) integration/verification executed | `verification_plan.rst:126-132` | **PARTIAL — host only**; `socom_test` PASSED on host; no target run |
| Feature (Level 2) integration verification | `verification_plan.rst:133-137` | **NOT PERFORMED / no feature requirement** |
| Platform (Level 3) integration on reference hardware | `verification_plan.rst:138-150` | **NOT RUN** — QEMU blocked by `cloud-localds`; final-product integration is the integrator's obligation |
| Interface-test method + interface link | `verification_plan.rst:195-198`; `verification_process.rst:211-212` | **NOT SATISFIED** — no `TestType`/interface link |
| Requirements-based test method | `verification_plan.rst:199-202` | **NOT PERFORMED** — no linked requirement |
| Resource-usage evaluation / benchmarks | `verification_plan.rst:203-207` | **NOT RUN** — `native_performance` benchmarks and profiling both timed out (124) |
| Fault injection / fuzz | `verification_plan.rst:234-236,265-270` | **NOT EXECUTED / NOT CLAIMED** — no harness |
| External-component AoUs verified | `verification_process.rst:214-226` | **NOT SATISFIED** (§8) |
| CI reference-integration execution | `verification_process.rst:250-264` | **NOT ESTABLISHED / applicability TODO**; QEMU leg failed |
| Linking tests to requirements/interface (`TestType`, `Verifies`) | `verification_process.rst:178-212` | **NOT DONE** — only `DerivationTechnique`/`Description` |
| Independence of verification / review | `verification_process.rst:141-152` | **NOT DONE** — human reviews unanswered |
| QEMU / native integration results retained | `obligations/native_integration/result.json` | **FAILED TO RUN** (exit 1) — retention ≠ passing |
| Traceability gate | `native_traceability` | **FAILED TO RUN** (exit 1) |
| Docs gate | `native_docs` / `native_traceability` | **FAILED** (exit 2) |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` | **UNKNOWN — NOT CLAIMED** (mapping `:status: draft`) |
| Static code analysis findings classified | `verification_process.rst:228-248` | **NOT DONE** — findings exist (googletest/CodeQL, cppcheck) with no authorized classification |
| Freedom from compiler warnings & errors (criterion 9) | `verification_plan.rst:332-335` | **PARTIAL** — focused gcc/clang `-Werror` clean and broad host build clean; clang-tidy analysis timed out |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** — human qualification required |
| Native acceptance | `source-index.json` | **`not_inferred` for every entry** |

**Explicit non-satisfaction statement.** Missing target tooling (`cloud-localds`), the
non-running QEMU/feature/platform legs, the failed traceability and docs gates, the non-running or
blocked static analysis, the failed focused TSan leg, the absent requirement/interface links, the
absent AoU register, the `not_inferred` applicability, and the unanswered human reviews mean
**none of the checked obligations may be treated as satisfied** on the strength of result
retention. The host build/test evidence is real but **scoped, unprotected, and below the human
gate**.

---

## 13. Measurement and validation status

- **Tools used by this iteration:** `read_file`, `grep`, `glob`, `write_file` only. No `shell`,
  delegation, web, approval, publishing, or engineering acceptance. **No new measurement was
  executed by this iteration.**
- **Retained measurements (present, scoped, unprotected):**
  - `native_build`: `bazel build //...` exit 0.
  - `native_tests`: `bazel test //...` exit 0; *"Executed 21 out of 29 tests: 21 pass, 8 skipped"*;
    `socom_test` PASSED. Argv carries `--build_tests_only` (inconsistency flagged).
  - `native_sanitizers` (ASan/LSan/UBSan): exit 0; `socom_test` PASSED. Argv carries
    `--build_tests_only`.
  - `native_tsan`: exit 0; `socom_test` PASSED among 5 newly executed. Argv carries
    `--build_tests_only`.
  - `cross_compilation`: x86_64-linux and aarch64-linux builds exit 0; QNX blocker.
  - `compiler_diagnostics`: focused gcc + clang compile/tests exit 0.
  - `focused_coverage`: 100 % line / 78.6 % branch for the focused files.
  - `focused_asan_lsan` exit 0; `focused_memcheck` exit 0; `focused_tsan` tests exit 66.
  - `validation/measurement.json`: focused identifier TU, 91 tests, baseline 33 failures →
    candidate 0 failures.
- **Not run / failed:** QEMU integration (image genrule, `cloud-localds`); `native_performance`
  (benchmarks + profiling timeout 124); `native_lint` clang-tidy (timeout 124); `native_docs`
  (exit 2); `native_traceability` (docs exit 2, gate exit 1); `codeql_misra` (blocked);
  `focused_clang_tidy` (config rejected); `format_precommit` format (timeout 124) and reuse lint
  (exit 1); benchmark/profiling and all seven integration test targets.
- **Scope:** local, unprotected, scoped. This draft has not been reviewed, accepted, published, or
  reproduced on a full native runtime. Unit/component host execution and human review remain
  pending; the target run is pending.
- **Reproduction path for a later, authorized iteration (not executed here):**

  ```bash
  bazel build //score/...
  bazel test //score/...
  bazel test //score/socom/test/unit:socom_test
  # install cloud-localds, then:
  bazel test --config=qemu-integration //quality/... //tests/integration_test/...
  bazel build --config=x86_64-linux //score/... //tests/...
  bazel build --config=aarch64-linux //score/... //tests/...
  bazel run //:docs
  bazel run //:traceability_gate -- --need-type=comp_req
  ```

---

## 14. Notice preservation

- **Only this report was written.** No source, build, test, config, `NOTICE`, `LICENSE`,
  `REUSE.toml`, host-validation, or prior-report file was created, edited, or deleted. Every file
  under `.llm_tmp/overnight/reports/` and `.llm_tmp/overnight/prior-reports/` was preserved
  unchanged.
- The header the task flagged (`score/socom/impl/service_identifier.hpp`) retains its
  Apache-2.0/SPDX comment (`:1-12`) and was left unchanged because it is already balanced (§2).
  The sibling `service_identifier.cpp` (`:1-12`), both BUILD files (`score/socom/BUILD:1-12`,
  `score/socom/test/unit/BUILD:1-12`), and both candidate test files
  (`service_identifier_tests.cpp:1-12`, `runtime_tests.cpp:1-12`) retain their Apache-2.0/SPDX
  headers; `interface_compatibility_tests.cpp:1-12` also carries one.
- **REUSE result (retained):** `reuse lint` exit 1 reports **387/389** files with
  copyright/license information; the two missing are `.bazel_config` and
  `third_party/score_baselibs/restore_qnx8_poll_workaround.patch` — **not** candidate paths. The
  slice itself is notice-clean, but the repo-level REUSE gate is not green and is recorded.
- The duplicate key remains an `impl/`-only type exposed only through the `testonly`
  `//score/socom:impl_service_identifier` library (`score/socom/BUILD:46-54`), so no public header
  or notice surface changed.
- This report itself carries the Apache-2.0 header. No licensed SOME/IP/AUTOSAR/TC8 text is
  reproduced; only native requirement/query identifiers and file locations are cited.

---

## 15. Pending human review checklist

- [ ] **Confirm §2:** `service_identifier.hpp` is brace-balanced (brace lines `:19,:29,:32,:38`;
      line 39 blank; net balance 0); the recorded "extra closing brace at line 39" is stale or
      refers to a different revision. No correction is required in this checkout. If a distinct
      "cancelled draft" revision still carries the brace, locate and correct it by an authorized
      iteration.
- [ ] **Resolve the instruction conflict:** "Inspect and correct the actual source" vs. "this is a
      review draft: only that report may be written". Confirm that writing only this report, with a
      no-op on already-correct source (and 91 tests already present), is intended.
- [ ] **Accept or reject the Level-1 host evidence:** confirm the `native_tests` /
      `native_sanitizers` / `native_tsan` artifacts (21/29, 19/27, 5/27 with `socom_test` PASSED)
      and the `--build_tests_only` argv inconsistency, and record that this is a host, unprotected,
      scoped result — not a full native run.
- [ ] **Restore the QEMU prerequisite:** install `cloud-localds` (and confirm the remaining image
      prerequisites), then run `bazel test --config=qemu-integration //quality/...
      //tests/integration_test/...`. Investigate why `test_someipd_startup` FAILED TO BUILD.
- [ ] **Decide the S-CORE/integrator split for this slice (§3):** confirm that final-product
      platform integration remains the integrator's obligation, that the S-CORE
      reference-hardware leg is the only in-scope platform activity, and that "reference hardware
      is not yet decided" is accepted as an open item.
- [ ] **Author the missing requirement links (§9):** add the `socom` component requirement(s) (and
      any interface need) for the duplicate-server registration key / version handling, then link
      the candidate tests' `TestType` and `Verifies`/`Partially`/`FullyVerifies`; or record an
      approved tailoring/deviation. Do not invent identifiers.
- [ ] **Complete interface-test metadata (§7)** and decide whether
      `interface_compatibility_tests.cpp`/`client_tests.cpp` are in scope for the `interface-test`
      method and its interface link.
- [ ] **Verify the external-component AoUs (§8)** by integration test or static analysis, and
      author the AoU requirements (including the `SCORE_LANGUAGE_FUTURECPP_ASSERT` semantics AoU
      and the FlatBuffers wildcard-default AoU). Confirm the platform-level
      `aou_req__platform__testing` / `aou_req__platform__test_completion` linkage upstream.
- [ ] **Adjudicate the design/code drift (I-11)** between the `make_server_connector` doc
      (`runtime.hpp:170-178`) and the minor-excluding key, and the multi-instance-per-service-type
      and config wildcard questions (I-10) before the key change can be integration-verified.
- [ ] **Close the non-clean analysis items:** re-run clang-tidy (config/verify-config and timeout),
      classify the CodeQL/cppcheck findings per `gd_req__verification_sca_classification`, address
      the focused TSan failure (exit 66), and raise branch coverage toward the platform goal.
- [ ] **Triage the retained secret-scan finding** (`private-key` in
      `quality/integration_testing/environments/qnx8_qemu/init_x86_64.build`) and adopt a
      vulnerability database/mapping, per the `secret_dependency_checks` blocker.
- [ ] **Reconcile notices:** add REUSE metadata for `.bazel_config` and
      `third_party/score_baselibs/restore_qnx8_poll_workaround.patch` (outside this slice's
      candidate set) or record the disposition.
- [ ] **Do not infer passing from retained collection nodes (§12):** the QEMU, feature/platform,
      traceability, docs, performance, lint, and several analysis legs did not pass; retention is
      not acceptance.
- [ ] **Keep the wider #84 public `Service_interface_identifier` restructure, FindService wildcard
      handling, and the config minor-wildcard narrowing out of this bounded slice** until
      separately accepted, and **do not claim an unmeasured fuzzy technique**.
- [ ] **Schedule independent human review** (approver ≠ author, per
      `gd_req__verification_independence`) and record engineering acceptance; no compliance claim
      may be made before that.

---

*End of integration and AoU review draft. Local, unprotected, scoped. No engineering acceptance;
human reviews unanswered; target/QEMU and full native runtime tests pending. The host
build/unit-component evidence is retained but is not acceptance, and no requirement link, no AoU
verification, and no QEMU result exists.*
