<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — module verification report & release-evidence archive index (review draft)

**Document type:** review draft — module verification report + release-evidence archive index for the
bounded duplicate-server registration-key slice of *Revise version handling in socom* (issue #84).

**Date:** 2026-10-03
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** duplicate-server registration-key handling inside issue #84
**Run / branch:** `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ`; current HEAD `030e367`
(`fabro(...): node_cffc406622ac0fe3ca90dbf0 (success)`) — `.git/logs/HEAD:89`.
**Verified baseline commit:** `f8a196c3b16d5172d898394ab99b0ed81346d63d`
(`.llm_tmp/context/source-manifest.json:3`).
**Status:** **local, unprotected, scoped.** No engineering acceptance exists. Human reviews are
unanswered. Full native runtime tests, platform validation and acceptance remain pending. Nothing here
is acceptance, review approval, publication, or a full native run.

> **Write boundary observed.** This iteration used only `read_file`, `grep`, `glob` and `write_file`.
> No `shell`, no delegation, no web access, no approval, no publishing and no engineering acceptance
> was performed. The task text contains a conflict — it says to *"Inspect and correct the actual source
> before expanding tests"*, while its explicit final sentence says *"This is a review draft: only that
> report may be written."* Following the explicit, more specific write boundary, **exactly one file was
> written — this report** (`/workspace/.llm_tmp/overnight/reports/verification_report_draft.md`). No
> source, build, test, config, `NOTICE`, `LICENSE` or `REUSE.toml` file was created, edited or deleted,
> and every prior report and host artifact was preserved.
>
> **The conflict is moot on the facts.** The recorded defect — *"a measured GCC syntax failure: an extra
> closing brace in `score/socom/impl/service_identifier.hpp` at line 39"* — is **not present in the
> current working tree** (§4). Direct inspection shows the header is brace-balanced (openers `:19`,
> `:29`; closers `:32`, `:38`; line `:39` is empty; `:40` is `#endif`). There is nothing to correct, and
> the write boundary would have forbidden a source write in any case.
>
> **Non-satisfaction rule applied throughout.** A successful obligation-collection node means results
> were **retained**, not that checks **passed**. Missing tools, unknown applicability, incomplete
> extraction, draft/inactive rule mappings and unanswered human reviews are **not** treated as
> satisfied. A tool that produced **no** finding because it **did not run** (or timed out) is recorded
> as *"not run / timed out"*, never as *"clean"*. Every unexecuted applicable check and every
> unaccepted deviation remains a **blocker** (§9, §10).

---

## 0. Summary

1. **Issue #84 is an unaccepted design proposal** (0 comments, no assignee/labels/milestone; §1).
2. **The recorded syntax failure is not in the actual source.** `score/socom/impl/service_identifier.hpp`
   is brace-balanced and line 39 is blank (§4). The focused GCC and Clang compilations of the candidate
   identifier translation unit (which includes this header) both exit `0` (`.llm_tmp/overnight/
   obligations/compiler_diagnostics/result.json`, `gcc-compile`/`clang-compile`), and the full native
   `bazel build //...` exits `0` (`native_build/result.json`).
3. **The bounded key change is present and internally consistent:** `operator<` orders by
   `(instance, service id, major)` with `minor` deliberately excluded
   (`score/socom/impl/service_identifier.cpp:28-29`), matching the minor-ignoring `Service_database`
   record index.
4. **Executed evidence now exists for the slice, but it is local, unprotected and mixed** (§6):
   - focused identifier TU: **91/91 pass, 0 failures, 0 disabled**; before-fix it was **91 tests /
     33 failures** (`.llm_tmp/overnight/validation/before.json`, `after.json`; `check-result` = `0`);
   - native `bazel build //...` exit `0`; native `bazel test //...` **21/29 executed, 21 pass,
     8 skipped**, including `//score/socom/test/unit:socom_test` PASSED;
   - native ASan/LSan/UBSan: **19/27 executed, 19 pass, 8 skipped**;
   - native TSan: only **5/27 executed** (19 cached passes + 8 skipped) — **incomplete**;
   - focused coverage: `service_identifier.cpp` + `string_registry.cpp` **line 36/36 = 100 %**,
     **branch 11/14 = 78.6 %** — **below** both platform goals (QM 85 %, safety 100 %).
5. **Multiple checks failed or timed out** and are **not** satisfied: native docs exit `2`; traceability
   gate exit `1`; QEMU integration exit `1`; clang-tidy timeout (exit `124`); focused clang-tidy config
   rejected (exit `1`); cppcheck exit `2`; focused TSan exit `66`; format check timeout `124`; `reuse
   lint` exit `1`; gitleaks exit `1`; performance benchmarks/profiling timed out `124`; CodeQL
   security/MISRA carry findings; cross-compilation builds x86_64+aarch64 but **not QNX** (§6–§8).
6. **No obligation is satisfied** (§9): every `source-index.json` entry is
   `native_acceptance: not_inferred`; `authority.json` records `engineering_acceptance: pending`,
   `human_reviews: unanswered`, `safety_class: unknown`.

---

## 1. Binding issue #84 to the verified baseline

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` | `.llm_tmp/context/issue-snapshot.json:2-4` |
| Title | *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:3` |
| State | `open`, **0 comments**, no milestone / assignee / labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` | `.llm_tmp/context/issue-snapshot.json:19-20` |
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Current branch / HEAD | `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ` / `030e367` | `.git/logs/HEAD:89` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**. It distinguishes: service-instance identifier = `service id + major + minor + instance
id`; service identifier = `service id + major`; FindService = `service id + major + optional<minor> +
optional<instance>`; and proposes to *"exclude the minor version and make it a property of the service
instance"*. The FindService `major = FF` AUTOSAR case is noted as theoretically possible but not
useful. There is **no comment and no acceptance record**; binding is by baseline commit, not by run
HEAD.

---

## 2. Candidate set: baseline blobs, manifest hashes, current-tree hashes

`score/socom/impl/service_identifier.hpp`, `score/socom/impl/service_identifier.cpp`,
`score/socom/BUILD`, `score/socom/test/unit/BUILD`, `score/socom/test/unit/runtime_tests.cpp` and the
new `score/socom/test/unit/service_identifier_tests.cpp` (baseline blob `null`).

The **current-tree hashes** below are taken from the host measurement's `source_hashes`
(`.llm_tmp/overnight/validation/measurement.json:8-...` and every
`.llm_tmp/overnight/obligations/*/result.json` `source_hashes`), which agree across all host artifacts.
They **differ from** the older values recorded in `.llm_tmp/context/candidate-files.json`, because the
draft was reworked after that snapshot was taken (the identifier suite grew from 87 to **91** `TEST_F`).

| File (repo-relative) | Baseline git blob | `candidate-files.json` sha256 (older) | Current-tree sha256 (host measurement) |
|----------------------|-------------------|----------------------------------------|------------------------------------------|
| `score/socom/BUILD` | `3477ea08…` | `dee82616…` | `68f4645a21e495fac43929fb125f7ba0b9e29fc84c0401fdb95238ffb7fd2cc8` |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e…` | `d766902e…` | `3c12b3f1dd3f1fa66cdf43766f374d7d067637bf8f11aba604c4e2688351f11a` |
| `score/socom/impl/service_identifier.hpp` | `c8bae790…` | `96b33a1f…` | `bdce3fcbc3cd78a8ecaece1ea36107d464011ab81c9bc39932d0be617befaea9` |
| `score/socom/test/unit/BUILD` | `3c03a7b1…` | `9b3c5b34…` | `e909151e822370bebe8d59b86369bddeb4d6cacfa02f10061bf6e134671ff9d4` |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab7…` | `5e35e24d…` | `9a2d6a154683a2b7ff9d51b7241e4fb74c1a8ef483895830cb409a8f5a1d3127` |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(none — `null`)* | `45d07399…` | `de79767c4653feca7b5b2fcf93f5a791bcc64ae4b554dc2ef35a8756536391e6` |

The `null` baseline blob for `service_identifier_tests.cpp` is the manifest's expectation of a **new**
file; it exists only in the un-merged working tree (the task's *"cancelled draft"*), never in the
baseline. `glob **/service_identifier.hpp` returns exactly one path, so there is no second,
differently-braced copy of the header. No local hashing tool was available in this task, so the
current-tree hashes are **quoted from the host measurement, not independently recomputed**.

---

## 3. Reproduced behaviour of the bounded change (source reading)

`score/socom/impl/service_identifier.cpp:20-30`:

```cpp
bool operator<(Service_instance_identifier const& lhs, Service_instance_identifier const& rhs) {
    // ... rationale comment: minor excluded; identity = service id + major (issue #84) ...
    return std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major) <
           std::tie(rhs.instance, rhs.interface.id, rhs.interface.version.major);
}
```

`std::set` uniqueness is `!(a<b) && !(b<a)`, so the duplicate-server registration identity on this tree
is exactly `(instance, service id, major)` and the minor version is excluded, matching the
minor-ignoring `Service_database` index. The public `Service_interface_identifier{Id id; Version{major,
minor}}` type is unchanged; exact-major and `client.minor <= server.minor` compatibility rules remain
enforced by `is_interface_compatible`, not by the key. This is a **source reading**; see §6 for the
executed evidence.

---

## 4. The recorded GCC syntax failure — inspection of the actual source

`score/socom/impl/service_identifier.hpp` is 40 lines and **brace-balanced**:

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

`grep '[{}]'` on the file returns exactly those four brace lines (net balance `0`). The recorded
*"extra closing brace at line 39"* is therefore a **stale, pre-correction description** that matches the
earliest prior reports' split-form double close (`}  // namespace socom` + `}  // namespace score`); the
`reproducer` iteration applied the correction and left line 39 blank. **No correction was applied and
none is required.** Corroborating executed evidence (retained, local, unprotected): `gcc-compile` and
`clang-compile` both exit `0` (`.llm_tmp/overnight/obligations/compiler_diagnostics/result.json:1152`
and `:1274`), and the full native build exits `0` (`native_build/result.json:1078`). A genuine
unmatched brace would have failed those.

If a distinct *"cancelled draft"* revision elsewhere still carries the extra brace, it is **not** the
file in this checkout and must be located and corrected by an authorized iteration; this report records
the discrepancy for human disposition.

---

## 5. Test inventory with exact test IDs

### 5.1 `score/socom/test/unit/service_identifier_tests.cpp` — 91 `TEST_F` under `ServiceInstanceIdentifierTest`

Fixture metadata (`SetUp()`): `DerivationTechnique = "boundary-values,equivalence-classes"` and a
`Description`. `TestType` / `Verifies` deliberately unset (no verified native requirement identifier
exists; inventing one is prohibited). All 91 were executed in the focused runs and **all passed** only
after the minor-excluding key; against the pre-correction key 33 failed (`before.json`).

| # | Test ID | # | Test ID |
|---|---------|---|---------|
| 1 | `SameIdentifierIsNotLessThanItself` | 47 | `EmptyServiceIdIsDistinctAndOrdersFirst` |
| 2 | `KeysDifferingOnlyInMinorVersionAreDuplicates` | 48 | `EmptyInstanceIdIsDistinctAndOrdersFirst` |
| 3 | `MinorVersionBoundariesAreDuplicates` | 49 | `EmptyIdKeysCollapseAcrossMinorVersions` |
| 4 | `AllMinorVersionsCollapseToSingleKey` | 50 | `ServiceIdPrefixOrderingIsLexicographic` |
| 5 | `MinorHighBitVariantsAreEquivalent` | 51 | `InstanceIdPrefixOrderingIsLexicographic` |
| 6 | `KeysDifferingInMajorVersionAreDistinct` | 52 | `MajorHighBitAdjacencyIsOrdered` |
| 7 | `MajorVersionBoundariesAreDistinct` | 53 | `KeysDifferingInInstanceAndMinorAreDistinct` |
| 8 | `MajorVersionSweepProducesDistinctKeys` | 54 | `KeysDifferingInMajorAndMinorAreDistinct` |
| 9 | `AdjacentMajorVersionBoundariesAreDistinct` | 55 | `SetFindLocatesMinorVariantAndCountsItOnce` |
| 10 | `KeysDifferingInServiceIdAreDistinct` | 56 | `PropertySortedDomainMatchesSortedIdentityTuples` |
| 11 | `DistinctServiceIdsProduceDistinctKeys` | 57 | `PropertyStrictWeakOrderingAxiomsOnVersionBoundaryDomain` |
| 12 | `EqualServiceIdTextProducesEquivalentKeys` | 58 | `PropertyIdentityEqualityClassesOnVersionBoundaryDomain` |
| 13 | `ServiceIdOrderingIsLexicographic` | 59 | `ConvertedInstanceTextPathsAgreeAtBoundaries` |
| 14 | `KeysDifferingInInstanceAreDistinct` | 60 | `ConvertedPublicIdentityDistinguishesMinorBoundariesWhileKeyCollapses` |
| 15 | `DistinctInstancesProduceDistinctKeys` | 61 | `ServiceIdLadderOrdersLexicographicallyAndDistinctly` |
| 16 | `EqualInstanceTextProducesEquivalentKeys` | 62 | `InstanceIdLadderOrdersLexicographicallyAndDistinctly` |
| 17 | `InstanceOrderingIsLexicographic` | 63 | `MajorVersionLadderOrdersNumericallyAndDistinctly` |
| 18 | `ServiceInstanceMajorMatrixProducesDistinctKeys` | 64 | `MinorVariantsCompareIdenticallyAgainstWholeDomain` |
| 19 | `ServiceInstanceMajorMatrixCollapsesMinorVersions` | 65 | `StdSetCollapsesFiveMinorVariantsOfEveryIdentity` |
| 20 | `ThreeByThreeByThreeMatrixProducesDistinctKeys` | 66 | `EquivalenceIsCompatibleWithStrictOrder` |
| 21 | `ThreeByThreeByThreeMatrixCollapsesMinorVersions` | 67 | `OrderingAgreesWithTupleOrderOnMixedBoundaryDomain` |
| 22 | `KeyEquivalenceDependsOnInstanceServiceIdAndMajor` | 68 | `SingleComponentChangesBreakEquivalenceAcrossAllBases` |
| 23 | `MinorVersionNeverAffectsOrdering` | 69 | `PropertyStrictWeakOrderingOnCombinedRegistrationKeyDomain` |
| 24 | `OrderingOrderIsInstanceThenServiceIdThenMajor` | 70 | `PropertyIdentifierEqualityOnCombinedRegistrationKeyDomain` |
| 25 | `OrderingIsTransitive` | 71 | `ConvertedInterfaceConstructionPathsAgreeAtEveryVersionBoundary` |
| 26 | `EquivalenceIsTransitive` | 72 | `ConvertedInstanceRegistryIdPathAgreesWithTextPaths` |
| 27 | `MajorDifferenceOutweighsMinorDifference` | 73 | `ConvertedKeyRetainsConfigWidthMajorBoundaries` |
| 28 | `InstanceIsThePrimaryOrderingComponent` | 74 | `ServiceIdOrderingIsLexicographicNotNumeric` |
| 29 | `MajorIsTheTertiaryOrderingComponent` | 75 | `InstanceIdOrderingIsLexicographicNotNumeric` |
| 30 | `DistinctKeysAreOrderedInExactlyOneDirection` | 76 | `MajorVersionByteBoundariesAreDistinctAndOrdered` |
| 31 | `StrictWeakOrderingHoldsAcrossMinorVariants` | 77 | `MajorVersionOrderMatchesUnsignedNumericOrder` |
| 32 | `SortingAgreesWithIndependentTupleOrder` | 78 | `MinorVariantsBoundDistinctIdentitiesWithoutBreakingOrder` |
| 33 | `SetUniquenessMatchesDistinctIdentityTupleCount` | 79 | `MinorSweepCollapsesPerIdentityAtEveryMajorBoundary` |
| 34 | `SetIterationFollowsInstanceThenServiceIdThenMajor` | 80 | `SetInsertionResultMatchesEquivalenceAcrossMinorVariants` |
| 35 | `PropertyStrictWeakOrderingAxiomsHoldOnDeterministicDomain` | 81 | `EquivalenceCoincidesWithIdentityOverFixtureCrossProduct` |
| 36 | `PropertyEquivalenceMatchesIdentityTupleOnDeterministicDomain` | 82 | `OrderingIsAntiSymmetricOverFixtureCrossProduct` |
| 37 | `PropertyOrderingIsDeterministicTotalAndTupleConsistent` | 83 | `KeyIdentityIsStableUnderRepeatedMinorRewritesOfTheSameIdentity` |
| 38 | `PropertyEquivalenceClassesMatchDistinctIdentityTupleCount` | 84 | `ConvertedEmptyTextInterfacePathsAgreeAtVersionBoundaries` |
| 39 | `PropertySetUniquenessIsIndependentOfInsertionOrder` | 85 | `ConvertedEmptyTextInstancePathsAgreeWithRegistryPath` |
| 40 | `PublicIdentifierIdentityDistinguishesMajorAndMinorBoundaries` | 86 | `FreshDynamicServiceIdStringViewRegistersAndCollapses` |
| 41 | `ConvertedKeyRetainsInstanceServiceIdMajorAndStoresMinor` | 87 | `FreshDynamicServiceIdRvalueRegistersAndCollapses` |
| 42 | `ConvertedKeyMinorBoundariesCollapseToSingleIdentity` | 88 | `ConvertedInterfaceAndInstanceConstructionPathsAgreeAcrossFullCrossProduct` |
| 43 | `ConvertedKeyMajorBoundariesStayDistinct` | 89 | `ConvertedConfigMinorNarrowingBoundariesCollapseAndDistinguish` |
| 44 | `ConvertedKeyTextAndRegistryConstructionAgreeAtBoundaries` | 90 | `FreshDynamicInstanceIdStringViewRegistersAndCollapses` |
| 45 | `ConvertedKeyCollapsesConfigMinorsThatNarrowAlike` | 91 | `FreshDynamicInstanceIdRvalueRegistersAndCollapses` |
| 46 | `ConvertedKeyIsDeterministicAcrossRepeatedConversions` | | |

### 5.2 `score/socom/test/unit/runtime_tests.cpp` — 33 macros (1 `TEST` + 31 `TEST_F` + 1 `TEST_P`)

Metadata helper `record_registration_key_metadata` sets `DerivationTechnique =
"design-analysis,equivalence-classes"` and a `Description`.

| # | Test ID | Kind |
|---|---------|------|
| 1 | `RuntimeFactoryTest.DefaultConstructorWorks` | `TEST` (`:239`) |
| 2 | `RuntimeTest.RegisterServiceBridgeWithIncompleteCallbacksReturnsCallbacksMissing` | `TEST_F` (`:279`) |
| 3 | `RuntimeTest.RegisterServiceBridgeWitCallbacksReturnsRegistration` | `TEST_F` (`:287`) |
| 4 | `RuntimeTest.BridgeReceivesRequestServiceFunctionCallForUnknownService` | `TEST_F` (`:295`) |
| 5 | `RuntimeTest.BridgeDoesNotReceiveRequestServiceFunctionCallForKnownService` | `TEST_F` (`:303`) |
| 6 | `RuntimeTest.BridgeCreatesServerConnectorInRequestServiceFunctionCallbackAtClientConnectorCreation` | `TEST_F` (`:311`) |
| 7 | `RuntimeTest.ConstructDuplicateReturnsDuplicateServiceError` | `TEST_F` (`:334`) |
| 8 | `RuntimeTest.ConstructDuplicateMultipleTimesReturnsDuplicateServiceError` | `TEST_F` (`:350`) |
| 9 | `RuntimeTest.CreatingServerConnectorDeletingItAndRecreatingReturnsValidServerConnector` | `TEST_F` (`:371`) |
| 10 | `RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError` | `TEST_F` (`:402`) — **slice regression** |
| 11 | `RuntimeTest.ConstructDuplicateSameConfigurationWhileBothConnectorsDisabledReturnsDuplicateServiceError` | `TEST_F` (`:440`) |
| 12 | `RuntimeTest.ConstructDifferentMajorWhileBothConnectorsDisabledReturnsDistinctServerConnectors` | `TEST_F` (`:471`) |
| 13 | `RuntimeTest.ConstructDifferentInstanceWhileBothConnectorsDisabledReturnsDistinctServerConnectors` | `TEST_F` (`:505`) |
| 14 | `RuntimeTest.ConstructDifferentServiceIdWhileBothConnectorsDisabledReturnsDistinctServerConnectors` | `TEST_F` (`:538`) |
| 15 | `RuntimeTest.ConstructDuplicateMinorBoundariesWhileBothConnectorsDisabledReturnsDuplicateServiceError` | `TEST_F` (`:573`) |
| 16 | `RuntimeTest.ConstructDuplicateWithSmallerMinorWhileBothConnectorsDisabledReturnsDuplicateServiceError` | `TEST_F` (`:607`) |
| 17 | `RuntimeTest.ConstructDuplicateRepeatedlyWhileBothConnectorsDisabledKeepsSlotHeld` | `TEST_F` (`:642`) |
| 18 | `RuntimeTest.ConstructDuplicateWhileFirstConnectorEnabledReturnsDuplicateServiceError` | `TEST_F` (`:694`) |
| 19 | `RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionWhileFirstConnectorEnabledReturnsDuplicateServiceError` | `TEST_F` (`:726`) |
| 20 | `RuntimeTest.ConstructDifferentInstanceWhileFirstConnectorEnabledReturnsDistinctServerConnectors` | `TEST_F` (`:763`) |
| 21 | `RuntimeTest.ConstructDifferentServiceIdWhileFirstConnectorEnabledReturnsDistinctServerConnectors` | `TEST_F` (`:796`) |
| 22 | `RuntimeTest.ConstructDuplicateMinorBoundariesWhileFirstConnectorEnabledReturnsDuplicateServiceError` | `TEST_F` (`:832`) |
| 23 | `RuntimeTest.ConstructDuplicateWithSmallerMinorWhileFirstConnectorEnabledReturnsDuplicateServiceError` | `TEST_F` (`:869`) |
| 24 | `RuntimeTest.ConstructDuplicateRepeatedlyWhileFirstConnectorEnabledKeepsSlotHeld` | `TEST_F` (`:905`) |
| 25 | `RuntimeTest.ConstructDifferentMajorWhileFirstConnectorEnabledReturnsDistinctServerConnectors` | `TEST_F` (`:951`) |
| 26 | `RuntimeTest.ConstructDuplicateAfterEnabledConnectorDestroyedReturnsValidServerConnector` | `TEST_F` (`:986`) |
| 27 | `RuntimeTest.ConnectorDestroyedAfterRuntimeDoesNotCrash` | `TEST_F` (`:1021`) |
| 28 | `RuntimeTest.ConstructDuplicateAfterDisabledConnectorDestroyedWithChangedMinorVersionReturnsValidServerConnector` | `TEST_F` (`:1045`) |
| 29 | `RuntimeTest.ConstructDuplicateAfterEnabledConnectorDestroyedWithChangedMinorVersionReturnsValidServerConnector` | `TEST_F` (`:1091`) |
| 30 | `RuntimeTest.DestroyingOneMajorSlotKeepsOtherMajorSlotOccupied` | `TEST_F` (`:1141`) |
| 31 | `RuntimeTest.DestroyingOneInstanceSlotKeepsOtherInstanceSlotOccupied` | `TEST_F` (`:1197`) |
| 32 | `RuntimeTest.DestroyingOneServiceIdSlotKeepsOtherServiceIdSlotOccupied` | `TEST_F` (`:1253`) |
| 33 | `RuntimeBridgeTest.CreationOfClientsWillCallRequestServiceFunction` | `TEST_P` (`:1311`) |

---

## 6. Module verification report — executed results

All figures below are **retained host artifact readings** (`origin: local_unprotected_measurement`,
`engineering_acceptance: pending`), **not** acceptance. Test-ID granularity is available for the
focused identifier suite only (its gtest JSON); the native `socom_test` target reports at target level,
not per-`TEST_F`.

### 6.1 Focused identifier translation unit (GCC, UBSan; the failed-then-fixed slice regression)

`service_identifier.cpp` + `string_registry.cpp` + `service_identifier_tests.cpp`, `g++-12 -std=c++17
-Wall -Wextra -Werror`, `mode: ubsan`, compiler sha256 `88315fd2…`.

| State | Tests | Pass | Fail | Disabled | Errors | Compile | Test | Source |
|-------|------:|-----:|-----:|---------:|-------:|--------:|-----:|--------|
| `before.json` | 91 | 58 | **33** | 0 | 0 | exit 0 | exit 1 | `.llm_tmp/overnight/validation/before.json:2-4` |
| `after.json` | 91 | **91** | **0** | 0 | 0 | exit 0 | exit 0 | `.llm_tmp/overnight/validation/after.json:2-4` |

`check-result` = `0`; `measurement.json` `changed_paths =
["score/socom/test/unit/service_identifier_tests.cpp"]`, `engineering_acceptance: pending`,
`full_native_tests: not_executed`. The pre-fix failure set is exactly the minor-collapse cases
(e.g. `KeysDifferingOnlyInMinorVersionAreDuplicates` at `:174`, `MinorVersionBoundariesAreDuplicates`
`:182`, `AllMinorVersionsCollapseToSingleKey` `:192`, `MinorHighBitVariantsAreEquivalent` `:203`,
`MinorVersionNeverAffectsOrdering` `:430`, matrix collapses `:372`/`:402`, …), i.e. the requested
failing regression reproduced and then passed after the key change.

### 6.2 Focused compiler diagnostics (GCC 12.3 and Clang 19)

`.llm_tmp/overnight/obligations/compiler_diagnostics/result.json` — status `completed`; all eight
commands exit `0`: `gcc-gtest-0`, `gcc-gtest-1`, `gcc-compile`, `gcc-tests`, `clang-gtest-0`,
`clang-gtest-1`, `clang-compile`, `clang-tests`. `limits`: *"Focused executable only; GCC 12.3 / Clang
19 differ from native toolchain pins"* and *"GoogleTest compiled separately with warnings retained;
-Werror on target and tests"*.

### 6.3 Focused sanitizer / analyzer runs

| Check | Result | Artifact |
|-------|--------|----------|
| ASan+LSan+UBSan focused | compile exit 0; tests exit 0 | `focused_asan_lsan/result.json:1115` |
| TSan focused | compile exit 0; **tests exit 66** (`unexpected memory mapping`) | `focused_tsan/result.json:1114` |
| Valgrind memcheck focused | compile exit 0; memcheck exit 0 | `focused_memcheck/result.json:1116` |
| cppcheck focused | **exit 2** (advisories, e.g. passed-by-value, out of slice) | `focused_cppcheck/result.json:1081` |
| clang-tidy focused | `--verify-config` **exit 1** (config rejected) | `focused_clang_tidy/result.json:1077` |
| focused coverage | compile 0 / tests 0 / gcovr 0 | `focused_coverage/result.json:1091,1115,1151` |

### 6.4 Native Bazel legs (`//...`, jobs=2)

| Check | Outcome | Artifact |
|-------|---------|----------|
| `bazel build //...` | exit 0 | `native_build/result.json:1078` |
| `bazel test //...` | exit 0; **21/29 executed, 21 pass, 8 skipped**; `//score/socom/test/unit:socom_test` PASSED | `native_tests/tests.stdout:31`, `:16` |
| native ASan/LSan/UBSan (`//score/... //tests/...`) | exit 0; **19/27 executed, 19 pass, 8 skipped** | `native_sanitizers/sanitizers.stdout:29` |
| native TSan | exit 0 but **only 5/27 executed** (19 cached, 8 skipped) → **incomplete** | `native_tsan/tsan.stdout:29` |
| native coverage (`COVERAGE_THRESHOLD=73`) | coverage exit 0; report exit 0; **repo CI threshold 73 is not the platform 85/100 goal** | `native_coverage/result.json:1080,1110,1117-1119` |
| native docs `//:docs` | **exit 2** | `native_docs/result.json:1078` |
| native traceability (`unit_tests`,`component_tests`=0; `//:docs`=2; `traceability_gate`=1) | **failure** | `native_traceability/result.json:1079,1105,1135` |
| native integration QEMU | **exit 1** | `native_integration/result.json:1080` |
| native lint clang-tidy check | **timeout exit 124**; ruff exit 0 | `native_lint/result.json:1079,1105` |
| native performance benchmarks / profiling | **both timeout exit 124** | `native_performance/result.json:1081,1110` |

The **8 skipped** targets are `//tests/benchmarks:e2e_benchmarks`, `…:e2e_benchmarks_profiling`, and the
six `//tests/integration_test:…` targets — i.e. the feature/integration/e2e layer is **unexecuted** in
the native legs (and the separate QEMU leg failed).

### 6.5 Coverage

Focused `service/socom/impl/` production filter (tests and third-party excluded):

| Metric | Value | Platform goal |
|--------|------:|---------------|
| Line | **36/36 = 100.0 %** | 85 % (QM) / 100 % (safety) |
| Branch | **11/14 = 78.6 %** | 85 % (QM) / 100 % (safety) |

`safety_class: unknown_requires_authorized_selection`; `complete_target_scope: false`
(`focused_coverage/result.json:1156-1174`). **Branch coverage is below both goals; no deviation is
accepted.** The native coverage leg only demonstrates the repository CI threshold `73`, which the
artifact itself flags as not the platform acceptance figure.

### 6.6 Static analysis / security

| Check | Status | Findings / notes |
|-------|--------|------------------|
| `compiler_diagnostics` | `completed` | GCC+Clang focused compile/test all exit 0 with `-Werror`. |
| `focused_clang_tidy` | `findings_or_execution_failure` | native analyzer config incompatible; blocker: *"no replacement called MISRA"*. |
| `native_lint` | `findings_or_execution_failure` | clang-tidy timeout 124; ruff clean. |
| `focused_cppcheck` | `findings_or_execution_failure` | exit 2; limits: *"Optional complementary checks; no inferred MISRA rule coverage"*. |
| `codeql_security` | `findings_or_execution_failure` | `scan_runs: 1`; 32 SARIF findings, **all in vendored `.llm_tmp/googletest`** (e.g. `cpp/path-injection`, `cpp/include-non-header`, `cpp/fixme-comment`, `cpp/equality-on-floats`); `"level": null`; limit *"Focused linked executable, not full target extraction; dependency findings retained"*. |
| `codeql_misra` | `findings_or_execution_failure` | `scan_runs: 1`; findings include **`cpp/misra/external-linkage-not-declared-in-header-file-misra` on `score/socom/test/unit/service_identifier_tests.cpp`** (GTest `TEST_F` macro expansions at `:1882,1929,1982,2012,2060,2103,2150,2181`, …) plus many vendored-googletest findings; blockers: *"MISRA applicability/mapping draft and incomplete; default suite omits manual/audit obligations; compiled query qualification and human deviations pending"*. |
| `secret_dependency_checks` | `findings_or_execution_failure` | gitleaks exit 1; blocker: *"No adopted vulnerability database/ecosystem mapping or GitHub dependency scan receipt; dependency inventory is not a vulnerability scan"*; dependency inventory includes `googletest 1.18.0`, `google_benchmark 1.9.5`, `rules_cc 0.2.22`, etc. |
| `format_precommit` | `findings_or_execution_failure` | `format.check` timeout 124; `reuse lint` exit 1; `pre-commit` exit 0; `mod tidy`/`mod deps` exit 0; limit *"Formatting/pre-commit mutations occur only in this disposable collector copy"*. |
| `cross_compilation` | `completed_with_blockers` | x86_64 and aarch64 `bazel build //score/... //tests/...` exit 0; blocker: *"QNX SDK entitlement and target execution not configured; no credential acquired"*. |
| `tool_assurance` | `completed_with_blockers` | 15 tools versioned/sha256-recorded; blockers: tool qualification/acceptance requires authorized humans; Coverity not installed; memcheck optional. |
| `process_checks` | `completed_with_blockers` | lexical metadata inventory only; records `service_identifier_tests.cpp` = 91 macros, `runtime_tests.cpp` = 33 macros, `record_properties` = `{DerivationTechnique, Description}`; blockers: *"Lexical metadata inventory cannot prove semantic requirement coverage; Safety/QM applicability and approved tailoring unknown; Independent inspection and acceptance required; External AoU and full integration verification require scoped review"*. |
| `rework_progress` | `completed` | `source_changed_this_round: false`, `rework_requested: false`, `stop_reason: "One complete pass requested; unresolved findings stay pending"`. |

### 6.7 Tool inventory (versions / hashes, from `tool_assurance/result.json`)

`g++-12` `88315fd2…`, `clang++` (LLVM 19.1.7) `79698463…`, `clang-tidy` `5f733fae…`, `bazel`
(`USE_BAZEL_VERSION=8.6.0`) `9860da9c…`, CodeQL 2.21.4 `d38df35e…`, `gcov-12` `dcaf103b…`, `gcovr`
`59cd3ede…`, `cppcheck` `d2268c85…`, `clang-format` `e93c5619…`, `pre-commit` `904701a1…`, `reuse`
`9ffc7483…`, `qemu-system-x86_64` `55862c76…`, `perf` `2d095308…`, `valgrind` `4652774b…`, `gitleaks`
`88f91962…`.

---

## 7. Release-evidence archive index

| # | Obligation / check | Artifact directory | Result file / key signals | Status label |
|---|--------------------|--------------------|---------------------------|--------------|
| 1 | `process_checks` | `.llm_tmp/overnight/obligations/process_checks/` | `result.json` (91 + 33 macros), `collection-result` | `completed_with_blockers` |
| 2 | `rework_progress` | `…/rework_progress/` | `result.json`, `collection-result` | `completed` |
| 3 | `compiler_diagnostics` | `…/compiler_diagnostics/` | `result.json`; 8 commands exit 0 | `completed` |
| 4 | `native_build` | `…/native_build/` | `result.json`; `build` exit 0 | `completed` |
| 5 | `native_tests` | `…/native_tests/` | `result.json`; `tests.stdout` 21/29 pass, 8 skipped | `completed` |
| 6 | `native_sanitizers` | `…/native_sanitizers/` | `result.json`; `sanitizers.stdout` 19/27 pass | `completed` |
| 7 | `native_tsan` | `…/native_tsan/` | `result.json`; `tsan.stdout` 5/27 executed | `completed` (incomplete) |
| 8 | `native_coverage` | `…/native_coverage/` | `result.json`; thresholds 73 only | `completed` |
| 9 | `focused_coverage` | `…/focused_coverage/` | `result.json`, `coverage-summary.json`, `tests.json` | `completed` |
| 10 | `focused_asan_lsan` | `…/focused_asan_lsan/` | `result.json`, `tests.json` | `completed` |
| 11 | `focused_memcheck` | `…/focused_memcheck/` | `result.json`, `memcheck.xml` | `completed` |
| 12 | `focused_tsan` | `…/focused_tsan/` | `result.json`; tests exit 66 | `findings_or_execution_failure` |
| 13 | `focused_cppcheck` | `…/focused_cppcheck/` | `result.json`; exit 2 | `findings_or_execution_failure` |
| 14 | `focused_clang_tidy` | `…/focused_clang_tidy/` | `result.json`; exit 1 | `findings_or_execution_failure` |
| 15 | `native_lint` | `…/native_lint/` | `result.json`; clang-tidy 124 | `findings_or_execution_failure` |
| 16 | `codeql_security` | `…/codeql_security/` | `result.json`, `results.sarif` | `findings_or_execution_failure` |
| 17 | `codeql_misra` | `…/codeql_misra/` | `result.json`, `results.sarif` | `findings_or_execution_failure` |
| 18 | `native_docs` | `…/native_docs/` | `result.json`; exit 2 | `findings_or_execution_failure` |
| 19 | `native_traceability` | `…/native_traceability/` | `result.json`; docs 2 / gate 1 | `findings_or_execution_failure` |
| 20 | `native_integration` | `…/native_integration/` | `result.json`; QEMU exit 1 | `findings_or_execution_failure` |
| 21 | `native_performance` | `…/native_performance/` | `result.json`; 124 ×2 | `findings_or_execution_failure` |
| 22 | `format_precommit` | `…/format_precommit/` | `result.json`; format 124 / reuse 1 | `findings_or_execution_failure` |
| 23 | `secret_dependency_checks` | `…/secret_dependency_checks/` | `result.json`, `secret-findings.json`; gitleaks 1 | `findings_or_execution_failure` |
| 24 | `cross_compilation` | `…/cross_compilation/` | `result.json`; x86/aarch64 0, QNX unconfigured | `completed_with_blockers` |
| 25 | `tool_assurance` | `…/tool_assurance/` | `result.json`; 15 tools versioned | `completed_with_blockers` |
| 26 | Host validation | `.llm_tmp/overnight/validation/` | `check-result`=0; `measurement.json`; `before.json`; `after.json`; `*-compile.*`, `*-test.*` | local capture (not acceptance) |

**Collection vs. pass.** Each `*/collection-result` file records only that the host *retained* the
artifacts (the completed queue nodes embed `blob://sha256/...` references). Retention is **not**
passing; 11 of the 24 checks above are labelled `findings_or_execution_failure`.

---

## 8. Earlier attempts and their disposition

| Iteration / attempt | Recorded outcome | Disposition |
|---------------------|------------------|-------------|
| Header split-form double close (`}  // namespace socom` + `}  // namespace score`) | Earliest reports found the header **broken** | Repaired by the `reproducer` iteration to the nested form; line 39 blank today. Stale description only. |
| Pre-fix key (minor included) | `before.json`: 91 tests / **33 failures** | Fixed by excluding `minor` in `operator<`; `after.json` 91/0. |
| Focused GCC compile of identifier TU | exit 0 with empty stderr | Corroborates balanced header. |
| AST/clang-tidy config | rejected (`--verify-config` exit 1); native check timed out 124 | **Unresolved**; no MISRA-named replacement run. |
| Clang dependency deprecation | historically blocked | Not re-run cleanly here; CodeQL/MISRA vendor findings retained. |
| TSan | focused exit 66; native 5/27 executed | **Incomplete**; concurrency evidence gap. |
| Performance | benchmarks/profiling timeout 124 | **Not measured.** |
| Docs/traceability | docs exit 2 (no git remote), gate exit 1 (`schema_version`) | **Failed**; slice reported as *"missing some properties"* (`TestType`/`Verifies` unset). |
| `reuse lint` / gitleaks | reuse 1 (non-slice files); gitleaks 1 (out-of-slice artifacts) | **Not clean**; out-of-slice hits, disposition required. |
| QEMU integration | exit 1 | **Failed.** |

Recording of these attempts is not a pass; each remains open until an authorized human disposes it.

---

## 9. Obligations status (none satisfied)

All nine pinned `.llm_tmp/context/obligations/source-index.json` entries were read; every entry is
`"native_acceptance": "not_inferred"`. `authority.json`: `engineering_acceptance: pending`,
`human_reviews: unanswered`, `safety_class: unknown`, `codeql_scope: "Public Apache-2.0
eclipse-score/inc_someip_gateway; no upload"`, instruction *"Restart the failed queue for one complete
pass through all obligations"*.

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Freedom from compiler warnings & errors (100 %) | `verification_plan.rst` (criterion 9) | **PARTIAL / NOT SATISFIED** — focused GCC+Clang `-Werror` exit 0 and native build exit 0, but no full-native toolchain-pinned sign-off |
| Static code analysis, findings classified | `code_analysis.rst`; `verification_process.rst` (`gd_req__verification_sca_classification`) | **NOT SATISFIED** — clang-tidy rejected/timed out; CodeQL findings unclassified; cppcheck advisory-only; **no authorized Critical/High/Medium/Low classification** |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` | **UNKNOWN — NOT CLAIMED** — mapping is `:status: draft`; rule applicability not asserted; CodeQL MISRA findings on GTest macros pending human review |
| Structural statement coverage | `verification_plan.rst` (criterion 1) | **MET for focused TU only** — 36/36 = 100 % |
| Structural branch coverage | `verification_plan.rst` (criterion 2) | **NOT MET** — 11/14 = 78.6 %, below 85 %/100 %; no accepted deviation |
| Unit/component testing executed and recorded | `verification_plan.rst` (criteria 6–7); `verification_guideline.rst` | **PARTIAL (local)** — focused 91/91; native `socom_test` PASSED; all local/unprotected, no acceptance |
| Interface / requirements-based / resource / fault-injection test types | `verification_process.rst` | **NOT PERFORMED / applicability not inferred** — no harness |
| Boundary / equivalence derivation | `verification_process.rst` | **EXECUTED (focused) / PARTIAL** |
| Fuzzy testing technique | `verification_plan.rst` | **NOT EXECUTED / NOT CLAIMED** |
| Linking tests to requirements (record properties) | `verification_process.rst` (`gd_req__verification_link_tests_cpp`) | **PARTIAL / NOT DONE** — `DerivationTechnique`/`Description` set; `TestType`/`Verifies` unset (no verified identifier); docs run confirms *"missing some properties"* |
| External-component AoUs verified | `verification_process.rst` (`gd_req__verification_external_aou`) | **NOT SATISFIED** — `SCORE_LANGUAGE_FUTURECPP_ASSERT` semantics, `score_baselibs`, googletest AoU not integration/static verified |
| Independence of verification / review | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered; approver ≠ author not established |
| Implementation inspection checklist IMPL_01…IMPL_03 | `inspection_checklist.rst` | **NOT FILLED** — `:status: draft`, blank template |
| Tool identification / evaluation / qualification | `tool_management.rst` | **IDENTIFIED, NOT QUALIFIED** — `tool_assurance` `completed_with_blockers` |
| Docs / traceability gate | repository CI | **FAILED** — docs exit 2; traceability gate exit 1 |
| Sanitizers | `code_analysis.rst` | **PARTIAL** — ASan/LSan/UBSan and memcheck pass; **TSan not clean/complete** |
| Secret / dependency checks | CI | **NOT CLEAN** — gitleaks exit 1 (out-of-slice); no vulnerability DB |
| Format / reuse | CI | **NOT CLEAN** — format timeout; `reuse lint` exit 1 (non-slice) |
| QEMU integration | `verification_plan.rst` | **FAILED** — exit 1 |
| Performance | `verification_plan.rst` | **NOT MEASURED** — 124 ×2 |
| Cross-compilation | `development_plan.rst` | **PARTIAL** — x86_64/aarch64 build; QNX not executed |
| Obligation-collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **RETAINED, NOT PASSING** — mix of `completed`, `completed_with_blockers`, `findings_or_execution_failure` |
| Native acceptance | `source-index.json` | **`not_inferred` for every entry** |

**Explicit non-satisfaction statement.** Missing full-native sign-off, the unclassified/incomplete
static analysis, the draft MISRA mapping, the blank inspection checklist, the failed docs/traceability/
reuse/format/integration gates, the incomplete TSan and performance runs, the unverified external AoUs,
the below-goal branch coverage, the unknown safety class, the un-inferred applicability and the
unanswered human reviews mean **none of the checked obligations may be treated as satisfied**. A
successful collection node proves *retention*, not passing; here the retained results include explicit
failures and non-runs.

---

## 10. Blockers and deviations (all open)

1. **TSan incomplete** — focused exit 66; native only 5/27 executed. Concurrency on the key/registration
   path unverified. *No deviation accepted.*
2. **Branch coverage 78.6 %** vs. platform 85 %/100 %. *No deviation accepted.*
3. **Static-analysis classification absent** — clang-tidy rejected/timed out; CodeQL findings
   unclassified; cppcheck advisory-only.
4. **MISRA mapping draft / CodeQL MISRA applicability** — `misra_mapping.rst:status: draft`; CodeQL
   MISRA findings on GTest macro expansions of the slice's test file pending human disposal.
5. **Docs / traceability gate failed** — `TestType`/`Verifies` unset; no honest requirement identifier.
6. **QNX cross-compilation not executed** — SDK entitlement/credential not configured.
7. **QEMU integration failed**; feature/e2e/integration targets skipped in native legs.
8. **Performance not measured** (timeouts).
9. **Secret/dependency** — gitleaks hit (out-of-slice) and no vulnerability DB.
10. **Format timing out / `reuse lint` failing** (non-slice files).
11. **External AoUs unverified** — `SCORE_LANGUAGE_FUTURECPP_ASSERT` semantics undetermined here.
12. **Human gates unanswered** — engineering acceptance pending, safety class unselected, independent
    review not done; no upload permitted.

---

## 11. Notice preservation

- No source, build, test, config, `NOTICE`, `LICENSE` or `REUSE.toml` file was created, edited or
  deleted; only this report was written. All prior reports (`.llm_tmp/overnight/prior-reports/`, 38
  files; `.llm_tmp/overnight/reports/`, all earlier files) and all host artifacts
  (`.llm_tmp/overnight/validation/`, `.llm_tmp/overnight/obligations/`) were read only and preserved.
- The flagged header `score/socom/impl/service_identifier.hpp` retains its Apache-2.0/SPDX header
  (`:1-12`) and was left unchanged because it is already brace-balanced (§4). The sibling `.cpp`, both
  BUILD files and both candidate test files retain their Apache-2.0/SPDX headers.
- This report itself carries the Apache-2.0 header. No licensed MISRA rule text is reproduced; only
  native rule/query identifiers, source hashes and file locations are cited.

---

## 12. Pending human review checklist

- [ ] **Confirm §4:** the header is brace-balanced (braces `:19,:29,:32,:38`; line `:39` blank; net
      balance 0) and the *"extra closing brace at line 39"* is stale or refers to a different revision.
      No source correction is required in this checkout.
- [ ] **Resolve the instruction conflict** ("inspect and correct the actual source" vs. "only that
      report may be written"); confirm inspection-only was intended and locate any distinct cancelled
      draft if it still carries the brace.
- [ ] **Confirm the bounded key decision:** `minor` is not part of the duplicate-server registration
      key; identity `(instance, service id, major)`; public interface and exact-major /
      minimum-minor rules unchanged.
- [ ] **Accept or amend the coverage position:** focused line 100 % / branch 78.6 % vs 85 %/100 %; add
      branch cases or record an approved deviation. Do not re-report repo CI threshold 73 as platform
      coverage.
- [ ] **Repair and re-run the failing tools:** clang-tidy config/timeout; TSan so the full suite runs;
      CodeQL full-target extraction; docs/traceability gate; `format.check`; `reuse lint`; gitleaks
      disposition; QEMU integration; performance benchmarks.
- [ ] **Classify the CodeQL/analyzer findings** (including `cpp/misra/external-linkage-not-declared-in-
      header-file-misra` on the test file) as Critical/High/Medium/Low with a Quality Manager and
      committer.
- [ ] **Complete the MISRA mapping and inspection checklist**, and author the missing `socom` component
      requirement(s) so `TestType`/`Verifies` can be completed without invention.
- [ ] **Verify external-component AoUs** (`SCORE_LANGUAGE_FUTURECPP_ASSERT`, `score_baselibs`,
      googletest).
- [ ] **Select the safety class** via the authorized role; do not infer it from the `:safety: ASIL_B`
      document attribute.
- [ ] **Schedule independent human review** (approver ≠ author), record engineering acceptance, and
      keep the implementation unpublished per `codeql_scope` (no upload).

---

*End of module verification report & release-evidence archive index (review draft). Local, unprotected,
scoped. No engineering acceptance; human reviews unanswered; full native runtime tests pending. Every
statement is a local reading of the working tree, a retained host artifact reading, or an
explicitly-labelled logical consequence — none is acceptance, review approval, publication, or a full
native run. A successful collection node evidences retention only, not that any check passed.*
