<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — duplicate-server registration-key unit matrix (actual-source inspection + coverage map)

**Document type:** review draft (actual-source inspection + existing key-matrix coverage map + expansion status + obligations status).

**Date:** 2026-10-03
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version handling in socom* (issue #84)
**Run / branch:** `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ`; current HEAD `406474b`
(`fabro(01M3ZRSDK2XQAF1H48VWTPKQNZ): node_c732605366498064fa626567 (success)`), per the run
environment and the recent-commit list. Completed stages supplied with this task:
`node_3752dc1af9e2f3b0ee1454f2`, `node_51f7ccb6b2715b106cf242f4`, `node_edd8fcbae2fee64d3bbd0c31`,
`node_d2fdb79acfbec37dfb74066b`, `node_c732605366498064fa626567` (all success).
**Verified baseline commit:** `f8a196c3b16d5172d898394ab99b0ed81346d63d`
(`.llm_tmp/context/source-manifest.json:3`).
**Status:** **local, unprotected, scoped.** No engineering acceptance exists. Human reviews are
unanswered. Full native runtime tests are pending. Nothing in this document is acceptance, review,
publication, or a full native run.

> **Tool / write boundary observed.** This iteration used only `read_file`, `grep`, `glob`, and
> `write_file`. No `shell`, no delegation, no web access, no approval, no publishing, and no
> engineering acceptance was performed. One `edit_file` application against a candidate test path
> was refused by the environment ("Overnight tool/path boundary"); it produced no output and no
> change, and `edit_file` is not in the permitted tool set for this node. The task permits changing
> only the six named candidate source paths and this report; of those, **exactly one file was
> written — this report** (`/workspace/.llm_tmp/overnight/reports/unit_matrix.md`). No source,
> build, test, config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was created, edited, or deleted,
> and every prior report was preserved (section 9).

> **Premise reconciliation (inspect before editing).** The task records "a measured GCC syntax
> failure: an extra closing brace in `score/socom/impl/service_identifier.hpp` at line 39" and
> directs that the actual source be corrected before the tests are expanded. Direct inspection of
> the actual working tree this iteration (direct `read_file` + `grep`, section 2) shows the header
> is **already brace-balanced**: the only brace-bearing lines are `:19` (`namespace score::socom {`),
> `:29` (`struct Service_instance_identifier final {`), `:32` (`};`) and `:38` (the single
> `}  // namespace score::socom`); line `:39` is **blank**. Two openers and two closers give a net
> brace balance of `0`; there is no third, unmatched closing brace. Re-introducing a broken brace
> so it could be "fixed", or deleting a needed brace to imitate a correction, would itself be the
> regression this node exists to prevent. The described defect is the stale pre-correction
> description that survives only in the earliest preserved prior reports, not the file compiled
> today.

> **The requested key-matrix expansion is already present on disk.** The five requested dimensions
> (service IDs, instance IDs, major versions, minor boundaries, equality/ordering consistency) are
> already exercised by **87 `TEST_F`** cases in `score/socom/test/unit/service_identifier_tests.cpp`
> (section 4). This iteration verified and mapped that coverage. Duplicating an existing
> deterministic matrix would add no coverage; the one residual gap identified (first-time dynamic
> insertion through the **instance-id** registry, section 5) could not be appended without
> rewriting the entire 2041-line file with no compiler available, which would risk introducing a
> syntax failure — precisely the class of defect this node is meant to remove. It is recorded as
> the concrete next expansion instead.

---

## 0. Summary

1. **Recorded syntax failure — inspected; not present.** `score/socom/impl/service_identifier.hpp`
   is 40 lines with exactly four brace-bearing lines (`:19`, `:29`, `:32`, `:38`) and a blank `:39`
   (section 2). Net brace balance is `0`; no source edit was applied because none is required, and
   the permitted tool set excludes `edit_file`.
2. **Key semantics re-verified.** The duplicate-server key's only operator,
   `Service_instance_identifier::operator<`, orders by `(instance, service id, major)`, so the
   **minor version is excluded** from the identity
   (`score/socom/impl/service_identifier.cpp:28-29`), matching the deliberately minor-ignoring
   `Service_database` index (`score/socom/impl/runtime_impl.hpp:116-134`). The public
   `Service_interface_identifier`/`Version` representation, its `operator==`, `operator<` and
   `std::hash` remain untouched (section 3).
3. **Key matrix present and mapped.** `service_identifier_tests.cpp` carries **87 `TEST_F`** cases
   under `ServiceInstanceIdentifierTest` (`:168`…`:2012`); `runtime_tests.cpp` carries
   **31 `TEST_F` + 1 `TEST` + 1 `TEST_P`**, including the runtime minor-only duplicate regression
   `ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError` (`:402-431`).
   Section 4 maps the 87 key cases to the five requested dimensions.
4. **Nothing was compiled or executed.** Every expected result is derived from the source ordering
   and from `std::set` / strict-weak-ordering semantics, not observed.
   `.llm_tmp/overnight/validation/` and `.llm_tmp/overnight/obligations/*/result.json` are **absent
   from this checkout**. **No obligation is treated as satisfied** (sections 7 and 8).

---

## 1. Binding to the verified baseline, prior reports, host feedback, obligations

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` | `.llm_tmp/context/issue-snapshot.json:2-4` |
| Title | *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:3` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` (unchanged) | `.llm_tmp/context/issue-snapshot.json:19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**: service-instance identifier = `service id + major + minor + instance id`; service
identifier = `service id + major`; FindService = `service id + major + optional<minor> +
optional<instance>`; and the proposal to "exclude the minor version and make it a property of the
service instance". The FindService `major = FF` AUTOSAR case is called theoretically possible but
not useful. There is **no comment and no acceptance record** in the snapshot, so none of it is
binding.

### 1.2 Verified baseline and current tree

| Item | Value | Source |
|------|-------|--------|
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |
| Current branch | `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ` | run environment |
| Current HEAD | `406474b` — `node_c732605366498064fa626567 (success)` | recent-commit list |

Binding is **by baseline commit**, not by run HEAD. Earlier reports reference other run IDs on the
same baseline commit, so they remain admissible prior evidence for this slice. No hashing tool is
available in this task, so the working tree was **not** re-hashed; the direct source reads in
sections 2–4 are authoritative for this report.

### 1.3 In-scope candidate files (the only writable source paths)

From `.llm_tmp/context/candidate-files.json:1-25` (baseline blobs cross-checked against the `files`
array of `.llm_tmp/context/source-manifest.json`):

| File (repo-relative) | Baseline git blob | Baseline present | Current working tree (read this iteration) |
|----------------------|-------------------|------------------|--------------------------------------------|
| `score/socom/BUILD` | `3477ea0851fdcd82ec6ea9d71424013cbdf41962` | yes | `socom` lib `:24-41`; `testonly` `impl_service_identifier` exposure `:43-54` |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e22355242009fe20dada2a9a0d0c7a9c7` | yes | key identity `(instance, service id, major)`; `minor` excluded (`:28-29`) |
| `score/socom/impl/service_identifier.hpp` | `c8bae7908da9f087c518934f7b9f8d86db9a20ec` | yes | **brace-balanced**, 40 lines; line `:39` blank (section 2) |
| `score/socom/test/unit/BUILD` | `3c03a7b14286051f97fa5022206564bd63645171` | yes | `socom_test` globs `*.cpp`; deps wired (`:16-29`) |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab726db8bf994c960045d6fd7fdf84d7395` | yes | 31 `TEST_F` + 1 `TEST` + 1 `TEST_P`; minor-only regression `:402-431` |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(none — `null`)* | no (manifest expects a new file) | **87 `TEST_F`** matrix present; `SetUp()` metadata `:42-65` |

The `null` baseline blob for `service_identifier_tests.cpp` is the manifest's expectation of a
**new** unit-test file; it exists on disk only in the un-merged working tree (the task's "cancelled
draft"), never in the baseline. A `glob` for `**/service_identifier*` returns exactly three paths
(`impl/service_identifier.cpp`, `impl/service_identifier.hpp`,
`test/unit/service_identifier_tests.cpp`), so there is **no second, differently-braced copy** of
the header in this checkout.

### 1.4 Prior reports read and preserved

- `.llm_tmp/overnight/prior-reports/` — **38 files present**, all preserved; `unit_matrix.md`,
  `key_fix.md`, `invariants.md`, `callsites.md`, `reproducer.md`, `scope.md`, `ordering_tests.md`,
  `conversion_tests.md`, `runtime_disabled.md`, `runtime_enabled.md`, `lifetime_tests.md`,
  `test_metadata.md`, and `repair_unit_matrix`-related references were read/cross-checked; the
  remainder were preserved unchanged. (`repair_unit_matrix.md` and a host addendum
  `obligation-addendum.md` are referenced by some reports but are **not present** in this checkout.)
- `.llm_tmp/overnight/reports/` — read, not modified: `scope.md`, `invariants.md`, `callsites.md`,
  `reproducer.md`, `key_fix.md` (the five earlier nodes of this run). This document adds
  `unit_matrix.md`.

Derived sequence across the preserved reports: `scope.md` (bounded the slice; identified the
key/index identity gap) → `invariants.md` (I-4 baseline key included `minor`; I-9 record index
ignores it; I-11 the resulting gap) → `callsites.md` (call-site map) → `reproducer.md` (header brace
correction + focused red regression) → `key_fix.md` / `unit_matrix.md` (drop `minor` from the
ordering; expand the key tests) → `ordering_tests.md` / `conversion_tests.md` → `runtime_disabled.md`,
`runtime_enabled.md`, `lifetime_tests.md` → `test_metadata.md`.

**Reconciliation of the brace claims across prior reports.** The earliest reports quote lines 38-39
as the split-form double close (`}  // namespace socom` + `}  // namespace score`) and record the
header as **broken**; every later report records it as **already balanced**. The actual source read
this iteration matches the later set: the correction is already applied, and line 39 is blank in
place of the removed brace.

### 1.5 Host validation feedback and obligation-collection results

- **Host feedback under `.llm_tmp/overnight/validation/`: absent from this checkout.** `glob`
  `.llm_tmp/overnight/**/*` returns no `validation/` entry; there is no host feedback to reconcile
  against.
- **Obligation-collection results under `.llm_tmp/overnight/obligations/`: absent from this
  checkout.** `glob` `.llm_tmp/overnight/**/*` returns no `obligations/` entry and no
  `*/result.json`. Earlier reports *retain summaries* of host artifacts (`check-result: 0`;
  `measurement.json` `origin: local_unprotected_measurement`, `initiator: Fabro host hook`,
  `engineering_acceptance: pending`, `full_native_tests: not_executed`; a focused identifier-TU
  capture; focused coverage `service_identifier.cpp` 100 % line / 50 % branch; sanitizer captures;
  clang-tidy configuration blocker; native/bazel legs failing to fetch toolchains). **Per the task
  rule, a successful collection node means results were retained, not that checks passed; here
  nothing is retained at all, so no obligation may be treated as satisfied on that basis.**
- Those retained summaries are also **scoped and stale**: they compiled only the focused identifier
  translation unit (`service_identifier.cpp` + `string_registry.cpp` +
  `service_identifier_tests.cpp`) with `g++-12 -std=c++17 -Wall -Wextra -Werror`; they did **not**
  compile `runtime_tests.cpp` or the full `socom_test` / `//score/...` targets, and their recorded
  `service_identifier_tests.cpp` hash predates the later expansions.

### 1.6 Pinned obligation sources and authority (all read this iteration)

All nine entries of `.llm_tmp/context/obligations/source-index.json`, together with
`.llm_tmp/context/obligations/authority.json`, were read from `.llm_tmp/context/obligations/`. Every
entry is pinned `"native_acceptance": "not_inferred"` — pinned, but its applicability to this slice
is **not inferred**.

| id | pinned file (id → path) | status note |
|----|-------------------------|-------------|
| `coding_guidelines` | `docs/contribute/development/cpp/coding_guidelines.rst` | `:status: valid`; MISRA C++:2023 with C++17 |
| `code_analysis` | `docs/contribute/development/cpp/code_analysis.rst` | `:status: valid`; clang-tidy + gcc/clang warnings + Coverity; sanitizers |
| `misra_mapping` | `docs/contribute/development/cpp/misra_2023_rule_mapping.rst` | **`:status: draft`**; the rule table is not a valid obligation |
| `verification_plan` | `docs/platform_management_plan/software_verification.rst` | `:status: valid`; quality criteria incl. criterion 9 "Freedom from compiler warnings & errors" |
| `development_plan` | `docs/platform_management_plan/software_development.rst` | `:status: valid`; C++17, GCC host compiler, QCC target, Bazel |
| `tool_management` | `docs/platform_management_plan/tool_management.rst` | `:status: valid`; tools identified / evaluated / qualified by a human |
| `verification_process` | `process/process_areas/verification/guidance/verification_process_reqs.rst` | `:status: valid`; `gd_req__verification_link_tests_cpp`, `_independence`, `_checks_extended`, `_sca_classification` |
| `verification_guideline` | `process/process_areas/verification/guidance/verification_guideline.rst` | `:status: valid`; traceability, independence, documented results |
| `inspection_checklist` | `score/component_example/docs/detailed_design/chklst_impl_inspection.rst` | **`:status: draft`**; blank `IMPL_01_01`…`IMPL_03_02` template |

**Authority record** (`.llm_tmp/context/obligations/authority.json`):
`engineering_acceptance: pending`; `human_reviews: unanswered`; `safety_class: unknown`;
`codeql_scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload"`; instruction
*"Restart the failed queue for one complete pass through all obligations"*.

**Safety-class note (recorded, not resolved).** The pinned platform documents carry
`:safety: ASIL_B`, while `authority.json` records `safety_class: unknown` and no authorized
selection exists. The document attribute is **not** a selection of the slice's safety class and must
not be inferred as one.

---

## 2. The recorded syntax failure: inspection of the actual source

### 2.1 Finding (re-verified this iteration by direct `read_file` + `grep`)

`score/socom/impl/service_identifier.hpp` is **brace-balanced**. It is 40 lines; a `grep` for a
brace character (`[{}]`) returns exactly four matches:

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`) and two closers (`:32`, `:38`) mean net brace balance `0`. There is
**no third, unmatched closing brace**, and line 39 contains no text at all. The sibling
`score/socom/impl/service_identifier.cpp` uses the same nested form (`:18` / `:32`) and is balanced
the same way (`[{}]`-bearing lines `:18`, `:20`, `:30`, `:32`). The task's "extra closing brace …
at line 39" is therefore a **stale, pre-correction description** that matches the earliest prior
reports (which quote lines 38-39 as the split-form `}  // namespace socom` + `}  // namespace
score`), not this checkout. The `reproducer` iteration applied the correction; the removed brace
left line 39 blank, exactly as observed here.

### 2.2 Repository convention (evidence)

The tree uses two internally-consistent styles:

- **Nested open + single close:** `namespace score::socom {` … one `}  // namespace score::socom`.
  This is the sibling `impl/service_identifier.cpp`, the public `service_interface_identifier.hpp`
  (`:25` / `:164`), and the key header itself.
- **Split open + double close:** `namespace score {` + `namespace socom {` … `}  // namespace
  socom` + `}  // namespace score`. This is `impl/runtime_impl.hpp`.

`impl/service_identifier.hpp` follows the **nested** form consistently and is balanced.

### 2.3 Minimal repair (retained for reference only; not applied because not needed)

Should the imbalance ever reappear, the minimal correction — matching the sibling `.cpp` and the
nested form — is:

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

Applying it to the already-balanced file would be a no-op; deleting a brace to "fix" the file would
*create* the reported defect. `edit_file` is outside this node's permitted tool set, and the one
application attempted against the candidate test path was refused by the environment. No candidate
source path was modified this iteration.

### 2.4 Why it would matter if present

The header is compiled into `//score/socom:socom` (`score/socom/BUILD:24-41`; its `srcs` globs
`impl/**/*.cpp` and `impl/**/*.hpp`) and re-exposed to `//score/socom/test/unit` through the
`testonly` library `impl_service_identifier` (`score/socom/BUILD:43-54`;
`score/socom/test/unit/BUILD:24`). A syntax error here would fail the library and the whole
`socom_test` target, contradicting S-CORE quality criterion 9, "Freedom from compiler warnings &
errors, 100 %" (`verification_plan.rst`). The current balanced state removes that blocker at the
source level; that is **not** a compile measurement (section 8).

---

## 3. Key semantics under test (as implemented)

The duplicate-server key is
`Service_instance_identifier { Service_interface_identifier interface; Service_instance instance; }`
(`score/socom/impl/service_identifier.hpp:29-32`). The only operator is the out-of-line `operator<`
(`:35`), defined as (`score/socom/impl/service_identifier.cpp:28-29`):

```cpp
return std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major) <
       std::tie(rhs.instance, rhs.interface.id, rhs.interface.version.major);
```

Therefore:

- identity (set equivalence) = **`(instance, service id, major)`**;
- **`minor` is ignored** — it is a compatibility selector enforced separately by
  `is_interface_compatible` (`runtime_impl.cpp:138-146`; `is_minor_version_compatible` at
  `:133-136`), not an identity component;
- `std::set` uniqueness (`!(a<b) && !(b<a)`) follows the same equivalence, so two keys that share
  `instance + id + major` (and differ only in minor) are duplicates.

The record index deliberately uses the same coarse identity (`Minor_version_ignoring_hash` /
`Minor_version_ignoring_key_equal`, `runtime_impl.hpp:116-134`), so the key gate covers every
collision the record index can produce. The duplicate is rejected in
`Runtime_impl::make_server_connector` (`runtime_impl.cpp:443`, insert/return `duplicate_service` at
`:449-454`), before the single-server precondition (`SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)`) in
`Service_record::register_server_connector` can be reached.

`Service_instance_identifier` declares **no `operator==` and no `std::hash`**. "Equality" in the
tests is therefore *set equivalence* — neither key orders before the other — which is the only
identity notion the type exposes. `Service_instance` and `Service_interface_identifier` do have
content-based `operator<` and `operator==` (`service_interface_identifier.hpp:61-71`, `:130-162`),
which the tuple ordering delegates to, and the full-version `std::hash` (`:170-190`) remains
distinguishing.

---

## 4. Test matrix and coverage by requested dimension

File: `score/socom/test/unit/service_identifier_tests.cpp` (Apache-2.0 header present). Shared
fixture helpers:

- `make_identifier(service_id, major, minor, instance_id)` (`:92-100`) — builds one key through the
  public constructors (registry-deduplicated string ids);
- `identity_of(key)` (`:86-90`) — the `(instance, service id, major)` identity tuple `Identity`;
- `equivalent(lhs, rhs)` (`:104-107`) — `!(lhs < rhs) && !(rhs < lhs)`, i.e. the `std::set`
  equivalence;
- boundary constants `major_min = 0`, `major_max = 65535`, `minor_min = 0`, `minor_max = 65535`
  (`:77-80`);
- sort extremes `service_id_first = "AAA_first"`, `service_id_last = "ZZZ_last"`,
  `instance_id_first = "AAA_instance"`, `instance_id_last = "ZZZ_instance"` (`:69-75`);
- `registration_key_domain()` (36 keys, `:115-128`) and `registration_key_boundary_domain()`
  (64 keys, `:139-154`);
- `make_registration_key(interface, instance)` (file-local, `:777-780`) for the public → internal
  conversion cases.

The suite contains **87 `TEST_F`** cases under `ServiceInstanceIdentifierTest` (`:168`…`:2012`,
counted this iteration by `grep`).

### 4.1 Coverage of the five requested dimensions

| Requested dimension | Representative existing cases (line) |
|---------------------|--------------------------------------|
| **Service IDs** | `KeysDifferingInServiceIdAreDistinct` (`:262`), `DistinctServiceIdsProduceDistinctKeys` (`:270`), `EqualServiceIdTextProducesEquivalentKeys` (`:281`), `ServiceIdOrderingIsLexicographic` (`:296`), `EmptyServiceIdIsDistinctAndOrdersFirst` (`:927`), `ServiceIdPrefixOrderingIsLexicographic` (`:970`), `ServiceIdLadderOrdersLexicographicallyAndDistinctly` (`:1218`), `ServiceIdOrderingIsLexicographicNotNumeric` (`:1625`), `FreshDynamicServiceIdStringViewRegistersAndCollapses` (`:1982`), `FreshDynamicServiceIdRvalueRegistersAndCollapses` (`:2012`) |
| **Instance IDs** | `InstanceIsThePrimaryOrderingComponent` (`:496`), `KeysDifferingInInstanceAreDistinct` (`:310`), `DistinctInstancesProduceDistinctKeys` (`:318`), `EqualInstanceTextProducesEquivalentKeys` (`:329`), `InstanceOrderingIsLexicographic` (`:342`), `EmptyInstanceIdIsDistinctAndOrdersFirst` (`:943`), `InstanceIdPrefixOrderingIsLexicographic` (`:985`), `InstanceIdLadderOrdersLexicographicallyAndDistinctly` (`:1241`), `InstanceIdOrderingIsLexicographicNotNumeric` (`:1641`), `ConvertedInstanceTextPathsAgreeAtBoundaries` (`:1149`), `ConvertedInstanceRegistryIdPathAgreesWithTextPaths` (`:1564`) |
| **Major versions** | `KeysDifferingInMajorVersionAreDistinct` (`:217`), `MajorVersionBoundariesAreDistinct` (`:225`), `MajorVersionSweepProducesDistinctKeys` (`:235`), `AdjacentMajorVersionBoundariesAreDistinct` (`:246`), `MajorDifferenceOutweighsMinorDifference` (`:486`), `MajorIsTheTertiaryOrderingComponent` (`:506`), `MajorHighBitAdjacencyIsOrdered` (`:998`), `MajorVersionLadderOrdersNumericallyAndDistinctly` (`:1264`), `MajorVersionByteBoundariesAreDistinctAndOrdered` (`:1656`), `MajorVersionOrderMatchesUnsignedNumericOrder` (`:1680`) |
| **Minor boundaries** | `SameIdentifierIsNotLessThanItself` (`:168`), `KeysDifferingOnlyInMinorVersionAreDuplicates` (`:174`), `MinorVersionBoundariesAreDuplicates` (`:182`), `AllMinorVersionsCollapseToSingleKey` (`:192`), `MinorHighBitVariantsAreEquivalent` (`:203`), `MinorVersionNeverAffectsOrdering` (`:430`), `SetFindLocatesMinorVariantAndCountsItOnce` (`:1034`), `MinorVariantsCompareIdenticallyAgainstWholeDomain` (`:1292`), `StdSetCollapsesFiveMinorVariantsOfEveryIdentity` (`:1321`), `MinorVariantsBoundDistinctIdentitiesWithoutBreakingOrder` (`:1702`), `MinorSweepCollapsesPerIdentityAtEveryMajorBoundary` (`:1728`), `KeyIdentityIsStableUnderRepeatedMinorRewritesOfTheSameIdentity` (`:1851`) |
| **Equality/ordering consistency** | `KeyEquivalenceDependsOnInstanceServiceIdAndMajor` (`:420`), `OrderingOrderIsInstanceThenServiceIdThenMajor` (`:441`), `OrderingIsTransitive` (`:460`), `EquivalenceIsTransitive` (`:473`), `DistinctKeysAreOrderedInExactlyOneDirection` (`:516`), `StrictWeakOrderingHoldsAcrossMinorVariants` (`:537`), `SortingAgreesWithIndependentTupleOrder` (`:563`), `SetUniquenessMatchesDistinctIdentityTupleCount` (`:588`), `SetIterationFollowsInstanceThenServiceIdThenMajor` (`:609`), `PropertyStrictWeakOrderingAxiomsHoldOnDeterministicDomain` (`:634`), `PropertyEquivalenceMatchesIdentityTupleOnDeterministicDomain` (`:662`), `PropertyOrderingIsDeterministicTotalAndTupleConsistent` (`:687`), `PropertyEquivalenceClassesMatchDistinctIdentityTupleCount` (`:712`), `PropertySetUniquenessIsIndependentOfInsertionOrder` (`:735`), `PropertySortedDomainMatchesSortedIdentityTuples` (`:1055`), `PropertyStrictWeakOrderingAxiomsOnVersionBoundaryDomain` (`:1087`), `PropertyIdentityEqualityClassesOnVersionBoundaryDomain` (`:1115`), `EquivalenceIsCompatibleWithStrictOrder` (`:1343`), `OrderingAgreesWithTupleOrderOnMixedBoundaryDomain` (`:1363`), `SingleComponentChangesBreakEquivalenceAcrossAllBases` (`:1407`), `PropertyStrictWeakOrderingOnCombinedRegistrationKeyDomain` (`:1456`), `PropertyIdentifierEqualityOnCombinedRegistrationKeyDomain` (`:1488`), `SetInsertionResultMatchesEquivalenceAcrossMinorVariants` (`:1754`), `EquivalenceCoincidesWithIdentityOverFixtureCrossProduct` (`:1777`), `OrderingIsAntiSymmetricOverFixtureCrossProduct` (`:1818`) |

A further set of cases pins the public-identifier → internal-key conversion at version boundaries
(`:784`, `:813`, `:833`, `:847`, `:861`, `:884`, `:911`, `:1149`, `:1187`, `:1531`, `:1564`,
`:1590`), including the config `uint8`/`uint32` → socom `uint16` narrowing and the `0xFFFFFFFF`
wildcard that narrows to `0xFFFF`. The empty-text identifier-conversion boundary is covered by
`:1882` and `:1929`. Those open #84 questions (public type shape, FindService wildcard, config
minor-wildcard semantics) are **not** decided here.

### 4.2 Boundary values exercised

- major `0`, `1`, `2`, `3`, `0x7F`, `0x80`, `0xFF`, `0x100`, `0x7FFE`, `0x7FFF`, `0x8000`,
  `0x8001`, `0xFFFE`, `0xFFFF`;
- minor `0`, `1`, `2`, `3`, `0x7FFF`, `0x8000`, `0xFFFE`, `0xFFFF`;
- string ids: empty, strict prefixes, sort extremes `AAA_*`/`ZZZ_*`, numeric-suffix ladders
  (`"S1" < "S10" < "S2"`, `"I1" < "I10" < "I2"`), and freshly allocated dynamic texts.

### 4.3 Determinism

Every case is a pure function of compile-time constants: each domain is a fixed cartesian product
enumerated in a fixed order (no randomness, no time dependence, no allocation beyond `std::vector` /
`std::set` / `std::string`). The expected sizes (36, 64, 48, 72, 144, 96, 60, `majors.size() *
minors.size()`) are exact for the listed products. The dynamic-registry cases use a per-run counter
suffix only to guarantee a genuinely new registry entry; they do not depend on wall-clock time or
randomness.

---

## 5. Expansion status and the one residual gap

The task asks to "expand agent-authored tests over service IDs, instance IDs, major versions, minor
boundaries and equality/ordering consistency". Those five dimensions are **already** exercised by
the 87 cases mapped in section 4; a prior iteration added the "seventh", "eighth" and "ninth"
expansions on disk (the ninth being the fresh dynamic **service-id** registry cases at `:1982` and
`:2012`). Appending further cases over the same dimensions would duplicate deterministic matrices
and add no coverage, so this iteration recorded the mapping rather than appending noise.

The one genuinely non-duplicative gap found is coverage-driven, not dimension-driven: the ninth
expansion takes the "not found" `String_registry::insert` branches of the **service-id** registry
(`service_id_registry()`), while the separate **instance-id** registry (`instance_id_registry()`,
`string_registry.hpp:82`) is never inserted into with a freshly allocated text in this suite — the
existing empty-text case (`:1929`) reuses a text likely already present. Three concrete cases were
designed to close it:

1. `FreshDynamicInstanceIdStringViewRegistersAndCollapses` — insert a fresh instance text via
   `instance_id_registry().insert(std::string_view)`, build the key from both the registry id and
   the text, and confirm one identity across opposite minor boundaries.
2. `FreshDynamicInstanceIdRvalueRegistersAndCollapses` — the same through
   `insert(std::string&&)`.
3. `FreshDynamicServiceAndInstanceTextsComposeIntoOneIdentity` — both a fresh service text and a
   fresh instance text composing to one identity across minor boundaries.

These were **not applied**. The permitted tool set for this node is `read_file`, `grep`, `glob`,
`write_file` (no `edit_file`), and the one `edit_file` attempt against the candidate test path was
refused by the environment. Applying the block would therefore require `write_file` to rewrite the
entire 2041-line `service_identifier_tests.cpp` from re-read fragments with **no compiler
available**; a single transcription error would introduce exactly the kind of syntax failure this
node is charged with removing. The block is recorded here so a later authorized iteration with a
compiler can append it and re-run the suite. This is a recorded, unresolved gap, **not** a
satisfied obligation.

---

## 6. Build wiring (no BUILD change required)

- `score/socom/BUILD:43-54` defines the `testonly` `impl_service_identifier` library exposing
  `impl/service_identifier.hpp` to `//score/socom/test/unit:__pkg__`, depending on `:socom`.
- `score/socom/test/unit/BUILD:16-29` defines `socom_test` with `srcs = glob(include = ["*.cpp"])`
  and depends on `//score/socom:impl_service_identifier`, `//score/socom:mock`,
  `//score/socom/test/framework:socom_test_framework`, and googletest.

Therefore both test files are already collected and the internal key header is visible to the test
package; **no BUILD change was required or made.**

---

## 7. Obligations status (none satisfied)

### 7.1 Pinned state

All nine pinned sources in `.llm_tmp/context/obligations/` were read this iteration (section 1.6);
every `source-index.json` entry is `"native_acceptance": "not_inferred"`. `authority.json` records
`engineering_acceptance: pending`, `human_reviews: unanswered`, `safety_class: unknown`,
`codeql_scope: Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload`, and the instruction
*"Restart the failed queue for one complete pass through all obligations"*.

### 7.2 Status for this slice (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Freedom from compiler warnings & errors (100 %) | `verification_plan.rst` (criterion 9) | **NOT MEASURED** — header is brace-balanced by inspection (section 2), but nothing was compiled; no host artifact is present |
| Static code analysis (clang-tidy / CodeQL), findings classified | `code_analysis.rst`; `verification_process.rst` (`gd_req__verification_sca_classification`) | **NOT PERFORMED** — no tool, no build; a prior clang-tidy attempt was blocked on configuration; CodeQL MISRA applicability unestablished (draft mapping) |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` | **UNKNOWN — NOT CLAIMED** — mapping is `:status: draft`; not applied |
| Structural statement / branch coverage goals | `verification_plan.rst` (criteria 1-2) | **NOT MEASURED** — no test execution; prior coverage capture is out of this checkout and below the platform goals |
| Unit/component testing executed, results recorded | `verification_plan.rst` (criteria 6-7); `verification_guideline.rst` | **NOT EXECUTED** — 0 tests run; the prior key-TU run is stale and excludes `runtime_tests.cpp` |
| Interface / requirements-based / resource / fault-injection test types | `verification_process.rst`; `verification_plan.rst` | **NOT PERFORMED / applicability not inferred** — no harness; identifier-only tests must not be labelled platform validation |
| Boundary / equivalence derivation | `verification_process.rst` | **SOURCE-ONLY** — cases exist (section 4) but were not executed |
| Fuzzy testing technique | `verification_plan.rst` | **NOT EXECUTED / NOT CLAIMED** — no harness and no measurement |
| Linking tests to requirements (record properties) | `verification_process.rst` (`gd_req__verification_link_tests_cpp`) | **PARTIAL / NOT DONE** — `DerivationTechnique`/`Description` recorded (`service_identifier_tests.cpp:42-65`; `runtime_tests.cpp:264-267`); `TestType` and the `Verifies` links cannot be set without inventing identifiers |
| External-component AoUs verified | `verification_process.rst` (`gd_req__verification_external_aou`) | **NOT SATISFIED** — no integration/static verdict; no AoU register |
| Independence of verification / review by a different committer | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Implementation inspection checklist IMPL_01…IMPL_03 | `inspection_checklist.rst` | **NOT FILLED** — draft template, no inspection |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** for this slice; no tool run here |
| Obligation collection results retained | `.llm_tmp/overnight/**/result.json` | **ABSENT in this checkout** — no `result.json` present |
| Native acceptance | `source-index.json` | **`not_inferred` for every entry** |

**Explicit non-satisfaction statement.** Missing tools (no build/test in this task), the unknown
safety class and un-inferred applicability, the incomplete extraction of host artifacts, the absent
obligation-collection results, and the unanswered human reviews mean **none of the checked
obligations may be treated as satisfied**. A collection node that retained results would only show
*retention*, not passing; here there are no retained results at all. In particular, the absence of
`.llm_tmp/overnight/validation/` and `.llm_tmp/overnight/**/result.json` is **not** evidence that
the corresponding checks passed.

---

## 8. Measurement and validation status

- **Tools:** `read_file`, `grep`, `glob`, `write_file` only (one `edit_file` attempt refused, no
  effect). No delegation, web, approval, publishing, or engineering acceptance.
- **Executed measurements:** **none** this iteration. No build, no `bazel test`, no runtime. The
  brace census (section 2), the key identity (section 3) and the expected test behaviour
  (section 4) are static source readings and strict-weak-ordering consequences, not observed
  results.
- **Test inventory (read, not run):** `service_identifier_tests.cpp` has **87 `TEST_F`** under
  `ServiceInstanceIdentifierTest` (`:168`…`:2012`, verified by `grep`); `runtime_tests.cpp` has
  **31 `TEST_F` + 1 `TEST` + 1 `TEST_P`**, including the minor-only duplicate regression
  `ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError` (`:402-431`).
- **Regression target (source-derived, not executed):**
  `RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError`
  (`runtime_tests.cpp:402-431`) and the key-level minor-collapse cases
  (`service_identifier_tests.cpp:174`, `:182`, `:192`, `:203`, …) assert that a second registration
  differing only in `minor` is rejected as `duplicate_service`. On a key that includes `minor` they
  would fail; on the working-tree key they should pass. This is a `std::set` / strict-weak-ordering
  consequence, not an observed result. Both connectors in the runtime regression remain disabled, so
  the duplicate is rejected at construction and never reaches the single-server
  `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)` path.
- **Scope:** local, unprotected, scoped. This is a bounded correction/verification record, not an
  accepted engineering decision. Full native runtime tests and human review remain pending.
- **Reproduction path for a later, permitted iteration (not executed here):**

  ```bash
  bazel build //score/...
  bazel test //score/socom/test/unit:socom_test
  # focused key-level:
  bazel test //score/socom/test/unit:socom_test --test_filter='ServiceInstanceIdentifierTest.*'
  # focused runtime regression:
  bazel test //score/socom/test/unit:socom_test \
      --test_filter='RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError'
  # integration / cross / docs / traceability (per the pinned plans)
  bazel test --config=qemu-integration //tests/integration_test/...
  ```

  Expected on the working-tree key: the minor-only key tests collapse to one set element and the
  runtime regression returns `Construction_error::duplicate_service`. On a key that includes
  `minor`, both focused checks would fail. These expectations are source-derived, not measured.

---

## 9. Notice preservation

- No source, build, test, config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was created, edited, or
  deleted by this iteration; only this report was written. Every existing Apache-2.0 / SPDX notice
  header is untouched, and all 38 prior-report files under `.llm_tmp/overnight/prior-reports/` plus
  the five earlier files under `.llm_tmp/overnight/reports/` were preserved.
- The header the task flagged (`score/socom/impl/service_identifier.hpp`) was inspected and left
  unchanged because it is already brace-balanced and otherwise well-formed (section 2). The sibling
  `service_identifier.cpp`, both BUILD files, and both candidate test files likewise retain their
  Apache-2.0 / SPDX headers.
- This report itself carries the Apache-2.0 header. No licensed MISRA rule text is reproduced; only
  native rule/query identifiers, file locations, and prior-report readings are cited.
- The duplicate key remains an `impl/`-only type; the `testonly`
  `//score/socom:impl_service_identifier` library exposes it to `//score/socom/test/unit` only, so no
  public header or notice surface changed.

---

## 10. Pending human review checklist

- [ ] **Confirm the section 2 inspection:** the header is already brace-balanced (braces at `:19`,
      `:29`, `:32`, `:38`; line `:39` blank; single nested close `}  // namespace score::socom`), so
      the recorded syntax failure is stale and no correction is required. If the "cancelled draft"
      is a different revision that still carries the extra brace, locate it and authorize its
      correction; no such file exists in this checkout.
- [ ] **Resolve the instruction/tool conflict:** the task directs expanding tests and correcting the
      source, while `edit_file` is outside the permitted tool set and the actual source contains no
      defect; confirm that the report-only outcome (with the recorded section 5 expansion block) is
      the intended one.
- [ ] **Confirm the key decision in section 3:** `minor` is **not** part of the duplicate-server
      registration key; identity `(instance, service id, major)`; interface representation and the
      exact-major / minimum-minor rules unchanged.
- [ ] **Confirm the section 4 mapping** of the 87 key cases to the five requested dimensions, and
      that the equivalence definition (`!(a<b) && !(b<a)`, since the type has no `operator==`) is
      acceptable.
- [ ] **Authorize the section 5 instance-id registry expansion** as the next concrete test change,
      to be applied and compiled by an iteration that has `edit_file`/a compiler.
- [ ] **Confirm `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)`** (`runtime_impl.cpp:369`) is the
      authoritative single-server invariant, so the key must be at least as coarse as the record
      index.
- [ ] **Keep the #84 public `Service_interface_identifier` restructure, FindService wildcard
      handling, and the config minor-wildcard narrowing out of this bounded slice** until separately
      accepted. Do **not** present the identifier-only tests as platform validation or claim an
      unmeasured fuzzy technique.
- [ ] **Supply the missing artifacts** (`.llm_tmp/overnight/**/result.json` and
      `.llm_tmp/overnight/validation/`) into this checkout; do not infer passing from absence or from
      prior reports' retained summaries.
- [ ] **Run the full native suite** (`bazel test //score/socom/test/unit:socom_test` and the broader
      `//score/...` set), including `runtime_tests.cpp`, record results, and schedule independent
      human review (the approver must differ from the author, per
      `gd_req__verification_independence`).
- [ ] **Select a safety class** via the authorized role; do not infer the slice's class from the
      `:safety: ASIL_B` attribute on the pinned platform documents (section 1.6).

---

*End of duplicate-server registration-key unit matrix review draft. Local, unprotected, scoped. No
engineering acceptance; human reviews unanswered; full native runtime tests pending. Every statement
is a local reading of the working tree, a prior report's recorded reading, or an explicitly-labelled
logical consequence — none is acceptance, review approval, publication, or a full native run.*
