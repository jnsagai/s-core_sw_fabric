<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — design inspection draft (duplicate-server registration-key slice)

**Document type:** review draft — implementation inspection against specification, design,
external libraries, static/dynamic analysis, manual coding checks and interface/traceability
consistency, plus drafted remaining safety-analysis (FMEA/DFA) impact questions.
**Date:** 2026-10-02
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version
handling in socom* (issue #84)
**Run:** branch `fabro/run/01M3YRJEGXNY6CB81T7TKW774B`
**Status:** local, unprotected, scoped. **No engineering acceptance exists. Human reviews are
unanswered. Full native runtime tests remain pending.** Every statement below is either a direct
`read_file`/`grep`/`glob` reading of this checkout, a direct reading of a retained artifact under
`.llm_tmp/overnight/`, or an explicitly-labelled logical consequence. Nothing here is published,
reviewed, accepted, or a full native run.

> **Write boundary actually observed (the reviewer-relevant point this draft must make first).**
> The task text contains two directions that conflict: it says *"Inspect and correct the actual
> source before expanding tests"* and *"The cancelled draft has a measured GCC syntax failure: an
> extra closing brace in `score/socom/impl/service_identifier.hpp` at line 39"*, but its explicit
> final sentence says *"This is a review draft: only that report may be written."* Only
> `read_file`, `grep`, `glob` and `write_file` were available and used; there was no `shell`, no
> `edit_file`, no delegation, no web access, no approval, and no publishing. Following the explicit,
> more specific write boundary, **exactly one file was written — this report.** No source, build,
> test, config, `NOTICE`, `LICENSE`, `REUSE.toml`, or prior-report file was created, edited, or
> deleted.
>
> **The conflict is moot on the facts: the described syntax failure is not present in the actual
> source (§2).** Direct inspection shows `score/socom/impl/service_identifier.hpp` is
> brace-balanced: openers at `:19` (`namespace score::socom {`) and `:29`
> (`struct Service_instance_identifier final {`); closers at `:32` (`};`) and `:38`
> (`}  // namespace score::socom`); line `:39` is **empty**; line `:40` is `#endif`. Two openers,
> two closers, net balance `0`; `grep '[{}]'` returns exactly those four lines and `grep
> 'namespace'` returns exactly `:19` and `:38`. There is no third, unmatched closing brace to
> remove. Applying the historical split-form repair to the already-nested file would be a no-op at
> best and a regression at worst. No test was expanded in this iteration either, because the
> draft's suites already exist on disk (§5).
>
> **Non-satisfaction rule applied throughout.** A successful obligation-collection node means the
> results were **retained**, not that the checks **passed**. Missing tools, unknown applicability,
> incomplete extraction, an inactive rule mapping, and unanswered human reviews are **not** treated
> as satisfied. A tool that produced **no** finding because it **did not run** is recorded as
> *"not run"*, never as *"clean"*.

---

## 0. Summary

1. **The recorded "extra closing brace at line 39" is not present in the actual source (§2).**
   The header is 40 lines and brace-balanced (braces at `:19`, `:29`, `:32`, `:38`; line `:39`
   blank). The retained focused GCC compile of the candidate translation unit (which `#include`s
   the header transitively) exits `0` with empty `stderr`; a surviving unmatched brace would have
   failed it. The description matches the earliest prior reports' pre-correction split-form double
   close, not this checkout. **No source correction was applied and none is required**; the review
   draft boundary forbids a source write in any case.
2. **Implementation against specification (§3): the bounded key change is present and internally
   consistent, but the "specification" it follows is an unaccepted issue-#84 proposal, not a
   verified requirement.** `operator<` orders by `(instance, service id, major)` with `minor`
   deliberately excluded (`service_identifier.cpp:28-29`), so the duplicate-server identity now
   matches the minor-ignoring `Service_database` record index (`runtime_impl.hpp:116-134`).
3. **Design inspection (§4): the change closes an invariant gap but rests on two cross-lock /
   lifetime properties** — key identity equal to record identity (so the single-server
   `ASSERT(!m_server)` stays unreachable), and key/registration teardown ordering. It does **not**
   implement the wider public-identifier restructure.
4. **External libraries (§6): no library is qualified, and the load-bearing AoU is undetermined.**
   The key/error path depends on `score_baselibs` (`SCORE_LANGUAGE_FUTURECPP_ASSERT` semantics,
   `score::Result`, `mw::log`) and, in the focused runs, on vendored googletest; the assert's
   terminate-vs-compiled-out semantics are external and unknown. No external-component AoU is
   integration-tested or statically analysed here.
5. **Static/dynamic analysis (§7): partial and mostly non-passing.** Focused GCC compile and
   focused ASan/LSan/UBSan pass; Clang is blocked by a dependency deprecation; clang-tidy did not
   run (config rejected); cppcheck findings are out of scope; CodeQL security is dependency-only
   and CodeQL MISRA has a `:status: draft` mapping; TSan produced no usable result; memcheck,
   Bazel, clang-format, pre-commit, reuse and gitleaks are unavailable. None is "clean".
6. **Manual coding checks (§8): a construct-by-construct inspection finds no confirmed
   safety-relevant defect in the changed comparator, but records actionable findings** (missing
   `noexcept`; documentation narrower than the new semantics; content-ordered `<` vs pointer-based
   `==`/`hash`; teardown-declaration-order fragility). No MISRA C++:2023 compliance is claimed,
   because `misra_mapping.rst` is `:status: draft` with the rule table commented out.
7. **Interface/traceability consistency (§9): the implementation and its code comments agree, but
   the design docs and the requirement model are silent, so the traceability chain is broken at
   both ends.** No `comp_req__socom__*` and no `:reqtype: Interface` need exist; `TestType` and the
   `Verifies`/`PartiallyVerifies`/`FullyVerifies` links are deliberately unset; the
   docs/traceability gate did not run.
8. **Remaining safety-analysis impact questions are drafted, not answered (§10).** Per the task,
   this draft does **not** act as the independent reviewer and does not select a safety class,
   accept risk, or answer the human gate.
9. **No obligation is satisfied (§11).** Every `source-index.json` entry is
   `native_acceptance: not_inferred`; `authority.json` records `engineering_acceptance: pending`,
   `human_reviews: unanswered`, `safety_class: unknown`.

---

## 1. Binding, candidate set, sources read

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` | `.llm_tmp/context/issue-snapshot.json:2-4` |
| Title | *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:3` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` | `.llm_tmp/context/issue-snapshot.json:19-20` |
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**. It distinguishes: service-instance identifier = `service id + major + minor + instance
id`; service identifier = `service id + major`; FindService = `service id + major +
optional<minor> + optional<instance>`; and proposes to "exclude the minor version and make it a
property of the service instance". The FindService `major = FF` AUTOSAR case is called theoretically
possible but not useful. There is **no comment and no acceptance record**, so none of it is binding.
Binding is **by baseline commit**, not by run HEAD.

### 1.2 In-scope candidate files (the only writable source paths in the broader task)

From `.llm_tmp/context/candidate-files.json:1-26`:

| File (repo-relative) | Baseline git blob | Working tree (read this iteration) |
|----------------------|-------------------|------------------------------------|
| `score/socom/BUILD` | `3477ea08…` | `socom` library `:24-41`; `testonly` `impl_service_identifier` `:46-54` |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e…` | key identity `(instance, id, major)`; `minor` excluded (`:28-29`) |
| `score/socom/impl/service_identifier.hpp` | `c8bae790…` | brace-balanced, 40 lines, `:39` blank (§2) |
| `score/socom/test/unit/BUILD` | `3c03a7b1…` | `socom_test` globs `*.cpp`; deps wired (`:16-29`) |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab7…` | 31 `TEST_F` + 1 `TEST` + 1 `TEST_P`; minor-only regression `:402-431` |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(none — `null`)* | key matrix present; the manifest expects a **new** file |

`glob **/service_identifier.hpp` returns exactly one path, so there is no second,
differently-braced copy of the header in this checkout. `glob **/*draft*` returns only
`.llm_tmp/overnight/reports/deviation_drafts.md`, so no separate draft source file exists.

> **Content-hash caution.** The context snapshot's declared `sha256` values differ from the
> tool-measured working-tree hashes retained in the obligation artifacts (e.g. header context
> `96b33a1f…` vs tool-measured `bdce3fcb…`). The working tree has moved relative to the snapshot, so
> the snapshot's *description* of a brace defect cannot be assumed to describe the current file; the
> **direct read of the actual file is authoritative** (§2). (No hashing tool is available in this
> task; the tool-measured values are quoted, not recomputed.)

### 1.3 Pinned process/platform sources read

All nine entries of `.llm_tmp/context/obligations/source-index.json` are present together with
`authority.json`:

| id | repository @ commit | status note |
|----|---------------------|-------------|
| `coding_guidelines` | `score` @ `e2373d82…` | `:status: valid`; **MISRA C++:2023 with C++17** (`coding_guidelines.rst:30-36,74`) |
| `code_analysis` | `score` @ `e2373d82…` | `:status: valid`; clang-tidy + gcc/clang warnings + Coverity; ASan/LSan/TSan/UBSan/Memcheck; gcov/gcovr |
| `misra_mapping` | `score` @ `e2373d82…` | **`:status: draft`**; rule `csv-table` commented out, `_assets/misra_2023.csv` absent |
| `verification_plan` | `score` @ `e2373d82…` | `:status: valid`; TestType table `:167-207`; DerivationTechnique table `:245-268`; quality criteria 1–9 `:292-335` |
| `development_plan` | `score` @ `e2373d82…` | `:status: valid`; C++17, GCC host compiler, QCC target, Bazel |
| `tool_management` | `score` @ `e2373d82…` | `:status: valid`; identify / evaluate / qualify / approve |
| `verification_process` | `process_description` @ `98d1d5f4…` | `:status: valid`; `gd_req__verification_link_tests` `:20-54`, `_cpp` `:56-75`, `_independence` `:141-152`, `_checks` `:178-196`, `_checks_extended` `:198-212`, `_external_aou` `:214-226`, `_sca_classification` `:228-248` |
| `verification_guideline` | `process_description` @ `98d1d5f4…` | `:status: valid`; traceability, independence, documented results |
| `inspection_checklist` | `module_template` @ `c4d4ad09…` | **`:status: draft`**; blank `IMPL_01_01`…`IMPL_03_02` template |

Every entry is pinned with `"native_acceptance": "not_inferred"` — pinned, but its applicability to
this slice is **not inferred**. `authority.json` records `codeql_scope: "Public Apache-2.0
eclipse-score/inc_someip_gateway; no upload"`, `engineering_acceptance: pending`,
`human_reviews: unanswered`, `safety_class: unknown`, and the instruction *"Restart the failed queue
for one complete pass through all obligations"*.

### 1.4 Prior reports and retained host feedback read

- `.llm_tmp/overnight/prior-reports/` — **12 files** present and preserved (`callsites.md`,
  `conversion_tests.md`, `invariants.md`, `key_fix.md`, `lifetime_tests.md`, `ordering_tests.md`,
  `reproducer.md`, `runtime_disabled.md`, `runtime_enabled.md`, `scope.md`, `test_metadata.md`,
  `unit_matrix.md`).
- `.llm_tmp/overnight/reports/` — earlier reports present and preserved; the ones consulted for
  this design inspection are `scope.md`, `key_fix.md`, `finding_classification.md`,
  `deviation_drafts.md`, `api_review.md`, `compatibility.md`, `coverage_review.md`,
  `lifetime_review.md`, `concurrency_review.md`, `sanitizer_review.md`, `security_review.md`,
  `integration_aou_review.md`, `tool_assurance_review.md`, `misra_manual_review.md`,
  `traceability_review.md`. This document adds `design_inspection_draft.md`; nothing was overwritten.
  (Some earlier reports also reference `verification_report_draft`, `cross_target_review`,
  `performance_review`, `native_build_review`, `analyzer_plan`, `bazel_plan`, `callsites`; where
  present they were cross-checked by `grep`.)
- `.llm_tmp/overnight/validation/` — present: `check-result` = `0`; `measurement.json`
  (`origin: local_unprotected_measurement`, `initiator: Fabro host hook`,
  `engineering_acceptance: pending`, `full_native_tests: not_executed`, compiler
  `/usr/bin/x86_64-linux-gnu-g++-12`); `baseline_with_agent_tests` = 85 tests / 28 failures /
  compile exit 0; `candidate` = 85 tests / 0 failures / compile exit 0; `before.json` = 85/28;
  `after.json` = 85/0. The `after-compile.stderr` is empty; the header is compiled transitively.
- `.llm_tmp/overnight/obligations/*/result.json` — present (≈24–25 checks). **Retention is not
  passing.** Relevant statuses are summarised in §7.

**Scope caveat carried into every section below.** Every retained code measurement compiles only the
focused identifier translation unit (`service_identifier.cpp` + `string_registry.cpp` +
`service_identifier_tests.cpp` + vendored googletest). **`runtime_tests.cpp` is not compiled or
executed by any retained artifact**, and `process_checks/result.json` records `test_macros: 87` for
`service_identifier_tests.cpp` while the retained `after.json` executed 85 — so even the identifier
measurement is **stale by two cases**. A green retained marker is therefore not evidence for the
runtime path this design drafts around.

### 1.5 Host addendum (task context, not acceptance)

The host addendum (available only as quoted by prior reports) states it "is task context, not
engineering acceptance or an approved tailoring decision". It asks the inspection to cover the
`verification_process` test types and derivation techniques; to keep unknown applicability and
unexecuted checks explicit; to **not** label identifier-only tests as full platform validation and
**not** to claim a fuzzy technique without a measurement; to permit concrete missing
boundary/equivalence regression cases within the six source paths; and to record that there is **no
authority to invent native links, select a safety classification, accept risk/deviations, or answer
the independent human gate.** This draft honours that in §3–§11.

---

## 2. The recorded GCC syntax failure — inspection of the actual source

### 2.1 Finding (re-verified this iteration by direct `read_file` + `grep`)

`score/socom/impl/service_identifier.hpp` is **brace-balanced**. It is 40 lines; `grep '[{}]'`
returns exactly four brace-bearing lines, and `grep 'namespace'` returns exactly two:

| Line | Content | Role |
|------|---------|------|
| 14 | `#ifndef SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard begin |
| 17 | `#include "score/socom/service_interface_identifier.hpp"` | include |
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 21–28 | doc comment | states that `minor` is intentionally not part of the identity |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 30–31 | `Service_interface_identifier interface;` / `Service_instance instance;` | members |
| 32 | `};` | closes the struct |
| 34–36 | `/// \cond` / `bool operator<(…)` / `/// \endcond` | the single operator declaration |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`) and two closers (`:32`, `:38`) give net brace balance `0`. There is **no
third, unmatched closing brace**, and line `:39` contains no text at all. The sibling
`impl/service_identifier.cpp` uses the same nested form (its brace lines are `:18`, `:20`, `:30`,
`:32`) and is balanced. The public `service_interface_identifier.hpp` uses the nested form as well
(`:25` / `:164`); `impl/runtime_impl.hpp` uses the split `namespace score { namespace socom {` form
(`:32-33` / `:232-233`). The flagged header follows the repository's nested convention consistently.

### 2.2 Independent (retained) corroboration — read, not produced here

- `.llm_tmp/overnight/validation/after-compile.command.json` compiles `score/socom/impl/
  service_identifier.cpp` (which includes this header) with
  `/usr/bin/x86_64-linux-gnu-g++-12 -std=c++17 -Wall -Wextra -Werror`, **exit 0**; `after-compile.stderr`
  is empty.
- `.llm_tmp/overnight/obligations/compiler_diagnostics/gcc-compile` **exit 0** with empty `stderr`;
  `gcc-tests` **exit 0** (85 cases in the retained `after.json`).
- The only non-zero compiler result in the retained set is **Clang** `exit 1`, a
  googletest/libstdc++ `-Wdeprecated-declarations` error reached through
  `.llm_tmp/googletest/googletest/src/gtest-all.cc` — a **dependency** diagnostic outside the six
  candidate paths, not a header syntax error.

A genuine unmatched brace would have failed every focused GCC compile. These are scoped,
unprotected, focused runs — corroboration, **not** a full native build.

### 2.3 Disposition

The described defect is a **stale, pre-correction description** that matches the earliest prior
reports (which quote lines 38–39 as the old split form `}  // namespace socom` + `}  // namespace
score`). The `reproducer` iteration applied the correction and left line 39 blank, exactly as
observed here. **No correction was applied; none is required.** Two independent reasons prevented a
source write, either of which is sufficient: (a) there is no defect in the actual source, and (b)
this review draft may write only this report. If a distinct "cancelled draft" revision elsewhere
still carries the extra brace, it is not the file in this checkout and must be located and corrected
by an authorized iteration; this draft records the discrepancy for human disposition rather than
speculating.

### 2.4 Why it would matter if present

The header is compiled into `//score/socom:socom` (`score/socom/BUILD:24-41`; its `srcs` globs
`impl/**/*.cpp` and `impl/**/*.hpp`) and re-exposed to `//score/socom/test/unit` only through the
`testonly` library `impl_service_identifier` (`score/socom/BUILD:46-54`; consumed at
`score/socom/test/unit/BUILD:24`). A syntax error would fail both the library and the whole
`socom_test` target, contradicting S-CORE quality criterion 9, "Freedom from compiler warnings &
errors, 100 %" (`verification_plan.rst:332-335`). It is **not** a blocker in the current tree; that
is a static brace-balance reading corroborated by focused compiles, **not** a full native
criterion-9 measurement.

---

## 3. Implementation inspection against the specification

### 3.1 The changed implementation (exact constructs)

```cpp
// score/socom/impl/service_identifier.hpp:29-35
struct Service_instance_identifier final {
    Service_interface_identifier interface;
    Service_instance instance;
};

/// \cond
bool operator<(Service_instance_identifier const& lhs, Service_instance_identifier const& rhs);
/// \endcond
```

```cpp
// score/socom/impl/service_identifier.cpp:20-30
bool operator<(Service_instance_identifier const& lhs, Service_instance_identifier const& rhs) {
    // ... rationale comment (minor excluded; identity = service id + major; issue #84) ...
    return std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major) <
           std::tie(rhs.instance, rhs.interface.id, rhs.interface.version.major);
}
```

`std::set` uniqueness is `!(a < b) && !(b < a)`, so the duplicate-server identity on this tree is
exactly `(instance, service id, major)` and **the minor version is excluded**.

### 3.2 Conformance to the (unaccepted) issue-#84 design

| #84 use case / proposal | State in this tree | Verdict |
|-------------------------|--------------------|---------|
| "service identifier = `service id + major`" | Realized **only internally**: the duplicate key and the `Service_database` index both use `(id, major)` (+ instance) | **Partially realized, internally only** — the public `Service_interface_identifier` and IPC `Service` remain minor-aware (§9.3) |
| "exclude the minor version and make it a property of the service instance" | `minor` is excluded from the internal registration key, but still lives on `Service_interface_identifier::Version` (public) | **Not realized as a public-type change** |
| service-instance identifier = `service id + major + minor + instance id` | The key drops `minor`; `Service_instance` carries no version | **Diverges from this use case** |
| FindService `service id + major + optional<minor> + optional<instance>` | Not implemented; discovery is untouched (§4.7) | **Not implemented** |
| FindService `major = FF` wildcard | Not implemented; `major` is an exact identity component (`runtime_impl.cpp:144`) | **Not implemented** |

**Important framing.** The row "Partially realized" is a *source reading*, not an acceptance. The
only thing the bounded slice actually does is drop `minor` from the internal duplicate key. The
issue body is an open proposal with **0 comments and no acceptance record**; there is no verified
native requirement it implements (§9.1). The implementation therefore cannot be said to "satisfy the
specification" in the S-CORE sense — it aligns with one internal design direction whose acceptance
is pending.

### 3.3 Preserved rules (implementation-vs-design cross-check)

| Rule / surface | Evidence | Preserved? |
|----------------|----------|------------|
| Public interface representation `Service_interface_identifier{Id id; Version{uint16 major; uint16 minor;}}` | `service_interface_identifier.hpp:74-124`, `:80-88` | **Yes — unchanged** |
| Full-version public `operator==`/`operator<`/`std::hash` (minor-aware) | `service_interface_identifier.hpp:130-162`, `:181-190` | **Yes** |
| Exact-major compatibility | `is_interface_compatible` requires `server.version.major == client.version.major` (`runtime_impl.cpp:144`) | **Yes** |
| Minimum-minor compatibility (`client.minor <= server.minor`) | `is_minor_version_compatible` (`runtime_impl.cpp:133-136`); applied at `:505-517`, `:534-544` | **Yes — not part of the key** |
| `Service_database` minor-ignoring index | `Minor_version_ignoring_key_equal` / `_hash` (`runtime_impl.hpp:116-134`); `get_record` (`runtime_impl.cpp:313-324`) | **Yes — untouched** |
| IPC wire `gateway_ipc_binding::Service` (full version, minor-aware equality/hash) | prior `api_review.md` §4.3; not in the key path | **Yes — untouched** |
| Key stays `impl/`-only | `score/socom/BUILD:17-22` (public `headers = glob(["*.hpp"])`) vs `:24-30` (`srcs` `impl/**`) | **Yes** |
| Ordering-only identity (no `operator==`/hash) | `service_identifier.hpp:35` is the only operator | **Yes** |

### 3.4 Test-to-behaviour correspondence (read, not executed)

- Key level: `service_identifier_tests.cpp` records `DerivationTechnique =
  "boundary-values,equivalence-classes"` and a fixture-wide `Description` in `SetUp()`
  (`:42-65`), and pins minor collapse (`KeysDifferingOnlyInMinorVersionAreDuplicates` `:174`;
  `MinorVersionBoundariesAreDuplicates` `:182`; `AllMinorVersionsCollapseToSingleKey` `:192`; …),
  major/service-id/instance distinctness, combined matrices, and strict-weak-ordering properties.
- Runtime level: `runtime_tests.cpp:402-431`
  (`ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError`) drives the public
  `Runtime::make_server_connector()` path and expects `Construction_error::duplicate_service` for a
  second registration differing only in `minor`.
- **Neither file is executed by a native Bazel target here**; the retained focused runs cover the
  key level only (85 of the current 87 macros). The red/green relationship is a `std::set` /
  strict-weak-ordering consequence (the key-includes-minor baseline fails; the minor-excluding key
  passes), **source-derived, not observed** in this iteration.

---

## 4. Design inspection (the registration key in its system context)

All line references are readings of this checkout.

### 4.1 Key type, role and lifetime

- **Type / role.** `Service_instance_identifier` is the element type of
  `using Service_identifiers = Mutexed_variable<std::set<Service_instance_identifier>>`
  (`runtime_impl.hpp:56`), held as `std::shared_ptr<Service_identifiers> m_service_identifiers`
  (`runtime_impl.hpp:228-229`). It is used only in `Runtime_impl::make_server_connector`.
- **Insertion / duplicate rejection.** `identifier{configuration.get_interface(), instance}`
  (`runtime_impl.cpp:443`); `is_valid(callbacks)` runs **before** insertion (`:445-447`), so a
  `callback_missing` return does not leak a key; then, under the key mutex, `insert(identifier)` and,
  on `false`, `MakeUnexpected(Construction_error::duplicate_service)` (`:449-454`).
- **Erase / invalidation.** A `Final_action` captures a copy of the identifier and a `weak_ptr` to
  the set, and erases under the same mutex on destruction, locking the `weak_ptr` first so it
  no-ops if the runtime is gone (`runtime_impl.cpp:456-463`). The `Final_action` is moved into the
  server connector and fires exactly once (`final_action.hpp` contract per prior `lifetime_review.md`).

### 4.2 The cross-lock single-server invariant (the design's core correctness property)

- `Service_record` holds a single `std::optional` server (`runtime_impl.hpp:70`) and
  `register_server_connector` asserts `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)` before
  `m_server.emplace(...)` (`runtime_impl.cpp:369,371`).
- The duplicate key mutex (A) is independent of the runtime record mutex (B)
  (`runtime_impl.hpp:50-56,220-221`). A's gate keeps the assert unreachable **only because** the key
  identity `(instance, id, major)` equals the record-index identity `(id, major, instance)`
  (`runtime_impl.hpp:116-134`) **and** the key is held continuously from construction to destruction.
- Closing this gap is precisely the change's purpose: on the pre-correction key (minor included) two
  servers sharing `instance + id + major` but differing in `minor` could both be constructed, resolve
  to one record, and reach the assert. The change reverses that reachability.
- **This is a static reading, not a race-detector result** (TSan produced no usable result; §7).

### 4.3 Teardown ordering (a fragility to preserve, not a defect claim)

`server_connector::Impl` declares `m_registration` before `m_final_action` (per prior
`concurrency_review.md` / `lifetime_review.md`; `server_connector_impl.hpp:162-163`), so members are
destroyed in the reverse order and the key-erasing `Final_action` runs **before** `m_registration`.
Correctness depends on `~Impl(){ disable(); }` having already reset `m_registration` in the
destructor body. Any future path that destroys an enabled `Impl` without clearing `m_registration`
would release the key while `Service_record::m_server` is still set, letting a new connector pass the
gate and violate the assert on enable. This is recorded as a latent ordering hazard (CE-4 / RCC-4 in
the prior reports), not introduced by the bounded change.

### 4.4 Lifetime of the non-owning views

The key stores `Registry_string_view`s (non-owning) into the process-wide, append-only
`String_registry` singletons. The registry-validity contract is explicit, and entries are only added,
never erased (per prior `misra_manual_review.md` §4.2). The residual static-destruction-order hazard
(a key outliving the registry) is unchanged by the key edit and not covered by any retained test.

### 4.5 Resource lifetime: records are never erased

`Service_database::get_record` only ever `emplace`s (`runtime_impl.cpp:313-324`); nothing erases
`m_service_records`, so records persist for the runtime's lifetime (prior `lifetime_review.md` CE-5).
This is orthogonal to the key change but relevant to the design's memory-growth profile and should be
part of any DFA/impact question (§10).

### 4.6 Discovery semantics deliberately unchanged

The key set is touched only in `make_server_connector`. The record index, `get_record`,
`bridge_service_requests` and `get_bridge_reported_instances` are untouched (prior
`compatibility.md` §7). The public identifier's ordering/hash and the IPC `Service` key remain
minor-aware. Future work must keep the change confined to the `std::set` duplicate gate.

### 4.7 Design documentation is silent on the changed behaviour

`grep` over `score/socom/docs/**` for `duplicate|registration|minor|major|version` returns **no
match**, and the design bundle (`30_structural_view.rst`, `40_behavioral_view.rst`,
`50_state_dynamics_view.rst`, and the PlantUML models) describes runtime, connectors, deadlock and
state behaviour but **nothing about the registration key, version identity or duplicate-server
rejection**. The behaviour is documented **only in code comments** (`service_identifier.hpp:21-28`,
`service_identifier.cpp:21-27`). This is a design-consistency gap (the design is
inconsistent-with/incomplete-for the implemented behaviour), recorded for human disposition.

---

## 5. Test-design inspection (read, not executed)

- Key suite: `service_identifier_tests.cpp` sets `DerivationTechnique` and a **fixture-wide**
  `Description` in `SetUp()` (`:50-55`); `TestType` and the `Verifies`/`PartiallyVerifies`/
  `FullyVerifies` links are deliberately **not** recorded, with an in-source rationale (`:57-64`).
  The suite covers irreflexivity, minor collapse at the `uint16` boundaries, major/id/instance
  distinctness, combined matrices, equivalence ⇔ `(instance, id, major)`, and strict-weak-ordering
  properties over deterministic domains; the two newest cases (`:1982`, `:2012`) are
  **coverage-driven** dynamic-insertion cases, not requirement-derived.
- Runtime suite: `runtime_tests.cpp` records per-case `Description` and
  `DerivationTechnique = "design-analysis,equivalence-classes"` via `record_registration_key_metadata`
  and carries the minor-only regression at `:402-431` plus enabled/disabled/lifetime/slot-isolation
  cases.
- **Coverage-goal caveat.** The retained `focused_coverage` result records `score/socom/impl/`
  36/36 lines (100 %) but **11/14 branches (78.6 %)**, which is below **both** the QM 85 % and the
  safety 100 % platform goals (`verification_plan.rst:300-307`); `complete_target_scope: false` and
  `safety_class: unknown_requires_authorized_selection`. Three uncovered branches are
  compiler-generated (a `throw` edge and two function-local-static guard edges); a `noexcept`
  comparator would remove one edge but still leave 13-total/11-covered (84.6 %). No deviation is
  accepted here.
- **Shallow-case caveats (prior `lifetime_review.md` CE-2/CE-3).** Several "slot reuse" / "isolation"
  runtime cases never re-enable the replacement, so they exercise the key set but not
  `Service_record::m_server`; `ConnectorDestroyedAfterRuntimeDoesNotCrash` only covers the disabled
  state, so an *enabled* connector outliving the `Runtime` (use-after-free on the server
  registration) is not covered. These are test-design observations, not defects.

---

## 6. External-library (component dependency) inspection

The bounded change itself uses only already-available operators (`std::tie` over
`Registry_string_view::operator<` and `std::uint16_t`). The **system context** nevertheless depends
on external components whose Assumptions of Use (AoUs) are not verified here.

| External component | Role in this slice | AoU / risk recorded | Verified here? |
|--------------------|--------------------|---------------------|----------------|
| `score_baselibs` — `futurecpp` `SCORE_LANGUAGE_FUTURECPP_ASSERT` | Guards `!m_server` (`runtime_impl.cpp:369`); the change's stated purpose is to keep it unreachable | **Semantics (terminate vs compiled-out) are external and undetermined in this checkout** — the pre-change failure mode cannot be stated exactly | **No** |
| `score_baselibs` — `score::Result` / `Construction_error` | Duplicate path returns a typed `Result` error (consistent with `coding_guidelines.rst:117-129`) | Error path is `Result`-based and also used by the IPC/reporting layer | Focused compile only |
| `score_baselibs` — `score/mw/log` | Minor-incompatibility logging (`runtime_impl.cpp:512-517`, `:539-543`) | Out of the key path | **No** |
| `String_registry` (internal, but a lifetime dependency) | Interns the non-owning `Registry_string_view`s the key stores | Append-only, process-duration singletons; interning is what makes content-ordered `<` consistent with pointer-based `==`/`hash` | Focused tests only |
| GoogleTest `1.18.0` | Test framework for the focused runs | Its `TEST_F` macro expansion is the source of the CodeQL MISRA `external-linkage` / `switch-body` hits (macro artifacts) | Run (focused) |
| FlatBuffers `25.12.19` (config schema) | Supplies `service_version_minor = uint32 0xFFFFFFFF` default and `service_version_major: uint8` | Unchecked `static_cast<uint16_t>` narrowing across conversion sites; under the coarsened key a wildcard-narrowed `0xFFFF` server and a concrete-minor server for the same `(instance, id, major)` now collide as duplicates | **No** (out of slice) |
| `vsomeip` / `score_communication` / `message_passing` | Downstream service offer/discovery consumers of `make_server_connector` | Not built or run here | **No** |

**Doctrine applied.** `gd_req__verification_external_aou` (`verification_process.rst:214-226`)
requires external-component AoUs to be verified by integration tests or static-analysis tooling.
Neither ran for this slice: the QEMU/native legs exit `127` (missing `bazel`), clang-tidy did not run,
and the CodeQL runs are focused/dependency-only. No AoU requirement register exists in the repository.
**No external-component AoU is verified**, and none may be treated as satisfied.

---

## 7. Static / dynamic analysis inspection (retained artifacts)

All statuses below are **readings of retained `.llm_tmp/overnight/obligations/*/result.json` and
`.llm_tmp/overnight/validation/` artifacts**. A successful collection node means *retention*, not
*passing*.

| Check | Retained result | Design-inspection reading |
|-------|-----------------|---------------------------|
| GCC focused compile+tests | `gcc-compile` exit 0 (empty stderr); `gcc-tests` exit 0 | Clean for the focused identifier TU; corroborates the balanced header (§2) but is **not** a native criterion-9 measurement |
| Clang focused compile | exit **1** — googletest/libstdc++ `-Wdeprecated-declarations` under `-Werror` | Dependency error outside the candidate paths; the Clang branch of criterion 9 is **unmet**; no in-scope fix is permitted |
| clang-tidy | `--verify-config` exit **1** (15 `unknown check` warnings; `.clang-tidy` folded-block `#` comments + version drift) | **Did not run** — *not* "clean". Zero translation units analysed |
| cppcheck | exit **2**; 19 `passedByValue` (performance, CWE 398) in `registry_string_view.hpp` and `service_interface_identifier.hpp` | All findings in headers **outside** the candidate paths; no correctness finding in the changed key |
| CodeQL security | 32 findings, every `uri` under `.llm_tmp/googletest/**`; `level: null`; focused extraction | Dependency-only; **none** in candidate/project code; not a clean bill (focused) |
| CodeQL MISRA | focused set; in-scope hits are the gtest `TEST_F` macro expansion; blockers: draft/incomplete mapping, default suite omits manual/audit rules, query qualification pending | Needs human deviation / macro-aware tooling; **no MISRA compliance claimed** |
| ASan / LSan / UBSan | focused compile exit 0, tests exit 0, **87/87** passed, empty stderr | Genuine **focused** pass for the key comparator + string registry; single-threaded, excludes `runtime_tests.cpp` |
| TSan | compile exit 0, tests exit **-11** with **no stdout/stderr/json** (prior collections: `FATAL: ThreadSanitizer: unexpected memory mapping`) | Sanitizer **runtime startup / environment failure**, not a data race and not a source defect; **no result** |
| Memcheck | compile exit 0, `valgrind` absent → exit **127** | Tool unavailable; no result |
| Coverage | `score/socom/impl/` 100 % line / **78.6 %** branch; `complete_target_scope: false` | Branch below both platform goals; focused |
| native / cross / integration / sanitizers / tsan / lint / docs / traceability / coverage / performance / format-precommit | all exit **127** (`/tmp/s-core-001/bin/bazel` missing) | Not run; the native and QEMU scopes were never exercised |
| secret scan | `gitleaks` absent → exit 127 | Not run; inventory ≠ vulnerability scan |
| tool assurance | `valgrind`/`gitleaks` unavailable; collector-vs-pinned version drift; no Tool Verification Report | Tool **execution ≠ qualification**; owner acceptance pending |

**Discrimination rule applied.** A non-zero exit is attributed to a source defect only when the tool
actually executed the code and reported a finding. TSan (failed to start), memcheck/`gitleaks`/`bazel`
(absent) and clang-tidy (config rejected) yield **no verdict** — recorded as *"not run"* / *"blocked"*,
never *"clean"* and never a source bug. No finding in any retained analyzer points into
`service_identifier.cpp` / `service_identifier.hpp` or the authored test bodies.

---

## 8. Manual coding checks (construct-by-construct)

**Method and limits.** `coding_guidelines.rst` (`:status: valid`) selects **MISRA C++:2023 designed
for C++17** and requires `score::Result`-based error handling, avoiding exceptions
(`coding_guidelines.rst:117-129`). Because `misra_mapping.rst` is `:status: draft` with the rule
table commented out and `_assets/misra_2023.csv` absent, **no numbered MISRA rule is asserted to
"apply"** in the S-CORE sense; this is a manual construct inspection only. The `inspection_checklist.rst`
(`:status: draft`, blank) defines the intended slots `IMPL_01_01`…`IMPL_02_02`; this draft is
**input** to that inspection, not a filled checklist.

| # | Topic | Construct / reading | Disposition |
|---|-------|---------------------|-------------|
| MF-1 | Ordering | `Registry_string_view::operator<` is **content**-based while `operator==`/`std::hash` are **pointer**-based; consistency relies on `String_registry` interning by content | **Invariant to preserve** (not an observed defect) |
| MF-2 | Error handling | The comparator is **not declared `noexcept`** although it cannot throw and is called from a `noexcept` function (`runtime_impl.cpp:440`) | **Manual finding** — source change would need authorization; also removes one coverage `throw` edge |
| MF-3 | Documentation | `Construction_error::duplicate_service` is commented only "Service identifier already exists" (`error.hpp:55`), now narrower than the minor-ignoring key | **Manual finding** |
| MF-4 | Ordering | Key is deliberately ordering-only (no `operator==`/hash); future equality-container use must keep identity `(instance, id, major)` | Design note |
| MF-5 | Concurrency | The single-server assert is safe only while key identity == record identity; do not re-fine the key without re-examining concurrency | **Invariant to preserve** |
| MF-6 | Lifetime/teardown | Key-erase `Final_action` is declared after `m_registration`, so erase-after-unregister is implicit in `~Impl(){ disable(); }` | Recorded hazard (CE-4 / RCC-4) |
| MF-7 | Initialization | The key is a non-default-constructible aggregate; the sole production use supplies both members | OK (static) |
| MF-8 | Lifetime | Non-owning views must not outlive `String_registry`; the static-destruction-order path is untested | Unresolved |
| MF-9 | Traceability | `DerivationTechnique`/`Description` set; `TestType`/`Verifies` unset (no verified identifier) | Unresolved (human) |
| MF-10 | Measurement | No retained artifact compiles `runtime_tests.cpp`; identifier measurement is stale (85 vs 87 macros) | Unresolved |

Additional documentation surfaces that diverge from the implemented semantics (recorded, not
applied): `Runtime::make_server_connector`'s doc says duplicates are judged by *"the
configuration.interface and instance parameters"* (`runtime.hpp:170-191`), but public
`Service_interface_identifier::operator==` includes `minor` while the registration key does not; and
the `duplicate_service` enum comment above (MF-3). Both would be public/implementation documentation
edits requiring authorization.

**No confirmed safety-relevant defect in the changed comparator was found by these manual checks.**
That is a statement about *static inspection*, not a compliance or safety claim.

---

## 9. Interface and traceability consistency

### 9.1 Requirement / interface inventory (present)

`grep ':id:' docs` verifies only: stakeholder `stkh_req__someip_gw__interoperability`; feature
`feat_req__tc8_conformance__conformance`; and eight `comp_req__tc8_conformance__*`. All 11
`:reqtype:` occurrences are `Functional`; there is **no `:reqtype: Interface` need** and **no
`comp_req__socom__*`**. `docs/requirements/component/index.rst` and
`docs/requirements/feature/index.rst` are placeholder toctrees; no `aou_req__*` need exists. The
repository's own CI comments note thresholds "default to 0 while comp_req coverage is being
(re-)built up".

### 9.2 Test metadata conformance

| Rule element | Recorded value | Verdict |
|--------------|----------------|---------|
| Record properties mechanism (`gd_req__verification_link_tests_cpp`) | `RecordProperty` used in both candidate test files | **Met (mechanism)** |
| `DerivationTechnique` set, allowed value(s) | `boundary-values,equivalence-classes` (key); `design-analysis,equivalence-classes` (runtime) | **Met** |
| `Description` non-empty | present in both | **Met** (the key file uses one fixture-wide sentence for all cases — a quality observation) |
| `TestType` set (`gd_req__verification_checks:191`) | **absent in both** | **NOT MET** |
| `PartiallyVerifies`/`FullyVerifies` | **absent everywhere** | **Not set** — in a Unit Test a link must target a Component Requirement, and none exists |
| `fuzz-testing` technique | not claimed | Correctly not claimed (no harness, no measurement) |

`gd_req__verification_checks_extended` (`:211-212`) forbids `requirements-based` / `interface-test`
`TestType` without a real requirement/interface link; no honest link exists, and inventing one is
prohibited. Leaving `TestType` unset is therefore a **recorded incompleteness, not a pass**.

### 9.3 Interface-name / design consistency (IMPL_03_01 / IMPL_03_02 material)

- The internal key type and `operator<` are consistent between header and `.cpp`, and the code
  comments accurately describe the implemented semantics.
- The **design documents are silent** on the registration key / version identity / duplicate-server
  rejection (§4.7), and there is no requirement to trace to (§9.1). The chain is broken at both
  ends:
  - requirement → implementation: no `comp_req` captures "minor is not part of the duplicate-server
    registration key";
  - design → implementation: no design element in `score/socom/docs/` records the key or version
    semantics;
  - test → requirement/design: therefore `PartiallyVerifies`/`FullyVerifies` have no honest target.
- Public interface names (`Service_interface_identifier`, `Service_instance`) are unchanged; the
  key remains `impl/`-only, so no public UID/header surface changed.
- The docs/traceability gate (`bazel run //:docs`; `bazel run //:traceability_gate`) exited `127`
  (missing `bazel`); no `_build/metrics.json` / `needs.json` / gate output exists. The CI gate is
  `continue-on-error: true` with thresholds defaulting to `0`; **a nonblocking gate is not
  acceptance**, and its absence is not evidence of a pass.

---

## 10. Remaining safety-analysis (FMEA / DFA) impact questions — drafted, not answered

This section is **draft input**. Per the task, this review **does not act as the independent
reviewer**, does **not** select a safety class (authority: `safety_class: unknown`), does **not**
accept risk or deviations, and does **not** answer the human gate. The questions below are framed so
an authorized safety engineer / committer can resolve them. Failure modes are stated as
*possibilities to be dispositioned*, not as accepted defects.

### 10.1 FMEA-style failure modes to disposition

| Id | Failure mode (local effect) | Potential system effect | Change-related? | Question for the authorized reviewer |
|----|-----------------------------|-------------------------|-----------------|--------------------------------------|
| FMEA-1 | The comparator's non-throwing contract is not expressed (`noexcept` absent, MF-2); if a compare component ever threw, `std::set::insert` inside the `noexcept` `make_server_connector` would terminate | Service offer aborts instead of returning a `Result` error | Pre-existing pattern, surfaced by the key path | Should `noexcept` be added (and does that alter the applicable MISRA/coding rationale)? |
| FMEA-2 | Key identity and record-index identity could diverge again (future re-fining of the key) | Two servers for one record reach `ASSERT(!m_server)`; depending on `SCORE_LANGUAGE_FUTURECPP_ASSERT` semantics, terminate or silent `m_server` overwrite | **The change closes this**; a future change could reopen it | Confirm key identity must stay `(instance, id, major)` as a **concurrency/safety requirement**, with a guard/regression |
| FMEA-3 | `Impl` member-declaration order (MF-6) could release the key before the record is unregistered if `disable()` ever stops clearing `m_registration` | A new connector passes the duplicate gate, then the single-server assert is violated on enable | Pre-existing fragility; adjacent to the key lifetime | Approve declaring `m_final_action` before `m_registration`, or an explicit ordering guard/assert |
| FMEA-4 | Key/registration views are non-owning; a key outliving `String_registry` (static destruction order) dangles | Undefined behaviour at or after process shutdown | Pre-existing contract | Is the registry-outlives-key contract a verified assumption, and is an ordered-shutdown regression required? |
| FMEA-5 | Enabled connector outliving its `Runtime` (CE-1): the server-registration `Final_action` captures the destroyed `Service_record` | Use-after-free / dangling `m_runtime_mutex` on `enabled.reset()` | Pre-existing; the key's `weak_ptr` guard covers only the key erase | Decide whether an enabled connector may outlive the runtime; if not, correct the contract/test name; if yes, extend the lifetime guard to the registration |
| FMEA-6 | `Service_database` records are never erased (CE-5) | Monotonic memory growth over many distinct identities | Pre-existing, adjacent | Is permanent record retention acceptable for the target duty cycle, or is cleanup required? |
| FMEA-7 | Config minor wildcard `0xFFFFFFFF` narrows to `0xFFFF` and now collides with a concrete-minor server under the coarsened key | A previously distinct server configuration is rejected as `duplicate_service` (daemon logs and skips → silently unoffered service) | **Interaction introduced by the change** | Adjudicate wildcard representation/validation/error semantics; is the new collision the intended behaviour? |
| FMEA-8 | A `duplicate_service` at a daemon boundary is logged and skipped (prior `integration_aou_review` I-2) | A collision surfaces as a silently unoffered service rather than an actionable failure | Pre-existing; widened by FMEA-7 | Confirm the desired externally observable behaviour before integration acceptance |

### 10.2 DFA-style dependency/impact questions

1. **Assert semantics dependency.** The outcome of `ASSERT(!m_server)` (terminate vs compiled-out
   overwrite) depends on `score_baselibs` `futurecpp`, which is external and undetermined here.
   *Question:* what is the qualified AoU for `SCORE_LANGUAGE_FUTURECPP_ASSERT`, and does a compiled-out
   build turn FMEA-2/FMEA-3 into silent state corruption?
2. **Interning dependency (MF-1).** Content-ordered `<` over the `std::set` and pointer-based
   `==`/`hash` over the `unordered_map` coincide only because `String_registry` interns by content.
   *Question:* is interning a verified invariant (with a regression), and what detects a break?
3. **Configuration-data flow.** Config → socom narrows `uint32 minor` → `uint16` unchecked at several
   conversion sites. *Question:* where in the data flow is the wildcard/sentinel meant to be resolved,
   and what are the residual/accumulated effects of the `0xFFFF` collapse under the new key?
4. **Cross-component flow.** `make_server_connector` is a public virtual called by `someipd`,
   `gatewayd` and the IPC binding. *Question:* what is the impact of an earlier `duplicate_service`
   on the offer/discovery chain, and is that behaviour traceable to a requirement?
5. **Failure of the resource-lifetime flow (FMEA-6).** *Question:* what is the maximum distinct-identity
   population expected, and does permanent record retention meet it?
6. **Verification-independence flow.** All execution evidence is focused and local, and the author
   and reviewer roles are unfilled. *Question (process, not code):* who is the independent approver,
   and what evidence closes the `gd_req__verification_independence` requirement?

### 10.3 Explicit non-answers

No severity (Critical/High/Medium/Low), no ASIL/QM selection, no FMEA/DFA acceptance, no
risk acceptance and no deviation decision is made in this draft. Per
`gd_req__verification_sca_classification` (`verification_process.rst:228-248`) those require a
Quality Manager together with a committer. The failure-mode list is review input for that role, not
its output.

---

## 11. Obligations status (none satisfied)

### 11.1 Pinned state

`authority.json`: `engineering_acceptance: pending`, `human_reviews: unanswered`,
`safety_class: unknown`, `codeql_scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway; no
upload"`. Every `source-index.json` entry is `"native_acceptance": "not_inferred"`.

### 11.2 Status for this slice

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Freedom from compiler warnings & errors (100 %, criterion 9) | `verification_plan.rst:332-335` | **PARTIAL / NOT SATISFIED** — focused GCC exit 0 with empty stderr; Clang blocked on a googletest/libstdc++ deprecation; no Bazel native build; `runtime_tests.cpp` not compiled |
| Static code analysis executed, findings classified (Critical/High/Medium/Low) | `code_analysis.rst`; `verification_process.rst:228-248` | **NOT SATISFIED** — clang-tidy not run (config rejected); CodeQL focused and dependency-only; cppcheck out of scope; **no authorized classification** |
| Freedom from SCA critical/high (criterion 8) | `verification_plan.rst:328-331` | **NOT MEASURED** — no authorized classification |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` (`:status: draft`) | **UNKNOWN — NOT CLAIMED**; rule↔tool mapping inactive |
| Implementation inspection checklist `IMPL_01_01`…`IMPL_03_02` | `inspection_checklist.rst` (`:status: draft`) | **NOT FILLED** — this draft is input, not a filled inspection |
| Structural statement coverage goal | `verification_plan.rst:300-303` (criterion 1) | **MET for the focused TU only** — 36/36 lines; not measured for the full target |
| Structural branch coverage goal | `verification_plan.rst:304-307` (criterion 2) | **NOT MET** — 11/14 = 78.6 %, below both QM 85 % and safety 100 %; no deviation accepted |
| Unit/component testing executed and recorded (criteria 6-7) | `verification_plan.rst:320-327` | **PARTIAL, STALE** — retained focused 85 tests / 0 failures; tree has 87 macros; `runtime_tests.cpp` never executed |
| Interface / requirements-based / resource / fault-injection test types | `verification_process.rst`; `verification_plan.rst:167-240` | **NOT PERFORMED / applicability not inferred** — no harness; identifier/runtime-key tests must not be labelled platform validation |
| Boundary / equivalence derivation | `verification_process.rst:46-49` | **SOURCE-ONLY / PARTIALLY EXECUTED (focused)** |
| Fuzzy testing technique | `verification_plan.rst:265-270` | **NOT EXECUTED / NOT CLAIMED** — no harness, no measurement |
| Linking tests to requirements via record properties | `verification_process.rst` (`gd_req__verification_link_tests_cpp` `:56-75`) | **PARTIAL** — `DerivationTechnique`/`Description` set; `TestType`/`Verifies` unset because no verified native link exists |
| External AoUs verified | `verification_process.rst:214-226` | **NOT SATISFIED** — no integration test or static-analysis verdict; no AoU register |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** — missing tools; collector-vs-pin version drift; no Tool Verification Report |
| Independence of verification / review | `verification_process.rst:141-152` | **NOT DONE** — human reviews unanswered |
| Obligation-collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **RETAINED, NOT PASSING** — many `findings_or_execution_failure` / exit 127 |
| Native acceptance | `source-index.json` | **`not_inferred` for every entry** |

**Explicit non-satisfaction statement.** Missing tools (`bazel`, `valgrind`, `gitleaks`,
`clang-format`, `pre-commit`, `reuse`), the non-running clang-tidy, the focused/incomplete CodeQL
extraction, the draft/inactive MISRA mapping, the blank inspection checklist, the blocked native and
QEMU checks, the stale focused measurement, the unverified external AoUs, the unknown safety class and
un-inferred applicability, and the unanswered human reviews mean **none of the checked obligations
may be treated as satisfied**. A successful collection node proves *retention*, not passing; here the
retained results include explicit failures and non-runs.

---

## 12. What this draft deliberately does NOT claim

- No engineering acceptance, review approval, publication, or upload.
- No MISRA C++:2023 compliance and no statement that any numbered rule "applies" (mapping is draft).
- No safety class / ASIL / QM selection, no FMEA/DFA acceptance, no risk acceptance, no deviation.
- No claim that identifier-only / key-level tests are platform, feature or interface validation.
- No fuzzy-testing claim (no harness, no measurement).
- No invented native requirement or interface identifiers.
- No claim that TSan, memcheck, clang-tidy, the native Bazel suite, or the QEMU integration leg
  passed; each is blocked or did not run.
- No assertion that the wider #84 public `Service_interface_identifier` restructure, FindService
  wildcard handling, or config minor-wildcard narrowing is in scope.

---

## 13. Files changed / notice preservation

This iteration wrote **only this report** (`.llm_tmp/overnight/reports/design_inspection_draft.md`).

| Candidate path | State | This iteration |
|----------------|-------|----------------|
| `score/socom/impl/service_identifier.hpp` | brace-balanced; line 39 blank; documents minor exclusion | **unchanged** (verified, §2) |
| `score/socom/impl/service_identifier.cpp` | `operator<` identity `(instance, id, major)`, minor excluded | **unchanged** |
| `score/socom/BUILD` | `testonly` `impl_service_identifier` exposure present | **unchanged** |
| `score/socom/test/unit/BUILD` | `socom_test` globs `*.cpp`; deps wired | **unchanged** |
| `score/socom/test/unit/runtime_tests.cpp` | minor-only regression present (`:402-431`) | **unchanged** |
| `score/socom/test/unit/service_identifier_tests.cpp` | key matrix present | **unchanged** |
| `.llm_tmp/overnight/reports/design_inspection_draft.md` | **new — this report** | written |

- No source, build, test, config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was created, edited, or
  deleted; every existing Apache-2.0 / SPDX header is untouched. Every file under
  `.llm_tmp/overnight/prior-reports/`, every earlier file under `.llm_tmp/overnight/reports/`, and
  every host/obligation artifact under `.llm_tmp/overnight/validation/` and
  `.llm_tmp/overnight/obligations/` was read only and preserved.
- The flagged header `score/socom/impl/service_identifier.hpp` retains its Apache-2.0/SPDX header
  (`:1-12`) and was left unchanged because it is already balanced (§2). The sibling `.cpp`, both
  BUILD files, and both candidate test files retain their Apache-2.0/SPDX headers.
- No licensed MISRA rule text is reproduced; only native rule/query identifiers, source hashes and
  file locations are cited.
- This report itself carries the Apache-2.0 header.

---

## 14. Pending human review checklist

- [ ] **Confirm §2:** `service_identifier.hpp` is brace-balanced (braces at `:19,:29,:32,:38`;
      line `:39` blank; net balance 0); the recorded "extra closing brace at line 39" is stale or
      refers to a different revision. No source correction is required in this checkout.
- [ ] **Resolve the instruction conflict:** "inspect and correct the actual source" vs. "only that
      report may be written"; confirm that inspection-only (with the source already correct) was the
      intended outcome, and locate any distinct "cancelled draft" revision if it still carries the
      brace.
- [ ] **Ratify the implementation-vs-specification reading (§3):** the bounded change follows the
      unaccepted issue-#84 direction `service id + major`; confirm whether it is intended, and that
      the public type / IPC / compatibility rules stay unchanged in this slice.
- [ ] **Confirm the design invariants (§4):** key identity must equal record identity so the
      single-server `ASSERT(!m_server)` stays unreachable; the registration-teardown ordering; the
      discovery semantics stay confined to the `std::set` gate.
- [ ] **Add the missing design documentation (§4.7):** the registration-key identity
      (`instance + service id + major`, `minor` excluded), the duplicate-server rejection path and
      the public-vs-internal version asymmetry in `score/socom/docs/design/`, or record that the
      behaviour is intentionally undocumented.
- [ ] **Adjudicate the manual findings (§8):** MF-2 (`noexcept` on the comparator), MF-3
      (`duplicate_service` comment), MF-1 (interning invariant), MF-5 (key/record identity), MF-6
      (teardown order), MF-8 (view lifetime). Each source change needs authorization and a
      build/test cycle this review cannot run.
- [ ] **Author the missing requirement/interface links (§9):** add the `socom` component
      requirement(s) (and any feature/interface need) so `TestType` and the `PartiallyVerifies`/
      `FullyVerifies` links can be completed without invention; or record an approved
      tailoring/deviation.
- [ ] **Complete and activate the MISRA mapping and the inspection checklist** (`misra_mapping.rst`,
      `inspection_checklist.rst`), and complete the mandated SCA classification
      (`gd_req__verification_sca_classification`) by the Quality Manager together with a committer.
- [ ] **Restore/fix the tools and re-run:** `bazel` (native build/test/coverage/analyzer),
      `valgrind`, `gitleaks`, `clang-format`, `pre-commit`, `reuse`; repair the `.clang-tidy`
      `Checks: >` folded block so clang-tidy can run; run a **full-target** CodeQL extraction
      including `runtime_tests.cpp`.
- [ ] **Refresh the measurement:** run `bazel test //score/socom/test/unit:socom_test` (and the
      broader `//score/...` set) so `runtime_tests.cpp` and all 87 key cases are compiled and
      executed; do not re-report the 85-case focused artifact as coverage of the current tree.
- [ ] **Verify the external-component AoUs (§6)**, including the `SCORE_LANGUAGE_FUTURECPP_ASSERT`
      semantics and the FlatBuffers wildcard default, by integration test or static analysis.
- [ ] **Answer the drafted FMEA/DFA impact questions (§10)** as the authorized safety engineer /
      committer, selecting the safety class and recording risk/deviation decisions.
- [ ] **Schedule independent human review** (approver ≠ author, `gd_req__verification_independence`)
      and record engineering acceptance; no compliance/safety claim may be made before that, and no
      report may be uploaded (`codeql_scope`: no upload).

---

*End of design-inspection draft. Local, unprotected, scoped. No engineering acceptance; human
reviews unanswered; full native runtime tests pending; no MISRA compliance, safety classification,
FMEA/DFA acceptance, risk acceptance, or deviation is claimed, and this draft does not act as the
independent reviewer.*
