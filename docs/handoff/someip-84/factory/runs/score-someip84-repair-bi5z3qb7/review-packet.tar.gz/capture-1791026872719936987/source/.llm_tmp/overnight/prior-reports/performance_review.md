<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — performance / resource-usage review draft

**Document type:** review draft (performance/resource-usage scope + actual-source inspection + source-defined expectation register + retained benchmark/profiling output review + unmeasured-limits and unavailable-prerequisite register + obligations status)
**Date:** 2026-10-02
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version handling in socom* (issue #84)
**Run:** branch `fabro/run/01M3YRJEGXNY6CB81T7TKW774B`
**Status:** local, unprotected, scoped. **No engineering acceptance exists. Human reviews are unanswered. Full native runtime tests remain pending. No performance/resource acceptance threshold exists and none is invented here.** Every statement below is either a direct reading of the working tree, a direct reading of a retained artifact under `.llm_tmp/overnight/`, or an explicitly-labelled logical consequence. Nothing here is published, reviewed, accepted, or a full native run.

> **Tool / write boundary actually observed.** Only `read_file`, `grep`, `glob`, and `write_file` were used. No `shell`, delegation, web access, approval, publishing, or engineering acceptance was performed. **This iteration wrote exactly one file — this report** (`performance_review.md`). No source, build, test, config, `NOTICE`, `LICENSE`, `REUSE.toml`, validation, or prior-report file was created, edited, or deleted. Every file under `.llm_tmp/overnight/reports/` and `.llm_tmp/overnight/prior-reports/` was preserved unchanged.
>
> **Instruction conflict, recorded not silently resolved.** The task records *"a measured GCC syntax failure: an extra closing brace in `score/socom/impl/service_identifier.hpp` at line 39"* and directs *"Inspect and correct the actual source before expanding tests."* Direct inspection of the **actual** source (§2) shows the header is **already brace-balanced** (brace lines `:19,:29,:32,:38`; line `:39` blank), and the retained focused GCC compile exits `0`. There is no unmatched brace to remove. The task's own final sentence — *"This is a review draft: only that report may be written"* — forbids a source write in any case. **No source was edited and no test was expanded.** The conflict is recorded for the human reviewer (§11), not silently resolved.
>
> **Non-satisfaction rule applied throughout.** A successful obligation-collection node means the results were **retained**, not that the checks **passed**. Missing tools, unknown applicability, an undecided reference platform, incomplete extraction, and unanswered human reviews are **not** treated as satisfied. In particular, a benchmark/profiler that produced **no** output because it **did not run** is recorded as *"not run"*, never as *"fast"*, *"clean"*, or *"within budget"*. No numeric latency/throughput/memory limit is asserted as an obligation, because no pinned source defines one.

---

## 0. Summary

1. **The named GCC syntax failure is not present in the actual source (§2).** `score/socom/impl/service_identifier.hpp` is a 40-line, brace-balanced header; `grep '[{}]'` returns exactly `:19`, `:29`, `:32`, `:38` (two openers, two closers, net balance `0`) and line `:39` is blank. The described defect matches the *earliest* prior reports (split-form double close), not this checkout. **No correction is required or applied**, per the write boundary.
2. **There are no numeric performance/resource acceptance thresholds in the pinned sources (§4).** The pinned verification plan states only the *objective* ("response time and throughput", `verification_plan.rst:54-55`) and makes resource-usage evaluation a **Level 2/3 method, "only on reference environment"** (`:203-207`, `:216-219`); the same document records **"The reference hardware is not yet decided."** (`:610`). No budget for latency, throughput, CPU, or memory is defined for this slice. Nothing is invented here.
3. **No benchmark or profiling output was produced for this slice (§5).** The retained `native_performance` collection is a **failure to run** — both legs exit `127` because `/tmp/s-core-001/bin/bazel` is missing (`obligations/native_performance/result.json:236-296`); `benchmarks.stdout` and `profiling.stdout` are empty. The retained `focused_memcheck` is likewise a failure to run (`valgrind` missing, exit `127`).
4. **The retained performance *documentation* is draft, stale, and internally inconsistent with the actual benchmark source (§5.3).** `tests/benchmarks/benchmarks_analysis.md` attributes its ~50 ms latency floor to `MAIN_LOOP_SLEEP{50}` in `echo_server.cpp`, but the actual source defines `MAIN_LOOP_SLEEP{10us}` (`tests/benchmarks/echo_server.cpp:35`); its embedded SOME/IP raw output also carries `***WARNING*** Library was built as DEBUG. Timings may be affected.` (`:920`), contradicting the source-defined requirement that profiling/benchmarks use an optimized release build (`.github/skills/memory-profiling/SKILL.md:51-59`). It is a **descriptive artifact, not measured here and not an acceptance input**.
5. **Prerequisites are mixed (§7).** `perf` and `qemu-system-x86_64` binaries are present and `kvm_exists: true`, but the Bazel driver and `valgrind` are absent, so nothing performance-related could execute; the `perf-tests` config also needs an unprivileged-userns network wrapper that no retained artifact records as verified.
6. **No obligation is satisfied (§8).** Every `source-index.json` entry is `native_acceptance: not_inferred`; `authority.json` is `engineering_acceptance: pending`, `human_reviews: unanswered`, `safety_class: unknown`.

---

## 1. Binding, scope, and evidence

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` — *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:2-4` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` | `.llm_tmp/context/issue-snapshot.json:19-20` |
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |
| Current branch | `fabro/run/01M3YRJEGXNY6CB81T7TKW774B` | environment |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted obligation**, and it contains **no performance requirement**: service-instance identifier = `service id + major + minor + instance id`; service identifier = `service id + major`; FindService = `service id + major + optional<minor> + optional<instance>`; plus the proposal to exclude `minor` from identity. There is no comment and no acceptance record, so none of it is binding, and none of it defines a timing or memory budget.

### 1.2 The six writable candidate source paths (`candidate-files.json`)

| File (repo-relative) | Baseline git blob | Baseline present | Working tree (read this iteration) |
|----------------------|-------------------|------------------|------------------------------------|
| `score/socom/BUILD` | `3477ea0851fdcd82ec6ea9d71424013cbdf41962` | yes | `testonly` `impl_service_identifier` exposure |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e22355242009fe20dada2a9a0d0c7a9c7` | yes | key identity `(instance, service id, major)`; `minor` excluded (`:20-30`) |
| `score/socom/impl/service_identifier.hpp` | `c8bae7908da9f087c518934f7b9f8d86db9a20ec` | yes | brace-balanced, 40 lines; line 39 blank (§2) |
| `score/socom/test/unit/BUILD` | `3c03a7b14286051f97fa5022206564bd63645171` | yes | `socom_test` globs `*.cpp`; deps wired |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab726db8bf994c960045d6fd7fdf84d7395` | yes | runtime suite present |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(none — `null`)* | **no** (manifest expects a **new** file) | `ServiceInstanceIdentifierTest` matrix present |

The `null` baseline blob for `service_identifier_tests.cpp` is the manifest's expectation of a **new** unit-test file; it exists on disk only as part of the un-merged working tree (the "cancelled draft"), never in the baseline. The five present baseline blobs also appear in `.llm_tmp/context/source-manifest.json`, binding the candidate set to the baseline commit. **None of these six paths contains a benchmark, profiler harness, or performance requirement.**

### 1.3 Retained artifacts read this iteration (performance-relevant)

- `.llm_tmp/overnight/obligations/native_performance/` — `result.json`, `benchmarks.command.json`, `benchmarks.stdout`, `benchmarks.stderr`, `profiling.command.json`, `profiling.stdout`, `profiling.stderr`, `collection-result`.
- `.llm_tmp/overnight/obligations/native_integration/result.json` (QEMU/KVM prerequisites, exit 127).
- `.llm_tmp/overnight/obligations/focused_memcheck/result.json` (`valgrind` missing, exit 127).
- `.llm_tmp/overnight/obligations/focused_asan_lsan/result.json`, `focused_coverage/result.json` (retained focused runs, non-performance).
- `.llm_tmp/overnight/obligations/tool_assurance/result.json` (tool inventory: `perf`/`qemu` present; `bazel`/`valgrind` absent).
- `.llm_tmp/overnight/validation/measurement.json`, `before.json`, `after.json` (focused GCC/UBSan key-TU red→green; **not** a performance measurement).
- `.llm_tmp/overnight/reports/`: `native_build_review.md`, `integration_aou_review.md`, `bazel_plan.md`, `scope.md`, `key_fix.md`, `finding_classification.md`, `coverage_review.md`, `sanitizer_review.md` (read, preserved).
- Source-side expectation documents: `tests/benchmarks/README.md`, `tests/benchmarks/benchmarks_analysis.md`, `tests/benchmarks/echo_server.cpp`, `tests/benchmarks/BUILD.bazel`, `.bazelrc` (§4), `score/gateway_ipc_binding/benchmark/README.md`, `.github/skills/memory-profiling/SKILL.md`.

Per the task rule, a successful collection node means results were **retained**, not that checks **passed**.

### 1.4 Pinned authority and obligation sources

`authority.json`: `codeql_scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload"`, `engineering_acceptance: pending`, `human_reviews: unanswered`, `safety_class: unknown`, instruction *"Restart the failed queue for one complete pass through all obligations"* (`.llm_tmp/context/obligations/authority.json:1-7`). Every entry of `source-index.json` is `"native_acceptance": "not_inferred"`. The nine pinned sources in `.llm_tmp/context/obligations/` were read to the extent relevant to resource usage, chiefly `verification_plan.rst` (§4.1).

---

## 2. Actual-source inspection of the recorded syntax failure

### 2.1 Verdict: the header is brace-balanced

`score/socom/impl/service_identifier.hpp`, read directly this iteration:

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

`grep '[{}]'` on the file returns exactly `:19`, `:29`, `:32`, `:38` — two openers, two closers, net brace balance `0`. Line `:39` contains no text. `glob **/service_identifier.hpp` returns exactly one path, so there is no second, differently-braced copy in this checkout.

### 2.2 Tool corroboration (retained, not re-measured here)

The retained focused GCC compile of the candidate translation unit exits `0` with empty `stderr`, and the candidate focused test run is `85 tests / 0 failures / compile exit 0` (`validation/measurement.json`; `validation/after.json`), against `baseline_with_agent_tests` `85 tests / 28 failures / compile exit 0` (`validation/before.json`). A surviving extra closing brace would break all of these. (Scope caveat: this is a **focused single-translation-unit** run, not a Bazel build; see §9.)

### 2.3 Disposition

The described defect is a **stale, pre-correction description** that matches the earliest prior reports (split-form `}  // namespace socom` + `}  // namespace score`). The correction recorded by the `reproducer` iteration left line `:39` blank — exactly the state observed here. Applying the historical repair to the already-balanced file would be a no-op at best and a compile break at worst. **No correction is applied; none is required.** Consistent with the write boundary, no test was expanded either. If a distinct "cancelled draft" revision still carries the extra brace, it is not the file in this checkout and must be located and corrected by an authorized iteration.

---

## 3. What "performance" can mean for this bounded slice

The slice changes only the ordering operator of the internal duplicate-server registration key (`score/socom/impl/service_identifier.cpp:20-30`): `minor` is dropped from `std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major)`. Source-derived, not measured:

- **No new allocation, lock, or I/O** is introduced. The key is stored in `std::set<Service_instance_identifier>` under an existing mutex; the change only removes one `std::uint16_t` component from each tuple comparison.
- **Set cardinality cannot increase.** Excluding `minor` collapses previously distinct minor variants into one element, so the number of registration-key elements is weakly reduced. Whether this is observable is not measurable here.
- **No resource-management requirement** is attached to this type or to this change in any pinned or repository requirement source. The pinned `resource-usage` method is scoped to **Level 2 Feature Integration / Level 3 platform** on a **reference environment** (`verification_plan.rst:203-207`, `:216-219`), while this slice is a unit-level change; the same document states **"The reference hardware is not yet decided."** (`:610`).

Therefore the honest performance verdict for this slice is: **not measurable in this checkout, and not required by any definition-of-record to be measured at unit level.** The remainder of this report reviews what performance evidence *does* exist in the tree and why none of it is a result for this slice.

---

## 4. Source-defined performance / resource expectations (register)

### 4.1 Normative/pinned expectations

| # | Source | Expectation | Threshold? |
|---|--------|-------------|-----------|
| E-1 | `verification_plan.rst:54-55` | Verification objective *"Performance — Assess the software's performance to ensure it meets the required performance criteria, such as response time and throughput."* | **No number defined** |
| E-2 | `verification_plan.rst:203-207` | Test type `resource-usage` — *"Resource Usage Evaluation (only on reference environment)"*, applicable on *"-, 2 Feature Integration, -"*, QM & ASIL B. | **No number defined; not applicable to unit level** |
| E-3 | `verification_plan.rst:216-219` | `resource-usage` *"should also be considered for level 3 (software platform level) testing … on reference hardware"*. | **No number defined** |
| E-4 | `verification_plan.rst:610` | *"The reference hardware is not yet decided."* | Blocking precondition |
| E-5 | `verification_plan.rst:300-335` (criteria 1-9) | Coverage/warnings/etc. goals. | **None is a latency/throughput/memory goal** |

**Conclusion:** the pinned obligation set defines an *objective* to assess response time and throughput, but **no acceptance budget**, and it locates resource-usage evaluation on a reference environment/level that does not exist yet.

### 4.2 Benchmark-harness expectations (repository source)

| # | Source | Expectation | Threshold? |
|---|--------|-------------|-----------|
| E-6 | `.bazelrc:93-96` | `--config=perf-tests` = `--run_under=//tests/benchmarks:setup_network`, `--define=perf_tests=true`, `--compilation_mode=opt`. | Optimized build required; no number |
| E-7 | `.bazelrc:98-106` | `--config=perf-tests-flamegraphs` adds `-fno-omit-frame-pointer -g --strip=never`, `--define=flamegraphs=true`; comment *"Requires perf; FlameGraph scripts are downloaded by Bazel."* | Prerequisite, no number |
| E-8 | `tests/benchmarks/README.md:23-51` | Run e2e over `127.0.0.2`/`127.0.0.3` in an isolated namespace; results as `benchmarks.json`; *"Unprivileged user namespaces must be enabled so the Bazel `--run_under` wrapper can configure the isolated loopback addresses…"* | Prerequisite, no number |
| E-9 | `tests/benchmarks/BUILD.bazel:21-29,107-159` | `perf_tests`/`flamegraphs` config settings; `e2e_benchmarks`/`e2e_benchmarks_profiling` are `py_pytest` targets, `target_compatible_with` Linux only under `:perf_tests`. | No number |
| E-10 | `tests/benchmarks/README.md:35-38` | Profiling filter `IpcBenchmark/Throughput/3/.*`; `.perf.data`/`.perf.svg` written beside `benchmarks.json`. | No number |

**Conclusion:** the harness defines *how* to measure (opt build, isolated network, perf/flamegraph prerequisites) but defines **no pass/fail number**.

### 4.3 Memory/CPU profiling expectations (repository source)

| # | Source | Expectation | Threshold? |
|---|--------|-------------|-----------|
| E-11 | `.github/skills/memory-profiling/SKILL.md:51-59,114` | Profiling requires **release-optimized** binaries with **no sanitizers** (`bazel build -c opt --features=-tsan`); *"Do NOT run profiling with debug builds or sanitizers — results will be misleading."* | Method requirement |
| E-12 | `score/gateway_ipc_binding/benchmark/README.md:99-112` | *"Expected results for a healthy build":* peak heap (memusage) ≈ 172 KB; peak heap (Massif useful) ≈ 172 KB; peak stack ≈ 11 KB; total malloc ≈ 373; allocations all during initialization (zero per-iteration); no heap growth; no leaks. | **Guide expectations, not pinned requirements** |
| E-13 | `score/gateway_ipc_binding/benchmark/README.md:193-205` | Typical profile composition: syscall/kernel ≈74%, poll ≈26%, recv ≈31%, send ≈9%, mutex ≈10%, shared-memory ≈5%. | Typical, not a threshold |

**Conclusion:** the profiling guide provides *expected values of a healthy build*, but these are documentation examples, and the profiling tools (`valgrind`/`massif`, `memusage`, `perf`) plus the affected `gateway_ipc_binding` components are **outside** the six candidate paths and this slice.

### 4.4 Retained descriptive analysis (not a requirement)

`tests/benchmarks/benchmarks_analysis.md` is a **draft** document (`:22`, "Document Version 0.2 (Draft)"; `:23`, last updated 2026-03-23) reporting an older measurement campaign (`:20`, "Test Date: November 18, 2025"; raw SOME/IP output dated `2025-08-06`, `:911`). Its §7.1 "Automotive Industry Context" table (`:358-364`) lists "typical requirement" values (p99 < 100 ms, CV < 5%, 10-50 MB/s, CPU < 10%) in a column explicitly headed **"Typical Requirement"**, not "project requirement". **These are not obligations and are not adopted as thresholds here.** Its own internal caveats are discussed in §5.3.

### 4.5 Explicit statement on thresholds

**No pinned source and no repository requirement defines a numeric latency, throughput, CPU, heap, or stack limit for this slice or for the benchmark targets.** This review therefore records the limits as **unmeasured/unavailable** (§6) and **invents none**. The E-12 values are labelled as a profiling guide's "expected results", not as acceptance criteria.

---

## 5. Retained benchmark/profiling outputs vs source-defined expectations

### 5.1 `native_performance`: a failure to run, not a benchmark result

`obligations/native_performance/result.json` records two attempted commands and status `findings_or_execution_failure` (`:296`):

| Label | Attempted argv (abridged) | Exit | Reason |
|-------|---------------------------|------|--------|
| `benchmarks` | `/tmp/s-core-001/bin/bazel --batch … test --jobs=2 --config=perf-tests //tests/benchmarks/... --build_tests_only` (`:236-265`) | **127** | `[Errno 2] No such file or directory: '/tmp/s-core-001/bin/bazel'` (`:263`) |
| `profiling` | `… test --jobs=2 --config=perf-tests-flamegraphs //tests/benchmarks/... --build_tests_only` (`:266-294`) | **127** | same missing `bazel` (`:292`) |

Two independent issues are recorded here:

1. **The driver is absent** (`/tmp/s-core-001/bin/bazel`, `tool_assurance/result.json:458-462`, `available: false`), so neither leg ran. `benchmarks.stdout` and `profiling.stdout` are **empty** (no captured output), consistent with never starting.
2. **Even with Bazel present, the command could not produce a measurement.** Both legs pass `--build_tests_only` (`:247`, `:276`), which builds test targets but does **not** execute them. The `perf-tests` config's `--run_under=//tests/benchmarks:setup_network` (`.bazelrc:94`) is therefore never exercised. So this collection node, by construction, is a **build-only** check — it cannot yield latency, throughput, or profiling data, and it must not be cited as one.

**Verdict:** no benchmark and no profiling result exists for this slice; the retained node is an unavailable-tool blocker.

### 5.2 `native_integration` (KVM/QEMU): prerequisites present, run absent

`obligations/native_integration/result.json` attempts `bazel test --config=qemu-integration //quality/... //tests/integration_test/...` and exits **127** for the same missing `bazel` (`:263-264`), status `findings_or_execution_failure` (`:267`). It records `prerequisites: { "kvm_exists": true, "qemu": "/usr/bin/qemu-system-x86_64" }` (`:271-274`). **KVM/QEMU availability is a prerequisite, not a run**: there is no QEMU execution, no cross-target measurement, and therefore no reference-environment data. This matters for `resource-usage`, which the pinned plan scopes to the reference environment (§4.1).

### 5.3 `tests/benchmarks/benchmarks_analysis.md` vs the actual benchmark source

The retained analysis document is inconsistent with the current benchmark source and cannot be treated as a current result:

- **Sleep-constant contradiction.** The document repeatedly attributes its ~50 ms latency floor to *"a 50 ms polling sleep (`MAIN_LOOP_SLEEP{50}`) in `echo_server.cpp`"* (`benchmarks_analysis.md:37-41`, `:60-64`, `:154`, `:322-326`, `:408`). The **actual** source defines `constexpr auto MAIN_LOOP_SLEEP{10us};` (`tests/benchmarks/echo_server.cpp:35`) and sleeps for it at `:212` and `:252`. The document's central timeline narrative (a ~50 ms floor, and a doubled ~100 ms gateway round trip) therefore **does not match the current source-defined harness**; the document is stale relative to the tree or refers to a different revision. No replacement latency figure is derived here (that would be inventing a measurement).
- **Debug-build timing.** The embedded SOME/IP raw output states `***WARNING*** Library was built as DEBUG. Timings may be affected.` (`benchmarks_analysis.md:920`). That directly conflicts with the source-defined profiling method, which requires a release-optimized build (`SKILL.md:114`; `.bazelrc:96` `--compilation_mode=opt`). Timings from a DEBUG artifact are not valid under those expectations.
- **No artifact for the current tree.** No `benchmarks.json`, `.perf.data`, `.perf.svg`, `memory_profile/`, or `profiling/` output exists in this checkout (`glob` over `**/benchmarks.json`, `**/*.perf.*`, and `**/{memory_profile,profiling}/**` returns nothing). The numbers in the document are prose/tables, not a reproducible artifact retained here.

**Verdict:** the document is a descriptive draft with its own documented caveats; it is **not** a current, reproducible benchmark result for this slice and is not used as one.

### 5.4 Memory/profiling expectations vs available outputs

| Expectation | Where defined | Evidence available here | Status |
|-------------|---------------|-------------------------|--------|
| Release-optimized, no-sanitizer profiling build | `SKILL.md:51-59,114` | none (Bazel missing) | **NOT RUN** |
| Peak heap ≈172 KB, peak stack ≈11 KB, ≈373 mallocs, zero per-iteration, no leaks | `gateway_ipc_binding/benchmark/README.md:99-112` | no `memusage`/`massif` output retained | **NOT MEASURED** |
| Typical profile mix (syscall/poll/recv/send/mutex/shm) | `gateway_ipc_binding/benchmark/README.md:193-205` | no `perf.data`/flamegraph retained | **NOT MEASURED** |
| Focused memcheck of the key TU | `obligations/focused_memcheck/result.json` | compile exit `0`; `valgrind` leg **exit 127**, reason `No such file or directory: '/tmp/score-someip84-obligation-tools/usr/bin/valgrind'` (`:299-300`), status `findings_or_execution_failure` (`:303`), limit *"Optional complementary focused memory analysis"* (`:305-307`) | **NOT RUN** |

`tool_assurance/result.json` confirms `valgrind` is unavailable at both recorded paths (`:508-517`, `available: false`, `sha256: null`). Therefore neither the guide's expected memory values nor the memcheck path produced a result.

### 5.5 The one retained "resource-adjacent" measurement is not performance evidence

`focused_coverage` (`obligations/focused_coverage/result.json`) records `line_total 36 / line_covered 36 (100.0%)`, `branch_total 14 / branch_covered 11 (78.6%)`, `complete_target_scope: false`, `safety_class: unknown_requires_authorized_selection`. This is structural coverage of the focused key executable, **not** a timing/throughput/memory measurement, and it is already addressed by the coverage report. The validation `measurement.json` (`candidate 85/0`, `baseline 85/28`, `full_native_tests: not_executed`, `mode: ubsan`) is likewise a focused correctness/sanitizer run, **not** a performance result.

---

## 6. Unmeasured resource limits (register)

Nothing in this row was measured for this slice in this checkout. "Source-defined expectation" means an expectation exists in a source file; "No number" means no acceptance threshold is defined anywhere and none is invented.

| Metric | Source-defined expectation | Status for this slice |
|--------|----------------------------|-----------------------|
| Round-trip latency (p50/p90/p99) | Objective only (`verification_plan.rst:54-55`); descriptive ranges in draft `benchmarks_analysis.md` | **UNMEASURED** — `native_performance` exit 127; no artifact |
| Tail-latency jitter (CV, spread) | None beyond objective | **UNMEASURED** |
| Throughput (msg/s) | Objective only | **UNMEASURED** |
| Bandwidth (MB/s) | None (descriptive only) | **UNMEASURED** |
| CPU time / utilization | Profiling guide "typical" mix only (`gateway_ipc_binding/benchmark/README.md:193-205`) | **UNMEASURED** — no `perf`/flamegraph retained |
| Heap peak / stack peak | Guide "expected for a healthy build" (`:99-112`) | **UNMEASURED** — no `memusage`/Massif, `valgrind` missing |
| Allocation count / per-iteration allocations / leaks | Guide expectations (`:99-112`) | **UNMEASURED** |
| Registration-key comparison cost / set cardinality effect | Source-derived: weakly reduced; no threshold | **SOURCE-ONLY**, not measured (§3) |
| Reference-environment (Level 2/3) resource usage | `verification_plan.rst:203-219` | **NOT APPLICABLE / NOT RUN** — reference hardware undecided (`:610`) |

**No acceptance threshold is asserted for any row.** The E-12 and E-13 numbers remain labelled as profiling-guide examples.

---

## 7. Unavailable prerequisites (perf / KVM / build / profiling)

| Prerequisite | Evidence | Consequence |
|--------------|----------|-------------|
| Bazel driver `/tmp/s-core-001/bin/bazel` | `tool_assurance/result.json:458-462` `available: false`, `sha256: null`; collector env `USE_BAZEL_VERSION=8.6.0` | `native_performance`, `native_integration`, all `native_*`, `cross_compilation`, `format_precommit` exit **127** — no build, no benchmark, no profiling |
| `valgrind` | `tool_assurance/result.json:508-517` `available: false`; `focused_memcheck/result.json:299-300` | Massif/memcheck memory profiling impossible; no heap/stack/leak numbers |
| `perf` | `tool_assurance/result.json:504-507` **available: true**, sha256 `2d095308…` | Binary present, **but** flamegraph profiling needs Bazel + FlameGraph download + the `setup_network` wrapper; **not run** |
| QEMU + KVM | `native_integration/result.json:271-274` `kvm_exists: true`, `qemu: /usr/bin/qemu-system-x86_64` (sha256 `55862c76…`) | Present, **but** `native_integration` exit 127; no QEMU/reference-environment execution |
| Unprivileged user namespaces | required by `tests/benchmarks/README.md:50` for the `setup_network` `--run_under` wrapper | **Not recorded as verified** by any retained artifact; a hidden prerequisite of `perf-tests` |
| Reference hardware | `verification_plan.rst:610` *"not yet decided"* | Level 2/3 `resource-usage` cannot be executed or bounded |
| `gnuplot` (for `memusage.png`) | `gateway_ipc_binding/benchmark/README.md:64-70` | Not present in the tool inventory; timeline graph cannot be produced |
| Bazel `--build_tests_only` scope | `native_performance/result.json:247,276` | Even with Bazel present, these legs build tests only and cannot measure |

---

## 8. Obligations status (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Performance objective: response time & throughput assessed | `verification_plan.rst:54-55` | **NOT MEASURED** — no benchmark ran; no threshold defined |
| `resource-usage` evaluation (reference environment) | `verification_plan.rst:203-207,216-219` | **NOT APPLICABLE / NOT RUN** — Level 2/3; reference hardware undecided (`:610`) |
| Native performance check (`--config=perf-tests`) | `.bazelrc:93-96`; `tests/benchmarks/README.md` | **NOT RUN** — exit 127 (missing `bazel`); command was build-only anyway |
| Profiling / flamegraphs (`--config=perf-tests-flamegraphs`) | `.bazelrc:98-106` | **NOT RUN** — exit 127 (missing `bazel`) |
| Memory profiling (Massif/memusage) | `SKILL.md`; `gateway_ipc_binding/benchmark/README.md` | **NOT RUN** — `valgrind` missing; no artifacts |
| Focused memcheck of the key TU | `focused_memcheck` collector | **NOT RUN** — exit 127 (missing `valgrind`) |
| QEMU/reference integration (resource context) | `verification_plan.rst`; `.bazelrc:73-85` | **NOT RUN** — exit 127; KVM/QEMU prerequisites present only |
| Benchmark outputs reviewed against source expectations | this task | **DONE (documentary)** — the only retained performance document is draft/stale/inconsistent (§5.3); no current artifact exists |
| Tools identified / evaluated / qualified | `tool_management.rst` | **NOT ESTABLISHED** — `perf`/`qemu` present but `bazel`/`valgrind` absent; qualification needs authorized humans |
| Independence of verification / review | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Obligation collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **RETAINED, NOT PASSING** |
| Native acceptance | `source-index.json` | **`not_inferred` for every entry** |

**Explicit non-satisfaction statement.** The absent Bazel driver and `valgrind`, the `--build_tests_only` scope of the perf collection, the undecided reference hardware, the missing benchmark/profiling artifacts, and the unanswered human reviews mean **none of the checked obligations may be treated as satisfied**. A retained collection result shows *retention*, not passing; an absent output is **not** evidence of good performance.

---

## 9. Measurement and validation status

- **Tools used:** `read_file`, `grep`, `glob`, `write_file` only. No `shell`, delegation, web, approval, publishing, or engineering acceptance.
- **Measurements executed this iteration:** **none**. No build, no `bazel test`, no benchmark, no profiler.
- **Genuine executed results available in the checkout (not performance):** focused GCC/UBSan key-TU compile+tests (candidate 85/0; baseline 85/28), focused ASan/LSan/UBSan (exit 0), focused Clang compile (dependency-only error), focused coverage (100 % line / 78.6 % branch), CodeQL security/MISRA focused scans, cppcheck (exit 2, out of scope), and `git-init`/`git-add` in the format collector. None of these measures latency, throughput, CPU, or memory.
- **Not run / unavailable:** every Bazel target and config (including `perf-tests`, `perf-tests-flamegraphs`, `qemu-integration`); `valgrind`/Massif/`memusage`; `gitleaks`; `pre-commit`; `reuse`; `clang-format`; clang-tidy analysis; QEMU/reference-environment execution.
- **Scope:** local, unprotected, scoped. This is not acceptance, review, publication, or a full native run; no performance claim is made.
- **Reproduction path for a later, authorized iteration (not executed here):**

  ```bash
  # Requires the pinned Bazel driver, network-namespace privileges, and (for flamegraphs) perf + FlameGraph.
  bazel test --config=perf-tests        //tests/benchmarks:e2e_benchmarks --test_output=streamed
  bazel test --config=perf-tests-flamegraphs //tests/benchmarks:e2e_benchmarks_profiling --test_output=streamed
  # Focused key-level correctness (not a performance measurement):
  bazel test //score/socom/test/unit:socom_test --test_filter='ServiceInstanceIdentifierTest.*'
  # Memory profiling (requires valgrind; release/no-sanitizer build):
  bazel build -c opt --features=-tsan //score/gateway_ipc_binding/benchmark:gateway_ipc_binding_memory
  ```

  Any value produced must be compared to a **human-approved** budget; none exists today (§4.5).

---

## 10. Notice preservation

- No source, build, test, config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was created, edited, or deleted by this iteration; **only this report was written.**
- The header the task flagged (`score/socom/impl/service_identifier.hpp`) retains its Apache-2.0/SPDX comment (`:1-12`) and was left unchanged because it is already brace-balanced (§2). The sibling `service_identifier.cpp` (`:1-12`), both BUILD files, both candidate test files, and the benchmark/profile source files retain their Apache-2.0/SPDX headers.
- All files under `.llm_tmp/overnight/reports/` and `.llm_tmp/overnight/prior-reports/` were preserved unchanged; this document is a new `reports/` entry.
- This report itself carries the Apache-2.0 header. No licensed MISRA rule text is reproduced; only rule/query identifiers and file locations are cited.

---

## 11. Pending human review checklist

- [ ] **Confirm §2:** `service_identifier.hpp` is brace-balanced (brace lines `:19,:29,:32,:38`; line 39 blank; net balance 0); the recorded "extra closing brace at line 39" is stale or refers to a different revision. No source correction is required in this checkout; if a distinct "cancelled draft" revision still carries the brace, locate and correct it by an authorized iteration.
- [ ] **Resolve the instruction conflict:** "Inspect and correct the actual source" vs. "this is a review draft: only that report may be written"; confirm that writing only this report was intended and that the no-op on already-correct source is acceptable.
- [ ] **Confirm §4.5:** no numeric latency/throughput/CPU/memory acceptance threshold exists in the pinned sources, and none should be inferred; treat `benchmarks_analysis.md` §7.1 "Typical Requirement" values and `gateway_ipc_binding/benchmark/README.md` §"Memory Profiling Results" as documentation examples, not obligations.
- [ ] **Restore the native driver and profiling tools** (`bazel` at `USE_BAZEL_VERSION=8.6.0`, `valgrind`, and — for flamegraphs — `perf` plus FlameGraph scripts) and re-run `native_performance` and `native_integration`, ensuring the performance legs **execute** benchmarks rather than `--build_tests_only`.
- [ ] **Confirm/record the unprivileged-userns prerequisite** (`tests/benchmarks/README.md:50`) and the KVM/QEMU setup before any reference-environment measurement; note that `kvm_exists: true` and QEMU presence are not a run.
- [ ] **Decide the reference hardware / resource-usage applicability** (`verification_plan.rst:203-219,610`) and either schedule Level 2/3 `resource-usage` evaluation or record it as out of scope for this unit-level slice.
- [ ] **Reconcile the stale analysis with source:** update or retire `tests/benchmarks/benchmarks_analysis.md` (the `MAIN_LOOP_SLEEP{50}` vs source `10us` mismatch, and the DEBUG-build timing warning), and regenerate benchmark/profile artifacts from a release (`-c opt`) build.
- [ ] **Disposition the slice's own performance posture** (§3): confirm the source-derived reading that the key change adds no allocation/lock and weakly reduces set cardinality, and either accept the absence of a unit-level performance requirement or define one.
- [ ] **Select the safety class**, schedule independent human review (approver ≠ author per `gd_req__verification_independence`), and record engineering acceptance; no performance compliance claim may be made before that.
- [ ] **Supply the missing/refreshed artifacts** (`.llm_tmp/overnight/obligations/*/result.json`, benchmark/profiling outputs) into this checkout; do not infer performance from absence or from a failed-to-run node.

---

*End of review draft. Local, unprotected, scoped. No engineering acceptance; human reviews unanswered; full native runtime and performance/profiling runs pending. The retained benchmark/profiling nodes are failures-to-run (missing `bazel`/`valgrind`), not results; no latency, throughput, CPU, heap, or stack limit is measured, and no acceptance threshold is invented.*
