<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — sanitizer review (ASan / LSan / UBSan / TSan) review draft

**Document type:** review draft (retained sanitizer-artifact audit + scope
analysis + runtime-startup-vs-source-defect discrimination + runtime connector
teardown / slot-reuse coverage assessment + obligations status)
**Date:** 2026-10-02
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise
version handling in socom* (issue #84)
**Run:** `fabro/run/01M3YRJEGXNY6CB81T7TKW774B`
**Status:** local, unprotected, scoped. **No engineering acceptance exists.
Human reviews are unanswered. Full native runtime tests remain pending.**
Every statement below is either a direct reading of the working tree, a direct
reading of the retained artifacts under `.llm_tmp/overnight/`, or an
explicitly-labelled logical consequence. Nothing here is published, reviewed,
accepted, or a full native run.

> **Tool / write boundary actually observed.** Only `read_file`, `grep`,
> `glob`, and `write_file` were used. No `shell`, delegation, web access,
> approval, publishing, or engineering acceptance was performed. The task's
> final sentence — *"This is a review draft: only that report may be written."*
> — is the operative write boundary. **This iteration wrote exactly one file:
> this report.** No source, build, test, config, `NOTICE`, `LICENSE`,
> `REUSE.toml`, or prior-report file was created, edited, or deleted. All prior
> reports under `.llm_tmp/overnight/reports/` and
> `.llm_tmp/overnight/prior-reports/` are preserved unchanged.
>
> **Instruction conflict (recorded, not silently resolved).** The task says the
> cancelled draft has *"a measured GCC syntax failure: an extra closing brace in
> `score/socom/impl/service_identifier.hpp` at line 39"* and directs *"Inspect
> and correct the actual source before expanding tests"*, but also says *"only
> that report may be written."* Direct inspection of the **actual** source (§2)
> shows the header is **already brace-balanced** and line 39 is **blank**; there
> is no unmatched brace to remove. The write boundary forbids a source write in
> any case. **No source was edited and no test was expanded.**
>
> **Non-satisfaction rule applied throughout.** A successful obligation-collection
> node means the results were **retained**, not that the checks **passed**.
> Missing tools, unknown applicability, incomplete extraction, an inactive rule
> mapping, and unanswered human reviews are **not** treated as satisfied. A tool
> that produced **no** finding because it **did not run** is recorded as *"not
> run"*, never as *"clean"*.

---

## 0. Summary

1. **ASan + LSan + UBSan pass, but only on the focused identifier translation
   unit (§3).** `focused_asan_lsan` compiled `service_identifier.cpp` +
   `string_registry.cpp` + `service_identifier_tests.cpp` + gtest with
   `-fsanitize=address,leak,undefined -fno-sanitize-recover=all` (compile exit
   `0`), ran it with `ASAN_OPTIONS=detect_leaks=1:halt_on_error=1` and
   `UBSAN_OPTIONS=halt_on_error=1` (tests exit `0`), and reported **87/87
   passed** with empty `stderr`. No address error, leak, or UB report was
   emitted. This is a genuine *focused* pass for the changed key unit and the
   string registry it links — **not** a full `//score/...` sanitizer run.
2. **TSan did not produce a usable result (§4).** `focused_tsan` compiled the
   *same* focused translation unit successfully (compile exit `0`) but the test
   process died with **exit `-11` (SIGSEGV)** and produced **no `stdout`, no
   `stderr`, and no `tests.json`**. Earlier retained collections of the same
   check recorded exit `66` with `FATAL: ThreadSanitizer: unexpected memory
   mapping` (prior reports). A process that dies *before* gtest prints
   `Running main()` — as this one did, since the ASan run of the identical
   source set printed it — is failing at sanitizer runtime startup, not in the
   candidate source. **Classified as a runtime/infrastructure startup failure,
   not a source defect and not a data race.** It is **not** a pass and does
   **not** establish freedom from data races.
3. **Memcheck is unavailable (§5).** `focused_memcheck` compiled the focused
   translation unit (exit `0`) but `valgrind` is absent
   (`/tmp/score-someip84-obligation-tools/usr/bin/valgrind`), so the check exits
   `127` with no memcheck result.
4. **The full-scope sanitizer checks never ran (§5).** `native_sanitizers`
   (`--features=asan,lsan,ubsan_clang`) and `native_tsan` (`--features=tsan`)
   over `//score/... //tests/...` both exit `127` because
   `/tmp/s-core-001/bin/bazel` is missing. No full-target ASan/LSan/UBSan/TSan
   evidence exists.
5. **Runtime connector teardown / slot-reuse is not covered by any sanitizer run
   (§6).** The behaviour *is* unit-tested in
   `score/socom/test/unit/runtime_tests.cpp` (destroy-and-recreate, enabled
   destroy-and-recreate, changed-minor reuse, and major/instance/service-id slot
   isolation), but that file is **not compiled into the focused sanitizer
   executables**, and the native sanitizer targets that *would* include it are
   blocked on `bazel`. So the key-erase / slot-reuse path is **unverified under
   ASan/LSan/UBSan** and **unverified under TSan**.
6. **The recorded GCC syntax failure is not present in the actual source (§2).**
   `score/socom/impl/service_identifier.hpp` is a 40-line brace-balanced header
   (braces at `:19`, `:29`, `:32`, `:38`; line `:39` blank). No correction is
   required or applied.
7. **No obligation is satisfied (§9).** Sanitizer coverage is partial (ASan/LSan/
   UBSan focused only), TSan and memcheck have no result, the full native
   sanitizer scope is blocked, `authority.json` records
   `engineering_acceptance: pending`, `human_reviews: unanswered`,
   `safety_class: unknown`, and every `source-index.json` entry is
   `native_acceptance: not_inferred`.

---

## 1. Binding, scope, and evidence

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` — *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:2-4` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` | `.llm_tmp/context/issue-snapshot.json:19-20` |
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json` |

The body is a **design proposal, not an accepted obligation**. It proposes
service-identifier = `service id + major` and to exclude `minor` from the service
identity. There is no acceptance record in the snapshot, so none of it is
binding.

### 1.2 The six writable candidate source paths

From `.llm_tmp/context/candidate-files.json`:

1. `score/socom/BUILD`
2. `score/socom/impl/service_identifier.cpp`
3. `score/socom/impl/service_identifier.hpp`
4. `score/socom/test/unit/BUILD`
5. `score/socom/test/unit/runtime_tests.cpp`
6. `score/socom/test/unit/service_identifier_tests.cpp` (baseline blob `null` — a **new** file)

The changed implementation is the registration-key comparator only:

```cpp
// score/socom/impl/service_identifier.cpp:20-30
return std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major) <
       std::tie(rhs.instance, rhs.interface.id, rhs.interface.version.major);
```

i.e. identity is `(instance, service id, major)`; `minor` is deliberately
excluded, matching the minor-ignoring `Service_database` index.

### 1.3 Retained sanitizer artifacts read this iteration

Paths are relative to `/workspace` (read, not produced, here).

| Artifact | What it records | Reading |
|----------|-----------------|---------|
| `.llm_tmp/overnight/obligations/focused_asan_lsan/result.json` | focused TU; `compile` exit `0` (`:274`), `tests` exit `0` (`:298`), `status: completed` (`:301`), limit *"Focused identifier executable; full native runtime scope measured separately"* (`:304`) | **pass (focused)** |
| `.llm_tmp/overnight/obligations/focused_asan_lsan/tests.stdout` | `Running 87 tests from 1 test suite` (`:2`); `[ PASSED ] 87 tests` (`:183`) | **87/87** |
| `.llm_tmp/overnight/obligations/focused_asan_lsan/tests.stderr`, `compile.stderr` | empty | no sanitizer diagnostic |
| `.llm_tmp/overnight/obligations/focused_tsan/result.json` | focused TU; `compile` exit `0` (`:273`), `tests` exit **`-11`** (`:297`), `status: findings_or_execution_failure` (`:300`) | **no usable result** |
| `.llm_tmp/overnight/obligations/focused_tsan/tests.stdout`, `tests.stderr` | empty | process died before any output |
| `.llm_tmp/overnight/obligations/focused_tsan/tests.json` | **absent** (glob shows no `tests.json` in the directory) | gtest never wrote results |
| `.llm_tmp/overnight/obligations/focused_memcheck/result.json` | focused TU; `compile` exit `0` (`:272`), `memcheck` exit `127`, `reason: ... '/tmp/score-someip84-obligation-tools/usr/bin/valgrind'` (`:299-300`) | **tool unavailable** |
| `.llm_tmp/overnight/obligations/native_sanitizers/result.json` | `bazel test //score/... //tests/... --features=asan --features=lsan --features=ubsan_clang` (`:243-250`), exit `127`, `bazel` missing (`:266`) | **not run** |
| `.llm_tmp/overnight/obligations/native_tsan/result.json` | `bazel test //score/... //tests/... --features=tsan` (`:243-248`), exit `127`, `bazel` missing (`:264`) | **not run** |
| `.llm_tmp/overnight/obligations/process_checks/result.json` | metadata inventory: `runtime_tests.cpp` `test_macros: 33` (`:248`); `service_identifier_tests.cpp` `test_macros: 87` (`:257`) | current test inventory |
| `.llm_tmp/overnight/obligations/rework_progress/result.json` | `source_changed_this_round: true`, `rework_requested: false`, stop reason *"One complete pass requested; unresolved findings stay pending"* (`:239-241`) | unresolved findings retained |

Host validation under `.llm_tmp/overnight/validation/` (also read):
`check-result` = `0`; `measurement.json` is `origin: local_unprotected_measurement`,
`initiator: Fabro host hook`, `mode: ubsan`, `engineering_acceptance: pending`,
`full_native_tests: not_executed`, compiler `/usr/bin/x86_64-linux-gnu-g++-12`,
`candidate` = **85 tests / 0 failures / compile 0**,
`baseline_with_agent_tests` = **85 tests / 28 failures / compile 0**;
`after-compile.command.json` shows the focused identifier TU built with
`-fsanitize=undefined -fno-sanitize-recover=all` (a *UBSan-only* focused host
check, distinct from `focused_asan_lsan`). `after.json` records **85** tests,
i.e. it predates the **87**-test tree (per `process_checks`).

### 1.4 Pinned obligation sources read

All nine `.llm_tmp/context/obligations/source-index.json` entries are present,
with `authority.json`:

| id | file | status note |
|----|------|-------------|
| `coding_guidelines` | `coding_guidelines.rst` | `:status: valid`; MISRA C++:2023, C++17 |
| `code_analysis` | `code_analysis.rst` | `:status: valid`; static analysis **and** dynamic analysis/sanitizers described (`:53-104`) |
| `misra_mapping` | `misra_mapping.rst` | **`:status: draft`**; rule table commented out |
| `verification_plan` | `verification_plan.rst` | `:status: valid`; quality criteria 1–9 (criteria 6–7 = executed/passed tests; 8 = SCA critical/high free; 9 = compiler warnings/errors free) |
| `development_plan` | `development_plan.rst` | `:status: valid`; C++17, GCC host, Bazel |
| `tool_management` | `tool_management.rst` | `:status: valid`; identify / evaluate / qualify |
| `verification_process` | `verification_process.rst` | `:status: valid`; test types and SCA classification |
| `verification_guideline` | `verification_guideline.rst` | `:status: valid`; traceability, independence, reporting |
| `inspection_checklist` | `inspection_checklist.rst` | **`:status: draft`**; blank template |

**Applicability nuance recorded for honesty:** `code_analysis.rst:53-55` states a
dynamic code analysis *"is not explicitly required by any S-CORE related
standards"* but that ASAN/LSAN, TSAN, UBSAN, and Memcheck *"should be used"* to
catch common errors. The sanitizers are therefore a **guideline-level quality
measure**, not a hard standards mandate; but per the non-satisfaction rule they
are still **not treated as satisfied** where evidence is partial or absent.

`authority.json`: `codeql_scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway;
no upload"`, `engineering_acceptance: pending`, `human_reviews: unanswered`,
`safety_class: unknown`. Every `source-index.json` entry is
`native_acceptance: not_inferred`.

---

## 2. The recorded GCC syntax failure — inspection of the actual source

`score/socom/impl/service_identifier.hpp` read from the working tree is a
40-line, **brace-balanced** header with its Apache-2.0/SPDX header intact
(`:1-12`):

| Line | Content | Role |
|------|---------|------|
| 14 | `#ifndef SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include guard begin |
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`) and two closers (`:32`, `:38`): net brace balance
`0`. There is **no third, unmatched closing brace**, and line 39 contains no
text. The sibling `service_identifier.cpp` uses the same nested form
(closers at `:30`, `:32`) and is balanced.

The retained tools corroborate a compiling unit: `focused_asan_lsan` and
`focused_tsan` both **compile exit 0** (and the focused host `candidate` is
`compile 0`). The only non-zero compiler result elsewhere is the Clang
googletest/libstdc++ `-Wdeprecated-declarations` dependency error, outside the
six paths.

**Disposition.** The described defect is a **stale, pre-correction description**
matching the earliest prior reports (split-form `}  // namespace socom` +
`}  // namespace score`). Re-applying the historical repair to the already
balanced file would be a no-op at best and a compile break at worst. **No
correction was applied; none is required.** If a distinct "cancelled draft"
revision still carries the extra brace, it is not the file in this checkout and
must be located and corrected by an authorized iteration.

---

## 3. ASan / LSan / UBSan review

### 3.1 What was built and run

`focused_asan_lsan` (`result.json:236-300`):

- **Compile** — `g++-12 -std=c++17 -Wall -Wextra -Werror -pthread -I.` over
  `score/socom/impl/service_identifier.cpp`,
  `score/socom/impl/string_registry.cpp`,
  `score/socom/test/unit/service_identifier_tests.cpp`, plus the vendored
  `gtest-all.cc` / `gtest_main.cc`, linked with
  `-fsanitize=address,leak,undefined -fno-sanitize-recover=all -g`.
  **exit `0`**; `compile.stderr` empty.
- **Tests** — the focused binary with
  `ASAN_OPTIONS=detect_leaks=1:halt_on_error=1` and
  `UBSAN_OPTIONS=halt_on_error=1`. **exit `0`**; `tests.stderr` empty.
- **Result** — `[==========] 87 tests from 1 test suite ran` and
  `[  PASSED  ] 87 tests` (`tests.stdout:2,182-183`).

### 3.2 Reading and scope

| Aspect | Value |
|--------|-------|
| Sanitizers active | ASan (address), **LSan** (leak; `detect_leaks=1`), UBSan (`-fsanitize=undefined`, `halt_on_error=1`) |
| Findings | **none emitted** (no ASan/LSan/UBSan report; empty `stderr`) |
| Tests | 87/87, all `ServiceInstanceIdentifierTest` |
| Production units exercised | `service_identifier.cpp` (the changed registration-key comparator) and `string_registry.cpp` |
| **Not** exercised | `score/socom/test/unit/runtime_tests.cpp`; all other `//score/...` units; the threaded stress suite |
| Self-declared limit | *"Focused identifier executable; full native runtime scope measured separately"* (`result.json:304`) |

**This is a real pass for the changed key unit and the string registry.** The
changed comparator and the registry intern path are exercised by 87 tests with
address, leak, and undefined-behaviour detection enabled, and no diagnostic was
produced. It is **not** evidence about the runtime connector, the service
database, or threaded code, and it is **not** a full-target sanitizer result.

### 3.3 What "no finding" does not mean

Because the run is single-threaded and covers only the identifier TU, it cannot
detect: runtime connector construction/teardown, slot reuse and key erasure,
the `std::set` mutex discipline, bridge/client/server locking, or any data race.
Those are the subject of §6.

---

## 4. TSan review

### 4.1 What was built and run

`focused_tsan` (`result.json:236-305`) compiled the **same focused translation
unit** (`service_identifier.cpp` + `string_registry.cpp` +
`service_identifier_tests.cpp` + gtest) with `-fsanitize=thread -g`.
**Compile exit `0`**; `compile.stdout`/`compile.stderr` empty.

The test invocation (`result.json:276-297`):

- argv: the focused binary with `--gtest_output=json:...` — **exit `-11`**
  (terminated by SIGSEGV).
- `tests.stdout` — **empty**.
- `tests.stderr` — **empty**.
- `tests.json` — **absent** (glob shows the directory contains only
  `collection-result`, `compile.command.json`, `compile.stderr`,
  `compile.stdout`, `result.json`, `tests.command.json`, `tests.stderr`,
  `tests.stdout`).

`status: findings_or_execution_failure` (`result.json:300`), with the same
limit *"Focused identifier executable; full native runtime scope measured
separately"* (`:303`).

### 4.2 Why this is a startup/infrastructure failure, not a source defect

Four independent observations support the classification:

1. **No output whatsoever.** The focused binary emits gtest's `Running main()
   from ...` line as its very first action; the ASan run of the *identical*
   source set did emit it (`focused_asan_lsan/tests.stdout:1`). The TSan run
   emitted nothing, so the process died **before `main()` ran any test**. That
   is the signature of sanitizer-runtime initialisation failure, not of a
   source-level crash inside a test.
2. **The same code passes ASan/LSan/UBSan 87/87.** If the exercised identifier
   code had a memory-safety defect capable of a SIGSEGV, the ASan run — which is
   strictly more sensitive to illegal access — would have reported it. It did
   not.
3. **The focused tests are single-threaded.** `ServiceInstanceIdentifierTest`
   constructs and compares `ServiceInstanceIdentifier` values and consults the
   string registry; it spawns no threads. There is no concurrency in the
   exercised code for TSan to diagnose, and a SIGSEGV there is not a data-race
   report (a TSan finding prints `WARNING: ThreadSanitizer: data race ...` and
   exits with its own code, not a bare `-11` with empty streams).
4. **Retained prior collections recorded the concrete environment message.**
   Earlier collections of `focused_tsan` recorded exit `66` with
   `FATAL: ThreadSanitizer: unexpected memory mapping` (prior reports; see
   `.llm_tmp/overnight/reports/tool_findings_repair.md:191,289`,
   `.llm_tmp/overnight/reports/analyzer_plan.md:347,460`,
   `.llm_tmp/overnight/reports/finding_classification.md:401`). That message is
   the well-known TSan / ASLR kernel-mmapping incompatibility, i.e. an
   environment failure at startup.

**Caveat on the current artifact.** In *this* recollection the `FATAL` message
is **not** present in the retained `tests.stderr` (it is empty). The empty
streams are consistent with the runtime aborting before flushing to the captured
pipe, but they mean the current artifact, read alone, states only *"exit -11,
no output"*. The environmental interpretation therefore rests on: (a) the
identical-source ASan pass, (b) the single-threaded scope, (c) the
before-`main()` death, and (d) the prior retained collections' explicit
`FATAL` message. It does **not** rest on a source-derived defect.

### 4.3 Classification and consequence

| Question | Answer |
|----------|--------|
| Is there a reported data race? | **No** — TSan produced no report at all. |
| Is there a source defect indicated? | **No** — compile clean; identical code passes ASan/LSan/UBSan; no test ever ran. |
| Is this a runtime startup/infrastructure failure? | **Yes** — death before `main()`, no output, prior `unexpected memory mapping` record. |
| Does this satisfy the concurrency check? | **No.** "No result" is not "clean". TSan is **not run / failed to start**, and freedom from data races is **not established**. |
| Does the TSan job actually cover the thread-relevant code? | **No.** Even had it started, the focused TU is single-threaded; the meaningful TSan scope is the out-of-candidate stress suite (§6.4). |

Minor observation: the TSan test environment carried `ASAN_OPTIONS` and
`UBSAN_OPTIONS` (`result.json:293-294`) — copies from the ASan check that are
irrelevant to TSan and would not affect its startup failure. This suggests the
check's environment template is shared and not TSan-specific; it is a
tooling-configuration observation only.

---

## 5. Memcheck and native sanitizer checks

### 5.1 Memcheck (complementary, unavailable)

`focused_memcheck` compiled the focused TU (exit `0`) and then attempted
`valgrind --tool=memcheck --leak-check=full --error-exitcode=42 --xml=yes ...`
(`result.json:274-301`). The binary path
`/tmp/score-someip84-obligation-tools/usr/bin/valgrind` does not exist, so the
command exits `127` with
`reason: [Errno 2] No such file or directory: '.../valgrind'` and `status:
findings_or_execution_failure`. Its own limit calls it *"Optional complementary
focused memory analysis"*. **No memcheck result exists; not satisfied.**

### 5.2 Full native sanitizer scope (blocked)

| Check | Command | Result |
|-------|---------|--------|
| `native_sanitizers` | `bazel test //score/... //tests/... --features=asan --features=lsan --features=ubsan_clang` | exit `127`, `/tmp/s-core-001/bin/bazel` missing (`result.json:266`) |
| `native_tsan` | `bazel test //score/... //tests/... --features=tsan` | exit `127`, `/tmp/s-core-001/bin/bazel` missing (`result.json:264`) |

Both are `findings_or_execution_failure`. The CI equivalent
(asan/lsan/ubsan and tsan over `//score/... //tests/...`) has **not** executed
here (prior report `.llm_tmp/overnight/reports/analyzer_plan.md:351-352`).
**No full-target sanitizer evidence exists.**

---

## 6. Runtime connector teardown / slot-reuse coverage

The task specifically asks whether connector teardown and slot reuse are
covered. They are **unit-tested** but **not covered by any sanitizer run**.

### 6.1 What the focused sanitizer executables actually include

Both `focused_asan_lsan` and `focused_tsan` compile exactly:

```
score/socom/impl/service_identifier.cpp
score/socom/impl/string_registry.cpp
score/socom/test/unit/service_identifier_tests.cpp
.llm_tmp/googletest/.../gtest-all.cc
.llm_tmp/googletest/.../gtest_main.cc
```

`runtime_tests.cpp` is **not** in the argument list
(`focused_asan_lsan/result.json:249-253`;
`focused_tsan/result.json:249-253`). All 87 executed tests are
`ServiceInstanceIdentifierTest`; the fixture set is key-comparison only.

### 6.2 What the runtime unit suite does cover (read, not run under sanitizers)

`score/socom/test/unit/runtime_tests.cpp` contains **31 `TEST_F` + 1 `TEST`
(`:239`) + 1 `TEST_P` (`:1311`)** (per `process_checks/result.json:248`). The
connector teardown / slot-reuse contract is pinned by, among others:

| Test | Line | Contract exercised |
|------|------|---------------------|
| `CreatingServerConnectorDeletingItAndRecreatingReturnsValidServerConnector` | `:371` | destroy erases the registration key; the same slot registers again |
| `ConstructDuplicateAfterEnabledConnectorDestroyedReturnsValidServerConnector` | `:986` | destroying an **enabled** connector disables it, erases the key, and frees the slot |
| `ConstructDuplicateAfterDisabledConnectorDestroyedWithChangedMinorVersionReturnsValidServerConnector` | `:1045` | freed disabled slot is reusable with a changed minor |
| `ConstructDuplicateAfterEnabledConnectorDestroyedWithChangedMinorVersionReturnsValidServerConnector` | `:1091` | freed enabled slot is reusable with a changed minor |
| `ConnectorDestroyedAfterRuntimeDoesNotCrash` | `:1021` | connector outlives the runtime; the key's `weak_ptr` guard path |
| `DestroyingOneMajorSlotKeepsOtherMajorSlotOccupied` | `:1141` | destruction frees only its own `(instance, id, major)` slot |
| `DestroyingOneInstanceSlotKeepsOtherInstanceSlotOccupied` | `:1197` | instance-slot isolation |
| `DestroyingOneServiceIdSlotKeepsOtherServiceIdSlotOccupied` | `:1253` | service-id-slot isolation |
| `ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError` | `:402` | the issue-#84 minor-excluding key regression |

These tests exercise the real registration entry point
(`Runtime::make_server_connector`) and the key-erasing `Final_action` lifetime.
They are, however, **single-threaded**.

### 6.3 The sanitizer coverage gap

| Behaviour | Unit-tested? | Exercised under ASan/LSan/UBSan? | Exercised under TSan? |
|-----------|--------------|----------------------------------|------------------------|
| Key comparator / string registry | yes (`service_identifier_tests.cpp`, 87) | **yes** (87/87, focused) | **no** (TSan died at startup) |
| Connector destroy → key erase → slot reuse | yes (`runtime_tests.cpp`) | **no** — file not in the focused sanitizer TU | **no** |
| Enabled destroy → disable → key erase | yes (`:986`, `:1091`) | **no** | **no** |
| Slot isolation across major/instance/service-id | yes (`:1141`, `:1197`, `:1253`) | **no** | **no** |
| Connector outliving runtime (`weak_ptr` guard) | yes (`:1021`) | **no** | **no** |
| Concurrent register/teardown races | **no** unit test; stress suite only | **no** | **no** |

Consequences:

- The **teardown / slot-reuse source path is not sanitizer-verified**. If the
  key-erase `Final_action` or the connector destructor ordering had a memory
  error (e.g. a use-after-free on the erased key or a double-erase), the
  focused ASan/LSan run would not see it, because that code is never linked in.
- The **native sanitizer target that would include `runtime_tests.cpp`**
  (`native_sanitizers`, over `//score/...`) is blocked on missing `bazel`
  (§5.2).
- The focused tests, being single-threaded, also cannot exercise the concurrency
  contract recorded in `concurrency_review.md` (single-lock, no-inversion;
  key-held-across-registration).

### 6.4 Where a meaningful TSan run would have to go

The project's concurrency tests live in the separate, out-of-candidate target
`//score/socom/test/stress:socom_stress_test`
(`score/socom/test/stress/*.cpp`, with `tsan.supp`), which is **not** part of
`socom_test` and was **not** executed (prior report
`concurrency_review.md:449-465`). The focused identifier TU is the wrong
instrument for TSan regardless of the startup failure. No TSan evidence exists
for the connector teardown/slot-reuse or concurrency paths.

---

## 7. Distinguishing runtime startup / infrastructure failures from source defects

The task asks for this discrimination explicitly. The retained sanitizer
signals separate cleanly:

| Signal | Evidence | Classification | Source defect? |
|--------|----------|----------------|----------------|
| ASan/LSan/UBSan focused | compile `0`, tests `0`, 87/87, empty `stderr` (`focused_asan_lsan`) | **genuine focused pass** | none reported |
| TSan focused | compile `0`, tests `-11`, **no stdout/stderr/json** (`focused_tsan`); prior `FATAL: ThreadSanitizer: unexpected memory mapping` | **sanitizer runtime startup / environment failure** | **no** — died before `main`; same code passes ASan |
| memcheck focused | compile `0`, `valgrind` missing, exit `127` | **tool unavailable** | n/a |
| `native_sanitizers` | `bazel` missing, exit `127` | **infrastructure/tool unavailable** | n/a |
| `native_tsan` | `bazel` missing, exit `127` | **infrastructure/tool unavailable** | n/a |

**Rule applied:** a non-zero exit is attributed to a source defect only when the
tool actually executed the code and reported a finding. A sanitizer that fails
to start (TSan) or a tool that is absent (`valgrind`, `bazel`) yields **no
verdict** — it is recorded as *"not run"* / *"blocked"*, never as *"clean"* and
never as a source bug.

---

## 8. Sanitizer coverage matrix (current state)

| Check | Scope actually built | Scope actually run | Result | Satisfies the check? |
|-------|----------------------|--------------------|--------|----------------------|
| `focused_asan_lsan` (ASan+LSan+UBSan) | identifier TU + string_registry + gtest | 87 identifier tests | **pass** | only for the focused identifier scope |
| `focused_tsan` | identifier TU + string_registry + gtest | none (startup SIGSEGV) | **no result** | **no** |
| `focused_memcheck` | identifier TU + string_registry + gtest | none (`valgrind` absent) | **no result** | **no** |
| `native_sanitizers` (asan/lsan/ubsan_clang) | — | none (`bazel` absent) | **not run** | **no** |
| `native_tsan` (tsan) | — | none (`bazel` absent) | **not run** | **no** |
| host `validation` (mode `ubsan`) | identifier TU + string_registry + gtest | 85 (stale) | **pass, stale** | only historical focused UBSan |

---

## 9. Obligations status (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Dynamic code analysis / sanitizers used | `code_analysis.rst:53-104` | **PARTIAL / NOT SATISFIED** — ASan/LSan/UBSan focused pass only; TSan no result; memcheck unavailable; native scope blocked |
| ASan/LSan (memory errors, leaks) | `code_analysis.rst:100-103` | **PARTIAL** — focused identifier pass; runtime connector/teardown not exercised |
| UBSan (undefined behaviour) | `code_analysis.rst:91-98` | **PARTIAL** — focused identifier pass; runtime not exercised |
| TSan (data races) | `code_analysis.rst:85-89` | **NOT SATISFIED** — startup failure, no result; thread-relevant stress suite not run |
| Memcheck (complementary) | `code_analysis.rst:76-83` | **NOT SATISFIED** — tool unavailable (exit `127`) |
| Relative amount of executed tests (100 %) | `verification_plan.rst:320-323` (criterion 6) | **NOT SATISFIED** — full native suite not executed; `runtime_tests.cpp` never run |
| Relative amount of passed tests (100 %) | `verification_plan.rst:324-327` (criterion 7) | **NOT SATISFIED** — no full native run |
| Freedom from compiler warnings & errors (100 %) | `verification_plan.rst:332-335` (criterion 9) | **PARTIAL** — focused GCC/ASan/TSan compiles exit `0`; Clang blocked on a dependency deprecation; no full-target warnings-as-errors build |
| Static code analysis classified | `verification_process.rst`; `code_analysis.rst` | **NOT SATISFIED** — clang-tidy not run; CodeQL focused/dependency-heavy; MISRA mapping draft (per `finding_classification.md`) |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` | **UNKNOWN** — mapping `:status: draft` |
| Fault-injection / interface / requirements / resource test types | `verification_plan.rst:167-240`; `verification_process.rst` | **NOT PERFORMED / applicability not inferred** |
| Linking tests to requirements (record properties) | `verification_process.rst` | **PARTIAL** — `DerivationTechnique`/`Description` set; `TestType`/`Verifies` unset (no invented links) |
| Independence of verification / review | `verification_process.rst` | **NOT DONE** — human reviews unanswered |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** for this slice — `bazel`, `valgrind` unavailable; TSan environment failing |
| Obligation collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **RETAINED, NOT PASSING** |
| Native acceptance | `source-index.json` | **`not_inferred` for every entry** |

**Explicit non-satisfaction statement.** The focused ASan/LSan/UBSan pass is
real but covers only the identifier translation unit; TSan produced no result
(startup failure) and memcheck is unavailable; the full-scope sanitizer targets
never ran (`bazel` absent); `runtime_tests.cpp` (including the connector
teardown and slot-reuse cases) is not compiled by any sanitizer run; the
`runtime_tests.cpp` metadata is 33 macros and `service_identifier_tests.cpp` is
87 macros while the host `after.json` still shows 85; and human reviews and
engineering acceptance are pending/unanswered. Therefore **none of the checked
sanitizer or verification obligations may be treated as satisfied.** A retained
collection result shows *retention*, not passing.

---

## 10. Notice preservation

- **Only this report was written.** No source, build, test, config, `NOTICE`,
  `LICENSE`, `REUSE.toml`, or prior-report file was created, edited, or deleted.
  All prior reports under `.llm_tmp/overnight/reports/` and
  `.llm_tmp/overnight/prior-reports/` are preserved unchanged.
- The header the task flagged (`score/socom/impl/service_identifier.hpp`) was
  inspected and left unchanged because it is already brace-balanced (§2); its
  Apache-2.0/SPDX header (`:1-12`) is intact. The sibling
  `service_identifier.cpp`, both BUILD files, and both candidate test files
  likewise retain their Apache-2.0/SPDX headers.
- This report carries the Apache-2.0 header.
- No licensed MISRA rule text is reproduced; only native rule/tool identifiers
  and file locations are cited.

---

## 11. Pending human review checklist

- [ ] **Confirm §2:** `service_identifier.hpp` is brace-balanced
      (`:19,:29,:32,:38`; line 39 blank); the recorded "extra closing brace at
      line 39" is stale or refers to a different revision; no source correction
      is required in this checkout.
- [ ] **Resolve the instruction conflict:** "inspect and correct the actual
      source" vs "only that report may be written"; confirm that writing only
      this report was intended, and that no source edit was expected because no
      defect is present.
- [ ] **Ratify the §3 reading:** ASan/LSan/UBSan pass 87/87 on the focused
      identifier TU with empty `stderr`, and the ASan argument
      `-fsanitize=address,leak,undefined` plus `ASAN_OPTIONS=detect_leaks=1`
      genuinely includes LSan.
- [ ] **Ratify the §4 classification:** TSan exit `-11` with no output is a
      sanitizer-runtime/startup (environment) failure, not a data race or a
      source defect; confirm the prior `FATAL: ThreadSanitizer: unexpected
      memory mapping` record and decide the remediation (e.g. reduce kernel
      address-space randomisation on the run host, or pin a TSan-compatible
      toolchain/kernel).
- [ ] **Do not treat TSan as passed.** If concurrency must be evidenced, run the
      out-of-candidate stress suite under TSan
      (`//score/socom/test/stress:socom_stress_test` with `--features=tsan` and
      the suite's `tsan.supp`), not the single-threaded focused identifier TU.
- [ ] **Close the teardown / slot-reuse sanitizer gap (§6):** include
      `runtime_tests.cpp` in a sanitized build once `bazel` is available, or
      explicitly record that the connector teardown/erase/reuse path has no
      ASan/LSan/UBSan coverage.
- [ ] **Restore or record the absent tools:** `valgrind` (memcheck) and `bazel`
      (`native_sanitizers`, `native_tsan`), or document accepted tooling
      deviations; do not infer passing from absence.
- [ ] **Refresh the measurement:** run the full native suite
      (`bazel test //score/socom/test/unit:socom_test` and `//score/...`) so
      `runtime_tests.cpp` and the current 87-case identifier suite are actually
      executed; the host `after.json` (85 tests) is stale.
- [ ] **Schedule independent human review** (approver ≠ author, per
      `gd_req__verification_independence`) and record engineering acceptance; no
      compliance claim may be made before that.
- [ ] **Keep the wider #84 public `Service_interface_identifier` restructure,
      FindService wildcard handling, and the config minor-wildcard narrowing out
      of this bounded slice** until separately accepted.

---

*End of review draft. Local, unprotected, scoped. No engineering acceptance;
human reviews unanswered; full native runtime tests pending. TSan produced no
usable result; memcheck and the full native sanitizer scope were not executed;
the focused ASan/LSan/UBSan pass covers only the identifier translation unit
and does not extend to runtime connector teardown or slot reuse.*
