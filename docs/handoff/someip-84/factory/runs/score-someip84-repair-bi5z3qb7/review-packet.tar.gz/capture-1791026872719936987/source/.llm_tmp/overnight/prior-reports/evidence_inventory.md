<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — evidence inventory and host-measurement reconciliation

**Document type:** review draft (host-measurement / changed-hash / remaining-runtime
evidence inventory and reconciliation)
**Date:** 2026-10-02
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version
handling in socom* (issue #84)
**Run / branch:** `fabro/run/01M3YRJEGXNY6CB81T7TKW774B`
**Baseline commit:** `f8a196c3b16d5172d898394ab99b0ed81346d63d`
(`.llm_tmp/context/source-manifest.json:3`)
**Status:** local, unprotected, scoped. **No engineering acceptance exists. Human
reviews are unanswered. Full native runtime tests remain pending.** Every statement
below is either a direct reading of this checkout / the retained artifacts, or an
explicitly-labelled logical consequence. **Agent statements are assertions; none is
an acceptance, an approval, or proof that an obligation passed.**

> **Write boundary observed.** Only `read_file`, `grep`, `glob`, and `write_file`
> were available and were the only tools used. No `shell`, delegation, web access,
> approval, publishing, or engineering acceptance was performed. The task's final
> sentence — *"This is a review draft: only that report may be written."* — is the
> binding write constraint, so **exactly one file was created or modified: this report
> (`/workspace/.llm_tmp/overnight/reports/evidence_inventory.md`).** No source, build,
> test, config, `NOTICE`, `LICENSE`, `REUSE.toml`, `validation/`, `obligations/`, or
> prior-report file was created, edited, or deleted. Every notice/licence header and
> every retained host artifact was preserved.
>
> **Instruction conflict recorded, not silently resolved.** The task also says
> *"Inspect and correct the actual source before expanding tests"* and records *"a
> measured GCC syntax failure: an extra closing brace in
> `score/socom/impl/service_identifier.hpp` at line 39."* Direct inspection (§2) shows
> the header is **already brace-balanced** and line 39 is **blank**; there is no
> unmatched brace to remove. The write boundary forbids a source write in any case. The
> conflict is therefore **moot on the facts** and is recorded for the human reviewer
> (§11).
>
> **Non-satisfaction rule applied throughout.** A successful obligation-collection node
> means results were **retained**, not that checks **passed**. Missing tools, unknown
> applicability, incomplete extraction, an inactive/draft rule mapping, and unanswered
> human reviews are **not** treated as satisfied. A tool that produced **no** finding
> because it **did not run** is recorded as *"not run"*, never as *"clean"*.

---

## 0. Summary

1. **The recorded GCC syntax failure is not present in the actual source (§2).**
   `score/socom/impl/service_identifier.hpp` is a 40-line, brace-balanced header: two
   openers (`:19`, `:29`) and two closers (`:32`, `:38`), net balance `0`, line `:39`
   blank. The retained focused **GCC** compile of the same translation unit exits `0`
   with empty stderr, and the retained GCC tests run **87/87 green**. The only non-zero
   compiler result is **Clang**, blocked by a libstdc++-12/googletest
   `-Wdeprecated-declarations` error under `-Werror` — a dependency/toolchain issue, not
   a brace/syntax defect. **No source correction is required or applied (§2, §7).**
2. **Host measurements were reconciled against the current tree (§3).** The retained
   host measurement (`validation/measurement.json`) is a **focused, stale** red→green
   record: `baseline_with_agent_tests` = 85 tests / 28 failures / compile 0;
   `candidate` = 85 tests / 0 failures / compile 0; it compiled **only** the focused
   identifier TU and **never** `runtime_tests.cpp` or any Bazel target. Its
   `service_identifier_tests.cpp` hash is the **85-macro** state; the working tree now has
   **87** `TEST_F` macros.
3. **Changed source hashes were reconciled (§5).** The context snapshot
   (`candidate-files.json`) and the tool-measured tree **disagree** on every candidate
   path. The tool-measured hashes (post-rework) are the authoritative record of what the
   collector actually analyzed; the snapshot hashes describe an earlier draft state.
   This is a reconciliation of *recorded values* (no local hashing tool was available);
   the current tree's macro counts corroborate the tool-measured state.
4. **Remaining full-runtime checks are blocked, not passed (§6).** All native / cross /
   QEMU / coverage / lint / docs / traceability / performance legs exited `127`
   (`/tmp/s-core-001/bin/bazel` absent); `runtime_tests.cpp` (33 macros) has never been
   compiled or executed by any retained artifact.
5. **Unresolved findings are inventoried, not resolved (§7).** Clang dependency error;
   Clang-Tidy configuration blocker (no analysis); 19 Cppcheck `passedByValue`
   suggestions in out-of-slice headers; a CodeQL security set (all dependency) and a
   large CodeQL MISRA set, all `level: null` (no authorized severity
   classification); TSan environment failure
   (`-11`); memcheck/`valgrind` unavailable; branch coverage 78.6 % below both platform
   goals; requirement/interface traceability links absent; secret scan not run.
6. **No obligation is satisfied (§8).** Every `source-index.json` entry is
   `native_acceptance: not_inferred`; `authority.json` records
   `engineering_acceptance: pending`, `human_reviews: unanswered`,
   `safety_class: unknown`.

---

## 1. Binding, scope, and the artifact set read

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` — *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:2-4` |
| State | `open`, 0 comments, no milestone / assignee / labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG`, created/updated `2026-04-14T13:23:24Z` | `.llm_tmp/context/issue-snapshot.json:8,19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an
accepted obligation**. It distinguishes service-instance identifier = `service id + major
+ minor + instance id`; service identifier = `service id + major`; FindService = `service
id + major + optional<minor> + optional<instance>`; and proposes to "exclude the minor
version and make it a property of the service instance". There is **no comment and no
acceptance record**, so none of it is binding. Binding is **by baseline commit**, not by
run HEAD.

### 1.2 In-scope candidate source paths (context snapshot)

From `.llm_tmp/context/candidate-files.json`: `score/socom/BUILD`,
`score/socom/impl/service_identifier.cpp`, `score/socom/impl/service_identifier.hpp`,
`score/socom/test/unit/BUILD`, `score/socom/test/unit/runtime_tests.cpp`, and
`score/socom/test/unit/service_identifier_tests.cpp` (baseline blob `null` — the manifest
expects a **new** file, the un-merged "cancelled draft").

### 1.3 Current as-is state read this iteration

| Item | Reading (direct) |
|------|------------------|
| Key type | `Service_instance_identifier{ Service_interface_identifier interface; Service_instance instance; }` (`impl/service_identifier.hpp:29-32`), one out-of-line `operator<` (`:35`) |
| Key identity | `operator<` orders by `(instance, service id, major)`; **minor excluded** (`impl/service_identifier.cpp:28-29`) |
| Key use | `std::set<Service_instance_identifier>` (`impl/runtime_impl.hpp:56`), inserted in `Runtime_impl::make_server_connector` (`impl/runtime_impl.cpp:443,449-454`) |
| Runtime regression | `RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError` present (`test/unit/runtime_tests.cpp:402-431`) |
| Key suite | **87** `TEST_F` under `ServiceInstanceIdentifierTest` (first `:168`, last `:2012`, incl. two newest at `:1982`, `:2012`) |
| Runtime suite | **31** `TEST_F` + **1** `TEST` + **1** `TEST_P` = 33 macros (`runtime_tests.cpp`) |
| Build wiring | `//score/socom:impl_service_identifier` test-only header exposure (`score/socom/BUILD:46-54`); `socom_test` globs `*.cpp` and depends on it (`test/unit/BUILD:16-29`) |

These counts were verified this iteration by `grep`; they are structural readings, not
hash measurements.

---

## 2. The recorded syntax failure — inspection of the actual source

### 2.1 Finding (re-verified this iteration)

`score/socom/impl/service_identifier.hpp` is **brace-balanced**. `grep '[{}]'` returns
exactly four brace-bearing lines:

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers, two closers: net balance `0`. There is **no third, unmatched closing brace**,
and line 39 contains no text.

### 2.2 Corroboration from the retained measurements

- `validation/measurement.json`: `candidate.compile_exit = 0`,
  `baseline_with_agent_tests.compile_exit = 0`; `before-compile`/`after-compile` stderr are
  empty.
- `obligations/compiler_diagnostics/result.json`: `gcc-compile` exit `0` (empty stderr),
  `gcc-tests` exit `0`; `gcc-tests.stdout` shows **87 tests, 87 passed**.
- The **only** non-zero compiler result is `clang-compile` exit `1`, whose stderr is a
  `-Wdeprecated-declarations` **error** on
  `/usr/lib/gcc/x86_64-linux-gnu/12/.../bits/stl_tempbuf.h:263`, instantiated from
  vendored `.llm_tmp/googletest/googletest/src/gtest.cc:3068` via `std::stable_sort`
  (native id `-Wdeprecated-declarations`; location **not** in any candidate path). This is
  a dependency/toolchain diagnostic, **not** the described brace error.

### 2.3 Disposition

The described defect is a **stale, pre-correction description** that matches the earliest
prior reports (split-form `}  // namespace socom` + `}  // namespace score`). Every later
report and the actual source show the nested form with a single closer. Re-applying the
historical repair (replace two closers with one) to the already-balanced file would be a
no-op at best and a compile break at worst. **No correction was applied; none is
required.** The minimal historical repair is retained for reference only:

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

This is a static source reading plus retained-tool readings; it is **not** a full native
criterion-9 measurement (§6, §8).

---

## 3. Host measurement inventory (`.llm_tmp/overnight/validation/`)

Files present (glob): `check-result`, `measurement.json`, `before.json`, `after.json`,
`before-compile.{command.json,stderr,stdout}`, `after-compile.{command.json,stderr,stdout}`,
`before-test.{command.json,stderr,stdout}`, `after-test.{command.json,stderr,stdout}`.

### 3.1 Collector marker and summary

| Artifact | Content (direct reading) |
|----------|--------------------------|
| `check-result` | `0` — collector success marker only; **not** a passing-engineering claim |
| `measurement.json` | `check_ref: check_conversion_tests`; `mode: ubsan`; `status: completed`; `changed_paths: ["score/socom/test/unit/service_identifier_tests.cpp"]`; `origin: local_unprotected_measurement`; `initiator: Fabro host hook`; `engineering_acceptance: pending`; `full_native_tests: not_executed`; `compiler: /usr/bin/x86_64-linux-gnu-g++-12` (`88315fd2…`) |
| `measurement.json` baseline | `baseline_with_agent_tests = {compile_exit 0, test_exit 1, tests 85, failures 28, disabled 0}` |
| `measurement.json` candidate | `candidate = {compile_exit 0, test_exit 0, tests 85, failures 0, disabled 0}` |

`before.json` = 85 tests / **28 failures** / 0 errors (all failures are
`ServiceInstanceIdentifierTest` cases whose minor-exclusion expectations fail against a
key that still includes `minor`). `after.json` = 85 tests / **0 failures** / 0 errors.
This is the focused red→green record for the key-level minor exclusion.

### 3.2 Exact commands

Both compile commands (`before-compile.command.json`, `after-compile.command.json`) are
the focused translation unit:

```
/usr/bin/x86_64-linux-gnu-g++-12 -std=c++17 -Wall -Wextra -Werror -pthread -I. \
  -I<googletest>/include -I<googletest> \
  score/socom/impl/service_identifier.cpp score/socom/impl/string_registry.cpp \
  score/socom/test/unit/service_identifier_tests.cpp <googletest>/src/gtest-all.cc \
  <googletest>/src/gtest_main.cc -o <binary>
```

Exit `0` for `before`; exit `0` for `after`, which additionally uses
`-fsanitize=undefined -fno-sanitize-recover=all`. `before-compile.stderr`,
`after-compile.stderr`, `before-compile.stdout`, `after-compile.stdout` are all empty.

### 3.3 Scope and staleness (reconciliation)

- **Scope:** one focused executable (identifier implementation + `string_registry.cpp` +
  the key test file + vendored googletest). It contains **no** `runtime_tests.cpp`, **no**
  framework link, **no** Bazel target, and **no** `//score/...` build.
- **Staleness:** the measurement's `source_hashes["score/socom/test/unit/service_identifier_tests.cpp"]`
  is `65c10517f0afd8fe2ced30c940158d1debec465895f9c154be1eeef1cd0eb675`
  (the **85-macro** state), matching the earlier `process_checks` capture
  (`node_0130bce9…`: `test_macros 85`, same hash). The current tree and every later
  obligation capture carry **87** macros at
  `4df2c63c4c2ea1a816898d8c33c506add3235509d85edfc51c535ab2aa1587a4`. **The host
  measurement therefore does not cover the two newest key tests (`:1982`, `:2012`).**

**Reading:** this is evidence *retention*, not a passing obligation. It supports (does not
establish) that the (earlier) key suite is green against the minor-excluding key under
focused GCC/UBSan.

---

## 4. Obligation-collection inventory (`.llm_tmp/overnight/obligations/`)

25 `result.json` files were read (glob). Statuses are the retained collector statuses;
**retention ≠ passing.**

| Check | Retained status | Reading (direct) |
|-------|-----------------|------------------|
| `compiler_diagnostics` | `findings_or_execution_failure` | GCC compile exit 0; GCC tests exit 0 (87/87); **Clang exit 1** (dependency deprecation error, §2.2) |
| `focused_asan_lsan` | `completed` | ASan+LSan+UBSan compile exit 0, tests exit 0 (focused single-threaded scope) |
| `focused_tsan` | `findings_or_execution_failure` | compile exit 0; tests exit **-11** (SIGSEGV) — environment failure, not a clean race result |
| `focused_memcheck` | `findings_or_execution_failure` | `valgrind` missing: `No such file or directory: '/tmp/score-someip84-obligation-tools/usr/bin/valgrind'`, exit 127 |
| `focused_cppcheck` | `findings_or_execution_failure` | exit 2; **19 × `passedByValue`** (CWE 398) all located in `registry_string_view.hpp` / `service_interface_identifier.hpp`, **outside** the six candidate paths |
| `focused_clang_tidy` | `findings_or_execution_failure` | `--verify-config` exit 1 with 15 unknown-check warnings; **no TU analysis ran** → "not run", never "clean" |
| `focused_coverage` | `completed` | focused: lines **36/36 = 100 %**, branches **11/14 = 78.6 %**; `complete_target_scope: false`; `safety_class: unknown_requires_authorized_selection`; limits "Focused identifier executable; full native runtime scope measured separately" |
| `codeql_security` | `findings_or_execution_failure` | `scan_runs: 1`; findings under `.llm_tmp/googletest/**`; every `level: null`; limit "Focused linked executable, not full target extraction; dependency findings retained" |
| `codeql_misra` | `findings_or_execution_failure` | large focused set (dependency + gtest macro + out-of-slice `string_registry.*`); `level: null`; mapping is `:status: draft` |
| `secret_dependency_checks` | `findings_or_execution_failure` | `gitleaks` missing (exit 127); a dependency inventory + `lock_sha256 c90b245b…` was retained, **not** a vulnerability scan |
| `tool_assurance` | `completed_with_blockers` | tool probes: `bazel` (`/tmp/s-core-001/bin/bazel`) **null/absent**, `valgrind`, `gitleaks`, `reuse`, `pre-commit`, `clang-format` absent; qualification requires authorized humans |
| `format_precommit` | `findings_or_execution_failure` | `bazel` missing, exit 127; formatting mutations confined to the disposable collector copy |
| `process_checks` | `completed_with_blockers` | metadata: `runtime_tests.cpp` **33** macros @ `9a2d6a15…`; `service_identifier_tests.cpp` **87** macros @ `4df2c63c…`; blockers: "Lexical metadata inventory cannot prove semantic requirement coverage"; "Safety/QM applicability and approved tailoring unknown"; "Independent inspection and acceptance required"; "External AoU and full integration verification require scoped review" |
| `rework_progress` | `completed` | `source_changed_this_round: true`; `rework_requested: false`; `stop_reason: "One complete pass requested; unresolved findings stay pending"` |
| `native_build`, `native_tests`, `native_integration`, `native_lint`, `native_docs`, `native_traceability`, `native_sanitizers`, `native_tsan`, `native_coverage`, `native_performance`, `cross_compilation` | `findings_or_execution_failure` | exit **127**, reason `No such file or directory: '/tmp/s-core-001/bin/bazel'`; `native_coverage` adds limit "Repository CI threshold 73 is not platform 85/100 line-and-branch acceptance" |

All statuses above were read directly from the retained `result.json` / stderr / stdout
files this iteration. The `native_*` entries are the **remaining full-runtime checks**
(§6).

---

## 5. Changed-hash reconciliation register

Three recorded hash families exist. They **disagree**; this register states each value and
the reconciliation, without claiming a local re-hash (no hashing tool was available).

| Path | Context snapshot `candidate-files.json` sha256 | Tool-measured sha256 (`measurement.json` / `obligations/*` / `process_checks`) | Reconciliation |
|------|-----------------------------------------------|------------------------------------------------------------------------------|----------------|
| `score/socom/impl/service_identifier.hpp` | `96b33a1fee4d54577ae9bc46c313409a0d59336f76df85ef1925ffebdd1a2119` | `bdce3fcbc3cd78a8ecaece1ea36107d464011ab81c9bc39932d0be617befaea9` | different revisions; the measured header is brace-balanced and compiles under GCC |
| `score/socom/impl/service_identifier.cpp` | `d766902e4bda5306095a6e5326ea91d28df3a6e1ef4e77dc9ba47556ed559a9a` | `3c12b3f1dd3f1fa66cdf43766f374d7d067637bf8f11aba604c4e2688351f11a` | same body seen on disk (minor-excluding `operator<`); hashes differ from snapshot |
| `score/socom/test/unit/service_identifier_tests.cpp` | `45d073998108df76c8f4534508d65f02cead28aa568cd5c45b5a3d8a4fd36a25` (snapshot: 83-case draft) | measurement `65c10517…` (**85** macros); later obligations/`process_checks` `4df2c63c…` (**87** macros) | three states; current tree has **87** `TEST_F`, consistent with `4df2c63c…` |
| `score/socom/test/unit/runtime_tests.cpp` | `5e35e24d0abcfa361b5a5283a005b307b86026a970464a3423be7c6eed66631e` | `9a2d6a154683a2b7ff9d51b7241e4fb74c1a8ef483895830cb409a8f5a1d3127` | current tree has **33** macros, consistent with `9a2d6a15…` |
| `score/socom/BUILD` | `dee826163ac5e6336d51a293136b424696c2884aa1b2592395e1e06423c0ba44` | `68f4645a21e495fac43929fb125f7ba0b9e29fc84c0401fdb95238ffb7fd2cc8` | measured build file exposes the test-only key header (`:46-54`) |
| `score/socom/test/unit/BUILD` | `9b3c5b341211e2c387858fd1fe5c669a6a422b6e8b5e80fce35ba22c61186799` | `e909151e822370bebe8d59b86369bddeb4d6cacfa02f10061bf6e134671ff9d4` | measured build file wires `impl_service_identifier` + framework |

**Reconciliation notes.**

- The context snapshot (`candidate-files.json`, plus its quoted restatements in several
  prior reports) and the tool-measured obligations describe **different revisions** of the
  candidate set. The snapshot hashes correspond to an earlier draft (key suite then
  83 cases, per prior reports); the measured hashes correspond to the post-rework tree
  (key suite 87 cases, runtime suite 33 macros).
- The `process_checks` node timeline shows the drift explicitly: an earlier capture
  (`node_0130bce9…`) recorded `service_identifier_tests.cpp` = `65c10517…` / 85 macros,
  while the latest capture (`node_01f223…`, and `rework_progress`) records `4df2c63c…` /
  87 macros. The two extra cases are `FreshDynamicServiceIdStringViewRegistersAndCollapses`
  (`:1982`) and `FreshDynamicServiceIdRvalueRegistersAndCollapses` (`:2012`).
- **Because no local hashing tool was available, the current working-tree hashes were not
  recomputed.** The correspondence above between the current files and the measured hashes
  is an inference from structural counts (87 / 33 macros; brace balance) and direct
  content reads, and is labelled as such.
- Baseline git blobs (`source-manifest.json`) are SHA-1 object ids and are **not**
  comparable to these SHA-256 values.

---

## 6. Remaining full-runtime checks (blocked, not run, not passed)

| Remaining check | Retained reason | Status |
|-----------------|-----------------|--------|
| `native_build` (`bazel build //score/...`) | exit 127, `/tmp/s-core-001/bin/bazel` absent | **NOT RUN** |
| `native_tests` | exit 127, bazel absent | **NOT RUN** — `runtime_tests.cpp` never compiled/executed |
| `native_integration` (QEMU) | exit 127, bazel absent (KVM/QEMU prerequisites present) | **NOT RUN** |
| `native_lint` (clang-tidy / ruff) | exit 127, bazel absent | **NOT RUN** |
| `native_coverage` | exit 127, bazel absent; CI threshold 73 ≠ platform 85/100 | **NOT RUN** |
| `native_sanitizers`, `native_tsan` | exit 127, bazel absent | **NOT RUN** |
| `native_docs`, `native_traceability`, `native_performance` | exit 127, bazel absent | **NOT RUN** |
| `cross_compilation` (x86_64 / aarch64 / QNX) | exit 127, bazel absent | **NOT RUN** |
| `format_precommit` (pre-commit / reuse / clang-format) | tools + bazel absent | **NOT RUN** |
| `secret_dependency_checks` (gitleaks) | gitleaks absent, exit 127 | **NOT RUN** |

`measurement.json` states `full_native_tests: not_executed`. **`runtime_tests.cpp`
(33 macros, including the minor-only duplicate regression at `:402-431`) has never been
compiled or executed by any retained artifact.** The focused identifier evidence that
does exist is the stale 85-case measurement plus the 87-case GCC/GCC-tests and
ASan/LSan/UBSan focused runs; none is a Bazel/native run.

---

## 7. Unresolved findings register (retained, not resolved)

| Id | Tool / category | Retained evidence | Scope | Authorized disposition |
|----|-----------------|-------------------|-------|------------------------|
| F-1 | Clang compiler diagnostic `-Wdeprecated-declarations` (under `-Werror`) | `compiler_diagnostics` clang exit 1; `stl_tempbuf.h:263` via `gtest.cc:3068` | dependency (libstdc++-12 / vendored googletest) | **NONE / pending** |
| F-2 | Clang-Tidy configuration | `--verify-config` exit 1; 15 unknown-check warnings | repo `.clang-tidy` | **NONE / pending**; no analysis ran |
| F-3 | Cppcheck `passedByValue` ×19 (CWE 398, tool severity `performance`) | exit 2, XML retained | `registry_string_view.hpp`, `service_interface_identifier.hpp` (outside candidate paths) | **NONE / pending** |
| F-4 | CodeQL security findings | `scan_runs: 1`; all `.llm_tmp/googletest/**`; `level: null` | dependency | **NONE / pending** |
| F-5 | CodeQL MISRA findings | large focused set; gtest macro expansion + out-of-slice `string_registry.*` + dependency; `level: null`; mapping `:status: draft` | test file / production outside slice / dependency | **NONE / pending** |
| F-6 | TSan | tests exit `-11` | focused executable | **NONE / pending**; environment failure |
| F-7 | Memcheck | valgrind unavailable (exit 127) | focused executable | **NONE / pending** |
| F-8 | Focused branch coverage | 11/14 = 78.6 % (`complete_target_scope: false`) | focused identifier TU | **NONE / pending**; below QM 85 and safety 100 |
| F-9 | Traceability | only `DerivationTechnique` + `Description` recorded; `TestType` and `Verifies` unset | both candidate test files | **NONE / pending**; no `comp_req__*`/interface ids exist and inventing them is prohibited |
| F-10 | Recorded brace defect | header balanced; GCC exit 0; Clang failure is F-1 | `impl/service_identifier.hpp` | **Not reproduced / stale** (review aid only) |
| F-11 | SCA severity classification | no Critical/High/Medium/Low rating on any finding; `engineering_acceptance: pending` | all findings | **NONE / pending** (requires QM + committer per `gd_req__verification_sca_classification`) |

No finding was suppressed, dropped, or reclassified. Dependency and out-of-slice findings
are retained as recorded by the collectors. `finding_classification.md`,
`independent_review_handoff.md`, and the prior reports catalogue these in more detail;
this register reconciles them against the retained obligation artifacts.

---

## 8. Obligation status (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Freedom from compiler warnings & errors (criterion 9, 100 %) | `verification_plan.rst` | **PARTIAL / NOT SATISFIED** — focused GCC compile exit 0 and 87/87 tests; Clang blocked (F-1); no native warnings-as-errors build |
| Static code analysis executed, findings classified | `code_analysis.rst`; `verification_process.rst:228-248` | **NOT DONE** — clang-tidy did not run; CodeQL focused/dependency-only; no authorized classification |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` (`:status: draft`) | **UNKNOWN — not claimed** |
| Structural line / branch coverage goals | `verification_plan.rst` (criteria 1-2) | **NOT MEASURED TO GOAL** — focused line 100 %, branch 78.6 %; full-scope pending |
| Unit/component testing executed, results recorded | `verification_plan.rst` (criteria 6-7) | **PARTIAL / STALE / BLOCKED** — focused 85-case measurement stale vs 87-macro tree; `runtime_tests.cpp` never executed; no Bazel run |
| Sanitizer / concurrency checks | `code_analysis.rst` | **PARTIAL / BLOCKED** — ASan/LSan/UBSan focused pass; TSan env failure; memcheck unavailable |
| Interface / requirements-based / resource / fault-injection test types | `verification_process.rst` | **NOT PERFORMED / applicability not inferred** |
| Linking tests to requirements (record properties) | `verification_process.rst` (`gd_req__verification_link_tests_cpp`) | **PARTIAL / NOT DONE** (F-9) |
| Independence of verification / review | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Implementation inspection IMPL_01…IMPL_03 | `inspection_checklist.rst` (`:status: draft`) | **NOT FILLED** |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** — missing tools + collector-vs-pin drift |
| Obligation collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **RETAINED, NOT PASSING** |
| Native acceptance | `source-index.json` | **`not_inferred` for every entry** |

**Explicit non-satisfaction statement.** Missing tools (`bazel`, `valgrind`, `gitleaks`,
`pre-commit`, `reuse`, `clang-format`), the non-running clang-tidy, the
focused/incomplete CodeQL extraction, the empty authorized finding classification, the
draft/inactive MISRA mapping, the stale and runtime-excluding measurement, the
environment-blocked TSan, and the unanswered human reviews mean **none of the checked
obligations may be treated as satisfied**. A retained collection node shows *retention*,
not passing; here several checks explicitly failed to run.

---

## 9. Measurement and validation status

- **Tools used this iteration:** `read_file`, `grep`, `glob`, `write_file` only. No
  `shell`, delegation, web, approval, publishing, or engineering acceptance.
- **Measurements executed this iteration:** **none.** No build, test, scan, or analysis was
  run here. Every number above is a reading of a retained artifact or of the working tree,
  or an explicitly-labelled inference.
- **Scope of retained runs:** focused identifier translation unit (plus vendored
  googletest); no `runtime_tests.cpp`; no Bazel/native target;
  `full_native_tests: not_executed`.
- **Reproduction path for a later, authorized iteration (NOT run here):**

  ```bash
  bazel build //score/...
  bazel test //score/...
  bazel test //score/socom/test/unit:socom_test
  bazel test //score/socom/test/unit:socom_test --test_filter='ServiceInstanceIdentifierTest.*'
  bazel test //score/socom/test/unit:socom_test \
      --test_filter='RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError'
  bazel test --config=qemu-integration //tests/integration_test/...
  bazel run //:traceability_gate -- --metrics-json _build/metrics.json --need-type=comp_req
  gitleaks dir . --redact=100 --report-format=json      # requires gitleaks
  # full-target CodeQL extraction (not the focused linked executable)
  codeql database create <db> --language=cpp --command='<full build>'
  ```

  Expected (source-derived, **not observed**): the minor-only key tests collapse to one
  set element and the runtime regression returns `Construction_error::duplicate_service`;
  on a key that includes `minor`, both focused checks would fail.

---

## 10. Notice preservation

- **Only this report was written.** No source, build, test, config, `NOTICE`, `LICENSE`,
  `REUSE.toml`, `validation/`, or `obligations/` file was created, edited, or deleted.
  All retained host artifacts and all prior reports under
  `.llm_tmp/overnight/reports/` and `.llm_tmp/overnight/prior-reports/` are preserved.
- The flagged header `score/socom/impl/service_identifier.hpp` retains its Apache-2.0 /
  SPDX header (`:1-12`) and was left unchanged because it is already brace-balanced (§2).
  The sibling `service_identifier.cpp`, both `BUILD` files, and both candidate test files
  likewise retain their Apache-2.0 / SPDX headers.
- This report carries the Apache-2.0 header. No licensed MISRA rule text is reproduced;
  only native rule ids, source hashes, and file locations are cited.

---

## 11. Pending human review checklist

- [ ] **Confirm §2:** the header is brace-balanced (brace lines `:19,:29,:32,:38`; line 39
      blank); the recorded "extra closing brace at line 39" is stale or refers to a
      different revision. If a distinct "cancelled draft" still carries the brace, locate
      it and correct it by an authorized iteration — it is not the file in this checkout.
- [ ] **Resolve the instruction conflict:** correct-the-source vs. report-only; confirm
      that inspection-only (source already correct) was intended.
- [ ] **Reconcile the hash families (§5):** confirm the tool-measured post-rework hashes
      are the intended review binding, and that the context-snapshot hashes describe the
      superseded draft.
- [ ] **Disposition F-1 (Clang dependency error)** and decide whether the pinned native
      toolchain avoids it; do not suppress it in-repo without an accepted deviation.
- [ ] **Repair and run Clang-Tidy (F-2)**; do not treat its non-run as clean.
- [ ] **Disposition F-3, F-4, F-5** (out-of-slice / macro / dependency findings) as
      acceptable, deviated, or refactored changes; do not patch the test framework or
      silently suppress rules.
- [ ] **Restore the missing tools and run the native checks (§6)**, including
      `runtime_tests.cpp` and the two newest key tests, and a warnings-as-errors build.
- [ ] **Complete the mandated SCA classification (F-11)** with the Quality Manager and a
      committer; the retained tools carried no Critical/High/Medium/Low rating.
- [ ] **Supply requirement/interface identifiers** for traceability links, or record
      applicability as unresolved (no invented links).
- [ ] **Select the safety class**, schedule independent human review (approver ≠ author),
      and record engineering acceptance before any compliance claim.
- [ ] **Keep the wider #84 public `Service_interface_identifier` restructure, FindService
      wildcard handling, and config minor-wildcard narrowing out of this bounded slice**
      until separately accepted.

---

*End of evidence inventory. Local, unprotected, scoped. No engineering acceptance; human
reviews unanswered; full native runtime tests pending. Agent statements are assertions and
do not substitute for the human gates above.*
