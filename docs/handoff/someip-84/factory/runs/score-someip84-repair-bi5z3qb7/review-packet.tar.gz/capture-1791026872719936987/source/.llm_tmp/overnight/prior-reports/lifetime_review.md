<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — lifetime / invalidation / slot-reuse review of the bounded registration-key slice

**Document type:** review draft (actual-source inspection + drafted-runtime-case review +
concrete counterexamples + obligations status)
**Date:** 2026-10-02
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version handling in
socom* — this document reviews **invalidation, connector lifetime and slot reuse**.
**Run:** `fabro/run/01M3YRJEGXNY6CB81T7TKW774B` (branch of the same name).
**Status:** local, unprotected, scoped. **No engineering acceptance exists. Human reviews are
unanswered. Full native runtime tests remain pending.** Everything below is either a direct static
reading of this checkout, or an explicitly-labelled logical consequence. Nothing is published,
reviewed, or accepted.

> **Tool / write boundary actually observed.** Only `read_file`, `grep`, `glob`, and `write_file`
> were available and were the only tools used. No `shell`, no delegation, no web access, no
> approval, no publishing, and no engineering acceptance was performed. The task says *"This is a
> review draft: only that report may be written."* **This iteration wrote exactly one file — this
> report.** No source, build, test, config, `NOTICE`, `LICENSE`, `REUSE.toml`, or prior-report file
> was created, edited, or deleted. Every prior report under `.llm_tmp/overnight/prior-reports/` and
> every pre-existing `.llm_tmp/overnight/reports/*` file was preserved unchanged.
>
> **Premise reconciliation — the recorded syntax failure is not in this checkout.** The task states
> *"a measured GCC syntax failure: an extra closing brace in
> `score/socom/impl/service_identifier.hpp` at line 39."* Direct inspection of the actual source
> (§2) shows exactly two opening braces (`:19`, `:29`) and two closing braces (`:32`, `:38`), net
> balance `0`; `:39` is **blank** and `:40` is `#endif`. There is no unmatched brace and — see §2 —
> no second copy of the header or leftover `.orig`/`.rej`/`.bak` file that could still carry it.
> Because (a) the write boundary forbids source edits this iteration and (b) there is no defect in
> the actual file to correct, **no production source was edited.** The minimal repair is recorded in
> §2.3 for reference only. The described defect survives only as a *pre-correction* description in
> the earliest prior reports; the `reproducer` iteration is the one that applied the single-close
> correction, and the balanced state is what this checkout contains.

---

## 0. Summary

This review inspects the *actual* lifetime machinery behind the duplicate-server registration key and
the drafted runtime cases that claim to pin it. The key correction itself is present and consistent
(§3). The drafted runtime cases are **logically sound on the corrected key but shallow**: every case
that could observe the dangerous lifetimes either never enables the connector or never re-enables the
replacement, and **no retained measurement compiles `runtime_tests.cpp` at all** (§1.4, §6). The
concrete counterexamples are:

1. **CE-1 (concrete defect): a connector that outlives its `Runtime` is only safe while it is
   *disabled*.** `ConnectorDestroyedAfterRuntimeDoesNotCrash` (`runtime_tests.cpp:1021-1028`) only
   ever creates a disabled connector. If the connector had been *enabled* before the runtime was
   destroyed, its destructor would run `~Impl() -> disable() -> m_registration.reset()`, and that
   registration's `Final_action` captures the `Service_record` that lived inside the now-destroyed
   `Runtime_impl` (`runtime_impl.cpp:372-377`, `:529-551`). It then locks
   `Service_record::m_runtime_mutex` and calls `m_server.reset()` on freed memory — a
   use-after-free. The key's `weak_ptr` guard (`runtime_impl.cpp:456-463`) protects only the *key
   erase*, not the server registration. The claim "does not crash" is therefore only established for
   the never-enabled state.
2. **CE-2 (test-coverage counterexample): the "enabled slot reuse" case never re-enables.** 
   `ConstructDuplicateAfterEnabledConnectorDestroyedWithChangedMinorVersionReturnsValidServerConnector`
   (`runtime_tests.cpp:1091-1134`), like `ConstructDuplicateAfterEnabledConnectorDestroyedReturnsValidServerConnector`
   (`:986-1019`), destroys the enabled connector and then only *constructs* a disabled replacement,
   asserting `has_value()`/non-null. It never calls `Disabled_server_connector::enable()` on the
   replacement, so it cannot observe whether `Service_record::m_server` was actually reset. If that
   reset `Final_action` were dropped, both tests would still pass, yet the next `enable()` would hit
   `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)` (`runtime_impl.cpp:369`) and terminate.
3. **CE-3 (shallow coverage): the destruction-isolation cases never enable, so they export only
   `std::set` behaviour, not record-state behaviour.** `DestroyingOneMajorSlotKeepsOtherMajorSlotOccupied`
   (`:1141`), `DestroyingOneInstanceSlotKeepsOtherInstanceSlotOccupied` (`:1197`) and
   `DestroyingOneServiceIdSlotKeepsOtherServiceIdSlotOccupied` (`:1253`) keep every connector
   disabled; they say nothing about `Service_record::m_server`/`m_client`.
4. **CE-4 (latent hazard): key erase is declared *after* the server registration in `Impl`.** 
   `m_registration` (`server_connector_impl.hpp:162`), then `m_final_action` (`:163`), then
   `m_credentials` (`:164`) are destroyed in reverse order, so `m_final_action` (key erase) runs
   **before** `m_registration`. Today `~Impl(){ disable(); }` (`server_connector_impl.cpp:53`) already
   resets `m_registration` in the destructor *body*, so the observed order is server-unregister then
   key-erase — correct. But this ordering is fragile: any future path that destroys `Impl` without
   `disable()` resetting `m_registration` would release the key while `Service_record::m_server` is
   still set, letting a new connector for the same slot through the gate and then violate
   `ASSERT(!m_server)` on enable.
5. **CE-5 (resource lifetime, uncovered): `Service_database` records are never erased.** 
   `Service_database::get_record` (`runtime_impl.cpp:313-324`) emplaces records into
   `m_service_records` and nothing ever erases them (no `erase` touches them; cf. the only erases in
   the file at `:60`, `:76`, `:110`, `:461`, `:555`). Destroying a connector resets `m_server` but
   leaves the record alive for the runtime's lifetime, so a program that enables and destroys many
   distinct identities grows `m_service_records` monotonically. No drafted lifetime test asserts
   record cleanup.
6. **CE-6 (measurement staleness + scope): no retained artifact covers the runtime suite, and the
   newest key tests post-date the artifact.** Every retained host/sanitizer/coverage measurement
   compiles only `service_identifier.cpp + string_registry.cpp + service_identifier_tests.cpp`
   (§1.4). `runtime_tests.cpp` (33 test macros) is never compiled. Additionally,
   `validation/after.json` reports **85** executed identifier tests, while the working tree contains
   **87** `TEST_F` (`grep`; the two newest at `:1982`, `:2012`), so the retained measurement is stale
   relative to the working tree.

Supporting invariant note: the gate's `std::set` ordering is **content-based** while
`Service_database`'s `unordered_map` equality/hash is **pointer-based** (`registry_string_view.hpp`
`:141-143` vs `:127-129`, `:186-193`). This is currently consistent only because `String_registry`
interns by content (`string_registry.cpp:26-28`, `:37-45`); if interning were ever broken the two
structures could disagree. The safe direction already holds (same record ⇒ same gate key), so it is
recorded as an invariant to preserve, not an observed defect.

---

## 1. Binding, candidate set, prior reports, host feedback, obligations

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` | `.llm_tmp/context/issue-snapshot.json:2-4` |
| Title | *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:3` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` | `.llm_tmp/context/issue-snapshot.json:19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**. No comment/acceptance record exists in the snapshot, so none of it is binding.

### 1.2 Verified baseline and candidate set

| Item | Value | Source |
|------|-------|--------|
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |

Candidate paths from `.llm_tmp/context/candidate-files.json`: `score/socom/BUILD`,
`score/socom/impl/service_identifier.cpp`, `score/socom/impl/service_identifier.hpp`,
`score/socom/test/unit/BUILD`, `score/socom/test/unit/runtime_tests.cpp`,
`score/socom/test/unit/service_identifier_tests.cpp` (the last has baseline blob `null`, i.e. the
manifest expects a **new** file). **Binding caveat:** the candidate manifest sha256 values no longer
match the host-measured working tree — e.g. candidate `service_identifier.hpp` `96b33a1f…`, host
`bdce3fcb…`; candidate `runtime_tests.cpp` `5e35e24d…`, host `9a2d6a15…`; candidate
`service_identifier_tests.cpp` `45d07399…`, host `4df2c63c…`. The working tree has moved past the
candidate snapshot; I cannot recompute hashes here, so I record the mismatch rather than resolve it.

### 1.3 Prior reports read (and preserved)

`.llm_tmp/overnight/prior-reports/` (12 files present): `scope.md`, `invariants.md`, `callsites.md`,
`reproducer.md`, `key_fix.md`, `unit_matrix.md`, `ordering_tests.md`, `conversion_tests.md`,
`runtime_disabled.md`, `runtime_enabled.md`, `lifetime_tests.md`, `test_metadata.md`.
`.llm_tmp/overnight/reports/` (this run): `scope.md`, `invariants.md`, `callsites.md`,
`reproducer.md`, `key_fix.md`, `lifetime_tests.md`, `compatibility.md`, `conversion_tests.md`,
`coverage_tests_repair.md`, `ordering_tests.md`, `runtime_disabled.md`, `runtime_enabled.md`,
`test_metadata.md`, `tool_findings_repair.md`, `unit_matrix.md`. This document adds
`lifetime_review.md`; nothing was overwritten.

Derived sequence: `scope` → `invariants` (I-4 baseline key included `minor`; I-9 record index ignores
`minor`; I-11 the resulting gap) → `callsites` → `reproducer` (header brace correction) → `key_fix`
(drop `minor`) → `ordering_tests` → `runtime_disabled`/`runtime_enabled`/`lifetime_tests` →
conversion/metadata/repair reports.

### 1.4 Host validation feedback and retained measurements (read this iteration)

`glob .llm_tmp/overnight/validation/**` now returns 16 files. The retained feedback is
`check_unit_matrix`: `check-result` = `0`; `after.json` = **85 tests / 0 failures**, single suite
`ServiceInstanceIdentifierTest`; `before.json` = 85 / 28; `measurement.json`
`origin: local_unprotected_measurement`, `initiator: Fabro host hook`,
`engineering_acceptance: pending`, `full_native_tests: not_executed`, compiler
`/usr/bin/x86_64-linux-gnu-g++-12`.

Obligation-collector results are now **present** under `.llm_tmp/overnight/obligations/`. All of
`compiler_diagnostics`, `focused_asan_lsan`, `focused_coverage`, `focused_memcheck`, `focused_tsan`,
`focused_clang_tidy`, `focused_cppcheck`, `codeql_*`, `format_precommit`, `secret_dependency_checks`,
`tool_assurance`, `native_*`, `cross_compilation` etc. **Per the task rule, a successful collection
node means results were retained, not that the checks passed.**

**Decisive scope caveat.** Every code-measuring command I read compiles the *focused identifier
translation unit only*:
`g++-12 -std=c++17 -Wall -Wextra -Werror -pthread score/socom/impl/service_identifier.cpp score/socom/impl/string_registry.cpp score/socom/test/unit/service_identifier_tests.cpp <gtest>`.
This is true of `compiler_diagnostics` (`gcc-compile`/`gcc-tests` exit 0; the `clang-compile` leg
exits 1 on a googletest/libstdc++ dependency issue outside the candidate paths),
`focused_asan_lsan` (adds `-fsanitize=address,leak,undefined`, exit 0),
`focused_coverage` (adds `--coverage`, exit 0), and by construction `focused_memcheck`/`focused_tsan`
(same focused executable). **`runtime_tests.cpp` is not compiled or executed by any retained
artifact**, so all drafted runtime lifetime cases remain natively unmeasured. `focused_coverage`
reports only `score/socom/impl/` (filter): `service_identifier.cpp` + `string_registry.cpp`, 36/36
lines, 11/14 branches (100 % line / 78.6 % branch), and explicitly marks
`complete_target_scope: false` and `safety_class: unknown_requires_authorized_selection`.

**Staleness.** `validation/after.json` contains no `FreshDynamic*` entries and stops at
`ConvertedEmptyTextInstancePathsAgreeWithRegistryPath` (`:1929`), 85 tests. The working tree has two
more `TEST_F` (`:1982` `FreshDynamicServiceIdStringViewRegistersAndCollapses`, `:2012`
`FreshDynamicServiceIdRvalueRegistersAndCollapses`), i.e. **87** identifier `TEST_F` by `grep`, and
`process_checks/result.json` inventory independently reports `test_macros: 87`. The retained 85-test
measurement therefore does not cover the two newest identifier tests (nor any runtime test).

### 1.5 Pinned obligation sources

All nine entries of `.llm_tmp/context/obligations/source-index.json` are present with
`authority.json`. Every entry is `"native_acceptance": "not_inferred"`. `authority.json` records
`engineering_acceptance: pending`, `human_reviews: unanswered`, `safety_class: unknown`,
`codeql_scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload"`. `misra_mapping.rst`
and `inspection_checklist.rst` are `:status: draft`.

---

## 2. The recorded syntax failure: inspection of the actual source

### 2.1 Finding (direct `read_file` + `grep`)

`score/socom/impl/service_identifier.hpp` is **brace-balanced**, 40 lines:

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers, two closers, net `0`. `glob **/service_identifier*` returns exactly three files
(`service_identifier.hpp`, `service_identifier.cpp`, `service_identifier_tests.cpp`); `glob` for
`**/*.{orig,rej,bak,patch,diff}` returns only unrelated `third_party/*.patch` files. There is no
second, differently-braced copy and no leftover patch/reject in this checkout. The task's "extra
closing brace at line 39" is therefore a stale, pre-correction description here.

### 2.2 Convention

The tree uses the nested form (`namespace score::socom {` … `}  // namespace score::socom`) in
`impl/service_identifier.cpp`, `service_interface_identifier.hpp`, `registry_string_view.hpp`,
`error.hpp`; the split form (`namespace score` + `namespace socom` … double close) is
`impl/runtime_impl.hpp`. The flagged header follows the nested form.

### 2.3 Minimal repair (reference only, not applied)

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

Applying this to the already-balanced file is a no-op at best; re-introducing a broken state to
"fix" it is a regression. **No source was edited.** This is a static brace reading, not a compile
measurement; the retained focused compiles (which include the header transitively) exited `0`
(§1.4), and a genuine extra `}` would make them fail — but those artifacts are scoped and
unprotected.

---

## 3. Source lifetime model (the object of this review)

All line references are readings of this working tree.

- **Key type.** `Service_instance_identifier{ Service_interface_identifier interface;
  Service_instance instance; }` with only an out-of-line `operator<` declaration
  (`impl/service_identifier.hpp:29-35`); no `operator==`, no hash.
- **Key identity.** `operator<` orders by `(instance, service id, major)` and excludes `minor`
  (`impl/service_identifier.cpp:20-30`, identity at `:28-29`). `std::set` equivalence is therefore
  `(instance, id, major)`, deliberately as coarse as the `Service_database` index.
- **Where the key lives.** `using Service_identifiers =
  Mutexed_variable<std::set<Service_instance_identifier>>` (`impl/runtime_impl.hpp:56`); held as
  `std::shared_ptr<Service_identifiers> m_service_identifiers` (`:228-229`).
- **Key insertion.** `Runtime_impl::make_server_connector` builds
  `Service_instance_identifier const identifier{configuration.get_interface(), instance}`
  (`runtime_impl.cpp:443`), checks callbacks (`:445-447`), then under the key mutex inserts and
  returns `duplicate_service` when `insert(...).second` is false (`:449-454`; insert `:451`, error
  `:452`). **Validity is checked before insertion**, so a `callback_missing` return does not leak a
  key.
- **Key erase (invalidation).** Only the `Final_action` installed at `runtime_impl.cpp:456-463`
  erases the key. It captures `identifier` by value and a `weak_ptr` to the set; if the runtime is
  gone, `identifiers.lock()` is empty and the erase is skipped. `Final_action`'s move resets the
  moved-from functor and its destructor executes it exactly once (`final_action.hpp:41-67`), so
  moving it into `SC_impl` does not fire the erase early and does not double-fire.
- **Connector lifetime.** `SC_impl` owns the `Final_action` (`server_connector_impl.hpp:163`) and
  stores it while the connector exists. `Disabled_server_connector::enable` /`Enabled_server_connector::disable`
  transfer the *same* `Impl` object between the two `unique_ptr` types without running a deleter
  (`server_connector_impl.cpp:365-389`), so the key persists across the enabled/disabled transition
  and is released only on destruction. `Impl::~Impl` calls `disable()` (`:53`).
- **Server registration lifecycle (separate from the key).** On first `enable()`,
  `Runtime_impl::register_connector(interface, instance, endpoint)` (`runtime_impl.cpp:526-551`)
  obtains the record via `Service_database::get_record` (`:313-324`) and calls
  `Service_record::register_server_connector` (`:366-382`), which asserts
  `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)` (`:369`), sets `m_server` (`:371`), and returns a
  `Registration` whose `Final_action` captures `this` (the `Service_record`) and resets `m_server`
  under `m_runtime_mutex` (`:372-377`). `Impl::disable()` resets `m_registration`
  (`server_connector_impl.cpp:80-114`), so the server is unregistered *before* the key-erasing
  `m_final_action` runs (see CE-4 for the ordering caveat).
- **Records are permanent.** `Service_database::get_record` only ever `emplace`s
  (`runtime_impl.cpp:313-324`); nothing erases `m_service_records` or its inner `Service_instances`.
  Record identity is `(id, major, instance)` via `Minor_version_ignoring_key_equal`/`_hash`
  (`impl/runtime_impl.hpp:116-134`), matching the key's `(instance, id, major)` component set.

---

## 4. Concrete counterexamples

### CE-1 — Enabled connector outliving its `Runtime` is a use-after-free; the drafted test only covers the disabled state

`ConnectorDestroyedAfterRuntimeDoesNotCrash` (`runtime_tests.cpp:1021-1028`) creates a connector
from a local `Connector_factory` copy (which owns a fresh runtime; `connector_factory.cpp:39-42`),
lets the factory/runtime go out of scope, and then lets the *never-enabled* connector be destroyed.
For a disabled connector `m_registration` is null, so `disable()` is a no-op and the only runtime
touch is the `weak_ptr` guard, which correctly no-ops. The test passes.

Concrete counterexample (same shape, one extra call): enable the connector before the runtime dies.

```cpp
Runtime::Uptr runtime = create_runtime();
auto first = runtime->make_server_connector(configuration, instance,
                                            create_server_callbacks(callbacks));
ASSERT_TRUE(first.has_value());
Enabled_server_connector::Uptr enabled =
    Disabled_server_connector::enable(std::move(first).value());
runtime.reset();          // Runtime_impl and its Service_database are destroyed here
enabled.reset();          // <-- ~Impl -> disable() -> m_registration.reset()
```

When `enabled` is destroyed, `Impl::disable()` (`server_connector_impl.cpp:80-114`) resets
`m_registration`. That `Registration`'s `Final_action` captures the `Service_record` that lived in
the destroyed `Runtime_impl` (`runtime_impl.cpp:372-377`) and executes
`std::lock_guard<std::mutex> const lock{m_runtime_mutex}; m_server.reset();` on freed storage. This
is a use-after-free (and a dangling `m_runtime_mutex` reference). The key's `weak_ptr` design
(`runtime_impl.cpp:456-463`) protects only the *key erase*; the server registration has no such
guard, so the runtime-outlives-connector support is **inconsistent**. No drafted case exercises the
enabled state here.

### CE-2 — The "enabled slot reuse" case never re-enables, so the `Service_record::m_server` reset is untested

`ConstructDuplicateAfterEnabledConnectorDestroyedWithChangedMinorVersionReturnsValidServerConnector`
(`runtime_tests.cpp:1091-1134`) does: enable first (minor 2); duplicate minor 3 is refused; destroy
first; construct replacement (minor 3) and assert `has_value()` / non-null. It **stops before
enabling the replacement**. `ConstructDuplicateAfterEnabledConnectorDestroyedReturnsValidServerConnector`
(`:986-1019`) has the same gap. Consequently the test cannot detect a missing/broken server-reset
`Final_action` in `Service_record::register_server_connector` (`runtime_impl.cpp:372-377`): if that
reset were dropped, the replacement would still be constructed successfully (the gate sees the freed
key) but the subsequent `enable()` would hit `ASSERT(!m_server)` at `runtime_impl.cpp:369` and
terminate. The drafted "slot reuse" claim is therefore verified only at the key-set level, not
end-to-end.

### CE-3 — Destruction-isolation cases never enable, so they export only `std::set` behaviour

`DestroyingOneMajorSlotKeepsOtherMajorSlotOccupied` (`:1141-1191`),
`DestroyingOneInstanceSlotKeepsOtherInstanceSlotOccupied` (`:1197-1245`), and
`DestroyingOneServiceIdSlotKeepsOtherServiceIdSlotOccupied` (`:1253-1304`) keep every connector
disabled and only probe `make_server_connector` return values. They confirm the `std::set::erase`
(`runtime_impl.cpp:461`) is per-key, which is useful, but they never create `Service_record`s, never
call `register_server_connector`, and never exercise the `m_server`/`m_client` state machine. A defect
in the record-level destruction isolation would not be caught by them.

### CE-4 — Key-erase runs before `m_registration` destruction (latent ordering hazard)

`Impl` declares `Registration m_registration;` at `server_connector_impl.hpp:162` and
`Final_action m_final_action;` at `:163`; members are destroyed in reverse order, so
`m_final_action` (key erase) is destroyed **before** `m_registration`. In the current code
`~Impl(){ disable(); }` (`:53`) resets `m_registration` in the destructor body first, so the
server is removed from `Service_record` before the key is freed — the required order. But the
correctness depends on `disable()` always resetting `m_registration` before member destruction. Any
future refactor that leaves `m_registration` non-null at member-destruction time would free the key
while `Service_record::m_server` is still set; a new connector for the same `(instance, id, major)`
would then pass the gate and violate `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)`
(`runtime_impl.cpp:369`) on enable. Recommended hardening: declare `m_final_action` **before**
`m_registration`, or erase the key only after `disable()` has completed (it already is, by virtue of
the destructor body, but the declaration order does not express it).

### CE-5 — `Service_database` records are never erased (resource lifetime)

`Service_database::get_record` (`runtime_impl.cpp:313-324`) `emplace`s an entry for every interface
key (id+major) and instance it is asked about (server enable, or client construction via
`register_connector`, `:496`), and no code path erases them (`runtime_impl.cpp` has no `erase` on
`m_service_records`; the only erases are the key at `:461` and bridge maps at `:60`, `:76`, `:110`,
`:555`). Destroying a connector resets `m_server` but the record persists for the runtime's life.
Concrete consequence: create/enable/destroy `N` distinct `(id, major, instance)` server connectors;
`m_service_records` holds `N` records (and their inner maps) after all connectors are gone. No
drafted lifetime test asserts any record cleanup, and no retained measurement exercises the runtime
database at all.

### CE-6 — Measurement coverage: runtime suite unmeasured, newest key tests stale

See §1.4. Every retained code measurement compiles only the identifier TU; `runtime_tests.cpp`
(33 test macros per `process_checks/result.json`) is not compiled. And `after.json` reports 85
identifier tests while the working tree has 87 `TEST_F` (`:1982`, `:2012`), so even the identifier
measurement does not cover the newest cases. A green `check-result` is therefore **not** evidence
for any lifetime case in this review.

### Supporting note — content-vs-pointer key consistency

`Registry_string_view::operator<` compares content (`registry_string_view.hpp:141-143`) while
`operator==` compares pointer+length (`:127-129`) and `std::hash` hashes the pointer (`:186-193`).
The gate (`std::set`) is content-ordered; the `Service_database` `unordered_map` is pointer-equal.
Within one registry these coincide only because `String_registry` interns by content
(`string_registry.cpp:26-28`, `:37-45`); `service_id_registry()`/`instance_id_registry()` are the two
single per-process registries (`:65-73`), and interface ids and instance ids are never compared to
each other. So the invariant "same `Service_record` ⇒ same gate key" holds, and the gate is at least
as coarse as the index. This is recorded as an invariant to preserve, not an observed defect.

---

## 5. Verdict on the drafted runtime cases

| Case (runtime_tests.cpp) | Claim | Verdict |
|--------------------------|-------|---------|
| `ConstructDuplicateReturnsDuplicateServiceError` `:334` | same config duplicate refused (disabled) | sound on corrected key; key-set only |
| `ConstructDuplicateMultipleTimesReturnsDuplicateServiceError` `:350` | repeated duplicates refused | sound; key-set only |
| `CreatingServerConnectorDeletingItAndRecreatingReturnsValidServerConnector` `:371` | same-config reuse (disabled) | sound; key-set only, never enables |
| `ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError` `:402` | minor-only duplicate refused (disabled) | sound, focused; key-set only |
| `ConstructDuplicateSameConfigurationWhileBothConnectorsDisabled…` `:440` | duplicate refused, both disabled | sound; key-set only |
| `ConstructDifferentMajor…Disabled…` `:471` | different major coexists | sound; key-set only |
| `ConstructDifferentInstance…Disabled…` `:505` | different instance coexists | sound; key-set only |
| `ConstructDifferentServiceId…Disabled…` `:538` | different service id coexists | sound; key-set only |
| `ConstructDuplicateMinorBoundaries…Disabled…` `:573` | minor 0/65535 collapse | sound; key-set only |
| `ConstructDuplicateWithSmallerMinor…Disabled…` `:607` | smaller minor still duplicate | sound; key-set only |
| `ConstructDuplicateRepeatedly…Disabled…KeepsSlotHeld` `:642` | slot stays held while disabled | sound; key-set only |
| `ConstructDuplicateWhileFirstConnectorEnabled…` `:694` | enabled connector holds the key | sound; enables but replacement not built |
| `ConstructDuplicateDifferingOnlyInMinorVersionWhileFirstConnectorEnabled…` `:726` | minor-only duplicate refused while enabled | sound, focused |
| `ConstructDifferentInstanceWhileFirstConnectorEnabled…` `:763` | enabled instance-A does not block instance-B | sound; different records by construction |
| `ConstructDifferentServiceIdWhileFirstConnectorEnabled…` `:796` | enabled service-id-A does not block B | sound; different records |
| `ConstructDuplicateMinorBoundariesWhileFirstConnectorEnabled…` `:832` | minor boundaries collide while enabled | sound |
| `ConstructDuplicateWithSmallerMinorWhileFirstConnectorEnabled…` `:869` | smaller minor still duplicate while enabled | sound |
| `ConstructDuplicateRepeatedlyWhileFirstConnectorEnabledKeepsSlotHeld` `:905` | slot held while enabled | sound |
| `ConstructDifferentMajorWhileFirstConnectorEnabled…` `:951` | enabled major-1 does not block major-2 | sound; different records |
| `ConstructDuplicateAfterEnabledConnectorDestroyedReturnsValidServerConnector` `:986` | enabled destroy frees the key | **limited — CE-2** |
| `ConnectorDestroyedAfterRuntimeDoesNotCrash` `:1021` | `weak_ptr` no-op after runtime destruction | **limited — CE-1** (disabled only) |
| `ConstructDuplicateAfterDisabledConnectorDestroyedWithChangedMinorVersion…` `:1045` | disabled destroy frees the key, changed minor reusable | sound; key-set only (never enables) |
| `ConstructDuplicateAfterEnabledConnectorDestroyedWithChangedMinorVersion…` `:1091` | enabled destroy frees the key, changed minor reusable | **limited — CE-2** (never re-enables) |
| `DestroyingOneMajorSlotKeepsOtherMajorSlotOccupied` `:1141` | per-key erase isolation (major) | **limited — CE-3** (never enables) |
| `DestroyingOneInstanceSlotKeepsOtherInstanceSlotOccupied` `:1197` | per-key erase isolation (instance) | **limited — CE-3** |
| `DestroyingOneServiceIdSlotKeepsOtherServiceIdSlotOccupied` `:1253` | per-key erase isolation (service id) | **limited — CE-3** |

Overall: the duplicate-refusal expectations are correct strict-weak-ordering consequences of
`service_identifier.cpp:28-29`, and the per-key erase expectations are correct consequences of
`runtime_impl.cpp:456-463` + `std::set::erase`. The limitations are that no case observes the
`Service_record` server state after reuse (CE-2/CE-3), and the runtime-outlives-connector case does
not cover the enabled state (CE-1). **None of these cases has been compiled or executed** in this
checkout (CE-6).

---

## 6. Obligations status (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Freedom from compiler warnings & errors (100 %) | `verification_plan.rst` (criterion 9) | **NOT MEASURED for runtime** — the focused identifier TU compiled (`gcc-compile` exit 0, empty stderr, scoped); the `clang` leg exits 1 on a googletest/libstdc++ dependency outside the candidate paths; `runtime_tests.cpp` and the full `socom_test`/`//score/...` targets are not compiled |
| Static code analysis (clang-tidy / CodeQL), findings classified | `code_analysis.rst`; `verification_process.rst` (SCA classification) | **NOT SATISFIED** — retained `focused_clang_tidy` failed on `--verify-config` (exit 1); CodeQL MISRA applicability is draft/unestablished; findings not classified by an authorized owner |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` (`:status: draft`) | **UNKNOWN** — mapping is draft; not applied |
| Structural statement / branch coverage goals | `verification_plan.rst` (criteria 1-2) | **NOT MEASURED for the slice** — focused coverage is `score/socom/impl/` only, 100 % line / 78.6 % branch, `complete_target_scope: false`, below the 85/100 platform goals |
| Unit/component testing executed, results recorded | `verification_plan.rst` (criteria 6-7) | **PARTIAL, STALE** — 85 identifier tests 0 failures (candidate) / 28 (baseline); `runtime_tests.cpp` (33 macros) not executed; the two newest identifier tests (`:1982`, `:2012`) post-date the artifact |
| Interface / requirements / resource / fault-injection test types | `verification_process.rst`; `verification_plan.rst` | **NOT PERFORMED / applicability not inferred** — no harness; identifier/runtime-key tests are not platform validation |
| Boundary / equivalence derivation | `verification_process.rst` | **SOURCE-ONLY for the lifetime cases**; the identifier key-level cases were executed by the host check |
| Fuzzy / fuzz testing technique | `verification_plan.rst` | **NOT EXECUTED / NOT CLAIMED** |
| Linking tests to requirements (record properties) | `verification_process.rst` (`gd_req__verification_link_tests_cpp`) | **PARTIAL** — `DerivationTechnique`/`Description` recorded; `TestType`/`Verifies` unset (no invented identifiers) |
| Independence of verification | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Implementation inspection checklist | `inspection_checklist.rst` (`:status: draft`) | **NOT FILLED** |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED**; several tool binaries are `null`/absent in the collector identity |
| Obligation collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **RETAINED, NOT PASSED** — present now, several with `status: findings_or_execution_failure` (native_*, cross_compilation, native_coverage, native_integration, native_tests, native_tsan, native_sanitizers, native_performance, focused_cppcheck, focused_clang_tidy, compiler_diagnostics clang leg, format_precommit) |
| Native acceptance | `source-index.json` | **`not_inferred` for every entry** |

**Explicit non-satisfaction statement.** Missing tools, unknown applicability, incomplete extraction
(no runtime measurement), stale artifacts, draft mappings/checklists, and unanswered human reviews
mean **none of the checked obligations may be treated as satisfied**. A retained collection node
proves *retention*, not passing.

---

## 7. Measurement and validation status

- **Tools:** `read_file`, `grep`, `glob`, `write_file` only. No `shell`, delegation, web, approval,
  publishing, or engineering acceptance.
- **Measurements executed by this iteration:** **none.** No build, no `bazel test`, no runtime. The
  brace census (§2), the lifetime model (§3) and the counterexamples (§4) are static readings or
  explicitly-labelled logical consequences.
- **Test inventory (read, not run):** `service_identifier_tests.cpp` has **87 `TEST_F`** under
  `ServiceInstanceIdentifierTest` (`:168`…`:2012`, `grep` this iteration);
  `runtime_tests.cpp` has **33 test macros** (31 `TEST_F` + 1 `TEST` + 1 `TEST_P`) per
  `process_checks/result.json` inventory and direct reading (`TEST_F` `:279`…`:1304`, `TEST` `:239`,
  `TEST_P` `:1311`, `INSTANTIATE_TEST_SUITE_P` `:1323`).
- **Retained host artifacts:** `check_unit_matrix` (85/0 candidate, 85/28 baseline) and the
  obligation collector set (all focused on the identifier TU; several failing/blocked per §6).
  None covers `runtime_tests.cpp`.
- **Reproduction path for a later, permitted iteration (not executed here):**

  ```bash
  bazel test //score/socom/test/unit:socom_test
  bazel test //score/socom/test/unit:socom_test --test_filter='ServiceInstanceIdentifierTest.*'
  bazel test //score/socom/test/unit:socom_test --test_filter='RuntimeTest.*'
  # targeted lifetime cases:
  bazel test //score/socom/test/unit:socom_test \
      --test_filter='RuntimeTest.ConnectorDestroyedAfterRuntimeDoesNotCrash'
  bazel test //score/socom/test/unit:socom_test \
      --test_filter='RuntimeTest.ConstructDuplicateAfterEnabledConnectorDestroyedWithChangedMinorVersionReturnsValidServerConnector'
  ```

  Expected on the corrected key: duplicates are refused with `Construction_error::duplicate_service`
  and a freed slot can be registered again. These expectations are source-derived, not measured.
  CE-1 and CE-2 propose additional cases (enable before/after destruction) that would turn these
  limitations into observable checks.

- **Scope:** local, unprotected, scoped. Full native runtime tests and human review remain pending.

---

## 8. Notice preservation

- No source, build, test, config, `NOTICE`, `LICENSE`, `REUSE.toml`, or prior-report file was
  created, edited, or deleted; only this report was written.
- The six candidate files retain their Apache-2.0 / SPDX headers (`…:1-12` each;
  `service_identifier.hpp` and `service_identifier.cpp` carry the 2025 copyright, the newer
  `service_identifier_tests.cpp` carries the 2026 copyright). This report carries the Apache-2.0
  header.
- The header flagged by the task was inspected and left unchanged because it is already
  brace-balanced and well-formed (§2).

---

## 9. Pending human review checklist

- [ ] **Resolve the premise discrepancy:** the "extra closing brace at line 39" does not exist in
      this checkout (line 39 is blank; the header is balanced). Confirm no source edit is required,
      or point to the actual "cancelled draft" revision if it is a different artifact.
- [ ] **Adjudicate CE-1:** decide whether an enabled connector may outlive its `Runtime`. If yes,
      the server-registration `Final_action` needs the same lifetime protection as the key's
      `weak_ptr` (or the contract must forbid it and the drafted test name/claim corrected).
- [ ] **Adjudicate CE-2/CE-3:** confirm whether the drafted "slot reuse"/"isolation" cases must
      re-enable the replacement so that `Service_record::m_server` reset is actually exercised.
- [ ] **Adjudicate CE-4:** consider declaring `m_final_action` before `m_registration` (or otherwise
      expressing the intended erase ordering) to remove the latent ordering hazard.
- [ ] **Adjudicate CE-5:** decide whether permanent `Service_database` records are acceptable or
      whether record cleanup is required; if required, add a lifetime test.
- [ ] **Refresh the measurements:** run `bazel test //score/socom/test/unit:socom_test` (and the
      broader `//score/...` set) so `runtime_tests.cpp` — and the two newest identifier tests
      (`:1982`, `:2012`) — are actually compiled and executed; do not re-report the 85-test focused
      artifact as coverage of the current tree.
- [ ] **Confirm the binding caveat in §1.2:** candidate-manifest hashes no longer match the
      working tree; re-baseline the candidate set.
- [ ] **Supply traceability metadata / resolve applicability** (no invented links), and schedule
      independent human review (approver ≠ author, `gd_req__verification_independence`).
- [ ] **Do not treat the retained obligation results as passing** (§6); several are
      `findings_or_execution_failure`, and the runtime suite is unmeasured.
