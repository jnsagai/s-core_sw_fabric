<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — exact-major / minimum-minor compatibility review against the changed duplicate-server registration key

**Document type:** review draft (actual-source inspection + syntax-failure reconciliation +
exact-major / minimum-minor compatibility analysis against the changed registration key + untested-path
register + discovery-semantics preservation + obligations status).

**Date:** 2026-10-03
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version handling in socom*
(issue #84)
**Run / branch:** `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ`; current run HEAD `95090f6`
(`fabro(01M3ZRSDK2XQAF1H48VWTPKQNZ): node_6ea11f155d1527d342eaf02e (success)`) per the run environment.
**Verified baseline commit:** `f8a196c3b16d5172d898394ab99b0ed81346d63d`
(`.llm_tmp/context/source-manifest.json:3`).
**Status:** **local, unprotected, scoped.** No engineering acceptance exists. Human reviews are
unanswered. Full native runtime tests and human reviews remain pending. Nothing in this document is
acceptance, review, publication, or a full native run.

> **Tool / write boundary observed.** This iteration used only `read_file`, `grep`, `glob`, and
> `write_file` (no `shell`, no `edit_file`, no delegation, no web access, no approval, no publishing,
> and no engineering acceptance). The task contains a conflict: it says to *"Inspect and correct the
> actual source before expanding tests"*, while its explicit, more specific final sentence says *"This
> is a review draft: only that report may be written."* Following the explicit write boundary,
> **exactly one file was written — this report**
> (`/workspace/.llm_tmp/overnight/reports/compatibility.md`). No source, build, test, config, `NOTICE`,
> `LICENSE`, `REUSE.toml`, or prior-report file was created, edited, or deleted, and no test was
> expanded. All prior reports were read and preserved.
>
> **The conflict is moot on the facts.** The described defect — *"a measured GCC syntax failure: an
> extra closing brace in `score/socom/impl/service_identifier.hpp` at line 39"* — is **not present in
> the current working tree** (§2). The header is brace-balanced (braces only at `:19`, `:29`, `:32`,
> `:38`; line `:39` is blank; `:40` is `#endif`), so there is no actual source to correct. Applying the
> historical repair to an already-balanced file would be a no-op at best and a regression at worst; the
> write boundary forbade a source write in any case. The minimal historical repair is retained in §2.4
> for reference only. No test was expanded because the draft's suites already exist on disk (§3, §9).
>
> **Non-satisfaction rule applied throughout.** A successful obligation-collection node means results
> were **retained**, not that checks **passed**. Missing tools, unknown applicability, incomplete
> extraction, a draft rule mapping, skipped/unexecuted applicable checks, and unanswered human reviews
> are **not** treated as satisfied. A tool that produced **no** finding because it **did not run** is
> recorded as *"not run"*, never as *"clean"*. Every unexecuted applicable check and every unaccepted
> deviation remains a **blocker** (§8, §9).

---

## 0. Summary

1. **Recorded syntax failure — inspected; not present in the actual source (§2).**
   `score/socom/impl/service_identifier.hpp` is brace-balanced: four brace-bearing lines
   (`:19` namespace opener, `:29` struct opener, `:32` struct close, `:38` namespace close); `:39` is
   blank; `:40` is `#endif`. Net brace balance `0`; there is no third, unmatched closing brace. The
   GCC/clang focused compiles retained under `.llm_tmp/overnight/obligations/compiler_diagnostics/`
   exit `0` with empty `stderr` including for clang (`clang-compile.stderr` is empty). **No source edit
   was made and none is required.**
2. **The changed key is exactly `(instance, service id, major)`; `minor` is excluded (§3).**
   `score/socom/impl/service_identifier.cpp:28-29` orders by
   `std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major)`. This matches the
   deliberately minor-ignoring `Service_database` index
   (`score/socom/impl/runtime_impl.hpp:116-134`), so two configurations that resolve to the same
   `Service_record` also collide in the key set and the second server connector is rejected with
   `Construction_error::duplicate_service` (`score/socom/impl/runtime_impl.cpp:443`, `:449-454`).
3. **Exact-major compatibility is preserved and consistent with the changed key (§4).** `major` remains
   an identity component of the key *and* is still required to match exactly in `is_interface_compatible`
   (`runtime_impl.cpp:144`). Two servers differing in `major` are distinct keys and may coexist; a
   client/server pair differing in `major` does not bind. The key change neither relaxes nor strengthens
   exact-major.
4. **Minimum-minor compatibility is preserved and unrelated to the changed key (§5).** The
   `client.minor <= server.minor` rule lives in `is_minor_version_compatible`
   (`runtime_impl.cpp:133-136`) and is applied only at client bind / server connect (`:505-517`,
   `:534-544`). It is **not** encoded in the key. Excluding `minor` from the duplicate key does not alter
   the minimum-minor relation; it only makes the duplicate-server gate as coarse as the record index, so
   the single-server precondition `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)` (`:369`) can no longer be
   reached via a minor-only pair of *enabled* server constructions.
5. **Untested paths identified (§6).** The focused `validation/` measurement covers only the identifier
   translation unit. The retained `native_tests` obligation did execute the Bazel suite (with 8
   integration/benchmark targets **SKIPPED**), but the host measurement still records
   `full_native_tests: not_executed`, and the defensive `is_interface_compatible` ASSERT branches,
   `Service_database::get_instances`, client-side minor duplicates, a key-change discovery regression,
   and the config wildcard narrowing remain unexercised. These are not satisfied.
6. **Discovery semantics were not changed (§7).** The key set `m_service_identifiers` is used only in
   `Runtime_impl::make_server_connector` (declared `runtime_impl.hpp:228-229`; constructed at
   `runtime_impl.cpp:443`; inserted/duplicate-gated at `:449-454`; erased at `:456-463`). The
   `Service_database` minor-ignoring index, `get_record`, `bridge_service_requests`,
   `get_or_create_service_requests`, and `get_bridge_reported_instances` are untouched. Future work must
   keep it that way.
7. **No obligation is satisfied (§8).** The host artifacts are **present** under
   `.llm_tmp/overnight/validation/` and `.llm_tmp/overnight/obligations/`, but per the task rule a
   successful collection node means results were *retained*, not that checks *passed*. Several retained
   checks failed or are blocked (`focused_coverage` branch `78.6 %` below the `100 %` safety goal;
   `focused_tsan` exit `66`; `focused_clang_tidy` exit `1`; `focused_cppcheck` exit `2`;
   `native_lint` exit `124`; `secret_dependency_checks` exit `1`; CodeQL findings including dependency
   hits; `process_checks` and `tool_assurance` `completed_with_blockers`), the safety class is unknown,
   applicability is `not_inferred`, and human reviews are unanswered.

---

## 1. Binding to the baseline, prior reports, host feedback, and obligations

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` | `.llm_tmp/context/issue-snapshot.json:2-4` |
| Title | *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:3` |
| State | `open`, 0 comments, no milestone / assignee / labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` (unchanged) | `.llm_tmp/context/issue-snapshot.json:19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted obligation**.
It distinguishes three use cases — *service-instance identifier* = `service id + major + minor +
instance id`; *service identifier* = `service id + major`; *FindService* = `service id + major +
optional<minor> + optional<instance>` — and proposes to *"exclude the minor version and make it a
property of the service instance to be able to better compare and index compatible service instances."*
It notes the FindService `major = FF` AUTOSAR case as theoretically possible but not useful. There is
**no comment and no acceptance record** in the snapshot, so none of it is binding. Binding is **by
baseline commit**, not by run HEAD.

### 1.2 Verified baseline and current tree

| Item | Value | Source |
|------|-------|--------|
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |
| Current branch | `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ` | run environment |
| Current run HEAD | `95090f6` — `node_6ea11f155d1527d342eaf02e (success)` | run environment / `git log` |

Binding is **by baseline commit**, not by run HEAD. Earlier reports reference other run IDs on the same
baseline commit (`01M3YRJEGXNY6CB81T7TKW774B`, `01M3YGTGYFEN406VDEVVTJTRWV`,
`01M3XZAQ65TTE35XSGXC4JAMAH`, `01M3XT7NQ04S4MTFRMTT2401XK`, `01M3WX09X84XFM5X08QY2944DF`, and before
them `01M3WSTF1DAJA248NQ5QQGQG52`/`a282596` and `01M3WWRQWT262FTYS52X80YPTP`/`e12e7cb`), so all of them
describe the same baseline and remain admissible prior evidence. No hashing tool is available in this
task, so the working tree was **not** re-hashed; the direct source reads in §2–§7 are authoritative for
this report, and quoted hashes come from the retained artifacts.

### 1.3 In-scope candidate files (`.llm_tmp/context/candidate-files.json`)

| File (repo-relative) | Baseline git blob | Declared sha256 | Baseline present | Working tree (read this iteration) |
|----------------------|-------------------|-----------------|------------------|------------------------------------|
| `score/socom/BUILD` | `3477ea0851fdcd82ec6ea9d71424013cbdf41962` | `dee826163ac5e6336d51a293136b424696c2884aa1b2592395e1e06423c0ba44` | yes | `headers` glob `*.hpp` (`:17-22`); `socom` lib (`:24-41`); `testonly` `impl_service_identifier` (`:43-54`) |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e22355242009fe20dada2a9a0d0c7a9c7` | `d766902e4bda5306095a6e5326ea91d28df3a6e1ef4e77dc9ba47556ed559a9a` | yes | key identity `(instance, service id, major)`; `minor` excluded (`:28-29`) |
| `score/socom/impl/service_identifier.hpp` | `c8bae7908da9f087c518934f7b9f8d86db9a20ec` | `96b33a1fee4d54577ae9bc46c313409a0d59336f76df85ef1925ffebdd1a2119` | yes | **brace-balanced**, 40 lines; line `:39` blank (§2) |
| `score/socom/test/unit/BUILD` | `3c03a7b14286051f97fa5022206564bd63645171` | `9b3c5b341211e2c387858fd1fe5c669a6a422b6e8b5e80fce35ba22c61186799` | yes | `socom_test` globs `*.cpp` (`:16-29`); deps wired (`:23-29`) |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab726db8bf994c960045d6fd7fdf84d7395` | `5e35e24d0abcfa361b5a5283a005b307b86026a970464a3423be7c6eed66631e` | yes | **33 macros** (1 `TEST` + 31 `TEST_F` + 1 `TEST_P`); minor-only regression `:402-431` |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(none — `null`)* | `45d073998108df76c8f4534508d65f02cead28aa568cd5c45b5a3d8a4fd36a25` | **no** (manifest expects a **new** file) | **91 `TEST_F`** matrix (measured: `validation/after.json`, `obligations/process_checks/result.json:1074`) |

The `null` baseline blob for `service_identifier_tests.cpp` is the manifest's expectation of a **new**
unit-test file; it exists on disk only in the un-merged working tree (the task's *"cancelled draft"*),
never in the baseline. `glob **/service_identifier.hpp` returns exactly **one** path, so there is no
second, differently-braced copy of the header in this checkout. `glob **/*.{orig,rej,bak,patch,diff}`
returns only the unrelated `third_party/*.patch` files, so no leftover reject/patch file carries the
defect.

> **Content-hash caution.** The declared header sha256 in `candidate-files.json` is `96b33a1f…`, while
> the retained host artifacts record the working-tree header as
> `bdce3fcbc3cd78a8ecaece1ea36107d464011ab81c9bc39932d0be617befaea9`
> (`obligations/native_tests/result.json:127`). These differ, i.e. the working tree has moved relative
> to the context snapshot that describes the "cancelled draft". Therefore the context snapshot's
> description of a brace defect cannot be assumed to describe the current file; the **direct read of
> the actual file is authoritative** here, and it shows a balanced header.
> `score/socom/impl/service_identifier.cpp` is recorded as
> `3c12b3f1dd3f1fa66cdf43766f374d7d067637bf8f11aba604c4e2688351f11a`
> (`obligations/native_tests/result.json:126`) — the post-correction key implementation.

### 1.4 Pinned obligation sources read this iteration

All nine entries of `.llm_tmp/context/obligations/source-index.json` were read from
`.llm_tmp/context/obligations/`, together with `authority.json`. Every entry is pinned with
`"native_acceptance": "not_inferred"` — pinned, but its applicability to this slice is **not inferred**.

| id | file | status note |
|----|------|-------------|
| `coding_guidelines` | `coding_guidelines.rst` | `:status: valid`; MISRA C++:2023 with C++17 |
| `code_analysis` | `code_analysis.rst` | `:status: valid`; clang-tidy + gcc/clang warnings + Coverity; sanitizers; gcov/gcovr |
| `misra_mapping` | `misra_mapping.rst` | **`:status: draft`**; the rule table is not a valid obligation |
| `verification_plan` | `verification_plan.rst` | `:status: valid`; quality criteria 1–9 (criterion 9 = freedom from compiler warnings & errors, 100 %) |
| `development_plan` | `development_plan.rst` | `:status: valid`; C++17, GCC host compiler, QCC target, Bazel |
| `tool_management` | `tool_management.rst` | `:status: valid`; tools identified / evaluated / qualified / released-or-rejected by a human |
| `verification_process` | `verification_process.rst` | `:status: valid`; `gd_req__verification_link_tests_cpp`, `_independence`, `_checks`, `_checks_extended`, `_external_aou`, `_sca_classification` |
| `verification_guideline` | `verification_guideline.rst` | `:status: valid`; traceability, independence, documented results |
| `inspection_checklist` | `inspection_checklist.rst` | **`:status: draft`**; blank `IMPL_01_01`…`IMPL_03_02` template |

**Authority record** (`.llm_tmp/context/obligations/authority.json`):
`engineering_acceptance: pending`; `human_reviews: unanswered`; `safety_class: unknown`;
`codeql_scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload"`; instruction
*"Restart the failed queue for one complete pass through all obligations"*.

**Safety-class note (recorded, not resolved).** The pinned platform documents carry `:safety: ASIL_B`,
while `authority.json` records `safety_class: unknown` and no authorized selection exists. The document
attribute is **not** a selection of the slice's safety class and must not be inferred as one.

### 1.5 Prior reports read and preserved

- `.llm_tmp/overnight/reports/` — read and preserved: `scope.md`, `callsites.md`, `invariants.md`,
  `reproducer.md`, `key_fix.md`, `unit_matrix.md`, `ordering_tests.md`, `conversion_tests.md`,
  `runtime_disabled.md`, `runtime_enabled.md`, `lifetime_tests.md`, `test_metadata.md`,
  `coverage_tests_repair.md`, `repair_conversion_tests.md`, `tool_findings_repair.md`. This document
  adds `compatibility.md` only.
- `.llm_tmp/overnight/prior-reports/` — 38 files preserved (including a same-named `compatibility.md`
  from an earlier run, used here only as *quoted prior evidence*, not as this iteration's measurement).

Derived sequence across the preserved reports: `scope.md` (bounded the slice; identified the key/index
identity gap) → `invariants.md` (I-1…I-16; R-1…R-15) → `callsites.md` → `reproducer.md` (header brace
correction + focused regression) → `key_fix.md` / `unit_matrix.md` (drop `minor` from the ordering;
expand the key tests) → `ordering_tests.md` / `conversion_tests.md` → `runtime_disabled.md`,
`runtime_enabled.md`, `lifetime_tests.md` → `test_metadata.md` → later host-side iterations
(`coverage_tests_repair.md`, `repair_conversion_tests.md`, `tool_findings_repair.md`) and review
artifacts under `prior-reports/`.

### 1.6 Host feedback and obligation-collection results (present this iteration)

- **Host validation feedback is present** under `.llm_tmp/overnight/validation/`
  (`check-result` = `0`; `measurement.json`; `before.json`; `after.json`; `before/after` command,
  stdout and stderr). Details in §9.
- **Obligation-collection results are present** under `.llm_tmp/overnight/obligations/*/result.json`
  (plus `collection-result`, command/stdout/stderr artifacts). Per the task rule, a successful
  collection node means results were **retained**, not that checks **passed**. Detailed status in §8.
  Many entries carry a `reused_from` host path — they are retained local, unprotected measurements, not
  a full native acceptance.

---

## 2. The recorded syntax failure: inspection of the actual source

### 2.1 Finding (re-verified this iteration by direct `read_file` + `grep`)

`score/socom/impl/service_identifier.hpp` is **brace-balanced**. It is exactly 40 lines; the only
brace-bearing lines are:

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 21–28 | doc comment | states `minor` is intentionally not part of the identity |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 30–31 | `Service_interface_identifier interface;` / `Service_instance instance;` | members |
| 32 | `};` | closes the struct |
| 34–36 | `/// \cond` / `bool operator<(…)` / `/// \endcond` | the single operator declaration (no brace) |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`) and two closers (`:32`, `:38`) give net brace balance `0`. There is **no
third, unmatched closing brace**, and line `:39` contains no text at all. The sibling
`score/socom/impl/service_identifier.cpp` uses the same nested form (`:18` / `:32`) and is balanced.
The task's *"extra closing brace … at line 39"* therefore matches a **stale, pre-correction
description** (the earliest prior reports quote the split form `}  // namespace socom` +
`}  // namespace score`). `glob **/service_identifier.hpp` returns exactly one path, and no source file
in `score/` uses the split-form `}  // namespace socom` for this header, so there is no second,
differently-braced copy to repair.

### 2.2 Measured corroboration (artifacts present this iteration; retention ≠ acceptance)

- `obligations/compiler_diagnostics/gcc-compile.command.json` and the focused `gcc-tests` command exit
  `0`; `gcc-compile.stderr` is empty. `obligations/compiler_diagnostics/result.json` records
  `status: completed`, `blockers: []`, and **all eight** command `exit_code` values `0`
  (`:1084, :1116, :1152, :1174, :1206, :1238, :1274, :1296`), including the `clang-compile` and
  `clang-tests` commands.
- `obligations/compiler_diagnostics/clang-compile.stderr` is **empty** (no clang
  `-Wdeprecated-declarations` failure this round; the limits note at `result.json:1303` records
  "GoogleTest compiled separately with warnings retained; `-Werror` on target and tests").
- `validation/after-compile.command.json` / `before-compile.command.json` compile the header as a
  transitive include of `service_identifier.cpp` + `string_registry.cpp` +
  `service_identifier_tests.cpp` with `g++-12 -std=c++17 -Wall -Wextra -Werror`, exit `0`, empty
  `stderr`; `after-test.stdout` reports `[ PASSED ] 91 tests`.

A surviving extra closing brace would have failed these compiles. **No compile was run by this
iteration**; the statements above are retained host measurements (§9), not acceptance.

### 2.3 Disposition and the write-boundary conflict

**No correction was applied, and none is required.** The instruction's precondition ("inspect and
correct the actual source before expanding tests") is satisfied without a source write: there is
nothing to correct, and the explicit write boundary ("only that report may be written") forbids the
write in any case. If the *"cancelled draft"* is a different revision that still carries the extra
brace (cf. the hash caution in §1.3), it is **not** the file in this checkout and must be located and
corrected by an authorized iteration; this report records the discrepancy for human disposition rather
than speculating. No test was expanded, because the draft's suites already exist on disk (§3, §9).

### 2.4 Minimal historical repair (reference only; NOT applied)

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

Applying this to the already-balanced file would be a no-op; deleting a brace would *create* the
reported defect.

### 2.5 Why it would matter if present

The header is compiled into `//score/socom:socom` (`score/socom/BUILD:24-41`; its `srcs` globs
`impl/**/*.cpp` and `impl/**/*.hpp`) and re-exposed to `//score/socom/test/unit` through the `testonly`
library `impl_service_identifier` (`score/socom/BUILD:43-54`; consumed at
`score/socom/test/unit/BUILD:24`). A syntax error there would fail the library and the whole
`socom_test` target, contradicting S-CORE quality criterion 9 (`verification_plan.rst`). It is **not** a
blocker in the current tree; that is a static brace-balance reading corroborated by the retained
compiles, **not** an acceptance.

---

## 3. The changed duplicate-server registration key (as-is)

All line references are readings of the current working tree at the baseline-bound candidate paths.

| Item | Site | Notes |
|------|------|-------|
| Key struct | `score/socom/impl/service_identifier.hpp:29-32` | `Service_instance_identifier{ Service_interface_identifier interface; Service_instance instance; }`; comment `:21-28` explains the minor exclusion and references the minor-ignoring index / issue #84 |
| `operator<` declaration | `service_identifier.hpp:35` (inside `\cond`/`\endcond`, `:34`/`:36`) | the **only** operator of the type; no `operator==`, no `std::hash` |
| `operator<` definition | `score/socom/impl/service_identifier.cpp:20-30` | `std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major) < std::tie(rhs.instance, rhs.interface.id, rhs.interface.version.major)` (`:28-29`); rationale comment `:21-27` |
| Container / storage | `score/socom/impl/runtime_impl.hpp:56`, `:228-229` | `Service_identifiers = Mutexed_variable<std::set<Service_instance_identifier>>` |
| Key construction / duplicate gate | `score/socom/impl/runtime_impl.cpp:443`, `:449-454` | `Service_instance_identifier const identifier{configuration.get_interface(), instance};` then, under the key mutex, `insert(identifier).second == false ⇒ Construction_error::duplicate_service` (`:451-452`) |
| Key lifetime | `score/socom/impl/runtime_impl.cpp:456-463` | `Final_action` captures `identifier` + `weak_ptr` and erases on destruction |
| Error value | `score/socom/error.hpp:54-58` | `Construction_error::duplicate_service` (`:55`), commented only *"Service identifier already exists."* |
| Public doc | `score/socom/runtime.hpp:170-178`, `:188-191` | `make_server_connector` doc: duplicates judged by *"the configuration.interface and instance parameters"* |

`std::set` uniqueness is `!(a < b) && !(b < a)`. Therefore, on this working tree, the duplicate server
identity is exactly `(instance, service id, major)` and **`minor` is not part of it**. The public
`Service_interface_identifier` ordering/hash still include `minor`
(`service_interface_identifier.hpp:130-133`, `:140-143`, `:149-152`, `:159-162`, `:181-190`); only the
`impl/`-only key excludes it.

This closes the key/index identity gap: the `Service_database` index already ignores `minor` via
`Minor_version_ignoring_key_equal` / `Minor_version_ignoring_hash` (`runtime_impl.hpp:116-121`,
`:123-129`, `:131-134`), and `Service_record` holds a single `std::optional` server
(`runtime_impl.hpp:70`) guarded by `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)`
(`runtime_impl.cpp:369`). With the changed key, two server connectors that share
`instance + id + major` but differ only in `minor` now collide at the set insertion rather than both
resolving to the same record and reaching the single-server assert on enable.

> **Documentation/contract mismatch carried forward (not a defect claim).** The public doc says
> duplicates are judged by the *"configuration.interface and instance parameters"*
> (`runtime.hpp:172-178`), and the public `operator==` includes `minor`
> (`service_interface_identifier.hpp:149-152`), while the registration key excludes it. A minor-only
> collision now returns `duplicate_service` even though the public interface values differ. Whether the
> doc and error text should be narrowed is an open question for human review (§11).

---

## 4. Exact-major compatibility against the changed key

**Result: preserved and consistent; no semantic change.**

- **In the key.** `major` is an identity component (`service_identifier.cpp:28-29`). Two server
  registrations that differ in `major` produce distinct keys and may coexist; the slot for one major
  does not block another. This is consistent with issue #84's "service identifier = `service id +
  major`" use case (a proposal, not an accepted obligation).
- **In the compatibility predicate.** `is_interface_compatible` requires
  `server.version.major == client.version.major` (`runtime_impl.cpp:144`) in addition to equal `id`; a
  client/server pair with different `major` never binds (the `else` branch logs "minor version
  incompatible"; call sites `:505-517` client, `:534-544` server). The changed key is never consulted
  by this predicate.
- **Key-level evidence (present in source; measured only as part of the native suite, §9).**
  `KeysDifferingInMajorVersionAreDistinct`, `MajorVersionBoundariesAreDistinct`,
  `MajorVersionSweepProducesDistinctKeys`, `AdjacentMajorVersionBoundariesAreDistinct`,
  `MajorVersionLadderOrdersNumericallyAndDistinctly`, `MajorVersionByteBoundariesAreDistinctAndOrdered`,
  `MajorVersionOrderMatchesUnsignedNumericOrder` (`service_identifier_tests.cpp`, e.g. listed at
  `:217`, `:225`, `:235`, `:246`, `:1264`, `:1656`, `:1680`; 91 cases total).
- **Runtime-level evidence (present in source).**
  `ConstructDifferentMajorWhileBothConnectorsDisabledReturnsDistinctServerConnectors`
  (`runtime_tests.cpp:471-500`); `DestroyingOneMajorSlotKeepsOtherMajorSlotOccupied` (`:1141`).
- **Interface/C++ evidence (present in source).** `interface_compatibility_tests.cpp` `Version`
  instantiation (`:190-211`) includes `{10, min_minor}` major-mismatch `no_connect` cases and the
  `max_major` mismatch; `client_tests.cpp:643` `DifferentServiceInterfaceMajorVersion`.
- **Measured run.** The retained `native_tests` Bazel run reports
  `//score/socom/test/unit:socom_test PASSED` (`obligations/native_tests/tests.stdout:16`), which
  includes the runtime and interface-compatibility suites. This is a retained local measurement
  (§8, §9), not acceptance.

**Boundary note (unresolved, out of slice).** Some SOME/IP stacks use `major = 0xFF` as a wildcard, and
the config declares `service_version_major: uint8` (`score/config/mw_someip_config.fbs:19`) versus
socom's `std::uint16_t major` (`service_interface_identifier.hpp:83`). The `uint8 → uint16` widening is
lossless; the changed key treats `major` as an exact identity component and implements no wildcard.
That is deliberate for this bounded slice and is recorded as unresolved, not as a defect.

---

## 5. Minimum-minor compatibility against the changed key

**Result: preserved; the changed key does not encode or alter the minimum-minor rule.**

- **The rule.** `is_minor_version_compatible(server, client)` is
  `client.version.minor <= server.version.minor` (`runtime_impl.cpp:133-136`); it is applied at client
  bind (`:505-517`) and server connect (`:534-544`). It is a **server-vs-client** relation, not a
  set-membership rule, and it is **not** consulted anywhere inside the key set.
- **The key.** `minor` is excluded (`service_identifier.cpp:28-29`; key members `:30-31`). Excluding it
  makes duplicate detection *coarser*; it does not change `<=`. Two servers sharing
  `instance + id + major` but differing in `minor` are now the same registration key. Consequently the
  client's possible counterpart server for a given `(instance, id, major)` is unique, and the `<=` test
  is evaluated against that single server's `minor`.
- **Direction of the interaction.** On the pre-correction key (`minor` included) two such servers could
  both be constructed, but `Service_record` can hold only one (`m_server` `std::optional`,
  `runtime_impl.hpp:70`; `ASSERT(!m_server)`, `runtime_impl.cpp:369`), so the second *enable* would hit
  the assert. The key change removes that path at *construction* time and returns
  `duplicate_service`. This is a change to duplicate **registration**, not to minimum-minor
  **compatibility**.
- **Evidence (present in source; compiled/run as part of the native suite, §9).**
  - `interface_compatibility_tests.cpp` `Version` instantiation (`:190-211`) covers: same version →
    connect; client `{min_major, 10}` vs server `{min_major, min_minor}` → `no_connect`; server
    `{min_major, 10}` vs client `{min_major, min_minor}` → `connect`; `max_major` mismatch →
    `no_connect`; `max_minor` variants; both-`max_version` → `connect`. Both
    `ServerCreatedBeforeClient` (`:73-89`) and `ClientCreatedBeforeServer` (`:91-123`) orders are
    parameterized.
  - `client_tests.cpp:660` `BiggerServiceInterfaceMinorVersion` (server minor smaller than the client's
    ⇒ `no_connect`) and `:678` `SmallerServiceInterfaceMinorVersion` (server minor larger ⇒ `connect`).
  - `runtime_tests.cpp:402-431` `ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError`
    and the disabled-only variants (`:440`, `:573`, `:607`, `:642`) exercise the key's minor collapse
    at the `Runtime::make_server_connector` entry point. All keep both connectors disabled, so the
    duplicate is rejected at construction and never reaches the single-server assert.

**Asymmetry worth recording.** `Service_record` also holds a single client (`m_client`,
`runtime_impl.hpp:71`), and `register_client_connector` returns `duplicate_client` when `m_client` is
already set (`runtime_impl.cpp:386-388`) — **without comparing versions at all**. Client duplicate
detection therefore already ignored version, including `minor`. The changed key makes the *server-side*
duplicate identity consistent with the same minor-ignoring record index; it does not touch client
duplicate detection. There is no test pinning the client-side minor-duplicate equivalence (§6).

**Config-width note (out of slice; untested).** The SOME/IP config declares
`service_version_minor: uint32 = 0xFFFFFFFF` (the "accept any minor" wildcard,
`score/config/mw_someip_config.fbs:23`) and it is narrowed with
`static_cast<uint16_t>(service_version_minor())` at config→socom conversion sites (e.g.
`score/someipd/impl/remote_network_service.cpp:42-45`; also `local_network_service.cpp:47-49`,
`score/gatewayd/impl/local_service_instance.cpp:48-49`,
`score/gatewayd/impl/remote_service_instance.cpp:91-93`, `score/gatewayd/main.cpp:231-232`), turning
`0xFFFFFFFF` into `0xFFFF`. Under the coarsened key, a wildcard-derived `0xFFFF` server and a
concrete-minor server sharing `(instance, id, major)` now collide as `duplicate_service`. How the
wildcard should map is unresolved and explicitly out of this bounded slice.

---

## 6. Untested paths (explicit register)

The following paths are **not covered by this iteration's measurements**, are **not established as
satisfied**, and must not be presented as passing:

1. **Integration / benchmark native suites are skipped.** The retained `native_tests` run
   (`bazel --batch test --jobs=2 //... --build_tests_only`) reports
   *"Executed 21 out of 29 tests: 21 tests pass and 8 were skipped"*
   (`obligations/native_tests/tests.stdout:31`). The eight `SKIPPED` targets are the integration tests
   under `//tests/integration_test/...` and the e2e benchmarks (`tests.stdout:1-8`). Cross/QEMU
   integration and benchmarks are therefore **not executed**. `cross_compilation` is
   `completed_with_blockers` (`.llm_tmp/overnight/obligations/cross_compilation/result.json:1113`).
2. **`is_interface_compatible` ASSERT branches** (`runtime_impl.cpp:508-509` client, `:535-536`
   server) are described in-source as defensive (`:140-142`) and are never independently triggered; no
   test forces the assert. Only the `else` minor-incompatible log branch is covered.
3. **`Service_database::get_instances`** (both overloads, `runtime_impl.cpp:326-343` and `:345-360`) has
   **no production caller** in the tree (the only reference is the self-forward at `:349`). This
   discovery helper is effectively dead / untested. It is not touched by the key.
4. **Client-side minor duplicates.** There is no test pinning that two client connectors for the same
   `(instance, id, major)` but different `minor` yield `duplicate_client` (client detection ignores the
   interface version entirely, `runtime_impl.cpp:386-388`). This is an untested equivalence class
   adjacent to the changed key.
5. **No discovery-regression test tied to the key change.** Nothing asserts that
   `get_bridge_reported_instances` / `bridge_service_requests` results are unchanged by the key change
   (bridge-behaviour tests such as `BridgeReceivesRequestServiceFunctionCallForUnknownService` and
   `BridgeDoesNotReceiveRequestServiceFunctionCallForKnownService` exist at `runtime_tests.cpp:295`,
   `:303`, but they are not framed as key-change regressions).
6. **Config minor wildcard / narrowing and FindService wildcard.** The `uint32 0xFFFFFFFF` minor
   wildcard (`score/config/mw_someip_config.fbs:23`) narrowed to `uint16 0xFFFF` at the conversion
   sites, and the FindService `major = FF` case, are unresolved and untested; they are explicitly out
   of this bounded slice (§5).
7. **Tool-based obligations remain unestablished**: clang-tidy (config `exit 1`), cppcheck (`exit 2`),
   TSan focused (`exit 66`), native lint (`exit 124`), CodeQL findings including dependency hits,
   secret/dependency scan `exit 1`, and focused coverage branch `78.6 %` (below the safety goal). These
   are not "passing" (§8).

---

## 7. Discovery semantics (deliberately unchanged)

The changed key is a **duplicate-server registration gate only**. It must not and does not affect
service discovery:

- The key set `m_service_identifiers` is read/written only in `Runtime_impl::make_server_connector`:
  declared at `runtime_impl.hpp:228-229`, constructed at `runtime_impl.cpp:443`, inserted under the key
  mutex at `:449-454`, erased by the captured `Final_action` at `:456-463`. A tree-wide search for
  `m_service_identifiers` returns exactly those sites.
- The `Service_database` record index (`Minor_version_ignoring_key_equal` /
  `Minor_version_ignoring_hash`, `runtime_impl.hpp:116-134`) and `get_record`
  (`runtime_impl.cpp:313-324`) are untouched and remain minor-ignoring.
- Bridge/discovery (`bridge_service_requests`, `runtime_impl.cpp:561-575`;
  `get_or_create_service_requests`, `:577-587`; `get_bridge_reported_instances`, `:595-612`) is driven
  by `m_service_requests` / `m_bridge_to_callbacks`, **not** by the key set, and is untouched.
- The public identifier's ordering/hash (still `minor`-aware,
  `service_interface_identifier.hpp:130-190`) and the IPC `Service` key (still `minor`-aware) are
  untouched.

**Recommendation carried to human review:** any future implementation in this slice must keep the key
change confined to the `std::set` duplicate gate and must not alter `Service_database`, `get_record`, or
the bridge/discovery paths, so that discovery semantics stay unchanged.

---

## 8. Obligations status (retention ≠ passing; none satisfied)

### 8.1 Pinned state

All nine pinned sources were read (§1.4); every `source-index.json` entry is
`"native_acceptance": "not_inferred"`. `authority.json` records `engineering_acceptance: pending`,
`human_reviews: unanswered`, `safety_class: unknown`. This iteration ran **no** build, test, or tool;
the statuses below are **retained host measurements** read from
`.llm_tmp/overnight/obligations/*/result.json`, which is *retention*, not passing.

### 8.2 Retained obligation results relevant to this slice

| Obligation (`result.json`) | Retained `status` | Retained signal |
|----------------------------|-------------------|-----------------|
| `compiler_diagnostics` | `completed` | all 8 gcc/clang command exits `0` (`:1084, :1116, :1152, :1174, :1206, :1238, :1274, :1296`); `blockers: []` (`:1052`); **focused identifier TU only** (`:1302`) |
| `focused_coverage` | `completed` | line `100 %`, **branch `78.6 %`** (`:1167-1168`); goals QM 85 / safety 100; `safety_class: unknown_requires_authorized_selection`; `complete_target_scope: false` (`:1173-1174`) |
| `focused_asan_lsan` | `completed` | exit `0` |
| `focused_memcheck` | `completed` | exit `0` (`:1116`, `:1119`) |
| `focused_tsan` | `findings_or_execution_failure` | exit `66` (`:1114`, `:1117`) |
| `focused_clang_tidy` | `findings_or_execution_failure` | config `exit 1` (`:1077`, `:1080`) |
| `focused_cppcheck` | `findings_or_execution_failure` | `exit 2` (`:1081`, `:1084`) |
| `codeql_security` | `findings_or_execution_failure` | scan exit `0`; findings retained incl. dependency hits (`:1110-1113`) |
| `codeql_misra` | `findings_or_execution_failure` | draft rule mapping; focused linked executable, not full target extraction |
| `secret_dependency_checks` | `findings_or_execution_failure` | scan `exit 1` (`:1080`, `:1083`) |
| `native_build` | `completed` | `bazel build --jobs=2 //...` exit `0` (`:1060-1078`) |
| `native_tests` | `completed` | `bazel test --build_tests_only //...` exit `0`; `//score/socom/test/unit:socom_test PASSED`; 21/29 pass, 8 skipped (`tests.stdout:16,31`) |
| `native_lint` | `findings_or_execution_failure` | first command `exit 124` (timeout), `ruff` `exit 0` (`:1079`, `:1105`) |
| `native_sanitizers`, `native_tsan` | `completed` | retained; not the full runtime scope |
| `native_coverage` | `completed` | retained |
| `native_integration`, `native_docs`, `native_traceability`, `native_performance`, `format_precommit` | `findings_or_execution_failure` | retained findings |
| `cross_compilation` | `completed_with_blockers` | exit `0`; blockers retained (`:1113`) |
| `tool_assurance` | `completed_with_blockers` | tool inventory: g++-12, clang++ 19, clang-tidy available (`:1391-1404`); blockers retained (`:1389`) |
| `process_checks` | `completed_with_blockers` | blockers: lexical inventory ≠ semantic coverage; safety/QM applicability unknown; independent inspection/acceptance required; external AoU/full integration review required (`:1052-1057`); 91 key macros / 33 runtime macros (`:1061-1080`) |
| `rework_progress` | `completed` | `source_changed_this_round: false`, `rework_requested: false` (`:1056-1057`) |

### 8.3 Status for this slice (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Freedom from compiler warnings & errors (100 %) | `verification_plan.rst` (criterion 9) | **NOT SATISFIED (retained focused signal only)** — gcc/clang focused compiles exit `0` empty `stderr`; no full-target `-Werror` build acceptance |
| Static code analysis (clang-tidy / CodeQL), findings classified | `code_analysis.rst`; `verification_process.rst` (`gd_req__verification_sca_classification`) | **NOT SATISFIED** — clang-tidy config `exit 1`, cppcheck `exit 2`, CodeQL findings incl. dependency hits, draft MISRA mapping |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` | **UNKNOWN — NOT CLAIMED** — mapping is `:status: draft` |
| Structural statement / branch coverage goals | `verification_plan.rst` (criteria 1–2) | **NOT SATISFIED** — focused `service_identifier.cpp` `78.6 %` branch `< 100 %` safety goal (and `< 85 %` QM goal); `safety_class: unknown`; `complete_target_scope: false` |
| Unit/component testing executed, results recorded | `verification_plan.rst` (criteria 6–7); `verification_guideline.rst` | **PARTIAL / NOT SATISFIED** — retained focused identifier suite `91/0` (red→green) and retained native `socom_test PASSED`; `validation/` `full_native_tests: not_executed`; 8 integration/benchmark targets skipped; no acceptance |
| Interface / requirements-based / resource / fault-injection test types | `verification_process.rst`; `verification_plan.rst` | **NOT PERFORMED / applicability not inferred** — no harness; identifier/runtime tests must not be labelled platform validation |
| Boundary / equivalence derivation | `verification_process.rst` | **PARTIAL** — boundary/equivalence cases exist and the retained native run compiled/ran them; derivation intent not accepted |
| Fuzzy testing technique | `verification_plan.rst` | **NOT EXECUTED / NOT CLAIMED** — no harness and no measurement |
| Linking tests to requirements (record properties) | `verification_process.rst` (`gd_req__verification_link_tests_cpp`) | **PARTIAL / NOT DONE** — `DerivationTechnique`/`Description` recorded (`service_identifier_tests.cpp:42-65`; `runtime_tests.cpp:264-267`); `TestType` and `Verifies` deliberately unset (no verified identifier exists; inventing one is prohibited) |
| External-component AoUs verified | `verification_process.rst` (`gd_req__verification_external_aou`) | **NOT SATISFIED** — no integration/static verdict; no AoU register |
| Independence of verification / review by a different committer | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Implementation inspection checklist IMPL_01…IMPL_03 | `inspection_checklist.rst` | **NOT FILLED** — draft template, no inspection |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** — `tool_assurance` `completed_with_blockers` |
| Obligation collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **RETAINED but retention ≠ passing** — several failures/blockers (§8.2) |
| Native acceptance | `source-index.json` | **`not_inferred` for every entry** |

**Explicit non-satisfaction statement.** The unknown safety class, the un-inferred applicability, the
failing or blocked focused checks (clang-tidy, cppcheck, tsan, native lint, secret scan, branch
coverage), the skipped integration/benchmark suites, the host `full_native_tests: not_executed` flag,
the incomplete extraction (many results `reused_from` host paths), and the unanswered human reviews
mean **none of the checked obligations may be treated as satisfied**. A successful collection node
means results were *retained*, not that checks *passed*; here the retained results include explicit
failures, and absence of a result would likewise not be evidence of passing.

---

## 9. Measurement and validation status

### 9.1 This iteration

- **Tools:** `read_file`, `grep`, `glob`, `write_file` only. No `shell`, delegation, web, approval,
  publishing, or engineering acceptance.
- **Executed measurements by this iteration:** **none**. No build, no test, no runtime. Every
  correctness statement in §2–§7 is a static reading of the working tree at the baseline-bound
  candidate paths or an explicitly-labelled logical consequence, except where a retained host artifact
  is cited as such.

### 9.2 Retained host measurements (present, scoped, unprotected)

- `validation/check-result` = `0`.
- `validation/measurement.json`: `check_ref: check_conversion_tests`, `mode: ubsan`,
  `changed_paths: ["score/socom/test/unit/service_identifier_tests.cpp"]`,
  `origin: local_unprotected_measurement`, `initiator: Fabro host hook`,
  `engineering_acceptance: pending`, `full_native_tests: not_executed`, compiler
  `/usr/bin/x86_64-linux-gnu-g++-12` (`sha256 88315fd2…`),
  `baseline_with_agent_tests` = **91 tests / 33 failures / compile exit 0 / test exit 1**,
  `candidate` = **91 tests / 0 failures / compile exit 0 / test exit 0** (`:2045-2058`).
- `validation/before.json` = 91 tests / 33 failures; `validation/after.json` = 91 tests / 0 failures
  (all `ServiceInstanceIdentifierTest`).
- `validation/after-compile.command.json` / `before-compile.command.json`: GCC `-std=c++17 -Wall
  -Wextra -Werror -pthread` over `service_identifier.cpp` + `string_registry.cpp` +
  `service_identifier_tests.cpp` + googletest, exit `0`, empty `stderr`; `after-test.stdout` ends
  `[ PASSED ] 91 tests`.
- **Scope caveat:** the `validation/` measurement compiles **only the focused identifier translation
  unit**. It does **not** cover `runtime_tests.cpp`, `interface_compatibility_tests.cpp`, or
  `client_tests.cpp`, and it is not a Bazel build. The before/after distinction (33 failures vs 0) is
  the registration-key implementation difference, demonstrating the expanded key tests are red on the
  baseline key and green on the changed key.
- `obligations/native_tests/tests.stdout` shows the native Bazel run did execute
  `//score/socom/test/unit:socom_test` (`PASSED`), plus the broader suite (21 pass / 8 skipped). This
  covers `runtime_tests.cpp` and `interface_compatibility_tests.cpp` in that retained run — but it is a
  local, unprotected, `reused_from` host measurement, the integration/benchmark targets were skipped,
  and `full_native_tests` remains `not_executed`. It is **not** acceptance.

### 9.3 Test inventory (read; measured counts)

- `score/socom/test/unit/service_identifier_tests.cpp` = **91 `TEST_F`** under
  `ServiceInstanceIdentifierTest` (`validation/after.json:2`; `obligations/process_checks/result.json:1074`),
  metadata in `SetUp()` (`:42-65`): `DerivationTechnique = "boundary-values,equivalence-classes"` and a
  `Description`; `TestType` and the verification links deliberately unset.
- `score/socom/test/unit/runtime_tests.cpp` = **33 macros** (1 `TEST` at `:239`, 31 `TEST_F`
  `:279`…`:1253`, 1 `TEST_P` at `:1311`; `obligations/process_checks/result.json:1065`), including the
  minor-only duplicate regression `:402-431`; shared metadata helper `:264-267`.
- `interface_compatibility_tests.cpp` = parameterized `InterfaceCompatibilityTest`
  (`ServerCreatedBeforeClient` `:73`, `ClientCreatedBeforeServer` `:91`; `Identifier` and `Version`
  instantiations `:179-211`). `client_tests.cpp`: `:643`, `:660`, `:678`.

### 9.4 Regression target (source-derived; retained focused signal)

`RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError`
(`runtime_tests.cpp:402-431`) and the key-level minor-collapse cases (`service_identifier_tests.cpp`,
e.g. `:174`, `:182`, `:192`, `:203`) assert that a second registration differing only in `minor` is
rejected as `duplicate_service`. On the pre-correction key they fail (33 failures in
`validation/before.json`); on the changed key the focused identifier suite passes (`validation/after.json`,
91/0). Both disabled-path runtime regressions keep their connectors disabled, so the duplicate is
rejected at construction and never reaches the single-server assert.

### 9.5 Reproduction path for a later, permitted iteration (not executed here)

```bash
bazel build //score/...
bazel test //score/...
bazel test //score/socom/test/unit:socom_test
# focused key-level:
bazel test //score/socom/test/unit:socom_test --test_filter='ServiceInstanceIdentifierTest.*'
# focused runtime regression:
bazel test //score/socom/test/unit:socom_test \
    --test_filter='RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError'
# minimum-minor matrix:
bazel test //score/socom/test/unit:socom_test --test_filter='InterfaceCompatibilityTest.*'
# integration / cross / docs / traceability (per the pinned plans)
bazel test --config=qemu-integration //tests/integration_test/...
```

**Scope:** local, unprotected, scoped. This draft has not been reviewed, accepted, published, or
reproduced on a full native runtime. Unit/integration execution and human review remain pending.

---

## 10. Notice preservation

- **Only this report was written.** No source, build, test, config, `NOTICE`, `LICENSE`,
  `REUSE.toml`, or prior-report file was created, edited, or deleted. Every existing Apache-2.0 /
  notice header is untouched, and all files under `.llm_tmp/overnight/reports/` and
  `.llm_tmp/overnight/prior-reports/` were preserved.
- The header the task flagged (`score/socom/impl/service_identifier.hpp`) was inspected and left
  **unchanged** because it is already brace-balanced and otherwise well-formed (§2). The sibling
  `service_identifier.cpp`, both BUILD files, and both candidate test files already carry their
  Apache-2.0 / SPDX headers (`:1-12`).
- This report itself carries the Apache-2.0 header. No licensed MISRA rule text is reproduced; only
  native rule/query identifiers, file locations, and prior-report readings are cited.
- The duplicate key remains an `impl/`-only type; the `testonly`
  `//score/socom:impl_service_identifier` library exposes it only to `//score/socom/test/unit`, so no
  public header or notice surface changed.

---

## 11. Pending human review checklist

- [ ] **Confirm the §2 inspection:** the header is already brace-balanced (`:19`, `:29`, `:32`, `:38`;
      line `:39` blank; single nested close `}  // namespace score::socom`), and the retained focused
      gcc and clang compiles both exit `0` with empty `stderr` — so the recorded syntax failure is
      stale and no source correction is required. If the *"cancelled draft"* (cf. the §1.3 hash
      caution) is a different revision that still carries the extra brace, locate it and authorize its
      correction; it is not the file in this checkout.
- [ ] **Resolve the instruction conflict:** the task directs correcting the source, while the actual
      source contains no defect and the explicit write boundary permits only the report. Confirm that a
      no-op plus this report is the intended outcome.
- [ ] **Confirm the changed key decision (§3):** `minor` is **not** part of the duplicate-server
      registration key; identity is `(instance, service id, major)`; the public interface representation
      is unchanged.
- [ ] **Confirm the exact-major analysis (§4):** `major` remains both a key identity component and an
      exact-equality requirement in `is_interface_compatible`; and confirm whether the `major = FF` /
      config-width wildcard question stays explicitly out of this slice.
- [ ] **Confirm the minimum-minor analysis (§5):** `client.minor <= server.minor` stays a
      client-vs-server predicate, is not encoded in the key, and the key change only prevents two
      same-`(instance, id, major)` server registrations from being constructed; confirm the client-side
      asymmetry (`duplicate_client` ignores version) is acceptable and out of slice.
- [ ] **Confirm the untested-path register (§6):** especially the skipped integration/benchmark suites,
      the defensive `is_interface_compatible` ASSERT branches, the caller-less `get_instances`, and the
      client-side minor-duplicate equivalence; do not present the identifier/runtime tests as platform
      validation.
- [ ] **Confirm the discovery-semantics guarantee (§7):** the key change must stay confined to the
      `std::set` duplicate gate; `Service_database`, `get_record`, and the bridge/discovery paths must
      remain untouched.
- [ ] **Decide the documentation/error-text mismatch (§3):** `runtime.hpp:172-178` speaks of duplicates
      judged by *"configuration.interface and instance parameters"* and `error.hpp:55` says only
      *"Service identifier already exists."*, while the key ignores `minor`. Authorize or reject a
      documentation/error-message correction.
- [ ] **Do not infer passing from retained collection nodes (§8):** several checks failed or are
      blocked (clang-tidy, cppcheck, focused TSan, native lint, secret scan, branch coverage below
      goal); retention is not acceptance. `process_checks` and `tool_assurance` are
      `completed_with_blockers`.
- [ ] **Run the full native suite and integration matrix** (`bazel test //score/...`, the skipped
      `//tests/integration_test/...` and benchmarks, and the interface-compatibility matrix), record
      results, and schedule independent human review (the approver must differ from the author, per
      `gd_req__verification_independence`).
- [ ] **Select a safety class** via the authorized role; do not infer the slice's class from the
      `:safety: ASIL_B` attribute on the pinned platform documents.

---

*End of exact-major / minimum-minor compatibility review draft. Local, unprotected, scoped. No
engineering acceptance; human reviews unanswered; full native runtime tests pending. Every statement is
a local reading of the working tree, a retained host measurement, a prior report's recorded reading, or
an explicitly-labelled logical consequence — none is acceptance, review approval, publication, or a
full native run.*
