<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — invalidation / connector-lifetime / slot-reuse review of the bounded
# duplicate-server registration-key slice (`lifetime_review`)

**Document type:** review draft — actual-source inspection of the registration-key lifetime machinery
+ review of the drafted runtime cases + concrete counterexamples + obligation/measurement status.

**Date:** 2026-10-03
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling inside *Revise version handling in
socom* (issue #84). This document reviews **invalidation, connector lifetime and slot reuse** of
that key.
**Run / branch:** `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ` (branch of the same name); latest recorded
commit `20199c3`.
**Verified baseline commit:** `f8a196c3b16d5172d898394ab99b0ed81346d63d`
(`.llm_tmp/context/source-manifest.json:3`).
**Status:** **local, unprotected, scoped.** No engineering acceptance exists. Human reviews are
**unanswered**. Full native runtime tests remain **pending**. Everything below is either a direct
static reading of this checkout, a reading of a retained host artifact present in this checkout, or
an explicitly-labelled logical consequence. Nothing here is published, reviewed, accepted, or a
full native run.

> **Tool / write boundary actually observed.** Only `read_file`, `grep`, `glob`, and `write_file`
> were available and were the only tools used. No `shell`, no delegation, no web access, no approval,
> no publishing, and no engineering acceptance was performed. The task's final sentence is the
> operative boundary: *"This is a review draft: only that report may be written."* **This iteration
> wrote exactly one file — this report**
> (`/workspace/.llm_tmp/overnight/reports/lifetime_review.md`). No source, build, test, config,
> `NOTICE`, `LICENSE`, or `REUSE.toml` file was created, edited, or deleted, and every prior report
> was preserved unchanged.
>
> **Premise reconciliation — the recorded syntax failure is not in this checkout.** The task states
> *"a measured GCC syntax failure: an extra closing brace in
> `score/socom/impl/service_identifier.hpp` at line 39"* and directs that the actual source be
> inspected and corrected before the tests are expanded. Direct inspection of the *actual* file this
> iteration (§4.1) shows exactly two opening braces (`:19`, `:29`) and two closing braces (`:32`,
> `:38`), net balance `0`; `:39` is **blank** and `:40` is `#endif`. A `glob` for
> `**/service_identifier.hpp` returns exactly one path and `glob` for `**/*.{orig,rej,bak}` returns
> nothing, so there is no second, differently-braced copy and no leftover patch/reject file.
> Independently, the retained host compile present in this checkout compiles two translation units
> that include that header, with `-Wall -Wextra -Werror`, and exits `0` with empty stderr (§3.3,
> §5.3) — which is incompatible with an unparsable header. The described defect therefore survives
> only in the earliest *pre-correction* prior reports; the `reproducer` iteration applied the
> single-close correction and that balanced state is what this checkout contains. Because (a) the
> write boundary forbids source edits this iteration and (b) there is no defect in the actual file to
> correct, **no production source was edited.** The minimal historical repair is retained in §4.3 for
> reference only.

---

## 0. Summary

This review inspects the *actual* lifetime machinery behind the duplicate-server registration key and
the drafted runtime cases that claim to pin it. The key correction itself is present and consistent
(§4). The concrete counterexamples are:

1. **CE-1 (concrete defect, use-after-free): a connector that outlives its `Runtime` is safe only
   while it is *disabled*.** `ConnectorDestroyedAfterRuntimeDoesNotCrash`
   (`runtime_tests.cpp:1021-1028`) only ever creates a disabled connector. If the connector had been
   *enabled* before the runtime was destroyed, its destructor would run
   `~Impl() -> disable() -> m_registration.reset()`, and that registration's `Final_action` captures
   the `Service_record` that lived inside the destroyed `Runtime_impl`
   (`runtime_impl.cpp:366-382`, `:526-551`). It then locks `Service_record::m_runtime_mutex` (a
   reference to the destroyed `Runtime_impl::m_runtime_mutex`) and calls `m_server.reset()` on freed
   storage. The key's `weak_ptr` guard (`runtime_impl.cpp:456-463`) protects only the *key erase*,
   not the server registration. Concrete two-extra-line counterexample in §5.1; the drafted test name
   "does not crash" is therefore established only for the never-enabled state.
2. **CE-2 (coverage counterexample): the "enabled slot reuse" cases never re-enable the replacement.**
   `ConstructDuplicateAfterEnabledConnectorDestroyedWithChangedMinorVersionReturnsValidServerConnector`
   (`:1091-1134`) and `ConstructDuplicateAfterEnabledConnectorDestroyedReturnsValidServerConnector`
   (`:986-1019`) destroy the enabled connector and then only *construct* a disabled replacement,
   asserting `has_value()`/non-null. Neither calls `Disabled_server_connector::enable()` on the
   replacement, so neither can observe whether `Service_record::m_server` was actually reset. If that
   reset `Final_action` were dropped, both tests would still pass, yet the next `enable()` would hit
   `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)` (`runtime_impl.cpp:369`) and terminate.
3. **CE-3 (coverage counterexample): the destruction-isolation cases never enable, so they export
   only `std::set` behaviour.** `DestroyingOneMajorSlotKeepsOtherMajorSlotOccupied` (`:1141-1191`),
   `DestroyingOneInstanceSlotKeepsOtherInstanceSlotOccupied` (`:1197-1245`) and
   `DestroyingOneServiceIdSlotKeepsOtherServiceIdSlotOccupied` (`:1253-1304`) keep every connector
   disabled; they never create a `Service_record`, never call `register_server_connector`, and say
   nothing about record-level isolation.
4. **CE-4 (latent ordering hazard): the key-erase member is destroyed before the server
   registration.** `Impl` declares `Registration m_registration;` (`server_connector_impl.hpp:162`)
   before `Final_action m_final_action;` (`:163`); members are destroyed in reverse order, so the
   key-erase `m_final_action` is destroyed **before** `m_registration`. Today `~Impl(){ disable(); }`
   (`server_connector_impl.cpp:53`) resets `m_registration` in the destructor body first, so the
   observed order is server-unregister then key-erase — correct. The correctness depends on
   `disable()` always running first; the declaration order does not express it.
5. **CE-5 (resource lifetime, uncovered): `Service_database` records are never erased.**
   `Service_database::get_record` (`runtime_impl.cpp:313-324`) only ever `emplace`s; nothing erases
   `m_service_records` or its inner `Service_instances`. Destroying a connector resets `m_server` but
   leaves the record alive for the runtime's lifetime, so enabling/destroying many distinct
   identities grows the database monotonically. No drafted lifetime test asserts record cleanup.
6. **CE-6 (measurement scope/staleness): no retained artifact executes the runtime suite.**
   The newest host check is `check_conversion_tests` (`mode: ubsan`, `check-result` = `0`), and its
   compile command names only `service_identifier.cpp`, `string_registry.cpp`,
   `service_identifier_tests.cpp` plus googletest (§3.3). It compiles/executes **91**
   `ServiceInstanceIdentifierTest` cases (candidate 91/0; baseline 91/33) and **never**
   `runtime_tests.cpp`. The `native_tests` obligation leg runs
   `bazel test //... --build_tests_only` (exit 0), i.e. it **builds** the test targets but does not
   run them, in a captured workspace outside this checkout.
7. **CE-7 (inherited invalidation hazard): the key element type holds non-owning views, and the
   `Literal_tag` registry path does not copy.** `Service_instance_identifier` stores
   `Registry_string_view`s (`service_identifier.hpp:29-32`) whose lifetime contract is explicit
   ("It is the programmer's responsibility to ensure that Registry_string_view does not outlive the
   String_registry", `registry_string_view.hpp:29-30`). `String_registry::insert(std::string_view,
   Literal_tag)` (`string_registry.cpp:21-29`) inserts the caller's view **without copying**, so
   constructing a key component with `Literal_tag` from non-static storage leaves the key (and the
   `Service_record` index) holding a dangling view. The drafted tests use `Literal_tag{}` only with
   string literals and use the interning overloads for dynamic text (§5.3), so the hazard is not
   exercised, but the key type itself has no defense.

Overall verdict: the duplicate-refusal expectations are correct strict-weak-ordering consequences of
`service_identifier.cpp:28-29`, and the per-key-erase expectations are correct consequences of
`runtime_impl.cpp:456-463` + `std::set::erase`. **No drafted runtime case has been executed in this
checkout**, and the one concrete *defect* found (CE-1) is a lifetime inconsistency, not a
registration-key identity error.

---

## 1. Binding: issue, baseline, candidate set, prior reports, artifacts

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` | `.llm_tmp/context/issue-snapshot.json:2-4` |
| Title | *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:3` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` | `.llm_tmp/context/issue-snapshot.json:19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**: it distinguishes service-instance identifier `service id + major + minor + instance id`,
service identifier `service id + major`, and FindService `service id + major + optional<minor> +
optional<instance>`, and proposes excluding the minor version from identity. The snapshot records no
comment and no acceptance, so none of it is binding.

### 1.2 Verified baseline and current tree

| Item | Value | Source |
|------|-------|--------|
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |
| Current branch | `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ` | run environment |
| Latest recorded commit | `20199c3` | run environment |

Binding is **by baseline commit**, not by run HEAD. The candidate set is bound to the baseline via
`candidate-files.json` (baseline git blobs) and the `files` array of `source-manifest.json`.

### 1.3 In-scope candidate files

From `.llm_tmp/context/candidate-files.json:1-25`:

| File (repo-relative) | Baseline git blob | Baseline present | This iteration |
|----------------------|-------------------|------------------|----------------|
| `score/socom/BUILD` | `3477ea0851fdcd82ec6ea9d71424013cbdf41962` | yes | inspected; unchanged |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e22355242009fe20dada2a9a0d0c7a9c7` | yes | verified: `minor` excluded (`:28-29`) |
| `score/socom/impl/service_identifier.hpp` | `c8bae7908da9f087c518934f7b9f8d86db9a20ec` | yes | verified: brace-balanced, `:39` blank (§4.1) |
| `score/socom/test/unit/BUILD` | `3c03a7b14286051f97fa5022206564bd63645171` | yes | inspected; unchanged |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab726db8bf994c960045d6fd7fdf84d7395` | yes | 31 `TEST_F` + 1 `TEST` + 1 `TEST_P`; lifetime cases present (§5) |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(none — `null`)* | **no** (manifest expects a new file) | 91 `TEST_F` present (§5.4) |

The `null` baseline blob for `service_identifier_tests.cpp` is the manifest's expectation of a
**new** unit-test file; it exists on disk only in the un-merged working tree (the task's "cancelled
draft"). `glob **/service_identifier.hpp` returns exactly one path.

### 1.4 Prior reports read and preserved

Read (not modified) this iteration:

- `.llm_tmp/overnight/reports/` — `key_fix.md`, `lifetime_tests.md`, `scope.md` (the earlier nodes
  of this run that bear on the key and its lifetime), plus the other files listed by `glob`.
- `.llm_tmp/overnight/prior-reports/` — `lifetime_review.md` (the prior-run lifetime review whose
  CE-1…CE-6 this document re-verifies and carries forward), `lifetime_tests.md`, `invariants.md`,
  `key_fix.md`, `runtime_disabled.md`, `runtime_enabled.md`, `callsites.md`, `compatibility.md`,
  `source`-level evidence as cited. All 39 files are preserved.

Derived sequence across the preserved reports: `scope` → `invariants` (I-4 baseline key included
`minor`; I-9 record index ignores `minor`; I-11 the resulting gap) → `callsites` → `reproducer`
(header brace correction) → `key_fix` (drop `minor`) → `ordering_tests` →
`runtime_disabled`/`runtime_enabled`/`lifetime_tests` → the earlier `lifetime_review` → conversion /
metadata / repair reports.

### 1.5 Host validation feedback and obligation-collection results (present in this checkout)

Host validation under `.llm_tmp/overnight/validation/` is present (16 files). The latest check is
**`check_conversion_tests`**:

| Artifact | Content |
|----------|---------|
| `measurement.json` head | `check_ref: "check_conversion_tests"`, `status: "completed"`, `mode: "ubsan"`, `changed_paths: ["score/socom/test/unit/service_identifier_tests.cpp"]` (`:1-7`) |
| `check-result` | `0` |
| `after.json` | `tests: 91`, `failures: 0`, single suite `ServiceInstanceIdentifierTest` (`:1-8`) |
| `before.json` | `tests: 91`, `failures: 33`, same single suite (`:1-8`) |
| `after-compile.command.json` | `g++-12 -std=c++17 -Wall -Wextra -Werror -pthread … -fsanitize=undefined -fno-sanitize-recover=all` over **only** `score/socom/impl/service_identifier.cpp`, `score/socom/impl/string_registry.cpp`, `score/socom/test/unit/service_identifier_tests.cpp` plus googletest; `exit_code: 0` |
| `measurement.json` tail | `origin: "local_unprotected_measurement"`, `initiator: "Fabro host hook"`, `engineering_acceptance: "pending"`, `full_native_tests: "not_executed"`, compiler `/usr/bin/x86_64-linux-gnu-g++-12`; `baseline_with_agent_tests {compile_exit 0, test_exit 1, tests 91, failures 33}`, `candidate {compile_exit 0, test_exit 0, tests 91, failures 0, disabled 0}`; UBSan enabled with `-fno-sanitize-recover=all` |

**Scope caveat — decisive.** The compile/run command names only the focused identifier translation
unit (`service_identifier.cpp` + `string_registry.cpp` + `service_identifier_tests.cpp` + gtest). It
does **not** compile `runtime_tests.cpp` and does **not** build or run the Bazel `socom_test` /
`//score/...` targets. The 91 tests are all `ServiceInstanceIdentifierTest`; the `RuntimeTest` suite
does not appear. Therefore **every runtime lifetime case reviewed here remains natively
unmeasured**, and the artifact is explicitly `local_unprotected_measurement` with
`engineering_acceptance: pending` and `full_native_tests: not_executed`.

Obligation-collection results under `.llm_tmp/overnight/obligations/` are present (25 `result.json`
files). **Per the task rule, a retained collection result means results were retained, not that
checks passed.** Observed `status` values:

| status | checks |
|--------|--------|
| `completed` | `native_build`, `native_tests`, `native_coverage`, `native_tsan`, `native_sanitizers`, `focused_coverage`, `focused_asan_lsan`, `focused_memcheck`, `compiler_diagnostics`, `rework_progress` |
| `completed_with_blockers` | `tool_assurance`, `cross_compilation`, `process_checks` |
| `findings_or_execution_failure` | `native_integration`, `native_lint`, `focused_cppcheck`, `format_precommit`, `codeql_security`, `focused_clang_tidy`, `native_traceability`, `codeql_misra`, `focused_tsan`, `native_performance`, `secret_dependency_checks`, `native_docs` |

Two scope facts matter and are read directly from the commands:

- `native_tests` runs `bazel --batch test --jobs=2 //... --build_tests_only` with `exit_code: 0`
  (`result.json:1053-1082`). `--build_tests_only` **builds** the test targets without running them,
  in the captured `native-workspace` (outside this checkout). It is therefore not a runtime-suite
  execution.
- `native_coverage`, `native_tsan`, `native_sanitizers`, `native_performance` likewise carry
  `--build_tests_only`. No collected leg runs `//score/socom/test/unit:socom_test`.

### 1.6 Pinned obligation sources and authority

All nine entries of `.llm_tmp/context/obligations/source-index.json` are present, each with
`"native_acceptance": "not_inferred"`:

| id | pinned path | repository |
|----|-------------|------------|
| `coding_guidelines` | `docs/contribute/development/cpp/coding_guidelines.rst` | `score` |
| `code_analysis` | `docs/contribute/development/cpp/code_analysis.rst` | `score` |
| `misra_mapping` | `docs/contribute/development/cpp/misra_2023_rule_mapping.rst` | `score` (draft) |
| `verification_plan` | `docs/platform_management_plan/software_verification.rst` | `score` |
| `development_plan` | `docs/platform_management_plan/software_development.rst` | `score` |
| `tool_management` | `docs/platform_management_plan/tool_management.rst` | `score` |
| `verification_process` | `process/process_areas/verification/guidance/verification_process_reqs.rst` | `process_description` |
| `verification_guideline` | `process/process_areas/verification/guidance/verification_guideline.rst` | `process_description` |
| `inspection_checklist` | `score/component_example/docs/detailed_design/chklst_impl_inspection.rst` | `module_template` (draft) |

**Authority record** (`.llm_tmp/context/obligations/authority.json:1-7`):
`engineering_acceptance: pending`, `human_reviews: unanswered`, `safety_class: unknown`,
`codeql_scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload"`, instruction
*"Restart the failed queue for one complete pass through all obligations"*.

**Safety-class note (recorded, not resolved).** The pinned platform documents carry `:safety: ASIL_B`
(per the prior reports' readings), while `authority.json` records `safety_class: unknown` and no
authorized selection exists. The document attribute is **not** a selection of the slice's safety
class and must not be inferred as one.

---

## 2. Scope of this review

This review covers exactly the three axes requested:

- **Invalidation** — when and how the registration key (and the record index it mirrors) releases or
  reuses an identity, and whether the stored identity handles stay valid.
- **Connector lifetime** — the ordering and ownership of `Runtime_impl`, the key
  (`m_service_identifiers`), the connector (`server_connector::Impl`), the `Service_record`
  registration, and the registries.
- **Slot reuse** — whether destroying a connector frees exactly its own `(instance, service id,
  major)` slot and nothing else, and whether the freed slot is reusable end-to-end.

Out of scope (unchanged from the bounded slice): the #84 public `Service_interface_identifier`
restructure, FindService wildcard handling, the config `0xFFFFFFFF` minor narrowing decision, and
client/server minor-compatibility semantics beyond what the key forces.

---

## 3. Binding to the host feedback (what is and is not measured)

### 3.1 What the latest check measures
`check_conversion_tests` compiled and ran the focused identifier TU under UBSan
(`-fsanitize=undefined -fno-sanitize-recover=all`) with `-Wall -Wextra -Werror`, exit 0; candidate 91
tests / 0 failures, baseline-with-agent-tests 91 / 33. This is real, local, scoped evidence for the
*identifier key* at the translation-unit level.

### 3.2 What it does not measure
It does not link `runtime_tests.cpp`, `server_connector_impl.cpp`, `runtime_impl.cpp`, or any of the
lifetime machinery. The 33 baseline failures are all `ServiceInstanceIdentifierTest` failures; no
`RuntimeTest` case appears in `after.json`/`before.json`.

### 3.3 Why this also refutes the recorded syntax failure
Both `service_identifier.cpp` (which `#include "service_identifier.hpp"`, `:14`) and
`service_identifier_tests.cpp` (which includes `score/socom/impl/service_identifier.hpp`, `:26`) are
compiled by `after-compile.command.json` with `exit_code: 0` and empty stderr. A translation unit
that transitively includes `impl/service_identifier.hpp` **with an extra closing brace** cannot
compile under `-Wall -Wextra -Werror`. The recorded "measured GCC syntax failure" therefore does not
describe this checkout's header.

---

## 4. Source lifetime model (actual-source inspection)

All line references are direct readings of this working tree.

### 4.1 The flagged header is brace-balanced

`score/socom/impl/service_identifier.hpp` is 40 lines. A `grep` for `[{}]` returns exactly four
lines:

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`) and two closers (`:32`, `:38`): net balance `0`. There is **no third,
unmatched closing brace**, and line 39 contains no text at all. The task's "extra closing brace at
line 39" is a stale, pre-correction description here.

### 4.2 Key type, identity and where the key lives

- **Key type.** `Service_instance_identifier{ Service_interface_identifier interface; Service_instance
  instance; }` with only an out-of-line `operator<` declaration
  (`impl/service_identifier.hpp:29-35`); no `operator==`, no hash. Its members are
  `Registry_string_view`s.
- **Key identity.** `operator<` orders by `(instance, service id, major)` and deliberately excludes
  `minor`:
  ```cpp
  return std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major) <
         std::tie(rhs.instance, rhs.interface.id, rhs.interface.version.major);
  ```
  (`impl/service_identifier.cpp:28-29`, comment `:21-27`). `std::set` equivalence is `!(a<b) &&
  !(b<a)`, i.e. exactly `(instance, id, major)` — deliberately as coarse as the record index.
- **Where the key lives.** `using Service_identifiers =
  Mutexed_variable<std::set<Service_instance_identifier>>` (`impl/runtime_impl.hpp:56`), held as
  `std::shared_ptr<Service_identifiers> m_service_identifiers` (`:228-229`) owned solely by
  `Runtime_impl`.
- **Key insertion.** `Runtime_impl::make_server_connector` builds
  `Service_instance_identifier const identifier{configuration.get_interface(), instance}`
  (`runtime_impl.cpp:443`), checks callbacks (`:445-447`), then under the key mutex inserts and
  returns `duplicate_service` when `insert(...).second` is false (`:449-454`; insert `:451`, error
  `:452`). Validity is checked **before** insertion, so a `callback_missing` return does not leak a
  key.
- **Key erase (invalidation).** Only the `Final_action` installed at `runtime_impl.cpp:456-463`
  erases the key. It captures `identifier` by value and a `weak_ptr` to the set; if the runtime is
  gone, `identifiers.lock()` is empty and the erase is skipped. `Final_action`'s move resets the
  moved-from functor and its destructor executes the stored functor exactly once
  (`final_action.hpp:41-44`, `:53`, `:58-67`), so moving it into `SC_impl` neither fires early nor
  double-fires.

### 4.3 Minimal historical repair (reference only; NOT applied)

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

Applying it to the already-balanced file would be a no-op; deleting a brace to "fix" the file would
*create* the reported defect. The write boundary of this review forbids any source edit in any case.

### 4.4 Connector lifetime

- **Connector.** `server_connector::Impl` owns the key-erasing `Final_action`
  (`server_connector_impl.hpp:163`) and the server registration `Registration m_registration;`
  (`:162`), plus the runtime as an alias: `Runtime_impl& m_runtime` (`:146`). The constructor stores
  both (`server_connector_impl.cpp:36-51`).
- **Enable / disable type transfer.** `Disabled_server_connector::enable` /
  `Enabled_server_connector::disable` transfer the *same* `Impl` object between the two `unique_ptr`
  types without running a deleter (`server_connector_impl.cpp:365-389`), so the key persists across
  the enabled/disabled transition and is released only on destruction.
- **Destruction.** `Impl::~Impl() noexcept { disable(); }` (`server_connector_impl.cpp:53`).
  `disable()` resets `m_registration` (`:80-114`), which runs the registration's `Final_action`
  (server unregister), then member destruction runs `m_final_action` (key erase). The destructor body
  runs before member destructors, so today the order is server-unregister then key-erase.
- **Server registration lifecycle (separate from the key).** On first `enable()`, `Impl::enable`
  (`server_connector_impl.cpp:55-78`) calls `m_runtime.register_connector(...)` (`:72`), which
  obtains the record via `Service_database::get_record` (`runtime_impl.cpp:526-531`) and calls
  `Service_record::register_server_connector` (`:366-382`), which asserts
  `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)` (`:369`), sets `m_server` (`:371`), and returns a
  `Registration` whose `Final_action` captures `this` (the `Service_record`) and resets `m_server`
  under `m_runtime_mutex` (`:372-377`).
- **Records are permanent.** `Service_database::get_record` (`runtime_impl.cpp:313-324`) only ever
  `emplace`s. Record identity is `id + major + instance`, ignoring `minor`, via
  `Minor_version_ignoring_key_equal`/`_hash` (`impl/runtime_impl.hpp:116-134`), matching the key's
  component set.

### 4.5 Registries and view validity

- `String_registry::insert(std::string_view)` and `insert(std::string&&)` intern by content into
  `m_dynamic_allocated` (a `std::forward_list<std::string>`), whose references are stable
  (`string_registry.cpp:31-63`; `string_registry.hpp:75-76`). Thus a view obtained from those
  overloads stays valid for the registry's lifetime.
- `String_registry::insert(std::string_view, Literal_tag)` inserts the caller's view **directly**
  without copying (`string_registry.cpp:21-29`); it is only safe for static string literals.
- `Registry_string_view::operator==` compares pointer + length (`registry_string_view.hpp:127-129`)
  and `std::hash` hashes the pointer (`:186-193`), while `operator<` compares **content**
  (`:141-143`). The key's `std::set` is content-ordered; the `Service_database` `unordered_map` is
  pointer-equal. These coincide only because the registries intern by content; the invariant "same
  `Service_record` ⇒ same gate key" holds, so the gate is at least as coarse as the index.

---

## 5. Concrete counterexamples

### 5.1 CE-1 — an enabled connector that outlives its `Runtime` is a use-after-free

**Mechanism.** `Runtime::make_server_connector` passes `*this` (`Runtime_impl&`) into `SC_impl`
(`runtime_impl.cpp:465`). Enabling calls `Runtime_impl::register_connector`, which obtains a
`Service_record&` inside `Runtime_impl::m_database` and installs a `Final_action` that captures that
record by raw `this` and resets its `m_server` under `Service_record::m_runtime_mutex`, itself a
reference to `Runtime_impl::m_runtime_mutex` (`runtime_impl.cpp:372-377`, `:64-65`). The connector
keeps this `Registration` in `m_registration` until disable/destruction. The key-erasing
`m_final_action` has a `weak_ptr` guard; the server-registration `Final_action` does **not**.

**Concrete counterexample** (same shape as the drafted `ConnectorDestroyedAfterRuntimeDoesNotCrash`,
which only covers the disabled case, `runtime_tests.cpp:1021-1028`):

```cpp
Enabled_server_connector::Uptr enabled{nullptr};
{
    Connector_factory factory{connector_factory};   // copy ctor creates a fresh Runtime (connector_factory.cpp:39-42)
    Server_connector_callbacks_mock callbacks;
    auto disabled = factory.create_server_connector(callbacks);
    enabled = Disabled_server_connector::enable(std::move(disabled));   // m_registration is now set
}   // factory (and its Runtime_impl + Service_database) destroyed here; `enabled` still alive
enabled.reset();
// ~Impl() -> disable() -> m_registration.reset()
//   -> Server_registration Final_action: lock_guard{m_runtime_mutex}; m_server.reset();
//      on storage owned by the destroyed Runtime_impl  ==> use-after-free
```

The key's `weak_ptr` design (`runtime_impl.cpp:456-463`) protects only the *key erase*; the server
registration has no such guard, so the runtime-outlives-connector support is **inconsistent**. No
drafted case exercises the enabled state here. This is a static consequence of the cited
registrations; it has **not** been executed here.

### 5.2 CE-2 — the "enabled slot reuse" cases never re-enable the replacement

`ConstructDuplicateAfterEnabledConnectorDestroyedWithChangedMinorVersionReturnsValidServerConnector`
(`runtime_tests.cpp:1091-1134`) enables first (minor 2); refuses duplicate minor 3; destroys first;
constructs a minor-3 replacement and asserts only `has_value()` / non-null (`:1129-1133`). It stops
before enabling the replacement. `ConstructDuplicateAfterEnabledConnectorDestroyedReturnsValidServerConnector`
(`:986-1019`) has the same gap (`:1015-1018`). Consequently the tests cannot detect a missing or
broken server-reset `Final_action` in `Service_record::register_server_connector`
(`runtime_impl.cpp:372-377`): if that reset were dropped, the replacement would still be constructed
(the gate sees the freed key) but the subsequent `enable()` would hit `ASSERT(!m_server)`
(`runtime_impl.cpp:369`) and terminate. The "slot reuse" claim is verified at the key-set level only.

### 5.3 CE-3 — the destruction-isolation cases never enable, so they export only `std::set` behaviour

`DestroyingOneMajorSlotKeepsOtherMajorSlotOccupied` (`:1141-1191`),
`DestroyingOneInstanceSlotKeepsOtherInstanceSlotOccupied` (`:1197-1245`), and
`DestroyingOneServiceIdSlotKeepsOtherServiceIdSlotOccupied` (`:1253-1304`) keep every connector
disabled and only probe `make_server_connector` return values. They confirm that the `std::set::erase`
(`runtime_impl.cpp:461`) is per-key — useful — but they never create a `Service_record`, never call
`register_server_connector`, and never exercise the `m_server`/`m_client` state machine. A defect in
record-level destruction isolation would not be caught.

### 5.4 CE-4 — key-erase member destroyed before the server registration (latent ordering hazard)

`Impl` declares `Registration m_registration;` (`server_connector_impl.hpp:162`) before
`Final_action m_final_action;` (`:163`); member destruction is reverse-declaration order, so
`m_final_action` (key erase) is destroyed **before** `m_registration`. The destructor body
`~Impl(){ disable(); }` (`server_connector_impl.cpp:53`) resets `m_registration` first, so the
required order (server unregister, then key erase) currently holds. But the correctness depends on
`disable()` always resetting `m_registration` before member destruction; the declaration order does
not express it. A future refactor that leaves `m_registration` non-null at member-destruction time
would free the key while `Service_record::m_server` is still set; a new connector for the same
`(instance, id, major)` would pass the gate and then violate `ASSERT(!m_server)` on enable.
Recommended hardening: declare `m_final_action` **before** `m_registration`, or express the intended
erase ordering explicitly.

### 5.5 CE-5 — `Service_database` records are never erased (resource lifetime)

`Service_database::get_record` (`runtime_impl.cpp:313-324`) `emplace`s an entry for every
`(id + major, instance)` it is asked about (server enable, or client construction) and no path erases
`m_service_records` or its inner `Service_instances`. Destroying a connector resets `m_server` but
the record persists for the runtime's life. Concrete consequence: create/enable/destroy `N` distinct
identities and `m_service_records` holds `N` records afterwards. No drafted lifetime test asserts
record cleanup, and no retained measurement exercises the runtime database.

### 5.6 CE-6 — measurement coverage: the runtime suite is not executed anywhere in this checkout

See §1.5 and §3. Every retained code-measuring artifact compiles the focused identifier TU only.
`native_tests` compiles the `//...` test targets with `--build_tests_only` (exit 0) in a captured
workspace outside this checkout and does not run them; `native_coverage`, `native_tsan`,
`native_sanitizers`, `native_performance` also carry `--build_tests_only`. The identifier
measurement itself is current (91 tests) but says nothing about `runtime_tests.cpp`. A green
`check-result` is therefore **not** evidence for any lifetime case in this review.

### 5.7 CE-7 — inherited invalidation hazard: non-owning key views and the non-copying `Literal_tag` path

`Service_instance_identifier` stores `Registry_string_view`s (`service_identifier.hpp:29-32`) whose
contract is explicit: the view must not outlive the registry (`registry_string_view.hpp:29-30`).
`String_registry::insert(std::string_view, Literal_tag)` inserts the caller's view **without
copying** (`string_registry.cpp:21-29`), so a key component built with `Literal_tag` from non-static
storage dangles once that storage dies. Concrete shape:

```cpp
std::string name = "Dyn";
// WRONG use of the static-literal tag: the registry stores a view into `name`, not a copy.
Service_instance si{std::string_view{name}, Literal_tag{}};
// Any key / record built from `si` after `name` dies holds a dangling view.
```

This is an API-contract hazard inherited by the registration key and the `Service_record` index, not
a defect introduced by the #84 correction. The drafted identifier tests are safe on this axis: they
use `Literal_tag{}` only with string literals and use the interning overloads
(`insert(std::string_view)` / `insert(std::string&&)`) for dynamic text
(`service_identifier_tests.cpp:1982-2039`, `:2150-2209`; `string_registry.cpp:31-63`). It is recorded
because it is the one *invalidation* failure mode that would silently corrupt the key's ordering, and
no drafted runtime case exercises the registries' lifetime at all.

Related lower-severity hazard: the process-global registries are function-local statics
(`string_registry.cpp:65-73`) destroyed at exit. A global `Runtime` or global connector destroyed
during static destruction could run the key's `erase` comparator on views whose registry is already
gone. No drafted case or global object exercises this, but it is the same non-owning-view contract.

---

## 6. Verdict on the drafted runtime cases

Line references are direct readings of `runtime_tests.cpp` in this checkout (31 `TEST_F` at
`:279, :287, :295, :303, :311, :334, :350, :371, :402, :440, :471, :505, :538, :573, :607, :642,
:694, :726, :763, :796, :832, :869, :905, :951, :986, :1021, :1045, :1091, :1141, :1197, :1253`,
plus `TEST(RuntimeFactoryTest, DefaultConstructorWorks)` at `:239` and
`TEST_P(RuntimeBridgeTest, CreationOfClientsWillCallRequestServiceFunction)` at `:1311` /
`INSTANTIATE_TEST_SUITE_P` at `:1323`).

| Case | Claim | Verdict |
|------|-------|---------|
| `ConstructDuplicateReturnsDuplicateServiceError` `:334` | same-config duplicate refused (disabled) | sound on corrected key; key-set only |
| `ConstructDuplicateMultipleTimesReturnsDuplicateServiceError` `:350` | repeated duplicates refused | sound; key-set only |
| `CreatingServerConnectorDeletingItAndRecreatingReturnsValidServerConnector` `:371` | same-config reuse (disabled) | sound; key-set only, never enables |
| `ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError` `:402` | minor-only duplicate refused (disabled) | sound, focused; key-set only |
| `ConstructDuplicateSameConfigurationWhileBothConnectorsDisabled…` `:440` | duplicate refused, both disabled | sound; key-set only |
| `ConstructDifferentMajor…Disabled…` `:471` | different major coexists | sound; key-set only |
| `ConstructDifferentInstance…Disabled…` `:505` | different instance coexists | sound; key-set only |
| `ConstructDifferentServiceId…Disabled…` `:538` | different service id coexists | sound; key-set only |
| `ConstructDuplicateMinorBoundaries…Disabled…` `:573` | minor 0/65535 collapse | sound; key-set only |
| `ConstructDuplicateWithSmallerMinor…Disabled…` `:607` | smaller minor still duplicate | sound; key-set only |
| `ConstructDuplicateRepeatedly…Disabled…KeepsSlotHeld` `:642` | slot held while disabled | sound; key-set only |
| `ConstructDuplicateWhileFirstConnectorEnabled…` `:694` | enabled connector holds the key | sound; replacement not built |
| `ConstructDuplicateDifferingOnlyInMinorVersionWhileFirstConnectorEnabled…` `:726` | minor-only duplicate refused while enabled | sound, focused |
| `ConstructDifferentInstanceWhileFirstConnectorEnabled…` `:763` | enabled instance-A does not block instance-B | sound; different records by construction |
| `ConstructDifferentServiceIdWhileFirstConnectorEnabled…` `:796` | enabled service-id-A does not block B | sound; different records |
| `ConstructDuplicateMinorBoundariesWhileFirstConnectorEnabled…` `:832` | minor boundaries collide while enabled | sound |
| `ConstructDuplicateWithSmallerMinorWhileFirstConnectorEnabled…` `:869` | smaller minor still duplicate while enabled | sound |
| `ConstructDuplicateRepeatedlyWhileFirstConnectorEnabledKeepsSlotHeld` `:905` | slot held while enabled | sound |
| `ConstructDifferentMajorWhileFirstConnectorEnabled…` `:951` | enabled major-1 does not block major-2 | sound; different records |
| `ConstructDuplicateAfterEnabledConnectorDestroyedReturnsValidServerConnector` `:986` | enabled destroy frees the key | **limited — CE-2** |
| `ConnectorDestroyedAfterRuntimeDoesNotCrash` `:1021` | `weak_ptr` no-op after runtime destruction | **limited — CE-1** (disabled only) |
| `ConstructDuplicateAfterDisabledConnectorDestroyedWithChangedMinorVersion…` `:1045` | disabled destroy frees the key, changed minor reusable | sound; key-set only (never enables) |
| `ConstructDuplicateAfterEnabledConnectorDestroyedWithChangedMinorVersion…` `:1091` | enabled destroy frees the key, changed minor reusable | **limited — CE-2** (never re-enables) |
| `DestroyingOneMajorSlotKeepsOtherMajorSlotOccupied` `:1141` | per-key erase isolation (major) | **limited — CE-3** (never enables) |
| `DestroyingOneInstanceSlotKeepsOtherInstanceSlotOccupied` `:1197` | per-key erase isolation (instance) | **limited — CE-3** |
| `DestroyingOneServiceIdSlotKeepsOtherServiceIdSlotOccupied` `:1253` | per-key erase isolation (service id) | **limited — CE-3** |

Every duplicate expectation is written as a value comparison against the genuine error result
`score::MakeUnexpected(Construction_error::duplicate_service)` (e.g. `:428-430`, `:1064-1077`,
`:1110-1126`), not a bare boolean assertion. Overall: the duplicate-refusal expectations are correct
strict-weak-ordering consequences of `service_identifier.cpp:28-29`; the per-key erase expectations
are correct consequences of `runtime_impl.cpp:456-463` + `std::set::erase`. The limitations are that
no case observes the `Service_record` server state after reuse (CE-2/CE-3), and the
runtime-outlives-connector case does not cover the enabled state (CE-1). **None of these cases has
been compiled or executed in this checkout** (CE-6). The identifier suite
`service_identifier_tests.cpp` has **91 `TEST_F`** under `ServiceInstanceIdentifierTest`
(`:168`…`:2181`, verified by `grep`), and it **is** the file measured by `check_conversion_tests`
(91/0 candidate; 91/33 baseline).

---

## 7. Obligations status (none satisfied)

### 7.1 Pinned state

All nine pinned sources in `.llm_tmp/context/obligations/` were read this iteration (§1.6); every
`source-index.json` entry is `"native_acceptance": "not_inferred"`. `authority.json` records
`engineering_acceptance: pending`, `human_reviews: unanswered`, `safety_class: unknown`,
`codeql_scope` no upload, and the instruction to restart the failed obligation queue.

### 7.2 Status for this slice (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Freedom from compiler warnings & errors (100 %) | `verification_plan.rst` (quality criterion 9) | **PARTIALLY MEASURED (scoped)** — the focused identifier TU compiled with `g++-12 … -Werror` (UBSan), exit 0, both legs; `runtime_tests.cpp` and the full `socom_test`/`//score/...` targets are **not compiled/run by any artifact that runs tests**; `native_tests` only *built* `//...` (`--build_tests_only`) in an external workspace |
| Static code analysis (clang-tidy / CodeQL), findings classified | `code_analysis.rst`; `verification_process.rst` (`gd_req__verification_sca_classification`) | **NOT SATISFIED** — `focused_clang_tidy`, `codeql_security`, `codeql_misra`, `native_lint` are `findings_or_execution_failure`; MISRA mapping is draft; no authorized classification |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` (`:status: draft`) | **UNKNOWN** — mapping is draft; not applied |
| Structural statement / branch coverage goals | `verification_plan.rst` (criteria 1-2) | **NOT MEASURED for the slice** — `focused_coverage` status `completed` but scoped to the identifier TU (`complete_target_scope: false` per prior readings); `native_coverage` only built tests |
| Unit/component testing executed, results recorded | `verification_plan.rst` (criteria 6-7); `verification_guideline.rst` | **PARTIAL, SCOPED** — 91 identifier tests 0 failures / 33 baseline failures (candidate/baseline) in this checkout; `runtime_tests.cpp` (33 macros) not executed |
| Interface / requirements-based / resource / fault-injection test types | `verification_process.rst`; `verification_plan.rst` | **NOT PERFORMED / applicability not inferred** — no harness; identifier/registration-key tests are not platform validation |
| Boundary / equivalence derivation | `verification_process.rst` | **SOURCE-ONLY for the lifetime/key cases here** (the identifier boundary cases *were* executed by `check_conversion_tests`) |
| Fuzzy testing technique | `verification_plan.rst` | **NOT EXECUTED / NOT CLAIMED** — no harness and no measurement |
| Linking tests to requirements (record properties) | `verification_process.rst` (`gd_req__verification_link_tests_cpp`) | **PARTIAL / NOT DONE** — `DerivationTechnique`/`Description` recorded (`service_identifier_tests.cpp:42-65`; `runtime_tests.cpp:264-267`); `TestType` and `Verifies` deliberately unset (no invented identifiers) |
| External-component AoUs verified | `verification_process.rst` (`gd_req__verification_external_aou`) | **NOT SATISFIED** — no integration/static verdict; no AoU register |
| Independence of verification / review by a different committer | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Implementation inspection checklist IMPL_01…IMPL_03 | `inspection_checklist.rst` (`:status: draft`) | **NOT FILLED** — draft template |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** for the slice; `tool_assurance` is `completed_with_blockers` |
| Obligation collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **RETAINED, NOT PASSED** — 25 results present; 12 are `findings_or_execution_failure`, 3 `completed_with_blockers`; retention ≠ passing |
| Native acceptance | `source-index.json` | **`not_inferred` for every entry** |

**Explicit non-satisfaction statement.** Missing runtime measurements, missing/blocked tools
(the `findings_or_execution_failure` set), the unknown safety class and un-inferred applicability,
the incomplete extraction of host artifacts (no leg runs `socom_test`), and the unanswered human
reviews mean **none of the checked obligations may be treated as satisfied**. A retained collection
node proves *retention*, not passing; the green focused `check_conversion_tests` helps criterion 9 at
the identifier-TU scope only and is **not** evidence that the runtime lifetime cases, the full suite,
or any other obligation passed.

---

## 8. Measurement and validation status

- **Tools:** `read_file`, `grep`, `glob`, `write_file` only. No `shell`, delegation, web, approval,
  publishing, engineering acceptance, or `edit_file`.
- **Executed measurements by this iteration:** **none.** No build, no `bazel test`, no runtime. The
  brace census (§4.1), the lifetime model (§4) and the counterexamples (§5) are static readings or
  explicitly-labelled logical consequences.
- **Retained host artifacts (read, not produced here):** `check_conversion_tests` (mode `ubsan`,
  `check-result` 0, candidate 91/0, baseline 91/33, focused identifier TU) and the 25 obligation
  results (§1.5). None runs `runtime_tests.cpp`; several are `findings_or_execution_failure`.
- **Test inventory (read, not run):** `runtime_tests.cpp` = 31 `TEST_F` + 1 `TEST` + 1 `TEST_P`;
  `service_identifier_tests.cpp` = 91 `TEST_F` (`:168`…`:2181`).
- **Reproduction path for a later, permitted iteration (not executed here):**
  ```bash
  bazel test //score/socom/test/unit:socom_test
  bazel test //score/socom/test/unit:socom_test --test_filter='ServiceInstanceIdentifierTest.*'
  bazel test //score/socom/test/unit:socom_test --test_filter='RuntimeTest.*'
  # targeted lifetime cases:
  bazel test //score/socom/test/unit:socom_test \
      --test_filter='RuntimeTest.ConnectorDestroyedAfterRuntimeDoesNotCrash'
  bazel test //score/socom/test/unit:socom_test \
      --test_filter='RuntimeTest.ConstructDuplicateAfterEnabledConnectorDestroyedWithChangedMinorVersionReturnsValidServerConnector'
  # plus an enabled-outlives-runtime case (CE-1) and re-enable-after-reuse cases (CE-2/CE-3)
  ```
  Expected on the corrected key: duplicates are refused with `Construction_error::duplicate_service`
  and a freed slot can be registered again. These expectations are source-derived, not measured.
- **Scope:** local, unprotected, scoped. Full native runtime tests and human review remain pending.

---

## 9. Notice preservation

- No source, build, test, config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was created, edited, or
  deleted by this iteration; only this report was written.
- All six candidate files retain their Apache-2.0 / SPDX headers (`service_identifier.hpp` and
  `service_identifier.cpp` carry the 2025 copyright; `service_identifier_tests.cpp` carries the 2025
  header; `runtime_tests.cpp`, `score/socom/BUILD`, and `score/socom/test/unit/BUILD` likewise
  retain theirs). This report carries the Apache-2.0 header.
- The header flagged by the task (`score/socom/impl/service_identifier.hpp`) was inspected and left
  unchanged because it is already brace-balanced and otherwise well-formed (§4.1).
- Every prior report under `.llm_tmp/overnight/prior-reports/` and every pre-existing
  `.llm_tmp/overnight/reports/*` file was preserved (including the prior-run
  `prior-reports/lifetime_review.md`, which is a different run's document and was **not**
  overwritten).
- The duplicate key remains an `impl/`-only type; the `testonly`
  `//score/socom:impl_service_identifier` library exposes it to `//score/socom/test/unit` only, so no
  public header or notice surface changed. No licensed MISRA rule text is reproduced.

---

## 10. Pending human review checklist

- [ ] **Resolve the premise discrepancy:** the "extra closing brace at line 39" does not exist in
      this checkout (line 39 is blank; the header is balanced; §4.1) and the retained focused compile
      of the header's includers exits 0. Confirm no source edit is required, or point to the actual
      "cancelled draft" revision if it is a different artifact.
- [ ] **Adjudicate CE-1 (blocking):** decide whether an enabled connector may outlive its `Runtime`.
      If yes, the server-registration `Final_action` needs the same lifetime protection as the key's
      `weak_ptr` (or the runtime must own/join connectors); if no, the contract and the drafted
      "does not crash" test name/claim must be corrected to state "disabled only".
- [ ] **Adjudicate CE-2 / CE-3:** confirm whether the drafted "slot reuse"/"isolation" cases must
      re-enable the replacement (thereby exercising `Service_record::m_server` reset and
      `ASSERT(!m_server)`), and add those cases if so.
- [ ] **Adjudicate CE-4:** declare `m_final_action` before `m_registration` (or otherwise express the
      intended erase ordering) to remove the latent ordering hazard.
- [ ] **Adjudicate CE-5:** decide whether permanent `Service_database` records are acceptable or
      whether record cleanup is required; if required, add a lifetime test.
- [ ] **Adjudicate CE-7:** decide whether the non-copying `Literal_tag` path and the non-owning key
      views need a guard (e.g. assert/reject dynamic strings in the literal overload), and refresh
      the `Registry_string_view` lifetime contract in the key documentation.
- [ ] **Refresh the measurements:** run `bazel test //score/socom/test/unit:socom_test` (and the
      broader `//score/...` set) so `runtime_tests.cpp` is actually compiled and executed; do not
      re-report the focused identifier artifact (`check_conversion_tests`, 91 tests) as coverage of
      the runtime suite.
- [ ] **Do not treat the retained obligation results as passing** (§1.5, §7): 12 are
      `findings_or_execution_failure` and 3 `completed_with_blockers`.
- [ ] **Keep the #84 public `Service_interface_identifier` restructure**, FindService wildcard
      handling, and the config minor-wildcard narrowing out of this bounded slice until separately
      accepted; do not present identifier/registration-key tests as platform validation or claim an
      unmeasured fuzzy technique.
- [ ] **Supply native requirement source IDs and traceability metadata** (no invented links), or
      record applicability as unresolved; resolve `engineering_acceptance: pending` and
      `human_reviews: unanswered`, and select a safety class via the authorized role (do not infer it
      from the `:safety: ASIL_B` attribute on the pinned documents).

---

*End of `lifetime_review` draft. Local, unprotected, scoped. No engineering acceptance; human reviews
unanswered; full native runtime tests pending. Every statement is a local reading of the working
tree, a retained host artifact present in this checkout, or an explicitly-labelled logical
consequence — none is acceptance, review approval, publication, or a full native run.*
