<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — bounded duplicate-server registration-key slice: scope binding (review draft)

**Document type:** review draft — scope binding of issue #84 to the verified baseline + actual-source
inspection + locally accepted draft scope + open design questions + obligations status.

**Date:** 2026-10-03
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** duplicate-server registration-key handling inside *Revise version handling in socom* (issue #84)
**Run / branch:** `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ`; HEAD `b7d55bb`
(`fabro(01M3ZRSDK2XQAF1H48VWTPKQNZ): start (success)`) — from the run environment.
**Verified baseline commit:** `f8a196c3b16d5172d898394ab99b0ed81346d63d`
(`.llm_tmp/context/source-manifest.json:3`).
**Status:** **local, unprotected, scoped.** No engineering acceptance exists. Human reviews are
unanswered. Full native runtime tests are pending. Nothing in this document is acceptance, review,
publication, or a full native run.

> **Tool / write boundary observed.** This iteration used only `read_file`, `grep`, `glob`, and
> `write_file`. No `shell`, no `edit_file`, no delegation, no web access, no approval, no publishing,
> and no engineering acceptance was performed. The task text contains a conflict: it says to
> *"Inspect and correct the actual source before expanding tests"*, while the explicit, more specific
> final sentence says *"This is a review draft: only that report may be written."* Following the
> explicit write boundary, **exactly one file was written — this report**
> (`/workspace/.llm_tmp/overnight/reports/scope.md`). No source, build, test, config, `NOTICE`,
> `LICENSE`, or `REUSE.toml` file was created, edited, or deleted, and no test was expanded. All
> prior reports were read and preserved.
>
> **The conflict is moot on the facts.** The described defect — *"a measured GCC syntax failure: an
> extra closing brace in `score/socom/impl/service_identifier.hpp` at line 39"* — is **not present in
> the current working tree** (§2). The header is brace-balanced (braces at `:19`, `:29`, `:32`,
> `:38`; line `:39` blank; `:40` the `#endif`), so there is no actual source to correct. Applying the
> historical repair to an already-balanced file would be a no-op at best and a regression at worst;
> the write boundary forbade a source write in any case. The minimal historical repair is retained in
> §2.3 for reference only. No test was expanded because the draft's suites already exist on disk
> (§3, §4).
>
> **Non-satisfaction rule applied throughout.** A successful obligation-collection node means results
> were **retained**, not that checks **passed**. Missing tools, unknown applicability, incomplete
> extraction, an inactive/draft rule mapping, and unanswered human reviews are **not** treated as
> satisfied. A tool that produced **no** finding because it **did not run** is recorded as *"not
> run"*, never as *"clean"*. Every unexecuted applicable check and every unaccepted deviation remains
> a **blocker** (§5, §6).

---

## 0. Summary

1. **Issue #84 is a design proposal, not an accepted obligation** (§1.1). It is bound to baseline
   commit `f8a196c3…`, not to any run HEAD. The body proposes `service id + major` as the service
   identifier and excluding the minor version from identity; the snapshot records **0 comments, no
   assignee, no labels, no milestone, and no acceptance** (`.llm_tmp/context/issue-snapshot.json`).
2. **The recorded "extra closing brace at line 39" is not present in the actual source** (§2). The
   header is 40 lines and brace-balanced; line 39 is empty. **No source correction was applied and
   none is required.**
3. **The bounded key change is present and internally consistent** (§3.1): `operator<` orders by
   `(instance, service id, major)` with `minor` deliberately excluded
   (`score/socom/impl/service_identifier.cpp:28-29`), matching the minor-ignoring `Service_database`
   record index (`score/socom/impl/runtime_impl.hpp:116-134`) and closing the key/index identity gap.
4. **Draft tests exist but are not natively run here** (§3.2, §6): `service_identifier_tests.cpp` has
   **87 `TEST_F`** (verified by `grep`, `:168`…`:2012`); `runtime_tests.cpp` has **33 macros**
   (1 `TEST` + 31 `TEST_F` + 1 `TEST_P`, `:239`…`:1311`), including the minor-only duplicate
   regression `:402-431`. `runtime_tests.cpp` has **never** been compiled or executed by any artifact
   available in this checkout.
5. **The host validation and obligation-collection artifacts are absent from this checkout**
   (§1.5): `.llm_tmp/overnight/validation/`, `.llm_tmp/overnight/obligations/`, and every
   `result.json` return **no** `glob` matches here. Prior reports under
   `.llm_tmp/overnight/prior-reports/` retain *readings* of those artifacts; a reading is not the
   artifact and is not a passed check.
6. **No obligation is satisfied** (§5). `authority.json` records `engineering_acceptance: pending`,
   `human_reviews: unanswered`, `safety_class: unknown`; every `source-index.json` entry is
   `native_acceptance: not_inferred`.

---

## 1. Binding issue #84 to the verified baseline

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` | `.llm_tmp/context/issue-snapshot.json:2-4` |
| Title | *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:3` |
| State | `open`, **0 comments**, no milestone / assignee / labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` (unchanged) | `.llm_tmp/context/issue-snapshot.json:19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**. It distinguishes three use cases:

- *service-instance identifier* = `service id + major + minor + instance id`;
- *service identifier* = `service id + major`;
- *FindService* = `service id + major + optional<minor> + optional<instance>`;

and proposes to *"exclude the minor version and make it a property of the service instance to be able
to better compare and index compatible service instances."* It notes the FindService `major = FF`
AUTOSAR case as theoretically possible but not useful. There is **no comment and no acceptance
record** in the snapshot, so none of the proposal is binding. Binding is **by baseline commit**, not
by run HEAD.

### 1.2 Verified baseline

| Item | Value | Source |
|------|-------|--------|
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |
| Current branch | `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ` | run environment |
| Current HEAD | `b7d55bb` — `fabro(01M3ZRSDK2XQAF1H48VWTPKQNZ): start (success)` | run environment |

Earlier reports reference other run IDs on the same baseline commit
(`01M3YRJEGXNY6CB81T7TKW774B`, `01M3YGTGYFEN406VDEVVTJTRWV`, `01M3XZAQ65TTE35XSGXC4JAMAH`, and
others). The binding is **by baseline commit `f8a196c3…`**, not by run HEAD, so those reports describe
the same baseline and remain admissible prior evidence for this slice. The candidate-set hashes in
`.llm_tmp/context/candidate-files.json` and those quoted by the prior reports differ from each other
(prior reports record tool-measured post-rework hashes); no hashing tool is available in this task,
so the current working tree was **not** re-hashed. The direct source reads in §2–§4 are authoritative
for this report.

### 1.3 In-scope candidate files (`.llm_tmp/context/candidate-files.json`)

| File (repo-relative) | Baseline git blob | Baseline present | Current working tree (read this iteration) |
|----------------------|-------------------|------------------|--------------------------------------------|
| `score/socom/BUILD` | `3477ea0851fdcd82ec6ea9d71424013cbdf41962` | yes | `socom` library `:24-41`; `testonly` `impl_service_identifier` exposure `:46-54` |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e22355242009fe20dada2a9a0d0c7a9c7` | yes | key identity `(instance, service id, major)`; `minor` excluded (`:28-29`) |
| `score/socom/impl/service_identifier.hpp` | `c8bae7908da9f087c518934f7b9f8d86db9a20ec` | yes | **brace-balanced**, 40 lines; line `:39` blank (§2) |
| `score/socom/test/unit/BUILD` | `3c03a7b14286051f97fa5022206564bd63645171` | yes | `socom_test` globs `*.cpp`; deps wired (`:16-29`) |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab726db8bf994c960045d6fd7fdf84d7395` | yes | **33 macros** (1 `TEST` + 31 `TEST_F` + 1 `TEST_P`); minor-only regression `:402-431` |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(none — `null`)* | **no** (manifest expects a **new** file) | **87 `TEST_F`** matrix; `SetUp()` metadata `:42-65` |

The `null` baseline blob is the manifest's expectation of a **new** unit-test file; it exists on disk
only in the un-merged working tree (the task's *"cancelled draft"*), never in the baseline. The five
present baseline blobs also appear in the `files` array of
`.llm_tmp/context/source-manifest.json`, binding the candidate set to the baseline commit.
`glob **/service_identifier.hpp` and `glob **/service_identifier_tests.cpp` each return exactly **one**
path, so there is no second, differently-braced copy of either file in this checkout.

### 1.4 Pinned obligation sources and authority (all read this iteration)

All nine entries of `.llm_tmp/context/obligations/source-index.json` were read from
`.llm_tmp/context/obligations/`, together with `authority.json`. Every entry is pinned
`"native_acceptance": "not_inferred"` — pinned, but its applicability to this slice is **not
inferred**.

| id | file | status (re-read this iteration) |
|----|------|---------------------------------|
| `coding_guidelines` | `coding_guidelines.rst` | `:status: valid` (`:20`); MISRA C++:2023 with C++17 (`:30-36,74`); document declares `:safety: ASIL_B` |
| `code_analysis` | `code_analysis.rst` | `:status: valid` (`:20`); clang-tidy + gcc/clang warnings + Coverity; ASan/LSan/TSan/UBSan/Memcheck; gcov/gcovr |
| `misra_mapping` | `misra_mapping.rst` | **`:status: draft`** (`:20`); the `csv-table` is commented out (`:26-31`), `_assets/misra_2023.csv` absent |
| `verification_plan` | `verification_plan.rst` | `:status: valid` (`:17`); quality criteria 1–9 (`:292-335`); criterion 9 = freedom from compiler warnings & errors, 100 % |
| `development_plan` | `development_plan.rst` | `:status: valid` (`:21`); C++17, GCC host compiler, QCC target, Bazel |
| `tool_management` | `tool_management.rst` | `:status: valid` (`:17`); tools identified / evaluated / qualified / released-or-rejected by a human |
| `verification_process` | `verification_process.rst` | `:status: valid` (`:22`); `gd_req__verification_link_tests_cpp` (`:56-75`), `_independence` (`:141-152`), `_checks` (`:178-196`), `_checks_extended` (`:198-212`), `_external_aou` (`:214-226`), `_sca_classification` (`:228-248`) |
| `verification_guideline` | `verification_guideline.rst` | `:status: valid` (`:19`); traceability, independence, documented results |
| `inspection_checklist` | `inspection_checklist.rst` | **`:status: draft`** (`:17`); blank `IMPL_01_01`…`IMPL_03_02` template naming content-responsible / reviewer / moderator |

**Authority record** (`.llm_tmp/context/obligations/authority.json`):

| Field | Value |
|-------|-------|
| `engineering_acceptance` | **pending** |
| `human_reviews` | **unanswered** |
| `safety_class` | **unknown** |
| `codeql_scope` | Public Apache-2.0 `eclipse-score/inc_someip_gateway`; **no upload** |
| `instruction` | *"Restart the failed queue for one complete pass through all obligations"* |

**Safety-class note (recorded, not resolved).** The pinned platform documents carry
`:safety: ASIL_B` (`coding_guidelines.rst:22`, `code_analysis.rst:22`, `verification_plan.rst:19`,
`development_plan.rst:23`, `tool_management.rst:19`, `misra_mapping.rst:22`,
`inspection_checklist.rst:19`), while `authority.json` records `safety_class: unknown` and no
authorized selection exists. The document attribute is **not** a selection of the slice's safety class
and must not be inferred as one; the QM-vs-safety goal split in criterion 1–2 remains unselectable
until an authorized human decides it.

### 1.5 Prior reports, host feedback, and obligation-collection results available in *this* checkout

- **`.llm_tmp/overnight/prior-reports/` — 38 files present**, all read/cross-checked and preserved:
  `analyzer_plan.md`, `api_review.md`, `bazel_plan.md`, `callsites.md`, `compatibility.md`,
  `concurrency_review.md`, `conversion_tests.md`, `coverage_review.md`, `coverage_tests_repair.md`,
  `cross_target_review.md`, `design_inspection_draft.md`, `deviation_drafts.md`,
  `evidence_inventory.md`, `finding_classification.md`, `independent_review_handoff.md`,
  `integration_aou_review.md`, `invariants.md`, `key_fix.md`, `lifetime_review.md`,
  `lifetime_tests.md`, `misra_applicability.md`, `misra_manual_review.md`, `native_build_review.md`,
  `ordering_tests.md`, `performance_review.md`, `reproducer.md`, `review_packet.md`,
  `runtime_disabled.md`, `runtime_enabled.md`, `sanitizer_review.md`, `scope.md`, `security_review.md`,
  `test_metadata.md`, `tool_assurance_review.md`, `tool_findings_repair.md`, `traceability_review.md`,
  `unit_matrix.md`, `verification_report_draft.md`.
- **`.llm_tmp/overnight/reports/`** returned **no** files before this write (the directory did not
  exist). This document is its first entry in this checkout. Earlier reports call their own
  `reports/` tree the home of the same-named files (e.g. `scope.md`, `key_fix.md`,
  `finding_classification.md`); in this checkout that corpus is physically consolidated under
  `prior-reports/`.
- **`.llm_tmp/overnight/validation/`** returned **no** files. The prior reports record its intended
  content (`check-result` = `0`; `measurement.json` with `origin: local_unprotected_measurement`,
  `initiator: Fabro host hook`, `mode: ubsan`, `engineering_acceptance: pending`,
  `full_native_tests: not_executed`, compiler `/usr/bin/x86_64-linux-gnu-g++-12`; a focused
  identifier-translation-unit `baseline_with_agent_tests` red vs. `candidate` green record). **The
  artifacts themselves are not present here**, so this report does not treat any host check as passed.
- **`.llm_tmp/overnight/obligations/*/result.json`** returned **no** files; `glob **/result.json`
  across the whole workspace returned **nothing**. The directory is absent from this checkout.
  Prior reports summarize collector rows (e.g. focused GCC green, clang blocked on a
  googletest/libstdc++ dependency deprecation, clang-tidy config rejected / not run, branch coverage
  below goal, TSan SIGSEGV, memcheck absent, native/`bazel` legs exit 127). Those are **readings of
  missing artifacts**, retained by the reports only; **retention ≠ passing**, and absence here is
  **not** evidence that the checks passed.

### 1.6 Derived sequence of the preserved reports (all on baseline `f8a196c3…`)

`scope.md` (bounded the slice; identified the key/index identity gap) → `invariants.md` (I-1…I-16) →
`callsites.md` → `reproducer.md` (key-level regression, test-only header exposure, and the header
brace correction that left line 39 blank) → `key_fix.md` / `unit_matrix.md` (drop `minor` from the
ordering; expand key tests) → `ordering_tests.md` / `conversion_tests.md` → `runtime_disabled.md`,
`runtime_enabled.md`, `lifetime_tests.md` (runtime regressions, never natively executed) →
`test_metadata.md` → later host-side iterations (`coverage_review.md`, `coverage_tests_repair.md`,
`finding_classification.md`, `misra_applicability.md`, `misra_manual_review.md`,
`tool_findings_repair.md`) → review artifacts (`design_inspection_draft.md`, `deviation_drafts.md`,
`security_review.md`, `tool_assurance_review.md`, `integration_aou_review.md`,
`traceability_review.md`, `evidence_inventory.md`, `independent_review_handoff.md`,
`review_packet.md`, `verification_report_draft.md`). `repair_unit_matrix.md` and a host addendum
`obligation-addendum.md` are referenced by some reports but are **not present** in this checkout.

---

## 2. The recorded syntax failure: inspection of the actual source

### 2.1 Finding (re-verified this iteration by direct `read_file` + `grep`)

`score/socom/impl/service_identifier.hpp` is **brace-balanced**. It is exactly 40 lines; `grep '[{}]'`
returns exactly four brace-bearing lines and `grep 'namespace'` returns exactly two:

| Line | Content | Role |
|------|---------|------|
| 14 | `#ifndef SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard begin |
| 17 | `#include "score/socom/service_interface_identifier.hpp"` | include |
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 21–28 | doc comment | states `minor` is intentionally not part of the identity |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 30–31 | `Service_interface_identifier interface;` / `Service_instance instance;` | members |
| 32 | `};` | closes the struct |
| 34–36 | `/// \cond` / `bool operator<(…)` / `/// \endcond` | the single operator declaration |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`) and two closers (`:32`, `:38`): net brace balance is `0`. There is **no
third, unmatched closing brace**, and line 39 contains no text at all. The sibling
`score/socom/impl/service_identifier.cpp` uses the same nested form (`:18` / `:32`) and is balanced.
The task's *"extra closing brace … at line 39"* is therefore a **stale, pre-correction description**.
It matches the earliest prior reports, which quote the split form `}  // namespace socom` +
`}  // namespace score`. The `reproducer` iteration is the one that records the correction; every
later prior report records the header as already balanced — which is what the actual source shows in
this checkout today.

### 2.2 Disposition and the write-boundary conflict

**No correction was applied, and none is required.** The instruction's precondition ("inspect and
correct the actual source before expanding tests") is satisfied without a source write: there is
nothing to correct, and the explicit write boundary ("only that report may be written") would have
forbidden the write in any case. If the *"cancelled draft"* is a different revision that still carries
the extra brace, it is **not** the file in this checkout and must be located and corrected by an
authorized iteration; this report records the discrepancy for human disposition rather than
speculating. No test was expanded, because the draft's suites already exist on disk (§3).

### 2.3 Minimal historical repair (reference only; NOT applied)

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

Applying this to the already-balanced file would be a no-op; deleting a brace would *create* the
reported defect.

### 2.4 Corroboration (recorded in prior reports; artifacts absent here)

The prior reports retain a host measurement that compiled the flagged header as a transitive include
of `service_identifier.cpp` / `service_identifier_tests.cpp` with
`g++-12 -std=c++17 -Wall -Wextra -Werror`, exiting `0` with empty `stderr`; a surviving extra closing
brace would have failed that compile. **The measurement artifacts themselves are absent from this
checkout** (§1.5); only the prior reports' records of them are available, and those are local,
unprotected, scoped captures — not acceptance. No compile was run in this iteration.

### 2.5 Why it would matter if present

The header is compiled into `//score/socom:socom` (`score/socom/BUILD:24-41`; its `srcs` globs
`impl/**/*.cpp` and `impl/**/*.hpp`) and re-exposed to `//score/socom/test/unit` through the
`testonly` library `impl_service_identifier` (`score/socom/BUILD:46-54`; consumed at
`score/socom/test/unit/BUILD:24`). A syntax error there would fail the library and the whole
`socom_test` target, contradicting S-CORE quality criterion 9 (`verification_plan.rst:332-335`). It
is **not** a blocker in the current tree; that is a static brace-balance reading, **not** a compile
measurement.

---

## 3. Accepted draft scope (local only)

**No acceptance record exists locally.** `authority.json` records `engineering_acceptance: pending`
and `human_reviews: unanswered` (with `safety_class: unknown`). Every `source-index.json` entry is
`native_acceptance: not_inferred`. The scope below is therefore the draft **accepted for this local
iteration only**; it is **not** an engineering acceptance and must be confirmed by human review before
implementation is treated as done.

### 3.1 In scope for this bounded slice

1. **Key semantics for duplicate server connectors.** Decide and implement whether
   `Service_instance_identifier` keeps or ignores `minor`, aligning with the `Service_database`
   minor-ignoring index and the #84 *"service identifier = service id + major"* use case. Current
   draft state: **minor excluded**, identity `(instance, service id, major)`.
2. **Ordering/identity contract.** Keep `operator<` as the single, unambiguous ordering used by the
   `std::set`; no companion equality/hash. `std::set` uniqueness is `!(a<b) && !(b<a)`.
3. **Key-level unit tests** in `score/socom/test/unit/service_identifier_tests.cpp` (new file, no
   baseline blob). The current draft carries **87 `TEST_F`** under `ServiceInstanceIdentifierTest`
   (verified this iteration by `grep`; `:168`…`:2012`), covering minor-only collapse and 16-bit minor
   boundaries; major/id/instance distinctness; combined matrices; equivalence ↔ `(instance, id,
   major)`; strict-weak-ordering properties over deterministic domains; empty/prefix/high-bit
   boundaries; and text/registry → public-identifier → internal-key conversion boundaries. Metadata
   is recorded in `SetUp()` (`:42-65`): `DerivationTechnique = "boundary-values,equivalence-classes"`
   and a `Description`; `TestType` and `Verifies` are deliberately left unset.
4. **Runtime-level duplicate tests** in `score/socom/test/unit/runtime_tests.cpp` — **33 macros**
   (1 `TEST` at `:239`, 31 `TEST_F` `:279`…`:1253`, 1 `TEST_P` at `:1311`). The focused minor-only
   regression is `ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError`
   (`:402-431`); the file also carries same-configuration duplicate, enabled duplicate,
   lifetime/reuse, differing-service-id/instance/major, and slot-isolation cases (e.g.
   `DestroyingOneServiceIdSlotKeepsOtherServiceIdSlotOccupied` at `:1253`). Shared metadata helper at
   `:264-267` records `DerivationTechnique = "design-analysis,equivalence-classes"` and a
   `Description`.
5. **Build wiring** for the new test file / test-only header exposure (already present; no BUILD
   change required). `score/socom/BUILD:46-54` exposes `impl/service_identifier.hpp`;
   `score/socom/test/unit/BUILD:16-29` defines `socom_test` with `srcs = glob(include = ["*.cpp"])`
   and depends on it.
6. **Test metadata** for the suites (`DerivationTechnique`, `Description`) per
   `gd_req__verification_link_tests_cpp`; `TestType` and `PartiallyVerifies`/`FullyVerifies` links are
   deliberately unset because no verified native requirement/interface identity exists for this slice
   (no invented links).
7. **Notice preservation** — Apache-2.0 headers on every touched file; no `NOTICE`/`LICENSE` changes.

### 3.2 Explicitly out of scope for this bounded slice

- Reshaping the public `Service_interface_identifier` type or moving `minor` onto `Service_instance`
  (the reporter's longer-term proposal).
- FindService wildcard (`major = FF`) handling and the SD/wire mapping.
- The `Service_database` minor-ignoring index and the client/server minor-compatibility algorithm
  beyond what the key decision forces.
- `score/config` minor wildcard (`0xFFFFFFFF`) semantics and the config→socom `uint32→uint16`
  narrowing (pinned only as a boundary in the tests, not decided).
- Fuzz/fault-injection harnesses and full feature/platform reference-hardware validation.

---

## 4. Open design questions

These must be resolved by an accepted human decision before the slice is considered done. They are
drawn from the preserved reports and re-grounded against the current source.

1. **Minor in the duplicate key, or not?** The draft excludes `minor` (consistent with
   `Service_database` and #84), so two servers sharing `id + major + instance` collide as
   `duplicate_service`. If the key must keep `minor`, the `Service_database` index must stop ignoring
   minor (or `register_server_connector` must tolerate replacement) to remove the assert/UB path.
   Which is authoritative?
2. **Two servers, one `id + major + instance`, different minor.** Reject as duplicate, let the later
   minor replace the earlier, or allow both with negotiation? The current code cannot express the last
   option (`m_server` is a single `std::optional`).
3. **Is the assert path reachable and intended?** `Service_record::register_server_connector` asserts
   `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)` (`score/socom/impl/runtime_impl.cpp:369`) before
   `m_server.emplace(...)` (`:371`). Is this a genuine invariant (so the duplicate gate must cover
   every collision the record index can produce), or a defensive check that should tolerate
   re-registration? The assert's terminate-vs-compiled-out semantics live in external
   `score_baselibs`/`futurecpp` and are **undetermined in this checkout**.
4. **Scope of the #84 restructure.** Introduce `Service_identifier = id + major` plus
   minor-as-instance-property (large public API change), or keep
   `Service_interface_identifier{major, minor}` and only fix the internal key? This draft assumes the
   latter; confirm.
5. **Version field widths and wildcard.** socom uses `uint16 major` / `uint16 minor`
   (`score/socom/service_interface_identifier.hpp:83,87`), while the SOME/IP config declares
   `service_version_major: uint8` / `service_version_minor: uint32 = 0xFFFFFFFF` (per prior reports).
   Every config→socom conversion narrows `uint32→uint16`, turning `0xFFFFFFFF` into `0xFFFF`. Under
   the coarsened key, a wildcard-derived `0xFFFF` server and a concrete-minor server now collide.
   How is the wildcard mapped, and does it interact with duplicate detection?
6. **Ordering vs. identity.** `operator<` is used only for `std::set` membership; the type declares no
   `operator==`/hash. Is a total order meaningful, or should the internal key be an equality/hash key?
7. **Public vs. internal placement.** The key is `impl/`-only, compiled via the `impl/**` glob, not
   the public `*.hpp` filegroup. Confirm it stays internal and that changing its ordering is not an
   ABI/API concern.
8. **Error semantics.** `Construction_error::duplicate_service` is commented only *"Service identifier
   already exists."* (`score/socom/error.hpp:55`), now narrower than the actual key. Should a
   minor-only collision report `duplicate_service`, or a more specific error?
9. **Documentation/contract.** `Runtime::make_server_connector`'s doc (`score/socom/runtime.hpp:176`)
   speaks of duplicates judged by *"the configuration.interface and instance parameters"*, but the
   public `operator==` includes `minor` while the registration key does not. Authorize a documentation
   correction?
10. **Test expectations.** Confirm the intended coverage and that a new `service_identifier_tests.cpp`
    is preferred over extending `service_interface_identifier_tests.cpp`, given the manifest treats it
    as new.
11. **Runtime regression acceptance.** Confirm the runtime-level cases (especially the minor-only
    duplicate regression and the service-id slot-isolation case) are wanted and that using the public
    `Runtime::make_server_connector()` path is acceptable, given none has been compiled or executed in
    a full native run in this checkout (§5, §6).

Derived-form questions carried from `prior-reports/invariants.md` §5 remain equivalent: Q-A
reachability of the minor-only collision; Q-B which equivalence is authoritative; Q-C
duplicate-vs-supersede; Q-D the status of `ASSERT(!m_server)`; Q-E whether the public-interface
restructure is pursued.

---

## 5. Obligations status (none satisfied)

### 5.1 Pinned state from `authority.json`

`engineering_acceptance: pending`; `human_reviews: unanswered`; `safety_class: unknown`;
`codeql_scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload"`; instruction
*"Restart the failed queue for one complete pass through all obligations"*. All nine pinned sources in
`.llm_tmp/context/obligations/` were read this iteration (§1.4); every `source-index.json` entry is
`"native_acceptance": "not_inferred"`.

### 5.2 Obligation status for this slice

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Freedom from compiler warnings & errors (100 %) | `verification_plan.rst` (criterion 9, `:332-335`) | **NOT MEASURED** — header is brace-balanced (§2), but nothing was compiled in this iteration; no host artifact is present here |
| Static code analysis (clang-tidy / CodeQL), findings classified | `code_analysis.rst`; `verification_process.rst` (`gd_req__verification_sca_classification`, `:228-248`) | **NOT PERFORMED** — no tool, no build; no authorized Critical/High/Medium/Low classification |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` | **UNKNOWN — NOT CLAIMED** — mapping document is `:status: draft`; no rule applicability asserted |
| Structural statement / branch coverage goals | `verification_plan.rst` (criteria 1–2, `:300-307`) | **NOT MEASURED** — no test execution in this iteration; prior coverage readings are out of this checkout and below platform goals |
| Unit/component testing executed, results recorded | `verification_plan.rst` (criteria 6–7); `verification_guideline.rst` | **NOT EXECUTED** — 0 tests run this iteration; prior key-TU run (if any) is stale/out-of-checkout and does not cover `runtime_tests.cpp` |
| Interface / requirements-based / resource / fault-injection test types | `verification_process.rst`; `verification_plan.rst` | **NOT PERFORMED / applicability not inferred** — no harness; identifier-only tests must not be labelled platform validation |
| Boundary / equivalence derivation | `verification_process.rst` (`:43-50`) | **SOURCE-ONLY** — cases exist in source but were not executed |
| Fuzzy testing technique | `verification_plan.rst` | **NOT EXECUTED / NOT CLAIMED** — no harness and no measurement |
| Linking tests to requirements (record properties) | `verification_process.rst` (`gd_req__verification_link_tests_cpp`, `:56-75`) | **PARTIAL / NOT DONE** — `DerivationTechnique`/`Description` recorded (`service_identifier_tests.cpp:42-65`; `runtime_tests.cpp:264-267`); `TestType` and `Verifies` cannot be set without inventing identifiers |
| External-component AoUs verified | `verification_process.rst` (`gd_req__verification_external_aou`, `:214-226`) | **NOT SATISFIED** — no integration test or static-analysis verdict; no AoU register |
| Independence of verification / review by a different committer | `verification_process.rst` (`gd_req__verification_independence`, `:141-152`) | **NOT DONE** — human reviews unanswered |
| Implementation inspection checklist IMPL_01…IMPL_03 | `inspection_checklist.rst` | **NOT FILLED** — draft template, no inspection |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** for this slice; no tool run here |
| Obligation collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **ABSENT in this checkout** — directory and every `result.json` not present |
| Native acceptance | `source-index.json` | **`not_inferred` for every entry** |

**Explicit non-satisfaction statement.** Missing tools (no `shell`/build/test in this task), the
unknown safety class and un-inferred applicability, the incomplete extraction of host artifacts, the
already-delivered-but-absent obligation-collection results, and the unanswered human reviews mean
**none of the checked obligations may be treated as satisfied**. A collection node that retained
results would only show *retention*, not passing; here the results are not present at all. In
particular, the absence of `.llm_tmp/overnight/validation/` and
`.llm_tmp/overnight/obligations/*/result.json` is **not** evidence that the corresponding checks
passed.

---

## 6. Measurement and validation status

- **Tools:** `read_file`, `grep`, `glob`, `write_file` only. No `shell`, delegation, web, approval,
  publishing, or engineering acceptance.
- **Executed measurements:** **none** this iteration. No build, no `bazel test`, no runtime. Every
  statement is a static reading of the working tree at the baseline-bound candidate paths, or an
  explicitly-labelled logical consequence (e.g. the key/index identity gap and the expected red/green
  behaviour).
- **Test inventory (read, not run):** `score/socom/test/unit/service_identifier_tests.cpp` has
  **87 `TEST_F`** cases under `ServiceInstanceIdentifierTest` (verified this iteration by `grep`;
  `:168`…`:2012`); `score/socom/test/unit/runtime_tests.cpp` has **33 macros** (1 `TEST` + 31
  `TEST_F` + 1 `TEST_P`, verified by `grep`; `TEST` at `:239`, `TEST_F` `:279`…`:1253`, `TEST_P` at
  `:1311`). These counts are static readings; the suites were not executed here.
- **Regression target (source-derived, not executed):**
  `RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError`
  (`runtime_tests.cpp:402-431`) and the key-level minor-collapse cases
  (`service_identifier_tests.cpp:174`, `:182`, `:192`, `:203`, …) assert that a second registration
  differing only in `minor` is rejected as `duplicate_service`. On a key that includes `minor` they
  would fail; on the working-tree key they should pass. This is a `std::set`/strict-weak-ordering
  consequence, not an observed result.
- **Key/index identity reading.** `Runtime_impl::make_server_connector` builds
  `Service_instance_identifier const identifier{configuration.get_interface(), instance}`
  (`score/socom/impl/runtime_impl.cpp:443`), inserts it under the key mutex (`:449-454`), and returns
  `Construction_error::duplicate_service` when `insert(...).second` is false (`:452`); a `Final_action`
  erases it (`:456-463`). The record index ignores minor via
  `Minor_version_ignoring_key_equal` / `Minor_version_ignoring_hash`
  (`score/socom/impl/runtime_impl.hpp:116-134`), consumed by `get_record`. The working-tree key
  (`minor` excluded) is as coarse as that index. This is a **source-derived reading, not a reproduced
  runtime result**.
- **Scope:** local, unprotected, scoped. This draft has not been reviewed, accepted, published, or
  reproduced on a full native runtime. Unit/integration execution and human review remain pending.
- **Reproduction path for the next authorized iteration (not run here):**

  ```bash
  bazel build //score/...
  bazel test //score/...
  bazel test //score/socom/test/unit:socom_test
  # focused key-level:
  bazel test //score/socom/test/unit:socom_test --test_filter='ServiceInstanceIdentifierTest.*'
  # focused runtime regression:
  bazel test //score/socom/test/unit:socom_test \
      --test_filter='RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError'
  # integration / cross / docs / traceability (per the pinned plans)
  bazel test --config=qemu-integration //tests/integration_test/...
  ```

- **No correction was needed for the recorded syntax failure** (§2), and **no test was expanded** in
  this iteration. The draft's 87-case key suite and 33-case runtime suite are as described in §3 but
  remain natively unmeasured in this checkout; the only host runs recorded by prior reports are absent
  here and cover the key translation unit only.

---

## 7. Notice preservation

- No source, build, test, config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was created, edited, or
  deleted by this iteration; only this report was written. Every existing Apache-2.0 / notice header
  is untouched, and all 38 prior-report files under `.llm_tmp/overnight/prior-reports/` were preserved.
- The header that the task flagged (`score/socom/impl/service_identifier.hpp`) was inspected and left
  unchanged because it is already brace-balanced and otherwise well-formed (§2). The sibling
  `service_identifier.cpp`, both BUILD files, and both candidate test files likewise retain their
  Apache-2.0 / SPDX headers (`:1-12`).
- This report itself carries the Apache-2.0 header. No licensed MISRA rule text is reproduced; only
  native rule/query identifiers, file locations, and prior-report readings are cited.
- Any future implementation in this slice must carry the Apache-2.0 header on new files, including
  `service_identifier_tests.cpp`, per `.github/instructions/code-style.md` and `REUSE.toml`.

---

## 8. Pending human review checklist

- [ ] **Confirm the source inspection in §2:** the header is already brace-balanced (braces at
      `:19`, `:29`, `:32`, `:38`; line `:39` blank; single nested close `}  // namespace score::socom`),
      so the recorded syntax failure is stale and no correction is required. If the *"cancelled
      draft"* is a different revision that still carries the extra brace, locate it and authorize its
      correction; it is not the file in this checkout.
- [ ] **Resolve the instruction conflict:** was a review-only iteration intended (report only, as done
      here), or was source correction expected? The write boundary forbade the latter, and it was moot
      because no defect was present.
- [ ] **Confirm the baseline binding** in §1.2–1.3 (issue #84 ↔ commit `f8a196c3…`) and that
      `prior-reports/invariants.md` I-4's baseline ordering (`minor` included) is still the correct
      description of the committed baseline.
- [ ] **Confirm or amend the accepted draft scope** in §3 (it is local-only; no acceptance exists) and
      the out-of-scope list in §3.2.
- [ ] **Answer the open design questions** in §4, in particular Q1/Q2 (minor-version key semantics),
      Q3 (status of `ASSERT(!m_server)`), and Q5 (config wildcard/narrowing).
- [ ] **Confirm whether the key/index identity gap is a real defect** and, if so, treat it as the
      slice's regression target.
- [ ] **Decide the runtime-level test coverage** (two connectors differing only in minor, the
      service-id slot-isolation case, and the disabled/enabled/lifetime cases) and confirm the public
      `Runtime::make_server_connector()` path is acceptable.
- [ ] **Supply the missing obligation results** (`.llm_tmp/overnight/obligations/*/result.json`) and
      host validation feedback (`.llm_tmp/overnight/validation/`) into this checkout; do not infer
      passing from absence or from prior reports' retained summaries.
- [ ] **Run the full native suite** (`bazel test //score/socom/test/unit:socom_test` and the broader
      `//score/...` set) and record results, including `runtime_tests.cpp`; schedule independent human
      review (the approver must differ from the author, per `gd_req__verification_independence`).
- [ ] **Select a safety class** via the authorized role; do not infer the slice's class from the
      `:safety: ASIL_B` attribute on the pinned platform documents (§1.4).
- [ ] **Keep the #84 public `Service_interface_identifier` restructure, FindService wildcard handling,
      and the config minor-wildcard narrowing out of this bounded slice** until separately accepted,
      and do not present the identifier-only tests as platform validation or claim an unmeasured fuzzy
      technique.

---

*End of scope review draft. Local, unprotected, scoped. No engineering acceptance; human reviews
unanswered; full native runtime tests pending. Every statement is a local reading of the working tree,
a prior report's recorded reading, or an explicitly-labelled logical consequence — none is acceptance,
review approval, publication, or a full native run.*
