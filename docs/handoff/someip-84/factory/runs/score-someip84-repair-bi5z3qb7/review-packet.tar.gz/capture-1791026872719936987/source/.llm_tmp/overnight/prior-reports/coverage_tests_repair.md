<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — coverage-driven test repair (`coverage_tests_repair`)

**Document type:** repair report (actual-source inspection + coverage-gap analysis against the
retained obligation artifacts + test-expansion record + obligations status)
**Date:** 2026-10-02
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version handling in
socom* (issue #84), covering the registration-key component conversion.
**Run:** branch `fabro/run/01M3YRJEGXNY6CB81T7TKW774B`
**Status:** local, unprotected, scoped. **No engineering acceptance exists. Human reviews are
unanswered. Full native runtime tests remain pending.** Every expected value below is derived from
the source ordering, from the documented `String_registry` contract and from
`std::set`/strict-weak-ordering semantics; the new cases were **not compiled or executed** (no
shell/compiler was available).

> **Tool / write boundary actually observed.** Only `read_file`, `grep`, `glob` and `write_file`
> were available and were the only tools used. No `shell`, no delegation, no web access, no
> approval, no publishing, and no engineering acceptance. `edit_file` and `update_plan` were
> refused by the sandbox with `Overnight tool/path boundary`, so the only write primitive for a
> candidate path is a whole-file overwrite via `write_file`. Of the six writable candidate source
> paths plus this report, **this iteration wrote exactly two files:**
> `score/socom/test/unit/service_identifier_tests.cpp` and this report. No other candidate source,
> `NOTICE`, `LICENSE`, `REUSE.toml`, config, BUILD, or prior-report file was created, edited, or
> deleted. Every prior report under `.llm_tmp/overnight/prior-reports/` and every earlier report
> under `.llm_tmp/overnight/reports/` was preserved unchanged.

---

## 0. Summary

1. **Recorded GCC syntax failure — inspected; not present in the actual source.**
   `score/socom/impl/service_identifier.hpp` is brace-balanced. A `grep` for a brace character on
   the file returns exactly four matches — `:19` (`namespace score::socom {`), `:29`
   (`struct Service_instance_identifier final {`), `:32` (`};`) and `:38`
   (`}  // namespace score::socom`) — so the net brace balance is `0`; line `:39` is blank and
   `:40` is `#endif`. There is no third, unmatched closing brace. `glob **/service_identifier.hpp`
   returns exactly one path. **No correction was applied, because none is required**; removing a
   brace from a balanced header, or adding one, would *create* the reported defect rather than fix
   it (section 2).

2. **Actual coverage gaps identified from the retained obligation artifact.** The focused coverage
   result (`.llm_tmp/overnight/obligations/focused_coverage/coverage.json` and
   `coverage-summary.json`) records the focused identifier executable as **28/36 lines (77.8 %)** and
   **9/14 branches (64.3 %)**, against the platform goals **QM 85 % / safety 100 %**. The candidate
   key implementation `score/socom/impl/service_identifier.cpp` is **3/3 lines (100 %)**; its single
   uncovered branch is a compiler-generated `throw` edge, not reachable logic. The only reachable
   uncovered code is in `score/socom/impl/string_registry.cpp`: the **"not found" branches of the two
   dynamic insert overloads** (`:38-42` for `insert(std::string_view)` and `:55-59` for
   `insert(std::string&&)`) were never taken, because every dynamic id text the tests used had
   already been registered through the literal overload (section 3).

3. **Two coverage-driven regression tests added** to the candidate file
   `score/socom/test/unit/service_identifier_tests.cpp` (which the manifest records as a new file,
   baseline blob `null`). They drive a **freshly allocated** service-id text through each dynamic
   insert overload and pin the duplicate-detection consequence: two constructions with the same
   dynamic text must resolve to one registry identity and therefore to one
   `(instance, service id, major)` registration key. The file now has **87 `TEST_F`** (85 preserved
   verbatim + 2 new); the Apache-2.0 header and the `SetUp()` record properties are preserved
   (section 4).

4. **Native test results read, not produced.** The retained host capture records
   `candidate` = **85 tests / 0 failures / compile exit 0** and `baseline_with_agent_tests` =
   **85 tests / 28 failures / compile exit 0** for the focused identifier translation unit
   (`before.json` / `after.json` / `measurement.json`); `full_native_tests: not_executed`. The
   focused translation unit does **not** include `runtime_tests.cpp`, and both new tests were
   **not** part of that capture (section 5).

5. **No obligation is satisfied.** A successful collection node means the results were *retained*,
   not that the checks *passed*. Missing tools (`bazel`, `valgrind`, `gitleaks`, `clang-format`,
   `re-use`, `pre-commit`), the unknown safety class, un-inferred applicability, incomplete
   extraction (focused TU only; dependency findings retained) and unanswered human reviews are
   **not** treated as satisfied (section 6).

---

## 1. Binding to the verified baseline, prior reports, host feedback, obligations

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` | `.llm_tmp/context/issue-snapshot.json:2-4` |
| Title | *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:3` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` | `.llm_tmp/context/issue-snapshot.json:19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**: service-instance identifier = `service id + major + minor + instance id`; service
identifier = `service id + major`; FindService = `service id + major + optional<minor> +
optional<instance>`; and the proposal to "exclude the minor version and make it a property of the
service instance". There is **no comment and no acceptance record**, so none of it is binding.

### 1.2 Verified baseline and the only writable source paths

| Item | Value | Source |
|------|-------|--------|
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |

The six candidate source paths (`.llm_tmp/context/candidate-files.json:1-25`), the only source
paths this iteration was permitted to change:

1. `score/socom/BUILD`
2. `score/socom/impl/service_identifier.cpp`
3. `score/socom/impl/service_identifier.hpp`
4. `score/socom/test/unit/BUILD`
5. `score/socom/test/unit/runtime_tests.cpp`
6. `score/socom/test/unit/service_identifier_tests.cpp`

`glob **/service_identifier.hpp` returns exactly one path
(`score/socom/impl/service_identifier.hpp`), so there is no second, differently-braced copy.

### 1.3 Prior reports, host feedback, obligation results read

- `.llm_tmp/overnight/prior-reports/` — **12 files**, read and preserved: `scope.md`,
  `invariants.md`, `callsites.md`, `reproducer.md`, `key_fix.md`, `unit_matrix.md`,
  `ordering_tests.md`, `conversion_tests.md`, `runtime_disabled.md`, `runtime_enabled.md`,
  `lifetime_tests.md`, `test_metadata.md`. Several reports additionally cite
  `repair_unit_matrix.md`, `coverage_tests_repair.md`, `tool_findings_repair.md` and a host
  addendum `obligation-addendum.md`; `coverage_tests_repair.md` is the file this report creates,
  and the other three are quoted by those reports only.
- `.llm_tmp/overnight/reports/` — 13 earlier reports, read and preserved (`scope.md`,
  `callsites.md`, `invariants.md`, `reproducer.md`, `key_fix.md`, `unit_matrix.md`,
  `ordering_tests.md`, `conversion_tests.md`, `runtime_disabled.md`, `runtime_enabled.md`,
  `lifetime_tests.md`, `test_metadata.md`, `tool_findings_repair.md`).
- `.llm_tmp/overnight/validation/` — **present**: `check-result` = `0`; `measurement.json`
  (`origin: local_unprotected_measurement`, `initiator: Fabro host hook`,
  `engineering_acceptance: pending`, `full_native_tests: not_executed`, compiler
  `/usr/bin/x86_64-linux-gnu-g++-12`); `before.json` (85 tests / 28 failures),
  `after.json` (85 tests / 0 failures), and the `before-*` / `after-*` command/stdout/stderr
  captures.
- `.llm_tmp/overnight/obligations/*/result.json` — **present** (24 checks), including
  `focused_coverage/coverage.json` and `coverage-summary.json` (the coverage basis used here),
  and the per-tool raw captures.

Per the task rule, a successful collection node means results were **retained**, not that checks
**passed**; and missing tools, unknown applicability, incomplete extraction and unanswered human
reviews are **not** treated as satisfied obligations.

### 1.4 Pinned obligation sources

All nine entries of `.llm_tmp/context/obligations/source-index.json` are present, together with
`authority.json`. Document status: `coding_guidelines`, `code_analysis`, `verification_plan`,
`development_plan`, `tool_management`, `verification_process`, `verification_guideline` = **valid**;
`misra_mapping` and `inspection_checklist` = **draft**. Every entry is pinned with
`"native_acceptance": "not_inferred"`. `authority.json` records
`engineering_acceptance: pending`, `human_reviews: unanswered`, `safety_class: unknown`,
`codeql_scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload"`.

---

## 2. The recorded syntax failure — inspection of the actual source

`score/socom/impl/service_identifier.hpp` read from the working tree is **brace-balanced** and is
40 lines:

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`) and two closers (`:32`, `:38`) give a net brace balance of `0`; there
is no third, unmatched closing brace and line `:39` contains no text. The task's "extra closing
brace … at line 39" therefore matches the **stale, pre-correction** description recorded by the
earliest prior reports (whose lines 38-39 were the split form `}  // namespace socom` +
`}  // namespace score`), not this checkout. The actual tree follows the repository's *nested open
+ single close* convention, exactly like the sibling `impl/service_identifier.cpp` (`:18` / `:32`).

**Minimal repair, retained for reference only (not applied, because not needed):**

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

Applying this to the already-balanced file would be a no-op at best and a compilation break at
worst. This iteration therefore **left the header unchanged**. A syntax error here would fail both
`//score/socom:socom` (whose `srcs` glob `impl/**/*.hpp`) and the whole
`//score/socom/test/unit:socom_test` target; the balanced state removes that source-level blocker
(the retained GCC focused compile corroborates it, `exit 0`, empty stderr), but that is not a
compile measurement in this iteration (section 5).

**Instruction conflict.** The task directs "inspect and correct the actual source before expanding
tests". Inspection shows there is no defect to correct, so the precondition is satisfied without a
source write; re-introducing a broken brace so it could be "fixed" would be a regression.

---

## 3. Actual coverage analysis (from the retained obligation artifact)

Source: `.llm_tmp/overnight/obligations/focused_coverage/coverage-summary.json` and
`coverage.json`. The focused executable compiles `score/socom/impl/service_identifier.cpp`,
`score/socom/impl/string_registry.cpp` and `score/socom/test/unit/service_identifier_tests.cpp`
with `g++-12 -std=c++17 -Wall -Wextra -Werror --coverage` and runs it under gtest; the production
filter is `score/socom/impl/`.

### 3.1 Summary as measured

| File | Lines | Branch | Uncovered statements / branches |
|------|-------|--------|---------------------------------|
| `score/socom/impl/service_identifier.cpp` | 3/3 (100 %) | 1/2 (50 %) | none; branch `:28` is the compiler-generated `throw` edge (count 0) |
| `score/socom/impl/string_registry.cpp` | 25/33 (75.8 %) | 8/12 (66.7 %) | lines `39,40,41,42` and `56,57,58,59`; branches `:38` (true) and `:55` (true), plus the guard/`throw` edges on `:66`, `:71` |
| **Total** | **28/36 (77.8 %)** | **9/14 (64.3 %)** | platform goals: QM 85 / safety 100; safety class unknown |

The candidate key implementation is fully line-covered. Its only uncovered branch is a
`fallthrough/throw` edge at `:28` that the `std::tie` comparisons (pointer/`uint16_t`) cannot
reach. The only **reachable** uncovered code is in `string_registry.cpp`:

- `String_registry::insert(std::string_view)` (`:34-46`): the `if (iter == m_registered_strings.end())`
  true branch at `:38` and its statements `:39-42` were never taken (branch counts
  `{fallthrough: 0, fallthrough: 37}`). Every dynamic `string_view` the tests built had already been
  registered by an earlier literal insertion, so the lookup always succeeded.
- `String_registry::insert(std::string&&)` (`:48-63`): the `if (iter == m_registered_strings.end())`
  true branch at `:55` and its statements `:56-59` were never taken (branch counts
  `{fallthrough: 0, fallthrough: 28}`).

This is a genuine equivalence/boundary gap in the **identifier-conversion** path of the
registration key: a configuration-provided id that has never been seen is exactly the first-use
case that takes the "not found" branch, and the duplicate gate depends on a second construction of
that same text resolving to the same registry identity.

### 3.2 Expected effect of the added tests (source-derived, not measured)

`score/socom/impl/string_registry.cpp` is **not** one of the six writable candidate paths, so it
was not modified. The gap is closed from the test side (a candidate path) by exercising the two
overloads with a text that is guaranteed absent from the process-wide registry. On the next
permitted coverage run this is expected to:

- cover statements `:39-42` and `:56-59` and the true branches at `:38` and `:55`, taking line
  coverage to **36/36 (100 %)** and branch coverage to **11/14 (78.6 %)**;
- leave three branches structurally uncoverable by design (the `throw` edge on
  `service_identifier.cpp:28` and the function-local-static guard/`throw` edges on
  `string_registry.cpp:66,71`), which is why a 100 % branch figure cannot be reached with these
  tests alone.

These are **expected**, not observed, effects.

---

## 4. Test expansion record

File changed: `score/socom/test/unit/service_identifier_tests.cpp` (Apache-2.0 header retained;
`SetUp()` record properties retained; **85 pre-existing `TEST_F` cases reproduced verbatim**, all
at their original line numbers `:168`…`:1929`). Two deterministic cases were appended.

### 4.1 New cases

| # | Test (line) | Overload exercised | Pins |
|---|-------------|--------------------|------|
| 86 | `FreshDynamicServiceIdStringViewRegistersAndCollapses` (`:1982`) | `insert(std::string_view)` (`:38-42`) | A brand-new dynamic service-id text is newly registered (`insert().second == true`), resolves back to the same text, a second insert of the same text is refused, and both constructions collapse to one `(instance, service id, major)` key across opposite minor boundaries |
| 87 | `FreshDynamicServiceIdRvalueRegistersAndCollapses` (`:2012`) | `insert(std::string&&)` (`:55-59`) | same contract via the `std::string&&` construction path |

Each case:

- builds a text with a per-run counter suffix (`"FreshDynamicServiceIdStringView_"` /
  `"FreshDynamicServiceIdRvalue_"` + `std::to_string(++counter)`), so it is guaranteed to be absent
  from the process-wide `service_id_registry()` on first insertion — including if the binary is
  repeated in one process — while remaining deterministic in structure;
- drives the corresponding public `Service_interface_identifier` constructor (the `std::string_view`
  overload for case 86; the `std::string&&` overload for case 87) with the *same* fresh text, so the
  registration key is built from a dynamically registered (`impl/`-only) registry view;
- asserts `identity_of(key) == (instance, service id, major)` and that two constructions differing
  only in `minor` are `equivalent` and occupy exactly one `std::set` element.

### 4.2 Why these tests and not others

No other reachable coverage gap exists in the slice. `service_identifier.cpp` is 100 % line-covered;
the header is declaration-only; the runtime-level duplicate regressions already exist in
`runtime_tests.cpp` (`ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError`
`:402-431`, plus same-configuration, different-major, different-instance, different-service-id and
lifetime cases), and there is no coverage artifact for `runtime_impl.cpp`, so no runtime coverage
gap is evidenced. The added cases are therefore the only additions supported by actual line/branch
coverage data. They are **not** padding: they pin the first-use registration and subsequent
duplicate-collapse behaviour of a configuration-provided (non-literal) id, which is exactly the
registration-key component conversion.

### 4.3 Unverified because no compiler was available

No `shell`/compiler was available, so the two new cases were **not compiled and not executed**. The
expected green result is derived from the `String_registry` contract and `std::set` equivalence.
If a future permitted run shows a compile or expectation failure in these two cases, that failure
is evidenced and must be corrected then; until then this report records the measurement as pending.

---

## 5. Native test results and measurement status

- **Retained host capture (read, not produced here), focused identifier translation unit**
  (`service_identifier.cpp` + `string_registry.cpp` + `service_identifier_tests.cpp`):
  - `before.json` / `measurement.json.baseline_with_agent_tests` = **85 tests / 28 failures**,
    compile exit 0 — the pre-correction `minor`-including key fails the 28 minor-insensitivity
    cases.
  - `after.json` / `measurement.json.candidate` = **85 tests / 0 failures**, compile exit 0,
    `stderr` empty — the red-to-green transition is the registration-key correction, not a syntax
    fix.
  - `check-result` = `0`; `origin: local_unprotected_measurement`;
    `engineering_acceptance: pending`; `full_native_tests: not_executed`.
  - Scope caveat: this capture covers 85 cases and therefore **predates** the two new cases (now
    87) and does **not** compile `runtime_tests.cpp` or the full `socom_test` / `//score/...`
    targets.
- **Focused coverage** (section 3): 77.8 % line / 64.3 % branch before this iteration's additions.
- **Other retained obligation results (blockers, not source defects):** clang compile blocked on a
  googletest/libstdc++ 12 `-Wdeprecated-declarations` dependency error under `-Werror`;
  `focused_cppcheck` `passedByValue` findings all in headers outside the six paths;
  `focused_clang_tidy` config rejected (`--verify-config`, unknown checks); CodeQL security findings
  only under `.llm_tmp/googletest/`; CodeQL MISRA only googletest-macro `external-linkage` hits in
  the candidate test file (draft mapping); ASan/LSan/UBSan pass; TSan fails to start
  (`unexpected memory mapping`); memcheck unavailable (exit 127); `native_*`,
  `cross_compilation`, `native_performance`, `format_precommit`, `native_lint`, `native_docs`,
  `native_traceability` fail with `No such file or directory: '/tmp/s-core-001/bin/bazel'`
  (exit 127) or missing `clang-format`/`pre-commit`/`reuse`; `secret_dependency_checks` has no
  `gitleaks`. **A successful collection node means retention, not passing.**
- **Reproduction path for a later, permitted run (not executed here):**

  ```bash
  bazel test //score/socom/test/unit:socom_test
  bazel test //score/socom/test/unit:socom_test --test_filter='ServiceInstanceIdentifierTest.*'
  bazel test //score/socom/test/unit:socom_test \
      --test_filter='ServiceInstanceIdentifierTest.FreshDynamicServiceIdStringViewRegistersAndCollapses:ServiceInstanceIdentifierTest.FreshDynamicServiceIdRvalueRegistersAndCollapses'
  # focused coverage (g++-12/gcovr), to confirm the expected 36/36 lines and 11/14 branches:
  #   compile service_identifier.cpp + string_registry.cpp + service_identifier_tests.cpp --coverage
  #   run the binary, then gcovr --filter score/socom/impl/
  ```

  Expected on the current key: all 87 cases pass; the two new cases register a fresh dynamic text
  and collapse the two constructions to one key. On a key that included `minor`, the collapse
  assertions fail.

---

## 6. Obligations status (none satisfied)

### 6.1 Pinned state

`authority.json`: `engineering_acceptance: pending`, `human_reviews: unanswered`,
`safety_class: unknown`, `codeql_scope: Public Apache-2.0 eclipse-score/inc_someip_gateway; no
upload`. Every `source-index.json` entry is `native_acceptance: not_inferred`.

### 6.2 Per-obligation status for this slice

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Freedom from compiler warnings & errors (100 %) | `verification_plan.rst` criterion 9 | **PARTIAL** — GCC focused compile clean in the retained capture; Clang blocked on a googletest/libstdc++ `-Wdeprecated-declarations` dependency error; the two new cases are uncompiled |
| Static code analysis (clang-tidy / CodeQL), findings classified | `code_analysis.rst`; `verification_process.rst` (SCA classification) | **NOT SATISFIED** — clang-tidy config blocker; cppcheck findings out of scope; CodeQL security dependency-only; CodeQL MISRA applicability draft + gtest-macro hits needing human deviation |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` (draft) | **UNKNOWN** — mapping draft; human deviations pending |
| Structural statement / branch coverage goals | `verification_plan.rst` criteria 1-2 | **NOT MEASURED TO GOAL** — focused 77.8 % line / 64.3 % branch; the new cases are expected to reach 100 % line / 78.6 % branch, but that is unmeasured |
| Unit/component testing executed, results recorded | `verification_plan.rst` criteria 6-7; `verification_guideline.rst` | **PARTIAL** — retained focused 85/85 green; the 87-case suite and full native `socom_test` are not executed |
| Interface / requirements-based / resource / fault-injection test types | `verification_process.rst` | **NOT PERFORMED / applicability not inferred** — no harness; identifier-only tests must not be labelled platform validation |
| Fuzzy testing technique | `verification_plan.rst` | **NOT EXECUTED / NOT CLAIMED** — no harness, no measurement |
| Boundary / equivalence derivation | `verification_process.rst` | **SOURCE-ONLY** — cases exist and were expanded, but the new cases were not executed |
| Linking tests to requirements (record properties) | `verification_process.rst` (`gd_req__verification_link_tests_cpp`) | **PARTIAL / NOT DONE** — `DerivationTechnique`/`Description` recorded in `SetUp()`; `TestType` and `Verifies` cannot be set without inventing identifiers |
| Independence of verification / review by a different committer | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Implementation inspection checklist IMPL_01…IMPL_03 | `inspection_checklist.rst` (draft) | **NOT FILLED** — draft template, no inspection |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** for this slice — bazel, valgrind, gitleaks, clang-format, pre-commit, reuse unavailable; clang-tidy config rejected |
| Obligation collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **RETAINED, NOT PASSING** — 24 checks present; most blockers above |
| Native acceptance | `source-index.json` | **not_inferred** for every entry |

**Explicit non-satisfaction statement.** Missing tools, the unknown safety class and un-inferred
applicability, the incomplete extraction (focused TU only, dependency findings retained), the
below-goal focused coverage, the uncompiled new cases, and the unanswered human reviews mean
**none of the checked obligations may be treated as satisfied**. A retained collection result shows
*retention*, not passing.

---

## 7. Files changed / state of the six candidate paths

| Candidate path | This iteration |
|----------------|----------------|
| `score/socom/impl/service_identifier.hpp` | **Unchanged** — inspected; already brace-balanced (`:39` blank), nested namespace close; no defect to correct |
| `score/socom/impl/service_identifier.cpp` | **Unchanged** — already orders by `(instance, service id, major)` with `minor` excluded; 100 % line-covered |
| `score/socom/BUILD` | **Unchanged** — `testonly` `impl_service_identifier` exposure present |
| `score/socom/test/unit/BUILD` | **Unchanged** — `socom_test` globs `*.cpp`; deps already wired |
| `score/socom/test/unit/runtime_tests.cpp` | **Unchanged** — already carries the minor-only runtime regression and the disabled/enabled/lifetime variants |
| `score/socom/test/unit/service_identifier_tests.cpp` | **Changed** — 85 cases preserved verbatim; 2 coverage-driven cases appended (87 total); Apache-2.0 header and `SetUp()` record properties preserved |
| `.llm_tmp/overnight/reports/coverage_tests_repair.md` | **New — this report** |

No file outside the six candidate paths and this report was written; no `NOTICE`, `LICENSE`, or
`REUSE.toml` file was created, edited, or deleted.

---

## 8. Notice preservation

- The only candidate path rewritten is `score/socom/test/unit/service_identifier_tests.cpp`; its
  Apache-2.0 header (`:1-12`) is reproduced verbatim and all 85 pre-existing cases and the
  `SetUp()` record properties are preserved. Only the two new cases were appended.
- `score/socom/impl/service_identifier.hpp` and `score/socom/impl/service_identifier.cpp` retain
  their Apache-2.0 / SPDX headers and were left unchanged.
- The duplicate key remains an `impl/`-only type exposed to `//score/socom/test/unit` solely
  through the `testonly` `//score/socom:impl_service_identifier` library, so no public header or
  notice surface changed.
- This report itself carries the Apache-2.0 header.
- All 12 files under `.llm_tmp/overnight/prior-reports/` and all earlier files under
  `.llm_tmp/overnight/reports/` were preserved unchanged.

---

## 9. Pending human review checklist

- [ ] **Confirm section 2:** the header is already brace-balanced (single nested close
      `}  // namespace score::socom`; line `39` blank), so the recorded "extra closing brace at
      line 39" is stale and **no source edit** was made. Confirm that a no-op is the intended
      outcome and that the cancelled-draft revision carrying the brace is not this checkout.
- [ ] **Confirm the coverage reading in section 3** against the retained
      `obligations/focused_coverage/` artifact, and confirm the platform goals to apply
      (QM 85 % / safety 100 % vs. the repository CI threshold 73) and the safety class, which
      remains human-owned and currently `unknown`.
- [ ] **Confirm the two new cases (section 4)** are the wanted coverage-driven additions and that
      driving a per-run-unique (non-literal) string through `String_registry::insert` is an
      acceptable way to close the first-use registration branch from a candidate test file.
- [ ] **Run the full native suite** (`bazel test //score/socom/test/unit:socom_test` and the
      broader `//score/...` set), including `runtime_tests.cpp` and the two new cases, and record
      the results; re-run the focused coverage tool to confirm the expected 36/36 lines and
      11/14 branches. Schedule independent human review (the approver must differ from the author,
      per `gd_req__verification_independence`).
- [ ] **Supply the missing tools/results** (`bazel`, `valgrind`, `gitleaks`, `clang-format`,
      `pre-commit`, `reuse`) and resolve the clang-tidy config and CodeQL MISRA applicability
      blockers, or record accepted deviations; do not treat retention as passing.
- [ ] **Supply native requirement/interface identifiers** for traceability links, or record
      applicability as unresolved (no invented links); set `TestType` only once a link exists.
- [ ] **Keep the #84 public `Service_interface_identifier` restructure, FindService wildcard
      handling, and the config minor-wildcard narrowing out of this bounded slice** until separately
      accepted, and do not present the identifier-only tests as platform validation or claim an
      unmeasured fuzzy technique.
