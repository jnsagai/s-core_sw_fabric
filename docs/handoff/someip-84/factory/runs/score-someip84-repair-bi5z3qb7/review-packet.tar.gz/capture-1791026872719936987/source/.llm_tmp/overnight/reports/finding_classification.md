<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — original tool-findings reconciliation and classification (`finding_classification`) review draft

**Document type:** review draft (actual-source inspection + original compiler / Clang-Tidy /
Cppcheck / sanitizer / CodeQL findings reconciliation + severity-classification register +
retained-dependency register + obligations status).

**Date:** 2026-10-03
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version handling in
socom* (issue #84)
**Run / branch:** `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ`
**Verified baseline commit:** `f8a196c3b16d5172d898394ab99b0ed81346d63d`
(`.llm_tmp/context/source-manifest.json:3`).
**Status:** **local, unprotected, scoped.** No engineering acceptance exists. Human reviews are
unanswered. Full native runtime tests are pending. Every statement below is either a direct
reading of the working tree, a direct reading of a *retained* artifact under
`.llm_tmp/overnight/`, or an explicitly-labelled logical consequence. Nothing here is
acceptance, review, publication, or a full native run.

> **Tool / write boundary observed.** This iteration used only `read_file`, `grep`, `glob`, and
> `write_file`. No `shell`, no delegation, no web access, no approval, no publishing, and no
> engineering acceptance was performed. A single attempted `shell` invocation was refused by the
> environment ("Overnight tool/path boundary") and produced no output and no change. **This
> iteration wrote exactly one file — this report.** No source, build, test, config, `NOTICE`,
> `LICENSE`, or `REUSE.toml` file was created, edited, or deleted, and every prior report under
> `.llm_tmp/overnight/reports/` and `.llm_tmp/overnight/prior-reports/` was preserved.

> **Instruction conflict (recorded, not silently resolved).** The task directs *"Inspect and
> correct the actual source before expanding tests"* and records *"a measured GCC syntax failure:
> an extra closing brace in `score/socom/impl/service_identifier.hpp` at line 39"*, while its
> explicit and more specific final sentence says *"This is a review draft: only that report may be
> written."* Direct inspection of the **actual** source (§2) shows the header is **already
> brace-balanced** — there is no extra closing brace, so there is nothing to correct. The write
> boundary forbids a source write in any case, so a no-op (report only) is the only action
> consistent with both the facts and the boundary. The conflict is recorded for human disposition
> (§10), not resolved by this draft.

> **Non-satisfaction rule applied throughout.** A successful obligation-collection node means the
> results were **retained**, not that the checks **passed**. Missing tools, unknown applicability,
> incomplete/extracted evidence (focused translation units; dependency findings retained),
> draft/inactive rule mappings, and unanswered human reviews are **not** treated as satisfied. A
> tool that produced **no** finding because it **did not run** is recorded as *"not run"*, never
> as *"clean"*. No finding is suppressed, dropped, or silently filtered.

---

## 0. Summary

1. **The recorded GCC syntax failure is not present in the actual source (§2).**
   `score/socom/impl/service_identifier.hpp` is a 40-line, brace-balanced header. A `grep` for
   `[{}]` returns exactly four brace-bearing lines — `:19` (`namespace score::socom {`), `:29`
   (`struct Service_instance_identifier final {`), `:32` (`};`), `:38`
   (`}  // namespace score::socom`) — two openers, two closers, net balance `0`; line `:39` is
   blank and `:40` is `#endif`. The retained focused **GCC** and **Clang** compiles of the same
   translation unit both exit `0` with empty stderr. **No correction is required or applied.**
2. **The candidate registration-key change is present and the retained host capture is
   red→green (§7).** `operator<` orders by `(instance, service id, major)` with `minor` excluded
   (`score/socom/impl/service_identifier.cpp:28-29`). `validation/measurement.json` records
   `baseline_with_agent_tests` **91 tests / 33 failures / compile 0** and `candidate` **91 tests /
   0 failures / compile 0**; `validation/check-result` = `0` is a *retention* marker, not a pass
   marker.
3. **Original findings were read from the raw retained artifacts and reconciled by location
   (§3).** The only non-zero results are: **Clang-Tidy did not run** (`--verify-config` exit
   `1`); **19 Cppcheck** `passedByValue` performance findings in headers outside the six
   candidate paths; **32 CodeQL security** findings all under `.llm_tmp/googletest/**`; and a
   large **CodeQL MISRA** set whose findings occupy `codeql_misra/result.json` lines
   `1123`–`121517` (grouped by `cpp/misra/*` query id, all with `level: null`). **No compiler
   diagnostic (GCC or Clang) was emitted in this run** — both focused compiles exit `0`.
4. **No authorized Critical/High/Medium/Low rating exists, and no tool-suggested rating either
   (§4).** Per `gd_req__verification_sca_classification`
   (`verification_process.rst:228-248`, `:status: valid`), findings must be classified
   Critical/High/Medium/Low by a **tool suggestion** or **manually by the Quality Manager together
   with a committer**. Every retained CodeQL finding carries `level: null`; Cppcheck carries only
   its own `severity="performance"`; the compiler/tool outputs carry no SCA class. No QM+committer
   classification is present (`engineering_acceptance: pending`). Review-aid classes below are
   labelled **indicative only**; every **authorized** class is **none / pending**.
5. **Dependency findings are retained, not filtered (§5).** Every googletest/library finding is
   preserved by native rule id and scope; no finding was suppressed, dropped, or discarded.
   Several MISRA rule ids observed in this run (`no-character-numerical-value`,
   `internal-linkage-specified-appropriately`, `inappropriate-bitwise-or-shift-operands`,
   `poorly-formed-identifier`, `no-implicit-bool-conversion`) were **absent from the earlier
   prior-report enumeration**, which confirms the earlier list was incomplete; this report does
   **not** claim completeness and defers to the artifact.
6. **The candidate key units are clean in the focused extraction, but that is not a compliance
   statement (§6).** `service_identifier.cpp` / `service_identifier.hpp` carry no analyzer
   finding; `runtime_tests.cpp` was **not extracted**; Clang-Tidy did not run; the CodeQL
   extraction is focused, not full-target.
7. **No obligation is satisfied (§8).** Every `source-index.json` entry is
   `native_acceptance: not_inferred`; authority is `engineering_acceptance: pending`,
   `human_reviews: unanswered`, `safety_class: unknown`. Missing tools/timeouts, the incomplete
   CodeQL extraction, the draft MISRA mapping, below-goal coverage, and unanswered human reviews
   are all treated as blockers.

---

## 1. Binding, scope, and evidence

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` — *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:2-4` |
| State | `open`, **0 comments**, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` | `.llm_tmp/context/issue-snapshot.json:19-20` |
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**: service-instance identifier = `service id + major + minor + instance id`; service
identifier = `service id + major`; FindService = `service id + major + optional<minor> +
optional<instance>`; and the proposal to exclude `minor` from identity and make it an instance
property. There is no comment and no acceptance record, so none of it is binding. Binding is **by
baseline commit**, not by run HEAD.

### 1.2 The six writable candidate source paths

From `.llm_tmp/context/candidate-files.json` (baseline git blobs cross-checked against
`.llm_tmp/context/source-manifest.json`):

| File (repo-relative) | Baseline git blob | Baseline present | Working tree (read this iteration) |
|----------------------|-------------------|------------------|------------------------------------|
| `score/socom/BUILD` | `3477ea0851fdcd82ec6ea9d71424013cbdf41962` | yes | `testonly` `impl_service_identifier` exposure present |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e22355242009fe20dada2a9a0d0c7a9c7` | yes | key identity `(instance, id, major)`; `minor` excluded (`:28-29`) |
| `score/socom/impl/service_identifier.hpp` | `c8bae7908da9f087c518934f7b9f8d86db9a20ec` | yes | brace-balanced, 40 lines, `:39` blank (§2) |
| `score/socom/test/unit/BUILD` | `3c03a7b14286051f97fa5022206564bd63645171` | yes | `socom_test` globs `*.cpp`; deps wired |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab726db8bf994c960045d6fd7fdf84d7395` | yes | 33 test macros; minor-only regression present |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(none — `null`)* | **no** (manifest expects a **new** file) | 91 `TEST_F`; metadata `SetUp()` |

The `null` baseline blob is the manifest's expectation of a **new** unit-test file; it exists on
disk only in the un-merged working tree (the task's *"cancelled draft"*). `glob
**/service_identifier*.{hpp,cpp}` returns exactly three paths (`impl/service_identifier.cpp`,
`impl/service_identifier.hpp`, `test/unit/service_identifier_tests.cpp`); `glob
**/*.{orig,rej,bak}` returns nothing. There is therefore **no second, differently-braced copy** of
the header and no leftover reject/patch file carrying the reported defect.

The changed implementation is the registration-key comparator only:

```cpp
// score/socom/impl/service_identifier.cpp:20-30
bool operator<(Service_instance_identifier const& lhs, Service_instance_identifier const& rhs) {
    return std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major) <
           std::tie(rhs.instance, rhs.interface.id, rhs.interface.version.major);
}
```

i.e. identity is `(instance, service id, major)`; `minor` is deliberately excluded, matching the
minor-ignoring `Service_database` index.

### 1.3 Prior reports read and preserved

- **`.llm_tmp/overnight/prior-reports/` — 38 files present**, all preserved. The earlier
  `finding_classification.md`, `tool_findings_repair.md`, `misra_applicability.md`,
  `misra_manual_review.md`, `sanitizer_review.md`, `security_review.md`, `coverage_review.md`,
  `tool_assurance_review.md`, `traceability_review.md`, and `verification_report_draft.md` were
  read and are the direct predecessors of this document.
- **`.llm_tmp/overnight/reports/` — read and preserved:** `scope.md`, `callsites.md`,
  `invariants.md`, `reproducer.md`, `key_fix.md`, `unit_matrix.md`, `ordering_tests.md`,
  `conversion_tests.md`, `repair_conversion_tests.md`, `runtime_disabled.md`, `runtime_enabled.md`,
  `lifetime_tests.md`, `test_metadata.md`, `coverage_review.md`, `coverage_tests_repair.md`,
  `misra_applicability.md`, `misra_manual_review.md`, `lifetime_review.md`, `analyzer_plan.md`,
  `api_review.md`, `bazel_plan.md`, `compatibility.md`, `concurrency_review.md`, and
  `tool_findings_repair.md`. **This document adds `finding_classification.md`**; no prior report was
  overwritten.

Derived sequence: `scope.md` → `invariants.md` → `callsites.md` → `reproducer.md` (header brace
correction; key-level red regression) → `key_fix.md` / `unit_matrix.md` (drop `minor` from the
key ordering) → `ordering_tests.md` / `conversion_tests.md` / `repair_conversion_tests.md` →
`runtime_disabled.md` / `runtime_enabled.md` / `lifetime_tests.md` → `test_metadata.md` →
host-side `coverage_*`, `misra_*`, `tool_findings_repair.md` → this `finding_classification.md`.

### 1.4 Latest host feedback and retained obligation artifacts (read this iteration)

The `.llm_tmp/overnight/validation/` and `.llm_tmp/overnight/obligations/` trees are **present**
in this checkout and were read:

- `validation/check-result` = `0` (**collector/retention marker only**).
- `validation/measurement.json` — `check_ref: check_conversion_tests`, `status: completed`,
  `mode: ubsan`, `changed_paths: ["score/socom/test/unit/service_identifier_tests.cpp"]`,
  `origin: local_unprotected_measurement`, `initiator: Fabro host hook`,
  `engineering_acceptance: pending`, `full_native_tests: not_executed`, compiler
  `/usr/bin/x86_64-linux-gnu-g++-12` (sha256 `88315fd2…`); `baseline_with_agent_tests`
  **91 / 33 / compile 0**, `candidate` **91 / 0 / compile 0** (`:2045-2058`).
- `validation/before.json` **91 tests / 33 failures**, `validation/after.json` **91 tests /
  0 failures**; `after-test.stdout` ends `[  PASSED  ] 91 tests.`; the pre-correction failing
  names include `KeysDifferingOnlyInMinorVersionAreDuplicates`,
  `MinorVersionBoundariesAreDuplicates`, `MinorVersionNeverAffectsOrdering`,
  `StrictWeakOrderingHoldsAcrossMinorVariants`, and `PropertyEquivalenceMatchesIdentityTupleOnDeterministicDomain`.
- `obligations/*/result.json` and per-command captures for 25 checks (compiler_diagnostics,
  focused_cppcheck, focused_clang_tidy, focused_asan_lsan, focused_tsan, focused_memcheck,
  focused_coverage, codeql_security, codeql_misra, native_build/tests/sanitizers/tsan/coverage/
  integration/lint/docs/traceability/performance, cross_compilation, format_precommit,
  secret_dependency_checks, process_checks, rework_progress, tool_assurance). Details in §3 and §7.

Pinned authority (`.llm_tmp/context/obligations/authority.json`):
`codeql_scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload"`;
`engineering_acceptance: pending`; `human_reviews: unanswered`; `safety_class: unknown`;
instruction *"Restart the failed queue for one complete pass through all obligations"*. Every
`source-index.json` entry is `native_acceptance: not_inferred`.

### 1.5 Pinned obligation sources read

| id | Pinned file | Status / content used here |
|----|-------------|----------------------------|
| `coding_guidelines` | `coding_guidelines.rst` | `:status: valid`; MISRA C++:2023 with C++17 |
| `code_analysis` | `code_analysis.rst` | `:status: valid`; MISRA + ISO 26262-based SCA; clang-tidy + gcc/clang warnings + Coverity; ASan/LSan/TSan/UBSan/Memcheck; gcov/gcovr; *"If for some technical reason any MISRA finding can not be addressed it needs to be justified appropriately … documented within the source code"* (`:51`) |
| `misra_mapping` | `misra_mapping.rst` | **`:status: draft`**; the `csv-table` is commented out and `_assets/misra_2023.csv` is not referenced as active (`:26-31`) |
| `verification_plan` | `software_verification.rst` | `:status: valid`; quality criteria incl. SCA critical/high freedom and compiler warnings/errors freedom |
| `development_plan` | `software_development.rst` | `:status: valid`; C++17, GCC host compiler, QCC target, Bazel |
| `tool_management` | `tool_management.rst` | `:status: valid`; tools identified / evaluated / qualified by a human |
| `verification_process` | `verification_process_reqs.rst` | `:status: valid`; **`gd_req__verification_sca_classification`, `:228-248`** (Critical/High/Medium/Low; tool suggestion or QM+committer) |
| `verification_guideline` | `verification_guideline.rst` | `:status: valid`; traceability, independence, documented results |
| `inspection_checklist` | `chklst_impl_inspection.rst` | **`:status: draft`**; blank template |

The pinned platform documents carry `:safety: ASIL_B`, but `authority.json` records
`safety_class: unknown` and no authorized selection exists. The document attribute is **not** a
selection of this slice's safety class and is **not** inferred as one.

---

## 2. The recorded GCC syntax failure — inspection of the actual source

`score/socom/impl/service_identifier.hpp` read from the working tree is **brace-balanced**
(40 lines):

| Line | Content | Role |
|------|---------|------|
| 14 | `#ifndef SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard begin |
| 17 | `#include "score/socom/service_interface_identifier.hpp"` | include |
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 21–28 | doc comment | states `minor` is intentionally not part of the identity |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 30–31 | `Service_interface_identifier interface;` / `Service_instance instance;` | members |
| 32 | `};` | closes the struct |
| 34–36 | `/// \cond` / `bool operator<(…)` / `/// \endcond` | the single operator declaration |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`) and two closers (`:32`, `:38`) give net brace balance `0`. There is
**no third, unmatched closing brace**, and line `:39` contains no text. The sibling
`score/socom/impl/service_identifier.cpp` uses the same nested form and is balanced.

**Independent corroboration from the retained artifacts.** `compiler_diagnostics/result.json`
records the focused **GCC** `gcc-compile` **exit 0** (`:1152`) and `gcc-tests` **exit 0** (`:1174`),
and the focused **Clang** `clang-compile` **exit 0** (`:1274`) and `clang-tests` **exit 0** (`:1296`),
each with `blockers: []`. A surviving unmatched brace in a header compiled into those translation
units would have failed the compiles, not passed them.

**Disposition.** The described defect is a **stale, pre-correction description** matching the
earliest prior reports (split-form `}  // namespace socom` + `}  // namespace score`); the
`reproducer` iteration is the one that records the correction, and every later report records the
header as balanced — which is what the actual source shows here. Re-applying the historical repair
would be a no-op; deleting a brace would *create* the reported defect. **No correction was applied;
none is required, and the review-draft write boundary would have forbidden a source write in any
case.**

Minimal historical repair, retained for reference **only** (not applied):

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

---

## 3. Reconciliation of the original findings (per tool, from the raw artifacts)

Paths are relative to `/workspace`. "In the six paths?" asks whether a flagged location is one of
§1.2's writable source paths. "Native severity" is the severity the tool itself carried.

### 3.1 Compiler — GCC and Clang (focused TU): no finding in this run

| Aspect | Value | Evidence |
|--------|-------|----------|
| GCC command | `g++-12 -std=c++17 -Wall -Wextra -Werror -pthread -I. … service_identifier.cpp string_registry.cpp service_identifier_tests.cpp gtest-all.o gtest_main.o` | `compiler_diagnostics/result.json:1119-1152` |
| `gcc-compile` | **exit 0** | `result.json:1152`; `gcc-compile.stderr` empty |
| `gcc-tests` | **exit 0** | `result.json:1174`; `gcc-tests.stderr` empty |
| Clang command | `clang++ -std=c++17 -Wall -Wextra -Werror -pthread -I. …` | `result.json:1240-1274` |
| `clang-compile` | **exit 0** | `result.json:1274`; `clang-compile.stderr` empty |
| `clang-tests` | **exit 0** | `result.json:1296`; `clang-tests.stderr` empty |
| Blockers | `[]` | `result.json:1052` |
| Limits | *"Focused executable only; GCC 12.3 / Clang 19 differ from native toolchain pins"*, *"GoogleTest compiled separately with warnings retained; -Werror on target and tests"* | `result.json:1301-1304` |

**Findings: none.** This is a *focused* clean compile under `-Werror` on the target and tests, not
a full-target criterion-9 measurement. **Note superseding the earlier prior report:** the prior
`finding_classification.md` recorded a Clang `-Wdeprecated-declarations` dependency error reached
from googletest; the retained artifact for this run records Clang `exit 0` with empty stderr. The
earlier reading is superseded by the current artifact; no Clang in-scope defect remains.

### 3.2 Analyzer — Clang-Tidy (focused): configuration rejected, **no TU analysis**

`clang-tidy --verify-config --config-file=<snapshot>/.clang-tidy` (clang-tidy 19.1.7) exits **1**
(`focused_clang_tidy/result.json:1077`; `native-config.stderr`), with 15 `unknown check` warnings.
The native texts (preserved verbatim) are:

| # | Native id / text in warning | Cause |
|---|-----------------------------|-------|
| 1 | `# --- autosar-severity-one --- bugprone-use-after-move` | `#` comment folded into check name |
| 2 | `# --- autosar-severity-two --- bugprone-forwarding-reference-overload` | comment folded |
| 3 | `# --- cert --- cert-err52-cpp` | comment folded |
| 4 | `clang-analyzer-alpha.security.ArrayBoundV2` | check absent from clang-tidy 19.1.7 |
| 5 | `# --- qnx-checks --- bugprone-reserved-identifier` | comment folded |
| 6 | `# --- extra --- bugprone-assert-side-effect` | comment folded |
| 7 | `#modernize-type-traits` | `#` prefix folded |
| 8 | `Disabled because of too much noise` | comment folded |
| 9 | `will later be re-enabled with a campaign to fix findings modernize-unary-static-assert` | comment folded |
| 10 | `modernize-use-integer-sign-comparison` | check absent from clang-tidy 19.1.7 |
| 11 | `#modernize-use-nodiscard` | `#` prefix folded |
| 12 | `Disabled because of too much noise` | comment folded |
| 13 | `will later be re-enabled with a campaign to fix findings modernize-use-nullptr` | comment folded |
| 14 | `# --- style-readability --- misc-confusable-identifiers` | comment folded |
| 15 | option `modernize-use-integer-sign-comparison.IncludeStyle` | option absent for the unknown check |

Retained blocker: *"Native analyzer configuration incompatible; no replacement called MISRA"*
(`result.json:1052-1053`); `status: findings_or_execution_failure`. The native `//:clang-tidy.check`
leg additionally **timed out** (exit `124`, `native_lint/result.json:1079`).

**Disposition: Clang-Tidy produced ZERO findings on the changed units because it did not run.**
This is *"not run"*, **not** *"clean"*. The repository `.clang-tidy` is outside the six candidate
paths; repairing it requires an authorized change. **Retained as a blocker; no in-scope
correction.**

### 3.3 Analyzer — Cppcheck (focused): 19 `passedByValue` performance findings

Command (`focused_cppcheck/result.json:1055-1081`): `/usr/bin/cppcheck --std=c++17
--enable=warning,style,performance,portability --xml --xml-version=2 --error-exitcode=2 -I.
score/socom/impl/service_identifier.cpp score/socom/impl/string_registry.cpp`; **exit 2**;
`status: findings_or_execution_failure`. All 19 findings share the native id `passedByValue`,
native severity `performance`, CWE `398`. `file0` is the candidate `service_identifier.cpp`, but
**every `<location>` is an included header outside the six candidate paths**
(`focused_cppcheck/cppcheck.stderr`):

| Native id | Native severity | Flagged declaration location | Count |
|-----------|-----------------|------------------------------|-------|
| `passedByValue` | `performance` | `score/socom/registry_string_view.hpp` `:127` (lhs,rhs), `:134` (lhs,rhs), `:141` (lhs,rhs), `:148` (lhs,rhs), `:155` (lhs,rhs), `:162` (lhs,rhs) | 12 |
| `passedByValue` | `performance` | `score/socom/registry_string_view.hpp:173` (`v`) | 1 |
| `passedByValue` | `performance` | `score/socom/service_interface_identifier.hpp:37,41,48,99,105,113` (`new_id`) | 6 |
| **Total** | | | **19** |

**Disposition: out-of-scope performance style suggestions on small view/value types; not
correctness defects.** Not fixed (headers outside the six paths). **Retained; no in-scope
correction.**

### 3.4 Analyzer — CodeQL security: 32 findings, **all dependency**

Command (`codeql_security/analyze.command.json`): CodeQL 2.21.4, suite
`cpp-security-and-quality.qls`, focused database; `status: findings_or_execution_failure`;
`scan_runs: 1`; self-declared limit *"Focused linked executable, not full target extraction;
dependency findings retained"* (`result.json:1755-1758`); analyze `exit 0`.

**Every finding's `uri` is under `.llm_tmp/googletest/**`.** No finding lands in any of the six
candidate paths, in `score/socom/**`, or anywhere in project code. `level` is `null` on all 32
(`result.json:1119-1753`):

| Native rule id | Count | Locations |
|----------------|-------|-----------|
| `cpp/fixme-comment` | 1 | gtest.h |
| `cpp/commented-out-code` | 7 | gtest-port.h, gtest-matchers.h, gtest.h, gtest.cc, gtest-death-test.h |
| `cpp/large-parameter` | 1 | gtest-death-test-internal.h |
| `cpp/equality-on-floats` | 2 | gtest-printers.h |
| `cpp/unused-static-function` | 2 | gtest.cc |
| `cpp/unused-static-variable` | 1 | gtest-death-test-internal.h |
| `cpp/rule-of-two` | 1 | gtest-port.h |
| `cpp/include-non-header` | 9 | gtest-all.cc |
| `cpp/trivial-switch` | 2 | gtest.cc |
| `cpp/loop-variable-changed` | 2 | gtest.cc |
| `cpp/path-injection` | 4 | gtest.cc |
| **Total** | **32** | **all dependency** |

`licensing.scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway only"`. **Retained; no
in-scope finding; no correction.**

### 3.5 Analyzer — CodeQL MISRA: large focused set (dependency + gtest-macro + out-of-slice production)

Command (`codeql_misra/analyze.command.json`): CodeQL coding-standards pack 2.61.0, suite
`misra-cpp-default.qls`, focused database; **218 queries loaded** (`analyze.stderr`), database-create
and analyze **exit 0**; `scan_runs: 1`; limit *"Focused linked executable, not full target
extraction; dependency findings retained"* (`result.json:121519-121520`). The `findings` array
spans `result.json` lines **1123–121517** and is grouped contiguously by `rule_id`; **`level` is
`null` on every finding** — no tool-suggested Critical/High/Medium/Low rating is carried. The
companion `results.sarif` assigns `ruleIndex` values up to **215** for the last-grouped rules
(`unnecessary-write-to-local-object` 213, `avoid-program-terminating-functions` 214,
`short-circuited-persistent-side-effect` 215), so a very large number of distinct `cpp/misra/*`
query ids produced findings; the artifact retains every occurrence.

**Project-code locations observed in the artifact (the only non-dependency URIs):**

| Native rule id | Located at | In the six paths? |
|----------------|-----------|-------------------|
| `cpp/misra/external-linkage-not-declared-in-header-file-misra` | `score/socom/test/unit/service_identifier_tests.cpp` — many `TEST_F` lines (e.g. `:1171`, `:1191`, …, `:2353`) | **yes** (test file) — gtest macro expansion |
| `cpp/misra/switch-body-compound-condition` | `score/socom/test/unit/service_identifier_tests.cpp` (e.g. `:292`, `:1864`) | **yes** (test file) |
| `cpp/misra/numeric-assignment-type-mismatch` | `service_identifier_tests.cpp` (observed via prior reading; block also dependency) | **yes** (test file) |
| `cpp/misra/no-implicit-bool-conversion` | `score/socom/test/unit/service_identifier_tests.cpp` (e.g. `:84011`) | **yes** (test file) |
| `cpp/misra/appropriate-structure-of-switch-statement` | `service_identifier_tests.cpp` (e.g. `:112001`, `:115009`, `:116513`) | **yes** (test file) |
| `cpp/misra/dynamic-memory-should-not-be-used` | `score/socom/string_registry.hpp:37` (+ dependency + test file) | **no** (production, outside slice) |
| `cpp/misra/local-variable-static-storage-duration` | `score/socom/impl/string_registry.cpp` | **no** (production, outside slice) |
| `cpp/misra/unnecessary-write-to-local-object` | `score/socom/impl/string_registry.cpp:23,35` (+ dependency) | **no** (production, outside slice) |
| `cpp/misra/no-conversion-from-bool` | `string_registry.cpp` (+ dependency) | **no** (production, outside slice) |

**No finding lands in `score/socom/impl/service_identifier.cpp` or
`score/socom/impl/service_identifier.hpp`.** A `grep` for those two paths in
`codeql_misra/result.json` returns nothing (they appear only in the `source_hashes`/tool-path
blocks). **`score/socom/test/unit/runtime_tests.cpp` was not extracted** and therefore has zero
findings only because it was not analysed.

**Additional `cpp/misra/*` rule ids confirmed present this iteration** (grouped blocks; the list is
by rule and scope, not one row per occurrence): `copy-and-move-assignments-shall-handle-self-assignment`,
`identifiers-used-in-the-controlling-expression-of`, `global-variable-used`,
`no-character-numerical-value`, `internal-linkage-specified-appropriately`,
`missing-precedence-clarifying-parenthesis`, `inappropriate-bitwise-or-shift-operands`,
`poorly-formed-identifier`, `legacy-for-statements-should-be-simple`,
`unused-return-value-misra-cpp`, `unsafe-string-handling-functions`,
`avoid-program-terminating-functions`, `short-circuited-persistent-side-effect`.

**Explicit limitation (no filtering).** The MISRA extraction is dominated by `.llm_tmp/googletest/**`
and, per the SARIF `ruleIndex` range, involves a very large number of distinct query ids. This
report enumerates the rules that touch project code and gives examples of dependency rules; it
does **not** reproduce every occurrence. **That is a presentation limit, not a filter** — every
finding remains in `codeql_misra/result.json` / `results.sarif`, none was suppressed or dropped.
The candidate test-file hits are dominated by the gtest `TEST_F` macro expansion (externally-linked
registration entities synthesised by the macro), which cannot be fixed inside the authored test
body; a fix would mean patching the test framework or suppressing the rule, both prohibited, or an
accepted human deviation, which is unavailable here. The `string_registry.cpp` / `string_registry.hpp`
hits are **repository production code but outside the six candidate paths**; per `code_analysis.rst:51`
an unaddressed MISRA finding must be justified in-source, and no such justification exists and
adding one is outside this review's write boundary. Retained blockers (collector): *"MISRA
applicability/mapping draft and incomplete"*, *"Default suite omits manual/audit obligations"*,
*"Compiled query qualifications and human deviations pending"*.

### 3.6 Sanitizers — ASan/LSan/UBSan and memcheck pass; TSan is an environment failure

| Check | Retained result | Reading |
|-------|-----------------|---------|
| `focused_asan_lsan` | compile **exit 0** (`:1091`); tests **exit 0** (`:1115`); **91/91 `[  PASSED  ]`** (`tests.stdout:187-191`); stderr empty | **Pass — focused identifier scope only.** `-fsanitize=address,leak,undefined -fno-sanitize-recover=all`; `ASAN_OPTIONS=detect_leaks=1:halt_on_error=1`, `UBSAN_OPTIONS=halt_on_error=1`. No overflow/UB/leak finding. |
| `focused_memcheck` | compile **exit 0** (`:1089`); memcheck **exit 0** (`:1116`); `memcheck.stderr` empty | **Pass — focused scope only.** Valgrind present; `--leak-check=full --error-exitcode=42`; no memcheck error. |
| `focused_tsan` | compile **exit 0** (`:1090`); tests **exit 66** (`:1114`); `tests.stderr` = `FATAL: ThreadSanitizer: unexpected memory mapping 0x…` | **Environment failure, not a data race.** Known TSan/ASLR kernel-mmapping incompatibility; the focused identifier tests are single-threaded. **Retained environment blocker; no source correction.** |

**Note superseding the earlier prior report.** The earlier report recorded memcheck `exit 127`
(`valgrind` unavailable) and TSan `exit -11`; the retained artifacts for this run show memcheck
`exit 0` and TSan `exit 66` with the mmapping message. The current artifacts govern.

### 3.7 Native / cross / coverage / lint / docs / format / secret legs

| Check | Retained result | Reading |
|-------|-----------------|---------|
| `native_build` | `bazel build --jobs=2 //...` **exit 0**; `status: completed` | broader tree compiles |
| `native_tests` | `bazel test //... --build_tests_only` **exit 0** | **build-only**; not a test run |
| `native_sanitizers` | `--features=asan,lsan,ubsan_clang` **exit 0** | **build-only**; not a run |
| `native_tsan` | `--features=tsan --build_tests_only` **exit 0** | **build-only** |
| `native_traceability` | `unit-component-tests` (`//:unit_tests //:component_tests`) **exit 0**; `docs` **exit 2**; `traceability_gate` **exit 1** | partial: unit/component ran green; docs/traceability gates fail |
| `native_integration` | `--config=qemu-integration //quality/... //tests/integration_test/...` **exit 1** (KVM/QEMU present) | integration gate fails |
| `native_lint` | clang-tidy **exit 124** (timeout); ruff **exit 0** | tool/infra |
| `native_docs` | `//:docs` **exit 2** | docs gate fails |
| `native_coverage` | `bazel coverage //... --build_tests_only` **exit 0**; report **exit 0**; limit *"Repository CI threshold 73 is not platform 85/100 line-and-branch acceptance"* | below platform goal |
| `focused_coverage` | line **36/36 = 100 %**; branch **11/14 = 78.6 %**; `service_identifier.cpp` 3/3 line, **1/2 branch (50 %)**; `string_registry.cpp` 33/33 line, 10/12 branch (83.3 %) | **focused**; branch below safety 100 % / QM 85 % |
| `native_performance` | **exit 124 / exit 124** (timeouts) | tool/infra |
| `cross_compilation` | x86 `--config=x86_64-linux` **exit 0**; arm `--config=aarch64-linux` **exit 0**; blocker *"QNX SDK entitlement and target execution not configured"* | cross-compiles; QNX not exercised |
| `format_precommit` | git-init 0; git-add 0; `//:format.check` **exit 124** (timeout); pre-commit **exit 0**; `reuse lint` **exit 1**; `mod tidy` 0; lockfile 0 | `status: findings_or_execution_failure` |
| `secret_dependency_checks` | gitleaks **exit 1** (findings in the collected `.llm_tmp/overnight/obligations/*/result.json` artifacts themselves, plus `quality/integration_testing/environments/qnx8_qemu/init_x86_64.build`); blocker *"No adopted vulnerability database/ecosystem mapping or GitHub dependency scan receipt; dependency inventory is not a vulnerability scan"* | out of the six paths; no adopted vuln DB |
| `process_checks` | `completed_with_blockers`; metadata inventory: `runtime_tests.cpp` **33 macros**, `service_identifier_tests.cpp` **91 macros**, both with `DerivationTechnique` + `Description`; blockers incl. *"Lexical metadata inventory cannot prove semantic requirement coverage"*, *"Safety/QM applicability and approved tailoring unknown"*, *"Independent inspection and acceptance required"*, *"External AoU and full integration verification require scoped review"* | metadata present; traceability not proven |
| `rework_progress` | `completed`; `source_changed_this_round: false`; `rework_requested: false`; stop reason *"One complete pass requested; unresolved findings stay pending"* | one pass only |
| `tool_assurance` | `completed_with_blockers`; 15 tool version commands all **exit 0** | tool qualification still requires authorized humans |

---

## 4. Severity classification (per `gd_req__verification_sca_classification`)

### 4.1 The governing requirement

`verification_process.rst:228-248` (`gd_req__verification_sca_classification`, `:status: valid`)
requires SCA findings to be classified as **Critical / High / Medium / Low**, where *"the actual
classification shall be either provided by the tool as a suggestion or defined manually by
`rl__quality_manager` together with `rl__committer`."* Alternative ratings (class A–D / 1–4) are
permitted only with the mapping documented.

### 4.2 Tool-suggested ratings actually present

- **CodeQL (security & MISRA): none.** Every retained finding has `"level": null`.
- **Cppcheck: none in the required taxonomy.** Cppcheck emits its own `severity="performance"`
  (all 19 findings), which is **not** a Critical/High/Medium/Low class.
- **Compiler (GCC/Clang): none this run.** Both focused compiles exit `0`; there is no diagnostic.
- **Clang-Tidy: none.** It produced only configuration warnings; it ran no analysis.
- **Sanitizers: none.** ASan/LSan/UBSan and memcheck produced no finding; TSan produced no result.

**There is therefore no tool-suggested Critical/High/Medium/Low rating for any retained finding.**

### 4.3 Authorized ratings

**None.** No `rl__quality_manager` + `rl__committer` classification exists anywhere in the retained
artifacts; `authority.json` records `engineering_acceptance: pending` and `human_reviews:
unanswered`. Every "authorized class" cell below is consequently **none / pending**.

### 4.4 Classification register (suggested = indicative only, not authorized)

The "Indicative class (review aid)" column is a **reviewer's suggestion**, offered only so a human
can begin the mandated classification. It is **not** a tool suggestion and **not** an authorized
rating, and no obligation status may be derived from it.

| # | Native id | Tool / category | Native severity | Scope | Indicative class (review aid, NOT authorized) | Authorized class |
|---|-----------|-----------------|-----------------|-------|-----------------------------------------------|------------------|
| T-1 | 15 unknown-check texts (§3.2) | clang-tidy config | `warning` | repository `.clang-tidy` | Low (tooling/config) | **none / pending** |
| P-1…P-19 | `passedByValue` (CWE 398) | cppcheck | `performance` | `registry_string_view.hpp`, `service_interface_identifier.hpp` (outside the six paths) | Low (performance style) | **none / pending** |
| S-1…S-32 | 11 CodeQL security rule ids (§3.4) | CodeQL security | `level: null` (none) | all dependency (googletest) | Medium–Low (dependency-only, focused extraction) | **none / pending** |
| M-T1 | `cpp/misra/external-linkage-not-declared-in-header-file-misra` | CodeQL MISRA | `level: null` | candidate test file (gtest `TEST_F` macro) | Low (framework macro artifact; needs deviation) | **none / pending** |
| M-T2 | `cpp/misra/switch-body-compound-condition` | CodeQL MISRA | `level: null` | candidate test file | Low | **none / pending** |
| M-T3 | `cpp/misra/no-implicit-bool-conversion` | CodeQL MISRA | `level: null` | candidate test file | Low | **none / pending** |
| M-T4 | `cpp/misra/numeric-assignment-type-mismatch`, `cpp/misra/appropriate-structure-of-switch-statement` | CodeQL MISRA | `level: null` | candidate test file (+ dependency) | Low | **none / pending** |
| M-P1 | `cpp/misra/dynamic-memory-should-not-be-used` | CodeQL MISRA | `level: null` | `string_registry.hpp` (outside slice) + test + dependency | Medium (deliberate container) | **none / pending** |
| M-P2 | `cpp/misra/local-variable-static-storage-duration` | CodeQL MISRA | `level: null` | `string_registry.cpp` (outside slice) | Medium (deliberate singleton) | **none / pending** |
| M-P3 | `cpp/misra/unnecessary-write-to-local-object` | CodeQL MISRA | `level: null` | `string_registry.cpp` (outside slice) + dependency | Low | **none / pending** |
| M-P4 | `cpp/misra/no-conversion-from-bool` | CodeQL MISRA | `level: null` | `string_registry.cpp` (outside slice) + dependency | Medium (needs human disposition) | **none / pending** |
| M-D | remaining `cpp/misra/*` dependency rule ids (§3.5) | CodeQL MISRA | `level: null` | dependency (googletest) | Low–Medium (dependency) | **none / pending** |
| D-1 | gitleaks findings in collected artifacts + `qnx8_qemu/init_x86_64.build` | secret scan | tool default | `.llm_tmp/**` collector artifacts + QNX build file; **not** the six paths | Low / infra | **none / pending** |

**Explicit statement.** The indicative classes above are **not** the mandated classification.
Until a Quality Manager and a committer complete `gd_req__verification_sca_classification`, the
slice has **no authorized finding classification**, and the criterion "freedom from static-analysis
critical/high findings" **cannot be assessed**.

---

## 5. Dependency findings retained (nothing filtered)

All findings whose location is not project code are retained in full in their artifacts; none was
suppressed, dropped, or silently discarded. The dependency/project-adjacent set is:

- **CodeQL security**: all 32 findings — `.llm_tmp/googletest/**` (§3.4).
- **CodeQL MISRA — dependency**: the googletest subset, e.g.
  `copy-and-move-assignments-shall-handle-self-assignment` (`gtest-filepath.h`),
  `avoid-program-terminating-functions`, `short-circuited-persistent-side-effect`,
  `unnecessary-write-to-local-object`, `dynamic-memory-should-not-be-used`,
  `identifiers-used-in-the-controlling-expression-of`, `global-variable-used`,
  `missing-precedence-clarifying-parenthesis`, `legacy-for-statements-should-be-simple`,
  `unused-return-value-misra-cpp`, `unsafe-string-handling-functions`,
  `no-character-numerical-value`, `internal-linkage-specified-appropriately`,
  `inappropriate-bitwise-or-shift-operands`, `poorly-formed-identifier`, `no-conversion-from-bool`
  and others (§3.5).
- **CodeQL MISRA — project code outside the slice**: `string_registry.cpp` /
  `string_registry.hpp` (§3.5).
- **Cppcheck**: the flagged declarations are in project headers
  (`registry_string_view.hpp`, `service_interface_identifier.hpp`) **outside the six candidate
  paths** (§3.3).
- **Secret scan**: findings are in the collected `.llm_tmp/overnight/**/result.json` artifacts and
  one pre-existing QNX test-configuration file (§3.7).

The **reason** these dependency/external findings are retained rather than "resolved" is that the
focused extraction deliberately links the vendored googletest and the `string_registry` unit; the
artifact's own limit records *"dependency findings retained"*. Suppressing them would violate the
instruction never to silently filter findings.

---

## 6. What has no finding, and what was not run (not "clean")

| Unit / check | State | Why this is not "clean" |
|--------------|-------|-------------------------|
| `service_identifier.cpp`, `service_identifier.hpp` | no analyzer finding | CodeQL security is dependency-only; CodeQL MISRA has no hit there; **Clang-Tidy did not run**; extraction focused |
| `runtime_tests.cpp` | **not extracted** | not present in the CodeQL MISRA database; the host measurement compiles only the focused identifier TU |
| `service_identifier_tests.cpp` | findings exist (gtest macro / macro-expanded switch & bool conversions) | cannot be fixed in the authored body without framework patching or an accepted deviation |
| full `//score/...` | analysed only by build; no full SCA verdict | `native_lint` clang-tidy timed out (124); CodeQL extraction is focused |
| Clang-Tidy on changed units | **not run** | `--verify-config` exit 1 (§3.2) |
| TSan | **no result** | environment failure — `unexpected memory mapping` (§3.6) |
| coverage to goal | **not met** | focused branch 78.6 %; native threshold 73 below platform 85/100 |
| MISRA compliance | **not claimed** | `misra_mapping.rst` is `:status: draft`; applicability not established |

---

## 7. Regenerated measurement, key behaviour, and red→green transition

- **Host capture** (`validation/measurement.json`): `check_ref: check_conversion_tests`, `mode:
  ubsan`, changed path `score/socom/test/unit/service_identifier_tests.cpp`, `origin:
  local_unprotected_measurement`, `initiator: Fabro host hook`, `engineering_acceptance: pending`,
  `full_native_tests: not_executed`, compiler `/usr/bin/x86_64-linux-gnu-g++-12`
  (`compiler_sha256 88315fd2d961a1f4e4070b104d7bd4c7670df19d9949409879ba269466c196d3`).
  `baseline_with_agent_tests`: **compile_exit 0, test_exit 1, tests 91, failures 33, disabled 0**.
  `candidate`: **compile_exit 0, test_exit 0, tests 91, failures 0, disabled 0**.
- **`validation/check-result` = `0`** is a *retention* marker, not a pass marker.
- **`after.json`** = 91 tests / 0 failures / 0 disabled / 0 errors; `after-test.stdout` ends
  `[  PASSED  ] 91 tests.`; `before.json` = 91 tests / **33 failures**, with the failing minor-only
  cases named in §1.4. This is the red→green transition of the key change.
- **Key identity (source-derived):** `std::set` uniqueness is `!(a<b) && !(b<a)`; `operator<`
  compares `(instance, service id, major)` with `minor` excluded
  (`score/socom/impl/service_identifier.cpp:28-29`), so a second registration differing only in
  `minor` is rejected with `Construction_error::duplicate_service`, matching the minor-ignoring
  `Service_database` index. On a key that included `minor` the minor-only cases would fail — as the
  pre-correction baseline capture shows (33 failures).
- **Test inventory (read, not run in this iteration):** `service_identifier_tests.cpp` = **91
  `TEST_F`** (`process_checks/result.json:1071-1079`); `runtime_tests.cpp` = **33 macros** (1
  `TEST` + 31 `TEST_F` + 1 `TEST_P`). Both suites are compiled/run only within the focused
  identifier executable here; `runtime_tests.cpp` was not extracted by CodeQL.
- **Scope:** local, unprotected, scoped. This report is not acceptance, review, publication, or a
  full native run.

---

## 8. Obligations status (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Freedom from compiler warnings & errors (100 %) | `verification_plan.rst` (criterion 9) | **PARTIAL, LOCAL** — focused GCC and Clang compiles exit 0 under `-Werror`; candidate 91/0 in the retained host capture; not a native full-target warnings-as-errors run of the whole tree |
| SCA findings classified Critical/High/Medium/Low | `verification_process.rst:228-248` | **NOT DONE** — no tool-suggested class; no authorized QM+committer classification |
| Static code analysis (clang-tidy / CodeQL / Cppcheck) executed and classified | `code_analysis.rst`; `verification_process.rst` | **NOT SATISFIED** — clang-tidy not run (config rejected / native timeout); cppcheck findings out of scope; CodeQL security dependency-only; CodeQL MISRA draft applicability + gtest-macro hits needing human deviation |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` (draft) | **UNKNOWN — NOT CLAIMED** — mapping `:status: draft`; human deviations pending |
| Structural statement / branch coverage goals | `verification_plan.rst` (criteria 1–2) | **NOT MEASURED TO GOAL** — focused 100 % line / 78.6 % branch; native threshold 73 is not platform 85/100 |
| Unit/component testing executed, results recorded | `verification_plan.rst` (criteria 6–7); `verification_guideline.rst` | **PARTIAL, LOCAL** — `unit-component-tests` exit 0; focused candidate 91/0; `full_native_tests: not_executed` |
| Sanitizer / concurrency checks | `code_analysis.rst` | **PARTIAL / BLOCKED** — ASan/LSan/UBSan and memcheck pass (focused); TSan environment failure |
| Interface / requirements-based / resource / fault-injection test types | `verification_process.rst`; `verification_plan.rst` | **NOT PERFORMED / applicability not inferred** — identifier-only tests must not be labelled platform validation |
| Fuzzy testing technique | `verification_plan.rst` | **NOT EXECUTED / NOT CLAIMED** — no harness, no measurement |
| Linking tests to requirements (record properties) | `verification_process.rst` (`gd_req__verification_link_tests_cpp`) | **PARTIAL / NOT DONE** — `DerivationTechnique`/`Description` recorded; `TestType`/`Verifies` cannot be set without inventing identifiers |
| External-component AoUs verified | `verification_process.rst` (`gd_req__verification_external_aou`) | **NOT SATISFIED** — no integration/static verdict; no AoU register |
| Independence of verification / review by a different committer | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Implementation inspection checklist IMPL_01…IMPL_03 | `inspection_checklist.rst` (draft) | **NOT FILLED** |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED for this slice** — clang-tidy unusable (config/timeout); docs/traceability/perf legs failing; tool-chain pins not demonstrated |
| Obligation collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **RETAINED, NOT PASSING** — 25 checks present; blockers above |
| Native acceptance | `source-index.json` | **`not_inferred` for every entry** |

**Explicit non-satisfaction statement.** Missing/unstable tooling (clang-tidy config + timeout,
`format.check` timeout, docs/traceability gates, performance timeouts, QEMU integration), the
unknown safety class and un-inferred applicability, incomplete extraction (focused translation
units; dependency findings retained), below-goal branch coverage, the draft MISRA mapping, and the
unanswered human reviews mean **none of the checked obligations may be treated as satisfied**. A
retained collection result shows *retention*, not passing.

---

## 9. Notice preservation

- No source, build, test, config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was created, edited, or
  deleted by this iteration; **only this report was written.** Every existing Apache-2.0 / SPDX
  notice header is untouched.
- The header the task flagged (`score/socom/impl/service_identifier.hpp`) retains its
  Apache-2.0/SPDX header (`:1-12`) and was left unchanged because it is already balanced (§2). The
  sibling `service_identifier.cpp` (`:1-12`), both BUILD files, and both candidate test files
  likewise retain their Apache-2.0/SPDX headers.
- All 38 files under `.llm_tmp/overnight/prior-reports/` and every earlier file under
  `.llm_tmp/overnight/reports/` were preserved unchanged; the earlier
  `prior-reports/finding_classification.md` was **not** overwritten.
- This report itself carries the Apache-2.0 header. No licensed MISRA rule text is reproduced; only
  native rule/query identifiers, file locations, and retained-artifact readings are cited.

---

## 10. Pending human review checklist

- [ ] **Confirm §2:** the header is brace-balanced (brace lines `:19`, `:29`, `:32`, `:38`; line
      `:39` blank; single nested close `}  // namespace score::socom`); the focused GCC/Clang
      compiles are exit `0`. The recorded "extra closing brace at line 39" is stale. If a distinct
      "cancelled draft" still carries the brace, locate and correct it by an authorized iteration;
      no such file exists in this checkout.
- [ ] **Resolve the instruction conflict:** correct-the-source vs. review-draft-only; confirm that
      writing only this report was intended.
- [ ] **Complete the mandated classification** (`gd_req__verification_sca_classification`): have
      the Quality Manager together with a committer assign Critical/High/Medium/Low to the
      register in §4.4. Treat the indicative classes as review aids only.
- [ ] **Repair and run Clang-Tidy (T-1):** unfold the `.clang-tidy` `Checks: >` block so `#`
      comments are not folded into check names; re-evaluate `clang-analyzer-alpha.security.ArrayBoundV2`
      and `modernize-use-integer-sign-comparison` for the pinned version; do not suppress checks
      inside this slice.
- [ ] **Disposition the Cppcheck findings (P-1…P-19)** in `registry_string_view.hpp` and
      `service_interface_identifier.hpp` as acceptable performance style or a separate change.
- [ ] **Disposition the CodeQL MISRA test-file findings (M-T1…M-T4)** as gtest macro artifacts:
      record an accepted deviation or adopt macro-aware tooling; do not patch the test framework or
      silently suppress the rules.
- [ ] **Disposition the CodeQL MISRA production findings (M-P1…M-P4)** in `string_registry.cpp` /
      `string_registry.hpp` (outside this slice): justify in-source per `code_analysis.rst:51`,
      refactor, or record an accepted deviation.
- [ ] **Decide the CodeQL posture:** run a full-target extraction (not a focused executable) that
      includes `runtime_tests.cpp` and the remaining units, and qualify the compiled queries.
- [ ] **Complete and activate the MISRA mapping** (`misra_mapping.rst`): supply
      `_assets/misra_2023.csv`, uncomment the `csv-table`, and raise `:status` to `valid` by an
      authorized change; until then no rule applicability may be stated.
- [ ] **Stabilize the blocked legs:** the `format.check` timeout, `//:docs` exit 2,
      traceability-gate exit 1, performance timeouts, QEMU integration exit 1, and the
      cross-compilation QNX blocker (§3.7), so they become results rather than blockers.
- [ ] **Provide a TSan-capable environment or an accepted exclusion** (§3.6).
- [ ] **Raise branch coverage to the selected goal** and run the full native suite
      (`bazel test //score/socom/test/unit:socom_test` and the broader `//score/...` set),
      recording results including `runtime_tests.cpp`.
- [ ] **Supply native requirement/interface identifiers** for traceability links, or record
      applicability as unresolved (no invented links).
- [ ] **Select the safety class**, schedule independent human review (approver ≠ author,
      `gd_req__verification_independence`), and record engineering acceptance; no compliance claim
      may be made before that.
- [ ] **Keep the wider #84 public `Service_interface_identifier` restructure, FindService wildcard
      handling, and the config minor-wildcard narrowing out of this bounded slice** until
      separately accepted; do not present the identifier-only tests as platform validation or claim
      an unmeasured fuzzy technique.

---

*End of finding-classification review draft. Local, unprotected, scoped. No engineering acceptance;
human reviews unanswered; full native runtime tests pending. No MISRA C++:2023 compliance is
claimed, no finding is filtered, and no authorized severity rating exists.*
