<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — identifier-conversion boundary coverage (`conversion_tests`) — iteration record

**Document type:** review draft (actual-source inspection + conversion-boundary coverage
addition + honest iteration/measurement record).

**Date:** 2026-10-03
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version handling
in socom*; this report covers the **identifier-conversion boundary** of that slice.
**Run / branch:** `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ`
**Verified baseline commit:** `f8a196c3b16d5172d898394ab99b0ed81346d63d`
(`.llm_tmp/context/source-manifest.json:3`).
**Status:** local, unprotected, scoped. **No engineering acceptance exists. Human reviews
are unanswered. Full native runtime tests remain pending.** Every expectation below is a
direct static reading of this checkout at the baseline-bound candidate paths, a retained
local host reading, or an explicitly-labelled logical consequence. Nothing here is
acceptance, review, publication, or a full native run.

> **Tool / write boundary actually observed.** Only `read_file`, `grep`, `glob` and
> `write_file` were used. No `shell`, no delegation, no web access, no approval, no
> publishing, and no engineering acceptance was performed. A single attempt to use
> `edit_file` on `score/socom/test/unit/service_identifier_tests.cpp` was refused by the
> environment (`Overnight tool/path boundary`) and changed nothing; the candidate test file
> was therefore re-emitted in full with `write_file`, exactly as the earlier
> `conversion_tests` iteration did. This iteration wrote **exactly two files**: the candidate
> test file `score/socom/test/unit/service_identifier_tests.cpp` (four boundary cases added)
> and this report. No other candidate source path — not
> `score/socom/impl/service_identifier.hpp`, `score/socom/impl/service_identifier.cpp`, either
> `BUILD` — and no `NOTICE`, `LICENSE`, `REUSE.toml`, config, or prior-report file was
> created, edited, or deleted. All prior reports were read and preserved.
>
> **The recorded syntax failure is not present in the actual source, and the latest host
> feedback contradicts it.** The task records *"a measured GCC syntax failure: an extra
> closing brace in `score/socom/impl/service_identifier.hpp` at line 39."* Direct
> `read_file` + `grep` (§2) show the header is **brace-balanced** (brace-bearing lines `:19`,
> `:29`, `:32`, `:38`; line `:39` blank; `:40` `#endif`), and the retained local host
> capture (`.llm_tmp/overnight/validation/`) records the **candidate compiling with
> `compile_exit: 0` and 87 tests / 0 failures** (`after.json`, `measurement.json`,
> `check-result` = `0`). There is therefore **no actual source to correct**; the described
> defect matches the stale, pre-correction split-namespace form quoted by the earliest prior
> reports. Re-introducing a break so it could be removed would be a regression, so the header
> was left untouched. The minimal historical repair is retained in §2.3 for reference only.
>
> **Non-satisfaction rule applied throughout.** A successful obligation-collection node means
> results were **retained**, not that checks **passed**. Missing tools, unknown applicability,
> incomplete extraction, a draft rule mapping, and unanswered human reviews are **not** treated
> as satisfied (§7). The retained host capture measured the **previous 87-case** file and does
> **not** cover the four cases added here.

---

## 0. Summary

1. **Recorded syntax failure — inspected; not present.** `score/socom/impl/service_identifier.hpp`
   is brace-balanced: openers `:19` (`namespace score::socom {`) and `:29`
   (`struct Service_instance_identifier final {`), closers `:32` (`};`) and `:38`
   (the single `}  // namespace score::socom`); net balance `0`; line `:39` is blank and `:40`
   is `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER`. The latest local host capture records
   candidate `compile_exit: 0` and 87/87 green, confirming the claim is stale. **No header edit
   was made and none is required** (§2).
2. **Identifier-conversion boundary coverage was added.** Four new deterministic cases were
   appended to `score/socom/test/unit/service_identifier_tests.cpp` (`:2060`, `:2103`, `:2144`,
   `:2175`), bringing the file from **87** to **91** `TEST_F` cases: a full 4×4 public
   interface-path × instance-path conversion cross product at every 16-bit version boundary; the
   uint32→uint16 configuration-minor narrowing boundary matrix; and first-time dynamic
   insertion through `instance_id_registry()` for both the `string_view` and `std::string&&`
   overloads (§3).
3. **The pre-existing 87 cases were preserved, not rewritten.** Every original `TEST_F` remains
   at its original line number (the first 87 cases still occupy `:168`…`:2012`; the fixture
   helpers are unchanged at `SetUp():42`, `equivalent():104`, `identity_of():86`,
   `registration_key_boundary_domain():139`). The four new cases follow the original final case
   at `:2012`; the file still ends with `}  // namespace score::socom` (now `:2205`).
4. **Public-interface identity is preserved.** No production source was touched. The public
   `Service_interface_identifier` / `Version` representation and its `operator==` / `operator<`
   / `std::hash` are unchanged and still distinguish `major` and `minor`, while the internal
   registration key still ignores `minor` (`service_identifier.cpp:28-29`) (§4).
5. **No obligation is satisfied.** No build or test ran in this iteration; the four new cases
   are locally **unmeasured**. The pinned obligation entries are
   `"native_acceptance": "not_inferred"`; `authority.json` records
   `engineering_acceptance: pending`, `human_reviews: unanswered`, `safety_class: unknown`.
   The retained host capture covers only the previous 87-case state (§6, §7).

---

## 1. Binding to the baseline, issue, prior reports, host feedback and obligations

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` | `.llm_tmp/context/issue-snapshot.json:2-4` |
| Title | *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:3` |
| State | `open`, **0 comments**, no milestone / assignee / labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` (unchanged) | `.llm_tmp/context/issue-snapshot.json:19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**. It distinguishes service-instance identifier = `service id + major + minor +
instance id`, service identifier = `service id + major`, and FindService = `service id +
major + optional<minor> + optional<instance>`, and proposes to "exclude the minor version
and make it a property of the service instance". There is **no comment and no acceptance
record** in the snapshot, so none of it is binding. Binding is **by baseline commit**, not
by run HEAD.

### 1.2 Verified baseline and current tree

| Item | Value | Source |
|------|-------|--------|
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |
| Working branch | `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ` | run environment |

Binding is **by baseline commit**, not by run HEAD; earlier reports reference other run IDs
on the same baseline commit and remain admissible prior evidence. No hashing tool is
available in this task, so the working tree was **not** re-hashed; the direct source reads
in §2–§4 are authoritative for this report.

### 1.3 In-scope candidate files (the only writable source paths)

From `.llm_tmp/context/candidate-files.json:1-25`:

| File (repo-relative) | Baseline git blob | This iteration |
|----------------------|-------------------|----------------|
| `score/socom/BUILD` | `3477ea0851fdcd82ec6ea9d71424013cbdf41962` | inspected, **unchanged** |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e22355242009fe20dada2a9a0d0c7a9c7` | inspected, **unchanged** (key identity `(instance, id, major)`, `:28-29`) |
| `score/socom/impl/service_identifier.hpp` | `c8bae7908da9f087c518934f7b9f8d86db9a20ec` | inspected, **unchanged** (already brace-balanced, §2) |
| `score/socom/test/unit/BUILD` | `3c03a7b14286051f97fa5022206564bd63645171` | inspected, **unchanged** (`socom_test` globs `*.cpp`, deps wired) |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab726db8bf994c960045d6fd7fdf84d7395` | inspected, **unchanged** |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(none — `null`)* | **changed — four conversion-boundary cases added (§3)** |

The `null` baseline blob for `service_identifier_tests.cpp` is the manifest's expectation
of a **new** unit-test file; it exists on disk only as part of the un-merged working tree
(the "cancelled draft"), never in the baseline. `glob **/service_identifier*` returns
exactly three paths (`impl/service_identifier.cpp`, `impl/service_identifier.hpp`,
`test/unit/service_identifier_tests.cpp`), so there is **no second, differently-braced
copy** of the header in this checkout.

### 1.4 Pinned obligation sources and authority (all read this iteration)

All nine entries of `.llm_tmp/context/obligations/source-index.json` were read from
`.llm_tmp/context/obligations/`, together with `authority.json`. Every entry is pinned
`"native_acceptance": "not_inferred"` — pinned, but its applicability to this slice is
**not inferred**.

| id | pinned file | status / safety (re-read) |
|----|-------------|---------------------------|
| `coding_guidelines` | `coding_guidelines.rst` | `:status: valid`, `:safety: ASIL_B`; MISRA C++:2023 with C++17 |
| `code_analysis` | `code_analysis.rst` | `:status: valid`, `:safety: ASIL_B`; clang-tidy + gcc/clang warnings + Coverity; sanitizers; gcov/gcovr |
| `misra_mapping` | `misra_mapping.rst` | **`:status: draft`**, `:safety: ASIL_B`; the rule table is not a valid obligation |
| `verification_plan` | `verification_plan.rst` | `:status: valid`, `:safety: ASIL_B`; quality criteria 1–9 (criterion 9 = freedom from compiler warnings & errors, 100 %) |
| `development_plan` | `development_plan.rst` | `:status: valid`, `:safety: ASIL_B`; C++17, GCC host compiler, QCC target, Bazel |
| `tool_management` | `tool_management.rst` | `:status: valid`, `:safety: ASIL_B`; tools identified / evaluated / qualified by a human |
| `verification_process` | `verification_process.rst` | `:status: valid`; `gd_req__verification_link_tests_cpp`, `_independence`, `_checks`, `_checks_extended`, `_external_aou`, `_sca_classification` |
| `verification_guideline` | `verification_guideline.rst` | `:status: valid`; traceability, independence, documented results |
| `inspection_checklist` | `inspection_checklist.rst` | **`:status: draft`**, `:safety: ASIL_B`; blank `IMPL_01_01`…`IMPL_03_02` template |

**Authority record** (`.llm_tmp/context/obligations/authority.json`):

| Field | Value |
|-------|-------|
| `engineering_acceptance` | **pending** |
| `human_reviews` | **unanswered** |
| `safety_class` | **unknown** |
| `codeql_scope` | `Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload` |
| `instruction` | *"Restart the failed queue for one complete pass through all obligations"* |

**Safety-class note (recorded, not resolved).** The pinned platform documents carry
`:safety: ASIL_B`, while `authority.json` records `safety_class: unknown` and no authorized
selection exists. The document attribute is **not** a selection of the slice's safety class
and must not be inferred as one.

### 1.5 Prior reports and the retained host feedback available in this checkout

- **`.llm_tmp/overnight/prior-reports/` — 38 files present**, read/cross-checked and
  preserved, including `scope.md`, `invariants.md`, `callsites.md`, `reproducer.md`,
  `key_fix.md`, `unit_matrix.md`, `ordering_tests.md`, the prior `conversion_tests.md`,
  `runtime_disabled.md`, `runtime_enabled.md`, `lifetime_tests.md`, `test_metadata.md`,
  `coverage_review.md`, `coverage_tests_repair.md`, `finding_classification.md`,
  `misra_applicability.md`, `misra_manual_review.md`, `tool_findings_repair.md`, and the
  review hand-off set. None was modified.
- **`.llm_tmp/overnight/reports/`** holds the earlier reports of this run
  (`scope.md`, `callsites.md`, `invariants.md`, `key_fix.md`, `reproducer.md`,
  `unit_matrix.md`, `ordering_tests.md`, `runtime_disabled.md`, `runtime_enabled.md`,
  `lifetime_tests.md`); this document adds `conversion_tests.md`.
- **Host feedback is present in this checkout** under `.llm_tmp/overnight/validation/`:
  `measurement.json` (`check_ref: check_lifetime_tests`, `status: completed`, `mode: plain`,
  `origin: local_unprotected_measurement`, `initiator: Fabro host hook`,
  `engineering_acceptance: pending`, `full_native_tests: not_executed`, compiler
  `/usr/bin/x86_64-linux-gnu-g++-12`), a `before.json` (87 tests / **30 failures**) and
  `after.json` (87 tests / **0 failures**) report in JUnit style, the compile/test command +
  stdout/stderr captures, and `check-result` = `0`. The `after-compile.stderr` and
  `before-compile.stderr` captures are empty. This is a **local, unprotected, scoped** capture
  of the focused identifier translation unit (`service_identifier.cpp` + `string_registry.cpp`
  + `service_identifier_tests.cpp`) and it **predates** the four cases added here.
- **Obligation-collection results are absent here.** `glob .llm_tmp/overnight/obligations/**`
  returns nothing; no `*/result.json` exists. Per the task rule, a collection node that
  retained results would show only *retention*, not passing; here nothing is retained, so
  nothing may be treated as satisfied on that basis.

### 1.6 Derived sequence of the preserved reports (all on baseline `f8a196c3…`)

`scope.md` (bounded the slice; identified the key/index identity gap) → `invariants.md`
(I-1…I-16) → `callsites.md` (call-site map) → `reproducer.md` (key-level regression,
test-only header exposure, and the header brace correction that left line 39 blank) →
`key_fix.md` / `unit_matrix.md` (drop `minor` from the ordering; expand key tests) →
`ordering_tests.md` / `conversion_tests.md` → `runtime_disabled.md`, `runtime_enabled.md`,
`lifetime_tests.md` (runtime regressions, never natively executed) → `test_metadata.md` →
later host-side iterations (coverage, finding classification, MISRA applicability,
tool-findings repair) → review artifacts (`design_inspection_draft.md`, `deviation_drafts.md`,
`security_review.md`, `tool_assurance_review.md`, `integration_aou_review.md`,
`traceability_review.md`, `evidence_inventory.md`, `independent_review_handoff.md`,
`review_packet.md`, `verification_report_draft.md`).

---

## 2. Recorded syntax failure: inspection of the actual source

### 2.1 Finding (re-verified this iteration by direct `read_file` + `grep`)

`score/socom/impl/service_identifier.hpp` is **brace-balanced**. It is exactly 40 lines; a
`grep` for a brace character (`[{}]`) returns exactly four matches:

| Line | Content | Role |
|------|---------|------|
| 14 | `#ifndef SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard begin |
| 15 | `#define SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard define |
| 17 | `#include "score/socom/service_interface_identifier.hpp"` | include |
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 21–28 | doc comment | states `minor` is intentionally not part of the identity |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 30 | `Service_interface_identifier interface;` | member |
| 31 | `Service_instance instance;` | member |
| 32 | `};` | closes the struct |
| 34 | `/// \cond` | doc guard |
| 35 | `bool operator<(Service_instance_identifier const& lhs, Service_instance_identifier const& rhs);` | the single operator declaration |
| 36 | `/// \endcond` | doc guard |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`) and two closers (`:32`, `:38`): net brace balance is `0`. There is
**no third, unmatched closing brace**, and line 39 contains no text at all. The sibling
`score/socom/impl/service_identifier.cpp` uses the same nested form (`:18` / `:32`) and is
balanced. The task's *"extra closing brace … at line 39"* therefore matches a **stale,
pre-correction description** (the earliest prior reports quote the split form
`}  // namespace socom` + `}  // namespace score`). The `reproducer` iteration records the
correction; every later prior report records the header as already balanced — which is what
the actual source shows in this checkout today.

### 2.2 Corroboration by the retained host feedback

The retained local capture **contradicts the syntax-failure premise directly**:

- `measurement.json` — candidate `compile_exit: 0`, `test_exit: 0`, `tests: 87`,
  `failures: 0`, `disabled: 0`; `origin: local_unprotected_measurement`,
  `initiator: Fabro host hook`, `engineering_acceptance: pending`,
  `full_native_tests: not_executed`.
- `after.json` — `87` tests, `0` failures (`ServiceInstanceIdentifierTest`), line-anchored to
  the same test names and line numbers as this file's first 87 cases.
- `after-compile.stderr` / `before-compile.stderr` — empty.
- `check-result` — `0`.

A surviving unmatched closing brace in a header compiled into `service_identifier.cpp` and
`service_identifier_tests.cpp` would have made `compile_exit` non-zero and prevented the test
binary from running. The capture therefore shows the candidate header compiles. **The
artifacts are local, unprotected and scoped** — this is *not* an acceptance or a full native
run — but it is the latest host feedback and it agrees with the direct brace-balance reading.

### 2.3 Minimal historical repair (reference only; NOT applied)

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

Applying this to the already-balanced file would be a no-op; deleting a brace would *create*
the reported defect. **No source edit was made to the header.**

### 2.4 Disposition

The instruction's precondition ("inspect and correct the actual source before expanding
tests") is satisfied without a source write: there is nothing to correct, and the explicit
"smallest correct change to already-correct source is no change" rule applies. If the
*"cancelled draft"* is a different revision that still carries the extra brace, it is **not**
the file in this checkout and must be located and corrected by an authorized iteration; this
report records the discrepancy for human disposition rather than speculating.

---

## 3. Identifier-conversion boundary coverage added

### 3.1 The conversions under test (unchanged semantics)

The duplicate-server key is
`Service_instance_identifier { Service_interface_identifier interface; Service_instance
instance; }` (`score/socom/impl/service_identifier.hpp:29-32`), with the out-of-line
`operator<` (`:35`) defined as (`score/socom/impl/service_identifier.cpp:28-29`):

```cpp
return std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major) <
       std::tie(rhs.instance, rhs.interface.id, rhs.interface.version.major);
```

Therefore the `std::set` equivalence is exactly `(instance, service id, major)` and the
**minor version is excluded**. The public
`Service_interface_identifier{Id id; Version{std::uint16_t major; std::uint16_t minor;}}`
representation and its `operator==` / `operator<` / `std::hash`
(`score/socom/service_interface_identifier.hpp:74-190`) are **unchanged** and still include
`minor`.

The reachable conversions covered are:

1. **Text/registry → public identifier** (`Service_interface_identifier` and
   `Service_instance` from `Registry_string_view`, `string_view`, `string_view + Literal_tag`,
   and `std::string&&`; `service_interface_identifier.hpp:35-55,96-124`).
2. **Public identifier + instance → internal key** (`Service_instance_identifier`, keeping
   `(instance, id, major)` and dropping `minor` from the identity;
   `impl/service_identifier.hpp:29-32`).
3. **Config widths → `Version`** (uint8 major widened losslessly; uint32 minor narrowed to
   uint16, including the `0xFFFFFFFF` wildcard; per the call-site map).

### 3.2 Cases added this iteration

Four deterministic cases were appended to `score/socom/test/unit/service_identifier_tests.cpp`
(the file now has **91** `TEST_F` cases; the four new ones are at `:2060`, `:2103`, `:2144`,
`:2175`):

| Line | New case | Boundary pinned |
|------|----------|-----------------|
| 2060 | `ConvertedInterfaceAndInstanceConstructionPathsAgreeAcrossFullCrossProduct` | The **full 4×4 cross product** of the four public `Service_interface_identifier` construction paths (registry `Id`, `string_view`, `string_view + Literal_tag`, `std::string&&`) and the four public `Service_instance` construction paths, at `major × minor ∈ {0, 0x7FFF, 0x8000, 0xFFFF} × {0, 0x7FFF, 0x8000, 0xFFFF}`. Every combination must resolve to the same public identity and the same `(instance, service id, major)` registration-key identity (64 version pairs × 16 combinations). |
| 2103 | `ConvertedConfigMinorNarrowingBoundariesCollapseAndDistinguish` | The uint32→uint16 configuration-minor narrowing transition boundaries: `0x00000000→0x0000`, `0x00000001→0x0001`, `0x0000FFFF→0xFFFF`, `0x00010000→0x0000`, `0x00010001→0x0001`, `0x7FFFFFFF→0xFFFF`, `0x80000000→0x0000`, `0xFFFFFFFF→0xFFFF`. Values sharing the low 16 bits convert to the same `Version` and the same key; the eight config values leave exactly three distinct key identities (`0x0000`, `0x0001`, `0xFFFF`). The wildcard is pinned only as a boundary — its semantics remain open. |
| 2144 | `FreshDynamicInstanceIdStringViewRegistersAndCollapses` | First-time `instance_id_registry().insert(std::string_view)` for a freshly allocated instance text (the "not found" branch), then a second insertion resolving to the same registry view, and the two minor variants collapsing to one registration key with identity `(instance, service id, major)`. |
| 2175 | `FreshDynamicInstanceIdRvalueRegistersAndCollapses` | The same first-time branch for `instance_id_registry().insert(std::string&&)`, with the two minor variants collapsing to one key (major `3` to avoid any name/identity collision with the `string_view` case). |

All four cases use only APIs and idioms already present in the file (`make_registration_key`,
`service_id_registry()` / `instance_id_registry()`, `String_registry`, `Literal_tag`,
`equivalent`, `identity_of`), and they only pin existing conversion behaviour — they do not
decide any of issue #84's open questions. The per-run counter suffix used by the two dynamic
cases guarantees the inserted text is absent from the process-wide registry on first insertion.

### 3.3 Preservation of the pre-existing 87 cases

The 87 pre-existing `TEST_F` cases were preserved, not rewritten. Evidence: every original
`TEST_F` line number is unchanged in the new file — the pre-existing cases still occupy
`:168`…`:2012`, exactly matching the original count of 87 and the retained host capture's
per-case listing (`after.json`). The fixture helpers are unchanged at `SetUp():42`,
`identity_of():86`, `equivalent():104`, `registration_key_domain():115`,
`registration_key_boundary_domain():139`, and the file-local `make_registration_key` helper is
unchanged at `:777`. The four new cases begin at `:2060` (after the original final case at
`:2012`), and the file still ends with `}  // namespace score::socom` (now `:2205`). The
`edit_file` refusal is recorded in the header note; the whole file was re-emitted with
`write_file`.

---

## 4. Public-interface identity preserved

- No production source was modified. No public header was modified. The public
  `Service_interface_identifier` / `Version` representation and its `operator==` /
  `operator<` / `std::hash` still distinguish `major` **and** `minor`, while the internal
  registration key still ignores `minor` (`service_identifier.cpp:28-29`).
- The conversion cases deliberately pair the **public** identity (which must keep
  distinguishing `major` and `minor`) with the **internal key** (which must collapse `minor`),
  so a change that wrongly leaked the key's minor-exclusion into the public type would be
  caught (e.g. `PublicIdentifierIdentityDistinguishesMajorAndMinorBoundaries` at `:784`).
- The new cross-product and dynamic-registry cases compare the four public construction paths
  by `operator==` / `std::hash` and compare the converted keys by set-equivalence, so both the
  public identity and the internal identity boundary are pinned.
- Any future implementation in this slice must carry the Apache-2.0 header on new files; the
  candidate `service_identifier_tests.cpp` already carries it (lines 1-12).

---

## 5. Files changed / state of the six candidate paths

| Candidate path | State | This iteration |
|----------------|-------|----------------|
| `score/socom/impl/service_identifier.hpp` | brace-balanced, nested namespace, documents minor exclusion | **unchanged** (inspected, §2) |
| `score/socom/impl/service_identifier.cpp` | `operator<` identity `(instance, id, major)`, minor excluded | **unchanged** |
| `score/socom/BUILD` | `testonly impl_service_identifier` exposure present | **unchanged** |
| `score/socom/test/unit/BUILD` | `socom_test` globs `*.cpp`, deps wired | **unchanged** |
| `score/socom/test/unit/runtime_tests.cpp` | minor-only duplicate regression present | **unchanged** |
| `score/socom/test/unit/service_identifier_tests.cpp` | 91-case key matrix (87 preserved + 4 conversion-boundary cases) | **changed** |
| `.llm_tmp/overnight/reports/conversion_tests.md` | **new — this report** | written |

No file outside the six candidate paths and this report was written; no `NOTICE`,
`LICENSE`, or `REUSE.toml` file was created, edited, or deleted; all prior reports were
preserved.

---

## 6. Measurement and validation status

- **Tools:** `read_file`, `grep`, `glob`, `write_file` only. One `edit_file` attempt was
  refused by the environment (`Overnight tool/path boundary`) and changed nothing; no `shell`,
  delegation, web, approval, publishing, or engineering acceptance.
- **Executed measurements:** **none** this iteration. No build, no `bazel test`, no runtime.
  The header brace census (§2), the key identity (§3.1), and the expected behaviour of the new
  cases (§3.2) are static source readings and strict-weak-ordering consequences, not observed
  results.
- **The added cases are unmeasured.** The new file could not be compiled or executed in this
  iteration, so it is a source-only change. Whether the four new cases compile and pass is
  **unknown** until an authorized build/test run is performed. The retained host capture
  (`.llm_tmp/overnight/validation/`) measured the **previous 87-case** file (`after.json`:
  87 tests / 0 failures; `before.json`: 87 / 30; `check-result` 0) and does **not** cover the
  added cases; the recorded hash of `service_identifier_tests.cpp` in `measurement.json`
  (`4df2c63c…`) therefore no longer matches the expanded file. The retained capture's hash
  scheme also differs from the `sha256` values in `.llm_tmp/context/candidate-files.json`, so
  the two are not directly comparable.
- **Test inventory (read, not run):** `service_identifier_tests.cpp` = **91 `TEST_F`** under
  `ServiceInstanceIdentifierTest` (87 preserved at `:168`…`:2012`; 4 added at `:2060`,
  `:2103`, `:2144`, `:2175`), verified by `grep`. `runtime_tests.cpp` has **1 `TEST` + 31
  `TEST_F` + 1 `TEST_P`** and is untouched.
- **Regression target (source-derived, not executed):**
  `RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError`
  (`runtime_tests.cpp:402-431`) and the key-level minor-collapse cases
  (`service_identifier_tests.cpp:174`, `:182`, `:192`, `:203`, …) assert that a second
  registration differing only in `minor` is rejected as `duplicate_service`. On a key that
  includes `minor` they fail (`before.json`: 30 failures); on the working-tree key they pass
  (`after.json`: 0 failures). These are host readings of the previous 87-case file, not an
  execution of this iteration's file.
- **Scope:** local, unprotected, scoped. This is a bounded coverage/verification record, not
  an accepted engineering decision. Full native runtime tests and human review remain pending.
- **Reproduction path for a later, permitted iteration (not executed here):**

  ```bash
  bazel test //score/socom/test/unit:socom_test
  # focused key-level, including the new conversion-boundary cases:
  bazel test //score/socom/test/unit:socom_test --test_filter='ServiceInstanceIdentifierTest.*'
  # the four newly added cases:
  bazel test //score/socom/test/unit:socom_test \
      --test_filter='ServiceInstanceIdentifierTest.ConvertedInterfaceAndInstanceConstructionPathsAgreeAcrossFullCrossProduct:ServiceInstanceIdentifierTest.ConvertedConfigMinorNarrowingBoundariesCollapseAndDistinguish:ServiceInstanceIdentifierTest.FreshDynamicInstanceIdStringViewRegistersAndCollapses:ServiceInstanceIdentifierTest.FreshDynamicInstanceIdRvalueRegistersAndCollapses'
  # integration / cross / docs / traceability (per the pinned plans)
  bazel test --config=qemu-integration //tests/integration_test/...
  ```

  Expected on the working-tree key: every construction path of each component resolves to the
  same public identity and the same registration key; the eight config minors leave exactly
  three key identities; the dynamic instance insertions register once and collapse. These
  expectations are source-derived, not measured.

---

## 7. Obligations status (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Freedom from compiler warnings & errors (100 %) | `verification_plan.rst` (criterion 9) | **NOT MEASURED** — header is brace-balanced by inspection and the retained capture shows candidate `compile_exit: 0`, but nothing was compiled in this iteration; the four added cases are unbuilt |
| Static code analysis (clang-tidy / CodeQL), findings classified | `code_analysis.rst`; `verification_process.rst` (`gd_req__verification_sca_classification`) | **NOT PERFORMED** — no tool, no build; a prior clang-tidy attempt was blocked on configuration |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` (`:status: draft`) | **UNKNOWN** — mapping is draft; not applied |
| Structural statement / branch coverage goals | `verification_plan.rst` (criteria 1-2) | **NOT MEASURED** — no execution; retained coverage readings are out of this checkout and below the platform goals |
| Unit/component testing executed, results recorded | `verification_plan.rst` (criteria 6-7); `verification_guideline.rst` | **PARTIAL / NOT COVERING THIS CHANGE** — retained focused host run is 87/87 green for the previous identifier TU; the four added cases and the runtime suite are unmeasured |
| Interface / requirements-based / resource / fault-injection test types | `verification_process.rst`; `verification_plan.rst` | **NOT PERFORMED / applicability not inferred** — no harness; identifier-only tests must not be labelled platform validation |
| Boundary / equivalence derivation | `verification_process.rst` | **SOURCE-ONLY (+ host-measured for the previous identifier TU)** — cases exist (§3); the new ones were not executed |
| Fuzzy testing technique | `verification_plan.rst` | **NOT EXECUTED / NOT CLAIMED** — no harness, no measurement |
| Linking tests to requirements (record properties) | `verification_process.rst` (`gd_req__verification_link_tests_cpp`) | **PARTIAL / NOT DONE** — `DerivationTechnique`/`Description` recorded in `SetUp()`; `TestType` and `Verifies` left unset (no verified native identifier; inventing one is prohibited) |
| External-component AoUs verified | `verification_process.rst` (`gd_req__verification_external_aou`) | **NOT SATISFIED** — no integration/static verdict; no AoU register |
| Independence of verification / review by a different committer | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Implementation inspection checklist IMPL_01…IMPL_03 | `inspection_checklist.rst` (`:status: draft`) | **NOT FILLED** — draft template, no inspection |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** for this slice; no tool run here |
| Obligation collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **ABSENT in this checkout** — directory not present |
| Native acceptance | `source-index.json` | **`not_inferred` for every entry** |

**Explicit non-satisfaction statement.** Missing tools, the unknown safety class and
un-inferred applicability, the incomplete extraction of host artifacts, the absent
obligation-collection results, the unmeasured new cases, and the unanswered human reviews mean
**none of the checked obligations may be treated as satisfied**. A collection node that
retained results would only show *retention*, not passing; here there are no retained
obligation-collection results at all. In particular, the absence of
`.llm_tmp/overnight/obligations/*/result.json` is **not** evidence that the corresponding
checks passed, and the retained 87-case host capture is **not** evidence for the four new
cases.

---

## 8. Notice preservation

- Only `.llm_tmp/overnight/reports/conversion_tests.md` (this report) and the candidate test
  file `score/socom/test/unit/service_identifier_tests.cpp` were written. No other candidate
  source path, `NOTICE`, `LICENSE`, `REUSE.toml`, config, BUILD, or prior-report file was
  created, edited, or deleted.
- `score/socom/test/unit/service_identifier_tests.cpp` retains its Apache-2.0 / SPDX header
  (lines 1-12). Every other existing Apache-2.0 / notice header is untouched; this report
  carries the Apache-2.0 header. No licensed MISRA rule text is reproduced; only native
  rule/query identifiers, file locations, and prior-report readings are cited.
- The prior `.llm_tmp/overnight/prior-reports/conversion_tests.md` was **not** overwritten.
- The duplicate key remains an `impl/`-only type; the `testonly`
  `//score/socom:impl_service_identifier` exposure (`score/socom/BUILD:46-54`) serves
  `//score/socom/test/unit` only, so no public header or notice surface changed.

---

## 9. Pending human review checklist

- [ ] **Confirm §2:** the header is already brace-balanced (single nested close
      `}  // namespace score::socom`; line 39 blank), so the recorded syntax failure is stale
      and no source edit is required. Confirm the no-op was the intended outcome, and confirm
      the retained capture's `compile_exit: 0` / 87-0 result is the correct reading.
- [ ] **Review the four added conversion-boundary cases (§3.2)** and confirm this is the
      wanted coverage; confirm the file now having **91** cases is acceptable, and that the
      full cross-product, config-minor narrowing matrix, and dynamic instance-registry cases do
      not overlap the earlier 87.
- [ ] **Compile and run** `bazel test //score/socom/test/unit:socom_test` (including the four
      new cases) since this iteration had no compiler; record the result. Do not infer passing
      from the retained 87-case capture.
- [ ] **Confirm the existing conversion cases plus the four new ones** are the wanted
      identifier-conversion boundary coverage, and that the public
      `Service_interface_identifier` identity is correctly left unchanged.
- [ ] **Supply the missing obligation results** (`.llm_tmp/overnight/obligations/*/result.json`)
      and resolve `engineering_acceptance: pending` / `human_reviews: unanswered`.
- [ ] **Keep the #84 public `Service_interface_identifier` restructure, FindService wildcard
      handling, and the config minor-wildcard narrowing out of this bounded slice** until
      separately accepted, and do not present the identifier-only tests as platform validation
      or claim an unmeasured fuzzy technique.
- [ ] **Select a safety class** via the authorized role; do not infer the slice's class from
      the `:safety: ASIL_B` attribute on the pinned platform documents (§1.4).
- [ ] **Schedule independent human review** (the approver must differ from the author, per
      `gd_req__verification_independence`).

---

*End of identifier-conversion boundary coverage iteration record. Local, unprotected, scoped.
No engineering acceptance; human reviews unanswered; full native runtime tests pending. Every
statement is a local reading of the working tree, a retained local host reading, or an
explicitly-labelled logical consequence — none is acceptance, review approval, publication, or
a full native run.*
