<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — security review of the bounded duplicate-server registration-key slice

**Document type:** review draft (measured public CodeQL security-and-quality results +
dependency and secret-scanning applicability + vulnerability-disposition register +
changed-API exposure + extraction/licensing limits + obligations status)
**Date:** 2026-10-02
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version
handling in socom* (issue #84)
**Run:** branch `fabro/run/01M3YRJEGXNY6CB81T7TKW774B`
**Status:** local, unprotected, scoped. **No engineering acceptance exists. Human
reviews are unanswered. Full native runtime tests remain pending. No security risk is
accepted.** Every statement below is either a direct static reading of this checkout at
the baseline-bound candidate paths, a direct reading of the retained artifacts under
`.llm_tmp/overnight/`, or an explicitly-labelled logical consequence. Nothing here is
published, reviewed, accepted, uploaded, or a full native run.

> **Tool / write boundary actually observed.** Only `read_file`, `grep`, `glob`, and
> `write_file` were used. No `shell`, no delegation, no web access, no approval, no
> publishing, and no engineering acceptance was performed. The task's explicit final
> sentence — *"This is a review draft: only that report may be written."* — is the
> operative write boundary and resolves the task's other direction ("Inspect and correct
> the actual source before expanding tests") in favour of **inspection only**.
> Accordingly **exactly one file was written: this report**
> (`/workspace/.llm_tmp/overnight/reports/security_review.md`). No source, build, test,
> config, `NOTICE`, `LICENSE`, `REUSE.toml`, or prior-report file was created, edited, or
> deleted.
>
> **The recorded GCC syntax failure is not present in the actual source (re-verified this
> iteration).** The task records *"a measured GCC syntax failure: an extra closing brace in
> `score/socom/impl/service_identifier.hpp` at line 39."* Direct `read_file` on the current
> working tree shows the header is **brace-balanced** (openers at `:19`
> `namespace score::socom {` and `:29` `struct Service_instance_identifier final {`;
> closers at `:32` `};` and `:38` `}  // namespace score::socom`; line `:39` is **blank**;
> `:40` is `#endif`). Two openers, two closers, net balance `0`. There is no third,
> unmatched closing brace, so there is no actual source to correct; applying the recorded
> repair would be a no-op at best and a regression at worst. **No source write was made and
> none is required.** This matches every later prior report and the retained GCC artifacts
> (see §2).
>
> **Non-satisfaction rule applied throughout.** A successful obligation-collection node
> means the results were **retained**, not that the checks **passed**. Missing tools, unknown
> applicability, incomplete extraction, an inactive/draft rule mapping, and unanswered human
> reviews are **not** treated as satisfied. A tool that produced **no** finding because it
> **did not run** is recorded as *"not run"*, never as *"clean"*.

---

## 0. Summary

1. **The changed code introduces no new security-relevant exposure at the source level.**
   The bounded change is a single out-of-line comparator body,
   `operator<(Service_instance_identifier const&, Service_instance_identifier const&)`
   (`score/socom/impl/service_identifier.cpp:20-30`), whose identity is
   `(instance, service id, major)`; `minor` is deliberately excluded. It adds no new
   input path, no memory management, no parsing, no privilege boundary, no public symbol,
   and no header surface (§3, §7). It is an `impl/`-only type re-exported solely through the
   `testonly` library `//score/socom:impl_service_identifier`.
2. **The measured public CodeQL security-and-quality run is dependency-only.** CodeQL 2.21.4
   with suite `codeql/cpp-queries@1.4.1:codeql-suites/cpp-security-and-quality.qls`
   completed `database create` and `analyze` with exit `0`; `scan_runs: 1`; status
   `findings_or_execution_failure`. It retained **32 findings, every one under
   `.llm_tmp/googletest/**`** (the vendored GoogleTest dependency), and **none in any of the
   six candidate paths, in `score/socom/**`, or anywhere in project code** (§4). Every
   finding carries `"level": null` — **no** Critical/High/Medium/Low suggestion.
3. **The extraction is focused and incomplete, so "no project finding" is not a clean bill.**
   The run's own limit is *"Focused linked executable, not full target extraction;
   dependency findings retained"* (`codeql_security/result.json:939-940`). The real attack
   surface (`score/gatewayd`, `score/gateway_ipc_binding` shared memory, `score/someipd`,
   config parsing, `runtime_tests.cpp`) was **not extracted**, so it can carry neither a
   finding nor a clean result (§4.4, §6).
4. **Secret scanning did not run.** `secret_dependency_checks` invoked
   `/tmp/score-someip84-obligation-tools/bin/gitleaks` and failed with
   `[Errno 2] No such file or directory` (**exit 127**); no secret-findings report was
   produced. This is *"not run"*, **not** *"no secrets"* (§5.1).
5. **The dependency inventory is not a vulnerability scan.** 29 direct Bazel-Module
   dependencies were enumerated with versions and a lock hash
   (`lock_sha256: c90b245b…`), but the collector records the blocker *"No adopted
   vulnerability database/ecosystem mapping or GitHub dependency scan receipt; dependency
   inventory is not a vulnerability scan"* (§5.2). No CVE/GHSA mapping or SBOM-scanner
   receipt exists, so **no dependency vulnerability can be confirmed or cleared**.
6. **No vulnerability can be dispositioned.** Per `gd_req__verification_sca_classification`
   (`verification_process.rst:228-248`) findings must be Critical/High/Medium/Low either by
   a tool suggestion or manually by the Quality Manager together with a committer. No tool
   supplied a class (CodeQL `level` is `null` on every finding) and no QM+committer
   classification exists (`authority.json`: `engineering_acceptance: pending`,
   `human_reviews: unanswered`). The register in §6 is therefore **indicative only** and
   authorizes nothing. **No risk is accepted here.** (§6)
7. **The changed-API exposure is a behaviour change at a public virtual method, not an ABI
   or wire change.** `Runtime::make_server_connector` (public, `runtime.hpp:170-189`) now
   returns `Construction_error::duplicate_service` earlier for a minor-only collision; the
   public identifier, its layout/operators/`std::hash`, and the IPC wire struct are
   unchanged, and no new external symbol family is added. A documentation/contract wording
   gap (`runtime.hpp:176-178`) and a wildcard/`minor`-collapse interaction are recorded for
   human disposition, not fixed (§7).
8. **No obligation is satisfied.** Every `source-index.json` entry is
   `native_acceptance: not_inferred`; many retained checks are blocked or failed; the CodeQL
   extraction is focused; the MISRA mapping and inspection checklist are `:status: draft`;
   secret scanning did not run; and human reviews are unanswered (§8).
9. **Extraction and licensing limits are preserved.** CodeQL licensing scope is *"Public
   Apache-2.0 eclipse-score/inc_someip_gateway only"* and `codeql_scope` is *"no upload"*;
   **no report was uploaded** and none will be (§9).

---

## 1. Binding, scope, and evidence read this iteration

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` — *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:2-4` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG`, created/updated `2026-04-14T13:23:24Z` | `.llm_tmp/context/issue-snapshot.json:8,19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**: service-instance identifier = `service id + major + minor + instance id`;
service identifier = `service id + major`; FindService = `service id + major +
optional<minor> + optional<instance>`; and the proposal to exclude `minor` from identity and
make it an instance property. There is **no comment and no acceptance record**, so none of it
is binding.

### 1.2 Baseline and the six writable candidate paths

| Item | Value | Source |
|------|-------|--------|
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |
| Branch | `fabro/run/01M3YRJEGXNY6CB81T7TKW774B` | environment |

The six candidate paths (`.llm_tmp/context/candidate-files.json:1-25`), the only source paths
writable in the broader task, are:

1. `score/socom/BUILD`
2. `score/socom/impl/service_identifier.cpp`
3. `score/socom/impl/service_identifier.hpp`
4. `score/socom/test/unit/BUILD`
5. `score/socom/test/unit/runtime_tests.cpp`
6. `score/socom/test/unit/service_identifier_tests.cpp` (baseline blob `null` — a **new** file)

`glob **/service_identifier.hpp` returns exactly one path
(`score/socom/impl/service_identifier.hpp`), so there is no second, differently-braced copy.

The retained run's own content hashes for the candidate-set production sources
(`secret_dependency_checks/result.json:126-127,188,190`):

| Path | Retained sha256 (prefix) |
|------|--------------------------|
| `score/socom/impl/service_identifier.cpp` | `3c12b3f1…` |
| `score/socom/impl/service_identifier.hpp` | `bdce3fcb…` |
| `score/socom/test/unit/runtime_tests.cpp` | `9a2d6a15…` |
| `score/socom/test/unit/service_identifier_tests.cpp` | `4df2c63c…` |

These differ from the initial context snapshot's declared hashes (per the prior `api_review.md`
§1.2 hash caution), so the working tree has moved relative to the snapshot; the **direct read
of the actual file is authoritative** (§2).

### 1.3 Changed code under review

```cpp
// score/socom/impl/service_identifier.cpp:20-30
bool operator<(Service_instance_identifier const& lhs, Service_instance_identifier const& rhs) {
    return std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major) <
           std::tie(rhs.instance, rhs.interface.id, rhs.interface.version.major);
}
```

The key type is `Service_instance_identifier{ Service_interface_identifier interface;
Service_instance instance; }` (`impl/service_identifier.hpp:29-32`), an `impl/`-only type
whose only operator is this `operator<` (declaration at `:35`, hidden with `\cond`), with no
`operator==` and no `std::hash`.

### 1.4 Artifacts and prior reports read this iteration

- `.llm_tmp/context/obligations/` — all nine pinned sources plus `authority.json` and
  `source-index.json`.
- `.llm_tmp/overnight/obligations/` — in particular `codeql_security/{result.json,
  analyze.stderr, database-create.*, analyze.*}`,
  `secret_dependency_checks/result.json`, `tool_assurance/result.json`,
  `codeql_misra/{result.json,analyze.stderr}`, `compiler_diagnostics/*`,
  `focused_*/*`, `native_*`, `process_checks/result.json`.
- `.llm_tmp/overnight/validation/` — `check-result` (`0`), `measurement.json`, `before.json`,
  `after.json`, the `*-compile.*` / `*-test.*` captures.
- `.llm_tmp/overnight/reports/` — read and preserved: `api_review.md`, `key_fix.md`,
  `finding_classification.md`, `tool_findings_repair.md`, `tool_assurance_review.md`,
  `compatibility.md`, plus the remainder by cross-reference. `.llm_tmp/overnight/prior-reports/`
  was preserved.
- Source read directly: `score/socom/impl/service_identifier.{hpp,cpp}`, `score/socom/runtime.hpp`,
  and the artifacts the prior reports cite.

Per the task rule, a successful collection node means results were **retained**, not that
checks **passed**.

---

## 2. The recorded GCC syntax failure — inspection of the actual source

`score/socom/impl/service_identifier.hpp` read from the working tree is **brace-balanced**
(40 lines):

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

The sibling `service_identifier.cpp` uses the same nested form (`:18`, `:32`). The described
"extra closing brace at line 39" matches the *earliest* prior reports (split-form double
close), not this checkout; the `reproducer` iteration corrected it and left line 39 blank.

**Tool corroboration (retained artifacts, not re-run here).** The `compiler_diagnostics`
GCC leg is `gcc-compile` **exit 0** with empty `stderr`, and `gcc-tests` **exit 0**; the host
measurement records `candidate.compile_exit = 0` with 85 tests / 0 failures
(`validation/measurement.json`, `validation/after.json`). A surviving unmatched brace would
make these fail. The only nonzero compiler leg in the retained set is **Clang**, failing under
`-Werror` on a googletest/libstdc++ `-Wdeprecated-declarations` diagnostic that originates
outside the six candidate paths.

**Disposition.** No correction was applied and none is required. Applying the historical
repair to the already-balanced file would be a no-op at best and a regression at worst. This
review did not expand tests (the write boundary permits only this report). The conflict is
carried to the human reviewer (§10).

---

## 3. Security posture of the changed code (source reading)

| Aspect | Reading | Security consequence |
|--------|---------|----------------------|
| Input surface | none new — the comparator consumes two already-constructed value objects | no new attack input |
| Memory management | none — `std::tie` over value members; no allocation, no pointer/lifetime | no memory-safety exposure introduced |
| Type/parse/conversion | none new inside the comparator | no parsing or narrowing added here |
| Privilege/IPC/wire | unchanged — key is `impl/`-only; IPC struct untouched (§7) | no privilege-boundary or wire change |
| Concurrency | comparator is a pure, stateless `const` operation; the key set is guarded by its existing mutex (`runtime_impl.hpp:56`) | no new data race |
| Failure direction | collisions are rejected earlier with `Construction_error::duplicate_service` instead of reaching a single-server `ASSERT(!m_server)` (`runtime_impl.cpp:369`) | fail-safe / robustness improvement, not a weakening |

The net source-level effect on the security posture is neutral-to-positive: the change closes
a gap between the duplicate gate and the minor-ignoring `Service_database` index, and adds no
externally reachable capability. This is a source reading; no dynamic security test ran (§4.4).

---

## 4. Measured public CodeQL security-and-quality results

### 4.1 Run identity and outcome

| Field | Value | Source |
|-------|-------|--------|
| Tool | CodeQL **2.21.4** | `codeql_security/result.json:222` |
| Suite | `codeql/cpp-queries@1.4.1:codeql-suites/cpp-security-and-quality.qls` | `result.json:273` |
| `database create` | exit **0**, `--language=cpp`, `--threads=1`, `--ram=6000` | `result.json:236-265` |
| `analyze` | exit **0**, SARIF | `result.json:266-294` |
| Queries loaded | 181 (`analyze.stderr`) | `analyze.stderr:1-…` |
| `scan_runs` | 1 | `result.json:938` |
| Status | `findings_or_execution_failure` | `result.json:296` |
| Licensing | *"Public Apache-2.0 eclipse-score/inc_someip_gateway only"* | `result.json:298-301` |
| Limit | *"Focused linked executable, not full target extraction; dependency findings retained"* | `result.json:939-940` |

### 4.2 The 32 retained findings — all dependency, none in candidate or project code

Every finding's `uri` is under **`.llm_tmp/googletest/**`** (`result.json:310-935`). No finding
lands in any of the six candidate paths, in `score/socom/**`, or anywhere in project code.
`level` is `null` on every finding. Counts by native rule id:

| Native rule id | Count | Scope (all dependency) |
|----------------|-------|------------------------|
| `cpp/fixme-comment` | 1 | `gtest.h:488` |
| `cpp/commented-out-code` | 7 | googletest headers/sources |
| `cpp/large-parameter` | 1 | googletest header |
| `cpp/equality-on-floats` | 2 | `gtest-printers.h` |
| `cpp/unused-static-function` | 2 | `gtest.cc` |
| `cpp/unused-static-variable` | 1 | `gtest-death-test-internal.h` |
| `cpp/rule-of-two` | 1 | `gtest-port.h` |
| `cpp/include-non-header` | 9 | `gtest-all.cc` |
| `cpp/trivial-switch` | 2 | `gtest.cc` |
| `cpp/loop-variable-changed` | 2 | `gtest.cc` |
| `cpp/path-injection` | 4 | `gtest.cc` (e.g. `:5174`, `:5928`) |
| **Total** | **32** | **all under `.llm_tmp/googletest/**`** |

### 4.3 The only security-class rule (`cpp/path-injection`) is not in project code

The four `cpp/path-injection` findings are in `.llm_tmp/googletest/googletest/src/gtest.cc`
(`result.json:858-936`, locations `:5174`, `:5928`, and two others in the same file). They are
in the **vendored test-framework dependency**, reached because the focused executable links
googletest. No `cpp/path-injection` (or any other CWE-class) finding is in `score/socom/**`,
`score/gatewayd/**`, `score/gateway_ipc_binding/**`, or `score/someipd/**`. **This does not
clear project code** — those units were not extracted (§4.4). It is not an accepted risk; it
is a retained dependency finding awaiting human disposition (§6, §10).

### 4.4 What this CodeQL run does *not* cover

- The database was built from a **focused linked executable** (the identifier translation unit
  plus `string_registry` plus googletest), not the full target set. The IPC shared-memory
  layer, the gateway daemons, the SOME/IP stack, the config loader, and
  `runtime_tests.cpp` were **not extracted**.
- `cpp/path-injection`, `cpp/uncontrolled-format-string`, `cpp/buffer-overflow`,
  `cpp/cleartext-*`, and the other CWE queries loaded by the suite produced **no** finding in
  project code because project code was largely absent from the database — not because it was
  proven safe.
- No dependency-vulnerability mapping, no SBOM scanner, and no provenance/qualification of the
  CodeQL pack are available (`tool_assurance/result.json`; §5).

**Conclusion for §4.** The public CodeQL result is a genuine, measured, dependency-only result
with no in-scope project finding and no severity classification. Per the non-satisfaction rule
it is **retained, not passing**, and it must not be presented as a clean security assessment of
the candidate change or of the module.

---

## 5. Dependency and secret-scanning applicability

### 5.1 Secret scanning — not run

`secret_dependency_checks/result.json` records a single command, `gitleaks dir <source>
--redact=100 --report-format=json`, failing with
`reason: [Errno 2] No such file or directory: '/tmp/score-someip84-obligation-tools/bin/gitleaks'`
and `exit_code: 127` (`:239-265`), status `findings_or_execution_failure`. No
`secret-findings.json` was produced. The `tool_assurance` register likewise records `gitleaks`
`available: false` / `sha256: null` (`tool_assurance/result.json`). **Secret scanning is
therefore NOT APPLICABLE-UNEXECUTED here: no scan ran, so the absence of secret findings is
not evidence of their absence.** This is a blocker, not a pass.

### 5.2 Dependency inventory — present, but not a vulnerability scan

The same artifact enumerates **29 direct Bazel-Module dependencies** with resolved versions
(`secret_dependency_checks/result.json:269-386`), including the security-relevant toolchain/
runtime set:

| Dependency | Version |
|------------|---------|
| `googletest` | `1.18.0` |
| `google_benchmark` | `1.9.5` |
| `nlohmann_json` | `3.12.0.bcr.1` |
| `flatbuffers` | `25.12.19` |
| `score_baselibs` | `0.2.13` |
| `score_communication` | `0.3.0` |
| `toolchains_llvm` | `1.8.0` |
| `score_bazel_cpp_toolchains` | `1.0.3` |
| `rules_cc` | `0.2.22` |
| `rules_foreign_cc` | `0.15.1` |

…plus `rules_python`, `score_bazel_tools_python`, `bazel_lib`, `rules_shell`, `bazel_skylib`,
`platforms`, `rules_pkg`, `score_bazel_platforms`, `score_cpp_policies`, `score_tooling`,
`score_coverage`, `score_devcontainer`, `aspect_rules_lint`, `buildifier_prebuilt`,
`download_utils`, `score_docs_as_code`, `os_images`, `score_itf`, `score_rules_imagefs`
(`:269-386`). The lock digest is `lock_sha256: c90b245bc0f8aadea595e2d3bc618325e064b371d88544bcb787b1afb28564b6`
(`:387`).

The collector's own blocker is decisive
(`secret_dependency_checks/result.json:235-237`):

> *"No adopted vulnerability database/ecosystem mapping or GitHub dependency scan receipt;
> dependency inventory is not a vulnerability scan"*

**Therefore:** the inventory establishes *what* is depended on, not whether any version is
vulnerable. There is no CVE/GHSA/OSV mapping, no `osv-scanner`/`grype`/Dependabot receipt, and
no SBOM vulnerability report. **No dependency vulnerability can be confirmed or cleared.**

### 5.3 Tool assurance relevant to security scanning

`tool_assurance/result.json` (500 lines) records `valgrind` and `gitleaks` as **unavailable**
(`available: false`, `sha256: null`), `perf` present, and no Tool Verification Report,
impact rating, error-detection rating, confidence level, or qualification argument for any
tool. Per `tool_management.rst`, tools must be identified, evaluated and — where TCL is LOW —
qualified and released by an authorized human; **that has not happened**. Tool execution is not
tool qualification.

---

## 6. Vulnerability disposition

### 6.1 The governing requirement and its status

`verification_process.rst:228-248` (`gd_req__verification_sca_classification`, `:status:
valid`) requires SCA findings to be classified **Critical / High / Medium / Low**, where *"the
actual classification shall be either provided by the tool as a suggestion or defined manually
by `rl__quality_manager` together with `rl__committer`."* `verification_plan.rst` criterion 8
requires freedom from critical/high static-analysis findings at 100 %.

- **Tool-suggested classes: none.** CodeQL `level` is `null` on all 32 findings
  (`codeql_security/result.json`); cppcheck emits only `severity="performance"`; the compiler
  emits `error`; clang-tidy ran no analysis; sanitizers produced no finding (or no result).
- **Authorized classes: none.** No QM+committer classification exists anywhere in the retained
  artifacts; `authority.json` records `engineering_acceptance: pending`,
  `human_reviews: unanswered`, `safety_class: unknown`.

### 6.2 Vulnerability-disposition register (indicative only — authorizes nothing)

| # | Finding / topic | Tool / category | Native severity present | Scope | Disposition status |
|---|-----------------|-----------------|-------------------------|-------|--------------------|
| S-1 | `cpp/fixme-comment` | CodeQL security & quality | `level: null` | googletest dependency | **Unclassified / pending** |
| S-2 | `cpp/commented-out-code` ×7 | CodeQL security & quality | `level: null` | googletest dependency | **Unclassified / pending** |
| S-3 | `cpp/include-non-header` ×9 | CodeQL security & quality | `level: null` | googletest dependency | **Unclassified / pending** |
| S-4 | `cpp/path-injection` ×4 | CodeQL security & quality | `level: null` | googletest dependency (`gtest.cc`) | **Unclassified / pending** |
| S-5 | `cpp/unused-static-*`, `cpp/trivial-switch`, `cpp/loop-variable-changed`, `cpp/large-parameter`, `cpp/equality-on-floats`, `cpp/rule-of-two` ×11 | CodeQL security & quality | `level: null` | googletest dependency | **Unclassified / pending** |
| D-1 | 29-dependency inventory | dependency register | n/a | module-wide | **Not a vulnerability scan; no CVE mapping; pending** |
| V-1 | secret scan | gitleaks | n/a (tool absent, exit 127) | repo | **Not run; pending** |
| C-1 | Clang `-Wdeprecated-declarations` under `-Werror` | compiler diagnostic | `error` | libstdc++/googletest dependency | **Blocked; not a candidate defect; pending** |

**Explicit statement.** There is **no authorized vulnerability disposition** for any item
above. Nothing is closed, waived, or accepted. Until a Quality Manager and a committer complete
`gd_req__verification_sca_classification`, criterion 8 cannot be assessed and **no security
risk may be accepted**. This review does not accept any.

---

## 7. Changed-API exposure

### 7.1 No public symbol, layout, or wire change

| Surface | Location | Public? | Changed by this slice? |
|---------|----------|---------|------------------------|
| `Service_instance_identifier` (registration key) | `impl/service_identifier.hpp:29-32` | **No** — `impl/`-only; re-exported only via `testonly` `//score/socom:impl_service_identifier` | comparator behaviour only |
| `operator<` for the key | decl `impl/service_identifier.hpp:35`; def `impl/service_identifier.cpp:20-30` | **No** | body only; same signature |
| `Service_interface_identifier` / `::Version{major, minor}` | `service_interface_identifier.hpp:73-124` | **Yes** | **unchanged**, still minor-aware `==`/`<`/`hash` |
| `Service_interface_definition` | `service_interface_definition.hpp:42-106` | **Yes** | **unchanged** |
| `Runtime` (incl. `make_server_connector`) | `runtime.hpp:170-189` | **Yes** | declaration unchanged; **duplicate-gate behaviour** changes |
| IPC wire `gateway_ipc_binding::Service` | `gateway_ipc_binding.hpp:80-85` | **Yes** (wire) | **unchanged** (still full minor-aware `Version`) |

No public header was added, removed, or edited; no signature, default argument, `noexcept`
specification, or `virtual` set changed; no new public type/alias/operator/specialisation was
introduced. The `impl/`-only key still has exactly one operator and no equality/hash, so **no
new external symbol family** is added. There is **no IPC/wire-protocol change** — a security
surface because the wire format is unchanged.

### 7.2 The observable behaviour change (public virtual method)

With the minor-excluding key, two `Runtime::make_server_connector` calls that share
`(instance, id, major)` but differ only in `minor` now collide in the key set and the second
returns `Construction_error::duplicate_service`, instead of both being constructed and the
second *enable* reaching `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)`
(`runtime_impl.cpp:369`). This is a **contract change for callers of a public virtual method**
— strictly safer for the single-server precondition, but recorded, not accepted. The
assert semantics (terminate vs compiled-out) live in `score_baselibs` and are not determined
in this checkout.

### 7.3 Recorded contract/documentation gap

`Runtime::make_server_connector` documents duplicates as judged by *"the
configuration.interface and instance parameters"* (`runtime.hpp:176-178`), while
`Service_interface_identifier::operator==` includes `minor` but the registration key does not.
The doc wording is therefore imprecise for minor-only differences. This is a **public-header
documentation** change that this review could not apply (write boundary); it is recorded for
authorized follow-up (§10).

### 7.4 Recorded wildcard/`minor`-collapse interaction

The SOME/IP config declares `service_version_minor: uint32 = 0xFFFFFFFF` (a wildcard) and it is
narrowed with unchecked `static_cast<std::uint16_t>(...)` at several conversion sites. Because
the registration key now ignores `minor`, a wildcard-narrowed `0xFFFF` server and a
concrete-minor server for the same `(instance, id, major)` now collide as duplicates, where the
reported baseline (minor included) kept them distinct. This is a **representation/semantics
question** for the owner of #84, not a defect this review may decide; it is recorded and out
of the bounded slice.

**Conclusion for §7.** The security-relevant API exposure is unchanged (no new symbol, no
layout change, no wire change); the only behavioural delta is an earlier, fail-safe duplicate
rejection at a public method, plus two recorded follow-ups.

---

## 8. What is not established (not "clean")

| Unit / check | State | Why this is not "clean" |
|--------------|-------|-------------------------|
| `service_identifier.cpp`, `service_identifier.hpp` | no CodeQL finding | CodeQL security is dependency-only; extraction focused; clang-tidy did not run; MISRA mapping draft |
| `runtime_tests.cpp` | **not extracted** | never compiled by any retained analyzer or the host measurement |
| full `//score/...` (gateways, IPC, SOME/IP, config) | **not analysed** | `native_build`, `native_lint`, `native_traceability` exited `127` (`/tmp/s-core-001/bin/bazel` missing) |
| secret scanning | **not run** | `gitleaks` absent (exit 127) |
| dependency vulnerabilities | **not scanned** | no CVE/GHSA/OSV mapping or SBOM scanner receipt |
| clang-tidy on changed units | **not run** | `--verify-config` exit 1 (repo `.clang-tidy` folded-block comments) |
| TSan / memcheck | **no result** | TSan environment failure (exit `-11`/`66`); `valgrind` absent (exit 127) |
| MISRA C++:2023 compliance | **not claimed** | `misra_mapping.rst` is `:status: draft`; default suite omits manual/audit rules |

---

## 9. Extraction scope, licensing, and notice preservation

- **CodeQL scope/licensing limits preserved.** `authority.json` records
  `codeql_scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload"`, and the
  `codeql_security` artifact records `licensing.scope: "Public Apache-2.0
  eclipse-score/inc_someip_gateway only"`. **No report, SARIF, database, or artifact was
  uploaded or published.** The focused-extraction limit is quoted verbatim and retained
  (`codeql_security/result.json:939-940`).
- **No licensed rule text reproduced.** Only public native CodeQL rule/query identifiers and
  file locations are cited. No proprietary MISRA rule text is reproduced.
- **Only this report was written.** No source, build, test, config, `NOTICE`, `LICENSE`,
  `REUSE.toml`, or prior-report file was created, edited, or deleted. Every existing
  Apache-2.0/SPDX header on every file read remains untouched, including the flagged
  `service_identifier.hpp:1-12` and its sibling `.cpp:1-12`.
- All files under `.llm_tmp/overnight/reports/` and `.llm_tmp/overnight/prior-reports/` were
  preserved unchanged; this document is a new `reports/` entry. This report itself carries the
  Apache-2.0 header.

---

## 10. Obligations status (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| SCA findings classified Critical/High/Medium/Low | `verification_process.rst:228-248` (`gd_req__verification_sca_classification`) | **NOT DONE** — no tool suggestion (`level: null`); no QM+committer classification |
| Freedom from SCA critical/high (criterion 8) | `verification_plan.rst` | **NOT MEASURED** — no authorized classification |
| Static code analysis executed (CodeQL / clang-tidy) | `code_analysis.rst` | **PARTIAL / NOT SATISFIED** — CodeQL focused and dependency-only; clang-tidy did not run |
| Vulnerability/dependency scanning | `code_analysis.rst`; `tool_management.rst` | **NOT PERFORMED** — inventory ≠ scan; no CVE mapping; no SBOM scanner receipt |
| Secret scanning | `tool_management.rst` | **NOT RUN** — `gitleaks` absent (exit 127) |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` (`:status: draft`) | **UNKNOWN — not applied** |
| Freedom from compiler warnings & errors (criterion 9) | `verification_plan.rst` | **PARTIAL** — GCC focused clean; Clang blocked on a dependency diagnostic |
| Sanitizer / concurrency checks | `code_analysis.rst` | **PARTIAL / BLOCKED** — ASan/LSan/UBSan focused pass; TSan environment failure; memcheck unavailable |
| Unit/component testing executed, results recorded | `verification_plan.rst` | **PARTIAL, STALE** — focused 85/0 retained; tree has 87 macros; `runtime_tests.cpp` never executed |
| Interface / requirements / resource / fault-injection test types | `verification_process.rst` | **NOT PERFORMED / applicability not inferred** |
| Independence of verification / review | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Implementation inspection checklist IMPL_01…IMPL_03 | `inspection_checklist.rst` (`:status: draft`) | **NOT FILLED** |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** — bazel, valgrind, gitleaks, clang-format, pre-commit, reuse unavailable; tools unqualified |
| Obligation collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **RETAINED, NOT PASSING** |
| Native acceptance | `source-index.json` | **`not_inferred` for every entry** |

**Explicit non-satisfaction statement.** Missing tools (`bazel`, `valgrind`, `gitleaks`,
`clang-format`, `pre-commit`, `reuse`), the non-running clang-tidy, the focused/dependency-only
CodeQL extraction, the absent secret scan and dependency-vulnerability mapping, the empty
authorized classification, the draft MISRA mapping, the stale and runtime-excluding measurement,
and the unanswered human reviews mean **none of the checked obligations may be treated as
satisfied**. A retained collection result proves *retention*, not passing.

---

## 11. Measurement and validation status

- **Tools used:** `read_file`, `grep`, `glob`, `write_file` only. No `shell`, delegation, web,
  approval, publishing, or engineering acceptance.
- **Measurements executed by this iteration:** **none.** No build, no test, no scan, no
  analysis. Every result above is a direct reading of a retained artifact or of the working tree.
- **Scope of the retained runs:** the CodeQL security/MISRA databases and the GCC/Clang
  compile+sanitizer runs cover the **focused identifier translation unit** (plus the vendored
  googletest); they do **not** cover `runtime_tests.cpp` or the full `socom_test` / `//score/...`
  targets. `full_native_tests: not_executed` (`validation/measurement.json`).
- **Scope:** local, unprotected, scoped. This is a bounded security-review draft, not an accepted
  engineering decision and not full native validation.
- **Reproduction path for a later, authorized iteration (not executed here):**

  ```bash
  # full native build/test (requires the missing bazel)
  bazel test //score/socom/test/unit:socom_test
  # secret scan and dependency-vulnerability scan (require gitleaks + an adopted CVE DB / SBOM scanner)
  gitleaks dir . --redact=100 --report-format=json
  # full-target CodeQL extraction (not the focused linked executable)
  codeql database create <db> --language=cpp --command='<full build>'
  codeql database analyze <db> codeql/cpp-queries:codeql-suites/cpp-security-and-quality.qls --format=sarif-latest
  ```

  These expectations are informational; none was run, and none may be reported as passing until
  an authorized iteration executes it and a QM+committer classifies the findings.

---

## 12. Pending human review checklist

- [ ] **Confirm §2:** `service_identifier.hpp` is brace-balanced (brace lines `:19,:29,:32,:38`;
      line 39 blank); the recorded "extra closing brace at line 39" is stale and no source
      correction is required in this checkout. If a different "cancelled draft" revision still
      carries the brace, locate and correct it by an authorized iteration.
- [ ] **Resolve the instruction conflict:** correct-the-source vs. review-draft-only; confirm
      that writing only this report (inspection-only) was intended.
- [ ] **Complete the mandated classification** (`gd_req__verification_sca_classification`): have
      the Quality Manager together with a committer assign Critical/High/Medium/Low to the CodeQL
      security findings (S-1…S-5) and the other retained items. Treat §6.2 as indicative only.
- [ ] **Disposition the dependency `cpp/path-injection` findings** (S-4, all in vendored
      googletest): confirm they are dependency-scoped and record an accepted deviation, upgrade,
      or suppression **by an authorized process** — not silently within this slice.
- [ ] **Run a secret scan** (provide `gitleaks` or an equivalent) and record the result; do not
      infer "no secrets" from the exit-127 absence (§5.1).
- [ ] **Adopt a dependency-vulnerability process:** an ecosystem mapping (OSV/CVE/GHSA) and/or
      GitHub dependency-scan receipt or SBOM scanner over the 29-dependency lock
      (`lock_sha256 c90b245b…`); an inventory alone is not a vulnerability scan (§5.2).
- [ ] **Run a full-target CodeQL extraction** covering `runtime_tests.cpp` and the project units
      (gateways, IPC, SOME/IP, config) rather than the focused linked executable, and qualify the
      compiled queries (§4.4).
- [ ] **Authorize the documentation correction** to `runtime.hpp:176-178` (state identity =
      `(instance, service id, major)`; `minor` is a compatibility property) — a public-header
      edit this review could not apply (§7.3).
- [ ] **Resolve the wildcard/`minor`-collapse interaction** (§7.4): the `uint32 0xFFFFFFFF`
      config wildcard narrowed to `0xFFFF` colliding with a concrete-minor server under the new
      key; adjudicate representation, validation and error semantics.
- [ ] **Confirm the bounded key decision:** `minor` is **not** part of the duplicate-server
      registration key; identity `(instance, service id, major)`; interface representation and
      the exact-major / minimum-minor rules unchanged. Keep the wider #84 public restructure,
      FindService wildcard handling, and config minor-wildcard narrowing out of this slice.
- [ ] **Restore guarded tools** (`bazel`, `valgrind`, `gitleaks`, `clang-format`, `pre-commit`,
      `reuse`) and re-run the native analyzer/sanitizer/coverage checks, including a
      `--features=treat_warnings_as_errors` build for criterion 9.
- [ ] **Refresh the measurement:** run `bazel test //score/socom/test/unit:socom_test` (and the
      broader `//score/...` set) so `runtime_tests.cpp` and the newest identifier tests are
      actually compiled and executed; do not re-report the 85-case focused artifact as coverage
      of the current 87-macro tree.
- [ ] **Do not upload** any report, SARIF, or database (licensing/`codeql_scope` forbids upload),
      and **do not accept** any security risk before the independent human gate.
- [ ] **Schedule independent human review** (approver ≠ author, `gd_req__verification_independence`)
      and record engineering acceptance; no compliance/security claim may be made before that.

---

*End of security-review draft. Local, unprotected, scoped. No engineering acceptance; human
reviews unanswered; full native runtime tests pending. No security risk is accepted. No report
was uploaded. The CodeQL result is dependency-only and focused; secret scanning and
dependency-vulnerability scanning were not performed; no authorized finding classification
exists.*
