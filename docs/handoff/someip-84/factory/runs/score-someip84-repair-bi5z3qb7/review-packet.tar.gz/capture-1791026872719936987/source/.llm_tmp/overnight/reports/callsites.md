<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — bounded duplicate-server registration-key call-site map (review draft)

**Document type:** review draft — actual-source inspection (construction, conversion, comparison,
service-database call sites) + obligations status.
**Date:** 2026-10-03
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version handling in
socom* (issue #84)
**Run / branch:** `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ`; HEAD `b7d55bb`
(`fabro(01M3ZRSDK2XQAF1H48VWTPKQNZ): start (success)`) — from the run environment.
**Verified baseline commit:** `f8a196c3b16d5172d898394ab99b0ed81346d63d`
(`.llm_tmp/context/source-manifest.json:3`).
**Status:** **local, unprotected, scoped.** No engineering acceptance exists. Human reviews are
unanswered. Full native runtime tests are pending. Nothing here is acceptance, review, publication,
or a full native run.

> **Tool / write boundary observed.** This iteration used only `read_file`, `grep`, `glob`, and
> `write_file`. No `shell`, no `edit_file`, no delegation, no web access, no approval, no publishing,
> and no engineering acceptance was performed. The task text says to *"Inspect and correct the actual
> source before expanding tests"*, while its explicit and more specific final sentence says *"This is
> a review draft: only that report may be written."* Following that final write boundary, **exactly
> one file was written — this report** (`/workspace/.llm_tmp/overnight/reports/callsites.md`). No
> source, build, test, config, `NOTICE`, `LICENSE`, `REUSE.toml`, or prior-report file was created,
> edited, or deleted, and no test was expanded. All prior reports were read and preserved.
>
> **No correction was required: the flagged file is brace-balanced in this checkout.** The task
> records *"a measured GCC syntax failure: an extra closing brace in
> `score/socom/impl/service_identifier.hpp` at line 39."* Direct `read_file` + `grep` on the current
> working tree (§2) show `score/socom/impl/service_identifier.hpp` is exactly 40 lines with braces
> only at `:19` (`namespace score::socom {`) and `:29` (`struct Service_instance_identifier final {`)
> as openers, and `:32` (`};`) and `:38` (`}  // namespace score::socom`) as closers. Line `:39` is
> **blank**; line `:40` is `#endif`. Two openers, two closers, net balance `0`. There is no third,
> unmatched closing brace. Applying the documented repair again would be a no-op, and re-introducing
> a break to "fix" it would be a regression. The minimal historical repair is retained in §2.3 for
> reference only. The write boundary forbids a source edit and no `edit_file` tool was permitted in
> any case.
>
> **Non-satisfaction rule applied throughout.** A successful obligation-collection node means results
> were **retained**, not that checks **passed**. Missing tools, unknown applicability, incomplete
> extraction, a draft rule mapping, and unanswered human reviews are **not** treated as satisfied.
> Every unexecuted applicable check remains a blocker (§9).

---

## 0. Summary

1. **Recorded syntax failure re-inspected; not present.** `score/socom/impl/service_identifier.hpp`
   is brace-balanced (§2). No correction was applied — none is required, the write boundary forbids
   it, and no `edit_file` tool was permitted. The minimal repair is retained for reference only.
2. **Call-site map produced** for the duplicate-server registration key **construction** (§4),
   **conversion** (§5), **comparison / ordering / hashing** (§6), and **service database** (§7),
   each with repo-relative paths and current working-tree line numbers read this iteration.
3. **The key ignores `minor`; two surrounding layers do not.** The registration key orders by
   `(instance, service id, major)` (`score/socom/impl/service_identifier.cpp:28-29`) and the
   `Service_database` index is minor-ignoring (`score/socom/impl/runtime_impl.hpp:116-134`), while
   the public `Service_interface_identifier` ordering/hash and the IPC `Service` key keep `minor`
   (§6). This is the substance of issue #84's key question, recorded as a **static observation, not
   a defect claim**.
4. **The only production construction site of the key is `Runtime_impl::make_server_connector`**
   (`score/socom/impl/runtime_impl.cpp:443`); all other key constructions are in tests (§4).
5. **87 key cases and 33 runtime macros are present but unexecuted here.** Counts were read this
   iteration by `grep` (§8).
6. **No obligation is satisfied.** No tool ran beyond reading; no build, no test. Pinned entries are
   `native_acceptance: not_inferred`; `authority.json` records `engineering_acceptance: pending`,
   `human_reviews: unanswered`, `safety_class: unknown` (§9).

---

## 1. Binding to the baseline, prior reports, host feedback, and obligations

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` | `.llm_tmp/context/issue-snapshot.json:2-4` |
| Title | *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:3` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` (unchanged) | `.llm_tmp/context/issue-snapshot.json:19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**. It distinguishes three use cases — *service-instance identifier* =
`service id + major + minor + instance id`; *service identifier* = `service id + major`;
*FindService* = `service id + major + optional<minor> + optional<instance>` — and proposes to
"exclude the minor version and make it a property of the service instance to be able to better
compare and index compatible service instances." It notes the FindService `major = FF` AUTOSAR case
as theoretically possible but not useful. There is **no comment and no acceptance record**, so none
of the proposal is binding.

### 1.2 Verified baseline and current tree

| Item | Value | Source |
|------|-------|--------|
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |
| Current branch | `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ` | run environment |
| Current HEAD | `b7d55bb` — `fabro(01M3ZRSDK2XQAF1H48VWTPKQNZ): start (success)` | run environment |

Binding is **by baseline commit**, not by run HEAD. Prior reports reference other run IDs on the same
baseline commit, so they remain admissible prior evidence for this slice. No hashing tool is
available in this task, so the working tree was **not** re-hashed; the direct source reads in
§2–§7 are authoritative for this report.

### 1.3 In-scope candidate files (`.llm_tmp/context/candidate-files.json`)

| File (repo-relative) | Baseline git blob | Baseline present | Current working tree (read this iteration) |
|----------------------|-------------------|------------------|--------------------------------------------|
| `score/socom/BUILD` | `3477ea0851fdcd82ec6ea9d71424013cbdf41962` | yes | `socom` lib `:24-41`; `testonly` `impl_service_identifier` `:46-54` |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e22355242009fe20dada2a9a0d0c7a9c7` | yes | key identity `(instance, id, major)`; `minor` excluded (`:28-29`) |
| `score/socom/impl/service_identifier.hpp` | `c8bae7908da9f087c518934f7b9f8d86db9a20ec` | yes | **brace-balanced**, 40 lines, `:39` blank (§2) |
| `score/socom/test/unit/BUILD` | `3c03a7b14286051f97fa5022206564bd63645171` | yes | `socom_test` globs `*.cpp`; deps wired (`:16-29`) |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab726db8bf994c960045d6fd7fdf84d7395` | yes | **33 macros** (1 `TEST` + 31 `TEST_F` + 1 `TEST_P`); minor-only regression `:402-431` |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(none — `null`)* | **no** (manifest expects a **new** file) | **87 `TEST_F`** matrix present; metadata `SetUp()` at `:42-65` |

The `null` baseline blob is the manifest's expectation of a **new** unit-test file; it exists on disk
only in the un-merged working tree (the task's *"cancelled draft"*), never in the baseline. `glob
**/service_identifier*` returns exactly three paths (`impl/service_identifier.cpp`,
`impl/service_identifier.hpp`, `test/unit/service_identifier_tests.cpp`), so there is no second,
differently-braced copy of the header in this checkout.

### 1.4 Pinned obligation sources and authority (all read this iteration)

All nine entries of `.llm_tmp/context/obligations/source-index.json` were read from
`.llm_tmp/context/obligations/`, together with `authority.json`. Every entry is pinned
`"native_acceptance": "not_inferred"` — pinned, but its applicability to this slice is **not
inferred**.

| id | file | status |
|----|------|--------|
| `coding_guidelines` | `coding_guidelines.rst` | `:status: valid`; MISRA C++:2023 with C++17 |
| `code_analysis` | `code_analysis.rst` | `:status: valid`; clang-tidy + gcc/clang warnings + Coverity; sanitizers; gcov/gcovr |
| `misra_mapping` | `misra_mapping.rst` | **`:status: draft`**; the rule table is commented out |
| `verification_plan` | `verification_plan.rst` | `:status: valid`; quality criteria 1–9 (criterion 9 = freedom from compiler warnings & errors, 100 %) |
| `development_plan` | `development_plan.rst` | `:status: valid`; C++17, GCC host compiler, QCC target, Bazel |
| `tool_management` | `tool_management.rst` | `:status: valid`; tools identified / evaluated / qualified |
| `verification_process` | `verification_process.rst` | `:status: valid`; `gd_req__verification_link_tests_cpp`, `_independence`, `_checks_extended`, `_sca_classification` |
| `verification_guideline` | `verification_guideline.rst` | `:status: valid`; traceability, independence, reporting |
| `inspection_checklist` | `inspection_checklist.rst` | **`:status: draft`**; blank `IMPL_01_01`…`IMPL_03_02` template |

**Authority record** (`.llm_tmp/context/obligations/authority.json:1-7`):

| Field | Value |
|-------|-------|
| `engineering_acceptance` | **pending** |
| `human_reviews` | **unanswered** |
| `safety_class` | **unknown** |
| `codeql_scope` | Public Apache-2.0 `eclipse-score/inc_someip_gateway`; **no upload** |
| `instruction` | *"Restart the failed queue for one complete pass through all obligations"* |

### 1.5 Prior reports, host feedback, and obligation-collection results available here

- **`.llm_tmp/overnight/prior-reports/` — 38 files present**, all read/cross-checked and preserved:
  `analyzer_plan.md`, `api_review.md`, `bazel_plan.md`, `callsites.md`, `compatibility.md`,
  `concurrency_review.md`, `conversion_tests.md`, `coverage_review.md`, `coverage_tests_repair.md`,
  `cross_target_review.md`, `design_inspection_draft.md`, `deviation_drafts.md`,
  `evidence_inventory.md`, `finding_classification.md`, `independent_review_handoff.md`,
  `integration_aou_review.md`, `invariants.md`, `key_fix.md`, `lifetime_review.md`,
  `lifetime_tests.md`, `misra_applicability.md`, `misra_manual_review.md`, `native_build_review.md`,
  `ordering_tests.md`, `performance_review.md`, `reproducer.md`, `review_packet.md`,
  `runtime_disabled.md`, `runtime_enabled.md`, `sanitizer_review.md`, `scope.md`, `security_review.md`,
  `test_metadata.md`, `tool_assurance_review.md`, `tool_findings_repair.md`, `traceability_review.md`,
  `unit_matrix.md`, `verification_report_draft.md`.
- **`.llm_tmp/overnight/reports/`** held only `scope.md` before this write; this document adds
  `callsites.md`.
- **`.llm_tmp/overnight/validation/`** returned **no** `glob` matches. Prior reports record its
  intended content (`check-result` = `0`; `measurement.json` with
  `origin: local_unprotected_measurement`, `initiator: Fabro host hook`, `mode: ubsan`,
  `engineering_acceptance: pending`, `full_native_tests: not_executed`, compiler
  `/usr/bin/x86_64-linux-gnu-g++-12`; a focused identifier-TU red/green record). The artifacts
  themselves are **not present here**, so no host check is treated as passed.
- **`.llm_tmp/overnight/obligations/*/result.json`** returned **no** `glob` matches; the directory is
  absent from this checkout. Prior reports summarize collector rows (focused GCC green, clang blocked
  on a googletest/libstdc++ deprecation, clang-tidy config rejected / not run, branch coverage below
  goal, TSan SIGSEGV, memcheck absent, native/bazel legs failing to fetch toolchains). Those are
  **readings of missing artifacts**, retained by the reports only; **retention ≠ passing**, and
  absence here is **not** evidence that the checks passed.

---

## 2. The recorded syntax failure: inspection of the actual source

### 2.1 Finding (re-verified this iteration by direct `read_file`)

`score/socom/impl/service_identifier.hpp` is **brace-balanced**. It is exactly 40 lines. The
brace-bearing and namespace lines are:

| Line | Content | Role |
|------|---------|------|
| 14 | `#ifndef SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard begin |
| 17 | `#include "score/socom/service_interface_identifier.hpp"` | include |
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 21–28 | doc comment | states `minor` is intentionally not part of the identity |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 30 | `Service_interface_identifier interface;` | member |
| 31 | `Service_instance instance;` | member |
| 32 | `};` | closes the struct |
| 34 | `/// \cond` | doc guard |
| 35 | `bool operator<(Service_instance_identifier const& lhs, Service_instance_identifier const& rhs);` | the single operator declaration |
| 36 | `/// \endcond` | doc guard |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`) and two closers (`:32`, `:38`): net brace balance is `0`. There is **no
third, unmatched closing brace**, and line 39 contains no text at all. The sibling
`score/socom/impl/service_identifier.cpp` uses the same nested form (`:18` / `:32`) and is balanced.
The task's *"extra closing brace … at line 39"* therefore matches a **stale, pre-correction
description** (the earliest prior reports quote the split form `}  // namespace socom` +
`}  // namespace score`). The `reproducer` iteration records the correction; every later prior report
records the header as already balanced — which is what the actual source shows in this checkout.

### 2.2 Disposition and the write-boundary conflict

**No correction was applied, and none is required.** The instruction's precondition ("inspect and
correct the actual source before expanding tests") is satisfied without a source write: there is
nothing to correct, and the explicit write boundary ("only that report may be written") would have
forbidden the write in any case. If the *"cancelled draft"* is a different revision that still
carries the extra brace, it is **not** the file in this checkout and must be located and corrected by
an authorized iteration; this report records the discrepancy for human disposition rather than
speculating. No test was expanded, because the draft's suites already exist on disk (§8).

### 2.3 Minimal historical repair (reference only; NOT applied)

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

Applying this to the already-balanced file would be a no-op; deleting a brace would *create* the
reported defect.

### 2.4 Why it would matter if present

The header is compiled into `//score/socom:socom` (`score/socom/BUILD:24-41`; its `srcs` globs
`impl/**/*.cpp`, `impl/**/*.hpp`) and re-exposed to `//score/socom/test/unit` through the `testonly`
library `impl_service_identifier` (`score/socom/BUILD:46-54`; consumed at
`score/socom/test/unit/BUILD:24`). A syntax error there would fail the library and the whole
`socom_test` target, contradicting S-CORE quality criterion 9, "Freedom from compiler warnings &
errors, 100 %" (`verification_plan.rst`). It is **not** a blocker in the current tree; that is a
static brace-balance reading, **not** a compile measurement.

---

## 3. The key type and its role

| Item | Site | Notes |
|------|------|-------|
| Key struct `Service_instance_identifier{ Service_interface_identifier interface; Service_instance instance; }` | `score/socom/impl/service_identifier.hpp:29-32` | Comment `:21-28` states it "is only used to check if any (Disabled, Enabled) Server_connector for the given interface and instance already exists" and documents the minor exclusion. |
| `operator<` declaration | `score/socom/impl/service_identifier.hpp:35` | The **only** operator declared for this type (no `operator==`, no `std::hash`). |
| `operator<` definition | `score/socom/impl/service_identifier.cpp:20-30` | `std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major) < std::tie(rhs.instance, rhs.interface.id, rhs.interface.version.major)` (`:28-29`) — identity `(instance, id, major)`, **minor excluded**; comment `:21-27`. |
| Container binding | `score/socom/impl/runtime_impl.hpp:56` | `using Service_identifiers = Mutexed_variable<std::set<Service_instance_identifier>>;` (`Mutexed_variable` at `:50-54`). |
| Storage | `score/socom/impl/runtime_impl.hpp:228-229` | `Runtime_impl::m_service_identifiers` (`std::shared_ptr<Service_identifiers>`). |
| Include | `score/socom/impl/runtime_impl.hpp:30` | `#include "service_identifier.hpp"`. |

`std::set` uniqueness is `!(a<b) && !(b<a)`. On this working tree, `minor` is therefore **not** part
of the duplicate-server key; on the baseline (per `prior-reports/invariants.md` I-4) it was.

---

## 4. Construction sites

### 4.1 Construction of `Service_instance_identifier` (the duplicate key)

| Site | Code | Relevance |
|------|------|-----------|
| `score/socom/impl/runtime_impl.cpp:443` | `Service_instance_identifier const identifier{configuration.get_interface(), instance};` | **The only production construction site of the key**, in `Runtime_impl::make_server_connector` (credentials overload, `:440-467`). |
| `score/socom/impl/runtime_impl.cpp:449-454` | under `m_service_identifiers->mutex`: `if (!m_service_identifiers->data.insert(identifier).second) return MakeUnexpected(Construction_error::duplicate_service);` (`:451-452`) | Duplicate rejection. |
| `score/socom/impl/runtime_impl.cpp:456-463` | `Final_action` captures `identifier` + `weak_ptr<Service_identifiers>` and `data.erase(identifier)` on destruction | Key lifetime = connector lifetime. |
| `score/socom/impl/runtime_impl.cpp:465-466` | `std::make_unique<SC_impl>(…)` | Connector construction, after the set insert. |

Entry point: the no-credentials overload (`score/socom/impl/runtime_impl.cpp:433-438`) delegates to
the credentials overload (`:440-467`).

Test-only constructions: `score/socom/test/unit/service_identifier_tests.cpp:99`
(`Service_instance_identifier{interface, instance}` in `make_identifier`), and the many direct
initializer-list uses in that file (e.g. `:169-170`, `:205-211`, `:247-258`).

### 4.2 Construction of `Service_interface_identifier` / `Service_instance`

Constructors live in `score/socom/service_interface_identifier.hpp`:

- `Service_instance` — class `:28-55`; `Id = Registry_string_view` `:30`; `id` `:33`; constructors
  `:37` (`Id`), `:41-42` (`string_view` → `instance_id_registry().insert`), `:48-49` (`string_view`
  + `Literal_tag`), `:53-54` (`std::string&&`).
- `Service_interface_identifier::Version` — `:80-88`; `major` `:83` (`std::uint16_t`), `minor` `:87`
  (`std::uint16_t`).
- `Service_interface_identifier` — struct `:74-124`; `Id` `:77`; `id` `:91`; `version` `:94`;
  constructors `:99-100` (`Id` + `Version`), `:105-106` (`string_view` → `service_id_registry().insert`),
  `:113-116` (`string_view` + `Literal_tag`), `:121-123` (`std::string&&`).

### 4.3 Definition / accessor types feeding the key

| Site | Code | Relevance |
|------|------|-----------|
| `score/socom/service_interface_definition.hpp:42-68` | `Service_interface_definition`; `interface` member `:65`; constructors `:47-48`, `:54` | IPC/config → runtime configuration. |
| `score/socom/service_interface_definition.hpp:77-106` | `Server_service_interface_definition`; `get_interface()` `:105`; conversion operator `:101` | `configuration.get_interface()` at the key site (`runtime_impl.cpp:443`). |
| `score/socom/impl/service_interface_definition.cpp:20-28,37-39` | definition constructors and `operator<` (`lhs.interface < rhs.interface`, `:38`) | Wraps the public identifier ordering. |
| `score/socom/impl/service_interface_definition.cpp:53-55,65-68` | conversion operator and `get_interface()` implementations | Enable the key construction. |

---

## 5. Conversion sites

### 5.1 Config → socom identifier (constructor with `Version`)

The SOME/IP configuration declares `service_version_major: uint8` (`score/config/mw_someip_config.fbs:19`)
and `service_version_minor: uint32 = 0xFFFFFFFF` (`:23`, the SOME/IP "accept any minor" wildcard);
`socom::Version` uses `std::uint16_t major` / `std::uint16_t minor`
(`score/socom/service_interface_identifier.hpp:83,87`). Every config→socom conversion narrows
`uint32→uint16`:

| Site | Expression | Notes |
|------|------------|-------|
| `score/someipd/impl/remote_network_service.cpp:42-45` | `{service_version_major(), static_cast<uint16_t>(service_version_minor())}` | Cast of a value that may be the `0xFFFFFFFF` wildcard → `0xFFFF`. |
| `score/someipd/impl/local_network_service.cpp:46-49` | same | same |
| `score/gatewayd/impl/local_service_instance.cpp:46-49` | same | same |
| `score/gatewayd/impl/remote_service_instance.cpp:89-92` | same | same |
| `score/gatewayd/main.cpp:229-232` | same | same |

`service_version_major()` is `uint8` and widens losslessly into `std::uint16_t`; only the minor
narrowing is lossy. These are recorded as call sites; no runtime behaviour is claimed.

### 5.2 IPC (`gateway_ipc_binding`) ↔ socom

| Site | Code | Relevance |
|------|------|-----------|
| `score/gateway_ipc_binding/gateway_ipc_binding.hpp:80-85` | `struct Service { Service_id service_id; socom::Service_interface_identifier::Version version; socom::Service_interface_identifier to_socom_identifier() const noexcept; }` (`:84`) | IPC POD carries `id + Version{major,minor}`. |
| `score/gateway_ipc_binding/impl/gateway_ipc_binding.cpp:27-30` | `Service::to_socom_identifier()` → `Service_interface_identifier{fixed_string_to_string(service_id), {version.major, version.minor}}` | IPC → socom, **full `(major, minor)` preserved**. |
| `score/gateway_ipc_binding/impl/service_state.hpp:412-417` | `get_or_create` builds `Service_state{interface.to_socom_identifier(), socom::Service_instance{fixed_string_to_string(instance)}}` (`:415-416`) | IPC → socom service state. |
| `score/gateway_ipc_binding/impl/shared_memory_slot_manager.cpp:286-288` | `register_configuration` builds `entry.service.to_socom_identifier()` (`:286`) | IPC → socom map key. |
| `score/gateway_ipc_binding/impl/binding_base.cpp:352-356` | `make_client_connector(Service_interface_definition{msg.service_id.to_socom_identifier()}, Service_instance{fixed_string_to_string(msg.instance_id)}, …)` (`:354`) | IPC request → socom client connector. |
| `score/gateway_ipc_binding/impl/shared_memory_managers.hpp:56-57` | `interface.get().to_socom_identifier()` (`:56`), `socom::Service_instance{fixed_string_to_string(instance.get())}` (`:57`) | Key → socom identifiers for slot-manager creation. |

---

## 6. Comparison / ordering / hashing sites

### 6.1 socom identifier operators (`score/socom/service_interface_identifier.hpp`)

| Site | Operator | Compares |
|------|----------|----------|
| `:61-63` | `Service_instance ==` | `id` (`:62`) |
| `:69-71` | `Service_instance <` | `id` (`:70`) |
| `:130-133` | `Version ==` | `(major, minor)` (`:132`) |
| `:140-143` | `Version <` | `(major, minor)` (`:142`) |
| `:149-152` | `Service_interface_identifier ==` | `(id, version)` (`:151`) |
| `:159-162` | `Service_interface_identifier <` | `(id, version)` (`:161`) |
| `:170-175` | `std::hash<Service_instance>` | `hash(id)` (`:173`) |
| `:181-190` | `std::hash<Service_interface_identifier>` | `h1 ^ (h2<<1) ^ (h3<<2)` (`:184-187`, includes minor) |

### 6.2 The duplicate-key ordering

| Site | Code | Notes |
|------|------|-------|
| `score/socom/impl/service_identifier.cpp:20-30` | `std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major) < std::tie(rhs.instance, rhs.interface.id, rhs.interface.version.major)` (`:28-29`) | The only ordering for the key. Working-tree identity is `(instance, id, major)`; **minor is not compared**. No `operator==`/hash for `Service_instance_identifier`. Baseline identity (per `invariants.md` I-4) also included minor. |

### 6.3 Compatibility predicates (separate from the key)

| Site | Code | Notes |
|------|------|-------|
| `score/socom/impl/runtime_impl.cpp:133-136` | `is_minor_version_compatible`: `client.version.minor <= server.version.minor` | Minor semantics used *outside* the key. |
| `score/socom/impl/runtime_impl.cpp:138-146` | `is_interface_compatible`: equal `id`, equal `major`, then the minor rule (`:144-145`) | Called at `:508-509` and `:536`. |
| `score/socom/impl/runtime_impl.cpp:505-517` | Client bind: checks `is_minor_version_compatible` (`:506`), else logs an error (`:512-516`) | — |
| `score/socom/impl/runtime_impl.cpp:534-544` | Server connect: same check (`:535`), else logs an error (`:539-542`) | — |

### 6.4 The minor-ignoring database key (coarser than the public identifier)

| Site | Code | Notes |
|------|------|-------|
| `score/socom/impl/runtime_impl.hpp:116-121` | `Minor_version_ignoring_key_equal`: `(lhs.id == rhs.id) && (lhs.version.major == rhs.version.major)` (`:119`) | Ignores `minor`. |
| `score/socom/impl/runtime_impl.hpp:123-129` | `Minor_version_ignoring_hash`: `id_hash ^ (major_hash << 1)` (`:127`) | Ignores `minor`. |
| `score/socom/impl/runtime_impl.hpp:131-134` | `Service_interfaces = unordered_map<Service_interface_identifier, Service_instances, Minor_version_ignoring_hash, Minor_version_ignoring_key_equal>` | The record index. |

### 6.5 Other comparison / hashing sites that use the full identifier

| Site | Code | Notes |
|------|------|-------|
| `score/socom/impl/runtime_impl.hpp:99-100` | `using Instances = std::vector<Service_instance>;` `using Interfaces_instances = std::unordered_map<Service_interface_identifier, Instances>;` | Uses the **full-version** `std::hash`/`operator==` (includes minor). |
| `score/gateway_ipc_binding/shared_memory_slot_manager.hpp` | `std::map<Service_interface_identifier, std::map<Service_instance, Shared_memory_metadata>>` | `std::map` ordering uses `Service_interface_identifier::operator<` (includes minor). |
| `score/gateway_ipc_binding/impl/gateway_ipc_binding.cpp:32-35` | `operator==(Service, Service)` | `service_id`, `version.major`, `version.minor`. |
| `score/gateway_ipc_binding/impl/gateway_ipc_binding.cpp:37-43` | `Service_hash::operator()` | `(h1 ^ (h2<<1)) ^ (h3<<2)` (`:42`). |
| `score/gateway_ipc_binding/impl/key.hpp:35-40` | `Keys` keyed by `unordered_map<Service, …, Service_hash>` (`:38`) | IPC-side identity **keeps full version**. |

**Cross-boundary observation (static, not a defect claim).** Within socom the duplicate-server key
and the `Service_database` index ignore `minor`, but the public identifier hash/order, the
`Interfaces_instances` map, and the IPC `Service` key keep it. Issue #84's "service identifier = id +
major" proposal is currently implemented *only* at the internal duplicate-key/index level; the
public-interface and IPC layers still distinguish minors.

---

## 7. Service-database call sites

`Service_database` (`score/socom/impl/runtime_impl.hpp:102-138`) is the only owner of
`m_service_records` (`:137`).

| Site | Call | Notes |
|------|------|-------|
| `score/socom/impl/runtime_impl.hpp:106-107` | `get_record(Service_interface_identifier const&, Service_instance const&)` declaration | Internal API. |
| `score/socom/impl/runtime_impl.hpp:109-113` | `get_instances(…)` declarations | Two overloads. |
| `score/socom/impl/runtime_impl.cpp:311` | `Service_database::Service_database` | Constructor. |
| `score/socom/impl/runtime_impl.cpp:313-324` | `Service_database::get_record` | `m_service_records.find(interface)` (`:315`), then `emplace(interface, Service_instances{})` (`:317`), then inner `emplace(instance, Service_record{…})` (`:320-321`). The outer `find`/`emplace` use the minor-ignoring key/hash. |
| `score/socom/impl/runtime_impl.cpp:326-343` | `get_instances(interface, filter)` | `m_service_records.find(interface)` (`:329`); filters by `is_available()` and optional instance. |
| `score/socom/impl/runtime_impl.cpp:345-360` | `get_instances(optional<interface>, filter)` | Iterates all of `m_service_records`; forwards to the first overload at `:349`. |
| `score/socom/impl/runtime_impl.cpp:496` | `m_database.get_record(configuration.interface, instance)` in the client `register_connector` (`:492-524`) | **Client call site.** |
| `score/socom/impl/runtime_impl.cpp:530` | `m_database.get_record(interface, instance)` in the server `register_connector` (`:526-551`) | **Server call site.** |
| `score/socom/impl/runtime_impl.hpp:220-221` | `m_runtime_mutex`, `Service_database m_database{m_runtime_mutex};` | Owned by `Runtime_impl`. |

**Observation (static, not a defect claim).** `get_instances` is declared twice
(`runtime_impl.hpp:109,112`), defined twice (`runtime_impl.cpp:326,345`), and self-called at
`runtime_impl.cpp:349`. No external caller of `Service_database::get_instances` was found in the
working tree; only `get_record` is used.

### 7.1 Record registration reached through `get_record`

| Site | Call | Notes |
|------|------|-------|
| `score/socom/impl/runtime_impl.cpp:366-382` | `Service_record::register_server_connector` | `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)` at `:369`; `m_server.emplace(Interfaced_server{interface, …})` at `:371`; `Server = std::optional` (`runtime_impl.hpp:70`). |
| `score/socom/impl/runtime_impl.cpp:384-399` | `Service_record::register_client_connector` | Returns `Construction_error::duplicate_client` if `m_client` already set (`:386-388`); `m_client.emplace(…)` at `:389`. |
| `score/socom/error.hpp:54-58` | `Construction_error` enum | `duplicate_service,  ///< Service identifier already exists.` (`:55`) — the comment is narrower than the actual key (`instance + id + major`). |
| `score/socom/runtime.hpp:170-178` | `make_server_connector` doc | Speaks of duplicates judged by "the configuration.interface and instance parameters" (`:172-173`, `:176-178`); the public `operator==` includes `minor` while the registration key does not. |

### 7.2 The key/index equivalence question (static, not reproduced)

On the **baseline**, the duplicate key included `minor` (`invariants.md` I-4) while `Service_database`
indexes by `id + major` and ignores it (§6.4). Two enabled-or-constructing server connectors for the
same `id + major + instance` with different minors then (1) build distinct keys, both passing the
insert check at `runtime_impl.cpp:451`, but (2) resolve to the same `Service_record` via the
minor-ignoring `find` at `runtime_impl.cpp:530`, so the second `register_server_connector` reaches
`ASSERT(!m_server)` (`:369`); where the assert does not terminate, `m_server.emplace` (`:371`)
silently replaces the first. On the **working tree**, the draft's key change makes the key as coarse
as the record index, so the second insert at `:451` is rejected first. Both readings are static;
neither is a measured runtime result. Whether this gap is a real defect is an open question.

---

## 8. Tests covering the key and its neighbours

Counts are static `grep` readings from this iteration; the suites were **not executed here**.

| Site | Coverage | Gap for this slice |
|------|----------|--------------------|
| `score/socom/test/unit/service_identifier_tests.cpp` | **New file**, `grep TEST_F` = **87** cases (`:168`…`:2012`) under `ServiceInstanceIdentifierTest`: irreflexivity (`:168`), minor-only duplicate (`:174`) and boundaries (`:182,192,203`), major including `0`/`65535` and adjacency (`:217-246`), service-id/instance distinctness and lexicography (`:262-357`), combined matrices with minor collapse (`:358-419`), equivalence/ordering consistency and independent tuple reference (`:420-536`), strict-weak-ordering property checks over deterministic 36-key and 64-key domains (`:537-735`, `:1055-1148`, `:1456-1488`), text/registry → public-identifier → internal-key conversion boundaries (`:784-1054`, `:1149-1200`, `:1531-1600`), and additional boundary/ladder cases to `:2012`. Metadata in `SetUp()` (`:42-65`): `DerivationTechnique = "boundary-values,equivalence-classes"` (`:50`); `TestType`/certificate links deliberately unset (`:57-64`). | Not executed here. |
| `score/socom/test/unit/runtime_tests.cpp` | **33 macros**: 1 `TEST` (`RuntimeFactoryTest.DefaultConstructorWorks`, `:239`), **31 `TEST_F`** (`:279`…`:1253`), 1 `TEST_P` (`RuntimeBridgeTest.CreationOfClientsWillCallRequestServiceFunction`, `:1311`). Duplicate/lifetime cases include `ConstructDuplicateReturnsDuplicateServiceError` (`:334`), `ConstructDuplicateMultipleTimesReturnsDuplicateServiceError` (`:350`), `CreatingServerConnectorDeletingItAndRecreatingReturnsValidServerConnector` (`:371`), **`ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError` (`:402-431`)**, `ConstructDuplicateSameConfigurationWhileBothConnectorsDisabledReturnsDuplicateServiceError` (`:440`), `ConstructDuplicateWhileFirstConnectorEnabledReturnsDuplicateServiceError` (`:694`), `ConstructDuplicateAfterEnabledConnectorDestroyedReturnsValidServerConnector` (`:986`), `DestroyingOneMajorSlotKeepsOtherMajorSlotOccupied` (`:1141`), `DestroyingOneInstanceSlotKeepsOtherInstanceSlotOccupied` (`:1197`), `DestroyingOneServiceIdSlotKeepsOtherServiceIdSlotOccupied` (`:1253`). Metadata helper `record_registration_key_metadata` (`:264-267`). | None executed here. |
| `score/socom/test/unit/service_interface_identifier_tests.cpp` | Constructors of `Service_interface_identifier`. | No ordering/identity test for `Service_instance_identifier`. |
| `score/socom/test/unit/interface_compatibility_tests.cpp` | `ServerCreatedBeforeClient` / `ClientCreatedBeforeServer` parameterized over id/version. | Covers `is_minor_version_compatible` semantics, not duplicate detection. |
| `score/socom/test/unit/client_tests.cpp` | `DifferentServiceInterfaceId` / `…InstanceId` / `…MajorVersion` / `…MinorVersion`. | Exercises bind/no-bind; not the duplicate-server key. |

Build wiring already present: `score/socom/BUILD:46-54` exposes `impl/service_identifier.hpp` via
`testonly` `impl_service_identifier`; `score/socom/test/unit/BUILD:16-29` defines `socom_test` with
`srcs = glob(include = ["*.cpp"])` and depends on it (`:24`).

---

## 9. Obligations status (none satisfied)

### 9.1 Pinned state from `authority.json`

`engineering_acceptance: pending`; `human_reviews: unanswered`; `safety_class: unknown`;
`codeql_scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload"`; instruction
*"Restart the failed queue for one complete pass through all obligations"*.

All nine pinned sources in `.llm_tmp/context/obligations/` were read this iteration (§1.4); every
`source-index.json` entry is `"native_acceptance": "not_inferred"`.

### 9.2 Obligation status for this slice (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Freedom from compiler warnings & errors (100 %) | `verification_plan.rst` (criterion 9) | **NOT MEASURED** — header is brace-balanced by inspection (§2), but nothing was compiled in this iteration; no host artifact is present here |
| Static code analysis (clang-tidy / CodeQL), findings classified | `code_analysis.rst`; `verification_process.rst` (`gd_req__verification_sca_classification`) | **NOT PERFORMED** — no tool, no build |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` | **UNKNOWN — NOT CLAIMED** — mapping document is `:status: draft` |
| Structural statement / branch coverage goals | `verification_plan.rst` (criteria 1–2) | **NOT MEASURED** — no test execution in this iteration |
| Unit/component testing executed, results recorded | `verification_plan.rst`; `verification_guideline.rst` | **NOT EXECUTED** — 0 tests run this iteration |
| Interface / requirements-based / resource / fault-injection test types | `verification_process.rst`; `verification_plan.rst` | **NOT PERFORMED / applicability not inferred** — identifier-only tests must not be labelled platform validation |
| Boundary / equivalence derivation | `verification_process.rst` | **SOURCE-ONLY** — cases exist in source (§8) but were not executed |
| Fuzzy testing technique | `verification_plan.rst` | **NOT EXECUTED / NOT CLAIMED** — no harness and no measurement |
| Linking tests to requirements (record properties) | `verification_process.rst` (`gd_req__verification_link_tests_cpp`) | **PARTIAL / NOT DONE** — `DerivationTechnique`/`Description` recorded (`service_identifier_tests.cpp:42-65`; `runtime_tests.cpp:264-267`); `TestType`/`Verifies` cannot be set without inventing identifiers |
| External-component AoUs verified | `verification_process.rst` (`gd_req__verification_external_aou`) | **NOT SATISFIED** — no integration/static verdict; no AoU register |
| Independence of verification / review by a different committer | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Implementation inspection checklist IMPL_01…IMPL_03 | `inspection_checklist.rst` | **NOT FILLED** — draft template, no inspection |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** for this slice; no tool run here |
| Obligation collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **ABSENT in this checkout** — directory and every `result.json` not present |
| Native acceptance | `source-index.json` | **`not_inferred` for every entry** |

**Explicit non-satisfaction statement.** Missing tools (no `shell`/build/test in this task), the
unknown safety class and un-inferred applicability, the incomplete extraction of host artifacts, the
absent obligation-collection results, and the unanswered human reviews mean **none of the checked
obligations may be treated as satisfied**. A collection node that retained results would only show
*retention*, not passing; here the results are not present at all. In particular, the absence of
`.llm_tmp/overnight/validation/` and `.llm_tmp/overnight/obligations/*/result.json` is **not**
evidence that the corresponding checks passed.

---

## 10. Measurement status, notice preservation, and pending human review

### 10.1 Measurement status

- **Tools:** `read_file`, `grep`, `glob`, `write_file` only. No `shell`, delegation, web, approval,
  publishing, or engineering acceptance.
- **Executed measurements:** **none** this iteration. No build, no `bazel test`, no runtime. Every
  statement is a static reading of the working tree at the baseline-bound candidate paths, or an
  explicitly-labelled logical consequence (e.g. the §7.2 gap).
- **Test inventory (read, not run):** `service_identifier_tests.cpp` = **87 `TEST_F`**;
  `runtime_tests.cpp` = **31 `TEST_F` + 1 `TEST` + 1 `TEST_P`**.
- **Regression target (source-derived, not executed):**
  `RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError`
  (`runtime_tests.cpp:402-431`) and the key-level minor-collapse cases
  (`service_identifier_tests.cpp:174`, `:182`, `:192`, `:203`, …) assert that a second registration
  differing only in `minor` is rejected as `duplicate_service`. On a key that includes `minor` they
  would fail; on the working-tree key they should pass. This is a `std::set`/strict-weak-ordering
  consequence, not an observed result.
- **Scope:** local, unprotected, scoped. This draft has not been reviewed, accepted, published, or
  reproduced on a full native runtime. Unit/integration execution and human review remain pending.
- **Reproduction path for the next authorized iteration (not run here):**

  ```bash
  bazel build //score/...
  bazel test //score/socom/test/unit:socom_test
  # focused key-level:
  bazel test //score/socom/test/unit:socom_test --test_filter='ServiceInstanceIdentifierTest.*'
  # focused runtime regression:
  bazel test //score/socom/test/unit:socom_test \
      --test_filter='RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError'
  # integration (per the pinned plans)
  bazel test --config=qemu-integration //tests/integration_test/...
  ```

- **No correction was needed for the recorded syntax failure** (§2), and **no test was expanded** in
  this iteration. The write boundary ("only that report may be written") and the permitted tool set
  (no `edit_file`) were both respected.

### 10.2 Notice preservation

- No source, build, test, config, `NOTICE`, `LICENSE`, `REUSE.toml`, or prior-report file was
  created, edited, or deleted by this iteration; **only this report was written**. Every existing
  Apache-2.0 / SPDX notice header is untouched, and all 38 prior-report files under
  `.llm_tmp/overnight/prior-reports/` plus `.llm_tmp/overnight/reports/scope.md` were preserved.
- The header the task flagged (`score/socom/impl/service_identifier.hpp`) was inspected and left
  unchanged because it is already brace-balanced and otherwise well-formed (§2).
- This report itself carries the Apache-2.0 header.
- Any future implementation in this slice must carry the Apache-2.0 header on new files, including
  `service_identifier_tests.cpp`, per `.github/instructions/code-style.md` and `REUSE.toml`.

### 10.3 Pending human review checklist

- [ ] **Confirm the §2 source inspection**: the header is already brace-balanced (braces at `:19`,
      `:29`, `:32`, `:38`; line `:39` blank; single nested close `}  // namespace score::socom`), so
      the recorded syntax failure is stale and no correction is required. If the *"cancelled
      draft"* is a different revision that still carries the extra brace, locate it and authorize its
      correction; it is not the file in this checkout.
- [ ] **Resolve the instruction conflict**: was a review-only iteration intended (report only, as
      done here), or was source correction expected? The write boundary forbade the latter, and it
      was moot because no defect was present.
- [ ] **Confirm the call-site map in §3–§7** against baseline `f8a196c3…`, including the
      minor-excluded key (`service_identifier.cpp:28-29`), the only production key construction
      (`runtime_impl.cpp:443`), and the minor-ignoring database index (`runtime_impl.hpp:116-134`).
- [ ] **Confirm the baseline binding** in §1.2–1.3 (issue #84 ↔ commit `f8a196c3…`) and that
      `prior-reports/invariants.md` I-4's baseline ordering (`minor` included) still describes the
      committed baseline.
- [ ] **Answer the open design questions**: minor-in-key semantics, duplicate-vs-supersede, status of
      `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)` (`runtime_impl.cpp:369`), config wildcard /
      `uint32→uint16` narrowing (`mw_someip_config.fbs:19,23` → §5.1), and public-identifier shape.
- [ ] **Confirm whether the §7.2 key/index gap is a real defect** and, if so, treat it as the slice's
      regression target.
- [ ] **Confirm the test coverage** (87 key cases and the 31 `TEST_F` + 1 `TEST` + 1 `TEST_P` runtime
      cases) and that using the public `Runtime::make_server_connector()` path is acceptable. Do
      **not** present the identifier-only tests as platform validation or claim an unmeasured fuzzy
      technique.
- [ ] **Keep the #84 public `Service_interface_identifier` restructure, FindService wildcard handling,
      and the config minor-wildcard narrowing out of this bounded slice** until separately accepted.
- [ ] **Supply the missing artifacts** (`.llm_tmp/overnight/obligations/*/result.json` and
      `.llm_tmp/overnight/validation/`) into this checkout; do not infer passing from absence or from
      prior reports' retained summaries.
- [ ] **Run the full native suite** (`bazel test //score/socom/test/unit:socom_test` and the broader
      `//score/...` set), including `runtime_tests.cpp`, record results, and schedule independent
      human review (the approver must differ from the author, per
      `gd_req__verification_independence`).

---

*End of call-site review draft. Local, unprotected, scoped. No engineering acceptance; human reviews
unanswered; full native runtime tests pending. Every statement is a local reading of the working
tree, a prior report's recorded reading, or an explicitly-labelled logical consequence — none is
acceptance, review approval, publication, or a full native run.*
