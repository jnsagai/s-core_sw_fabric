<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — traceability review of the bounded duplicate-server registration-key slice

**Document type:** review draft (test-metadata / requirement-link / source-design
traceability review + docs-metrics status + obligations status)
**Date:** 2026-10-03
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version
handling in socom* (issue #84). This review covers **descriptions, `TestType`,
`DerivationTechnique`, `PartiallyVerifies`/`FullyVerifies` links, requirement/interface
types, source/design consistency and docs metrics**.
**Branch:** `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ`
**Status:** local, unprotected, scoped. **No engineering acceptance exists. Human reviews
are unanswered. Full native runtime tests remain pending.** Every measured number below is
quoted from a *retained* `.llm_tmp/overnight` artifact; every source statement is a direct
`read_file`/`grep`/`glob` reading of this checkout. Nothing here is published, reviewed,
accepted, or a full native execution.

> **Tool / write boundary actually observed.** Only `read_file`, `grep`, `glob` and
> `write_file` were available and were the only tools used. No `shell`, no delegation, no
> web access, no approval, no publishing, and no engineering acceptance was performed.
> The task states: *"This is a review draft: only that report may be written."*
> Accordingly **this iteration wrote exactly one file — this report.** No source, build,
> test, config, `NOTICE`, `LICENSE`, `REUSE.toml`, or prior-report file was created,
> edited, or deleted. Every file under `.llm_tmp/overnight/prior-reports/`,
> `.llm_tmp/overnight/reports/`, `.llm_tmp/overnight/validation/`, and
> `.llm_tmp/overnight/obligations/` was read only and preserved unchanged.
>
> **Instruction conflict, recorded explicitly.** The task also directs *"Inspect and
> correct the actual source before expanding tests"* because *"The cancelled draft has a
> measured GCC syntax failure: an extra closing brace in
> `score/socom/impl/service_identifier.hpp` at line 39."* Direct inspection shows the
> actual source is **already brace-balanced** and line 39 is **blank** (§2). There is
> therefore no defect to correct; and the task's own write restriction forbids writing any
> source path in this review draft anyway. Both facts are recorded rather than silently
> reconciled. No test was "expanded" here either: the current draft's suites already exist
> on disk (§3).

---

## 0. Summary

1. **Recorded syntax failure — inspected; not present in the actual source.**
   `score/socom/impl/service_identifier.hpp` is brace-balanced: `grep namespace` returns
   only `:19` (`namespace score::socom {`) and `:38` (`}  // namespace score::socom`);
   the struct opener is `:29` and its closer `:32`. Two openers, two closers, net balance
   `0`; line 39 is empty and line 40 is `#endif`. A repository-wide
   `glob **/service_identifier.hpp` finds a single path. Independently, every retained
   compile of a translation unit that includes this header exits `0` under
   `g++-12 -std=c++17 -Wall -Wextra -Werror` (§2.2). **No header edit was made and none is
   required.**
2. **The source-supported test metadata is present but partial.**
   `process_checks/result.json` inventories exactly two files with record properties:
   `service_identifier_tests.cpp` (`test_macros: 91`; properties `DerivationTechnique`,
   `Description`) and `runtime_tests.cpp` (`test_macros: 33`; same two properties)
   (§3). Both record `DerivationTechnique` and a non-empty `Description`. **`TestType` is
   not recorded in either file, and neither `PartiallyVerifies` nor `FullyVerifies` is
   recorded anywhere.** A repository-wide `grep 'RecordProperty' score/` returns only these
   two files.
3. **The missing links cannot be completed from the repository's requirements as they
   exist, and none was invented.** The only real `:id:` requirement directives are the
   stakeholder requirement `stkh_req__someip_gw__interoperability`
   (`docs/requirements/stakeholder.rst:24`) and the TC8 set
   (`feat_req__tc8_conformance__conformance`,
   `comp_req__tc8_conformance__*`). All ten `:reqtype:` occurrences in `docs/tc8_conformance/`
   and `docs/requirements/` are `Functional`; **no `:reqtype: Interface` need exists**.
   No socom component requirement exists: `docs/requirements/component/index.rst` and
   `docs/requirements/feature/index.rst` are placeholder toctrees. Therefore a Unit Test
   `PartiallyVerifies`/`FullyVerifies` link to a Component Requirement
   (`gd_req__verification_checks`, `:196`) has **no valid target**, and a
   `requirements-based` / `interface-test` `TestType`
   (`gd_req__verification_checks_extended`, `:211-212`) is **explicitly prohibited without
   a real link**. Missing links remain missing (§5).
4. **`TestType` is a known, recorded gap, not a pass.**
   `gd_req__verification_checks` (`:191`) says *"TestType and DerivationTechnique shall be
   set"*; only `DerivationTechnique` is set. Every otherwise-allowed `TestType` value in
   `verification_plan.rst` (`:167-207`) is either link-dependent
   (`requirements-based`, `interface-test`), harness-dependent (`static-code-analysis`,
   `inspection`, `walkthrough`, `resource-usage`, `fault-injection`), or would be an
   unmeasured coverage-tool claim (`structural-statement-coverage`,
   `structural-branch-coverage`). The tests record the omission and its rationale in-source
   (`service_identifier_tests.cpp:57-64`; `runtime_tests.cpp:261-263`) (§4, §6).
5. **Source/design consistency is incomplete.** The minor-excluding registration-key
   identity is documented **only in code comments**
   (`impl/service_identifier.hpp:21-28`, `impl/service_identifier.cpp:21-27`). Iteration
   `grep`es over `score/socom/docs` find **no** occurrence of `duplicate` and no
   version-identity content (`version` occurs only in `docs/index.rst:25` licence/`:version:`
   metadata). There is no requirement or design element to trace the implementation to
   (§7).
6. **Docs metrics are not measured.** The documented quality-pack flow
   (`README.md:46-72`; `.github/workflows/quality_pack.yml`) is
   `bazel test //:unit_tests //:component_tests` → `bazel run //:docs` →
   `bazel run //:traceability_gate -- --metrics-json _build/metrics.json
   --need-type=comp_req`. The retained `native_traceability` run records
   `unit-component-tests` exit `0` but `docs` exit `2` and `traceability` exit `1`;
   `native_docs` records `docs` exit `2`. No `_build/**` or `_quality_pack/**` artifact
   exists in this checkout. The CI gate is `continue-on-error: true` with thresholds
   defaulting to `0`; **a nonblocking CI gate is not acceptance** (§8).
7. **No obligation is satisfied.** A successful collection node means the results were
   *retained*, not that the checks *passed*. Missing/unstated tools, unknown safety class,
   un-inferred applicability, incomplete extraction (focused translation unit only), a
   build-only native test leg and unanswered human reviews mean none of the checked
   obligations may be treated as satisfied (§9).

---

## 1. Binding to the verified baseline, pinned sources, prior reports, host feedback

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` | `.llm_tmp/context/issue-snapshot.json:2-4` |
| Title | *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:3` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` (unchanged) | `.llm_tmp/context/issue-snapshot.json:19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**: service-instance identifier = `service id + major + minor + instance id`;
service identifier = `service id + major`; FindService = `service id + major +
optional<minor> + optional<instance>`; and the proposal to "exclude the minor version and
make it a property of the service instance". There is **no comment and no acceptance
record** in the snapshot, so none of it is binding. This is the root of the traceability
gap: the implemented behaviour follows a *proposal* for which no `comp_req`/design element
was ever written.

### 1.2 Verified baseline and bounded candidate paths

| Item | Value | Source |
|------|-------|--------|
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |
| Branch | `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ` | environment |

The six candidate source paths (`.llm_tmp/context/candidate-files.json`), the only paths
this slice may change in an authorized iteration:

1. `score/socom/BUILD`
2. `score/socom/impl/service_identifier.cpp`
3. `score/socom/impl/service_identifier.hpp`
4. `score/socom/test/unit/BUILD`
5. `score/socom/test/unit/runtime_tests.cpp`
6. `score/socom/test/unit/service_identifier_tests.cpp`

The `null` baseline blob for `service_identifier_tests.cpp` in
`candidate-files.json:23-24` marks it as a **new** file: it exists on disk only in the
un-merged working tree (the "cancelled draft"), never in the baseline commit.

The production duplicate-server registration key is
`Service_instance_identifier{Service_interface_identifier interface; Service_instance
instance;}` (`score/socom/impl/service_identifier.hpp:29-32`), whose only operator is the
out-of-line `operator<` (`:35`). Its identity is `(instance, service id, major)` with
`minor` deliberately excluded (`score/socom/impl/service_identifier.cpp:28-29`).

**Hash caution.** The `candidate-files.json` `sha256` for the header is `96b33a1f…`, while
the retained host captures (`validation/measurement.json`, `process_checks/result.json`,
`native_*/result.json`) record the header as `bdce3fcb…`. The working tree has therefore
moved relative to the context snapshot; the binding above is by path, not by a
re-derived hash (hashing would require a `shell`, which was unavailable).

### 1.3 Pinned obligation sources read

All nine `.llm_tmp/context/obligations/source-index.json` entries are present, each with
`"native_acceptance": "not_inferred"`, plus `authority.json`:

| id | file | status note (this checkout) |
|----|------|-----------------------------|
| `coding_guidelines` | `coding_guidelines.rst` | MISRA C++:2023 with C++17 |
| `code_analysis` | `code_analysis.rst` | clang-tidy + gcc/clang warnings; sanitizers; gcov/gcovr |
| `misra_mapping` | `misra_mapping.rst` | **`:status: draft`** — not applied |
| `verification_plan` | `verification_plan.rst` | `:status: valid`; `TestType` table `:167-207`; `DerivationTechnique` table `:245-268` |
| `development_plan` | `development_plan.rst` | C++17, GCC host, Bazel |
| `tool_management` | `tool_management.rst` | tools must be identified / evaluated / qualified |
| `verification_process` | `verification_process.rst` | `:status: valid`; `gd_req__verification_checks` `:178-196`, `..._extended` `:198-212` |
| `verification_guideline` | `verification_guideline.rst` | traceability `:36`, workflow `:70-89`, partial/full coverage properties `:83-89` |
| `inspection_checklist` | `inspection_checklist.rst` | **`:status: draft`** |

`authority.json` records `"engineering_acceptance": "pending"`,
`"human_reviews": "unanswered"`, `"safety_class": "unknown"`, `"codeql_scope": "Public
Apache-2.0 eclipse-score/inc_someip_gateway; no upload"`, and
`"instruction": "Restart the failed queue for one complete pass through all obligations"`.

### 1.4 Prior reports, host feedback, obligation results read

- `.llm_tmp/overnight/prior-reports/` — present and preserved (the traceability-relevant
  ones consulted: `test_metadata.md`, `unit_matrix.md`, `coverage_review.md`, `key_fix.md`,
  `scope.md`, `runtime_enabled.md`, `ordering_tests.md`, `deviation_drafts.md`, and the
  prior `traceability_review.md`).
- `.llm_tmp/overnight/reports/` — earlier reports present and preserved. Previous
  iterations already recorded the brace-balance finding, the metadata inventory, and the
  missing-link rationale; this report re-verifies them against the current tree (now a
  91-case suite) rather than restating them.
- `.llm_tmp/overnight/validation/` — present: `check-result` = `0`;
  `after-compile.command.json` / `after-compile.stderr` (empty) and
  `after-compile.command.json` exit `0`; `after.json` (91 tests / 0 failures);
  `before.json` (91 tests / 33 failures); `measurement.json`
  (`origin: local_unprotected_measurement`, `initiator: Fabro host hook`,
  `engineering_acceptance: pending`, `full_native_tests: not_executed`;
  `baseline_with_agent_tests` `91 / 33`, `candidate` `91 / 0`; compiler
  `g++-12`). **Scope caveat:** the measurement compiles only the focused identifier
  translation unit, and `--build_tests_only`/`not_executed` means the runtime suite was
  not executed natively (§8, §9).
- `.llm_tmp/overnight/obligations/*/result.json` — present (25 checks). The ones used here
  are `process_checks/`, `compiler_diagnostics/`, `focused_coverage/`, `native_tests/`,
  `native_traceability/`, `native_docs/`, and `native_coverage/`.

Per the task rule, a successful collection node means results were **retained**, not that
checks **passed**.

---

## 2. The recorded GCC syntax failure — inspection of the actual source

### 2.1 Direct reading (this iteration)

`score/socom/impl/service_identifier.hpp` read from the working tree is **40 lines** and
brace-balanced:

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

This iteration's `grep namespace` returns exactly `:19` and `:38`. Two openers and two
closers give net brace balance `0`, and line 39 contains no text. A repository-wide
`glob **/service_identifier.hpp` returns exactly one path, so there is no second,
differently-braced copy. **The task's "extra closing brace … at line 39" is not present in
the actual source**; it matches only the earliest, pre-correction reports (which quote the
split-form `}  // namespace socom` + `}  // namespace score`). The repository's
nested-namespace convention (used consistently by the sibling `impl/service_identifier.cpp`,
closer at `:32`) is followed here.

### 2.2 Retained compiler corroboration (read, not produced here)

- `validation/after-compile.command.json` and `validation/before-compile.command.json` both
  compile `score/socom/impl/service_identifier.cpp` (which `#include`s this header) with
  `/usr/bin/x86_64-linux-gnu-g++-12 -std=c++17 -Wall -Wextra -Werror`, and each records
  `exit_code: 0`; `after-compile.stderr` is empty.
- `obligations/compiler_diagnostics/result.json` (`status: completed`) records
  `gcc-compile` exit `0`, `gcc-tests` exit `0`, `clang-compile` exit `0`, `clang-tests`
  exit `0` for a focused executable over `service_identifier.cpp` + `string_registry.cpp` +
  `service_identifier_tests.cpp`. Its limits state: *"Focused executable only; GCC 12.3 /
  Clang 19 differ from native toolchain pins"* and *"GoogleTest compiled separately with
  warnings retained; -Werror on target and tests"*.

A surviving unmatched brace would have made the GCC leg fail. These are local,
unprotected, scoped captures — retention and evidence, not acceptance.

### 2.3 Minimal repair (retained for reference only; not applied)

Should the imbalance ever reappear, the minimal correction — matching the sibling `.cpp`
— is:

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

Applying this to the already-balanced file would be a no-op at best; deleting a brace from
a balanced header would *create* the reported defect. **No source edit was made**, because
(a) there is no defect and (b) this review draft may write only this report.

### 2.4 Self-recorded staleness inside the test file

The test suite itself records the correction. `service_identifier_tests.cpp:1213-1216`
and `:2043-2048` state the header "is brace-balanced (the recorded syntax failure is the
stale pre-correction state)". One embedded detail is now itself stale: `:2046` cites the
host capture as "87 tests / 0 failures", whereas the current retained
`validation/after.json` records **91 tests / 0 failures**. This is a source-comment /
measurement currency mismatch, not a functional defect; it is flagged for human review
(§11).

---

## 3. Test-metadata inventory (descriptions, `DerivationTechnique`, `TestType`, links)

### 3.1 What the retained process check measured

`obligations/process_checks/result.json` (`check_ref: recollect_process_checks`,
`status: completed_with_blockers`, `origin: local_unprotected_measurement`) contains the
only lexical metadata inventory of this slice:

| Path | test_macros | record_properties |
|------|-------------|-------------------|
| `score/socom/test/unit/service_identifier_tests.cpp` | **91** | `DerivationTechnique`, `Description` |
| `score/socom/test/unit/runtime_tests.cpp` | **33** | `DerivationTechnique`, `Description` |

Its recorded `blockers` are decisive for this review and are quoted verbatim:

- "Lexical metadata inventory cannot prove semantic requirement coverage"
- "Safety/QM applicability and approved tailoring unknown"
- "Independent inspection and acceptance required"
- "External AoU and full integration verification require scoped review"

The check has **no commands** (`"commands": []`) and never asserts requirement coverage;
it only inventories record-property *names*. A repository-wide
`grep 'RecordProperty' score/` confirms the two files above are the **only** C++ tests in
the repository tree that use gtest record properties:
`service_identifier_tests.cpp:50-51` and `runtime_tests.cpp:265-266`.

### 3.2 `service_identifier_tests.cpp` (the key suite)

- **Apache-2.0 header** at `:1-12`.
- Fixture `ServiceInstanceIdentifierTest` `SetUp()` (`:42-65`) records:
  - `RecordProperty("DerivationTechnique", "boundary-values,equivalence-classes")` (`:50`);
  - a single **fixture-wide** `Description` (`:51-55`):
    *"Deterministic identity, ordering, boundary and equivalence-class checks for the
    Service_instance_identifier duplicate-server registration key (issue #84): the key
    identity is (instance, service id, major) and the minor version is not part of it."*
- `:57-64` explicitly records why `TestType` and the
  `PartiallyVerifies`/`FullyVerifies` links are **not** recorded: the slice has "no
  verified native requirement or interface identifier to link to",
  `gd_req__verification_checks_extended` forbids an `interface-test`/`requirements-based`
  `TestType` without such a link, and "inventing an identifier is prohibited".
- **91 `TEST_F` cases** (`:168` … `:2181`), counted this iteration by `grep 'TEST_F'` and
  corroborated by the metadata inventory (`test_macros: 91`) and by the retained
  `validation/after.json` (`91` tests, all in `ServiceInstanceIdentifierTest`). The newest
  cases are the ninth-expansion, coverage-driven
  `FreshDynamicServiceIdStringViewRegistersAndCollapses` (`:1982`) and
  `FreshDynamicServiceIdRvalueRegistersAndCollapses` (`:2012`), and the tenth-expansion
  conversion-boundary cases
  `ConvertedInterfaceAndInstanceConstructionPathsAgreeAcrossFullCrossProduct` (`:2060`),
  `ConvertedConfigMinorNarrowingBoundariesCollapseAndDistinguish` (`:2103`),
  `FreshDynamicInstanceIdStringViewRegistersAndCollapses` (`:2150`) and
  `FreshDynamicInstanceIdRvalueRegistersAndCollapses` (`:2181`). Their rationale comments
  (`:1965-1980`, `:2041-2059`) state they were added to take the `String_registry`
  "not found" insertion branches and conversion boundaries, not from a requirement.

**Review note (description adequacy).** `gd_req__verification_link_tests_cpp` permits
"attributes which are common for all test cases" in `SetUp()`, so a fixture-wide
`Description` is formally allowed. However, all 91 cases carry the *same* generic
description, which is accurate for the identity/ordering matrix but does **not** describe
the conversion/registry cases (`:784`…`:1200`, `:1531`…`:1600`) or the coverage-driven
dynamic-insertion cases specifically; test-name specificity is the only per-case
descriptor. `gd_guidl__verification_guide` (`:47-55`) asks for a description that is
"Clear, Specific, Measurable, Complete". This is recorded as a quality observation, not a
metadata violation.

### 3.3 `runtime_tests.cpp` (the runtime regressions)

- **Apache-2.0 header** at `:1-12`.
- `RuntimeTest` fixture helper `record_registration_key_metadata` (`:253-267`) records
  `RecordProperty("DerivationTechnique", "design-analysis,equivalence-classes")` (`:265`)
  and a **per-case** `RecordProperty("Description", description)` (`:266`).
- Its doc comment (`:261-263`) records the same omission rationale for `TestType` and the
  verifies links as the key file.
- `grep 'record_registration_key_metadata'` returns the definition at `:264` and **25 call
  sites**: `:335`, `:351`, `:372`, `:403`, `:442`, `:473`, `:507`, `:540`, `:575`, `:609`,
  `:643`, `:695`, `:728`, `:765`, `:798`, `:834`, `:871`, `:906`, `:953`, `:987`,
  `:1048`, `:1094`, `:1142`, `:1198`, `:1254`. Each passes a distinct, non-empty
  per-case description.
- Test macro census (this iteration): **31 `TEST_F`** (`:279` … `:1253`) **+ 1 `TEST`**
  (`:239`) **+ 1 `TEST_P`** (`:1311`) = the 33 macros the inventory counts. The
  bridge/factory tests and the `TEST_P` deliberately carry **no** registration-key
  metadata because their subject is not the key.

### 3.4 Measurement currency of the metadata

The metadata is observable in JUnit output because gtest emits record properties. The
retained `validation/after.json` shows `DerivationTechnique` and `Description` on **all 91
cases** it ran. The metadata is set in `SetUp()` / per-case, so it applies to the newest
cases as well. This is a focused-translation-unit capture and is **not** native
acceptance.

---

## 4. Conformance against the pinned metadata rules

### 4.1 The rules

- `gd_req__verification_link_tests` (`verification_process.rst`) fixes the linking
  metadata and the allowed `TestType` (`fault-injection`, `interface-test`,
  `requirements-based`, `resource-usage`) and `DerivationTechnique`
  (`requirements-analysis`, `design-analysis`, `boundary-values`, `equivalence-classes`,
  `fuzz-testing`, `error-guessing`, `explorative-testing`) values.
- `gd_req__verification_checks` (`verification_process.rst:191-196`) says *"TestType and
  DerivationTechnique shall be set"*, *"Description shall not be empty"*, and that a Unit
  Test `Partially/FullyVerifies` link must target at least one Component Requirement.
- `gd_req__verification_checks_extended` (`:211-212`) makes
  `requirements-based`/`interface-test` `TestType` values link-dependent.
- `verification_plan.rst` fixes the allowed identifier sets (`TestType` `:167-207`;
  `DerivationTechnique` `:245-268`).

### 4.2 Rule-by-rule result

| Rule element | Recorded value | Verdict |
|--------------|----------------|---------|
| Record properties for C++ tests | gtest `RecordProperty` used in both candidate test files | **Met (mechanism)** |
| Common attributes in `SetUp()` | key file's `DerivationTechnique`/`Description` in `SetUp()` (`:50-55`) | **Met (common)** |
| Per-case attributes in the test case | `runtime_tests.cpp` per-case `Description` (25 calls); key file has none per-case | **Met for runtime; not per-case for the 91 key cases** |
| `DerivationTechnique` set | `boundary-values,equivalence-classes` (key); `design-analysis,equivalence-classes` (runtime) | **Met**; all identifiers allowed by `verification_plan.rst:245-268` |
| `Description` non-empty | present in both files | **Met** (see §3.2 adequacy note) |
| `TestType` set | **absent in both files** | **NOT MET** (`gd_req__verification_checks:191`) |
| `PartiallyVerifies`/`FullyVerifies` | **absent everywhere** | **Not set**; in a Unit Test they must link a Component Requirement if set — there is none (§5) |
| `fuzz-testing` technique | not claimed | **Not claimed** — correctly, because no fuzz harness/measurement exists |

### 4.3 Why `TestType` cannot be validly filled here

`verification_plan.rst:167-207` allows eight `TestType` values. Applied to these two test
files:

| Allowed `TestType` | Applicable? | Reason |
|--------------------|-------------|--------|
| `requirements-based` | **No** | Needs a requirement link; no socom `comp_req` exists; `_extended` forbids it without one; inventing an id is prohibited |
| `interface-test` | **No** | Needs an interface link; no `:reqtype: Interface` need exists anywhere in `docs/` |
| `structural-statement-coverage` | **No (unmeasured claim)** | These are behaviour tests, not a coverage-tool artifact; no retained `TestType`-scoped coverage run exists for the native target |
| `structural-branch-coverage` | **No (unmeasured claim)** | Same; the focused gcovr figure (100 % line / 78.6 % branch) is a separate `focused_coverage` check, not a `TestType` assertion |
| `static-code-analysis` | **No** | These tests execute code at runtime; they are not a static analysis |
| `walkthrough` | **No** | No walkthrough was performed |
| `inspection` | **No** | `inspection_checklist.rst` is a draft template and was not filled |
| `resource-usage` | **No** | No resource evaluation was performed |

Conclusion: with the repository's current requirements model there is **no truthful,
source-supported `TestType`** for this slice. The gap is recorded in-source
(`service_identifier_tests.cpp:57-64`, `runtime_tests.cpp:261-263`) and must be closed by a
human supplying the native links (or an approved coverage-type convention), **not** by an
invented identifier. `TestType` remaining unset is a **known incompleteness**, not a pass.

---

## 5. Requirement/interface inventory and types

### 5.1 Verified requirement-link inventory

A repository-wide `grep ':id:' docs` yields these directives (architecture/decision ids are
`comp__*`, `logic_arc_int__*`, `dec_rec__*`, `feat__*`, which are **not** linkable
requirements):

| Identifier (verified `:id:`) | Source | `:reqtype:` | Applicable to this slice? |
|------------------------------|--------|-------------|----------------------------|
| `stkh_req__someip_gw__interoperability` | `docs/requirements/stakeholder.rst:24` | Functional | no — wire-level interoperability |
| `feat_req__tc8_conformance__conformance` | `docs/tc8_conformance/requirements.rst:25` | Functional | no — TC8 wire conformance |
| `comp_req__tc8_conformance__sd_offer_format` | `docs/tc8_conformance/requirements.rst:56` | Functional | no |
| `comp_req__tc8_conformance__sd_cyclic_timing` | `:76` | Functional | no |
| `comp_req__tc8_conformance__sd_find_response` | `:95` | Functional | no |
| `comp_req__tc8_conformance__sd_sub_lifecycle` | `:114` | Functional | no |
| `comp_req__tc8_conformance__sd_phases_timing` | `:136` | Functional | no |
| `comp_req__tc8_conformance__msg_resp_header` | `:159` | Functional | no |
| `comp_req__tc8_conformance__msg_error_codes` | `:181` | Functional | no |
| `comp_req__tc8_conformance__evt_subscription` | `:205` | Functional | no |

No identifier scopes socom registration-key / version handling. `grep ':reqtype: docs`
returns exactly ten requirement-attribute matches plus `docs/requirements/index.rst:118`,
which is the *documentation of allowed values*, not a need; **every one is `Functional`**.
There is **no `:reqtype: Interface` need**, and **no `Process` or `Non-Functional` need**
either.

### 5.2 Requirement/interface types and the missing targets

- `docs/requirements/index.rst:109-120` declares the mandatory attributes and the allowed
  `:reqtype:` set (`Functional`, `Interface`, `Process`, `Non-Functional`). The existing
  needs use only `Functional`; the scheme documents `:satisfies:` as mandatory at feature
  and component level.
- `docs/requirements/component/index.rst` is a **placeholder toctree** ("Add component
  requirement files … as they are created"); there is **no `comp_req__socom__*`** and no
  file defining one. `docs/requirements/feature/index.rst` is likewise a placeholder; the
  only feature requirement is the TC8 one.
- `aou_req` appears only as scheme documentation; no `aou_req` need exists.
- The repository's own CI comments acknowledge the gap:
  `.github/workflows/quality_pack.yml` says thresholds "default to 0 while comp_req
  coverage is being (re-)built up against the SOME/IP protocol spec".

Consequently:

| Missing identity | Consequence |
|------------------|-------------|
| socom Component Requirement for registration-key / version handling | `PartiallyVerifies`/`FullyVerifies` cannot be set; `TestType=requirements-based` forbidden by `_extended` |
| Interface requirement/identifier for `Service_instance_identifier` | `TestType=interface-test` forbidden by `_extended` (no interface need exists) |
| Human review / independence record | `gd_req__verification_independence` unmet (`authority.json: human_reviews: unanswered`) |

**Missing links remain missing.** No `comp_req__`, `feat_req__`, or `stkh_req__` string
appears in either candidate test file, and none was invented.

---

## 6. `DerivationTechnique` and `Description` review (detail)

| Aspect | Key suite | Runtime regression suite |
|--------|-----------|--------------------------|
| Recorded `DerivationTechnique` | `boundary-values,equivalence-classes` (`:50`) | `design-analysis,equivalence-classes` (`:265`) |
| Allowed? | Yes (`verification_plan.rst:257-264`) | Yes (`:253-262`) |
| `Description` scope | one fixture-wide string for all 91 cases (`:51-55`) | per-case strings via helper (25 cases) |
| `Description` non-empty | Yes | Yes |
| `TestType` | absent | absent |
| `Partially/FullyVerifies` | absent | absent |

Assessment:

- The `DerivationTechnique` values are truthful and source-supported: the key suite is
  boundary/equivalence derived (major/minor/instance boundaries and equivalence classes of
  `std::set` identity), and the runtime cases are derived from the registration-key design
  and its equivalence classes. No `fuzz-testing` is claimed.
- The key suite's single generic `Description` is technically permitted by
  `gd_req__verification_link_tests_cpp` but weakens per-case traceability: 91 distinct test
  cases share one sentence. This is especially relevant for the newest cases
  (`:1982`, `:2012`, `:2060`, `:2103`, `:2150`, `:2181`), which are explicitly
  **coverage-driven** and therefore are not derived from a requirement or design element.
  Their `DerivationTechnique` tag describes the assertion they make rather than why they
  were added. This is recorded as a traceability observation for human review; no edit was
  made.
- Descriptions are non-empty, so the `gd_req__verification_checks` "Description shall not
  be empty" element is met; the "TestType shall be set" element is **not** met (§4).

---

## 7. Source/design consistency

### 7.1 Implementation as it stands

- Internal key identity: `std::tie(lhs.instance, lhs.interface.id,
  lhs.interface.version.major)` (`impl/service_identifier.cpp:28-29`) → `(instance,
  service id, major)`; `minor` excluded.
- Code documentation: the header comment (`impl/service_identifier.hpp:21-28`) and the
  `.cpp` rationale comment (`impl/service_identifier.cpp:21-27`) both state the exclusion
  and tie it to issue #84 and to the minor-ignoring `Service_database` index.
- Public type unchanged: `Service_interface_identifier{Id id; Version{major, minor}}`
  with full-version `operator==`, `operator<` and `std::hash`
  (`score/socom/service_interface_identifier.hpp`); the exact-major and client-minor ≤
  server-minor compatibility rules remain in `is_interface_compatible`
  (`impl/runtime_impl.cpp`).

### 7.2 Design documentation

The socom design bundle (`score/socom/docs/`) contains:

- `docs/index.rst` and `docs/design/index.rst` (bundle/toctree placeholders);
- `docs/design/30_structural_view.rst` — Runtime, Client_connector, Server_connector;
- `docs/design/40_behavioral_view.rst` — creation/connectivity, deadlock behaviour;
- `docs/design/50_state_dynamics_view.rst` — state dynamics;
- PlantUML component/interaction/state models.

Iteration `grep`es over `score/socom/docs` find connector/runtime/deadlock content but
**no** occurrence of `duplicate`, and no version-identity content (`version` occurs only in
`docs/index.rst:25` as `:version: 1` metadata). There is **no design element describing the
registration key, the minor-excluding identity, or duplicate-server rejection**. The design
documents are therefore **inconsistent-with/incomplete-for** the implemented behaviour:
the behaviour is documented only in code comments.

### 7.3 Traceability consequence

The chain that S-CORE traceability expects
(`verification_guideline.rst:36`: "All verification activities should be traceable to
requirements, architectural design, etc.") is broken at both ends for this slice:

- **requirement → implementation:** issue #84 is an unaccepted proposal; no `comp_req`
  captures "minor is not part of the duplicate-server registration key".
- **design → implementation:** no design element in `score/socom/docs/` records the key or
  version semantics.
- **test → requirement/design:** therefore the tests' `PartiallyVerifies`/`FullyVerifies`
  links have no honest target (§5).

The implementation itself is internally consistent (key vs. record index vs. compatibility
rules), and the code comments are accurate; the gap is in the requirements/design artifacts
and their links, not in the source comments or tests.

---

## 8. Docs metrics, native tests, and the `traceability_gate`

### 8.1 The documented flow

`README.md:46-72` documents the quality-pack flow:

```sh
bazel test //:unit_tests //:component_tests
bazel run //:docs
# generates _build/index.html, _build/needs.json, _build/metrics.json
bazel run //:traceability_gate -- --metrics-json "$PWD/_build/metrics.json"
```

`.github/workflows/quality_pack.yml` runs the same sequence in CI: builds the unit +
component tests ("needed for test links"), runs `//:docs`, then runs
`//:traceability_gate -- --need-type=comp_req` with **`continue-on-error: true`** while
thresholds default to `0` (comment: "default to 0 while comp_req coverage is being
(re-)built up"), and uploads `_build/metrics.json` and `_quality_pack/gate.txt` as an
artifact.

### 8.2 Status in this checkout

| Artifact / command | Status |
|--------------------|--------|
| `native_docs/result.json` — `bazel run //:docs` | `findings_or_execution_failure`; `docs` command exit `2` |
| `native_traceability/result.json` — `unit-component-tests` | `exit_code: 0` (tests target passed in the retained local run) |
| `native_traceability/result.json` — `docs` | `exit_code: 2` |
| `native_traceability/result.json` — `traceability` gate | `exit_code: 1` |
| `native_traceability/status` | `findings_or_execution_failure` |
| `_build/metrics.json`, `_build/needs.json`, `_build/index.html` | **absent** (`glob _build/**` empty) |
| `_quality_pack/gate.txt` | **absent** (`glob _quality_pack/**` empty) |
| `native_tests/result.json` | `status: completed`; command is `bazel test //... --build_tests_only` (build only, not execution) |
| `native_coverage/result.json` | `status: completed`; coverage report exit `0`; limit: *"Repository CI threshold 73 is not platform 85/100 line-and-branch acceptance"* |
| `focused_coverage/coverage-summary.json` | 100 % line (36/36), 78.6 % branch (11/14), focused files only |
| `validation/measurement.json` | `full_native_tests: not_executed`; candidate 91/0, baseline-with-agent-tests 91/33 |

### 8.3 Interpretation

- **No docs metric exists for this slice.** The traceability metrics the docs build would
  produce (`metrics.json`, `needs.json`) and the gate summary are not present; the docs
  build itself exits `2` and the gate exits `1` in the retained run. There is no measured
  test-to-requirement linkage and no measured coverage percentage from the docs flow. The
  focused gcovr figure (100 % line / 78.6 % branch) is a **different, focused**
  measurement and is not the docs/gate metric.
- **Even if it ran, the gate would show this slice as unlinked**, because it is scoped
  `--need-type=comp_req` and no socom `comp_req` exists to receive the
  `PartiallyVerifies`/`FullyVerifies` links (§5).
- **The gate is nonblocking and is not acceptance.** CI sets `continue-on-error: true` and
  thresholds default to `0`; the task rule applies: *the nonblocking CI traceability gate
  is not acceptance*, and missing links remain missing. A nonzero gate exit is a
  finding, not a pass.
- **Native tests were built, not run.** The retained `native_tests` command is
  `bazel test //... --build_tests_only`; the measurement records
  `full_native_tests: not_executed`. The focused unit capture (91/0) is local and scoped,
  and the `runtime_tests.cpp` suite (33 macros) was not executed in it.

---

## 9. Obligations status (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Linking C++ tests to requirements via record properties | `verification_process.rst` (`gd_req__verification_link_tests_cpp`) | **PARTIAL** — `DerivationTechnique` + `Description` recorded in both candidate test files (host-observed on the 91-case run); `TestType` and `Partially/FullyVerifies` unset because no verified native link exists |
| Test-metadata consistency checks | `verification_process.rst` (`gd_req__verification_checks` `:191-196`; `_extended` `:211-212`) | **NOT SATISFIED** — `TestType` is not set (`:191`); no comp_req/interface link exists to make the linked types valid |
| Requirement/interface types available for linking | `docs/requirements/index.rst:109-120`; `docs/**` needs | **ABSENT** — all existing needs are `Functional`; no `:reqtype: Interface`, no socom `comp_req`; component/feature indexes are placeholders |
| Traceability matrix / consistency checks | `verification_guideline.rst:36`, `:81`; `verification_process.rst` | **NOT MEASURED** — docs/gate did not succeed; no `metrics.json`/`needs.json` |
| Docs metrics / quality-pack gate | `README.md:46-72`; `.github/workflows/quality_pack.yml` | **NOT MEASURED** — `native_docs`/`native_traceability` exit `2`/`1`; gate is `continue-on-error` and not acceptance |
| Source/design consistency | `verification_guideline.rst`; `score/socom/docs/design/*` | **INCOMPLETE** — key/version semantics documented only in code comments; no design element covers them |
| Boundary / equivalence derivation | `verification_process.rst`; `verification_plan.rst:245-268` | **SOURCE-ONLY / PARTIALLY EXECUTED (focused)** — cases tagged and green in focused captures; no full native execution |
| Fuzzy testing technique | `verification_plan.rst:265-270` | **NOT EXECUTED / NOT CLAIMED** — no harness and no measurement |
| Unit/component testing executed, results recorded | `verification_plan.rst` criteria; `verification_guideline.rst` | **PARTIAL / FOCUSED ONLY** — retained focus capture is 91 tests / 0 failures; `native_tests` built with `--build_tests_only`; full native `socom_test` (incl. 33 runtime macros) not executed |
| Independence of verification / review by a different committer | `gd_req__verification_independence` | **NOT DONE** — `human_reviews: unanswered` |
| Implementation inspection checklist IMPL_01…IMPL_03 | `inspection_checklist.rst` (`:status: draft`) | **NOT FILLED** |
| Safety/QM applicability and approved tailoring | `authority.json`; `process_checks/result.json` blockers | **UNKNOWN** — `safety_class: unknown`; blocker "Safety/QM applicability and approved tailoring unknown" |
| Semantic requirement coverage | `process_checks/result.json` | **NOT PROVEN** — blocker "Lexical metadata inventory cannot prove semantic requirement coverage" |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** for this slice |
| Native acceptance | `source-index.json` | **`not_inferred`** for every entry |

**Explicit non-satisfaction statement.** Missing or unstated tools, the unknown safety
class and un-inferred applicability, the incomplete extraction (focused translation unit
only), the absent docs/needs metrics, the build-only native test leg, obligation-collection
artifacts that are retained-but-failed, and the unanswered human reviews mean **none of the
checked obligations may be treated as satisfied**. In particular, `TestType` being unset
and the `PartiallyVerifies`/`FullyVerifies` links being absent are **recorded gaps**, not
passes; and the nonblocking CI traceability gate is **not** engineering acceptance.

---

## 10. Files changed and notice preservation

This iteration wrote **only this report** (`.llm_tmp/overnight/reports/traceability_review.md`).

| Candidate path | State | This iteration |
|----------------|-------|----------------|
| `score/socom/impl/service_identifier.hpp` | brace-balanced; line 39 blank; documents minor exclusion | **unchanged** (verified, §2) |
| `score/socom/impl/service_identifier.cpp` | `operator<` identity `(instance, id, major)`, minor excluded | **unchanged** |
| `score/socom/BUILD` | `testonly` key exposure present (`impl_service_identifier`) | **unchanged** |
| `score/socom/test/unit/BUILD` | `socom_test` globs `*.cpp`, deps wired | **unchanged** |
| `score/socom/test/unit/runtime_tests.cpp` | metadata helper + 25 per-case descriptions; minor-only regressions | **unchanged** |
| `score/socom/test/unit/service_identifier_tests.cpp` | 91-case matrix; fixture-wide metadata | **unchanged** |
| `.llm_tmp/overnight/reports/traceability_review.md` | **new — this report** | written |

- No source, build, test, config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was created,
  edited, or deleted; every existing Apache-2.0 / SPDX header is untouched.
- Every prior report under `.llm_tmp/overnight/prior-reports/` and
  `.llm_tmp/overnight/reports/`, every host artifact under
  `.llm_tmp/overnight/validation/`, and every obligation result under
  `.llm_tmp/overnight/obligations/` was preserved; they were read only.
- This report itself carries the Apache-2.0 header.
- The duplicate-server registration key remains an `impl/`-only type exposed to
  `//score/socom/test/unit` only through the `testonly`
  `//score/socom:impl_service_identifier` library, so no public header or notice surface
  changed.

---

## 11. Pending human review checklist

- [ ] **Confirm §2:** the header is already brace-balanced (`:19`, `:29`, `:32`, `:38`;
      line 39 blank), so the recorded syntax failure is stale; no source edit was made. If
      the "cancelled draft" is a different revision that still carries the extra brace,
      locate it and authorize its correction.
- [ ] **Resolve the instruction conflict:** the task directs correcting the source, while
      the actual source contains no defect and the write boundary allows only this report;
      confirm that a no-op is the intended outcome here.
- [ ] **Supply a socom Component Requirement** (a `comp_req__socom__*` in
      `docs/requirements/component/`) covering the duplicate-server registration-key /
      version-identity behaviour, or record applicability as unresolved — so that
      `PartiallyVerifies`/`FullyVerifies` and `TestType` can be completed without
      invention (§5).
- [ ] **Decide whether an `Interface` requirement/identifier** for
      `Service_instance_identifier` is wanted; if `TestType=interface-test` is intended,
      an interface need must first exist (`_extended`, `:212`).
- [ ] **Decide the `TestType`** for the two suites (and the convention for filling it when
      no requirement link exists); confirm that leaving it unset is an accepted,
      documented gap rather than a closure (§4.3).
- [ ] **Decide whether the fixture-wide `Description`** in `service_identifier_tests.cpp`
      (one sentence for 91 cases) is acceptable, or whether per-case descriptions are
      required for the conversion/registry and the coverage-driven dynamic-insertion cases
      (§3.2, §6).
- [ ] **Refresh the stale in-source citation:** `service_identifier_tests.cpp:2046` says
      the host capture records "87 tests / 0 failures", but the current retained
      `validation/after.json` records 91 tests / 0 failures (§2.4).
- [ ] **Add the missing design content:** document the registration-key identity
      (`instance + service id + major`, minor excluded), the duplicate-server rejection
      path and the public-vs-internal version asymmetry in `score/socom/docs/design/`, or
      record that the behaviour is intentionally undocumented (§7).
- [ ] **Run and retain the docs/quality-pack metrics** (`bazel test //:unit_tests
      //:component_tests`; `bazel run //:docs`; `bazel run //:traceability_gate --
      --metrics-json _build/metrics.json --need-type=comp_req`) and record
      `metrics.json`/`needs.json`/gate output; the retained run exits `2`/`1` and produces
      no `_build/**` or `_quality_pack/**` artifact. Do not infer linkage from absence, and
      do not treat the nonblocking gate as acceptance (§8).
- [ ] **Confirm the baseline binding** (issue #84 ↔ commit `f8a196c3…`) and the candidate
      set, including the header hash drift (`96b33a1f…` in `candidate-files.json` vs
      `bdce3fcb…` in the host captures), and that the un-merged
      `service_identifier_tests.cpp` is intended as a new file (§1.2).
- [ ] **Run the full native suite by execution** (not `--build_tests_only`), including
      `runtime_tests.cpp` (33 macros) and the 91-case key suite, and record results; supply
      the missing tools/results.
- [ ] **Schedule independent human review** (the approver must differ from the author, per
      `gd_req__verification_independence`).
- [ ] **Keep the wider #84 restructure** (public `Service_interface_identifier` change,
      FindService wildcard handling, config minor-wildcard narrowing) out of this bounded
      slice until separately accepted, and do not present the identifier-only tests as
      platform validation.
