<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — conversion-test repair (`repair_conversion_tests`) — iteration record

**Document type:** review draft (actual-source inspection + concrete test-finding repair +
honest iteration/measurement record).

**Date:** 2026-10-03
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version handling
in socom*; this report repairs the **identifier-conversion test** that the latest host
feedback measured as failing.
**Run / branch:** `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ`
**Verified baseline commit:** `f8a196c3b16d5172d898394ab99b0ed81346d63d`
(`.llm_tmp/context/source-manifest.json:3`).
**Status:** **local, unprotected, scoped.** No engineering acceptance exists. Human reviews
are unanswered. Full native runtime tests remain pending. Nothing here is acceptance, review,
publication, or a full native run.

> **Tool / write boundary actually observed.** Only `read_file`, `grep`, `glob` and
> `write_file` were used, as the task directs. No `shell`, no delegation, no web access, no
> approval, no publishing, and no engineering acceptance was performed. A single `edit_file`
> attempt on `score/socom/test/unit/service_identifier_tests.cpp` was refused by the
> environment with `Overnight tool/path boundary` and changed nothing; the candidate test file
> was therefore re-emitted in full with `write_file`. This iteration wrote **exactly two
> files**: the candidate test file `score/socom/test/unit/service_identifier_tests.cpp` (one
> failing case corrected) and this report. No other candidate source path — not
> `score/socom/impl/service_identifier.hpp`, `score/socom/impl/service_identifier.cpp`, either
> `BUILD`, or `score/socom/test/unit/runtime_tests.cpp` — and no `NOTICE`, `LICENSE`,
> `REUSE.toml`, config, or prior-report file was created, edited, or deleted. All prior reports
> were read and preserved.

> **Non-satisfaction rule applied throughout.** A successful obligation-collection node means
> results were **retained**, not that checks **passed**. Missing tools, unknown applicability,
> incomplete extraction, a draft rule mapping, and unanswered human reviews are **not** treated
> as satisfied (§6). This iteration ran **no** build and **no** test, so the repaired case is
> **unmeasured**; the retained host capture measured the **prior (failing)** revision of the
> file, not the repaired one.

---

## 0. Summary

1. **The recorded header syntax failure is not present in the actual source; no header edit was
   made or is required.** `score/socom/impl/service_identifier.hpp` is **brace-balanced**: a
   `grep` for `[{}]` returns exactly four lines — `:19` (`namespace score::socom {`), `:29`
   (`struct Service_instance_identifier final {`), `:32` (`};`) and `:38`
   (`}  // namespace score::socom`) — i.e. two openers and two closers, net balance `0`. Line
   `:39` is blank and `:40` is `#endif`. The sibling `impl/service_identifier.cpp` is balanced
   the same way. The retained host capture in fact records the candidate **compiling**
   (`after-compile.stderr` empty; the 91-case binary ran), so the described *"extra closing
   brace at line 39"* matches the stale, pre-correction split-namespace form quoted by the
   earliest prior reports, not this checkout (§2). Applying the historical repair to the
   balanced file would be a no-op; deleting a brace would **create** the defect. The header was
   therefore left untouched, and the recorded `edit_file` refusal is noted rather than worked
   around by re-introducing a break.

2. **The one concrete, latest host finding is corrected at its root cause.**
   `.llm_tmp/overnight/validation/after-test.stdout:182-189` records the single failing case
   `ServiceInstanceIdentifierTest.ConvertedConfigMinorNarrowingBoundariesCollapseAndDistinguish`
   at `service_identifier_tests.cpp:2141`, expecting `3U` distinct **registration keys** when the
   eight configuration values in fact collapse to `1`. That expectation contradicted the very
   identity this slice defines: the registration key **deliberately excludes the minor version**
   (`score/socom/impl/service_identifier.cpp:28-29`; header comment
   `impl/service_identifier.hpp:26-28`), so every configuration sharing
   `(instance, service id, major)` is one key regardless of minor. The public
   `Service_interface_identifier` identity, by contrast, **does** include minor
   (`service_interface_identifier.hpp:130-162`), so it is the public identity — not the key —
   that leaves three distinct values. The case was corrected to assert both halves of its own
   name: `public_identities.size() == 3` (distinguish) and `keys.size() == 1` (collapse) (§3).

3. **No test was added, removed or renamed, and no other case was changed.** The file still
   carries **91 `TEST_F`** cases under `ServiceInstanceIdentifierTest`, verified by `grep`. The
   pre-existing 90 cases remain, and the corrected case keeps its name and its eight-case
   configuration-minor table; only its tracking containers and its two size assertions changed.
   The two dynamic-instance cases that already pass in the retained capture are unchanged (§3.3,
   §4). No contract or coverage was weakened: the correction pins *both* the public distinction
   and the key collapse that the original case intended.

4. **The repaired case is unmeasured.** No build or test ran in this iteration, so whether the
   file compiles and whether all 91 cases pass is **unknown** until an authorized run. The
   retained capture (`.llm_tmp/overnight/validation/`) measured the **prior** revision of the
   file (`after.json`: `tests: 91, failures: 1`); after the correction the file hash no longer
   matches that capture. The repair is a source-level consequence of the documented key
   semantics, not an observed pass.

5. **No obligation is satisfied.** The pinned obligation entries are
   `"native_acceptance": "not_inferred"`; `authority.json` records
   `engineering_acceptance: pending`, `human_reviews: unanswered`, `safety_class: unknown`.
   Missing tools, the un-inferred applicability, the incomplete extraction of host artifacts,
   the absence of `.llm_tmp/overnight/obligations/*/result.json`, the unmeasured repair and the
   unanswered human reviews mean **none of the checked obligations may be treated as
   satisfied** (§6).

---

## 1. Binding to the baseline, issue, prior reports, host feedback and obligations

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` | `.llm_tmp/context/issue-snapshot.json:2-4` |
| Title | *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:3` |
| State | `open`, **0 comments**, no milestone / assignee / labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` (unchanged) | `.llm_tmp/context/issue-snapshot.json:19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**: service-instance identifier = `service id + major + minor + instance id`,
service identifier = `service id + major`, FindService = `service id + major +
optional<minor> + optional<instance>`, and a proposal to exclude minor and make it a property
of the instance. There is **no comment and no acceptance record** in the snapshot, so none of it
is binding. Binding is **by baseline commit**, not by run HEAD.

### 1.2 Verified baseline and in-scope candidate files

| Candidate path | Baseline git blob | This iteration |
|----------------|-------------------|----------------|
| `score/socom/BUILD` | `3477ea0851fdcd82ec6ea9d71424013cbdf41962` | inspected, **unchanged** |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e22355242009fe20dada2a9a0d0c7a9c7` | inspected, **unchanged** (key identity `(instance, id, major)`, `:28-29`) |
| `score/socom/impl/service_identifier.hpp` | `c8bae7908da9f087c518934f7b9f8d86db9a20ec` | inspected, **unchanged** (already brace-balanced, §2) |
| `score/socom/test/unit/BUILD` | `3c03a7b14286051f97fa5022206564bd63645171` | inspected, **unchanged** |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab726db8bf994c960045d6fd7fdf84d7395` | inspected, **unchanged** |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(none — `null`)* | **changed — the one failing conversion case corrected (§3)** |

Source: `.llm_tmp/context/candidate-files.json:1-25`. The `null` baseline blob for
`service_identifier_tests.cpp` is the manifest's expectation of a **new** unit-test file; it
exists on disk only as part of the un-merged working tree (the "cancelled draft"), never in the
baseline. `glob **/service_identifier*` returns exactly three paths, so there is **no second,
differently-braced copy** of the header.

### 1.3 Prior reports read and preserved

- **`.llm_tmp/overnight/prior-reports/` — 38 files present**, all preserved; the relevant ones
  were read/cross-checked: `conversion_tests.md`, `key_fix.md`, `scope.md`, `invariants.md`,
  `callsites.md`, `reproducer.md`, `unit_matrix.md`, `ordering_tests.md`, `runtime_disabled.md`,
  `runtime_enabled.md`, `lifetime_tests.md`, `test_metadata.md`, plus the review hand-off set.
- **`.llm_tmp/overnight/reports/`** holds the earlier reports of this run (`scope.md`,
  `callsites.md`, `invariants.md`, `key_fix.md`, `reproducer.md`, `unit_matrix.md`,
  `ordering_tests.md`, `runtime_disabled.md`, `runtime_enabled.md`, `lifetime_tests.md`,
  `conversion_tests.md`); all were read and preserved. This document adds
  `repair_conversion_tests.md`. In particular the prior `reports/conversion_tests.md` — which
  argued there was "no actual source to correct" and left the failing case in place — was **not
  overwritten**, and its §6 "the added cases are unmeasured" caveat is exactly the gap the
  latest host feedback then measured.

Derived sequence: `scope.md` → `invariants.md` (I-1…I-16) → `callsites.md` → `reproducer.md`
(header brace correction) → `key_fix.md` / `unit_matrix.md` (drop `minor` from the ordering) →
`ordering_tests.md` / `conversion_tests.md` → `runtime_disabled.md`, `runtime_enabled.md`,
`lifetime_tests.md` → `test_metadata.md` → later host-side iterations → review artifacts.

### 1.4 Host feedback present in this checkout (the finding of record)

`.llm_tmp/overnight/validation/` is present and is the **latest** host feedback:

| Artifact | Reading |
|----------|---------|
| `measurement.json` | `check_ref: check_conversion_tests`, `status: findings`, `mode: ubsan`, `changed_paths: ["score/socom/test/unit/service_identifier_tests.cpp"]`; `origin: local_unprotected_measurement`; `initiator: Fabro host hook`; `engineering_acceptance: pending`; `full_native_tests: not_executed`; compiler `/usr/bin/x86_64-linux-gnu-g++-12`; `baseline_with_agent_tests` = 91 tests / 32 failures; `candidate` = 91 tests / **1 failure** |
| `after.json` | `tests: 91`, `failures: 1`, `disabled: 0`, `errors: 0` |
| `after-test.stdout` | `:182` `service_identifier_tests.cpp:2141: Failure`; `:184` `Expected equality of these values: 3U` vs `keys.size() Which is: 1`; `:200` the single failed case `ConvertedConfigMinorNarrowingBoundariesCollapseAndDistinguish`; `:197` `91 tests … 90 passed` |
| `after-compile.stderr` / `before-compile.stderr` | empty |
| `check-result` | `0` (retention marker; the collection succeeded, it does not mean the checks passed) |

So the candidate **compiled** and ran; the retained finding is a **single logical test
failure**, not a compiler/syntax failure. This is a **local, unprotected, scoped** capture and
**predates** the repair in §3.

### 1.5 Pinned obligation sources and authority (read this iteration)

All nine entries of `.llm_tmp/context/obligations/source-index.json`, together with
`.llm_tmp/context/obligations/authority.json`, were read from
`.llm_tmp/context/obligations/`. Every entry is pinned `"native_acceptance": "not_inferred"` —
pinned, but its applicability to this slice is **not inferred**.

| id | pinned file (id → path) | status note |
|----|-------------------------|-------------|
| `coding_guidelines` | `docs/contribute/development/cpp/coding_guidelines.rst` | MISRA C++:2023 with C++17; `:status: valid` |
| `code_analysis` | `docs/contribute/development/cpp/code_analysis.rst` | clang-tidy + gcc/clang warnings + Coverity; sanitizers; `:status: valid` |
| `misra_mapping` | `docs/contribute/development/cpp/misra_2023_rule_mapping.rst` | **`:status: draft`**; rule table not a valid obligation |
| `verification_plan` | `docs/platform_management_plan/software_verification.rst` | `:status: valid`; criterion 9 = freedom from compiler warnings & errors (100 %) |
| `development_plan` | `docs/platform_management_plan/software_development.rst` | `:status: valid`; C++17, GCC host, QCC target, Bazel |
| `tool_management` | `docs/platform_management_plan/tool_management.rst` | `:status: valid`; tools identified/evaluated/qualified by a human |
| `verification_process` | `process/process_areas/verification/guidance/verification_process_reqs.rst` | `:status: valid`; `gd_req__verification_link_tests_cpp`, `_independence`, `_checks_extended`, `_external_aou`, `_sca_classification` |
| `verification_guideline` | `process/process_areas/verification/guidance/verification_guideline.rst` | `:status: valid`; traceability, independence, documented results |
| `inspection_checklist` | `score/component_example/docs/detailed_design/chklst_impl_inspection.rst` | **`:status: draft`**; blank `IMPL_01_01`…`IMPL_03_02` template |

**Authority record** (`.llm_tmp/context/obligations/authority.json:1-7`):
`engineering_acceptance: pending`; `human_reviews: unanswered`; `safety_class: unknown`;
`codeql_scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload"`; instruction
*"Restart the failed queue for one complete pass through all obligations"*.

**Obligation-collection results are absent here.** `glob .llm_tmp/overnight/obligations/**`
returns nothing; no `*/result.json` exists. Per the task rule, a collection node that retained
results would show only *retention*, not passing; here nothing is retained, so nothing may be
treated as satisfied on that basis (§6).

**Safety-class note (recorded, not resolved).** The pinned platform documents carry
`:safety: ASIL_B`, while `authority.json` records `safety_class: unknown` and no authorized
selection exists. The document attribute is **not** a selection of the slice's safety class and
must not be inferred as one.

---

## 2. The recorded header syntax failure: inspection of the actual source

`score/socom/impl/service_identifier.hpp` is **brace-balanced** (40 lines):

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 30-31 | `Service_interface_identifier interface;` / `Service_instance instance;` | members |
| 32 | `};` | closes the struct |
| 35 | `bool operator<(...);` | the single out-of-line declaration (no brace) |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`) and two closers (`:32`, `:38`): net brace balance is `0`. There is
**no third, unmatched closing brace**, and line `:39` contains no text at all. The sibling
`impl/service_identifier.cpp` uses the same nested form (braces at `:18`, `:20`, `:30`, `:32`)
and is balanced. The task's *"extra closing brace … at line 39"* therefore matches a **stale,
pre-correction description** (the earliest prior reports quote the split form
`}  // namespace socom` + `}  // namespace score`), and the retained host capture corroborates
this: `after-compile.stderr` is empty and the 91-case binary ran, which an unmatched brace in a
header compiled into `service_identifier.cpp` / `service_identifier_tests.cpp` would have
prevented.

`glob **/service_identifier*` returns exactly three paths, so there is **no second,
differently-braced copy** of the header in this checkout.

**Minimal historical repair (reference only; NOT applied, because not needed):**

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

Applying this to the already-balanced file would be a no-op; deleting a brace would *create*
the reported defect. **No source edit was made to the header.** The instruction's precondition
("inspect and correct the actual source before expanding tests") is satisfied without a source
write under the rule that the smallest correct change to already-correct source is no change;
the actual, *measured* defect is in the test (§3), not the header.

---

## 3. The corrected test case

### 3.1 The recorded failure

From `.llm_tmp/overnight/validation/after-test.stdout:182-189`:

```
score/socom/test/unit/service_identifier_tests.cpp:2141: Failure
Expected equality of these values:
  3U
    Which is: 3
  keys.size()
    Which is: 1
[  FAILED  ] ServiceInstanceIdentifierTest.ConvertedConfigMinorNarrowingBoundariesCollapseAndDistinguish
```

The case (prior form, at `:2103`-`:2142`) built eight `Service_instance_identifier` keys from
eight configuration minors (`0x00000000`, `0x00000001`, `0x0000FFFF`, `0x00010000`,
`0x00010001`, `0x7FFFFFFF`, `0x80000000`, `0xFFFFFFFF`), inserted them into one
`std::set<Service_instance_identifier>`, and asserted `EXPECT_EQ(3U, keys.size())` with the
comment *"values sharing the low 16 bits convert to the same Version and the same key; the
eight config values leave exactly three distinct key identities."*

### 3.2 Root cause

The registration key **deliberately excludes the minor version**. `operator<` is
(`score/socom/impl/service_identifier.cpp:28-29`):

```cpp
return std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major) <
       std::tie(rhs.instance, rhs.interface.id, rhs.interface.version.major);
```

`std::set` equivalence is `!(a<b) && !(b<a)`, so the key identity is exactly
`(instance, service id, major)` — **minor is not compared** (the header states this at
`impl/service_identifier.hpp:26-28`, and the file-wide design is asserted by the 90 other
cases, e.g. `KeysDifferingOnlyInMinorVersionAreDuplicates`, `AllMinorVersionsCollapseToSingleKey`,
`ConvertedKeyMinorBoundariesCollapseToSingleIdentity`). All eight configuration values share
`instance_id_a`, `service_id_a` and `major = 1`, so every one of them maps to the **same** key:
`keys.size() == 1`, not 3. The denominator of "distinct" belongs to the **public**
`Service_interface_identifier` identity, which **does** include minor
(`service_interface_identifier.hpp:130-162`: `operator==`/`operator<`/`hash` all use
`(major, minor)`), and whose distinct narrowed values are exactly `{0x0000, 0x0001, 0xFFFF}` —
three.

So the case's *name* ("…CollapseAndDistinguish") and the *design* (public identity
distinguishes, key collapses — the same pairing documented in
`.llm_tmp/overnight/reports/conversion_tests.md` §4) were right, but its *assertion* used the
collapsing key for the distinguishing half. This is the concrete, root-cause defect.

### 3.3 The repair (minimal, within scope)

In `score/socom/test/unit/service_identifier_tests.cpp` the case now tracks **both** identities:

- a new `std::set<Service_interface_identifier> public_identities;` receives the public
  `interface` built from each narrowed minor, and the case asserts
  `EXPECT_EQ(3U, public_identities.size());`
- the existing `std::set<Service_instance_identifier> keys;` continues to receive the converted
  registration key, and the case now asserts `EXPECT_EQ(1U, keys.size());`
- the explanatory comment now states the two halves explicitly (values sharing the low 16 bits
  convert to the same public Version; the registration key drops minor, so all eight collapse to
  one), and the now-corrected trailing comment no longer claims "three registration-key
  identities".
- the per-case assertions (`EXPECT_EQ(test_case.narrowed, narrowed);` and
  `EXPECT_EQ((Identity{instance_id_a, service_id_a, std::uint16_t{1U}}), identity_of(key));`)
  are unchanged, and the eight-entry table is unchanged.

Nothing else in the file changed. This is the smallest correction that makes the case assert
its own documented intent; it does not weaken coverage — it **adds** the public-identity
distinction that the failing revision had omitted, while keeping the key-collapse assertion that
the solution space actually exercises.

### 3.4 What was deliberately not done

- **No production/header edit.** The measured defect is in the test, not the header or the
  `operator<`; the header is balanced (§2) and the key exclusion is the intended slice
  behaviour. Editing any of them to make the old assertion pass would be a regression.
- **No new tests.** The task's *"before expanding tests"* precondition is met by inspecting the
  header (§2) and correcting the concrete finding (§3.3); no coverage was expanded.
- **No assertion weakened to a tautology.** The repair pins three distinct public identities
  **and** one collapsed key, rather than deleting the distinguishing check.

---

## 4. Files changed / state of the six candidate paths

| Candidate path | State | This iteration |
|----------------|-------|----------------|
| `score/socom/impl/service_identifier.hpp` | brace-balanced, nested namespace, documents minor exclusion | **unchanged** (verified, §2) |
| `score/socom/impl/service_identifier.cpp` | `operator<` identity `(instance, id, major)`, minor excluded | **unchanged** |
| `score/socom/BUILD` | `testonly impl_service_identifier` exposure present | **unchanged** |
| `score/socom/test/unit/BUILD` | `socom_test` globs `*.cpp`, deps wired | **unchanged** |
| `score/socom/test/unit/runtime_tests.cpp` | minor-only duplicate regression present | **unchanged** |
| `score/socom/test/unit/service_identifier_tests.cpp` | 91-case key matrix; `ConvertedConfigMinorNarrowingBoundariesCollapseAndDistinguish` corrected (§3.3) | **changed** |
| `.llm_tmp/overnight/reports/repair_conversion_tests.md` | **new — this report** | written |

No file outside the six candidate paths and this report was written; no `NOTICE`, `LICENSE`, or
`REUSE.toml` file was created, edited, or deleted; all prior reports were preserved.

**Test inventory after the change (read, not run):** `service_identifier_tests.cpp` = **91
`TEST_F`** under `ServiceInstanceIdentifierTest`, verified by `grep`; the corrected case is at
`:2103` and the file closes with `}  // namespace score::socom` at `:2211`.
`runtime_tests.cpp` is untouched.

---

## 5. Measurement and validation status

- **Tools:** `read_file`, `grep`, `glob`, `write_file` only. One `edit_file` attempt was refused
  by the environment (`Overnight tool/path boundary`) and changed nothing; no `shell`,
  delegation, web, approval, publishing, or engineering acceptance.
- **Executed measurements:** **none** this iteration. No build, no `bazel test`, no runtime.
  The §2 brace census, the §3.2 identity reading, and the §3.3 expected behaviour are static
  source readings and strict-weak-ordering / `std::set`-equivalence consequences, not observed
  results.
- **The repaired case is unmeasured.** The retained host capture
  (`.llm_tmp/overnight/validation/`) measured the **prior** revision (`after.json`: 91 tests /
  1 failure; `before.json`/`baseline_with_agent_tests`: 91 / 32), and the changed file's hash no
  longer matches `measurement.json`'s recorded hash for `service_identifier_tests.cpp`.
  Whether the repaired file compiles and all 91 cases pass is **unknown** until an authorized
  run.
- **Regression target (source-derived, not executed):**
  `RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError`
  (`runtime_tests.cpp:402-431`) and the key-level minor-collapse cases
  (`service_identifier_tests.cpp:174`, `:182`, `:192`, `:203`, …) assert that a second
  registration differing only in `minor` is rejected as `duplicate_service`. On a key that
  includes `minor` they fail (baseline: 32 failures); on the working-tree key they are expected
  to pass. These are host readings of the earlier revisions, not an execution of this
  iteration's file.
- **Scope:** local, unprotected, scoped. This is a bounded coverage/verification record, not an
  accepted engineering decision. Full native runtime tests and human review remain pending.
- **Reproduction path for a later, permitted iteration (not executed here):**

  ```bash
  bazel test //score/socom/test/unit:socom_test
  # focused key-level, including the corrected conversion case:
  bazel test //score/socom/test/unit:socom_test --test_filter='ServiceInstanceIdentifierTest.*'
  bazel test //score/socom/test/unit:socom_test \
      --test_filter='ServiceInstanceIdentifierTest.ConvertedConfigMinorNarrowingBoundariesCollapseAndDistinguish'
  # integration / cross / docs / traceability (per the pinned plans)
  bazel test --config=qemu-integration //tests/integration_test/...
  ```

  Expected on the working-tree key: the eight configuration minors leave three distinct public
  identities and exactly one registration-key identity. These expectations are source-derived,
  not measured.

---

## 6. Obligations status (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Freedom from compiler warnings & errors (100 %) | `verification_plan.rst` (criterion 9) | **NOT MEASURED** — header is brace-balanced by inspection and the retained capture shows the prior revision compiling, but nothing was compiled this iteration; the repaired case is unbuilt |
| Static code analysis (clang-tidy / CodeQL), findings classified | `code_analysis.rst`; `verification_process.rst` (`gd_req__verification_sca_classification`) | **NOT PERFORMED** — no tool, no build; a prior clang-tidy attempt was blocked on configuration |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` (`:status: draft`) | **UNKNOWN — NOT CLAIMED** — mapping is draft; not applied |
| Structural statement / branch coverage goals | `verification_plan.rst` (criteria 1-2) | **NOT MEASURED** — no execution |
| Unit/component testing executed, results recorded | `verification_plan.rst` (criteria 6-7); `verification_guideline.rst` | **PARTIAL / NOT COVERING THIS CHANGE** — retained focused host run is 91 cases with 1 failure on the **prior** file; the repaired file and the runtime suite are unmeasured |
| Interface / requirements-based / resource / fault-injection test types | `verification_process.rst`; `verification_plan.rst` | **NOT PERFORMED / applicability not inferred** — no harness; identifier-only tests must not be labelled platform validation |
| Boundary / equivalence derivation | `verification_process.rst` | **SOURCE-ONLY** — cases exist; the repaired one was not executed |
| Fuzzy testing technique | `verification_plan.rst` | **NOT EXECUTED / NOT CLAIMED** — no harness, no measurement |
| Linking tests to requirements (record properties) | `verification_process.rst` (`gd_req__verification_link_tests_cpp`) | **PARTIAL / NOT DONE** — `DerivationTechnique`/`Description` recorded in `SetUp()`; `TestType` and `Verifies` left unset (no verified native identifier; inventing one is prohibited) |
| External-component AoUs verified | `verification_process.rst` (`gd_req__verification_external_aou`) | **NOT SATISFIED** — no integration/static verdict; no AoU register |
| Independence of verification / review by a different committer | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Implementation inspection checklist IMPL_01…IMPL_03 | `inspection_checklist.rst` (`:status: draft`) | **NOT FILLED** — draft template, no inspection |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** for this slice; no tool run here |
| Obligation collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **ABSENT in this checkout** — directory not present |
| Native acceptance | `source-index.json` | **`not_inferred` for every entry** |

**Explicit non-satisfaction statement.** Missing tools, the unknown safety class and
un-inferred applicability, the incomplete extraction of host artifacts, the absent
obligation-collection results, the unmeasured repair, and the unanswered human reviews mean
**none of the checked obligations may be treated as satisfied**. A collection node that
retained results would only show *retention*, not passing; here there are no retained
obligation-collection results at all. In particular, the `check-result` = `0` marker and the
retained 91-case capture with 1 failure are **not** evidence that the repaired case or the
suite passes.

---

## 7. Notice preservation

- Only `.llm_tmp/overnight/reports/repair_conversion_tests.md` (this report) and the candidate
  test file `score/socom/test/unit/service_identifier_tests.cpp` were written. No other
  candidate source path, `NOTICE`, `LICENSE`, `REUSE.toml`, config, BUILD, or prior-report file
  was created, edited, or deleted.
- `score/socom/test/unit/service_identifier_tests.cpp` retains its Apache-2.0 / SPDX header
  (lines 1-12). Every other existing Apache-2.0 / notice header is untouched; this report
  carries the Apache-2.0 header. No licensed MISRA rule text is reproduced; only native
  rule/query identifiers, file locations, and prior-report readings are cited.
- The prior `.llm_tmp/overnight/reports/conversion_tests.md` and
  `.llm_tmp/overnight/prior-reports/conversion_tests.md` were **not** overwritten.
- The duplicate key remains an `impl/`-only type; the `testonly`
  `//score/socom:impl_service_identifier` exposure serves `//score/socom/test/unit` only, so no
  public header or notice surface changed.

---

## 8. Pending human review checklist

- [ ] **Confirm §2:** the header is already brace-balanced (four braces at `:19`, `:29`, `:32`,
      `:38`; line `:39` blank; single nested close `}  // namespace score::socom`), and the
      retained `after-compile.stderr` is empty, so the recorded syntax failure is stale and no
      header edit is required. If the "cancelled draft" is a different revision that still
      carries the extra brace, locate it and authorize its correction; no such file exists in
      this checkout.
- [ ] **Review §3.2-3.3:** confirm that the failing case's root cause is its use of the
      minor-excluding registration key for the "distinguish" half, and that the repair
      (three distinct public identities **and** one collapsed registration key) is the intended
      assertion. Confirm no coverage was weakened.
- [ ] **Compile and run** `bazel test //score/socom/test/unit:socom_test` (including the
      corrected case) since this iteration had no compiler; record the result. Do **not** infer
      passing from the retained 91-case capture that still shows the one failure.
- [ ] **Confirm the file still has 91 cases** and that the corrected case is the only
      behavioural change; confirm the 90 pre-existing cases are preserved.
- [ ] **Supply the missing obligation results** (`.llm_tmp/overnight/obligations/*/result.json`)
      and resolve `engineering_acceptance: pending` / `human_reviews: unanswered`.
- [ ] **Keep the #84 public `Service_interface_identifier` restructure, FindService wildcard
      handling, and the config minor-wildcard narrowing out of this bounded slice** until
      separately accepted, and do not present the identifier-only tests as platform validation
      or claim an unmeasured fuzzy technique.
- [ ] **Select a safety class** via the authorized role; do not infer the slice's class from the
      `:safety: ASIL_B` attribute on the pinned platform documents (§1.5).
- [ ] **Schedule independent human review** (the approver must differ from the author, per
      `gd_req__verification_independence`).

---

*End of conversion-test repair iteration record. Local, unprotected, scoped. No engineering
acceptance; human reviews unanswered; full native runtime tests pending. Every statement is a
local reading of the working tree, a retained local host reading, or an explicitly-labelled
logical consequence — none is acceptance, review approval, publication, or a full native run.*
