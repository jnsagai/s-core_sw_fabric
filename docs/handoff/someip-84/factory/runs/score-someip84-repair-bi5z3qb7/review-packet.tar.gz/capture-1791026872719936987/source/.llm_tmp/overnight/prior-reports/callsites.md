<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — duplicate-server registration-key call-site map (review draft)

**Document type:** review draft (actual-source inspection + call-site map:
construction, conversion, comparison, service database + obligations status)
**Date:** 2026-10-02
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version handling in
socom*
**Run:** `fabro/run/01M3YRJEGXNY6CB81T7TKW774B` (branch
`fabro/run/01M3YRJEGXNY6CB81T7TKW774B`, HEAD `8934e94` —
`fabro(01M3YRJEGXNY6CB81T7TKW774B): start (success)`)
**Status:** local, unprotected, scoped. **No engineering acceptance exists. Human reviews are
unanswered. Full native runtime tests remain pending.** Every statement below is either a direct
static reading of this checkout at the baseline-bound candidate paths or an explicitly-labelled
logical consequence. Nothing here is compiled, executed, reviewed, published, accepted, or a full
native run.

> **Tool / write boundary observed.** This iteration used only `read_file`, `grep`, `glob`, and
> `write_file`. No `shell`, no delegation, no web access, no approval, no publishing, and no
> engineering acceptance was performed. `edit_file` is **not** in the permitted tool set. The task
> says to *"Inspect and correct the actual source before expanding tests"*, while its explicit and
> more specific final sentence says *"This is a review draft: only that report may be written."*
> Following that final write boundary, **only this report was written**
> (`/workspace/.llm_tmp/overnight/reports/callsites.md`). No source, build, test, config, `NOTICE`,
> `LICENSE`, `REUSE.toml`, or prior-report file was created, edited, or deleted. All prior reports
> are preserved.
>
> **The described syntax defect is not present in the actual source.** The task records *"a measured
> GCC syntax failure: an extra closing brace in `score/socom/impl/service_identifier.hpp` at line
> 39."* Direct `read_file` + `grep` on the current working tree (§2) show the header is **already
> brace-balanced**: the only brace-bearing lines are `:19` (`namespace score::socom {`) and `:29`
> (`struct Service_instance_identifier final {`) as openers, and `:32` (`};`) and `:38`
> (`}  // namespace score::socom`) as closers. Line `:39` is **blank**, and `:40` is `#endif`. Two
> openers, two closers, net balance `0`; there is no third, unmatched closing brace. Applying the
> documented repair again would be a no-op, and re-introducing a break to "fix" it would be a
> regression. **No source write was made and none is needed.** The minimal repair is retained in
> §2.3 for reference only. The write boundary forbids source edits and no `edit_file` was available
> in any case.
>
> **Directory note (re-verified this iteration by `glob`).** `.llm_tmp/overnight/prior-reports/` holds
> **12 files** — all present and preserved (earlier reports claimed 13 and cited a sibling
> `repair_unit_matrix.md`, which is **not** present in this checkout). `.llm_tmp/overnight/reports/`
> held only `scope.md` before this write; this document adds `callsites.md`. `glob` over
> `.llm_tmp/overnight/validation/**` and over `.llm_tmp/overnight/obligations/**/result.json` both
> returned **nothing**: those host artifacts are **absent from this checkout**, and absence is not
> evidence that a check passed.

---

## 0. Summary

1. **Recorded syntax failure re-inspected; not present.** `score/socom/impl/service_identifier.hpp`
   is brace-balanced (§2). No correction was applied — none is required, the write boundary forbids
   it, and no `edit_file` tool was permitted. The minimal repair is retained for reference only.
2. **Call-site map produced** for the duplicate-server registration key **construction** (§4),
   **conversion** (§5), **comparison / ordering / hashing** (§6), and **service database** (§7),
   each with repo-relative paths and current working-tree line numbers read this iteration.
3. **The key ignores `minor`; two surrounding layers do not.** The registration key orders by
   `(instance, service id, major)` (`score/socom/impl/service_identifier.cpp:28-29`) and the
   `Service_database` index is minor-ignoring (`score/socom/impl/runtime_impl.hpp:116-134`), while
   the public `Service_interface_identifier` ordering/hash and the IPC `Service` key keep `minor`
   (§6). This is the substance of issue #84's key question and is recorded as a **static
   observation, not a defect claim**.
4. **83 key cases and 31 runtime `TEST_F` cases are present but unexecuted here.** Counts were
   read this iteration by `grep` (§8); prior reports recorded smaller, superseded counts (73 / 24).
5. **No obligation is satisfied.** No tool ran beyond reading; no build, no test. Pinned entries are
   `native_acceptance: not_inferred`; `authority.json` records `engineering_acceptance: pending`,
   `human_reviews: unanswered`, `safety_class: unknown` (§9). Absent `validation/` and
   `obligations/` artifacts are not evidence of passing.

---

## 1. Binding to the baseline, prior reports, host feedback, and obligations

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` | `.llm_tmp/context/issue-snapshot.json:2-4` |
| Title | *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:3` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` (unchanged) | `.llm_tmp/context/issue-snapshot.json:19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**. It distinguishes three use cases — *service-instance identifier* =
`service id + major + minor + instance id`; *service identifier* = `service id + major`;
*FindService* = `service id + major + optional<minor> + optional<instance>` — and proposes to
"exclude the minor version and make it a property of the service instance to be able to better
compare and index compatible service instances." It notes the FindService `major = FF` AUTOSAR
case as theoretically possible but not useful. There is **no comment and no acceptance record** in
the snapshot, so none of the proposal is binding.

### 1.2 Verified baseline

| Item | Value | Source |
|------|-------|--------|
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |
| Current branch | `fabro/run/01M3YRJEGXNY6CB81T7TKW774B` | environment |
| Current HEAD | `8934e94` — `fabro(01M3YRJEGXNY6CB81T7TKW774B): start (success)` | environment |

Binding is **by baseline commit `f8a196c3…`**, not by run HEAD. Earlier reports reference other run
IDs on the same baseline commit (`01M3YGTGYFEN406VDEVVTJTRWV`, `01M3XZAQ65TTE35XSGXC4JAMAH`,
`01M3XT7NQ04S4MTFRMTT2401XK`, `01M3WX09X84XFM5X08QY2944DF`, and before them
`01M3WSTF1DAJA248NQ5QQGQG52` / `a282596` and `01M3WWRQWT262FTYS52X80YPTP` / `e12e7cb`), so all of
them describe the same baseline and remain admissible prior evidence for this run's slice.

### 1.3 In-scope candidate files (`.llm_tmp/context/candidate-files.json:1-25`)

| File (repo-relative) | Baseline git blob | Baseline present | Current working tree (read this iteration) |
|----------------------|-------------------|------------------|--------------------------------------------|
| `score/socom/BUILD` | `3477ea0851fdcd82ec6ea9d71424013cbdf41962` | yes | `socom` lib (`:24-41`); `testonly` `impl_service_identifier` (`:46-54`) |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e22355242009fe20dada2a9a0d0c7a9c7` | yes | key identity `(instance, id, major)`; `minor` excluded (`:28-29`) |
| `score/socom/impl/service_identifier.hpp` | `c8bae7908da9f087c518934f7b9f8d86db9a20ec` | yes | **brace-balanced**, 40 lines, `:39` blank (§2) |
| `score/socom/test/unit/BUILD` | `3c03a7b14286051f97fa5022206564bd63645171` | yes | `socom_test` globs `*.cpp`; deps wired (`:16-29`) |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab726db8bf994c960045d6fd7fdf84d7395` | yes | **31 `TEST_F` + 1 `TEST` + 1 `TEST_P`**; minor-only regression at `:402-431` |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(none — `null`)* | **no** (manifest expects a **new** file) | **83 `TEST_F`** matrix present; metadata `SetUp()` at `:42-65` |

The `null` baseline blob for `service_identifier_tests.cpp` is the manifest's expectation of a
**new** unit-test file; it exists on disk only as part of the un-merged working tree (the "cancelled
draft"), never in the baseline. The five present baseline blobs also appear in the `files` array of
`.llm_tmp/context/source-manifest.json`, binding the candidate set to the baseline commit.

### 1.4 Pinned obligation sources read this iteration

All nine entries of `.llm_tmp/context/obligations/source-index.json` were read from
`.llm_tmp/context/obligations/`, together with `authority.json`:

| id | file | status note (re-read this iteration) |
|----|------|--------------------------------------|
| `coding_guidelines` | `coding_guidelines.rst` | `:status: valid` (`:20`); MISRA C++:2023 with C++17 |
| `code_analysis` | `code_analysis.rst` | `:status: valid`; clang-tidy + gcc/clang warnings + Coverity; sanitizers; gcov/gcovr |
| `misra_mapping` | `misra_mapping.rst` | **`:status: draft`** (`:20`); the rule table is commented out |
| `verification_plan` | `verification_plan.rst` | `:status: valid` (`:17`), `:safety: ASIL_B` (`:19`); TestType/DerivationTechnique tables; quality criteria 1–9 (criterion 9 = freedom from compiler warnings & errors, 100 %) |
| `development_plan` | `development_plan.rst` | `:status: valid`; C++17, GCC host compiler, QCC target, Bazel, clang-tidy, CodeQL |
| `tool_management` | `tool_management.rst` | `:status: valid`; tools identified / evaluated / qualified |
| `verification_process` | `verification_process.rst` | `:status: valid`; `gd_req__verification_link_tests_cpp` (`:57`, `:status: valid` `:58`), `gd_req__verification_independence` (`:142`), `gd_req__verification_checks_extended` (`:199`), `gd_req__verification_sca_classification` (`:229`) |
| `verification_guideline` | `verification_guideline.rst` | `:status: valid`; traceability, independence, reporting |
| `inspection_checklist` | `inspection_checklist.rst` | **`:status: draft`** (`:17`); blank IMPL_01_01…IMPL_03_02 template |

Every entry in `source-index.json` is pinned with `"native_acceptance": "not_inferred"` — pinned,
but its applicability to this slice is **not inferred**. `authority.json` records
`"engineering_acceptance": "pending"`, `"human_reviews": "unanswered"`, `"safety_class": "unknown"`,
`"codeql_scope": "Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload"`, and the
instruction `"Restart the failed queue for one complete pass through all obligations"`.

### 1.5 Prior reports, host feedback, obligation-collection results

- **Prior reports read and preserved.** `.llm_tmp/overnight/prior-reports/` — **12 files present**,
  all read and preserved: `scope.md`, `invariants.md`, `callsites.md`, `reproducer.md`, `key_fix.md`,
  `unit_matrix.md`, `ordering_tests.md`, `conversion_tests.md`, `runtime_disabled.md`,
  `runtime_enabled.md`, `lifetime_tests.md`, `test_metadata.md`. Earlier reports also cite
  `repair_unit_matrix.md`, `coverage_tests_repair.md`, `tool_findings_repair.md`, and a host
  addendum `obligation-addendum.md`; **none of those four is present** in this checkout (`glob`
  returns no entries), so their content is available only as quoted by the other reports. Also read
  and preserved: `.llm_tmp/overnight/reports/scope.md`.
- **Host validation feedback under `.llm_tmp/overnight/validation/`: absent.** `glob` returns no
  entries. Prior reports retain summaries only: `check-result: 0`; `measurement.json`
  `origin: local_unprotected_measurement`, `initiator: Fabro host hook`, `mode: ubsan`,
  `engineering_acceptance: pending`, `full_native_tests: not_executed`, compiler
  `/usr/bin/x86_64-linux-gnu-g++-12`, `check_ref: check_conversion_tests`; candidate = 83 tests /
  0 failures / compile exit 0 (an earlier retained capture recorded 46/0); `baseline_with_agent_tests`
  = 83 / 28 / exit 0. Scope caveat: the measurement compiled **only the focused identifier
  translation unit** (`service_identifier.cpp` + `string_registry.cpp` +
  `service_identifier_tests.cpp`) with `g++-12 -std=c++17 -Wall -Wextra -Werror` (plus
  `-fsanitize=undefined -fno-sanitize-recover=all`); it did **not** compile `runtime_tests.cpp` or
  the full `socom_test` / `//score/...` targets.
- **Obligation-collection results under `.llm_tmp/overnight/obligations/`: absent.** No
  `*/result.json` exists here (`glob` returns nothing). Prior reports retain collector summaries
  (GCC focused compile/tests exit 0; clang compile blocked on a googletest/libstdc++
  `-Wdeprecated-declarations` dependency error outside the six paths; focused coverage
  `service_identifier.cpp` 100 % line / 50 % branch, `string_registry.cpp` 75.8 % / 66.7 %; overall
  77.8 % / 64.3 %; asan/lsan/memcheck pass; tsan environment failure; clang-tidy config blocker;
  CodeQL security no candidate-path findings; CodeQL MISRA only googletest-macro
  `external-linkage-…` hits with draft/unestablished applicability; `native_*` / `cross_compilation`
  / `native_performance` failing to fetch toolchains/Ubuntu image with `No space left on device`).
  **Per the task rule, a successful collection node means results were *retained*, not that checks
  *passed*; here nothing is even present, so nothing may be treated as satisfied on that basis.**

### 1.6 Host addendum (task context, not acceptance)

The host addendum (present only as quoted by prior reports) states it "is task context, not
engineering acceptance or an approved tailoring decision." It asks the review to cover the
`verification_process.rst` test types (fault injection, interface, requirements, resource) and
derivation techniques (requirements/design/boundary/equivalence/fuzzy/error-guessing/explorative);
to keep `security_review`, `traceability_review`, `integration_aou_review`, and
`verification_report_draft` distinguishing configured module tests from any absent fuzz/fault-
injection harness or full feature/platform reference-hardware tests; to leave unknown applicability
and unexecuted applicable checks explicit; to **not** label identifier-only tests as full platform
validation and **not** to claim a fuzzy technique without a measurement; to permit concrete missing
boundary/equivalence regression cases within the six source paths; and states there is **no
authority to invent native links, select a safety classification, accept risk/deviations, or answer
the independent human gate.** This report honours that in §5, §8, and §9.

---

## 2. The recorded syntax failure: inspection of the actual source

### 2.1 Finding (re-verified this iteration by direct `read_file` + `grep`)

`score/socom/impl/service_identifier.hpp` is **brace-balanced**. It is exactly 40 lines. A `grep`
for brace characters (`[{}]`) on the file returned exactly four matches:

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`) and two closers (`:32`, `:38`): net brace balance is `0`. There is **no
third, unmatched closing brace**, and line 39 contains no text at all. The task's "extra closing
brace … at line 39" therefore matches a **stale, pre-correction** description — the earliest prior
reports quote lines 38–39 as the split-form `}  // namespace socom` + `}  // namespace score` — not
the actual working tree. The `reproducer` iteration records the correction; every later prior report
records the header as already balanced, which is what the actual source shows here.

### 2.2 Repository convention

The tree uses two internally-consistent styles:

- **Nested open + single close:** `namespace score::socom {` … one `}  // namespace score::socom`.
  This is the sibling `impl/service_identifier.cpp` (`:18` / `:32`) and the public
  `service_interface_identifier.hpp` (`:25` / `:164`).
- **Split open + double close:** `namespace score {` + `namespace socom {` … `}  // namespace
  socom` + `}  // namespace score`. This is `impl/runtime_impl.hpp` (`:32-33` / `:232-233`).

`impl/service_identifier.hpp` follows the **nested** form consistently and is balanced.

### 2.3 Correction status

**No correction was applied, and none is required.** The minimal repair — retained for reference
only, in the event the imbalance ever reappears — matches the sibling `.cpp`:

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

Applying this to the already-balanced file would be a no-op; re-introducing a broken state merely
to "fix" it would be a regression. Two independent reasons prevented a source write, either of
which is sufficient: (a) there is no defect to correct in the actual source, and (b) the task's
explicit write boundary permits only this report and the permitted tool set contains no
`edit_file`. **If a different revision (the "cancelled draft") still carries the extra brace, it is
not the file in this checkout** and must be located and corrected by an authorized iteration; this
report records the discrepancy for human disposition rather than speculating.

### 2.4 Why it would matter if present

The header is compiled into `//score/socom:socom` (`score/socom/BUILD:24-41`; its `srcs` globs
`impl/**/*.cpp` and `impl/**/*.hpp`) and re-exposed to `//score/socom/test/unit` through the
`testonly` library `impl_service_identifier` (`score/socom/BUILD:46-54`;
`score/socom/test/unit/BUILD:24`). A syntax error there would fail the library and the whole
`socom_test` target, contradicting S-CORE quality criterion 9, "Freedom from compiler warnings &
errors, 100 %" (`verification_plan.rst`). It is **not** a blocker in the current tree; that is a
static brace-balance reading, **not** a compile measurement, and no GCC measurement is reproduced
here (no build tool in this task).

---

## 3. The key type and its role

| Item | Site | Notes |
|------|------|-------|
| Key struct `Service_instance_identifier{ Service_interface_identifier interface; Service_instance instance; }` | `score/socom/impl/service_identifier.hpp:29-32` | Comment `:21-28` states it is "only used to check if any (Disabled, Enabled) Server_connector for the given interface and instance already exists" and documents the minor exclusion. |
| `operator<` declaration | `score/socom/impl/service_identifier.hpp:35` | The **only** operator declared for this type (no `operator==`, no `std::hash`). It is wrapped in `\cond`/`\endcond` (`:34`, `:36`). |
| `operator<` definition (working tree) | `score/socom/impl/service_identifier.cpp:20-30` | `std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major) < std::tie(rhs.instance, rhs.interface.id, rhs.interface.version.major)` (`:28-29`) — identity `(instance, id, major)`, **minor excluded**; comment `:21-27`. |
| Baseline `operator<` (pre-draft) | reported in `prior-reports/invariants.md` I-4 | `std::tie(lhs.instance, lhs.interface) < …` — identity `(instance, id, major, minor)`. The baseline blob is not in this working tree, so this is a prior-report reading, not a re-read. |
| Container binding | `score/socom/impl/runtime_impl.hpp:56` | `using Service_identifiers = Mutexed_variable<std::set<Service_instance_identifier>>;` (`Mutexed_variable` at `:50-54`). |
| Storage | `score/socom/impl/runtime_impl.hpp:228-229` | `Runtime_impl::m_service_identifiers` (`std::shared_ptr<Service_identifiers>`). |
| Include | `score/socom/impl/runtime_impl.hpp:30` | `#include "service_identifier.hpp"`. |

`std::set` uniqueness is `!(a<b) && !(b<a)`. On the working tree, `minor` is therefore **not** part
of the duplicate-server key; on the baseline (per the prior report) it was.

---

## 4. Construction sites

### 4.1 Construction of `Service_instance_identifier` (the duplicate key)

| Site | Code | Relevance |
|------|------|-----------|
| `score/socom/impl/runtime_impl.cpp:443` | `Service_instance_identifier const identifier{configuration.get_interface(), instance};` | **The only production construction site of the key**, in `Runtime_impl::make_server_connector` (credentials overload, `:440-467`). |
| `score/socom/impl/runtime_impl.cpp:449-454` | under `m_service_identifiers->mutex` (`:450`): `if (!m_service_identifiers->data.insert(identifier).second) return MakeUnexpected(Construction_error::duplicate_service);` (`:451-452`) | Duplicate rejection. |
| `score/socom/impl/runtime_impl.cpp:456-463` | `Final_action` captures `identifier` + `weak_ptr<Service_identifiers>` and `data.erase(identifier)` on destruction | Key lifetime = connector lifetime. |
| `score/socom/impl/runtime_impl.cpp:465-466` | `std::make_unique<SC_impl>(…)` | Connector construction, after the set insert. |

Entry into `make_server_connector`: the no-credentials overload (`:433-438`) delegates to the
credentials overload (`:440-467`).

### 4.2 Construction of `Service_interface_identifier` / `Service_instance`

Constructors live in `score/socom/service_interface_identifier.hpp`:

- `Service_instance` — class `:28-55`; `Id = Registry_string_view` `:30`; `id` `:33`; constructors
  `:37` (`Id`), `:41-42` (`string_view` → `instance_id_registry().insert`), `:48-49` (`string_view`
  + `Literal_tag`), `:53-54` (`std::string&&`).
- `Service_interface_identifier::Version` — `:80-88`; `major` `:83` (`std::uint16_t`), `minor` `:87`
  (`std::uint16_t`).
- `Service_interface_identifier` — struct `:74-124`; `Id` `:77`; `id` `:91`; `version` `:94`;
  constructors `:99-100` (`Id` + `Version`), `:105-106` (`string_view` → `service_id_registry().insert`),
  `:113-116` (`string_view` + `Literal_tag`), `:121-123` (`std::string&&`).

### 4.3 Definition / accessor types feeding the key

| Site | Code | Relevance |
|------|------|-----------|
| `score/socom/service_interface_definition.hpp:65` | `Service_interface_identifier const interface;` | Stored by `Service_interface_definition`. |
| `score/socom/service_interface_definition.hpp:85-86` | `Server_service_interface_definition(Service_interface_identifier const& sif, …)` | Server-configuration constructor. |
| `score/socom/service_interface_definition.hpp:101` | `operator Service_interface_definition() const;` | Conversion to the client-side definition. |
| `score/socom/service_interface_definition.hpp:105` | `Service_interface_identifier const& get_interface() const noexcept;` | Accessor used at `runtime_impl.cpp:443`. |
| `score/socom/impl/service_interface_definition.cpp:20-28` | constructors store `interface{sif}` (`:23`, `:28`) | — |
| `score/socom/impl/service_interface_definition.cpp:30-35` | `operator==` delegates to mutual non-ordering (`:31`) with an assert on `num_events`/`num_methods` | — |
| `score/socom/impl/service_interface_definition.cpp:37-39` | `operator<` → `lhs.interface < rhs.interface` (`:38`) | Ordering includes minor via `Service_interface_identifier::<`. |
| `score/socom/impl/service_interface_definition.cpp:41-44` | `Server_service_interface_definition` ctor stores `m_configuration` | — |
| `score/socom/impl/service_interface_definition.cpp:53-55` | `operator Service_interface_definition()` returns `m_configuration` | — |
| `score/socom/impl/service_interface_definition.cpp:65-68` | `get_interface()` returns `m_configuration.interface` | The exact value used to build the key. |

### 4.4 Config → socom construction sites (all narrow `minor`; see §5.4)

| Site | Construction | Downstream path |
|------|--------------|-----------------|
| `score/someipd/impl/remote_network_service.cpp:42-47` | `iface{service_type_name()->string_view(), {service_version_major(), static_cast<uint16_t>(service_version_minor())}}` (`:42-45`); `inst{service_type_name()->string_view()}` (`:47`) | `make_server_connector` at `:53` → key via `runtime_impl.cpp:443`. |
| `score/someipd/impl/local_network_service.cpp:46-52` | same pattern (`:46-49`, `:52`) | `make_client_connector` at `:58` → `Service_database::get_record`. |
| `score/gatewayd/impl/local_service_instance.cpp:46-53` | same pattern (`:46-49`, `:53`) | `make_server_connector` at `:59` → key. |
| `score/gatewayd/impl/remote_service_instance.cpp:89-94` | same pattern (`:89-92`, `:94`) | `make_client_connector` at `:105` → `get_record`. |
| `score/gatewayd/main.cpp:229-235` | same pattern (`:229-232`, `:235`) | Builds the shared-memory configuration map keyed by `Service_interface_identifier`. |

### 4.5 Test construction sites

| Site | Construction | Relevance |
|------|--------------|-----------|
| `score/socom/test/unit/service_identifier_tests.cpp:92-100` | `make_identifier(service_id, major, minor, instance_id)` builds `Service_interface_identifier` with `Literal_tag` (`:96-97`), `Service_instance` (`:98`), and `Service_instance_identifier{interface, instance}` (`:99`) | Drives the 83 key tests. |
| `score/socom/test/unit/service_identifier_tests.cpp:86-90` | `identity_of(identifier)` projects `(instance, id, major)` | Independent reference tuple for ordering/equivalence checks. |
| `score/socom/test/unit/service_identifier_tests.cpp:115-154` | deterministic 36-key and 64-key domains, built through `make_identifier` | Property-style checks; pure functions of compile-time constants. |
| `score/socom/test/unit/runtime_tests.cpp:409-418` | builds `interface_minor_2` (`1,2`), `interface_minor_3` (`1,3`) and two `Server_service_interface_definition`s | Feeds the minor-only duplicate regression at `:402-431`. |
| `score/socom/test/framework/inc/score/socom/single_connection_test_fixture.hpp:37-39` | `Service_interface_identifier{"TestInterface1", Literal_tag{}, Version{1U,2U}}` + `Service_instance{"TestInterface1", Literal_tag{}}` | Fixture for `RuntimeTest`. |

---

## 5. Conversion sites

### 5.1 socom `Service_interface_identifier` → IPC `Service`

| Site | Code | Relevance |
|------|------|-----------|
| `score/gateway_ipc_binding/gateway_ipc_binding.hpp:80-85` | `struct Service { Service_id service_id; socom::Service_interface_identifier::Version version; to_socom_identifier(); }` (`:84`) | IPC POD carries `id + Version{major,minor}`. |
| `score/gateway_ipc_binding/impl/gateway_ipc_binding.cpp:45-53` | `make_service(interface)` copies `version.major` (`:47`) / `version.minor` (`:48`) and asserts the id fits the fixed string (`:50`) | socom → IPC, **full version retained**. |
| `score/gateway_ipc_binding/impl/gateway_ipc_binding.cpp:55-59` | `make_instance_id(instance)` | `Service_instance` → IPC instance id. |
| `score/gateway_ipc_binding/impl/key.hpp:66-69` | `Keys::get(Service_interface_identifier, Service_instance)` → `get(make_service(configuration), make_instance_id(instance))` (`:68`) | socom → IPC key bridge; full version retained in the `Service` key. |
| `score/gateway_ipc_binding/impl/key.hpp:76-79` | `Keys::get(Service_interface_definition, Service_instance)` → `get(configuration.interface, instance)` (`:78`) | Definition overload. |
| `score/gateway_ipc_binding/impl/binding_base.cpp:207-208` | `msg.payload.service_id = make_service(state.service); msg.payload.instance_id = make_instance_id(state.instance);` | Outbound IPC message construction. |
| `score/gateway_ipc_binding/impl/binding_base.cpp:221-222` | `send_request_service_locked(make_service(state.service), make_instance_id(state.instance), true)` | Outbound request. |
| `score/gateway_ipc_binding/impl/binding_base.cpp:636-637` | `make_service(configuration.interface); … make_instance_id(instance);` | IPC → socom lookup path. |
| `score/gateway_ipc_binding/impl/service_state.hpp:97` | `msg.payload.service_id = make_service(service);` | Connect_service message. |
| `score/gateway_ipc_binding/impl/shared_memory_slot_manager.cpp:412-413` | `entry.service = make_service(interface)` (`:412`), `entry.instance_id = make_instance_id(instance)` (`:413`) | Configuration serialization. |

### 5.2 IPC `Service` / `Instance_id` → socom identifiers

| Site | Code | Relevance |
|------|------|-----------|
| `score/gateway_ipc_binding/impl/gateway_ipc_binding.cpp:27-30` | `Service::to_socom_identifier()` → `Service_interface_identifier{fixed_string_to_string(service_id), {version.major, version.minor}}` | IPC → socom, **full `(major, minor)` preserved**. |
| `score/gateway_ipc_binding/impl/service_state.hpp:415` | `get_or_create` builds `interface.to_socom_identifier()` | IPC → socom service state. |
| `score/gateway_ipc_binding/impl/shared_memory_slot_manager.cpp:286` | `register_configuration` builds `entry.service.to_socom_identifier()` | IPC → socom map key. |
| `score/gateway_ipc_binding/impl/binding_base.cpp:352-356` | `make_client_connector(Service_interface_definition{msg.service_id.to_socom_identifier()}, Service_instance{fixed_string_to_string(msg.instance_id)}, …)` (`:354`) | IPC request → socom client connector. |
| `score/gateway_ipc_binding/impl/shared_memory_managers.hpp:56-57` | `interface.get().to_socom_identifier()` (`:56`), `socom::Service_instance{fixed_string_to_string(instance.get())}` (`:57`) | Key → socom identifiers for slot-manager creation. |

### 5.3 `Service_interface_definition` type conversions

| Site | Code | Relevance |
|------|------|-----------|
| `score/socom/service_interface_definition.hpp:101,105` | `operator Service_interface_definition()` / `get_interface()` | Enable `configuration.get_interface()` at the key site. |
| `score/socom/impl/service_interface_definition.cpp:53-55,65-68` | implementations of the above | — |

### 5.4 Config → socom, including the version-width narrowing

The SOME/IP config declares `service_id: uint16` (`score/config/mw_someip_config.fbs:16`),
`service_version_major: uint8` (`:19`) and `service_version_minor: uint32 = 0xFFFFFFFF` (`:23`, the
SOME/IP "accept any minor" wildcard). socom's `Version` uses `std::uint16_t major` / `std::uint16_t
minor` (`score/socom/service_interface_identifier.hpp:83,87`). Every config→socom conversion narrows
`uint32→uint16`:

| Site | Expression | Relevance |
|------|------------|-----------|
| `score/someipd/impl/remote_network_service.cpp:44-45` | `{service_version_major(), static_cast<uint16_t>(service_version_minor())}` | Cast of a value that may be the `0xFFFFFFFF` wildcard → `0xFFFF`. |
| `score/someipd/impl/local_network_service.cpp:48-49` | same | same. |
| `score/gatewayd/impl/local_service_instance.cpp:48-49` | same | same. |
| `score/gatewayd/impl/remote_service_instance.cpp:91-92` | same | same. |
| `score/gatewayd/main.cpp:231-232` | same | same. |

Recorded as call sites; no runtime behaviour is claimed. `service_version_major()` is `uint8` and
widens losslessly into `std::uint16_t`; only the minor narrowing is lossy.

---

## 6. Comparison / ordering / hashing sites

### 6.1 socom identifier operators (`score/socom/service_interface_identifier.hpp`)

| Site | Operator | Compares |
|------|----------|----------|
| `:61-63` | `Service_instance ==` | `id` (`:62`) |
| `:69-71` | `Service_instance <` | `id` (`:70`) |
| `:130-133` | `Version ==` | `(major, minor)` (`:132`) |
| `:140-143` | `Version <` | `(major, minor)` (`:142`) |
| `:149-152` | `Service_interface_identifier ==` | `(id, version)` (`:151`) |
| `:159-162` | `Service_interface_identifier <` | `(id, version)` (`:161`) |
| `:170-175` | `std::hash<Service_instance>` | `hash(id)` (`:173`) |
| `:181-190` | `std::hash<Service_interface_identifier>` | `h1 ^ (h2<<1) ^ (h3<<2)` (`:184-187`, includes minor) |

### 6.2 The duplicate-key ordering

| Site | Code | Notes |
|------|------|-------|
| `score/socom/impl/service_identifier.cpp:20-30` | `std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major) < std::tie(rhs.instance, rhs.interface.id, rhs.interface.version.major)` (`:28-29`) | The only ordering for the key. Working-tree identity is `(instance, id, major)`; **minor is not compared**. No `operator==`/hash for `Service_instance_identifier`. Baseline identity (per `invariants.md` I-4) also included minor. |

### 6.3 Compatibility predicates (separate from the key)

| Site | Code | Notes |
|------|------|-------|
| `score/socom/impl/runtime_impl.cpp:133-136` | `is_minor_version_compatible`: `client.version.minor <= server.version.minor` | Minor semantics used *outside* the key. |
| `score/socom/impl/runtime_impl.cpp:138-146` | `is_interface_compatible`: equal `id`, equal `major`, then the minor rule (`:144-145`) | Called at `:508-509` and `:536`. |
| `score/socom/impl/runtime_impl.cpp:505-517` | Client bind: checks `is_minor_version_compatible` (`:506`), else logs an error (`:512-516`) | — |
| `score/socom/impl/runtime_impl.cpp:534-544` | Server connect: same check (`:535`), else logs an error (`:539-542`) | — |

### 6.4 The minor-ignoring database key (coarser than the public identifier)

| Site | Code | Notes |
|------|------|-------|
| `score/socom/impl/runtime_impl.hpp:116-121` | `Minor_version_ignoring_key_equal`: `(lhs.id == rhs.id) && (lhs.version.major == rhs.version.major)` (`:119`) | Ignores `minor`. |
| `score/socom/impl/runtime_impl.hpp:123-129` | `Minor_version_ignoring_hash`: `id_hash ^ (major_hash << 1)` (`:127`) | Ignores `minor`. |
| `score/socom/impl/runtime_impl.hpp:131-134` | `Service_interfaces = unordered_map<Service_interface_identifier, Service_instances, Minor_version_ignoring_hash, Minor_version_ignoring_key_equal>` | The record index. |

### 6.5 Other comparison / hashing sites that use the full identifier

| Site | Code | Notes |
|------|------|-------|
| `score/socom/impl/runtime_impl.hpp:99-100` | `using Interfaces_instances = std::unordered_map<Service_interface_identifier, Instances>;` | Uses the **full-version** `std::hash`/`operator==` (includes minor). |
| `score/gateway_ipc_binding/shared_memory_slot_manager.hpp:289-291` | `std::map<Service_interface_identifier, std::map<Service_instance, Shared_memory_metadata>>` | `std::map` ordering uses `Service_interface_identifier::operator<` (includes minor). |
| `score/gateway_ipc_binding/impl/gateway_ipc_binding.cpp:32-35` | `operator==(Service, Service)` | `service_id`, `version.major`, `version.minor`. |
| `score/gateway_ipc_binding/impl/gateway_ipc_binding.cpp:37-43` | `Service_hash::operator()` | `(hash(service_id) ^ (hash(major)<<1)) ^ (hash(minor)<<2)` (`:42`). |
| `score/gateway_ipc_binding/impl/key.hpp:35-40` | `Keys` keyed by `unordered_map<Service, …, Service_hash>` (`:38`) | IPC-side identity **keeps full version**. |

**Cross-boundary observation (static, not a defect claim).** Within socom the duplicate-server key
and the `Service_database` index ignore `minor`, but the public identifier hash/order, the
`Interfaces_instances` map, and the IPC `Service` key keep it. Issue #84's "service identifier = id +
major" proposal is currently implemented *only* at the internal duplicate-key/index level; the
public-interface and IPC layers still distinguish minors.

---

## 7. Service-database call sites

`Service_database` (`score/socom/impl/runtime_impl.hpp:102-138`) is the only owner of
`m_service_records` (`:137`).

| Site | Call | Notes |
|------|------|-------|
| `score/socom/impl/runtime_impl.hpp:106-113` | `get_record(…)` (`:106-107`), `get_instances(…)` declarations (`:109-113`) | Internal API; two `get_instances` overloads. |
| `score/socom/impl/runtime_impl.cpp:313-324` | `Service_database::get_record` | `m_service_records.find(interface)` (`:315`), then `emplace(interface, …)` (`:317`), then inner `emplace(instance, Service_record{…})` (`:320-321`). The outer `find`/`emplace` use the minor-ignoring key/hash. |
| `score/socom/impl/runtime_impl.cpp:326-343` | `get_instances(interface, filter)` | `m_service_records.find(interface)` (`:329`); filters by `is_available()` and optional instance. |
| `score/socom/impl/runtime_impl.cpp:345-360` | `get_instances(optional<interface>, filter)` | Iterates all of `m_service_records`; forwards to the first overload at `:349`. |
| `score/socom/impl/runtime_impl.cpp:496` | `m_database.get_record(configuration.interface, instance)` in the client `register_connector` (`:492-524`) | **Client call site.** |
| `score/socom/impl/runtime_impl.cpp:530` | `m_database.get_record(interface, instance)` in the server `register_connector` (`:526-551`) | **Server call site.** |
| `score/socom/impl/runtime_impl.hpp:220-221` | `m_runtime_mutex`, `Service_database m_database{m_runtime_mutex};` | Owned by `Runtime_impl`. |

**Observation (static, not a defect claim).** `get_instances` is declared twice
(`runtime_impl.hpp:109,112`), defined twice (`runtime_impl.cpp:326,345`), and self-called at
`runtime_impl.cpp:349`. No external caller of `Service_database::get_instances` was found in the
working tree; only `get_record` is used.

### 7.1 Record registration reached through `get_record`

| Site | Call | Notes |
|------|------|-------|
| `score/socom/impl/runtime_impl.cpp:366-382` | `Service_record::register_server_connector` | `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)` at `:369`; `m_server.emplace(Interfaced_server{interface, …})` at `:371`; `Server = std::optional` (`runtime_impl.hpp:70`). |
| `score/socom/impl/runtime_impl.cpp:384-399` | `Service_record::register_client_connector` | Returns `Construction_error::duplicate_client` if `m_client` already set (`:386-388`); `m_client.emplace(…)` at `:389`. |
| `score/socom/error.hpp:54-58` | `Construction_error` enum | `duplicate_service,  ///< Service identifier already exists.` (`:55`) — the comment is narrower than the actual key (`instance + id + major`). |

### 7.2 The key/index equivalence question (static, not reproduced)

On the **baseline**, the duplicate key included `minor` (`invariants.md` I-4) while `Service_database`
indexes by `id + major` and ignores it (§6.4). Two enabled-or-constructing server connectors for the
same `id + major + instance` with different minors then (1) build distinct keys, both passing the
insert check at `runtime_impl.cpp:451`, but (2) resolve to the same `Service_record` via the
minor-ignoring `find` at `runtime_impl.cpp:530`, so the second `register_server_connector` reaches
`ASSERT(!m_server)` (`:369`); where the assert does not terminate, `m_server.emplace` (`:371`)
silently replaces the first. On the **working tree**, the draft's key change makes the key as coarse
as the record index, so the second insert at `:451` is rejected first. Both readings are static;
neither is a measured runtime result. Whether this gap is a real defect is an open question (§10).

---

## 8. Tests covering the key and its neighbours

| Site | Coverage | Gap for this slice |
|------|----------|--------------------|
| `score/socom/test/unit/service_identifier_tests.cpp` | **New file**, `grep TEST_F` = **83** cases (`:168`…`:1851`) under `ServiceInstanceIdentifierTest`: irreflexivity (`:168`), minor-only duplicate (`:174`) and boundaries (`:182,192,203`), major including `0`/`65535` and adjacency (`:217-246`), service-id/instance distinctness and lexicography (`:262-357`), combined 2×2×2 and 3×3×3 matrices with minor collapse (`:358-419`), equivalence/ordering consistency and independent tuple reference (`:420-536`), strict-weak-ordering property checks over deterministic 36-key and 64-key domains (`:537-735`, `:1055-1148`, `:1456-1488`), text/registry → public-identifier → internal-key conversion boundaries (`:784-1054`, `:1149-1200`, `:1531-1600`), and additional boundary/ladder cases to `:1851`. Metadata in `SetUp()` (`:42-65`): `DerivationTechnique = "boundary-values,equivalence-classes"` (`:50`); `TestType`/certificate links deliberately unset (`:57-64`). | Not executed here; the last recorded host run covered a 46- or 83-case state of the key translation unit only. |
| `score/socom/test/unit/runtime_tests.cpp` | `grep` = **31 `TEST_F`** (`:279`…`:1253`) + **1 `TEST`** (`RuntimeFactoryTest.DefaultConstructorWorks`, `:239`) + **1 `TEST_P`** (`RuntimeBridgeTest.CreationOfClientsWillCallRequestServiceFunction`, `:1311`). Duplicate/lifetime cases include `ConstructDuplicateReturnsDuplicateServiceError` (`:334`), `ConstructDuplicateMultipleTimesReturnsDuplicateServiceError` (`:350`), `CreatingServerConnectorDeletingItAndRecreatingReturnsValidServerConnector` (`:371`), **`ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError` (`:402-431`)**, `ConstructDuplicateSameConfigurationWhileBothConnectorsDisabledReturnsDuplicateServiceError` (`:440`), `ConstructDuplicateWhileFirstConnectorEnabledReturnsDuplicateServiceError` (`:694`), `ConstructDuplicateAfterEnabledConnectorDestroyedReturnsValidServerConnector` (`:986`), `DestroyingOneMajorSlotKeepsOtherMajorSlotOccupied` (`:1141`), `DestroyingOneInstanceSlotKeepsOtherInstanceSlotOccupied` (`:1197`), `DestroyingOneServiceIdSlotKeepsOtherServiceIdSlotOccupied` (`:1253`). Metadata helper `record_registration_key_metadata` (`:264-267`). | None executed here; the prior host measurement did not compile `runtime_tests.cpp`. |
| `score/socom/test/unit/service_interface_identifier_tests.cpp` | Constructors of `Service_interface_identifier` (per prior call-site map `:26-29,58,65,75,84`). | No ordering/identity test for `Service_instance_identifier`. |
| `score/socom/test/unit/interface_compatibility_tests.cpp` | `ServerCreatedBeforeClient` / `ClientCreatedBeforeServer` parameterized over id/version (per prior map `:148-210`). | Covers `is_minor_version_compatible` semantics, not duplicate detection. |
| `score/socom/test/unit/client_tests.cpp` | `DifferentServiceInterfaceId` / `…InstanceId` / `…MajorVersion` / `…MinorVersion` (per prior map `:616-689`). | Exercises bind/no-bind; not the duplicate-server key. |

Counts are static readings from this iteration; the suites were not executed here. The 83 / 31
counts supersede the smaller 73 / 24 counts retained by `prior-reports/callsites.md`; those prior
reports remain preserved.

---

## 9. Obligations status (none satisfied)

### 9.1 Pinned state from `authority.json`

| Field | Value |
|-------|-------|
| `codeql_scope` | Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload |
| `engineering_acceptance` | **pending** |
| `human_reviews` | **unanswered** |
| `safety_class` | **unknown** |
| `instruction` | "Restart the failed queue for one complete pass through all obligations" |

All nine pinned sources in `.llm_tmp/context/obligations/` were read this iteration (§1.4); every
`source-index.json` entry is `"native_acceptance": "not_inferred"`.

### 9.2 Obligation status for this slice (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Freedom from compiler warnings & errors (100 %) | `verification_plan.rst` (criterion 9) | **NOT MEASURED** — header is brace-balanced by inspection (§2), but nothing was compiled in this iteration; no host artifact is present here |
| Static code analysis (clang-tidy / CodeQL), findings classified | `code_analysis.rst`; `verification_process.rst` (`gd_req__verification_sca_classification`) | **NOT PERFORMED** — no tool, no build; a prior clang-tidy attempt was blocked on configuration; CodeQL MISRA applicability unestablished (draft mapping) |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` | **UNKNOWN** — mapping document is `:status: draft`; not applied |
| Structural statement / branch coverage goals | `verification_plan.rst` (criteria 1–2) | **NOT MEASURED** — no test execution in this iteration; prior coverage capture is out of this checkout and below platform goals |
| Unit/component testing executed, results recorded | `verification_plan.rst` (criteria 6–7); `verification_guideline.rst` | **NOT EXECUTED** — 0 tests run this iteration; the prior key-TU run is stale/out-of-checkout and does not cover `runtime_tests.cpp` |
| Interface / requirements-based / resource / fault-injection test types | `verification_process.rst`; `verification_plan.rst` | **NOT PERFORMED / applicability not inferred** — no harness; identifier-only tests must not be labelled platform validation |
| Boundary / equivalence derivation | `verification_process.rst` | **SOURCE-ONLY** — cases exist in source (§8) but were not executed |
| Fuzzy testing technique | `verification_plan.rst` | **NOT EXECUTED / NOT CLAIMED** — no harness and no measurement |
| Linking tests to requirements (record properties) | `verification_process.rst` (`gd_req__verification_link_tests_cpp`) | **PARTIAL / NOT DONE** — `DerivationTechnique`/`Description` recorded (`service_identifier_tests.cpp:42-65`; `runtime_tests.cpp:264-267`); `TestType` and `Verifies` cannot be set without inventing identifiers |
| Independence of verification / review by a different committer | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Implementation inspection checklist IMPL_01…IMPL_03 | `inspection_checklist.rst` | **NOT FILLED** — draft template, no inspection |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** for this slice; no tool run here |
| Obligation collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **ABSENT in this checkout** — directory not present |
| Native acceptance | `source-index.json` | **not_inferred** for every entry |

**Explicit non-satisfaction statement.** Missing tools (no `shell`/build/test in this task), the
unknown safety class and un-inferred applicability, the incomplete extraction of host artifacts, the
absent obligation-collection results, and the unanswered human reviews mean **none of the checked
obligations may be treated as satisfied**. A collection node that retained results would only show
*retention*, not passing; here the results are not present at all. In particular, the absence of
`.llm_tmp/overnight/validation/` and `.llm_tmp/overnight/obligations/*/result.json` is **not**
evidence that the corresponding checks passed.

---

## 10. Measurement status, notice preservation, and pending human review

### 10.1 Measurement status

- **Tools:** `read_file`, `grep`, `glob`, `write_file` only. No `shell`, delegation, web, approval,
  publishing, or engineering acceptance.
- **Executed measurements:** **none** this iteration. No build, no `bazel test`, no runtime. Every
  statement is a static reading of the working tree at the baseline-bound candidate paths, or an
  explicitly-labelled logical consequence (e.g. the §7.2 gap and the expected red/green behaviour).
- **Test inventory (read, not run):** `service_identifier_tests.cpp` = **83 `TEST_F`**;
  `runtime_tests.cpp` = **31 `TEST_F` + 1 `TEST` + 1 `TEST_P`**. Counts are static readings; neither
  suite was executed here.
- **Regression target (source-derived, not executed):**
  `RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError`
  (`runtime_tests.cpp:402-431`) and the key-level minor-collapse cases
  (`service_identifier_tests.cpp:174`, `:182`, `:192`, `:203`, …) assert that a second registration
  differing only in `minor` is rejected as `duplicate_service`. On a key that includes `minor` they
  would fail; on the working-tree key they should pass. This is a `std::set`/strict-weak-ordering
  consequence, not an observed result.
- **Scope:** local, unprotected, scoped. This draft has not been reviewed, accepted, published, or
  reproduced on a full native runtime. Unit/integration execution and human review remain pending.
- **Reproduction path for the next authorized iteration (not run here):**

  ```bash
  bazel test //score/socom/test/unit:socom_test
  # focused key-level:
  bazel test //score/socom/test/unit:socom_test --test_filter='ServiceInstanceIdentifierTest.*'
  # focused runtime regression:
  bazel test //score/socom/test/unit:socom_test \
      --test_filter='RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError'
  ```

- **No correction was needed for the recorded syntax failure** (§2), and **no test was expanded** in
  this iteration. The write boundary ("only that report may be written") and the permitted tool set
  (no `edit_file`) were both respected.

### 10.2 Notice preservation

- No source, build, test, config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was created, edited, or
  deleted by this iteration; **only this report was written**. Every existing Apache-2.0 / notice
  header is untouched, and all 12 prior-report files under `.llm_tmp/overnight/prior-reports/` plus
  `.llm_tmp/overnight/reports/scope.md` were preserved.
- The header the task flagged (`score/socom/impl/service_identifier.hpp`) was inspected and left
  unchanged because it is already brace-balanced and otherwise well-formed (§2).
- This report itself carries the Apache-2.0 header.
- Any future implementation in this slice must carry the Apache-2.0 header on new files, including
  `service_identifier_tests.cpp`, per `.github/instructions/code-style.md` and `REUSE.toml`.

### 10.3 Pending human review checklist

- [ ] **Confirm the §2 source inspection**: the header is already brace-balanced (single nested close
      `}  // namespace score::socom`; line 39 blank), so the recorded syntax failure is stale and no
      correction is required. If the "cancelled draft" is a different revision that still carries the
      extra brace, locate it and authorize its correction; it is not the file in this checkout.
- [ ] **Resolve the instruction conflict**: was a review-only iteration intended (report only, as done
      here), or was source correction expected? The write boundary forbade the latter, it was moot
      because no defect was present, and no `edit_file` tool was permitted.
- [ ] **Confirm the call-site map in §3–§7** against baseline `f8a196c3…`, including the
      minor-excluded key (`service_identifier.cpp:28-29`) and the minor-ignoring database index
      (`runtime_impl.hpp:116-134`).
- [ ] **Confirm the baseline binding** in §1.2–1.3 (issue #84 ↔ commit `f8a196c3…`) and confirm that
      `prior-reports/invariants.md` I-4's baseline ordering (`minor` included) still describes the
      committed baseline.
- [ ] **Answer the open design questions**: minor-in-key semantics, duplicate-vs-supersede, status of
      `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)` (`runtime_impl.cpp:369`), config wildcard /
      `uint32→uint16` narrowing (`mw_someip_config.fbs:16,19,23` → §5.4), and public-identifier shape.
- [ ] **Confirm whether the §7.2 key/index gap is a real defect** and, if so, treat it as the slice's
      regression target.
- [ ] **Confirm the test coverage** (83 key cases and the 31 `TEST_F` + 1 `TEST` + 1 `TEST_P` runtime
      cases, especially the minor-only duplicate regression and the service-id slot-isolation case)
      and that using the public `Runtime::make_server_connector()` path is acceptable. Do **not**
      present the identifier-only tests as platform validation or claim an unmeasured fuzzy
      technique.
- [ ] **Keep the #84 public `Service_interface_identifier` restructure, FindService wildcard handling,
      and the config minor-wildcard narrowing out of this bounded slice** until separately accepted.
- [ ] **Supply the missing artifacts** (`.llm_tmp/overnight/obligations/*/result.json` and
      `.llm_tmp/overnight/validation/`) into this checkout; do not infer passing from absence or from
      prior reports' retained summaries.
- [ ] **Run the full native suite** (`bazel test //score/socom/test/unit:socom_test` and the broader
      `//score/...` set), including `runtime_tests.cpp`, record results, and schedule independent
      human review (the approver must differ from the author, per
      `gd_req__verification_independence`).
