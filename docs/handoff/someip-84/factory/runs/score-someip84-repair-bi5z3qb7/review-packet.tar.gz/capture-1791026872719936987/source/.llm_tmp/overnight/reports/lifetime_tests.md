<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — registration-slot reuse and connector-destruction tests (`lifetime_tests`)

**Document type:** review draft (actual-source inspection + registration-slot lifetime test record
+ premise reconciliation + host-feedback reconciliation + obligations status).

**Date:** 2026-10-03
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version handling in
socom* (issue #84) — this iteration records the **slot-lifetime** half of that slice: slot reuse
after connector destruction (including a **changed minor version**) and destruction isolation across
**different major / instance / service-id slots**.
**Run / branch:** `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ`; latest recorded commit
`8982760` — `fabro(01M3ZRSDK2XQAF1H48VWTPKQNZ): node_57efd47e04fdae0af817c408 (success)` (run
environment).
**Verified baseline commit:** `f8a196c3b16d5172d898394ab99b0ed81346d63d`
(`.llm_tmp/context/source-manifest.json:3`).

**Status:** **local, unprotected, scoped.** No engineering acceptance exists. Human reviews are
**unanswered**. Full native runtime tests remain **pending**. Every expected test result below is a
static source reading or an explicitly-labelled `std::set` / strict-weak-ordering / connector-lifetime
consequence, never an observed result — except where a host measurement artifact present in this
checkout is quoted and explicitly labelled as such. Nothing in this document is a published, reviewed,
or accepted engineering artifact.

> **Tool / write boundary actually observed.** Only `read_file`, `grep`, `glob`, and `write_file` were
> available and were the only tools used. No `shell`, no delegation, no web access, no approval, no
> publishing, no engineering acceptance, and no `edit_file` was performed. The task permits changing
> only the six named candidate source paths and this report. **This iteration wrote exactly one file —
> this report** (`/workspace/.llm_tmp/overnight/reports/lifetime_tests.md`). No source, build, test,
> config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was created, edited, or deleted. Every prior report
> under `.llm_tmp/overnight/prior-reports/` and every pre-existing `.llm_tmp/overnight/reports/*` file
> was preserved unchanged (including the same-named `prior-reports/lifetime_tests.md`, which is a
> different run's document and was **not** overwritten).
>
> **Premise reconciliation — why no source edit was made, though source writes were permitted.**
> The task records "a measured GCC syntax failure: an extra closing brace in
> `score/socom/impl/service_identifier.hpp` at line 39" and directs that the actual source be
> corrected before the tests are expanded. Direct inspection of the *actual* working tree this
> iteration (§2) shows the header is **already brace-balanced**: a `grep` for `[{}]` returns exactly
> four lines — `:19` (`namespace score::socom {`), `:29`
> (`struct Service_instance_identifier final {`), `:32` (`};`), and `:38`
> (`}  // namespace score::socom`) — i.e. two openers and two closers, net balance `0`; line `:39` is
> **blank** and `:40` is `#endif`. A `glob` for `**/service_identifier.hpp` returns exactly one path
> and a `glob` for `**/*.{orig,rej,bak}` returns nothing, so there is no second, differently-braced
> copy and no leftover patch/reject file. Independently, the host measurement **present in this
> checkout** compiled a translation unit that includes that header (`before-compile` *and*
> `after-compile` each exit `0`, both stderr empty, §1.5, §2.3) — which is incompatible with a syntax
> error. The described defect survives only in the earliest *pre-correction* prior reports; a
> `reproducer` iteration applied the single-close correction and it is present in this working tree.
> Editing an already-valid header — or re-introducing a broken brace merely to "fix" it — would be a
> no-op at best and a regression at worst, so **no production source was edited.**
>
> **The requested slot-lifetime tests are already present in the working tree.** The five focused
> runtime cases this slice asks for (slot reuse after destruction with a **changed minor version**,
> in the disabled and enabled states, and destruction isolation across different
> **major / instance / service-id** slots) already exist in the candidate test file
> `score/socom/test/unit/runtime_tests.cpp` (§4). This iteration verified and mapped them rather than
> appending duplicates; duplicating an existing deterministic suite would add complexity without
> adding coverage, contrary to the surgical-change requirement.
>
> **Artifact note.** The host validation directory `.llm_tmp/overnight/validation/` **is present in
> this checkout** (16 files) and was read (§1.5). The obligation-collection directory
> `.llm_tmp/overnight/obligations/` is **absent** — `glob` returns no entries and no
> `*/result.json` exists (§6.3). An absent result is not a passed check.

---

## 0. Summary

1. **Recorded syntax failure — inspected; not present in the actual source, and refuted by the host
   measurement.** `score/socom/impl/service_identifier.hpp` has exactly two opening braces (`:19`,
   `:29`) and two closing braces (`:32`, `:38`), net balance `0`; `:39` is empty and `:40` is
   `#endif`. `grep` over the file returns only those four brace lines; `glob` returns a single copy.
   The host compile of the identifier translation unit (which includes this header) exited `0` under
   `-Werror` in **both** the baseline-with-agent-tests and candidate legs, with empty stderr (§1.5,
   §2.3). No source correction was applied, because none is required and any edit would corrupt an
   already-valid header.
2. **Registration-key correction — present and consistent.** `Service_instance_identifier`'s only
   operator, `operator<`, orders by `(instance, service id, major)` and deliberately excludes `minor`
   (`score/socom/impl/service_identifier.cpp:28-29`), agreeing with the minor-ignoring
   `Service_database` record index (`score/socom/impl/runtime_impl.hpp:116-134`) (§3).
3. **The requested slot-lifetime tests already exist in the working tree, verified not re-added.**
   Five runtime-level cases in `score/socom/test/unit/runtime_tests.cpp` pin (a) slot reuse after
   connector destruction with a **changed minor version**, in both the disabled (`:1045-1085`) and the
   enabled (`:1091-1134`) state, and (b) destruction **isolation** across different **major**
   (`:1141-1191`), different **instance** (`:1197-1245`), and different **service-id**
   (`:1253-1304`) slots. Every duplicate expectation is written as a value comparison against the
   genuine error result `score::MakeUnexpected(Construction_error::duplicate_service)`, not a bare
   boolean assertion (§4).
4. **The latest host feedback is present and covers only the identifier translation unit.**
   `check-result` is `0`; `measurement.json` (`check_ref: check_unit_matrix`, `status: completed`,
   `mode: plain`, `changed_paths: []`) reports candidate compile exit `0` / 87 tests / 0 failures and
   `baseline_with_agent_tests` compile exit `0` / 87 tests / **30 failures**; `after.json` shows
   87 tests / 0 failures against `before.json` 87 / 30, all in the single suite
   `ServiceInstanceIdentifierTest`. The compile command (`after-compile.command.json`, exit `0`) names
   only `service_identifier.cpp`, `string_registry.cpp`, `service_identifier_tests.cpp`, `gtest-all.cc`,
   `gtest_main.cc` — **`runtime_tests.cpp` is not compiled or executed by any host measurement here**
   (§1.5, §5). `engineering_acceptance: pending`, `full_native_tests: not_executed`.
5. **No obligation is treated as satisfied** (§6). The obligation-collection results are absent; the
   pinned entries are `native_acceptance: not_inferred`; `authority.json` records
   `engineering_acceptance: pending`, `human_reviews: unanswered`, `safety_class: unknown`. Missing
   tools, unknown applicability, incomplete extraction, and unanswered human reviews are explicitly
   **not** treated as satisfied.

---

## 1. Binding to the verified baseline, prior reports, host feedback, obligations

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` | `.llm_tmp/context/issue-snapshot.json:2-4` |
| Title | *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:3` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` (unchanged) | `.llm_tmp/context/issue-snapshot.json:19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**: service-instance identifier = `service id + major + minor + instance id`; service
identifier = `service id + major`; FindService = `service id + major + optional<minor> +
optional<instance>`; and the proposal to "exclude the minor version and make it a property of the
service instance to be able to better compare and index compatible service instances." The
FindService `major = FF` AUTOSAR case is called theoretically possible but not useful. There is
**no comment and no acceptance record** in the snapshot, so none of it is binding.

### 1.2 Verified baseline and current tree

| Item | Value | Source |
|------|-------|--------|
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |
| Current branch | `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ` | run environment |
| Latest recorded commit | `8982760` — `node_57efd47e04fdae0af817c408 (success)` | run environment |

Binding is **by baseline commit**, not by run HEAD. Earlier reports reference other run IDs on the
same baseline commit (`01M3YRJEGXNY6CB81T7TKW774B`, `01M3YGTGYFEN406VDEVVTJTRWV`,
`01M3XZAQ65TTE35XSGXC4JAMAH`, `01M3XT7NQ04S4MTFRMTT2401XK`, `01M3WX09X84XFM5X08QY2944DF`, and before
them `01M3WSTF1DAJA248NQ5QQGQG52`/`a282596` and `01M3WWRQWT262FTYS52X80YPTP`/`e12e7cb`), so all of
them describe the same baseline and remain admissible prior evidence for this run's slice.

### 1.3 In-scope candidate files (the only writable source paths)

From `.llm_tmp/context/candidate-files.json:1-25` (five baseline blobs cross-checked against the
`files` array of `.llm_tmp/context/source-manifest.json`):

| File (repo-relative) | Baseline git blob | Baseline present | Recorded sha256 (manifest) | Host `measurement.json` hash | This iteration |
|----------------------|-------------------|------------------|----------------------------|------------------------------|----------------|
| `score/socom/BUILD` | `3477ea0851fdcd82ec6ea9d71424013cbdf41962` | yes | `dee82616…0ba44` | `68f4645a…d2cc8` | inspected; **unchanged** |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e22355242009fe20dada2a9a0d0c7a9c7` | yes | `d766902e…59a9a` | `3c12b3f1…1f11a` | inspected; **unchanged** (minor already excluded) |
| `score/socom/impl/service_identifier.hpp` | `c8bae7908da9f087c518934f7b9f8d86db9a20ec` | yes | `96b33a1f…a2119` | `bdce3fcb…faea9` | inspected; **unchanged** (already brace-balanced, §2) |
| `score/socom/test/unit/BUILD` | `3c03a7b14286051f97fa5022206564bd63645171` | yes | `9b3c5b34…186799` | `e909151e…ff9d4` | inspected; **unchanged** |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab726db8bf994c960045d6fd7fdf84d7395` | yes | `5e35e24d…66631e` | `9a2d6a15…1d3127` | inspected; **unchanged** (slot-lifetime cases already present, §4) |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(none — `null`)* | no (manifest expects a **new** file) | `45d07399…d36a25` | `4df2c63c…587a4` | inspected; **unchanged** (87-case key matrix present, §4.5) |

The `null` baseline blob for `service_identifier_tests.cpp` is the manifest's expectation of a
**new** unit-test file; it exists on disk only as part of the un-merged working tree (the
"cancelled draft"), never in the baseline. The recorded `candidate-files.json` sha256 values were
copied from the manifest and were **not** recomputed this iteration (no hashing tool was
available). The host `measurement.json` records *its own* per-file hashes
(`.llm_tmp/overnight/validation/measurement.json:1026-1029`, `:1206-1209`, `:1211-1214`,
`:1441-1444`, `:1516-1519`, `:1526-1529`) which differ from the `candidate-files.json` snapshot,
consistent with the in-run edits recorded by the earlier nodes of this run; those hashes cannot be
independently re-derived here.

### 1.4 Prior reports read and preserved

Read (and **not modified**) this iteration:

- `.llm_tmp/overnight/prior-reports/` — the corpus is present and preserved. The slice-relevant
  documents read in full or in substantial part: `lifetime_tests.md`, `lifetime_review.md`,
  `invariants.md`, `key_fix.md`, `reproducer.md`, `scope.md`, `unit_matrix.md`, `runtime_disabled.md`,
  `runtime_enabled.md`, `ordering_tests.md`, `conversion_tests.md`, `test_metadata.md`; the remaining
  review artifacts were cross-checked as references. The prior-run `lifetime_tests.md` was read as
  evidence and is **not** overwritten; this document is written to the separate this-run path
  `.llm_tmp/overnight/reports/lifetime_tests.md`.
- `.llm_tmp/overnight/reports/` — the earlier nodes of this run, all preserved: `scope.md`,
  `invariants.md`, `callsites.md`, `reproducer.md`, `key_fix.md`, `unit_matrix.md`,
  `runtime_disabled.md`, `runtime_enabled.md`. This document adds `lifetime_tests.md`; nothing was
  overwritten.

Derived sequence across the preserved reports: `scope.md` (bounded the slice; identified the
key/index identity gap) → `invariants.md` (I-4 baseline key included `minor`; I-9 record index ignores
`minor`; I-11 the resulting gap) → `callsites.md` (call-site map) → `reproducer.md` (**header brace
correction** + focused red regression) → `key_fix.md`/`unit_matrix.md` (drop `minor` from the
ordering; expand the key tests) → `ordering_tests.md` → `runtime_disabled.md` (both connectors
disabled) → `runtime_enabled.md` (first connector enabled) → **this report** (slot-lifetime: reuse
after destruction and destruction isolation) → later conversion/metadata reports.

**Reconciliation of the conflicting brace claims across prior reports.** The earliest reports
quote lines 38-39 as the split-form double close (`}  // namespace socom` + `}  // namespace
score`) and record the header as **broken**. `reproducer.md` records that it **applied** the
correction; every later report records the header as **already balanced**. The actual source read
this iteration (§2) matches the **later** set; the header is balanced now.

### 1.5 Host validation feedback (present in this checkout) and obligation-collection results

**Host validation feedback under `.llm_tmp/overnight/validation/` — present, read this iteration.**

| Artifact | Content (verbatim / derived) |
|----------|------------------------------|
| `check-result` | `0` |
| `measurement.json` head | `check_ref: "check_unit_matrix"`, `status: "completed"`, `mode: "plain"`, `changed_paths: []` (`:1-5`) |
| `measurement.json` tail | `origin: "local_unprotected_measurement"`, `initiator: "Fabro host hook"`, `engineering_acceptance: "pending"`, `full_native_tests: "not_executed"`, `compiler: "/usr/bin/x86_64-linux-gnu-g++-12"`, `compiler_sha256: 88315fd2…c196d3`; `baseline_with_agent_tests {compile_exit 0, test_exit 1, tests 87, failures 30, disabled 0}`; `candidate {compile_exit 0, test_exit 0, tests 87, failures 0, disabled 0}` (`:2037-2056`) |
| `after.json` | `tests: 87`, `failures: 0`, single suite `ServiceInstanceIdentifierTest` (`:1-9`) |
| `before.json` | `tests: 87`, `failures: 30` (same suite; the agent key tests against the pre-correction key) (`:1-9`) |
| `before-compile.command.json` | `argv`: `g++-12 -std=c++17 -Wall -Wextra -Werror -pthread` over **only** `score/socom/impl/service_identifier.cpp`, `score/socom/impl/string_registry.cpp`, `score/socom/test/unit/service_identifier_tests.cpp`, plus the googletest sources; `exit_code: 0` (`:1-20`) |
| `after-compile.command.json` | identical `argv`/scope; `exit_code: 0` (`:1-20`) |
| `before-compile.stderr` | *(empty)* |
| `after-compile.stderr` | *(empty)* |
| `before-test.stdout` | `Running 87 tests from 1 test suite.` … first failure at `service_identifier_tests.cpp:178` |
| `after-test.stdout` | `Running 87 tests from 1 test suite.` … all `[ OK ]` from `ServiceInstanceIdentifierTest` |

**Scope caveat — decisive.** The compile commands name only `service_identifier.cpp`,
`string_registry.cpp` and `service_identifier_tests.cpp` (plus googletest). They do **not** compile
`runtime_tests.cpp` and do **not** build the Bazel `socom_test` / `//score/...` targets. The 87 tests
are all `ServiceInstanceIdentifierTest` cases; the `RuntimeTest` suite does not appear. Therefore the
five **slot-lifetime runtime tests recorded in §4 are not covered by any host measurement here** and
remain natively unmeasured. The artifact is explicitly `local_unprotected_measurement` with
`engineering_acceptance: pending` and `full_native_tests: not_executed` — not native acceptance.

**Independent refutation of the recorded syntax failure.** Both the baseline and the candidate leg
compile with `exit_code: 0` and empty stderr (§2.3). A translation unit that transitively includes
`impl/service_identifier.hpp` — with an extra closing brace in that header — cannot compile under
`-Wall -Wextra -Werror`. The recorded "measured GCC syntax failure" therefore does **not** describe
the file in this checkout.

**Obligation-collection results under `.llm_tmp/overnight/obligations/` — absent from this
checkout.** `glob .llm_tmp/overnight/obligations/**` and a repo-wide `glob **/result.json` both
return no entries; no `*/result.json` exists here. **Per the task rule, a successful collection node
means results were retained, not that checks passed; here nothing is retained at all, so no
obligation may be treated as satisfied on that basis.**

### 1.6 Pinned obligation sources and authority

All nine entries of `.llm_tmp/context/obligations/source-index.json` are present in
`.llm_tmp/context/obligations/`, together with `authority.json`. The `:status:` / `:safety:`
attributes were re-read this iteration:

| id | file | status / safety (re-read) |
|----|------|---------------------------|
| `coding_guidelines` | `coding_guidelines.rst` | `:status: valid` (`:20`), `:safety: ASIL_B` (`:22`); MISRA C++:2023 with C++17 |
| `code_analysis` | `code_analysis.rst` | `:status: valid` (`:20`), `:safety: ASIL_B` (`:22`); clang-tidy + gcc/clang warnings + Coverity; sanitizers; gcov/gcovr |
| `misra_mapping` | `misra_mapping.rst` | **`:status: draft`** (`:20`), `:safety: ASIL_B` (`:22`); the rule table is not a valid obligation |
| `verification_plan` | `verification_plan.rst` | `:status: valid` (`:17`), `:safety: ASIL_B` (`:19`); quality criteria 1-9 (`:292-335`), criterion 9 = "Freedom from compiler warnings & errors" at `:332-335` |
| `development_plan` | `development_plan.rst` | `:status: valid` (`:21`), `:safety: ASIL_B` (`:23`); C++17, GCC host compiler, QCC target, Bazel |
| `tool_management` | `tool_management.rst` | `:status: valid` (`:17`), `:safety: ASIL_B` (`:19`); tools identified / evaluated / qualified by a human |
| `verification_process` | `verification_process.rst` | `:status: valid` (`:22`); `gd_req__verification_link_tests_cpp` (`:56-75`), `_independence` (`:141-152`), `_checks` (`:178-196`), `_checks_extended` (`:198-212`), `_external_aou` (`:214-226`), `_sca_classification` (`:228-248`) |
| `verification_guideline` | `verification_guideline.rst` | `:status: valid` (`:19`); traceability, independence, documented results |
| `inspection_checklist` | `inspection_checklist.rst` | **`:status: draft`** (`:17`), `:safety: ASIL_B` (`:19`); blank `IMPL_01_01`…`IMPL_03_02` template |

Every entry in `source-index.json` is marked `"native_acceptance": "not_inferred"` — pinned, but its
applicability to this slice is **not inferred**. `authority.json` records
`"engineering_acceptance": "pending"`, `"human_reviews": "unanswered"`, `"safety_class": "unknown"`,
`"codeql_scope": "Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload"`, and the
instruction `"Restart the failed queue for one complete pass through all obligations"`.

**Safety-class note (recorded, not resolved).** The pinned platform documents carry `:safety: ASIL_B`,
while `authority.json` records `safety_class: unknown` and no authorized selection exists. The
document attribute is **not** a selection of the slice's safety class and must not be inferred as one.

---

## 2. The recorded syntax failure: inspection of the actual source

### 2.1 Finding (re-verified this iteration by direct `read_file` + `grep`)

`score/socom/impl/service_identifier.hpp` is **brace-balanced**. It is 40 lines; `grep` for `[{}]`
on the file returns exactly four matches:

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`) and two closers (`:32`, `:38`) mean net brace balance `0`; **there is
no third, unmatched closing brace**, and line 39 contains no text at all. A `glob` for
`**/service_identifier.hpp` returns exactly one path and `glob` for `**/*.{orig,rej,bak}` returns
nothing, so there is no second, differently-braced copy and no leftover patch/reject file. The task's
"extra closing brace … at line 39" is therefore a **stale, pre-correction description** matching the
earliest prior reports, not this snapshot. The `reproducer` iteration is the one that applied the
correction, as `reproducer.md` §2 records.

### 2.2 Repository convention (evidence)

The tree uses two internally-consistent styles:

- **Nested open + single close:** `namespace score::socom {` … one `}  // namespace score::socom`.
  This is the sibling `impl/service_identifier.cpp` (`:18` / `:32`), the public
  `service_interface_identifier.hpp`, and `error.hpp`.
- **Split open + double close:** `namespace score {` + `namespace socom {` … `}  // namespace
  socom` + `}  // namespace score`. This is `impl/runtime_impl.hpp`.

`impl/service_identifier.hpp` follows the **nested** form consistently and is balanced.

### 2.3 Independent measured refutation (host artifact present in this checkout)

The host "before" and "after" compiles (`.llm_tmp/overnight/validation/before-compile.command.json`,
`after-compile.command.json`; both `exit_code: 0` with **empty** `before-compile.stderr` and
`after-compile.stderr`) passed `score/socom/impl/service_identifier.cpp` and
`score/socom/test/unit/service_identifier_tests.cpp` to `g++-12 -std=c++17 -Wall -Wextra -Werror`
(`service_identifier.cpp:14` includes `"service_identifier.hpp"`, and the key tests construct
`Service_instance_identifier`). A C++ source that includes a header with an extra closing brace
cannot compile under `-Werror`, so the recorded "measured GCC syntax failure" does **not** describe
this snapshot. This is nonetheless a *focused-translation-unit* compile, not a Bazel build of
`//score/socom:socom`.

### 2.4 Disposition (no correction applied)

**No correction was applied, and none is required.** The minimal repair — matching the sibling
`.cpp` — would be, **only if the split-form imbalance reappeared**:

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

Applying this to the already-balanced file would be a no-op; deleting a brace to "fix" it would
*create* the reported defect. If the *"cancelled draft"* is a different revision that still carries
the extra brace, it is **not** the file in this checkout and must be located and corrected by an
authorized iteration; this report records the discrepancy for human disposition.

---

## 3. The registration key and its lifetime (source-derived)

The duplicate-server registration key is
`Service_instance_identifier { Service_interface_identifier interface; Service_instance instance; }`
(`score/socom/impl/service_identifier.hpp:29-32`). Its only operator is the out-of-line `operator<`
(`:35`), defined as (`score/socom/impl/service_identifier.cpp:28-29`):

```cpp
return std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major) <
       std::tie(rhs.instance, rhs.interface.id, rhs.interface.version.major);
```

Therefore:

- identity (`std::set` equivalence `!(a<b) && !(b<a)`) = **`(instance, service id, major)`**;
- **`minor` is excluded** — it selects a compatible instance and is enforced separately by
  `is_interface_compatible`, not treated as identity;
- the key agrees with the deliberately minor-ignoring `Service_database` record index
  (`score/socom/impl/runtime_impl.hpp:116-134`: `Minor_version_ignoring_key_equal` /
  `Minor_version_ignoring_hash` compare/hash `id + major` only).

The gate and its lifetime are in `Runtime_impl::make_server_connector`
(`score/socom/impl/runtime_impl.cpp:440-467`):

- the key is built at `:443` (`Service_instance_identifier const identifier{configuration.get_interface(), instance}`);
- it is inserted under its own mutex at `:449-454`; a collision returns
  `Construction_error::duplicate_service` at `:452`;
- the key is **held for the whole connector lifetime** — the header comment calls the struct "only
  used to check if any (Disabled, Enabled) Server_connector for the given interface and instance
  already exists" (`service_identifier.hpp:23-24`) — and is erased only by the `Final_action`
  installed at `:456-463` when the connector is destroyed.

Because the key excludes `minor`, a freed slot can be reused by a connector that carries a
**changed minor version**, and destroying one key never releases a different `major`, `instance`, or
service-id slot. `Service_instance_identifier` declares no `operator==` and no `std::hash`; the only
identity notion is `std::set` equivalence.

---

## 4. Slot-reuse and destruction-isolation runtime tests (present; verified, not re-added)

### 4.1 Files and scope

All of the following are inside the candidate path `score/socom/test/unit/runtime_tests.cpp`. They
use only the public `Runtime` / `Disabled_server_connector` / `Enabled_server_connector` API and
the existing test-framework helpers (`create_runtime()`, `create_server_callbacks()`,
`Server_service_interface_definition`, `to_num_of_methods`, `to_num_of_events`), so no framework or
build-wiring change is needed. The file includes `<utility>` (`:19`) for `std::move`. The
explanatory group comment is at `:1030-1039`.

In this codebase a service instance is represented by a server connector. The registration key
exists from construction (disabled state) to destruction; enabling a connector does not remove it.
"Slot reuse" is therefore realised by letting a connector go out of scope (destroying it) and then
calling `Runtime::make_server_connector(...)` again for the same identity; "destruction isolation"
is realised by destroying one connector while another connector on a different identity remains
alive.

### 4.2 Test list (present, verified this iteration)

| # | Test (lines) | Scenario | Expected (source-derived) |
|---|--------------|----------|---------------------------|
| 1 | `ConstructDuplicateAfterDisabledConnectorDestroyedWithChangedMinorVersionReturnsValidServerConnector` (`:1045-1085`) | Disabled connector for `id + major 1 + instance`, minor 2, created; duplicate with minor 3 refused while alive; then the disabled connector is destroyed and a minor-3 connector is constructed | While alive → `Construction_error::duplicate_service`; after destruction → re-construction valid & non-null |
| 2 | `ConstructDuplicateAfterEnabledConnectorDestroyedWithChangedMinorVersionReturnsValidServerConnector` (`:1091-1134`) | Same, but the first connector is **enabled** before the duplicate attempt, then destroyed | Duplicate while enabled → `duplicate_service`; after destruction → re-construction valid & non-null |
| 3 | `DestroyingOneMajorSlotKeepsOtherMajorSlotOccupied` (`:1141-1191`) | Major-2 connector kept alive; a major-1 connector is created in an inner scope and destroyed at its end; duplicates of major 2 attempted before and after | Before destroy → duplicate major 2 refused; major-1 slot re-creatable after destroy; major-2 slot still occupied (duplicate refused) |
| 4 | `DestroyingOneInstanceSlotKeepsOtherInstanceSlotOccupied` (`:1197-1245`) | Instance-B connector kept alive; an instance-A connector is created in an inner scope and destroyed at its end; duplicates of instance B attempted before and after | Before destroy → duplicate instance B refused; instance-A slot re-creatable after destroy; instance-B slot still occupied (duplicate refused) |
| 5 | `DestroyingOneServiceIdSlotKeepsOtherServiceIdSlotOccupied` (`:1253-1304`) | Service-id-B connector kept alive; a service-id-A connector is created in an inner scope and destroyed at its end; duplicates of service-id B attempted before and after | Before destroy → duplicate service-id B refused; service-id A slot re-creatable after destroy; service-id B slot still occupied (duplicate refused) |

Tests 1 and 2 cover the **slot-reuse after destruction with a changed minor version** requirement
in the two connector states (disabled, enabled). Tests 3, 4 and 5 cover the **destruction isolation
across different major / instance / service-id slots** requirement, completing the identity matrix.
Together they pin that the erase performed by the `Final_action` is exactly per-key and never
releases an unrelated slot.

Related pre-existing lifetime coverage retained unchanged in the same file:

- `CreatingServerConnectorDeletingItAndRecreatingReturnsValidServerConnector` (`:371-390`) — reuse
  with the **same** configuration after a disabled connector is destroyed (factory path);
- `ConstructDuplicateAfterEnabledConnectorDestroyedReturnsValidServerConnector` (`:986-1019`) —
  reuse with the **same** configuration after an enabled connector is destroyed;
- `ConnectorDestroyedAfterRuntimeDoesNotCrash` (`:1021-1028`) — the `weak_ptr` no-op after runtime
  destruction.

The pre-existing equivalence-class coexistence tests
(`ConstructDifferentMajorWhileBothConnectorsDisabledReturnsDistinctServerConnectors` `:471-500`,
`ConstructDifferentInstance…` `:505-531`, `ConstructDifferentServiceId…` `:538-567`, plus their
enabled counterparts `:763-826`, `:951-981`) cover coexistence only; tests 3-5 add the
destruction-isolation dimension.

### 4.3 "Preserve genuine error results rather than assertions" — verified

Every duplicate expectation is written as a value comparison against the **genuine error result**:

```cpp
score::Result<Disabled_server_connector::Uptr> const duplicate_service =
    score::MakeUnexpected(Construction_error::duplicate_service);
EXPECT_EQ(duplicate_service, duplicate);   // runtime_tests.cpp:1077, 1126, 1176, 1190, 1230, 1244, 1289, 1303
```

i.e. the actual error carried by the returned `Result` is preserved and checked, rather than a bare
boolean assertion. This matters because on the pre-correction key (minor included) a minor-only
second construction would **not** return an error at all: it would succeed, and enabling it would
reach `Service_record::register_server_connector()`'s single-server precondition
(`SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)`, `runtime_impl.cpp:369`) — a genuine termination, not
a returned error. The tests therefore preserve the real error result instead of asserting a
success the actual source would not produce.

### 4.4 Expected behaviour (source-derived, not observed)

- **On the corrected key** (`service_identifier.cpp:28-29`, minor excluded): each duplicate attempt
  in tests 1-5 collides at `runtime_impl.cpp:451-452` and returns `duplicate_service`; after the
  owning connector is destroyed the `Final_action` (`:456-463`) erases exactly that key, so the
  re-construction succeeds and the untouched slots remain occupied.
- **On the pre-correction key** (minor included): test 1's minor-3 second construction would
  succeed (distinct key) and `EXPECT_EQ(duplicate_service, duplicate)` would **fail**; test 2 would
  likewise fail while enabled; tests 3-5 would still pass for the major/instance/service-id
  differences but would no longer pin a minor-only collision.

These expectations are strict-weak-ordering / lifetime consequences of the source; they were
**not** executed here (§5).

### 4.5 Key-level matrix (the other candidate test file)

`score/socom/test/unit/service_identifier_tests.cpp` is the new key matrix expected by the
manifest. `grep` finds **87 `TEST_F`** cases under `ServiceInstanceIdentifierTest`
(`:168`…`:2012`, verified this iteration), including the focused minor-only collapse
`KeysDifferingOnlyInMinorVersionAreDuplicates` (`:174`) and its boundary/equivalence variants. The
file records `DerivationTechnique = "boundary-values,equivalence-classes"` and a `Description` in
`SetUp()` (`:42-65`); `TestType` and the `Verifies`/`PartiallyVerifies`/`FullyVerifies` links are
deliberately left unset because no verified native requirement/interface identifier exists for this
slice (no invented links). This file **is** covered by the host measurement (§1.5): 87 tests, 0
failures after the key correction, 30 failures before it.

### 4.6 Why no new test was written this iteration

The requested slot-lifetime coverage already spans the identity dimensions the lifetime contract can
vary — reuse after destruction with a changed minor version in both connector states, and
destruction isolation across major / instance / service-id slots — plus the pre-existing
same-configuration reuse and the `weak_ptr` after-runtime no-op. Appending further cases would
duplicate an existing deterministic suite and add complexity without coverage, contrary to the
surgical-change requirement. The requested tests are therefore **verified and retained, not
duplicated**. They are, however, **not compiled or executed** by any measurement in this checkout
(§5).

### 4.7 What is deliberately *not* claimed

- The slot-lifetime tests have **not been compiled or executed** here or by any host artifact in
  this checkout. The present host measurement compiled only the focused identifier TU
  (`service_identifier.cpp` + `string_registry.cpp` + `service_identifier_tests.cpp`), so the
  lifetime cases recorded above are entirely unmeasured.
- They exercise the registration-key gate and its erasure only. They are **not** platform
  validation, and no boundary/equivalence technique is claimed as *executed*; no fuzz,
  fault-injection, or reference-hardware harness exists in this workspace.
- They do not settle the open design questions (whether `minor` should ever distinguish, supersede
  vs reject, the authority of `ASSERT(!m_server)`, the #84 public-interface restructure, FindService
  wildcard, config `0xFFFFFFFF` narrowing). Those remain pending human decisions.

### 4.8 Build wiring (no BUILD change required)

- `score/socom/BUILD:46-54` defines the `testonly` `impl_service_identifier` library exposing
  `impl/service_identifier.hpp` to `//score/socom/test/unit:__pkg__`, depending on `:socom`.
- `score/socom/test/unit/BUILD:16-29` defines `socom_test` with `srcs = glob(include = ["*.cpp"])`
  (`:19`) and depends on `//score/socom:impl_service_identifier`, `//score/socom:mock`,
  `//score/socom/test/framework:socom_test_framework`, and googletest.

Therefore the lifetime test file is already collected and the internal key header is already
visible to the test package; **no BUILD change was required or made.**

---

## 5. Measurement and validation status

- **Tools:** `read_file`, `grep`, `glob`, `write_file` only. No `shell`, delegation, web, approval,
  publishing, engineering acceptance, or `edit_file`.
- **Executed measurements by this iteration:** **none**. No build, no `bazel test`, no runtime. The
  brace balance (§2) and all lifetime-test expectations (§4.4) are static readings or
  explicitly-labelled `std::set` / strict-weak-ordering / lifetime consequences.
- **Test inventory (read, not run):** `score/socom/test/unit/runtime_tests.cpp` has **31 `TEST_F`**
  (lines 279, 287, 295, 303, 311, 334, 350, 371, 402, 440, 471, 505, 538, 573, 607, 642, 694, 726,
  763, 796, 832, 869, 905, 951, 986, 1021, 1045, 1091, 1141, 1197, 1253 — verified this iteration
  by `grep`), plus **1 `TEST`** (`RuntimeFactoryTest.DefaultConstructorWorks`, `:239`) and
  **1 `TEST_P`** (`RuntimeBridgeTest.CreationOfClientsWillCallRequestServiceFunction`, `:1311`, with
  `INSTANTIATE_TEST_SUITE_P` at `:1323`). `score/socom/test/unit/service_identifier_tests.cpp`
  retains its **87 `TEST_F`** matrix (`:168`…`:2012`). Counts are static `grep` readings; the suites
  were not executed here (except the identifier TU via the host artifact, §1.5).
- **Host measurements present in this checkout:** `check_unit_matrix` only — a focused g++-12
  `-std=c++17 -Wall -Wextra -Werror -pthread` compile and run of `service_identifier.cpp +
  string_registry.cpp + service_identifier_tests.cpp`; candidate 87/0, baseline-with-agent-tests
  87/30, both compile exits `0` with empty stderr, `check-result: 0`
  (`origin: local_unprotected_measurement`, `initiator: Fabro host hook`,
  `engineering_acceptance: pending`, `full_native_tests: not_executed`). It does **not** cover
  `runtime_tests.cpp`, the `RuntimeTest` suite, the `socom_test` Bazel target, or the broader
  `//score/...` set, and must not be re-reported as full native results or as engineering
  acceptance. Its recorded per-file hashes differ from the `candidate-files.json` snapshot `sha256`
  values (§1.3), consistent with the in-run edits recorded by the earlier nodes.
- **Scope:** local, unprotected, scoped. This is a bounded source-inspection and test-verification
  record, not an accepted engineering decision. Full native runtime tests and human review remain
  pending.
- **Reproduction path for a later, permitted iteration (not executed here):**

  ```bash
  bazel test //score/socom/test/unit:socom_test
  # focused slot-lifetime regressions:
  bazel test //score/socom/test/unit:socom_test \
      --test_filter='RuntimeTest.ConstructDuplicateAfterDisabledConnectorDestroyedWithChangedMinorVersionReturnsValidServerConnector'
  bazel test //score/socom/test/unit:socom_test \
      --test_filter='RuntimeTest.ConstructDuplicateAfterEnabledConnectorDestroyedWithChangedMinorVersionReturnsValidServerConnector'
  bazel test //score/socom/test/unit:socom_test \
      --test_filter='RuntimeTest.DestroyingOneMajorSlotKeepsOtherMajorSlotOccupied'
  bazel test //score/socom/test/unit:socom_test \
      --test_filter='RuntimeTest.DestroyingOneInstanceSlotKeepsOtherInstanceSlotOccupied'
  bazel test //score/socom/test/unit:socom_test \
      --test_filter='RuntimeTest.DestroyingOneServiceIdSlotKeepsOtherServiceIdSlotOccupied'
  ```

  Expected on the corrected key: while the owning connector is alive each duplicate attempt returns
  `Construction_error::duplicate_service`, and after destruction the freed slot is re-constructible
  while unrelated major/instance/service-id slots stay occupied. These expectations are
  source-derived, not measured.

---

## 6. Obligations status (none satisfied)

### 6.1 Pinned state from `authority.json`

| Field | Value |
|-------|-------|
| `codeql_scope` | Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload |
| `engineering_acceptance` | **pending** |
| `human_reviews` | **unanswered** |
| `safety_class` | **unknown** |
| `instruction` | "Restart the failed queue for one complete pass through all obligations" |

All nine pinned sources in `.llm_tmp/context/obligations/` were read this iteration (§1.6); every
`source-index.json` entry is `"native_acceptance": "not_inferred"`.

### 6.2 Obligation status for this slice (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Freedom from compiler warnings & errors (100 %) | `verification_plan.rst` (criterion 9, `:332-335`) | **PARTIALLY MEASURED (scoped)** — the focused identifier TU compiled with `g++-12 … -Werror`, exit 0, empty stderr in both legs (§1.5/§2.3); `runtime_tests.cpp` and the full `socom_test`/`//score/...` targets are **not** compiled; not a full native result |
| Static code analysis (clang-tidy / CodeQL), findings classified | `code_analysis.rst`; `verification_process.rst` (`gd_req__verification_sca_classification`, `:228-248`) | **NOT PERFORMED here** — no tool, no build this iteration; a prior clang-tidy attempt was blocked on configuration; CodeQL MISRA applicability unestablished (draft mapping) |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` (`:status: draft`) | **UNKNOWN** — mapping is draft; not applied |
| Structural statement / branch coverage goals | `verification_plan.rst` (criteria 1-2, `:300-307`) | **NOT MEASURED by this slice's check** — `check_unit_matrix` ran tests only and reported no coverage |
| Unit/component testing executed, results recorded | `verification_plan.rst` (criteria 6-7); `verification_guideline.rst` | **PARTIALLY MEASURED (scoped)** — 87 identifier tests executed 87/0 (candidate) and 87/30 (baseline); `runtime_tests.cpp` and the lifetime cases are **not executed** |
| Interface / requirements-based / resource / fault-injection test types | `verification_process.rst`; `verification_plan.rst` | **NOT PERFORMED / applicability not inferred** — no harness; identifier/runtime-key tests must not be labelled platform validation |
| Boundary / equivalence derivation | `verification_process.rst` (`:43-50`) | **SOURCE-ONLY for the lifetime cases**; the key-level boundary/equivalence cases *were* executed by the host check (§1.5) |
| Fuzzy testing technique | `verification_process.rst`; `verification_plan.rst` | **NOT EXECUTED / NOT CLAIMED** — no harness and no measurement |
| Linking tests to requirements (record properties) | `verification_process.rst` (`gd_req__verification_link_tests_cpp`, `:56-75`) | **PARTIAL / NOT DONE** — `DerivationTechnique`/`Description` are recorded in the sources; `TestType` and the `Verifies` links are deliberately unset (no invented identifiers) |
| External-component AoUs verified | `verification_process.rst` (`gd_req__verification_external_aou`, `:214-226`) | **NOT SATISFIED** — no integration test or static-analysis verdict; no AoU register |
| Independence of verification / review by a different committer | `verification_process.rst` (`gd_req__verification_independence`, `:141-152`) | **NOT DONE** — human reviews unanswered |
| Implementation inspection checklist IMPL_01…IMPL_03 | `inspection_checklist.rst` (`:status: draft`) | **NOT FILLED** — draft template, no inspection |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** for this slice; no tool run here |
| Obligation collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **ABSENT in this checkout** — directory not present |
| Native acceptance | `source-index.json` | **`not_inferred` for every entry** |

**Explicit non-satisfaction statement.** Missing tools (only the host hook compiled a focused TU;
this iteration ran no build/test), the unknown safety class and un-inferred applicability, the
incomplete extraction of host artifacts (the check covers only the identifier TU), the absent
obligation-collection results, and the unanswered human reviews mean **none of the checked
obligations may be treated as satisfied**. A collection node that retained results would only show
*retention*, not passing; here the obligation results are not present at all. The presence of a
green focused `check_unit_matrix` helps criterion 9 at the identifier-TU scope only and is **not**
evidence that the runtime lifetime tests, the full suite, or any other obligation passed.

### 6.3 Absence of `.llm_tmp/overnight/obligations/*/result.json`

`glob .llm_tmp/overnight/obligations/**` and `glob **/result.json` return **no entries** this
iteration. The directory is **absent from this checkout**, so there is no collector result to read
and none may be reported as retained or as passed.

---

## 7. Files changed / unchanged (candidate set)

This iteration wrote **only this report**. No candidate source path required a change:

| Candidate path | State | This iteration |
|----------------|-------|----------------|
| `score/socom/impl/service_identifier.hpp` | brace-balanced, nested namespace, documents minor exclusion | **unchanged** (verified, §2) |
| `score/socom/impl/service_identifier.cpp` | `operator<` identity `(instance, id, major)`, minor excluded | **unchanged** (verified, §3) |
| `score/socom/BUILD` | `testonly impl_service_identifier` exposure present | **unchanged** (verified) |
| `score/socom/test/unit/BUILD` | `socom_test` globs `*.cpp`, deps wired | **unchanged** (verified) |
| `score/socom/test/unit/runtime_tests.cpp` | 31 `TEST_F`; five slot-lifetime cases present (§4) | **unchanged** (inspected; already present) |
| `score/socom/test/unit/service_identifier_tests.cpp` | 87-case key matrix present; measured 87/0 candidate | **unchanged** (inspected) |
| `.llm_tmp/overnight/reports/lifetime_tests.md` | **new — this report** | **written** |

No file outside the six candidate paths and this report was written; no `NOTICE`, `LICENSE`, or
`REUSE.toml` file was created, edited, or deleted; all prior reports were preserved.

---

## 8. Notice preservation

- No source, build, test, config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was created, edited, or
  deleted by this iteration; only this report was written.
- All six candidate files carry their Apache-2.0 / notice header unchanged:
  `service_identifier.hpp:1-12`, `service_identifier.cpp:1-12`, `score/socom/BUILD:1-12`,
  `score/socom/test/unit/BUILD:1-12`, `runtime_tests.cpp:1-12`,
  `service_identifier_tests.cpp:1-12`. `SPDX-License-Identifier: Apache-2.0` is present on all six.
- The header the task flagged (`score/socom/impl/service_identifier.hpp`) was inspected and left
  unchanged because it is already brace-balanced and otherwise well-formed (§2).
- Every existing Apache-2.0 / notice header is untouched, and all prior reports under
  `.llm_tmp/overnight/prior-reports/` and the pre-existing `.llm_tmp/overnight/reports/*` were
  preserved (including the same-named `prior-reports/lifetime_tests.md`, which is a different run's
  document and was **not** overwritten).
- This report carries the Apache-2.0 header.
- The duplicate key remains an `impl/`-only type; the `testonly`
  `//score/socom:impl_service_identifier` library exposes it to `//score/socom/test/unit` only, so
  no public header or notice surface changed. No licensed MISRA rule text is reproduced.

---

## 9. Pending human review checklist

- [ ] **Confirm the §2 inspection**: the actual `service_identifier.hpp` is brace-balanced (single
      nested close `}  // namespace score::socom`, line 39 blank) and the focused host compile
      exited 0 under `-Werror` in both legs; the "extra brace at line 39" appears only in earlier
      pre-correction reports. Confirm no source edit is needed, and reconcile the task's "measured"
      wording with the balanced working tree. If the "cancelled draft" is a different revision that
      still carries the extra brace, locate it and authorize its correction; it is not the file in
      this checkout.
- [ ] **Confirm §3**: `minor` is **not** part of the duplicate-server registration key; identity is
      `(instance, service id, major)`; the key persists while the connector is **enabled** and is
      erased only on destruction.
- [ ] **Confirm the slot-lifetime tests in §4** (reuse after destruction with a changed minor
      version, disabled and enabled; destruction isolation across major, instance, and service-id
      slots) are the intended coverage, and decide whether any further runtime variants are wanted.
      Note explicitly that these tests were **not** executed by the host measurement in this
      checkout.
- [ ] **Resolve the instruction conflict**: the task directs correcting the source and drafting new
      tests, while the actual source contains no defect and the requested tests already exist;
      confirm that report-only is the intended outcome here.
- [ ] **Confirm the baseline binding** in §1.2-1.3 (issue #84 ↔ commit `f8a196c3…`).
- [ ] **Run `bazel test //score/socom/test/unit:socom_test`** (and the broader `//score/...` set) on
      the native host to turn the source-derived expectations into measurements — in particular the
      `runtime_tests.cpp` lifetime cases, which no present host artifact covers.
- [ ] **Supply native requirement source IDs and traceability metadata** (no invented links), or
      record applicability as unresolved.
- [ ] **Keep the #84 public `Service_interface_identifier` restructure**, FindService wildcard
      handling, and the config minor-wildcard narrowing out of this bounded slice until separately
      accepted.
- [ ] **Do not treat the identifier-only/registration-key tests as platform validation**; provide a
      fuzz / fault-injection harness and full feature/platform reference-hardware tests separately
      if required.
- [ ] **Supply the missing artifacts** (`.llm_tmp/overnight/obligations/*/result.json`) and resolve
      the `engineering_acceptance: pending` / `human_reviews: unanswered` state; do not infer
      passing from absence.
- [ ] **Resolve the premise discrepancy**: the task's "extra closing brace at line 39" does not
      match this checkout; confirm whether the "cancelled draft" refers to a different revision that
      must be located and corrected elsewhere, or whether the description was simply stale.

---

*End of `lifetime_tests` review draft. Local, unprotected, scoped. No engineering acceptance; human
reviews unanswered; full native runtime tests pending. Every statement is a local reading of the
working tree, a prior report's recorded reading, a host artifact present in this checkout, or an
explicitly-labelled logical consequence — none is acceptance, review approval, publication, or a
full native run.*
