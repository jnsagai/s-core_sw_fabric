<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — registration / teardown concurrency review of the bounded
# duplicate-server registration-key slice (`concurrency_review`)

**Document type:** review draft — actual-source concurrency inspection of the duplicate-server
registration/teardown paths + locking map + assertion audit + proposed tests + obligations status.

**Date:** 2026-10-03
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version handling in
socom* (issue #84). This document reviews **concurrency assumptions, locking, ordering and
assertions across registration and teardown** of that key.
**Run / branch:** `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ`; latest recorded commit `bfd7f7c`
(`fabro(01M3ZRSDK2XQAF1H48VWTPKQNZ): node_53ea467c63349831653e3c69 (success)`), per the run
environment. All completed stages listed for this task returned `success`.
**Verified baseline commit:** `f8a196c3b16d5172d898394ab99b0ed81346d63d`
(`.llm_tmp/context/source-manifest.json:3`).
**Status:** **local, unprotected, scoped.** No engineering acceptance exists. Human reviews are
**unanswered**. Full native runtime tests remain **pending**. Every statement below is either a
direct static reading of this checkout, a reading of a retained host artifact present in this
checkout, or an explicitly-labelled logical consequence or proposal. Nothing here is compiled by
this iteration, executed, reviewed, accepted, published, or a full native run. **This is a review
draft and proposes tests; it does not claim safety acceptance.**

> **Tool / write boundary observed.** Only `read_file`, `grep`, `glob`, and `write_file` were
> available and were the only tools used. No `shell`, no delegation, no web access, no approval, no
> publishing, no engineering acceptance, and no `edit_file` was performed. The task's explicit final
> sentence — *"This is a review draft: only that report may be written."* — is the operative write
> boundary. **Exactly one file was written: this report**
> (`/workspace/.llm_tmp/overnight/reports/concurrency_review.md`). No source, build, test, config,
> `NOTICE`, `LICENSE`, or `REUSE.toml` file was created, edited, or deleted, and every prior report
> was preserved unchanged.
>
> **Premise reconciliation — the recorded syntax failure is not in this checkout, so no source edit
> was made.** The task records *"a measured GCC syntax failure: an extra closing brace in
> `score/socom/impl/service_identifier.hpp` at line 39"* and directs that the actual source be
> inspected and corrected before expanding tests. Direct inspection of the *actual* file this
> iteration (§2) shows exactly two opening braces (`:19`, `:29`) and two closing braces (`:32`,
> `:38`), net balance `0`; `:39` is **blank** and `:40` is `#endif`. A `glob` for
> `**/service_identifier.hpp` returns exactly one path, so there is no second, differently-braced
> copy. The retained host capture in this checkout compiles two translation units that include that
> header transitively (`score/socom/impl/service_identifier.cpp` and
> `score/socom/test/unit/service_identifier_tests.cpp`) with `-Wall -Wextra -Werror` and exits `0`
> (`.llm_tmp/overnight/validation/after-compile.command.json` `exit_code: 0`), which is incompatible
> with an unparsable header. Because (a) the write boundary permits only a report this iteration and
> (b) there is no defect in the actual file to correct, **no production source was edited.** The
> minimal historical repair is retained in §2.3 for reference only.
>
> **Non-satisfaction rule applied throughout.** A successful obligation-collection node means
> results were **retained**, not that checks **passed**. Missing tools, unknown applicability,
> incomplete extraction, a draft rule mapping, `--build_tests_only` legs, and unanswered human
> reviews are **not** treated as satisfied. A tool that produced no finding because it did not run is
> recorded as *"not run"*, never as *"clean"*.

---

## 0. Summary

1. **Registration locking is single-lock-at-a-time; no lock-order inversion is visible in the paths
   reviewed (§3, §4).** The duplicate key set has a dedicated mutex (A) distinct from the runtime
   record mutex (B), the connector mutexes (C/Cc), and the bridge mutex (D). This iteration found no
   site that holds one of A/B/C/Cc/D while acquiring another. A is taken only around the key
   `insert`/`erase` (`runtime_impl.cpp:449-454`, `:456-463`); B is taken in the two
   `register_connector` overloads and the record `Final_action`s; D is explicitly released around
   bridge callbacks. This is a static reading, **not** a ThreadSanitizer/lock-order result (§9).
2. **The correctness property behind the single-server assertion is cross-lock, and it survives the
   working-tree key (§4.3).** `Service_record` holds a single `std::optional` server
   (`runtime_impl.hpp:70`) and `register_server_connector` asserts `!m_server`
   (`runtime_impl.cpp:369`) before `m_server.emplace(...)` (`:371`). The duplicate gate (A) is only
   able to serialize this because the key identity `(instance, service id, major)`
   (`service_identifier.cpp:28-29`) now equals the record index identity `(id, major, instance)`,
   which deliberately ignores `minor` (`runtime_impl.hpp:116-134`). On the reported pre-correction
   baseline key (which included `minor`) the gate was finer than the record identity and the assert
   could be reached by a second server; the working-tree key removes that reachability. Preserving
   key/record identity equality is therefore a **concurrency requirement**, not merely an identity
   nicety.
3. **Teardown ordering is correct today but fragile in expression (§5).** `Impl` declares
   `Registration m_registration` (`server_connector_impl.hpp:162`) **before** `Final_action
   m_final_action` (`:163`); member destruction is reverse-declaration, so the key-erasing final
   action is destroyed **before** the server registration. Correctness depends entirely on
   `~Impl(){ disable(); }` (`server_connector_impl.cpp:53`) having already reset `m_registration` in
   the destructor **body** (`:81-85`). Any future path that leaves `m_registration` non-null at member
   destruction would free the key (A) while `Service_record::m_server` (B) is still set, and a new
   connector for the same identity could then reach `ASSERT(!m_server)` on enable.
4. **Teardown carries an inherited lifetime/ordering hazard for an enabled connector that outlives
   its `Runtime` (§5.4).** The server-registration `Final_action` (`runtime_impl.cpp:372-377`)
   captures `this` (`Service_record*`) and locks a `std::mutex&` that lives inside the `Runtime_impl`;
   only the key-erase `Final_action` is protected by a `weak_ptr` (`:456-463`). This is the same
   inconsistency recorded as CE-1 in `lifetime_review.md`; it is re-stated here as an ordering
   hazard, not re-claimed as a new defect.
5. **Several concurrency assumptions are documented in comments but are neither enforced nor
   measured (§6.2).** Enable/disable non-concurrency (`server_connector_impl.cpp:56-60`, `:83-84`),
   exactly one `Connect` per server connector (`:234`), the client weak-token handshake
   (`client_connector_impl.cpp:146-153`, `:177-193`), and `send_all` copy-then-send
   (`server_connector_impl.hpp:167-176`) all rely on caller discipline. Assertion semantics
   (`SCORE_LANGUAGE_FUTURECPP_ASSERT`) are defined in an external dependency and are **not
   established in this checkout**.
6. **Coverage attribution is stale (§6.3).** `runtime_impl.cpp:81-82`, `:101-102`, `:215-216`,
   `:295` cite `RuntimeMultiThreadingTest` cases that do **not exist** in the tree; the real
   concurrency suite is the separate `//score/socom/test/stress:socom_stress_test`.
7. **No retained artifact runs the runtime or stress suites (§7, §9).** The newest host check
   (`check_conversion_tests`, UBSan, `check-result` `0`) compiles/executes only the focused identifier
   translation unit (91 `ServiceInstanceIdentifierTest` cases, candidate 91/0, baseline 91/33).
   `native_tests` and `native_tsan` run Bazel with `--build_tests_only` (they **build** targets, they
   do not **run** tests); `focused_tsan` is `findings_or_execution_failure` (compile exit 0, tests
   exit 66). `runtime_tests.cpp` (31 `TEST_F` + 1 `TEST` + 1 `TEST_P`) is single-threaded and is not
   executed by any retained artifact.
8. **No obligation is satisfied (§9).** All nine `source-index.json` entries are
   `native_acceptance: not_inferred`; `authority.json` records `engineering_acceptance: pending`,
   `human_reviews: unanswered`, `safety_class: unknown`. Of the 25 retained obligation results, 12 are
   `findings_or_execution_failure` and 3 are `completed_with_blockers`. Retention is not passing.

---

## 1. Binding: issue, baseline, candidate set, prior work, host feedback

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` | `.llm_tmp/context/issue-snapshot.json:2-4` |
| Title | *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:3` |
| State | `open`, 0 comments, no milestone / assignee / labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` | `.llm_tmp/context/issue-snapshot.json:19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**: service-instance identifier `service id + major + minor + instance id`; service
identifier `service id + major`; FindService `service id + major + optional<minor> +
optional<instance>`; and the proposal to "exclude the minor version and make it a property of the
service instance". No comment and no acceptance record exists in the snapshot, so none of it is
binding. Binding is **by baseline commit**, not by run HEAD.

### 1.2 Verified baseline and candidate set

| Item | Value | Source |
|------|-------|--------|
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |
| Current branch | `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ` | run environment |
| Latest recorded commit | `bfd7f7c` | run environment |

| Candidate file | Baseline git blob | Baseline present | This iteration |
|----------------|-------------------|------------------|----------------|
| `score/socom/BUILD` | `3477ea08…` | yes | inspected; unchanged |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e…` | yes | `operator<` identity `(instance, id, major)`, `minor` excluded (`:28-29`) |
| `score/socom/impl/service_identifier.hpp` | `c8bae790…` | yes | brace-balanced, 40 lines, `:39` blank (§2) |
| `score/socom/test/unit/BUILD` | `3c03a7b1…` | yes | `socom_test` globs `*.cpp`, deps wired |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab7…` | yes | 31 `TEST_F` + 1 `TEST` + 1 `TEST_P`; single-threaded |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(none — `null`)* | **no** (a new file) | 91 `TEST_F` under `ServiceInstanceIdentifierTest` |

Source: `.llm_tmp/context/candidate-files.json:1-25`. The `null` baseline blob for
`service_identifier_tests.cpp` is the manifest's expectation of a **new** unit-test file; it exists
on disk only in the un-merged working tree (the task's "cancelled draft"), never in the baseline.
The **concurrency sources reviewed below (`impl/runtime_impl.{hpp,cpp}`,
`impl/server_connector_impl.{hpp,cpp}`, `impl/client_connector_impl.{hpp,cpp}`,
`test/stress/*`) are outside the six candidate paths**; they are read as evidence only, and changing
them would need separate authorization.

### 1.3 Prior reports read and preserved

- `.llm_tmp/overnight/reports/` (current run) — read: `scope.md`, `invariants.md`, `key_fix.md`,
  `lifetime_review.md`, `lifetime_tests.md`, `ordering_tests.md`; the remaining files listed by
  `glob` were cross-checked and preserved. This document adds `concurrency_review.md`; nothing was
  overwritten.
- `.llm_tmp/overnight/prior-reports/` (39 files) — read: `concurrency_review.md` (a **different
  run's** document, run `01M3YRJEGXNY6CB81T7TKW774B`, whose RCC-1…RCC-6, AS-1…AS-6 and proposed
  tests this document re-verifies and carries forward), plus `lifetime_review.md`, `invariants.md`,
  `key_fix.md`, `lifetime_tests.md`, `runtime_disabled.md`, `runtime_enabled.md`, `callsites.md`.
  All 39 files are preserved.

Derived sequence across the preserved reports (all on baseline `f8a196c3…`): `scope` (bounded the
slice) → `invariants` (I-4 baseline key included `minor`; I-9 record index ignores it; I-11 the
resulting gap) → `callsites` → `reproducer` (header brace correction) → `key_fix` (drop `minor`) →
`ordering_tests` → `runtime_disabled`/`runtime_enabled`/`lifetime_tests` → `lifetime_review` →
the earlier-run `concurrency_review` and later host-side iterations.

**Reconciliation with the earlier `concurrency_review`.** Its structural findings reproduce here
against the current source (single-lock registration; cross-lock single-server invariant; fragile
reverse member destruction; stale coverage comments; separate stress target). Two corrections are
recorded: (a) at `enable` the key lock A is **not** re-acquired — A-membership is established once at
`make_server_connector` and persists for the connector's life, so the correct statement is "the key
is *held by membership*, and B is the only lock taken at enable" (the earlier phrasing "A is acquired
before the record is touched" over-states it); (b) its identifier-suite count (85 then 87) is now
**91** in this checkout and in the retained capture (§1.5).

### 1.4 Pinned obligation sources and authority (all read this iteration)

All nine entries of `.llm_tmp/context/obligations/source-index.json` were read, together with
`authority.json`. Every entry is pinned `"native_acceptance": "not_inferred"`. Two entries are
`:status: draft` (`misra_mapping`, `inspection_checklist`); the rest are `:status: valid`.

**Authority record** (`.llm_tmp/context/obligations/authority.json`): `engineering_acceptance:
pending`; `human_reviews: unanswered`; `safety_class: unknown`; `codeql_scope: "Public Apache-2.0
eclipse-score/inc_someip_gateway; no upload"`; instruction *"Restart the failed queue for one
complete pass through all obligations"*.

**Safety-class note (recorded, not resolved).** The pinned platform documents carry
`:safety: ASIL_B`, while `authority.json` records `safety_class: unknown` and no authorized selection
exists. The document attribute is **not** a selection of the slice's safety class and must not be
inferred as one.

### 1.5 Host feedback present in this checkout

`.llm_tmp/overnight/validation/` is present. The latest check is **`check_conversion_tests`**:

| Artifact | Content |
|----------|---------|
| `measurement.json` head | `check_ref: "check_conversion_tests"`, `status: "completed"`, `mode: "ubsan"`, `changed_paths: ["score/socom/test/unit/service_identifier_tests.cpp"]` (`:1-7`) |
| `check-result` | `0` |
| `after.json` | `tests: 91`, `failures: 0`, single suite `ServiceInstanceIdentifierTest` (`:1-17`) |
| `before.json` | `tests: 91`, `failures: 33`, same single suite (`:1-17`) |
| `after-compile.command.json` | `g++-12 -std=c++17 -Wall -Wextra -Werror -pthread … -fsanitize=undefined -fno-sanitize-recover=all` over **only** `service_identifier.cpp`, `string_registry.cpp`, `service_identifier_tests.cpp` + googletest; `exit_code: 0` |
| `after-test.stdout` | 91 tests from 1 test suite, all `ServiceInstanceIdentifierTest`; `[ PASSED ] 91 tests` |

**Scope caveat — decisive.** No retained leg compiles or runs `runtime_tests.cpp`, the connector
implementations, or the stress suite. The 91 tests are all `ServiceInstanceIdentifierTest`; no
`RuntimeTest` case appears. The artifact is explicitly `origin: local_unprotected_measurement`,
`initiator: Fabro host hook`, `engineering_acceptance: pending`, `full_native_tests: not_executed`.
It is nevertheless useful corroboration that the flagged header's includers compile under
`-Werror` (§2.2).

### 1.6 Obligation-collection results present in this checkout

`.llm_tmp/overnight/obligations/` contains 25 `matrix` result files. **Per the task rule, a retained
collection result means results were retained, not that checks passed.**

| status | checks |
|--------|--------|
| `completed` | `native_build`, `native_tests`, `native_coverage`, `native_tsan`, `native_sanitizers`, `focused_coverage`, `focused_asan_lsan`, `focused_memcheck`, `compiler_diagnostics`, `rework_progress` |
| `completed_with_blockers` | `tool_assurance`, `cross_compilation`, `process_checks` |
| `findings_or_execution_failure` | `native_integration`, `native_lint`, `focused_cppcheck`, `format_precommit`, `codeql_security`, `focused_clang_tidy`, `native_traceability`, `codeql_misra`, `focused_tsan`, `native_performance`, `secret_dependency_checks`, `native_docs` |

Two scope facts read directly from the commands matter for this review:

- **`native_tests`** runs `bazel --batch test --jobs=2 //... --build_tests_only` with `exit_code: 0`
  (`native_tests/result.json:1054-1082`). `--build_tests_only` **builds** the test targets without
  running them, in a captured `native-workspace` outside this checkout. It is **not** a runtime-suite
  execution.
- **`native_tsan`** runs `bazel --batch test --jobs=2 //score/... //tests/... --build_tests_only
  --features=tsan` with `exit_code: 0`, status `completed` (`native_tsan/result.json:1053-1084`).
  Despite the `tsan` feature, this leg **builds** rather than runs, so it is not a race-detector
  result. **`focused_tsan`** compiles only the focused identifier TU with `-fsanitize=thread`
  (compile `exit_code: 0`) and runs it (`tests` `exit_code: 66`) — status
  `findings_or_execution_failure` (`focused_tsan/result.json:1053-1117`), and its `limits` note reads
  *"Focused identifier executable; full native runtime scope measured separately"*.

Neither leg executes `//score/socom/test/unit:socom_test` or
`//score/socom/test/stress:socom_stress_test`.

---

## 2. The recorded syntax failure: inspection of the actual source

### 2.1 Finding (re-verified this iteration by direct `read_file` + `grep`)

`score/socom/impl/service_identifier.hpp` is **brace-balanced**. It is 40 lines; the only
brace-bearing lines are:

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`) and two closers (`:32`, `:38`): net brace balance `0`. There is **no
third, unmatched closing brace**, and line 39 contains no text at all. The sibling
`score/socom/impl/service_identifier.cpp` uses the same nested form (`:18`/`:32`). A `glob` for
`**/service_identifier.hpp` returns exactly one path, so there is no second, differently-braced copy.
The task's *"extra closing brace … at line 39"* matches a **stale, pre-correction description**; the
`reproducer` iteration applied the single-close correction and it is present in this working tree.

### 2.2 Retained measured corroboration (present, scoped, not acceptance)

`after-compile.command.json` and `before-compile.command.json` each compile
`service_identifier.cpp` / `service_identifier_tests.cpp`, both of which transitively include
`impl/service_identifier.hpp`, with `-Wall -Wextra -Werror`, `exit_code: 0`, and empty stderr. A
translation unit that includes an unparsable header cannot compile under `-Werror`. These captures
are local, unprotected, scoped, and cover the identifier TU only; they corroborate the static reading
but are **not** a full native build.

### 2.3 Minimal historical repair (reference only; NOT applied)

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

Applying it to the already-balanced file would be a no-op; deleting a brace to "fix" it would
*introduce* the reported defect.

### 2.4 Why it matters for this review

The header is compiled into `//score/socom:socom` (its `srcs` glob `impl/**/*.hpp`) and re-exposed to
`//score/socom/test/unit` through the `testonly` `impl_service_identifier` library. A syntax error
would fail the library and the whole `socom_test` target, so no concurrency conclusion could be
worth anything; the balanced state removes that blocker at the source level. **No source was
edited.**

---

## 3. Registration ordering

All line references are direct readings of this working tree.

### 3.1 `Runtime_impl::make_server_connector` (`runtime_impl.cpp:440-467`)

1. `Service_instance_identifier const identifier{configuration.get_interface(), instance};`
   (`:443`). Building the identifier interns the service id and instance id in the process-wide
   registries (`String_registry`, each under its own mutex R) — R is released before step 3.
2. Callback validation (`:445-447`) — no lock; returns `callback_missing` **before** touching the key.
3. **Lock A** (`m_service_identifiers->mutex`): `insert(identifier)`; on `false` return
   `duplicate_service`; A is released at end of scope (`:449-454`).
4. Build the key-erasing `Final_action` capturing `identifier` by value and a `weak_ptr` to the key
   set (`:456-463`).
5. Construct `SC_impl` and move the `Final_action` in; return (`:465-466`).

Static readings of the registration path:

- **RC-1 — the duplicate check is atomic.** The only two mutations of the key set are the `insert`
  (`:451`) and the `erase` (`:460-461`), both under A. There is no read-then-write window, so for two
  concurrent `make_server_connector` calls on the same identity **exactly one** `insert` returns
  `true`. This is a `std::set`/mutex consequence, not an observed result.
- **RC-2 — no lock is held across user-visible work.** A is released before `SC_impl` is constructed
  and before any callback. R is released before A is taken.
- **RC-3 — the key is reserved before the connector exists.** A second construction for the same slot
  is refused even while the first connector is still being built. This is intentional: the key is
  described as tracking "any (Disabled, Enabled) Server_connector"
  (`impl/service_identifier.hpp:23-24`).
- **RC-4 — `m_service_identifiers` is read without A.** The `shared_ptr` member
  (`runtime_impl.hpp:228-229`) is initialized at construction and never reassigned, so concurrent
  reads are safe *provided* the `Runtime_impl` is published before threads use it (the factory
  contract). This is an assumption, not enforced locally.
- **RC-5 — the failed-insert path does not leak a key.** `is_valid` runs before the insert
  (`:445` then `:449`), so `callback_missing` leaves no key behind. If `SC_impl` construction threw,
  the function is `noexcept` and would terminate (no unwinding guarantee).

### 3.2 `Impl::enable` → `Runtime_impl::register_connector`
(`server_connector_impl.cpp:55-78`; `runtime_impl.cpp:526-551`)

1. Reset the promises and create `m_stop_block_token` / `m_all_clients_disconnected_block_token`
   (`:66-71`) — **no lock**.
2. `m_runtime.register_connector(interface, instance, Listen_endpoint{*this, m_stop_block_token})`
   (`:72-73`). Inside: **Lock B** (`m_runtime_mutex`) → `get_record` (`runtime_impl.cpp:530`,
   `:313-324`) → `register_server_connector` (`:531`, `:366-382`): assert `!m_server` (`:369`),
   `m_server.emplace(...)` (`:371`), build the record-unregistering `Final_action` (`:372-377`);
   B is released (`:532`); then, if a client is present, `connect_client(...)` runs **outside B**
   (`:534-548`).
3. `SCORE_LANGUAGE_FUTURECPP_ASSERT(m_registration != nullptr)` (`:75`); assign `m_registration`
   (`:72`).

- **RC-6 — `assert(!m_server)` and `m_server.emplace` are atomic under B.** There is no window
  between the check and the write for a competing holder of B.
- **RC-7 — the assert's precondition is supplied by A-membership, not by B.** Only one connector can
  hold the key for a record (RC-1), and membership persists from `make_server_connector` until the
  connector is destroyed, so no second server can reach `register_server_connector` for the same
  record in between. This holds **because key identity == record identity** (`minor` is excluded
  from both; `service_identifier.cpp:28-29`, `runtime_impl.hpp:116-134`). This is the cross-lock
  invariant of §4.3.
- **RC-8 — `connect_client` runs outside B.** The copied `Interfaced_client` keeps the
  `Server_indication` alive; the client-side lambda re-checks its own weak stop token
  (`client_connector_impl.cpp:146-153`) before use. This avoids an obvious lock-order hazard, but the
  token check is only weakly synchronized with the client destructor (§6.2, AS-3).

---

## 4. Locking map and ordering

### 4.1 Locks in scope

| Id | Lock | Site | Guards | Held across user callback? |
|----|------|------|--------|----------------------------|
| A | key mutex (`Mutexed_variable::mutex`) | `runtime_impl.hpp:50-56`, `:228-229`; used `runtime_impl.cpp:450`, `:460` | duplicate-server key `std::set` | no |
| B | `Runtime_impl::m_runtime_mutex` | `runtime_impl.hpp:220-221`, `:136`, `:94`; used `runtime_impl.cpp:495`, `:529`, `:374`, `:392` | `Service_database` records + server/client optionals | no (released before `connect_client`) |
| C | `server_connector::Impl::m_mutex` | `server_connector_impl.hpp:153`; used `server_connector_impl.cpp:87,123,146,163,181,203,219,226,295,344` | subscriber/update-requester/event tables, `m_client`, tokens | no (released before callbacks) |
| Cc | `client_connector::Impl::m_mutex` | `client_connector_impl.hpp:95`; used `:104`, `:111`, `:178`, `:196`, `:39` | `m_server`, `m_registration`, `m_stop_block_token` | no |
| D | `Runtime_impl::m_bridge_mutex` | `runtime_impl.hpp:223`; used `runtime_impl.cpp:483,554,583,591,598` | bridge maps | no (`register_bridge`/`get_bridge_requests` explicitly unlock around callbacks, `:181-192`, `:285-287`) |
| R | `String_registry` mutex (per registry) | `string_registry.cpp` | process-wide id registries | no |

### 4.2 Ordering / nesting

This iteration found **no site that holds one of A/B/C/Cc/D while acquiring another**:

- A is taken only in `make_server_connector` (`:450`) and its `Final_action` (`:460`); neither
  touches B/C/Cc/D.
- B is taken in the two `register_connector` overloads and the two record `Final_action`s; none of
  those acquires A/C/Cc/D while holding B. `connect_client` (which can re-enter the runtime) runs
  **after** `lock.unlock()` (`:532`).
- C/Cc are taken inside the connector `Impl`s and released before any user callback.
- D is taken in `register_bridge` / `stop_registration` / `get_bridge_reported_instances` and is
  explicitly unlocked around bridge callbacks.

**RCC-1 (static):** lock-order inversion among A/B/C/Cc/D is not reachable through the sites
reviewed. This is **not** a ThreadSanitizer or lock-order-inversion tool result (§9), and a global
claim would require the full native concurrency run.

**RCC-2 (static):** the registration/teardown ordering — not the lock order — is the real invariant:
the key is reserved (A-membership) **before** the record is touched (B) and released **after** the
record is unregistered. Because A and B are never held together, a lock-order tool would not see
this; it must be preserved by construction (§5).

### 4.3 The cross-lock single-server invariant

`Service_record` holds a single `std::optional` server (`runtime_impl.hpp:70,95`) and
`register_server_connector` asserts `!m_server` (`runtime_impl.cpp:369`). The gate that keeps this
true is A-membership (server connectors only), while B protects the record itself:

> For every record, at most one live server connector exists at any instant, and it holds the key
> for that record's identity; therefore no second `register_server_connector` for the same record
> can run while it is held.

This is preserved because key identity == record identity (RC-7). If the key were finer than the
record identity (the reported baseline, whose key included `minor`), A would not serialize the two
registrations and the assert would be reachable. Preserving key/record identity equality is
therefore a **concurrency requirement** of this slice. The working-tree key
(`service_identifier.cpp:28-29`) satisfies it; the public `Service_interface_identifier` and the
minor-compatibility rules are separate and unchanged.

---

## 5. Teardown ordering

### 5.1 `~Impl` → `disable` (`server_connector_impl.cpp:53`, `:80-114`)

1. `disable()`: if `m_registration != nullptr`, `m_registration.reset()` (`:81-85`). For the server
   path the registration is the `Final_action_registration` built at `runtime_impl.cpp:379-381`; its
   `Final_action` (`:372-377`) takes **B** and resets `m_server`.
2. Under **C**: reset `m_stop_block_token`, `m_all_clients_disconnected_block_token`,
   `unsubscribe_event()` (`:86-91`).
3. `m_stop_complete_promise.get_future().wait()` (`:106`) — waits for the stop handshake.
4. `send_all(Service_state_change{not_available, …})` (`:109`) — copies `m_client` under C, unlocks,
   then sends (`server_connector_impl.hpp:167-176`).
5. `m_all_clients_disconnected_promise.get_future().wait()` (`:110`).
6. `assert(m_registration == nullptr)` (`:112`).
7. Destructor body ends; members are destroyed in reverse declaration order
   (`server_connector_impl.hpp:146-164`): `m_credentials`, **`m_final_action`** (key erase under A),
   **`m_registration`** (already null), `m_client`, tables, tokens, promises, `m_mutex`, …,
   `m_runtime`.

### 5.2 Ordering claims (static)

- **RCC-3 (correct today):** because `disable()` runs in the destructor *body* and resets
  `m_registration`, the server is unregistered under B **before** the key is erased under A. A new
  `make_server_connector` for the same slot must take A, and A can only be released by the
  key-erasing `Final_action`; therefore the new connector can only be constructed **after** the old
  record's `m_server` is cleared. This closes the registration/teardown ordering.
- **RCC-4 (fragile expression):** the member declaration order is the **reverse** of the intended
  execution order (`m_registration` declared before `m_final_action`,
  `server_connector_impl.hpp:162-163`). Correctness depends entirely on step 1. If a future refactor
  ever destroyed an enabled `Impl` without `disable()` clearing `m_registration`, the key would be
  released while `m_server` is still set, and the next enable for that record would reach
  `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)`. This mirrors `lifetime_review.md` CE-4. Recommended
  hardening (proposed, **not applied**): declare `m_final_action` **before** `m_registration`, or
  otherwise assert/express the erase-after-unregister order.
- **RCC-5 (disabled connector):** if `m_registration` is null, `disable()` is a no-op and only the
  key erase runs. Fine.
- **RCC-6 (runtime destroyed first):** the key's `weak_ptr` guard (`runtime_impl.cpp:456-463`) skips
  the erase if the runtime is gone. The key erase then touches no lock. This is also the guard that
  makes the disabled `ConnectorDestroyedAfterRuntimeDoesNotCrash` case a no-op (§5.4).

### 5.3 `send_all` and the client lock

`send_all` copies `m_client` under C, unlocks, and dereferences the copy
(`server_connector_impl.hpp:167-176`); the client side mirrors this with `lock_server`, copying
`m_server` under Cc and unlocking before sending (`client_connector_impl.hpp:103-113`). Safety of the
dereference depends on the disable handshake (§5.1, steps 3-5) having serialized client teardown; it
is not independently protected. Recorded as AS-4.

### 5.4 Inherited lifetime/ordering hazard: enabled connector outliving its `Runtime`

The server-registration `Final_action` captures `this` (the `Service_record*`, which lives inside
`Runtime_impl::m_database`) and captures/reference-locks `Service_record::m_runtime_mutex`, itself a
reference to `Runtime_impl::m_runtime_mutex` (`runtime_impl.hpp:94`; `runtime_impl.cpp:364-377`).
Only the key-erase `Final_action` uses a `weak_ptr` guard (`:456-463`). Therefore, if an **enabled**
connector's destructor runs after the `Runtime` (and its database and mutex) is destroyed, the
`m_registration.reset()` in `disable()` reaches stale storage. The drafted
`ConnectorDestroyedAfterRuntimeDoesNotCrash` (`runtime_tests.cpp:1021-1028`) only ever creates a
**disabled** connector, so it exercises the key `weak_ptr` no-op, not this path. This is the same
inconsistency recorded as CE-1 in `lifetime_review.md`; it is re-stated here as a
registration/teardown ordering hazard and is **not** re-claimed as an independently verified defect.
It has **not** been executed in this checkout. A concrete two-line counterexample is in
`lifetime_review.md` §5.1.

---

## 6. Assertions and un-enforced concurrency assumptions

### 6.1 Assertion audit (concurrency-relevant)

| Assertion | Site | Lock | What would violate it |
|-----------|------|------|-----------------------|
| `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)` | `runtime_impl.cpp:369` | B (caller) | two servers for one record (the gate must stay ≥ record identity, §4.3) |
| `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_client.has_value())` | `server_connector_impl.cpp:234` | C | a second `Connect` to one server connector |
| `SCORE_LANGUAGE_FUTURECPP_ASSERT(m_registration != nullptr)` | `server_connector_impl.cpp:75` | none | enable/disable called concurrently or out of contract |
| `SCORE_LANGUAGE_FUTURECPP_ASSERT(m_registration == nullptr)` | `server_connector_impl.cpp:112` | none | enable/disable called concurrently or out of contract |
| `SCORE_LANGUAGE_FUTURECPP_ASSERT(is_interface_compatible(...))` | `runtime_impl.cpp:508`, `:536` | none (after B unlock) | defensive; record narrowing should make it unreachable |
| `SCORE_LANGUAGE_FUTURECPP_ASSERT(id < m_subscriber.size())` etc. | `server_connector_impl.cpp:121,144,161,179,199-201,292-293,342` | C (mostly) | table/id mismatch |
| `SCORE_LANGUAGE_FUTURECPP_ASSERT(bridge_lock.owns_lock())` | `runtime_impl.cpp:170,225,258` | D | internal lock-state protocol |
| `SCORE_LANGUAGE_FUTURECPP_ASSERT(m_registration)` | `client_connector_impl.cpp:174` | none | `set_registration` after a failed register |

**Assertion semantics are external.** Whether `SCORE_LANGUAGE_FUTURECPP_ASSERT` terminates, logs, or
is compiled out is defined in the external `score_baselibs` / `futurecpp` dependency and is **not
established in this checkout** (the pinned obligation sources do not settle it and the tool tree is
outside this workspace). Where it does not terminate, the code after a violated assert (e.g.
`m_server.emplace`) silently replaces or corrupts state. This matters for §4.3 and RCC-4 and is
recorded as unknown.

### 6.2 Assumptions documented but not enforced

- **AS-1 — enable/disable are not concurrent.** The in-source comments
  (`server_connector_impl.cpp:56-60`, `:83-84`) justify the unlocked `m_registration` accesses by the
  API's `unique_ptr` type conversion. Nothing enforces it; two threads invoking `enable`/`disable` on
  the same object would race on `m_registration` and the promises. The public headers
  (`score/socom/server_connector.hpp`, `runtime.hpp`) state **no** thread-safety contract for
  concurrent `make_server_connector`/`enable`/`disable` calls.
- **AS-2 — exactly one `Connect` per server connector.** `receive(message::Connect)`
  (`server_connector_impl.cpp:225-248`) asserts `!m_client` and emplaces under C; the comment says it
  "should have been checked already in Runtime" (`:233`). The effective guard is the client-side
  single-client rule (`register_client_connector` → `duplicate_client`,
  `runtime_impl.cpp:386-388`). If a client endpoint were delivered twice, the assert is the only
  guard.
- **AS-3 — weak-token handshake for client destruction.** The client connect lambda checks
  `weak_stop_token.lock()` (`client_connector_impl.cpp:146-153`) and
  `set_id_mappings_and_server` re-checks `m_stop_block_token` under Cc (`:177-193`). The source
  comments themselves call this "non deterministic behavior of thread scheduling" and exclude the
  false branches from coverage (`:163-165`, `:182-186`). A residual window remains where the lock
  succeeds just before the destructor resets the token.
- **AS-4 — `send_all` / `lock_server` copy-then-send.** `send_all` copies `m_client` under C,
  unlocks, then dereferences (`server_connector_impl.hpp:167-176`); `lock_server` copies `m_server`
  under Cc, unlocks, then dereferences (`client_connector_impl.hpp:103-113`). Safety depends on the
  disable handshake (§5.1) having serialized peer teardown; it is not independently protected.
- **AS-5 — `m_service_identifiers` publication.** Read without A (RC-4). Safe only under the factory
  publication contract; never reassigned after construction.
- **AS-6 — failed insert never leaks; failed construct is `noexcept`-terminate.**
  `runtime_impl.cpp:445` then `:449` ordering means `callback_missing` does not leak a key;
  `make_server_connector` is `noexcept`, so a throwing `SC_impl` constructor would terminate (no
  unwinding guarantee). Recorded, not a defect claim.

### 6.3 Stale coverage attribution (concrete, static)

`runtime_impl.cpp` cites non-existent tests as coverage for its race-prone branches:

- `:81-82` and `:215-216` — `// Sporadically covered by TEST_F(RuntimeMultiThreadingTest,
  BridgesAndSubscribeFindServiceHaveNoRaceConditions)`
- `:101-102` — `// Sporadically covered by TEST_F(RuntimeMultiThreadingTest,
  CreationOfMultipleServerAndClientConnectorsHasNoRaceCondition)`
- `:295` — `// TEST_F(RuntimeMultiThreadingTest, BridgesAndSubscribeFindServiceHaveNoRaceConditions)`

A `grep` over `/workspace` finds these names **only in those comments**; no such `TEST_F` exists. The
current `RuntimeMultiThreadingTest` (`test/stress/runtime_multi_threading_tests.cpp:141,150,160,191`)
contains `CreationOfServerAndClientConnectorsHasNoRaceCondition`,
`CreationOfServerAndClientConnectorsCallsCallbacksInCorrectOrder`,
`BridgesWhichCreateServerConnectorsAndClientConnectorsHaveNoRaceCondition`, and
`BridgesAndClientConnectorsHaveNoRaceCondition` — a different set. The comments therefore assert
coverage that the suite does not provide.

---

## 7. Existing concurrency suite, the in-scope runtime suite, and their strength

### 7.1 The in-scope unit suite is single-threaded

`score/socom/test/unit/runtime_tests.cpp` contains **31 `TEST_F`** (`:279, :287, :295, :303, :311,
:334, :350, :371, :402, :440, :471, :505, :538, :573, :607, :642, :694, :726, :763, :796, :832, :869,
:905, :951, :986, :1021, :1045, :1091, :1141, :1197, :1253`), **1 `TEST`**
(`RuntimeFactoryTest.DefaultConstructorWorks`, `:239`) and **1 `TEST_P`**
(`RuntimeBridgeTest.CreationOfClientsWillCallRequestServiceFunction`, `:1311`). A `grep` for
`thread|Thread|mutex|Mutex|concurren|Concurrent` over the file returns **nothing**: every case is
single-threaded. The duplicate/teardown cases therefore pin *identity* and *single-threaded slot
reuse* only; they cannot exercise any interleaving in §4-§6. Metadata is recorded by
`record_registration_key_metadata` (`:264-267`: `DerivationTechnique =
"design-analysis,equivalence-classes"` + a `Description`); `TestType` and the `Verifies` links are
deliberately unset.

### 7.2 The real concurrency suite is a separate target

`score/socom/test/stress/` holds three files with **14 `TEST_F`** total:

- `runtime_multi_threading_tests.cpp` — 4 `TEST_F` (`:141, :150, :160, :191`).
- `client_multi_threading_tests.cpp` — 5 `TEST_F` (`:42, :59, :65, :86, :97`).
- `connection_multi_threading_tests.cpp` — 5 `TEST_F` (`:131, :151, :169, :188, :203`).

They build as `//score/socom/test/stress:socom_stress_test` (`test/stress/BUILD:16-31`):
`tags = ["component"]`, `data = ["tsan.supp"]`, `env = {"TSAN_OPTIONS":
"suppressions=$(location tsan.supp)"}`. This target is **not** part of `socom_test`
(`test/unit/BUILD` `srcs = glob(["*.cpp"])` over the unit directory only). Additionally
`test/unit/multi_connection_tests.cpp` exists in the unit target. No retained artifact in this
checkout runs the stress target (§9).

### 7.3 Strength limitation of the template (static)

`multi_threaded_test_template` (`test/framework/src/multi_threaded_test_template.cpp:61-88`) runs
each loop thread under
`Or_stop{Timeout{now + 5s}, And_stop{Num_iterations{100}, caller_stop_condition}}`. Two consequences:

- The loop terminates on the 5 s timeout **regardless of** `caller_stop_condition`; and
- the template never asserts that `caller_stop_condition` was ever satisfied.

A stress case can therefore pass without the intended interleaving or condition ever holding. This is
an observation about test strength, not a defect claim; any new stress proposal must assert its own
success counts inside the loop (see §8).

---

## 8. Proposed tests (proposals only — none written, none run, no safety acceptance)

These are **proposals** for authorized follow-up work. The unit-level ones can be added to the
in-scope candidate `score/socom/test/unit/runtime_tests.cpp`; additions to the out-of-candidate
`test/stress/` suite need separate authorization. **None was compiled or executed here, and none is
a safety-acceptance claim.**

### 8.1 Registration-race tests (unit, `RuntimeTest`)

1. **`ConcurrentDuplicateRegistrationsHaveExactlyOneWinner`** — spawn N threads that each call
   `runtime->make_server_connector(configuration, instance, callbacks_i)` for the same identity;
   join and assert exactly one result `has_value()` and N-1 equal
   `MakeUnexpected(Construction_error::duplicate_service)`. Detects a read-then-write (TOCTOU) in the
   A-protected insert (RC-1) or a missing lock.
2. **`ConcurrentDuplicateRegistrationsThenEnableWinner`** — as (1), then
   `Disabled_server_connector::enable` the winner. A second valid connector reaching enable would
   violate `ASSERT(!m_server)`; the test would terminate rather than return, so it doubles as the
   guard for RC-7/RCC-3 under concurrency.
3. **`ConcurrentDistinctKeysAllSucceed`** — N threads register N distinct
   `(instance, service id, major)` identities; assert all succeed and all subsequent duplicates are
   refused (i.e. the key set holds exactly N members). Detects false collisions from a
   mis-synchronized comparator.

### 8.2 Teardown-race tests (unit, `RuntimeTest`)

4. **`ConcurrentMakeAndDestroySameSlotConvergesToFreeSlot`** — one thread loops
   `make_server_connector` + immediate destroy for a fixed identity while another does the same for a
   *different* identity; join, then assert a fresh registration for the first identity succeeds.
   Detects a key leaked by a failed concurrent construct/destroy and exercises RCC-3 under
   interleaving.
5. **`ConcurrentEnableAndDestroyDifferentSlotsIsRaceFree`** — two threads each
   make → enable → destroy a distinct slot; assert both complete without termination. Exercises the
   B-vs-A teardown ordering for independent records.

### 8.3 Lifetime/ordering regression proposals (unit, `RuntimeTest`)

6. **`EnabledConnectorOutlivesRuntimeIsNotUseAfterFree`** — the enabled-state counterpart of
   `ConnectorDestroyedAfterRuntimeDoesNotCrash` (`runtime_tests.cpp:1021-1028`). Construct a runtime,
   create and **enable** a connector, destroy the runtime, then destroy the connector. This is the
   regression for §5.4 / CE-1; whether the intended contract forbids this shape must be decided by a
   human first (see §11).
7. **`ReEnableReplacementAfterEnabledSlotReuse`** — extend the existing "enabled destroy then
   replacement" cases (`runtime_tests.cpp:986-1019`, `:1091-1134`, which today only *construct* the
   replacement) to actually call `Disabled_server_connector::enable()` on the replacement. This
   exercises `Service_record::m_server` reset and `ASSERT(!m_server)`, which `lifetime_review.md`
   CE-2/CE-3 records as unobserved.

### 8.4 Stress / TSAN proposals (out-of-candidate; authorization required)

8. **`ConcurrentServerConnectorRegistrationStress`** in
   `test/stress/runtime_multi_threading_tests.cpp`, using `multi_threaded_test_template`, with the
   caller stop condition requiring **at least one success and one duplicate per iteration** (to work
   around the §7.3 strength limitation). It only has evidential value under the stress target's TSAN
   configuration (`test/stress/BUILD:20-23`).
9. **`ConcurrentServerAndClientConnectorLifetimeStress`** — overlapping client connect/disconnect and
   server enable/disable on matching identities, to exercise AS-3/AS-4 under TSAN.

### 8.5 Hardening proposals (source; not applied; authorization required)

- Declare `m_final_action` **before** `m_registration` in `server_connector_impl.hpp:162-163`, or
  otherwise assert/express that the key erase must follow server unregister (RCC-4).
- Add a guard in `remove_client()` (`server_connector_impl.cpp:217-223`) that `m_client` is engaged
  before `unsubscribe_event(*m_client)` (AS-2/AS-4 robustness).
- Document the single-threaded-per-connector contract (AS-1) in
  `score/socom/server_connector.hpp` / `runtime.hpp`, since the code relies on it.
- Remove or re-point the stale coverage comments in `runtime_impl.cpp:81-82`, `:101-102`, `:215-216`,
  `:295` so coverage attribution matches existing tests.

---

## 9. Obligations and measurement status (none satisfied)

### 9.1 Pinned state

All nine pinned sources in `.llm_tmp/context/obligations/` were read (§1.4); every
`source-index.json` entry is `"native_acceptance": "not_inferred"`. `authority.json` records
`engineering_acceptance: pending`, `human_reviews: unanswered`, `safety_class: unknown`,
`codeql_scope` no-upload, and the instruction to restart the failed obligation queue.

### 9.2 Status for this slice (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Freedom from compiler warnings & errors (100 %) | `verification_plan.rst` (criterion 9) | **PARTIAL, SCOPED** — the focused identifier TU (incl. the flagged header) compiled `g++-12 … -Werror` (UBSan), exit 0; `runtime_impl.cpp`, `server_connector_impl.cpp`, `runtime_tests.cpp` and the stress target are **not** compiled/run by any artifact that runs tests; `native_tests` only *built* `//...` (`--build_tests_only`) in an external workspace |
| Static code analysis (clang-tidy / CodeQL), findings classified | `code_analysis.rst`; `verification_process.rst` (`gd_req__verification_sca_classification`) | **NOT SATISFIED** — `focused_clang_tidy`, `codeql_security`, `codeql_misra`, `native_lint` are `findings_or_execution_failure`; MISRA mapping is `:status: draft`; no authorized classification |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` (`:status: draft`) | **UNKNOWN — NOT CLAIMED** |
| Structural statement / branch coverage goals | `verification_plan.rst` (criteria 1-2) | **NOT MEASURED for the slice** — `focused_coverage` status `completed` but scoped to the identifier TU; `native_coverage` only built tests |
| Unit/component testing executed, results recorded | `verification_plan.rst` (criteria 6-7); `verification_guideline.rst` | **PARTIAL, SCOPED** — 91 identifier tests, 0 failures (33 baseline failures) in this checkout; `runtime_tests.cpp` (33 macros) and the 14 stress `TEST_F` **not executed** |
| **Concurrency / race verification (TSAN)** | `code_analysis.rst` (sanitizers); `verification_process.rst` | **NOT SATISFIED** — `focused_tsan` compiled only the identifier TU and its test run exited `66` (`findings_or_execution_failure`); `native_tsan` is `--build_tests_only --features=tsan` (builds, does not run); no stress-suite run |
| Interface / requirements-based / resource / fault-injection test types | `verification_process.rst`; `verification_plan.rst` | **NOT PERFORMED / applicability not inferred** — no harness; identifier/registration-key tests are not platform validation |
| Boundary / equivalence derivation | `verification_process.rst` | **SOURCE-ONLY for the concurrency cases here** (identifier boundary cases were executed) |
| Fuzzy testing technique | `verification_plan.rst` | **NOT EXECUTED / NOT CLAIMED** |
| Linking tests to requirements (record properties) | `verification_process.rst` (`gd_req__verification_link_tests_cpp`) | **PARTIAL / NOT DONE** — `DerivationTechnique`/`Description` recorded; `TestType` and `Verifies` deliberately unset (no invented identifiers) |
| External-component AoUs verified | `verification_process.rst` (`gd_req__verification_external_aou`) | **NOT SATISFIED** |
| Independence of verification / review | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Implementation inspection checklist IMPL_01…IMPL_03 | `inspection_checklist.rst` (`:status: draft`) | **NOT FILLED** |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** — `tool_assurance` is `completed_with_blockers` |
| Obligation collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **RETAINED, NOT PASSED** — 25 present; 12 `findings_or_execution_failure`, 3 `completed_with_blockers` |
| Native acceptance | `source-index.json` | **`not_inferred` for every entry** |

**Explicit non-satisfaction statement.** Missing runtime measurements, the build-only
`native_tests`/`native_tsan` legs, the failing/blocked focused checks
(`findings_or_execution_failure`), the un-inferred applicability, the unknown safety class, the
incomplete extraction of host artifacts, and the unanswered human reviews mean **none of the checked
obligations may be treated as satisfied**. A retained collection node proves *retention*, not
passing; the green focused `check_conversion_tests` helps criterion 9 at the identifier-TU scope
only and is **not** evidence that the runtime concurrency cases, the full suite, or any other
obligation passed.

### 9.3 Measurement executed by this iteration

**None.** No build, no `bazel test`, no runtime, no sanitizer. The brace census (§2), the locking map
(§4), the ordering claims (§3, §5), the assertion audit (§6) and the proposed tests (§8) are static
readings or explicitly-labelled logical consequences; the host artifacts in §1.5-1.6 are *retained*
readings, not produced here.

**Reproduction path for a later, authorized iteration (not run here):**

```bash
bazel test //score/socom/test/unit:socom_test
bazel test //score/socom/test/unit:socom_test --test_filter='RuntimeTest.*'
# concurrency suite (separate target; must be executed under TSAN to be meaningful):
bazel test //score/socom/test/stress:socom_stress_test
bazel test --config=tsan //score/socom/test/stress:socom_stress_test   # if such a config exists
```

---

## 10. Notice preservation

- **Only this report was written.** No source, build, test, config, `NOTICE`, `LICENSE`,
  `REUSE.toml`, or prior-report file was created, edited, or deleted. Every Apache-2.0 / SPDX header
  on every file read remains untouched (`score/socom/impl/service_identifier.{hpp,cpp}:1-12`,
  `runtime_impl.{hpp,cpp}:1-12`, `server_connector_impl.{hpp,cpp}:1-12`,
  `client_connector_impl.{hpp,cpp}:1-12`, `test/unit/runtime_tests.cpp:1-12`,
  `test/unit/service_identifier_tests.cpp:1-14`, `test/stress/*.cpp:1-12`, and the `BUILD` files).
- The header the task flagged (`score/socom/impl/service_identifier.hpp`) was inspected and left
  unchanged because it is already brace-balanced and otherwise well-formed (§2).
- All 39 prior-report files under `.llm_tmp/overnight/prior-reports/` and every pre-existing
  `.llm_tmp/overnight/reports/*` file were preserved (including the earlier-run
  `prior-reports/concurrency_review.md`, which is a different run's document and was **not**
  overwritten).
- This report itself carries the Apache-2.0 header. No licensed MISRA rule text is reproduced.
- The duplicate key remains an `impl/`-only type exposed to `//score/socom/test/unit` only through
  the `testonly` `//score/socom:impl_service_identifier` library; no public header or notice surface
  changed.

---

## 11. Pending human review checklist

- [ ] **Resolve the premise discrepancy (§2):** the "extra closing brace at line 39" does not exist
      in this checkout (line `:39` blank; header balanced; retained compile of its includers exits
      `0`). Confirm no source edit is required, or point to the actual "cancelled draft" revision if
      it is a different artifact.
- [ ] **Confirm the single-lock, no-inversion reading (§4)** and authorize a lock-order/TSAN run of
      the runtime and stress suites; the static reading is not a race-detector result.
- [ ] **Ratify the cross-lock single-server invariant (§4.3):** key identity must stay equal to
      record identity so that A-membership continues to protect B's `ASSERT(!m_server)`; do not
      re-fine the key without re-examining concurrency.
- [ ] **Adjudicate the teardown-order fragility (RCC-4, §5.2):** approve declaring `m_final_action`
      before `m_registration` (or an equivalent guard) so the erase-after-unregister order is
      expressed, not incidental.
- [ ] **Adjudicate the enabled-outlives-runtime hazard (§5.4 / CE-1):** decide whether an enabled
      connector may outlive its `Runtime`. If yes, the server-registration `Final_action` needs the
      same lifetime protection as the key's `weak_ptr` (or the runtime must own/join connectors); if
      no, the contract and the drafted "does not crash" test name/claim must state "disabled only".
- [ ] **Resolve the assertion semantics** of `SCORE_LANGUAGE_FUTURECPP_ASSERT` in `score_baselibs`
      (terminate vs compiled out) — it determines whether a violated precondition is UB.
- [ ] **Confirm the un-enforced assumptions (§6.2)** are acceptable contract, or request
      enforcement/documentation (AS-1 enable/disable; AS-2 one `Connect`; AS-3 weak-token handshake;
      AS-4 copy-then-send; AS-5 publication).
- [ ] **Correct the stale coverage attribution (§6.3):** remove or re-point the
      `BridgesAndSubscribeFindServiceHaveNoRaceConditions` /
      `CreationOfMultipleServerAndClientConnectorsHasNoRaceCondition` comments in
      `runtime_impl.cpp`.
- [ ] **Approve or reject the proposed tests (§8)** and the out-of-candidate stress additions; none
      was written here and none is a safety-acceptance claim. Confirm the §7.3 strength limitation is
      handled by an in-loop success assertion.
- [ ] **Refresh the measurements (§9):** run `bazel test //score/socom/test/unit:socom_test` and
      `//score/socom/test/stress:socom_stress_test` (under TSAN), so `runtime_tests.cpp` and the 14
      stress `TEST_F` are actually compiled and executed; do not re-report the focused identifier
      artifact (`check_conversion_tests`, 91 tests) as coverage of the runtime suite, and do not read
      `--build_tests_only` as a test run.
- [ ] **Do not treat the retained obligation results as passing** (§1.6, §9): 12 are
      `findings_or_execution_failure` and 3 `completed_with_blockers`.
- [ ] **Keep the #84 public `Service_interface_identifier` restructure**, FindService wildcard
      handling, and the config minor-wildcard narrowing out of this bounded slice until separately
      accepted; do not present identifier/registration-key tests as platform validation or claim an
      unmeasured fuzzy technique.
- [ ] **Supply native requirement source IDs and traceability metadata** (no invented links), or
      record applicability as unresolved; resolve `engineering_acceptance: pending` and
      `human_reviews: unanswered`, and select a safety class via the authorized role (do not infer it
      from the `:safety: ASIL_B` attribute on the pinned documents).

---

*End of `concurrency_review` draft. Local, unprotected, scoped. No engineering acceptance; human
reviews unanswered; full native runtime tests pending. Every statement is a local reading of the
working tree, a retained host artifact present in this checkout, or an explicitly-labelled logical
consequence or proposal — none is acceptance, review approval, publication, or a full native run.*
