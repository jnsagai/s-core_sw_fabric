<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — line and branch coverage review (`coverage_review`)

**Document type:** review draft — actual-source inspection of the recorded syntax
failure + measured line/branch coverage assessment against the pinned platform
goals + uncovered changed lines/branches + concrete follow-up tests + obligations
status.

**Date:** 2026-10-03
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling inside *Revise
version handling in socom* (issue #84)
**Run / branch:** `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ`
**Verified baseline commit:** `f8a196c3b16d5172d898394ab99b0ed81346d63d`
(`.llm_tmp/context/source-manifest.json:3`).
**Status:** **local, unprotected, scoped.** No engineering acceptance exists.
Human reviews are unanswered. Full native runtime tests and reference-hardware /
QEMU integration remain pending. Nothing here is acceptance, review approval,
publication, or a full native acceptance run.

> **Tool / write boundary observed.** Only `read_file`, `grep`, `glob` and
> `write_file` were used, exactly as directed. No `shell`, no delegation, no web
> access, no approval, no publishing, and no engineering acceptance. The task
> states: *"This is a review draft: only that report may be written."*
> Accordingly **this iteration wrote exactly one file — this report**
> (`/workspace/.llm_tmp/overnight/reports/coverage_review.md`). No candidate
> source path, `NOTICE`, `LICENSE`, `REUSE.toml`, config, or prior-report file was
> created, edited or deleted. Every prior report and every host artifact was read
> and preserved unchanged.
>
> **Recorded instruction conflict.** The task directs *"Inspect and correct the
> actual source before expanding tests"* because *"the cancelled draft has a
> measured GCC syntax failure: an extra closing brace in
> `score/socom/impl/service_identifier.hpp` at line 39."* Direct inspection shows
> the actual source is **already brace-balanced** and line 39 is **blank** (§2);
> there is no defect to correct, and the explicit write boundary forbids a source
> write in this review draft anyway. Both facts are recorded rather than silently
> reconciled.
>
> **Non-satisfaction rule applied throughout.** A successful obligation-collection
> node means results were **retained**, not that checks **passed**. Missing tools,
> unknown applicability, incomplete extraction, a draft rule mapping, the skipped
> integration/benchmark targets, and unanswered human reviews are **not** treated
> as satisfied. A check that produced no finding because it did not run is
> recorded as *not run*, never as *clean*.

---

## 0. Summary

1. **The recorded "extra closing brace at `service_identifier.hpp:39`" is not
   present in the actual source.** `grep` for `[{}]` over
   `score/socom/impl/service_identifier.hpp` returns exactly four lines — `:19`
   (`namespace score::socom {`), `:29`
   (`struct Service_instance_identifier final {`), `:32` (`};`) and `:38`
   (`}  // namespace score::socom`) — two openers and two closers, net balance
   `0`. Line `:39` is blank; line `:40` is `#endif`. The retained GCC compile of
   this header's translation unit exited `0`. **No correction was applied and
   none is required** (§2).

2. **Measured line coverage is 100.0 %; measured branch coverage is 78.6 %.**
   The retained focused coverage artifact
   (`.llm_tmp/overnight/obligations/focused_coverage/result.json`) records
   **36/36 lines (100.0 %)** and **11/14 branches (78.6 %)** over
   `score/socom/impl/service_identifier.cpp` + `string_registry.cpp`. Against the
   pinned platform goals (`verification_plan.rst` criteria 1–2: **QM 85 % /
   safety 100 %** for *both* statement and branch coverage), **line coverage meets
   both goals; branch coverage (78.6 %) meets neither the QM 85 % nor the safety
   100 % goal.** The safety class is `unknown_requires_authorized_selection`; it
   is **not** chosen here and **no deviation is accepted** (§3, §4).

3. **The changed production file has 50 % branch coverage on its own.**
   `service_identifier.cpp` is the only changed executable production file: 3/3
   lines (100 %) but **1/2 branches (50 %)**; the single uncovered branch is the
   compiler-generated `throw` edge at `:28` (count `0`). The aggregate 78.6 %
   is lifted above the changed file's own figure by `string_registry.cpp`
   (33/33 lines, 10/12 branches), an **unchanged dependency** file. Under a
   changed-lines-only reading the branch figure is 50 %, below both goals (§4).

4. **Uncovered changed branches.** There are **no uncovered changed lines**. The
   only uncovered **changed branch** is `service_identifier.cpp:28` — the `throw`
   edge of the `std::tie` comparison (`{count 1091951, fallthrough}` vs
   `{count 0, throw}`). Two further compiler-generated branches are uncovered in
   the measured, **unchanged** dependency `string_registry.cpp:66` and `:71`
   (function-local static initialisation guard exception edges, one count-`0`
   branch each). All three are compiler-generated and not reachable by a
   deterministic test through the public API (§5).

5. **The reachable identifier-registration gap is already closed.** The dynamic
   `String_registry::insert` "not found" branches (`string_registry.cpp:38` and
   `:55`) are both taken in the retained run, driven by
   `FreshDynamicServiceIdStringViewRegistersAndCollapses` (`:1982`) and
   `FreshDynamicServiceIdRvalueRegistersAndCollapses` (`:2012`). The
   minor-only-registration regression
   `RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError`
   (`runtime_tests.cpp:402-431`) is present and the retained native
   `//score/socom/test/unit:socom_test` target (which globs both test files)
   **PASSED** (§3.4). These are retained, local, unprotected measurements.

6. **The repository CI line threshold of 73 % is separate.** The retained native
   coverage job ran with `COVERAGE_THRESHOLD=73` and reported
   *"Raw line coverage: 74.51 %"* / *"gating on raw line coverage"* — a
   repository-wide, line-only gate. It is **not** the platform 85/100
   line-and-branch acceptance basis, and it does not excuse the branch shortfall
   (§3.3).

7. **No obligation is satisfied.** `authority.json` records
   `engineering_acceptance: pending`, `human_reviews: unanswered`,
   `safety_class: unknown`; every `source-index.json` entry is
   `native_acceptance: not_inferred`. `process_checks` is
   `completed_with_blockers`; the branch goal is measurably unmet; the 8
   QEMU/benchmark targets were skipped; TSan cannot start; the clang-tidy config
   was rejected; MISRA mapping and inspection checklist are draft (§6).

---

## 1. Binding to the issue, baseline, candidate paths and sources

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` | `.llm_tmp/context/issue-snapshot.json:2-4` |
| Title | *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:3` |
| State | `open`, **0 comments**, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` (unchanged) | `.llm_tmp/context/issue-snapshot.json:19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an
accepted obligation** — service-instance identifier =
`service id + major + minor + instance id`; service identifier =
`service id + major`; FindService =
`service id + major + optional<minor> + optional<instance>`; plus the proposal to
*"exclude the minor version and make it a property of the service instance."*
There is no comment and no acceptance record, so none of it is binding. Binding is
**by baseline commit**, not by run HEAD.

### 1.2 Verified baseline and the six writable candidate paths

| Candidate path | Baseline git blob | Current working tree (read this iteration) |
|----------------|-------------------|---------------------------------------------|
| `score/socom/BUILD` | `3477ea0851fdcd82ec6ea9d71424013cbdf41962` | `testonly` `impl_service_identifier` exposure |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e22355242009fe20dada2a9a0d0c7a9c7` | `operator<` identity `(instance, service id, major)`, `minor` excluded |
| `score/socom/impl/service_identifier.hpp` | `c8bae7908da9f087c518934f7b9f8d86db9a20ec` | **brace-balanced**, 40 lines; `:39` blank |
| `score/socom/test/unit/BUILD` | `3c03a7b14286051f97fa5022206564bd63645171` | `socom_test` globs `*.cpp`; deps wired |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab726db8bf994c960045d6fd7fdf84d7395` | 1 `TEST` + 31 `TEST_F` + 1 `TEST_P` (33 macros) |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(none — expected new file)* | **91 `TEST_F`** under `ServiceInstanceIdentifierTest` |

Source: `.llm_tmp/context/candidate-files.json:1-25` and
`.llm_tmp/context/source-manifest.json`. The `null` baseline blob is the
manifest's expectation of a **new** test file; it exists only in the un-merged
working tree (the task's "cancelled draft"). The changed **production** surface is
therefore `service_identifier.cpp` (executable) and `service_identifier.hpp`
(documentation/declaration only); the other four candidate paths are build/test
wiring.

**Working-tree hash note.** The `sha256` values in
`.llm_tmp/context/candidate-files.json` are a start-of-task snapshot; the retained
artifacts record the evolved tree consistently
(`service_identifier.cpp` = `3c12b3f1…`, `service_identifier.hpp` = `bdce3fcb…`,
`score/socom/BUILD` = `68f4645a…`, `score/socom/test/unit/BUILD` = `e909151e…`,
`runtime_tests.cpp` = `9a2d6a15…`, `service_identifier_tests.cpp` = `de79767c…`;
`focused_coverage/result.json`, `native_coverage/result.json`,
`process_checks/result.json:1061-1080`). No local hashing tool was available, so
these are the artifacts' recorded hashes, not values recomputed here; the direct
source reads in §2 and §5 are authoritative for this report's inspection claims.

### 1.3 Pinned obligation sources and authority (read this iteration)

All nine `.llm_tmp/context/obligations/source-index.json` entries were read;
**every** entry is `"native_acceptance": "not_inferred"`. Relevant for this
review:

| id | pinned path (repository) | status note |
|----|--------------------------|-------------|
| `verification_plan` | `docs/platform_management_plan/software_verification.rst` (exported here as `verification_plan.rst`) | `:status: valid`; `:safety: ASIL_B`; quality criteria 1–9 |
| `code_analysis` | `docs/contribute/development/cpp/code_analysis.rst` | `:status: valid`; gcov/gcovr, sanitizers, clang-tidy |
| `misra_mapping` | `…/misra_2023_rule_mapping.rst` | draft mapping — not applied |
| `verification_process` / `verification_guideline` | process_description | valid; traceability, independence, documented results |
| `inspection_checklist` | `module_template` | draft template — not filled |

**Authority record** (`.llm_tmp/context/obligations/authority.json:1-7`):
`engineering_acceptance: pending`; `human_reviews: unanswered`;
`safety_class: unknown`; `codeql_scope: "Public Apache-2.0
eclipse-score/inc_someip_gateway; no upload"`; instruction *"Restart the failed
queue for one complete pass through all obligations"*.

**Safety-class note (recorded, not resolved).** The pinned platform documents
carry `:safety: ASIL_B` (`verification_plan.rst:19`), while `authority.json`
records `safety_class: unknown` and no authorized selection exists; the focused
coverage artifact itself records
`safety_class: "unknown_requires_authorized_selection"`. The document attribute is
**not** a selection of the slice's safety class and must not be inferred as one.
This review therefore shows **both** the QM 85 % and safety 100 % goals and
selects neither.

### 1.4 Pinned platform coverage goals (the yardstick used in §3)

`verification_plan.rst:292-307` defines the quality criteria to be reached with
every contribution:

| # | Criterion | Goal QM | Goal Safety |
|---|-----------|---------|-------------|
| 1 | Structural Statement Coverage (represented by Line Coverage) | **85 %** | **100 %** |
| 2 | Structural Branch Coverage | **85 %** | **100 %** |

`verification_plan.rst:340-346` states that these structural statement/branch
percentages are represented by the reported **Line** and **Branch** coverage
values of the unit-test tooling, and that the confirmation *or any deviation* must
be documented with a reasoning in the module documentation. Because the safety
class is `unknown`, neither goal is selected here.

### 1.5 Prior reports, host feedback and obligation results read (and preserved)

- `.llm_tmp/overnight/prior-reports/` — 38 files present and preserved, including
  the earlier same-named `coverage_review.md`, `coverage_tests_repair.md`,
  `repair_conversion_tests.md`, `key_fix.md`, `invariants.md`, `scope.md`,
  `tool_findings_repair.md`, `verification_report_draft.md`.
- `.llm_tmp/overnight/reports/` — this run's earlier nodes, read and preserved
  (`scope.md`, `callsites.md`, `invariants.md`, `reproducer.md`, `key_fix.md`,
  `unit_matrix.md`, `ordering_tests.md`, `conversion_tests.md`,
  `repair_conversion_tests.md`, `runtime_disabled.md`, `runtime_enabled.md`,
  `lifetime_tests.md`, `test_metadata.md`, `tool_findings_repair.md`,
  `coverage_tests_repair.md`). **This document adds `coverage_review.md` and
  overwrites no prior report.**
- `.llm_tmp/overnight/validation/` — present and read: `check-result` = `0`
  (retention marker); `measurement.json` (`check_ref: check_conversion_tests`,
  `mode: ubsan`, `origin: local_unprotected_measurement`,
  `initiator: Fabro host hook`, `engineering_acceptance: pending`,
  `full_native_tests: not_executed`, compiler
  `/usr/bin/x86_64-linux-gnu-g++-12`, `baseline_with_agent_tests` = 91 tests /
  33 failures, `candidate` = 91 tests / 0 failures / 0 disabled);
  `before.json` (91 / 33) and `after.json` (91 / 0); empty
  `before-`/`after-compile.stderr`.
- `.llm_tmp/overnight/obligations/*/result.json` — 24 checks present and read.
  The ones this review relies on: `focused_coverage` (§3), `native_coverage`
  and `native_tests` (§3.3, §3.4), `compiler_diagnostics` (§2.3),
  `focused_asan_lsan`, `process_checks` (§6).

Per the task rule, a successful collection node means results were **retained**,
not that checks **passed**.

---

## 2. The recorded GCC syntax failure — inspection of the actual source

### 2.1 Direct reading (this iteration, by `read_file` + `grep`)

`score/socom/impl/service_identifier.hpp` is **brace-balanced**. A `grep` for
`[{}]` returns exactly four brace-bearing lines:

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`) and two closers (`:32`, `:38`) give net brace
balance `0`. There is **no third, unmatched closing brace**, and line 39 contains
no text at all. The sibling `impl/service_identifier.cpp` uses the same nested
form (`:18` / `:32`) and is balanced. `glob **/service_identifier.hpp` returns
exactly one path, so there is no second, differently-braced copy of the header in
this checkout.

### 2.2 Disposition

The task's *"extra closing brace … at line 39"* matches a **stale,
pre-correction description** — the earliest prior reports quote the split form
`}  // namespace socom` + `}  // namespace score`, which the `reproducer`
iteration already merged into the single nested close, leaving line 39 blank
exactly as observed here. **No source edit was made**, because (a) there is no
defect to correct and (b) this review draft may write only this report.

### 2.3 Independent retained compiler evidence (read, not produced here)

`.llm_tmp/overnight/obligations/compiler_diagnostics/result.json` is
`status: completed`, with every recorded compile command `exit_code: 0` (`:1084`
… `:1296`). That capture compiled the same header (as a transitive include of
`service_identifier.cpp` / `service_identifier_tests.cpp`) with
`g++-12 -std=c++17 -Wall -Wextra -Werror`; an unmatched brace would have produced
a compile failure, not exit `0`. This is a retained **local, unprotected, scoped**
measurement, not acceptance.

### 2.4 Minimal historical repair (reference only; NOT applied)

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

Applying this to the already-balanced file would be a no-op; deleting a brace
from a balanced header would *create* the reported defect.

---

## 3. Measured line and branch coverage

### 3.1 Basis artifacts (retained)

| Artifact | What it records |
|----------|-----------------|
| `.llm_tmp/overnight/obligations/focused_coverage/coverage-summary.json` | line 36/36, branch 11/14 |
| `.llm_tmp/overnight/obligations/focused_coverage/coverage.json` | per-line/per-branch counts used in §5 |
| `.llm_tmp/overnight/obligations/focused_coverage/result.json` | goals QM 85 / safety 100; `safety_class: unknown_requires_authorized_selection`; `complete_target_scope: false`; `engineering_acceptance: pending` |
| `.llm_tmp/overnight/obligations/focused_coverage/tests.json` | **91 tests / 0 failures / 0 disabled** |
| `.llm_tmp/overnight/validation/measurement.json` | candidate 91/0; `full_native_tests: not_executed` |
| `.llm_tmp/overnight/obligations/native_coverage/report.stdout` | *"Raw line coverage: 74.51 %"*; `COVERAGE_THRESHOLD=73` in the command env (`result.json:1077,1107`) |
| `.llm_tmp/overnight/obligations/native_tests/tests.stdout` | 21 passed / 8 skipped; `//score/socom/test/unit:socom_test PASSED` |

The focused executable compiles `score/socom/impl/service_identifier.cpp` +
`score/socom/impl/string_registry.cpp` + `service_identifier_tests.cpp` with
`g++-12 -std=c++17 -Wall -Wextra -Werror --coverage`, runs it, then runs
`gcovr --filter score/socom/impl/`. All commands are `exit_code: 0`.

**Important scope limit:** the focused measurement covers only
`score/socom/impl/service_identifier.cpp` (the changed production file) and
`string_registry.cpp` (an **unchanged** dependency). It does **not** compile
`runtime_impl.cpp`, so the full duplicate-registration path is not branch-measured
there; the native run measures it line-only (§3.3).

### 3.2 Result against the platform goals

| Metric | Measured | QM goal | Safety goal | Verdict |
|--------|----------|---------|-------------|---------|
| Line (statement) coverage | **36/36 = 100.0 %** | 85 % | 100 % | **Meets** QM and safety (focused scope) |
| Branch coverage | **11/14 = 78.6 %** | 85 % | 100 % | **Meets neither** — below QM by 6.4 pp, below safety by 21.4 pp |

Per-file split (`coverage-summary.json`):

| File | Line | Branch | Note |
|------|------|--------|------|
| `score/socom/impl/service_identifier.cpp` (**changed**) | 3/3 (100 %) | **1/2 (50 %)** | uncovered branch = compiler `throw` edge at `:28` |
| `score/socom/impl/string_registry.cpp` (unchanged dependency) | 33/33 (100 %) | 10/12 (83.3 %) | uncovered compiler guard edges at `:66`, `:71` |
| **Total** | **36/36 (100 %)** | **11/14 (78.6 %)** | |

**Changed-file reading.** If coverage is scoped to the single changed executable
production file, `service_identifier.cpp` is **50 % branch** — below both goals.
The 78.6 % aggregate is not a property of the changed code; it is diluted upward
by an unchanged dependency. This distinction is material for the branch-goal
assessment.

**Safety-class handling.** The safety class is `unknown`; this draft does **not**
choose QM or safety and does **not** accept a deviation. Because branch coverage
is below *both* the QM 85 % and the safety 100 % goals, it fails regardless of
which class is eventually selected; only the line metric changes classification.

### 3.3 The repository CI line threshold is separate

`native_coverage/result.json` records the command environment
`COVERAGE_THRESHOLD=73` (`:1077`, `:1107`) and the explicit limit
*"Repository CI threshold 73 is not platform 85/100 line-and-branch acceptance"*
(`:1117-1119`). `native_coverage/report.stdout:3-4` records *"no --yaml given;
justification processing skipped, gating on raw line coverage. Raw line coverage:
74.51 %."* This is a **repository-wide, line-only** gate; it is not the slice's
line/branch figure and not the platform acceptance basis. Line coverage passes it;
it does not excuse the branch shortfall. `native_coverage/report.stderr:19-33`
also lists 14 in-scope files never compiled into a test binary (including
`score/socom/error.hpp`, `score/socom/impl/messages.hpp`,
`score/socom/string_registry.hpp`); none is one of the six candidate paths except
through internals already exercised.

### 3.4 Retained test execution

- **Focused identifier suite:** `validation/measurement.json` candidate =
  **91 tests / 0 failures / 0 disabled** (`compile_exit 0`, `test_exit 0`);
  `after.json` = 91/0. The same 91 cases are recorded in
  `focused_coverage/tests.json`.
- **Full native host run:** `native_tests/result.json` `status: completed`,
  `exit_code: 0`; `tests.stdout` = **21 passed / 8 skipped**, with
  `//score/socom/test/unit:socom_test PASSED` (`:16`). Because `socom_test`
  globs every `*.cpp` under `score/socom/test/unit`, that target compiles and runs
  **both** candidate test files — including the registration-key runtime
  regressions. `native_coverage/coverage.stdout:19` shows the same target
  `PASSED` in the coverage build.
- **Skipped (not passed):** the 8 skipped targets are
  `//tests/benchmarks:e2e_*` and `//tests/integration_test:*`
  (reference-hardware / QEMU). They are pending, not satisfied.

### 3.5 ASan/LSan corroboration (retained)

`focused_asan_lsan` retains a focused run under ASan/LSan/UBSan
(`ASAN_OPTIONS=detect_leaks=1:halt_on_error=1`, `UBSAN_OPTIONS=halt_on_error=1`)
reporting the same 91/91 identifier tests passing. This is a retained local
capture, not acceptance.

---

## 4. Assessment against the 85 % QM / 100 % safety goals

| Criterion (`verification_plan.rst:292-307`) | Goal QM | Goal Safety | Measured (focused) | Assessment |
|---------------------------------------------|---------|-------------|--------------------|------------|
| 1 Structural statement (line) coverage | 85 % | 100 % | 36/36 = **100.0 %** | Meets both goals on the measured scope |
| 2 Structural branch coverage | 85 % | 100 % | 11/14 = **78.6 %** | **Meets neither**; deviation required and human-owned |
| 2 (changed file only) | 85 % | 100 % | 1/2 = **50.0 %** | **Meets neither** |

- The line metric meets both goals **only for the focused scope**
  (`complete_target_scope: false`); the full-`socom_test` branch/line figure is
  not measured (native coverage is line-only).
- The branch metric fails both goals. The three uncovered branches are
  compiler-generated (§5), so the shortfall is structural rather than a missing
  behaviour test; nonetheless `verification_plan.rst:345-346` requires that *any
  deviation be documented with a reasoning*, and that authorization is
  **human-owned**.
- **This review does not choose the safety class, does not select QM or safety,
  and does not accept the deviation.** It records the measurement, the structural
  cause, and the decision that remains open.

---

## 5. Uncovered changed lines / branches and concrete follow-up tests

### 5.1 Changed production surface

- `score/socom/impl/service_identifier.cpp:20-30` — `operator<`; executable lines
  are `:20` (signature), `:28` and `:29` (the `std::tie` comparison); `:21-27`
  are the explanatory comment.
- `score/socom/impl/service_identifier.hpp:21-32` — the `minor`-exclusion
  documentation and the `Service_instance_identifier` declaration
  (declaration-only, no executable lines).
- Test-only changes are not production.

### 5.2 Uncovered changed lines: none

`coverage.json` gives `service_identifier.cpp:20` count `1091951`, `:28` count
`1091951`, `:29` count `2183902` — all non-zero. **Every changed executable
production line is covered.**

### 5.3 Uncovered branches (exhaustive, from `coverage.json`)

| # | Location | Branch | Counts | Classification |
|---|----------|--------|--------|----------------|
| 1 | `service_identifier.cpp:28` | `throw` edge of the `std::tie` comparison | `{1091951, fallthrough}` vs `{0, throw}` | **changed branch**, compiler-generated |
| 2 | `string_registry.cpp:66` | 4th edge of the function-local static guard in `service_id_registry()` | `{1},{1866},{1},{0}` | unchanged dependency, compiler-generated |
| 3 | `string_registry.cpp:71` | 4th edge of the function-local static guard in `instance_id_registry()` | `{1},{1819},{1},{0}` | unchanged dependency, compiler-generated |

All three are GCC-generated exception/guard edges. The comparison operands are
non-throwing: `Registry_string_view::operator<` is declared `noexcept`
(`score/socom/registry_string_view.hpp:141`), `Service_instance::operator<`
compares `Registry_string_view` ids (`service_interface_identifier.hpp:69-71`),
and the remaining operand is `std::uint16_t`. The `String_registry` static
constructors do not throw observably. These edges can be taken only if a
comparison or a static initialiser throws — which the public API cannot induce
without a fault-injection seam or undefined behaviour. **There are no reachable
logic branches left uncovered in the changed code.**

### 5.4 Concrete follow-up tests and actions

These are concrete and independent of the write restriction (they are for a later,
authorized iteration). No safety classification, deviation, or native traceability
identifier is invented.

1. **Re-run focused coverage after any code motion** and confirm 36/36 lines and
   11/14 branches, using the recipe recorded in `focused_coverage/result.json`
   (`g++-12 … --coverage` then `gcovr --filter score/socom/impl/`). Keep the two
   dynamic-registration tests (`service_identifier_tests.cpp:1982`, `:2012`);
   they are what closes `string_registry.cpp:38` / `:55`. Then run the full native
   target `bazel test //score/socom/test/unit:socom_test` and the broader
   `//score/...` set.
2. **Add a static contract test pinning non-throwing comparison** in
   `service_identifier_tests.cpp`, e.g.
   `static_assert(noexcept(std::declval<Service_instance_identifier const&>() <
   std::declval<Service_instance_identifier const&>()), ...);` **after** the
   production operator is annotated `noexcept`
   (`service_identifier.hpp:35` declaration and `service_identifier.cpp:20`
   definition). This is a reachable, meaningful test that also removes the
   compiler `throw` edge at `:28`. Note the arithmetic: `noexcept` alone drops the
   branch total to 13 and yields 11/13 = **84.6 %**, still below QM 85 %; it must
   be combined with an approved policy for the two guard edges or with a
   documented deviation.
3. **Keep the std::set-insertion behaviour pinned at both outcomes.** The
   duplicate outcome is already pinned by the key-level minor-collapse tests and
   by `RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError`
   (`runtime_tests.cpp:402-431`); the distinct outcome (different major/instance/id
   coexist) is covered by the sibling runtime tests. If the runtime path is to be
   branch-measured, extend the coverage filter/recipe to include
   `runtime_impl.cpp` (currently outside the focused measurement).
4. **For the two `string_registry.cpp` guard edges (not reachable today):** a test
   would require an injectable constructor-failure seam, which is out of this
   bounded slice. The honest alternatives are (a) an authorized, documented
   gcovr exclusion policy for compiler-generated guard/`throw` edges, or (b) a
   documented deviation from criterion 2. Neither may be self-applied here.
5. **Measure branch coverage for the full target.** `native_coverage` currently
   reports only repository-wide **line** coverage (74.51 %); there is no native
   branch figure. Add a per-file branch report over `//score/socom/test/unit`
   (including `runtime_impl.cpp`) and over the changed files specifically, so the
   50 % changed-file branch figure can be re-confirmed or refuted.
6. **Traceability metadata (no invented links).** Only `DerivationTechnique` and
   `Description` are recorded (`process_checks/result.json:1061-1080`:
   `service_identifier_tests.cpp` 91 macros, `runtime_tests.cpp` 33 macros).
   Add `TestType` and `Verifies`/`FullyVerifies` only once a verified native
   requirement/interface identifier exists; otherwise record applicability as
   unresolved.
7. **Do not present these identifier-only tests as platform validation** and do
   not claim a fuzzy/fault-injection technique without a measurement.

---

## 6. Obligations status (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Structural statement (line) coverage goal | `verification_plan.rst:300-303` (criterion 1) | **MET for the focused scope only** — 36/36 = 100 % (QM 85 / safety 100). Not measured for the full target. Local/unprotected. |
| Structural branch coverage goal | `verification_plan.rst:304-307` (criterion 2) | **NOT MET** — 11/14 = 78.6 % (changed file 1/2 = 50 %); below both QM 85 % and safety 100 %; `safety_class: unknown`; **no deviation accepted** |
| Repository CI line gate (73 %) | `native_coverage/result.json` (`COVERAGE_THRESHOLD=73`) | **Passed, but separate** — raw line coverage 74.51 %; explicitly *"not platform 85/100 line-and-branch acceptance"* |
| Full native coverage branch/line scope | `native_coverage/result.json` | **PARTIAL** — line-only (74.51 %); no native branch figure; 14 in-scope files never compiled into a test binary |
| Unit/component testing executed, results recorded | `verification_plan.rst` criteria 6–7; `verification_guideline.rst` | **PARTIAL / NOT SATISFIED** — host `socom_test` PASSED (21 run / 8 skipped); 8 QEMU/benchmark integration targets pending; reference-hardware not run |
| Freedom from compiler warnings & errors (100 %) | `verification_plan.rst:332-335` (criterion 9) | **PARTIAL** — retained focused GCC compiles exit 0; clang/TSan legs blocked by environment/dependency, not by the slice |
| Static code analysis (clang-tidy / CodeQL), findings classified | `code_analysis.rst`; `gd_req__verification_sca_classification` | **NOT SATISFIED** — clang-tidy config rejected; CodeQL MISRA applicability draft |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` (draft) | **UNKNOWN — NOT CLAIMED** — mapping not applied |
| Interface / requirements-based / resource / fault-injection tests | `verification_process.rst` | **NOT PERFORMED / applicability not inferred** — no harness; identifier tests must not be labelled platform validation |
| Boundary / equivalence derivation | `verification_process.rst` | **TAGGED / EXECUTED (host)** — `boundary-values,equivalence-classes` on the 91 key cases; `design-analysis,equivalence-classes` on the runtime cases; local only |
| Linking tests to requirements (record properties) | `gd_req__verification_link_tests_cpp` | **PARTIAL / NOT DONE** — `DerivationTechnique`/`Description` recorded; `TestType`/`Verifies` unset (no invented identifiers) |
| External-component AoUs verified | `gd_req__verification_external_aou` | **NOT SATISFIED** — no integration/static verdict; no AoU register |
| Independence of verification / review by a different committer | `gd_req__verification_independence` | **NOT DONE** — human reviews unanswered |
| Implementation inspection checklist IMPL_01…IMPL_03 | `inspection_checklist.rst` (draft) | **NOT FILLED** |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** for this slice — TSan cannot start; clang-tidy config rejected |
| Obligation collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **RETAINED, NOT PASSING** — 24 checks present; `process_checks` is `completed_with_blockers` |
| Process checks | `process_checks/result.json:1052-1059` | **completed_with_blockers** — *"Lexical metadata inventory cannot prove semantic requirement coverage"*, *"Safety/QM applicability and approved tailoring unknown"*, *"Independent inspection and acceptance required"*, *"External AoU and full integration verification require scoped review"* |
| Native acceptance | `.llm_tmp/context/obligations/source-index.json` | **`not_inferred` for every entry** |

**Explicit non-satisfaction statement.** A retained green host measurement
(`socom_test` PASSED, focused 91/0, ASan/LSan 91/91) is *retention of a local,
unprotected, scoped run*, not engineering acceptance. The measured branch
coverage is below both platform goals (and 50 % for the changed file); the full
native branch/target scope is not measured; the safety class is unknown and
applicability is not inferred; the MISRA mapping and inspection checklist are
draft; the QEMU/benchmark targets are skipped; and human reviews are unanswered.
Therefore **none of the checked obligations may be treated as satisfied**.

---

## 7. Files changed / state of the six candidate paths

This iteration wrote **only this report**.

| Candidate path | State | This iteration |
|----------------|-------|----------------|
| `score/socom/impl/service_identifier.hpp` | brace-balanced, nested namespace, documents minor exclusion | **unchanged** (verified, §2) |
| `score/socom/impl/service_identifier.cpp` | `operator<` identity `(instance, service id, major)`, minor excluded; 100 % line, 50 % branch | **unchanged** (verified, §3) |
| `score/socom/BUILD` | `testonly` `impl_service_identifier` exposure present | **unchanged** |
| `score/socom/test/unit/BUILD` | `socom_test` globs `*.cpp`; deps wired | **unchanged** |
| `score/socom/test/unit/runtime_tests.cpp` | 33 macros; minor-only duplicate regression `:402-431` | **unchanged** (verified) |
| `score/socom/test/unit/service_identifier_tests.cpp` | 91 `TEST_F`; `SetUp()` metadata | **unchanged** (verified) |
| `.llm_tmp/overnight/reports/coverage_review.md` | **new — this report** | written |

No file outside the six candidate paths and this report was written; no `NOTICE`,
`LICENSE`, or `REUSE.toml` file was created, edited or deleted; all prior reports
and all host artifacts were preserved.

---

## 8. Notice preservation

- No source, build, test, config, `NOTICE`, `LICENSE` or `REUSE.toml` file was
  created, edited or deleted by this iteration; only this report was written.
- `score/socom/impl/service_identifier.hpp` and `service_identifier.cpp` retain
  their Apache-2.0 / SPDX headers (`:1-12`) and were left unchanged; both BUILD
  files and both candidate test files likewise retain their `:1-12` headers.
- The duplicate-server registration key remains an `impl/`-only type exposed only
  to `//score/socom/test/unit` via the `testonly`
  `//score/socom:impl_service_identifier` library, so no public header or notice
  surface changed.
- This report itself carries the Apache-2.0 header. No licensed MISRA rule text is
  reproduced; only native rule/query identifiers, file locations, and artifact
  readings are cited.
- All files under `.llm_tmp/overnight/prior-reports/`, all earlier files under
  `.llm_tmp/overnight/reports/`, and all host artifacts under
  `.llm_tmp/overnight/validation/` and `.llm_tmp/overnight/obligations/` were
  preserved; the host artifacts were read only.

---

## 9. Pending human review checklist

- [ ] **Confirm §2:** the recorded "extra closing brace at
      `service_identifier.hpp:39`" is not present in this checkout (braces at
      `:19`,`:29`,`:32`,`:38`; line 39 blank), and the retained GCC compile
      exited 0, so no source edit was made. If a different revision of the
      "cancelled draft" still carries the extra brace, locate it and authorize its
      correction; no such file exists in this checkout.
- [ ] **Confirm §3 reading:** line 36/36 = 100 %, branch 11/14 = 78.6 %; changed
      file `service_identifier.cpp` 1/2 = 50 % branch. Confirm the repository CI
      line threshold 73 % is **not** the acceptance basis.
- [ ] **Select the safety class and the applicable criterion-2 goal** (QM 85 % vs
      safety 100 %) via the authorized role, and **document the branch-coverage
      deviation** (or authorize a coverage-exclusion policy). This draft chooses
      neither and does not accept a deviation.
- [ ] **Confirm the three uncovered branches in §5.3 are compiler-generated** and
      not product logic, and choose the §5.4 follow-up (e.g. `noexcept` plus an
      approved guard-branch exclusion) — noting that `noexcept` alone leaves
      11/13 = 84.6 %.
- [ ] **Add native branch coverage** for the full `socom_test` target (currently
      line-only) and confirm or refute the changed-file branch figure.
- [ ] **Resolve the skipped targets** (8 of 29: QEMU integration and e2e
      benchmarks) and the blocked TSan / clang-tidy-config legs; record results.
- [ ] **Supply native requirement/interface identifiers** for traceability (no
      invented links), or record applicability unresolved.
- [ ] **Resolve `engineering_acceptance: pending` / `human_reviews: unanswered`**
      and schedule independent review (approver must differ from the author, per
      `gd_req__verification_independence`).
- [ ] **Address the retained `process_checks` blockers** and the draft
      `misra_mapping.rst` / `inspection_checklist.rst`; do not treat retention as
      passing.
- [ ] **Keep the wider #84 restructure** (public `Service_interface_identifier`
      change, FindService wildcard handling, config minor-wildcard narrowing) out
      of this bounded slice until separately accepted, and do not present the
      identifier-only tests as platform validation.

---

*End of line and branch coverage review draft. Local, unprotected, scoped. No
engineering acceptance; human reviews unanswered; full native runtime and
reference-hardware tests pending. Every statement is a local reading of the
working tree, a retained local artifact reading, or an explicitly-labelled logical
consequence — none is acceptance, review approval, publication, or a full native
acceptance run.*
