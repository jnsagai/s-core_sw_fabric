<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — evidence inventory and host-measurement reconciliation

**Document type:** review draft (host-measurement / changed-hash / remaining-runtime
evidence inventory and reconciliation).

**Date:** 2026-10-03
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version
handling in socom* (issue #84)
**Run / branch:** `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ`; current HEAD `44042a6`
(`fabro(01M3ZRSDK2XQAF1H48VWTPKQNZ): node_5aa5ee0c4f55cfd240b661a6 (success)`), per the run
environment's recent-commit list.
**Verified baseline commit:** `f8a196c3b16d5172d898394ab99b0ed81346d63d`
(`.llm_tmp/context/source-manifest.json:3`).
**Status:** **local, unprotected, scoped.** No engineering acceptance exists. Human reviews are
unanswered. Full native runtime tests remain pending. Every statement below is either a direct
reading of this checkout / the retained artifacts, or an explicitly-labelled logical consequence.
**Agent statements are assertions; none is acceptance, an approval, a review, publication, or proof
that an obligation passed.**

> **Write boundary observed.** This iteration used only `read_file`, `grep`, `glob`, and
> `write_file`. No `shell`, delegation, web access, approval, publishing, or engineering acceptance
> was performed. The task's final sentence — *"This is a review draft: only that report may be
> written."* — is the binding write constraint, so **exactly one file was created or modified: this
> report (`/workspace/.llm_tmp/overnight/reports/evidence_inventory.md`).** No source, build, test,
> config, `NOTICE`, `LICENSE`, `REUSE.toml`, `validation/`, `obligations/`, or prior-report file was
> created, edited, or deleted. Every notice/licence header and every retained host artifact was
> preserved.
>
> **Instruction conflict recorded, not silently resolved.** The task also says *"Inspect and correct
> the actual source before expanding tests"* and records *"a measured GCC syntax failure: an extra
> closing brace in `score/socom/impl/service_identifier.hpp` at line 39."* Direct inspection (§2)
> shows the header is **already brace-balanced** and line 39 is **blank**; there is no unmatched
> brace to remove. All retained host compiles of that translation unit exit `0` (§2.2, §3). The
> written constraint forbids a source write in any case. The conflict is therefore **moot on the
> facts** and is recorded for the human reviewer (§11).
>
> **Non-satisfaction rule applied throughout.** A successful obligation-collection node means the
> results were **retained**, not that the checks **passed**. Missing tools, unknown applicability,
> incomplete extraction, an inactive/draft rule mapping, a build-only leg, and unanswered human
> reviews are **not** treated as satisfied. A tool that produced **no** finding because it **did not
> run** (or did not complete) is recorded as *"not run"*, never as *"clean"*.

---

## 0. Summary

1. **The recorded GCC syntax failure is not present in the actual source (§2).**
   `score/socom/impl/service_identifier.hpp` is a 40-line, brace-balanced header: two openers
   (`:19`, `:29`) and two closers (`:32`, `:38`), net balance `0`, line `:39` blank. `glob
   **/service_identifier*` returns exactly three files (no second, differently-braced copy). The
   retained host **GCC** (`g++-12 -Werror`) and **Clang** 19 (`-Werror`) focused compiles both exit
   `0`, the focused host measurement compiles exit `0`, and the native `bazel build //...` exits `0`.
   **No source correction is required or applied.**
2. **The latest host measurement is a focused red→green record, not full native execution (§3).**
   `.llm_tmp/overnight/validation/measurement.json` + `before.json`/`after.json`:
   `baseline_with_agent_tests` = 91 tests / **33 failures** / compile `0` / test exit `1`;
   `candidate` = 91 tests / **0 failures** / compile `0` / test exit `0`. The TU compiled is **only**
   `service_identifier.cpp` + `string_registry.cpp` + `service_identifier_tests.cpp` + vendored
   googletest; `runtime_tests.cpp` is **not** in it. `check-result` is `0`.
3. **The host measurement set is newer than the context snapshot set (§4).** The two hash sets
   disagree on all six candidate paths. The host/tool-measured hash for
   `service_identifier_tests.cpp` is the **91-macro** state; the context `candidate-files.json` hash
   corresponds to the earlier draft state (87 macros, superseded). Current direct reads show 91
   `TEST_F` in the key suite and 33 test macros in `runtime_tests.cpp`, i.e. the host-measured state.
   No local hashing tool was available, so hashes are **quoted, not recomputed**.
4. **The registration-key correction is present and minimal (§5).** `operator<` compares
   `(instance, service id, major)`; `minor` is excluded, matching the minor-ignoring
   `Service_database` index. Interface representation and the exact-major / `client.minor <=
   server.minor` rules are unchanged.
5. **Host obligation results were reconciled; many legs did not pass (§6).** `native_build` (`//...`)
   exit `0`; `native_tests` was **build-only** (`--build_tests_only`); the only executed
   unit/component result is `bazel test //:unit_tests //:component_tests` exit `0` with
   `socom_test PASSED`; `//:docs` exit `2`, traceability gate exit `1`, QEMU integration exit `1`,
   performance/profiling exit `124`, `format.check` exit `124`, `reuse lint` exit `1`, focused TSan
   exit `66`, focused clang-tidy `--verify-config` exit `1`, gitleaks exit `1`.
6. **Remaining full-runtime checks are pending, not passed (§7).** No true `bazel test //...`
   execution (no `--build_tests_only`), no executed Bazel sanitizer/TSan run, no passed QEMU
   integration, no passed performance run, no QNX target build/run, no clang-tidy verdict, no SCA
   classification, coverage below the platform goals, no engineering acceptance.
7. **Unresolved findings are inventoried, not resolved (§8).** CodeQL security/MISRA findings
   (`level: null`; dependency findings retained during focused extraction), gitleaks findings,
   focused Cppcheck findings, TSan exit 66, rejected `.clang-tidy` config, 78.6 % focused branch
   coverage, absent Coverity/QNX entitlement, missing requirement/interface links.
8. **No obligation is satisfied (§9).** Every `source-index.json` entry is
   `native_acceptance: not_inferred`; `authority.json` records `engineering_acceptance: pending`,
   `human_reviews: unanswered`, `safety_class: unknown`.

---

## 1. Binding, scope, and the artifact set read

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` — *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:2-4` |
| State | `open`, **0 comments**, no milestone / assignee / labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG`, created/updated `2026-04-14T13:23:24Z` | `.llm_tmp/context/issue-snapshot.json:8,19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**. It distinguishes service-instance identifier = `service id + major + minor + instance
id`; service identifier = `service id + major`; FindService = `service id + major + optional<minor> +
optional<instance>`; and proposes to "exclude the minor version and make it a property of the service
instance". The FindService `major = FF` AUTOSAR case is called theoretically possible but not useful.
There is **no comment and no acceptance record**, so none of it is binding. Binding is **by baseline
commit**, not by run HEAD.

### 1.2 In-scope candidate source paths (context snapshot)

From `.llm_tmp/context/candidate-files.json` (baseline git blobs cross-checked against the `files`
array of `.llm_tmp/context/source-manifest.json`):

| File (repo-relative) | Baseline git blob | Baseline present | Context snapshot sha256 |
|----------------------|-------------------|------------------|-------------------------|
| `score/socom/BUILD` | `3477ea0851fdcd82ec6ea9d71424013cbdf41962` | yes | `dee826163ac5e6336d51a293136b424696c2884aa1b2592395e1e06423c0ba44` |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e22355242009fe20dada2a9a0d0c7a9c7` | yes | `d766902e4bda5306095a6e5326ea91d28df3a6e1ef4e77dc9ba47556ed559a9a` |
| `score/socom/impl/service_identifier.hpp` | `c8bae7908da9f087c518934f7b9f8d86db9a20ec` | yes | `96b33a1fee4d54577ae9bc46c313409a0d59336f76df85ef1925ffebdd1a2119` |
| `score/socom/test/unit/BUILD` | `3c03a7b14286051f97fa5022206564bd63645171` | yes | `9b3c5b341211e2c387858fd1fe5c669a6a422b6e8b5e80fce35ba22c61186799` |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab726db8bf994c960045d6fd7fdf84d7395` | yes | `5e35e24d0abcfa361b5a5283a005b307b86026a970464a3423be7c6eed66631e` |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(none — `null`)* | **no** (manifest expects a **new** file) | `45d073998108df76c8f4534508d65f02cead28aa568cd5c45b5a3d8a4fd36a25` |

The `null` baseline blob is the manifest's expectation of a **new** unit-test file; it exists only in
the un-merged working tree (the task's "cancelled draft"). `glob **/service_identifier*` returns
exactly three paths — `impl/service_identifier.cpp`, `impl/service_identifier.hpp`,
`test/unit/service_identifier_tests.cpp` — so there is **no second, differently-braced copy** of the
header.

### 1.3 Prior reports read and preserved

- `.llm_tmp/overnight/reports/` — read, not modified (all preserved): among others `scope.md`,
  `invariants.md`, `callsites.md`, `reproducer.md`, `key_fix.md`, `unit_matrix.md`, `ordering_tests.md`,
  `runtime_disabled.md`, `runtime_enabled.md`, `lifetime_tests.md`, `conversion_tests.md`,
  `coverage_tests_repair.md`, `native_build_review.md`, `tool_assurance_review.md`,
  `finding_classification.md`, `verification_report_draft.md`, `independent_review_handoff.md`,
  `design_inspection_draft.md`, `misra_applicability.md`, `test_metadata.md`, `sanitizer_review.md`,
  `security_review.md`, `performance_review.md`, `compatibility.md`, `cross_target_review.md`,
  `integration_aou_review.md`, `traceability_review.md`, `deviation_drafts.md`.
- `.llm_tmp/overnight/prior-reports/` — 38 files present and preserved; `evidence_inventory.md` there
  is from an **earlier run** (`01M3YRJEGXNY6CB81T7TKW774B`) in which Bazel was absent (exit `127`)
  and the key suite had 85/87 cases. It is **superseded** by the retained measurements reconciled in
  §3–§6; it is preserved unchanged.
- Derived sequence across the preserved reports: `scope.md` (bounded the slice; identified the
  key/index identity gap) → `invariants.md` (baseline key included `minor`; record index ignores it)
  → `callsites.md` (call-site map) → `reproducer.md` (header brace correction + focused red
  regression) → `key_fix.md` / `unit_matrix.md` (drop `minor`; expand key tests) → `ordering_tests.md`
  → `runtime_disabled.md` / `runtime_enabled.md` / `lifetime_tests.md` → `conversion_tests.md` →
  `test_metadata.md`, followed by the review/hand-off reports listed above.
- **Reconciliation of the brace claims across prior reports.** The earliest reports quote lines 38-39
  as the split-form double close (`}  // namespace socom` + `}  // namespace score`) and record the
  header as **broken**; every later report records it as **already balanced**. The actual source read
  this iteration (§2) matches the later set.

### 1.4 Pinned obligation sources and authority (all read this iteration)

All nine entries of `.llm_tmp/context/obligations/source-index.json` plus
`.llm_tmp/context/obligations/authority.json` were read. Every entry is pinned
`"native_acceptance": "not_inferred"` — pinned, but its applicability to this slice is **not
inferred**.

| id | pinned file | status note |
|----|-------------|-------------|
| `coding_guidelines` | `docs/contribute/development/cpp/coding_guidelines.rst` | `:status: valid`; MISRA C++:2023 with C++17 (`:30-36`, `:74-76`) |
| `code_analysis` | `docs/contribute/development/cpp/code_analysis.rst` | `:status: valid`; clang + Coverity + Sanitizers + memcheck (diagram `:40-89`) |
| `misra_mapping` | `docs/contribute/development/cpp/misra_2023_rule_mapping.rst` | **`:status: draft`** (`misra_mapping.rst:20`); not a valid obligation table |
| `verification_plan` | `docs/platform_management_plan/software_verification.rst` | `:status: valid`; quality criteria incl. criterion 9 "Freedom from compiler warnings & errors" (`:333`); structural statement/branch coverage (`:179-184`) |
| `development_plan` | `docs/platform_management_plan/software_development.rst` | `:status: valid`; C++17, GCC host compiler, QCC target, Bazel |
| `tool_management` | `docs/platform_management_plan/tool_management.rst` | `:status: valid`; tools identified/documented/evaluated and, if applicable, qualified (`:33-48`, `:121`) |
| `verification_process` | `process/process_areas/verification/guidance/verification_process_reqs.rst` | `:status: valid`; `gd_req__verification_link_tests_cpp` (`:57`), `gd_req__verification_independence` (`:142`), `gd_req__verification_checks_extended` (`:199`), `gd_req__verification_external_aou` (`:215`), `gd_req__verification_sca_classification` (`:229`) |
| `verification_guideline` | `process/process_areas/verification/guidance/verification_guideline.rst` | `:status: valid`; traceability, independence, documented results |
| `inspection_checklist` | `score/component_example/docs/detailed_design/chklst_impl_inspection.rst` | **`:status: draft`** (`inspection_checklist.rst:17`); blank template |

**Authority record** (`.llm_tmp/context/obligations/authority.json`): `engineering_acceptance:
pending`; `human_reviews: unanswered`; `safety_class: unknown`; `codeql_scope: "Public Apache-2.0
eclipse-score/inc_someip_gateway; no upload"`; instruction *"Restart the failed queue for one complete
pass through all obligations"*.

**Safety-class note (recorded, not resolved).** The pinned platform documents carry `:safety: ASIL_B`
(e.g. `coding_guidelines.rst:22`), while `authority.json` records `safety_class: unknown` and no
authorized selection exists. The document attribute is **not** a selection of the slice's safety
class and must not be inferred as one.

---

## 2. The recorded syntax failure: inspection of the actual source

### 2.1 Finding (re-verified this iteration by direct `read_file` + `grep`)

`score/socom/impl/service_identifier.hpp` is **brace-balanced**. It is 40 lines; a `grep` for `[{}]`
returns exactly four matches:

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`) and two closers (`:32`, `:38`) give net brace balance `0`. There is **no
third, unmatched closing brace**, and line 39 contains no text. The sibling
`score/socom/impl/service_identifier.cpp` is balanced the same way (braces at `:18`, `:20`, `:30`,
`:32`). The task's "extra closing brace … at line 39" is therefore a **stale, pre-correction
description** that matches the earliest prior reports, not this checkout. The `reproducer` iteration
applied the correction; the removed brace left line 39 blank, exactly as observed here.

### 2.2 Repository convention and retained-compile corroboration

The tree uses two internally-consistent namespace styles:

- **Nested open + single close:** `namespace score::socom {` … one `}  // namespace score::socom`.
  This is the public `service_interface_identifier.hpp`, `impl/service_identifier.cpp`, and the
  flagged header itself.
- **Split open + double close:** `namespace score {` + `namespace socom {` … `}  // namespace socom` +
  `}  // namespace score`. This is `impl/runtime_impl.hpp`.

Retained host compiles of `score/socom/impl/service_identifier.cpp` (which `#include`s the flagged
header) all exit `0`:

- `obligations/compiler_diagnostics/result.json` — `gcc-gtest-0` `0`, `gcc-gtest-1` `0`,
  `gcc-compile` `0`, `gcc-tests` `0`, `clang-gtest-0` `0`, `clang-gtest-1` `0`, `clang-compile` `0`,
  `clang-tests` `0`; status `completed`; limits: *"Focused executable only; GCC 12.3 / Clang 19
  differ from native toolchain pins"*, *"GoogleTest compiled separately with warnings retained;
  -Werror on target and tests"*.
- `obligations/native_build/result.json` — `bazel --batch … build --jobs=2 //...` exit `0`,
  status `completed`, `blockers: []`.
- `.llm_tmp/overnight/validation/before-compile.command.json` and `after-compile.command.json` —
  both `exit_code: 0`; `before/after-compile.stderr` are empty.

### 2.3 Disposition

Applying the historical repair to the already-balanced file would be a no-op at best and a compile
break at worst. **No correction is applied; none is required.** If the *"cancelled draft"* is a
distinct revision that still carries the brace, it is not the file in this checkout and must be
located and corrected by an authorized iteration. Consistent with the write boundary, no test was
expanded either (and the "expanded" tests already exist on disk, §5).

---

## 3. Host-measurement reconciliation (validation artifacts)

### 3.1 The focused red→green measurement

`.llm_tmp/overnight/validation/measurement.json` (copied from the host
`…/runs/score-someip84-factory-oicrb03_/measurements/`):

| Field | Value |
|-------|-------|
| `check_ref` | `check_conversion_tests` |
| `mode` | `ubsan` |
| `status` | `completed` |
| `changed_paths` | `["score/socom/test/unit/service_identifier_tests.cpp"]` |
| `origin` / `initiator` | `local_unprotected_measurement` / `Fabro host hook` |
| `engineering_acceptance` / `full_native_tests` | `pending` / `not_executed` |
| `compiler` / `compiler_sha256` | `/usr/bin/x86_64-linux-gnu-g++-12` / `88315fd2…c196d3` |
| `baseline_with_agent_tests` | `compile_exit 0`, `test_exit 1`, `tests 91`, `failures 33`, `disabled 0` |
| `candidate` | `compile_exit 0`, `test_exit 0`, `tests 91`, `failures 0`, `disabled 0` |
| `check-result` | `0` |

Command detail (`before/after-compile.command.json`, `before/after-test.command.json`): the TU is
**only** `score/socom/impl/service_identifier.cpp` + `score/socom/impl/string_registry.cpp` +
`score/socom/test/unit/service_identifier_tests.cpp` + vendored googletest (`gtest-all.cc`,
`gtest_main.cc`), built with `g++-12 -std=c++17 -Wall -Wextra -Werror -pthread`; the candidate adds
`-fsanitize=undefined -fno-sanitize-recover=all`. It does **not** compile `runtime_tests.cpp`, the
full `socom_test` glob, or any Bazel target.

`before-test.command.json` exit `1`; `after-test.command.json` exit `0`. `before-test.stdout` shows
the 33 failing assertions (all minor-collapse/equivalence cases, lines 178-1124 region);
`after-test.stdout` ends `[  PASSED  ] 91 tests.` Both `before-test.stderr` and
`after-test.stderr` are empty. `after.json` records `tests 91, failures 0`; `before.json` records
`tests 91, failures 33`.

### 3.2 Superseded earlier host-feedback snapshots

Three completed-stage hosts read `validation/measurement.json` earlier in this run and reported
`tests 87 / failures 30` (two nodes) and `tests 91 / failures 33` (one node). The **retained**
artifacts in this checkout (`measurement.json`, `before.json`, `after.json`) are the **91 / 33 → 0**
state, which is the latest. The 87/30 snapshots are consistent with an intermediate tree (87-macro
key suite) and are **superseded**; they must not be quoted as the current measurement.

### 3.3 What this measurement does and does not prove

- **Proves (local, unprotected, scoped):** the corrected `operator<` key turns a focused baseline red
  state (33/91 failures under the pre-correction ordering) green (0/91) in a UBSan-enabled focused
  binary.
- **Does not prove:** `runtime_tests.cpp` execution, the full `socom_test` glob, any Bazel target,
  any sanitizer/TSan verdict, integration, performance, cross-target, or acceptance.

---

## 4. Changed source hashes reconciliation

No local hashing tool was available; the values below are **quoted** from the retained artifacts, not
recomputed. Two captures disagree on every candidate path.

| Candidate path | Context snapshot `candidate-files.json` sha256 | Host/tool-measured sha256 (native_build / process_checks / validation measurement) |
|----------------|-----------------------------------------------|----------------------------------------------------------------------------------|
| `score/socom/BUILD` | `dee82616…23c0ba44` | `68f4645a21e495fac43929fb125f7ba0b9e29fc84c0401fdb95238ffb7fd2cc8` |
| `score/socom/impl/service_identifier.cpp` | `d766902e…ed559a9a` | `3c12b3f1dd3f1fa66cdf43766f374d7d067637bf8f11aba604c4e2688351f11a` |
| `score/socom/impl/service_identifier.hpp` | `96b33a1f…dd1a2119` | `bdce3fcbc3cd78a8ecaece1ea36107d464011ab81c9bc39932d0be617befaea9` |
| `score/socom/test/unit/BUILD` | `9b3c5b34…c61186799` | `e909151e822370bebe8d59b86369bddeb4d6cacfa02f10061bf6e134671ff9d4` |
| `score/socom/test/unit/runtime_tests.cpp` | `5e35e24d…ed66631e` | `9a2d6a154683a2b7ff9d51b7241e4fb74c1a8ef483895830cb409a8f5a1d3127` |
| `score/socom/test/unit/service_identifier_tests.cpp` | `45d07399…a4fd36a25` | `de79767c4653feca7b5b2fcf93f5a791bcc64ae4b554dc2ef35a8756536391e6` |

**Reading.** The host/tool-measured hashes are the authoritative record of what the collector
actually analyzed. The context snapshot hashes describe an earlier (superseded) draft state: the
snapshot's `service_identifier_tests.cpp` hash `45d07399…` corresponds to the 87-macro state recorded
by the earlier `reproducer` iteration, whereas the host-measured `de79767c…` corresponds to the
91-macro state recorded by `process_checks` and reflected on disk today.

**Corroboration by direct read (this iteration):**

- `score/socom/test/unit/service_identifier_tests.cpp` contains **91** `TEST_F` macros under
  `ServiceInstanceIdentifierTest` (`:168` … `:2181`), matching the host-measured 91-test metadata and
  the 91-test measurement — i.e. the host-measured/hash-`de79767c` state, not the 87-macro snapshot.
- `score/socom/test/unit/runtime_tests.cpp` contains **31 `TEST_F`** (`:279`…`:1253`), **1 `TEST`**
  (`:239`) and **1 `TEST_P`** (`:1311`) = **33** test macros, matching `process_checks`
  `metadata_inventory` (`test_macros: 33`).
- `process_checks` `metadata_inventory` records both candidate test files with `record_properties:
  ["DerivationTechnique", "Description"]` only — no `TestType`, no `Verifies`/`PartiallyVerifies`/
  `FullyVerifies`.

The context snapshot set is therefore **stale**; the working tree content matches the host-measured
set. This is a reconciliation of recorded values plus macro-count corroboration, **not** an
independent re-hash.

---

## 5. The bounded registration-key correction (present)

### 5.1 The change (present in `score/socom/impl/service_identifier.cpp:20-30`)

```cpp
return std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major) <
       std::tie(rhs.instance, rhs.interface.id, rhs.interface.version.major);
```

This makes the duplicate-server registration key consistent with the record index. `std::set`
uniqueness is `!(a < b) && !(b < a)`, so identity is exactly `(instance, service id, major)` and
**the minor version is excluded**. The ordering relies only on already-available operators:
`Service_instance::operator<` and `Registry_string_view::operator<`.

The key type is unchanged in representation: `Service_instance_identifier{ Service_interface_identifier
interface; Service_instance instance; }` (`impl/service_identifier.hpp:29-32`), with `operator<` as
its only operator (`:35`; declaration hidden with `\cond`) and **no** `operator==`/`std::hash`. It is
used only as the `std::set` element type (`using Service_identifiers =
Mutexed_variable<std::set<Service_instance_identifier>>`, `impl/runtime_impl.hpp:56`), constructed at
`runtime_impl.cpp:443` and inserted under the key mutex at `:449-454`.

### 5.2 What is preserved

| Rule | Evidence | Preserved |
|------|----------|-----------|
| Interface representation | `Service_interface_identifier{Id id; Version{major, minor}}`, both `std::uint16_t` | yes |
| Exact-major | `major` is an identity component of the key (`service_identifier.cpp:28-29`) and of `is_interface_compatible` | yes |
| Minimum-minor (client minor ≤ server minor) | `is_minor_version_compatible` / `is_interface_compatible`; **not** part of the key | yes |
| `Service_database` minor-ignoring index | `Minor_version_ignoring_key_equal` / `Minor_version_ignoring_hash` untouched | yes |
| Public/ABI surface | the key stays an `impl/`-only type exposed only by the `testonly` `impl_service_identifier` library | yes |
| Ordering-only identity | no `operator==`/`std::hash` added for the key | yes |

### 5.3 Tests and build wiring (already present; no BUILD change)

- `score/socom/BUILD:46-54` defines the `testonly` `impl_service_identifier` library exposing
  `impl/service_identifier.hpp` to `//score/socom/test/unit:__pkg__`, depending on `:socom`.
- `score/socom/test/unit/BUILD:16-29` defines `socom_test` with `srcs = glob(include = ["*.cpp"])`
  and depends on `//score/socom:impl_service_identifier`, `//score/socom:mock`,
  `//score/socom/test/framework:socom_test_framework`, and googletest.
- `runtime_tests.cpp:402-431` carries the runtime minor-only duplicate regression
  `ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError`, driving the real
  `Runtime::make_server_connector()` path and expecting `Construction_error::duplicate_service`.

---

## 6. Host obligation results inventory (retained, not necessarily passing)

All figures below are direct readings of `.llm_tmp/overnight/obligations/*/result.json`. A retained
collection node means results were **retained**, not that checks **passed**.

| Check | `status` | Commands / exit codes | Notes (blockers / limits) |
|-------|----------|-----------------------|---------------------------|
| `native_build` | `completed` | `bazel build --jobs=2 //...` → `0` | `blockers: []`; Bazel 8.6.0; `reused_from` earlier run. Build only (no execution). |
| `native_tests` | `completed` | `bazel test //... --build_tests_only` → `0` | **Build-only**: 29 test targets built, no `Executed N` summary. Built ≠ executed. |
| `native_traceability` | `findings_or_execution_failure` | `bazel test //:unit_tests //:component_tests` → `0`; `bazel run //:docs` → `2`; `//:traceability_gate` → `1` | Unit/component leg ran: `socom_test PASSED in 1.4s`, `Executed 4 out of 4 tests: 4 tests pass.` Docs and traceability legs failed. |
| `native_docs` | `findings_or_execution_failure` | `bazel run //:docs` → `2` | Documentation build failed. |
| `native_lint` | `findings_or_execution_failure` | `//:clang-tidy.check` → `124` (timeout); `//:ruff.check` → `0` | No static-analysis verdict; clang-tidy timed out. |
| `native_coverage` | `completed` | `bazel coverage //...` + report → `0` | Limit: CI `COVERAGE_THRESHOLD=73` is not the platform 85/100 line-and-branch acceptance. |
| `native_sanitizers` | `completed` | `bazel test //score/... //tests/... --build_tests_only --features=asan,lsan,ubsan_clang` → `0` | **Build-only** sanitizer leg; no execution result. |
| `native_tsan` | `completed` | `bazel test //score/... //tests/... --build_tests_only --features=tsan` → `0` | **Build-only** TSan leg; no execution result. |
| `native_integration` | `findings_or_execution_failure` | `bazel test --config=qemu-integration //quality/... //tests/integration_test/...` → `1` | QEMU/KVM present (`kvm_exists: true`); integration still failed. |
| `native_performance` | `findings_or_execution_failure` | benchmarks → `124`; profiling → `124` | Both timed out. |
| `cross_compilation` | `completed_with_blockers` | `--config=x86_64-linux` → `0`; `--config=aarch64-linux` → `0` | Blocker: *"QNX SDK entitlement and target execution not configured; no credential acquired"*. |
| `compiler_diagnostics` | `completed` | GCC 12 (`-Werror`) compile/tests → `0`; Clang 19 (`-Werror`) compile/tests → `0` | Limits: focused executable only; GCC 12.3 / Clang 19 differ from native toolchain pins; googletest warnings retained. |
| `format_precommit` | `findings_or_execution_failure` | `git-init` `0`, `git-add` `0`, `format.check` `124`, `pre-commit` `0`, `reuse lint` `1`, `bazel mod tidy` `0`, lockfile `0` | Format check timed out; `reuse lint` failed. Limit: mutations only in the disposable collector copy. |
| `secret_dependency_checks` | `findings_or_execution_failure` | `gitleaks dir …` → `1` | Blocker: no adopted vulnerability DB/ecosystem mapping or GitHub dependency scan receipt; dependency inventory ≠ vulnerability scan. |
| `tool_assurance` | `completed_with_blockers` | `version-0`…`version-14` → `0` | Blockers: tool confidence/qualification/acceptance require authorized humans; Coverity not installed/adopted; memcheck is optional. |
| `codeql_security` | `findings_or_execution_failure` | `codeql database create` → `0`; `database analyze` (`cpp-security-and-quality.qls`) → `0` | `blockers: []`; limit: *"Focused linked executable, not full target extraction; dependency findings retained"*. SARIF findings retained. |
| `codeql_misra` | `findings_or_execution_failure` | `codeql database create` → `0`; `database analyze` (`misra-cpp-default.qls`) → `0` | Blockers: *"MISRA applicability/mapping draft and incomplete"*, *"Default suite omits manual/audit obligations"*, *"Compiled query qualification and human deviations pending"*; same focused-extraction limit. Large retained finding set (incl. googletest dependency findings). |
| `focused_asan_lsan` | `completed` | focused compile → `0`; focused tests → `0` | Limit: focused identifier executable; full native runtime scope measured separately. |
| `focused_tsan` | `findings_or_execution_failure` | focused compile → `0`; focused tests → `66` | Non-zero TSan execution; not a pass. |
| `focused_memcheck` | `completed` | focused compile → `0`; `valgrind --tool=memcheck --error-exitcode=42` → `0` | Limit: optional complementary focused memory analysis. |
| `focused_coverage` | `completed` | focused compile → `0`; tests → `0`; `gcovr` → `0` | `coverage-summary.json`: line 36/36 (**100.0 %**), branch 11/14 (**78.6 %**). `service_identifier.cpp`: 3/3 line, 1/2 branch. |
| `focused_clang_tidy` | `findings_or_execution_failure` | `clang-tidy --verify-config --config-file=.clang-tidy` → `1` | Blocker: *"Native analyzer configuration incompatible; no replacement called MISRA"*. Record as **not run**, never "clean". |
| `focused_cppcheck` | `findings_or_execution_failure` | `cppcheck --error-exitcode=2 …` → `2` | Blockers: none; limit: *"Optional complementary checks; no inferred MISRA rule coverage"*. |
| `process_checks` | `completed_with_blockers` | no commands | Blockers: lexical metadata inventory cannot prove semantic requirement coverage; safety/QM applicability unknown; independent inspection/acceptance required; external AoU and full integration require scoped review. Metadata: `runtime_tests.cpp` 33 macros, `service_identifier_tests.cpp` 91 macros, each only `DerivationTechnique`/`Description`. |
| `rework_progress` | `completed` | no commands | `source_changed_this_round: false`, `rework_requested: false`, stop reason *"One complete pass requested; unresolved findings stay pending"*. |

### 6.1 Genuine executed results (local, unprotected, scoped)

- `native_build`: `bazel build //...` exit `0`, `blockers: []`.
- `native_traceability` `unit-component-tests`: `bazel test //:unit_tests //:component_tests` exit
  `0`; `//score/socom/test/unit:socom_test PASSED`; `Executed 4 out of 4 tests: 4 tests pass.`
- `cross_compilation`: x86_64 and aarch64 Bazel builds exit `0`.
- `compiler_diagnostics`: GCC/Clang focused `-Werror` compile+tests all exit `0`.
- Focused `validation` measurement: candidate 91/0 vs baseline 33 failures, UBSan.
- `focused_asan_lsan`, `focused_memcheck`: exit `0`.
- `format_precommit`: `pre-commit`, module tidy, lockfile exit `0`.

### 6.2 Genuine runs that did not pass

| Check | Command | Exit | Class |
|-------|---------|------|-------|
| `native_docs` / `native_traceability` docs | `bazel run //:docs` | `2` | documentation build failure |
| `native_traceability` traceability | `//:traceability_gate -- --need-type=comp_req` | `1` | traceability gate failure |
| `native_integration` | `bazel test --config=qemu-integration …` | `1` | integration failure |
| `native_performance` | benchmarks / profiling | `124` / `124` | timeout |
| `native_lint` | `//:clang-tidy.check` | `124` | timeout |
| `format_precommit` | `//:format.check`; `reuse lint` | `124`; `1` | timeout; licence/reuse failure |
| `focused_tsan` | TSan executable | `66` | execution failure |
| `focused_clang_tidy` | `clang-tidy --verify-config` | `1` | configuration rejected |
| `focused_cppcheck` | `cppcheck` focused | `2` | findings |
| `secret_dependency_checks` | `gitleaks dir …` | `1` | findings |

### 6.3 Build-only legs (compiled, not executed)

`native_tests`, `native_sanitizers`, and `native_tsan` all use `--build_tests_only`; they compile
configured test targets and produce **no** executed-test summary. `native_performance` also uses
`--build_tests_only` but timed out before completing the build.

### 6.4 Selected tool/target identity (from `tool_assurance` and per-check command JSON)

| Role | Identity | Available |
|------|----------|-----------|
| Bazel driver | `…/score-someip84-tools-…/bin/bazel`, `bazel 8.6.0` (`USE_BAZEL_VERSION=8.6.0`) | yes |
| Host C++ compiler (focused) | `/usr/bin/x86_64-linux-gnu-g++-12`, sha256 `88315fd2…c196d3` | yes |
| Clang compiler | `…/llvm-19.1.7/…/clang++` | yes |
| clang-tidy | `…/llvm-19.1.7/…/clang-tidy` (incompatible config) | yes |
| CodeQL | `…/codeql-2.21.4/codeql/codeql` | yes |
| gcov / gcovr | `/usr/bin/gcov-12`, `/usr/bin/gcovr` | yes |
| valgrind | `…/bin/valgrind` | yes |
| gitleaks | `…/bin/gitleaks` | yes |
| pre-commit / reuse | `…/bin/pre-commit`, `…/bin/reuse` | yes |
| QEMU | `/usr/bin/qemu-system-x86_64`, `kvm_exists: true` | yes (integration still failed) |
| Coverity | — | **no** (`tool_assurance` blocker) |

**Tool identification is not tool qualification.** `tool_assurance` blockers state that confidence
evaluation, qualification where applicable, and acceptance require authorized humans.

---

## 7. Remaining full-runtime checks (pending, not passed)

The following are **not established** by anything retained in this checkout:

1. **True `bazel test //...` execution** (without `--build_tests_only`). The strongest executed
   native result is `bazel test //:unit_tests //:component_tests` (`socom_test PASSED`), which
   includes `runtime_tests.cpp` via the `socom_test` glob — but it is not `//...` and
   `measurement.json` still records `full_native_tests: not_executed`.
2. **Executed Bazel sanitizer / ASan / LSan / UBSan / TSan runs** — the Bazel legs are build-only;
   the focused ASan/LSan/UBSan binary is narrow and the focused TSan execution failed (`66`).
3. **QEMU integration** — exit `1` with KVM/QEMU present.
4. **Performance / profiling** — both timed out (`124`).
5. **QNX target build/execution** — QNX entitlement not configured; only x86_64/aarch64 host builds
   ran.
6. **clang-tidy static analysis** — configuration rejected; native leg timed out. No verdict.
7. **CodeQL SCA classification** — findings retained but not classified; no authorized severity
   rating; MISRA mapping is a draft.
8. **Coverage goals** — focused branch 78.6 % is below the platform 85/100 goals and
   `complete_target_scope` is false.
9. **Docs and traceability** — `//:docs` exit `2`; traceability gate exit `1`; candidate test records
   carry only `DerivationTechnique`/`Description`.
10. **Requirement link** — no verified native requirement/interface identifier exists for this slice;
    `TestType` and `Verifies` links are deliberately unset (not fabricated).
11. **Secret/dependency adjudication** — gitleaks findings not dispositioned; no vulnerability DB.
12. **Engineering acceptance and independent human review** — unanswered/pending.
13. **Safety class** — unknown; no authorized selection.

---

## 8. Unresolved findings inventory (not resolved)

| # | Finding | Evidence | Disposition |
|---|---------|----------|-------------|
| F-1 | Recorded "extra closing brace at `service_identifier.hpp:39`" | Actual header balanced; all retained compiles exit `0` | **Stale**; no source defect in this checkout |
| F-2 | CodeQL security findings retained | `codeql_security/result.json` (analyze exit `0`); `level: null`; dependency findings retained | **Unclassified**; no authorized severity; focused extraction limit |
| F-3 | CodeQL MISRA findings retained (large set incl. googletest) | `codeql_misra/result.json`; blockers listed in §6 | **Unclassified**; mapping draft; query qualification/deviation pending |
| F-4 | gitleaks findings | `secret_dependency_checks/result.json` exit `1`; findings in tool artifacts and `quality/integration_testing/environments/qnx8_qemu/init_x86_64.build` | **Not dispositioned**; blocker recorded; no vuln DB |
| F-5 | focused Cppcheck findings | `focused_cppcheck/result.json` exit `2` | Optional complementary; no inferred MISRA coverage |
| F-6 | focused TSan execution failure | `focused_tsan/result.json` tests exit `66` | **Failed**; no concurrency verdict |
| F-7 | clang-tidy configuration rejected | `focused_clang_tidy/result.json` exit `1` | **Not run**, not "clean" |
| F-8 | Branch coverage below goals | `focused_coverage/coverage-summary.json` 78.6 % | **Below** 85/100; `complete_target_scope: false` |
| F-9 | QNX entitlement / target execution | `cross_compilation/result.json` blocker | **Platform gap** |
| F-10 | Coverity absent | `tool_assurance` blocker | **Not installed/adopted** |
| F-11 | Traceability/test-record links absent | `process_checks` metadata; `native_traceability` gate exit `1` | **Missing**; no invented identifiers |
| F-12 | `//:docs`, `format.check`, `reuse lint` failures | `native_docs` `2`; `format_precommit` `124`/`1` | **Not passing** |
| F-13 | Safety class unknown; human reviews unanswered; acceptance pending | `authority.json` | **Unresolved authority gate** |

---

## 9. Obligation status (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Freedom from compiler warnings & errors (100 %, criterion 9) | `verification_plan.rst:333` | **NOT ESTABLISHED** — focused GCC/Clang clean with `-Werror`; default native build disables warnings-as-errors (`.bazelrc:117`); `format.check` timed out |
| Native build (`bazel build //...`) | `AGENTS.md`; `development_plan.rst` | **RAN, exit 0** (local, unprotected) — not acceptance, not warnings-as-errors |
| Native test execution | `verification_plan.rst` (criteria 6-7) | **PARTIAL** — `//:unit_tests //:component_tests` executed and `socom_test` PASSED; `//...` was build-only; `full_native_tests: not_executed` |
| Native sanitizer / TSan execution | `code_analysis.rst` | **NOT EXECUTED at Bazel scope** — legs build-only; focused TSan exit `66` |
| Static code analysis (clang-tidy / CodeQL) | `code_analysis.rst` | **NOT SATISFIED** — clang-tidy config rejected and native leg timed out; CodeQL findings retained but unclassified |
| SCA findings classified Critical/High/Medium/Low | `verification_process.rst` (`gd_req__verification_sca_classification`) | **NOT DONE** — no authorized classification |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` *(draft)* | **UNKNOWN — NOT CLAIMED** |
| Structural statement / branch coverage goals | `verification_plan.rst` (`:179-184`) | **NOT MET** — focused 100 % line / 78.6 % branch; `complete_target_scope: false` |
| Native integration / QEMU | `verification_process.rst` | **NOT PASSED** — exit `1` (KVM/QEMU present) |
| Native performance / profiling | `verification_plan.rst` | **NOT PASSED** — both timed out (`124`) |
| Cross-compilation (x86_64 / aarch64) | `development_plan.rst` | **RAN, exit 0** (both); QNX entitlement blocker remains |
| Documentation build | `verification_guideline.rst` | **NOT PASSED** — `//:docs` exit `2` |
| Traceability gate | `verification_process.rst` (`gd_req__verification_link_tests_cpp`) | **NOT PASSED** — exit `1`; test records carry only `DerivationTechnique`/`Description` |
| Format / pre-commit / reuse / module lock | `.pre-commit-config.yaml`; `REUSE.toml` | **PARTIAL** — pre-commit/module tidy/lockfile `0`; `format.check` `124`; `reuse lint` `1` |
| Secret / dependency scan | `tool_management.rst` | **NOT SATISFIED** — gitleaks findings; no vuln DB/receipt |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED for this slice** — qualification requires authorized humans; Coverity absent |
| Independence of verification / review | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Implementation inspection checklist IMPL_01…IMPL_03 | `inspection_checklist.rst` *(draft)* | **NOT FILLED** |
| Obligation collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **RETAINED, NOT PASSING** |
| Native acceptance | `source-index.json` | **`not_inferred` for every entry** |

**Explicit non-satisfaction statement.** The clang-tidy configuration blocker and native timeout, the
build-only sanitizer/TSan legs, the failed docs/traceability/integration/performance/format/reuse
checks, the below-goal branch coverage, the absent Coverity and QNX entitlement, the unclassified
CodeQL/secret findings, the unknown safety class, and the unanswered human reviews mean **none of the
checked obligations may be treated as satisfied**. A retained collection result shows *retention*, not
passing; a build-only leg shows *compilation*, not execution; a tool that produced no finding because
it did not run is *not run*, not *clean*.

---

## 10. Notice preservation

- No source, build, test, config, `NOTICE`, `LICENSE`, `REUSE.toml`, validation, obligation, or
  prior-report file was created, edited, or deleted by this iteration; **only this report was
  written.**
- The flagged header `score/socom/impl/service_identifier.hpp` was inspected and left unchanged; it
  retains its Apache-2.0/SPDX comment (`:1-12`) and is already balanced (§2). The sibling
  `service_identifier.cpp`, both BUILD files, and both candidate test files retain their Apache-2.0 /
  SPDX headers.
- All files under `.llm_tmp/overnight/reports/` and `.llm_tmp/overnight/prior-reports/` were
  preserved unchanged; this document is a new `reports/` entry (the prior
  `prior-reports/evidence_inventory.md` from the earlier run is preserved and superseded).
- This report itself carries the Apache-2.0 header. No licensed MISRA rule text is reproduced; only
  native rule/query identifiers, file locations, and prior-report readings are cited.

---

## 11. Pending human review checklist

- [ ] **Confirm §2:** `service_identifier.hpp` is brace-balanced (braces at `:19,:29,:32,:38`; line
      39 blank; net balance `0`), and all retained GCC/Clang `-Werror` focused compiles, the focused
      measurement compile, and the native `bazel build //...` exit `0`. The recorded "extra closing
      brace at line 39" is stale or refers to a distinct revision; if a distinct "cancelled draft"
      still carries the brace, locate and correct it by an authorized iteration.
- [ ] **Resolve the instruction conflict:** "Inspect and correct the actual source" vs. "This is a
      review draft: only that report may be written"; confirm that writing only this report was
      intended and the no-op on already-correct source is acceptable.
- [ ] **Confirm the reconciliation in §3–§4:** the retained 91-test / 33-failure → 0-failure focused
      measurement is the latest; the earlier 87/30 snapshots are superseded; the host-measured hash
      set (not the `candidate-files.json` snapshot set) describes the analyzed tree; and 91 `TEST_F`
      + 33 runtime macros corroborate it.
- [ ] **Confirm the bounded key decision (§5):** `minor` is **not** part of the duplicate-server
      registration key; identity is `(instance, service id, major)`; interface representation and the
      exact-major / minimum-minor rules are unchanged.
- [ ] **Decide whether a true `bazel test //...` execution** (without `--build_tests_only`) is required
      before any "tests pass" claim beyond the executed `//:unit_tests //:component_tests`
      (`socom_test` PASSED), and whether executed Bazel sanitizer/TSan runs are required.
- [ ] **Repair/disposition the failed legs:** `//:docs` (`2`), traceability gate (`1`), QEMU
      integration (`1`), performance/profiling (`124`), `format.check` (`124`), `reuse lint` (`1`),
      focused TSan (`66`).
- [ ] **Restore a usable clang-tidy configuration** and obtain a real static-analysis verdict;
      disposition the Coverity absence and the `.bazelrc:117` warnings-as-errors posture.
- [ ] **Classify the CodeQL / MISRA / secret / Cppcheck findings** under the mandated SCA
      classification, or record applicability as unresolved; activate the MISRA mapping (currently
      `:status: draft`).
- [ ] **Resolve the QNX entitlement gap** for the QNX target build/execution.
- [ ] **Select the safety class** via the authorized role; do not infer it from the `:safety: ASIL_B`
      document attribute.
- [ ] **Supply native requirement/traceability identifiers** (no invented links), then schedule
      independent human review (approver ≠ author per `gd_req__verification_independence`) and record
      engineering acceptance.
- [ ] **Keep the wider #84 public `Service_interface_identifier` restructure, FindService wildcard
      handling, and the config minor-wildcard narrowing out of this bounded slice** until separately
      accepted, and do not present the identifier-only tests as full platform validation.

---

*End of evidence inventory review draft. Local, unprotected, scoped. No engineering acceptance;
human reviews unanswered; full native runtime tests pending. The native `//...` build and the executed
`//:unit_tests //:component_tests` (`socom_test` PASSED) are genuine local results but are not
acceptance and do not cover the build-only sanitizer/TSan legs, the failed docs/traceability/
integration/performance/format/reuse legs, or the missing clang-tidy/Coverity/QNX/warnings-as-errors
evidence. The focused GCC/UBSan pass is not full native readiness; no finding was filtered and no
authorized severity rating exists.*
