<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — MISRA C++:2023 applicability assessment (`misra_applicability`) review draft

**Document type:** review draft — pinned-requirement reading + licensed-source reading + measured-CodeQL-result reading + MISRA C++:2023 applicability assessment.

**Date:** 2026-10-03
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version handling in socom* (issue #84)
**Run / branch:** `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ`
**Verified baseline commit:** `f8a196c3b16d5172d898394ab99b0ed81346d63d` (`.llm_tmp/context/source-manifest.json:3`)

**Status:** **local, unprotected, scoped. No engineering acceptance exists. Human reviews are unanswered. Full native runtime tests are pending.** Every statement below is either a direct static reading of this checkout, a reading of a retained artifact under `.llm_tmp/overnight/`, or an explicitly-labelled logical consequence. Nothing here is published, reviewed, accepted, or a full native run. **No MISRA C++:2023 compliance is claimed, and no MISRA rule is asserted to "apply" to the deliverable in the process sense.**

> **Tool / write boundary observed.** This iteration used only `read_file`, `grep`, `glob`, and `write_file`. No `shell`, no `edit_file`, no delegation, no web access, no approval, no publishing, and no engineering acceptance was performed. **Exactly one file was written — this report** (`/workspace/.llm_tmp/overnight/reports/misra_applicability.md`). No source, build, test, config, `NOTICE`, `LICENSE`, `REUSE.toml`, prior-report, or obligation/validation artifact was created, edited, or deleted.
>
> **Source-correction instruction vs. review-draft boundary (recorded, not silently resolved).** The task records *"a measured GCC syntax failure: an extra closing brace in `score/socom/impl/service_identifier.hpp` at line 39"* and directs *"Inspect and correct the actual source before expanding tests"*, while the final sentence says *"This is a review draft: only that report may be written."* Direct inspection of the *actual* working tree (§4) shows the header is **already brace-balanced**, line 39 is blank, and the retained focused compiler legs exit `0` (§7). There is no unmatched brace to remove. The final sentence forbids a source write; the conflict is recorded for the human reviewer (§10) and **no source was edited**. No test was expanded either — the draft's suites already exist on disk.
>
> **Non-satisfaction rule applied throughout.** A successful obligation-collection node means the results were **retained**, not that the checks **passed**. Missing tools, unknown applicability, incomplete extraction, an inactive/draft rule mapping, unclassified findings, and unanswered human reviews are **not** treated as satisfied. A tool that did not run is recorded as *"not run"*, never as *"clean"*.

---

## 0. Summary

1. **The governing MISRA C++:2023 requirement is valid; the rule mapping is a draft with no active CSV (§3).** `coding_guidelines.rst` is `:status: valid` and selects **MISRA C++:2023 with C++17** (`:30-36`, `:74`). `misra_mapping.rst` is `:status: draft` (`:20`) and its only content is a `csv-table` directive **inside an RST comment** referencing `_assets/misra_2023.csv` (`:26-31`); `glob` finds **no** such CSV and no second mapping file. In-repo, therefore, **no MISRA rule is mapped to any tool**; the only active mapping evidence is the licensed CodeQL coding-standards pack's own annotations (§5, §6).
2. **Licensed source references are identified, and proprietary rule text is not reproduced (§5).** The measured run used the licensed **CodeQL coding-standards `2.61.0`** pack (`codeql-coding-standards-2.61.0`) and its `misra-cpp-default.qls` suite with the CodeQL **`2.21.4`** engine, under the recorded scope *"Public Apache-2.0 eclipse-score/inc_someip_gateway only"* with **no upload** (`authority.json`; `codeql_misra/result.json:1119-1122`). Only rule identifiers, tool query ids, and locations are cited; the MISRA rule statements themselves (licensed, proprietary) are deliberately not reproduced.
3. **The measured CodeQL MISRA result is real but scoped and incomplete (§6).** `database create` and `analyze` both exit `0`; the suite loaded **218 compiled queries** and exported SARIF (`codeql_misra/analyze.stderr:879`). The collector records `status: findings_or_execution_failure` with three self-declared blockers and the extraction limit *"Focused linked executable, not full target extraction; dependency findings retained"* (`codeql_misra/result.json:1052-1056`, `:1117`, `:121519-121521`).
4. **Findings land in three buckets (§6).** (a) *Dependency* locations under `.llm_tmp/googletest/**` (not project code). (b) *Repository code in the focused build* — the candidate test file `score/socom/test/unit/service_identifier_tests.cpp`, plus the transitive public headers `score/socom/service_interface_identifier.hpp` and `score/socom/registry_string_view.hpp`, plus `score/socom/impl/string_registry.cpp` and `score/socom/string_registry.hpp`. (c) No finding lands in the slice's own new/changed operator files `score/socom/impl/service_identifier.cpp` / `.hpp`, nor in `runtime_impl.*`, `server_connector_impl.*`, `client_connector_impl.*`, `error.hpp`, or `final_action.hpp`.
5. **Correction to the earlier retained reading.** The prior `prior-reports/misra_applicability.md` recorded *zero* findings in `service_interface_identifier.hpp` and `registry_string_view.hpp`. The **retained result read this iteration does flag both** (7 and 4 locations respectively, §6.3). This report records the current reading; the earlier report is preserved unchanged but is superseded on this point.
6. **Applicability is largely unresolved (§7).** The slice's own operator unit is clean in this extraction, but the safety class is `unknown`, every rule is unmapped in-repo, the extraction is focused, `runtime_tests.cpp` was **not extracted**, the manual/audit obligations were **not run**, and several repository-header findings are unresolved. **MISRA C++:2023 compliance is UNKNOWN and is not claimed.**
7. **No obligation is satisfied (§8).** Every `source-index.json` entry is `native_acceptance: not_inferred`; `authority.json` records `engineering_acceptance: pending`, `human_reviews: unanswered`, `safety_class: unknown`.

---

## 1. Binding, prior reports, host feedback, obligation artifacts

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` — *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:2-4` |
| State | `open`, **0 comments**, no milestone / assignee / labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` | `.llm_tmp/context/issue-snapshot.json:19-20` |
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted obligation**: service-instance identifier = `service id + major + minor + instance id`; service identifier = `service id + major`; FindService = `service id + major + optional<minor> + optional<instance>`; and the proposal to *"exclude the minor version and make it a property of the service instance"*. There is **no comment and no acceptance record**, so none of it is binding. Binding is **by baseline commit**, not by run HEAD.

### 1.2 Candidate paths

From `.llm_tmp/context/candidate-files.json:1-25`, cross-checked against `.llm_tmp/context/source-manifest.json`:

1. `score/socom/BUILD`
2. `score/socom/impl/service_identifier.cpp`
3. `score/socom/impl/service_identifier.hpp`
4. `score/socom/test/unit/BUILD`
5. `score/socom/test/unit/runtime_tests.cpp`
6. `score/socom/test/unit/service_identifier_tests.cpp` (baseline blob `null` — a **new** file)

`glob **/service_identifier.hpp` returns exactly one path, so there is no second, differently-braced header in this checkout. The focused CodeQL extraction compiled `service_identifier.cpp`, `string_registry.cpp`, and `service_identifier_tests.cpp` (plus vendored googletest); it did **not** compile `runtime_tests.cpp` or the full `//score/...` target set.

### 1.3 Pinned obligation sources read and preserved

All nine entries of `.llm_tmp/context/obligations/source-index.json` were read with `authority.json`:

| id | file | status |
|----|------|--------|
| `coding_guidelines` | `coding_guidelines.rst` | `:status: valid`; **MISRA C++:2023 with C++17** (`:30-36`, `:74`) |
| `code_analysis` | `code_analysis.rst` | `:status: valid`; MISRA/ISO 26262-based SCA; mapping + in-source justification required |
| `misra_mapping` | `misra_mapping.rst` | **`:status: draft`; rule `csv-table` commented out; CSV absent** |
| `verification_plan` | `verification_plan.rst` | `:status: valid`; quality criteria 1–9 |
| `development_plan` | `development_plan.rst` | `:status: valid` |
| `tool_management` | `tool_management.rst` | `:status: valid`; identify / evaluate / qualify |
| `verification_process` | `verification_process.rst` | `:status: valid`; SCA classification, test links |
| `verification_guideline` | `verification_guideline.rst` | `:status: valid` |
| `inspection_checklist` | `inspection_checklist.rst` | **`:status: draft`, blank `IMPL_01_…`…`IMPL_03_…`** |

`authority.json`: `codeql_scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload"`, `engineering_acceptance: pending`, `human_reviews: unanswered`, `safety_class: unknown`, `instruction: "Restart the failed queue for one complete pass through all obligations"`. Every `source-index.json` entry is `native_acceptance: not_inferred`.

### 1.4 Prior reports, host feedback, obligation artifacts available *this* checkout

- **`.llm_tmp/overnight/prior-reports/` — 38 files present**, all read/cross-checked and preserved. The most directly relevant are `misra_applicability.md`, `misra_manual_review.md`, `analyzer_plan.md`, `tool_findings_repair.md`, `finding_classification.md`, and `tool_assurance_review.md`. The earlier `misra_applicability.md` is superseded only on the point recorded in §0.5 / §6.3; it remains otherwise admissible.
- **`.llm_tmp/overnight/reports/`** — 22 files present before this write; this document adds `misra_applicability.md` (23rd). All earlier entries preserved.
- **`.llm_tmp/overnight/validation/`** — present: `check-result` = `0` (collector marker only); `measurement.json` (`check_ref: check_conversion_tests`, `mode: ubsan`, `origin: local_unprotected_measurement`, `initiator: Fabro host hook`, `engineering_acceptance: pending`, `full_native_tests: not_executed`, compiler `/usr/bin/x86_64-linux-gnu-g++-12`; `baseline_with_agent_tests` **91 tests / 33 failures / compile 0**; `candidate` **91 tests / 0 failures / compile 0** — `measurement.json:2042-2058`); focused `before-*`/`after-*` captures.
  - **Scope caveat:** the measured `changed_paths` is only `score/socom/test/unit/service_identifier_tests.cpp` (`measurement.json:5-7`); the 91 tests are the identifier suite. `runtime_tests.cpp` (33 macros) is **not** compiled or executed by this measurement.
- **`.llm_tmp/overnight/obligations/`** — 25 checks retained, each `origin: local_unprotected_measurement`, `engineering_acceptance: pending`. **Retention is not passing.** Relevant statuses are tabulated in §7.1.

---

## 2. What "applicable" means for this draft

Because `misra_mapping.rst` is a draft with no active CSV (§3.3), this report does **not** claim that a MISRA C++:2023 rule is "applicable to the deliverable" in the process sense. It records, per observed rule:

- the **rule identifier** taken from the licensed pack's own query directory (e.g. `RULE-6-5-1`), not from the S-CORE mapping;
- the pack's **query id** (e.g. `cpp/misra/external-linkage-not-declared-in-header-file-misra`);
- **where it landed** in the focused extraction;
- **whether it can support a compliance statement** — here, **no**.

The applicable acceptance level (QM vs. safety) is also not selected (`safety_class: unknown`), so even a clean automated result could not be translated into an acceptance decision.

---

## 3. Governing MISRA C++:2023 requirements (pinned)

### 3.1 Coding guidelines — valid, MISRA C++:2023 with C++17

`coding_guidelines.rst` (`:status: valid`, `:id: doc__cpp_coding_guidelines`, `:safety: ASIL_B`) states at `:30-36` that S-CORE adheres to **MISRA C++:2023**, designed for C++17, and at `:74` that **C++17 is the selected standard**. C++20 features require prior process-community evaluation (`:76-80`). Error handling is through `score::Result`, value-encoded errors are discouraged, throwing is avoided (hardwired to abort), and aborts are a last resort (`:117-129`).

### 3.2 Code analysis — valid, MISRA-based SCA with mandated mapping and disposition

`code_analysis.rst` (`:status: valid`) requires a Static Code Analysis concept based on **MISRA and ISO 26262** (`:30`), with a **rule mapping** to tool rules/queries (`:32`), and states at `:51`: *"If for some technical reason any MISRA finding can not be addressed it needs to be justified appropriately … and finally documented within the source code."* The named tool set is clang-tidy + GCC/Clang compiler warnings + Coverity (`:34-47`).

### 3.3 The rule mapping — draft, no active CSV

`misra_mapping.rst`:

- `:status: draft` (`:20`), `:safety: ASIL_B`, `:version: 1`.
- Its only content is a `csv-table` directive **inside an RST comment block** (`:26-31`): `.. csv-table:: MISRA C++:2023 Rule Mapping` with `:file: _assets/misra_2023.csv`.
- `glob` finds **no** `_assets/**` and **no** second `*misra*` file; the referenced CSV is **absent** and the table is **inactive**.

**Consequence:** in-repo there is **no active linkage from MISRA rules to tool rules/queries**. The mapping is effectively *unmapped for every MISRA rule* until the draft is completed, the CSV supplied, and the document raised to `:status: valid` by an authorized change.

### 3.4 Verification plan/process — static analysis is a verification method; findings must be classified

- `verification_plan.rst:328-335`: criterion 8 = freedom from static-code-analysis violations (critical/high) at 100 % (QM: no remaining critical findings; safety: no remaining critical or high severity); criterion 9 = freedom from compiler warnings & errors at 100 %.
- `verification_process.rst:228-248` (`gd_req__verification_sca_classification`): SCA findings shall be classified **Critical / High / Medium / Low**, either by the tool as a suggestion or manually by the quality manager together with a committer.
- `verification_process.rst:20-54` (`gd_req__verification_link_tests*`): test record properties (`TestType`, `DerivationTechnique`, `Description`, `Verifies`).

### 3.5 Tool management — identification / evaluation / qualification

`tool_management.rst` (`:status: valid`) requires every tool to be identified, evaluated (tool confidence level), and, where the TCL is LOW, **qualified**, with a released Tool Verification Report (`:32-37`, `:45-49`). No MISRA-capable tool has a released tool verification report for this slice, so tool confidence is not established here.

---

## 4. The recorded GCC syntax failure: inspection of the actual source

`score/socom/impl/service_identifier.hpp` read directly from the working tree is **brace-balanced** and 40 lines:

| Line | Content | Role |
|------|---------|------|
| 14–15 | `#ifndef SRC_SOCOM_SRC_SERVICE_IDENTIFIER` / `#define …` | include guard |
| 17 | `#include "score/socom/service_interface_identifier.hpp"` | include |
| 19 | `namespace score::socom {` | one opening brace |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers and two closers give net brace balance `0`; line 39 is blank. The described "extra closing brace at line 39" matches the **earliest** prior reports' split-form close (`}  // namespace socom` + `}  // namespace score`), which the `reproducer` iteration corrected; the sibling `score/socom/impl/service_identifier.cpp` uses the same nested form (`:18` / `:32`) and is balanced. **No correction was applied and none is required** (and the review-draft boundary forbade a source write). The minimal historical repair (replacing a split double close with the single nested form) would be a no-op at best and a compile break at worst. If a distinct "cancelled draft" revision still carries the brace, it is not the file in this checkout and must be located and corrected by an authorized iteration.

---

## 5. Licensed source references (and why rule text is not reproduced)

| Aspect | Value | Source |
|--------|-------|--------|
| Licensed analysis pack | **CodeQL coding-standards `2.61.0`** (`/home/jefferson/.local/share/s-core-tools/codeql-coding-standards-2.61.0`) | `codeql_misra/result.json:1094`; `analyze.stderr` |
| Query suite | `codeql-suites/misra-cpp-default.qls` | `codeql_misra/result.json:1094` |
| Query engine | CodeQL **`2.21.4`** (`/home/jefferson/.local/share/s-core-tools/codeql-2.21.4`) | `codeql_misra/result.json:1061,1090` |
| Recorded licensing scope | *"Public Apache-2.0 eclipse-score/inc_someip_gateway only"* | `codeql_misra/result.json:1119-1122` |
| Recorded licensing source | `https://docs.github.com/en/code-security/concepts/code-scanning/codeql/codeql-cli` | `codeql_misra/result.json:1121` |
| Authority scope | `codeql_scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload"` | `.llm_tmp/context/obligations/authority.json:2` |

The **MISRA C++:2023 rule text is licensed / proprietary**. This report therefore cites only:

- **MISRA rule identifiers** and **CodeQL query ids** and their **locations**; and
- the pack's own machine-readable query paths (e.g. `RULE-6-5-1/ExternalLinkageNotDeclaredInHeaderFileMisra`).

It does **not** reproduce the standard's rule statements, rationale, or examples. A short paraphrase of the tool's own already-published check name is used only as a label; the authoritative text must be read in the licensed MISRA C++:2023 document.

The mapping used here is therefore the **licensed pack's internal mapping** (query → MISRA rule identifier), **not** the S-CORE `misra_mapping.rst`, which is inactive (§3.3). This is a methodological substitution that a reviewer must accept before the assessment has process standing.

---

## 6. Measured CodeQL MISRA results (as retained)

### 6.1 Run shape and collector status

- `codeql database create … --language=cpp --command=<focused codeql-build.sh>` → **exit `0`** (`database-create.stderr:16`).
- `codeql database analyze <db> misra-cpp-default.qls --format=sarif-latest` → **exit `0`**; `analyze.stderr` shows `Loaded … [1/218] … [218/218]` compiled queries, per-query evaluation, and `Exported results to SARIF (205ms)` (`analyze.stderr:879`).
- `status: findings_or_execution_failure` (`result.json:1117`).
- Blockers (`result.json:1052-1056`):
  *"MISRA applicability/mapping draft and incomplete"*, *"Default suite omits manual/audit obligations"*, *"Compiled query qualification and human deviations pending"*.
- Limit (`result.json:121519-121521`): *"Focused linked executable, not full target extraction; dependency findings retained"*.
- `scan_runs: 1`; the result was `reused_from` an earlier focused run of the same shape (`result.json:121522-121524`).

**The `218` loaded queries are one vendor's compiled subset, not the complete MISRA C++:2023 rule set, and the collector itself records that the default suite omits manual/audit obligations.** An `exit 0` on `analyze` means the tool completed; it is **not** a compliance verdict.

### 6.2 Findings on repository code in the focused build

All locations below are from `codeql_misra/result.json`; rule→query mapping confirmed against `analyze.stderr`. **Counts are direct readings of the retained JSON; the dependency portion of the JSON is very large and is described by rule/sample rather than exhaustively counted** (no counting utility was available under the read-only boundary).

| File | MISRA rule (pack annotation) | CodeQL query id | Locations (sample) |
|------|------------------------------|-----------------|--------------------|
| `score/socom/test/unit/service_identifier_tests.cpp` | **6.5.1** | `cpp/misra/external-linkage-not-declared-in-header-file-misra` | many, ≈ one per test macro (`:40`, `:671`, `:168`…`2181`); gtest `TEST_F` registration expansion |
| same | **6.7.2** | `cpp/misra/global-variable-used` | `:2181` and the other `TEST_F` expansion lines |
| same | **6.9.2** | `cpp/misra/avoid-standard-integer-type-names` | e.g. `:2181` |
| same | **9.3.1** | `cpp/misra/switch-body-compound-condition` | fires in the file (macro/defaulted-body artifact) |
| `score/socom/impl/string_registry.cpp` | **6.7.1** | `cpp/misra/local-variable-static-storage-duration` | `:71`, `:66` |
| same | **7.0.1** | `cpp/misra/no-conversion-from-bool` | `:28`, `:42`, `:45`, `:59`, `:62` |
| same | **0.1.1** | `cpp/misra/unnecessary-write-to-local-object` | `:23`, `:35` |
| `score/socom/string_registry.hpp` | **21.6.1** | `cpp/misra/dynamic-memory-should-not-be-used` | `:37` (class member `std::forward_list<std::string>`) |
| `score/socom/service_interface_identifier.hpp` | **5.10.1** | `cpp/misra/poorly-formed-identifier` | `:172`, `:183`, `:184`, `:185`, `:186`, `:187` (short hash local names / parameters) |
| same | **6.9.2** | `cpp/misra/avoid-standard-integer-type-names` | `:187` (`std::uint16_t` in the `std::hash` specialization) |
| `score/socom/registry_string_view.hpp` | **4.1.2** | `cpp/misra/implicit-declaration-of-copy-constructor` | `:32` |
| same | **5.10.1** | `cpp/misra/poorly-formed-identifier` | `:187` |
| same | **8.2.5** | `cpp/misra/reinterpret-cast-shall-not-be-used` | `:192` (has an in-source `NOLINTNEXTLINE` plus a prose justification) |
| same | **8.2.7** | `cpp/misra/no-pointer-to-integral-cast` | `:192` (same `std::hash` pointer-to-`intptr_t` conversion) |

Rule identifiers are taken from the pack's query directories, confirmed in `analyze.stderr` (e.g. `RULE-6-7-1/LocalVariableStaticStorageDuration`, `RULE-6-7-2/GlobalVariableUsed`, `RULE-7-0-1/NoConversionFromBool`, `RULE-0-1-1/UnnecessaryWriteToLocalObject`, `RULE-21-6-1/DynamicMemoryShouldNotBeUsed`, `RULE-6-5-1/ExternalLinkageNotDeclaredInHeaderFileMisra`, `RULE-5-10-1/PoorlyFormedIdentifier`, `RULE-6-9-2/AvoidStandardIntegerTypeNames`, `RULE-4-1-2/ImplicitDeclarationOfCopyConstructor`, `RULE-8-2-5/ReinterpretCastShallNotBeUsed`, `RULE-8-2-7/NoPointerToIntegralCast`).

### 6.3 Correction vs. the earlier retained reading

The prior `prior-reports/misra_applicability.md` §7.5 stated that `grep` confirmed **zero** CodeQL MISRA locations in `service_interface_identifier.hpp` and `registry_string_view.hpp`. The **result retained in this checkout does contain such locations** (7 and 4, §6.2). The prior report is preserved unchanged but is **superseded on this point**. Any reader relying on the earlier "clean" statement must re-derive it against the current result. The slice's own operator files (`service_identifier.cpp`, `service_identifier.hpp`) remain **without findings** in this extraction.

### 6.4 Findings in dependencies (not project code) and macro artifacts

- Vendored **googletest** under `.llm_tmp/googletest/**` carries many findings across rules including `copy-and-move-assignments-shall-handle-self-assignment` (Dir **15.8.1**) at `gtest-filepath.h:80,84`; `dynamic-memory-should-not-be-used`; `global-variable-used`; `invariant-condition`; `identifiers-used-in-the-controlling-expression-of`; `nullptr-not-the-only-form-of-the-null-pointer-constant`; `poorly-formed-identifier`; `no-conversion-from-bool`; `unnecessary-write-to-local-object`; and others. These are the test framework, retained only because the extraction is focused; they are **not** project code and do **not** bear on the slice's compliance.
- The candidate test file's `external-linkage-not-declared-in-header-file-misra` hits are **gtest `TEST_F` macro-expansion artifacts** (synthesised externally-linked registration entities), not authored defects; they cannot be fixed inside the authored test body and silently suppressing the rule is prohibited. They require an accepted human deviation or macro-aware tooling (`tool_findings_repair.md` §4.6, `analyzer_plan.md` G8).

### 6.5 The slice operator unit is clean in this extraction

Direct `grep` confirms **zero** CodeQL MISRA locations in `score/socom/impl/service_identifier.cpp` or `score/socom/impl/service_identifier.hpp`, and none in `runtime_impl.*`, `server_connector_impl.*`, `client_connector_impl.*`, `error.hpp`, or `final_action.hpp`. `runtime_tests.cpp` has **zero** because it was **not extracted**. "Clean" here means "no query produced a result in a focused, incomplete extraction" — **not** a compliance statement.

---

## 7. Applicability assessment (bounded slice)

### 7.1 Measurement status of the MISRA-relevant tools

| Check | Retained result | Reading |
|-------|-----------------|---------|
| CodeQL MISRA | `codeql_misra/result.json` | create **exit 0**, analyze **exit 0**; **218** compiled queries; SARIF exported; `status: findings_or_execution_failure`; 3 blockers; focused-extraction limit |
| CodeQL security | `codeql_security/result.json` | `status: findings_or_execution_failure` (`:1113`), `blockers: []` (`:1052`), limit *"Focused linked executable, not full target extraction; dependency findings retained"* (`:1756-1758`); no `score/` finding URI for the candidate/production files read (findings are on googletest) |
| clang-tidy (focused) | `focused_clang_tidy/result.json` | **`--verify-config` exit 1**; blocker *"Native analyzer configuration incompatible; no replacement called MISRA"* (`:1052-1054`); **no TU analysis, not "clean"** |
| cppcheck (focused) | `focused_cppcheck/result.json` | `--error-exitcode=2` **exit 2**; `blockers: []`; limit *"Optional complementary checks; no inferred MISRA rule coverage"* (`:1086-1088`); ran only `service_identifier.cpp` + `string_registry.cpp` |
| GCC + Clang compiler diagnostics (focused) | `compiler_diagnostics/result.json` | `status: completed` (`:1299`); **all 8 commands exit 0** (`:1084…:1296`); limits *"Focused executable only; GCC 12.3 / Clang 19 differ from native toolchain pins"* and *"GoogleTest compiled separately with warnings retained; -Werror on target and tests"* (`:1301-1304`) |
| native tests | `native_tests/result.json` | `status: completed` (`:1082`) for `bazel test //... --build_tests_only` (build-only; a build, **not** an execution of the suite) |
| native lint | `native_lint/result.json` | `status: findings_or_execution_failure` (`:1108`) |
| other native/cross/sanitizer/tsan/performance/integration/docs/traceability/format/pre-commit | `native_*/result.json`, `cross_compilation`, `format_precommit` | retained with failures/environment limits; **not** MISRA measurements |
| host validation | `validation/check-result` = `0`; `measurement.json` | identifier TU only; candidate 91/0; `full_native_tests: not_executed`; `runtime_tests.cpp` not executed |

None of these is a MISRA measurement except the CodeQL MISRA extraction; the others are context for the non-satisfaction statement (§8).

### 7.2 What is covered

| Area | Status | Evidence |
|------|--------|----------|
| `service_identifier.cpp` / `.hpp` (slice production code) | **No finding** in the focused extraction; focused GCC+Clang compile/tests exit 0 | §4, §6.5, §7.1 |
| `service_identifier_tests.cpp` (slice test code) | Findings present, dominated by **gtest macro-expansion artifacts** (external-linkage), plus `global-variable-used` / `avoid-standard-integer-type-names` / switch artifact | §6.2, §6.4 |
| Transitive public headers `service_interface_identifier.hpp`, `registry_string_view.hpp` | **Findings present** (5.10.1, 6.9.2, 4.1.2, 8.2.5, 8.2.7) — pre-existing, not introduced by this slice, but unresolved | §6.2 |
| `string_registry.cpp` / `.hpp` (focused-build production, outside slice) | Findings present (6.7.1, 7.0.1, 0.1.1, 21.6.1) | §6.2 |
| Dependency (`googletest`) | Findings present; out of scope | §6.4 |

### 7.3 Unmapped rules (explicit)

Because `misra_mapping.rst` is a draft with **no active CSV** (§3.3):

- **Every** MISRA C++:2023 rule is **unmapped in-repo**. There is no S-CORE-authorised statement that a given MISRA rule is covered by `misra-cpp-default.qls`, by clang-tidy, by a compiler, or by a manual check.
- The only active mapping is the licensed pack's built-in query annotations; those cover **only the compiled subset** of rules the pack ships, which is **not** a statement of applicability to this unit or this safety class.
- The **218** loaded queries do **not** represent the complete MISRA C++:2023 rule set; they are one vendor's compiled subset.

### 7.4 Manual / audit / undecidable rules (explicit)

- The collector's own blocker *"Default suite omits manual/audit obligations"* means the **manual/audit** class of MISRA obligations was **not executed** and cannot be inferred from this extraction. It remains **manual and unperformed**.
- MISRA marks many rules as **undecidable**; an automated query cannot by itself discharge those. No manual review filled that gap here (`inspection_checklist.rst` `IMPL_02_01`/`IMPL_02_02` is a **draft, blank template**; `:97-108`).
- `code_analysis.rst:51` requires any unaddressed MISRA finding to be **justified and documented in the source**; only `registry_string_view.hpp:188-191` carries such an in-source justification (for the pointer-to-integral hash). The other §6.2 repository findings have no recorded, accepted disposition, and adding one is outside this review's write boundary.

### 7.5 Not extracted / not assessed (explicit "unknown", not "clean")

- `score/socom/test/unit/runtime_tests.cpp` — not in the focused extraction.
- The full `//score/...` (and `//tests/...`) target set — `native_*` legs are build-only or failed/limited; **not** fully analysed or executed.
- clang-tidy on the changed units — config rejected (`--verify-config` exit 1); **not run**.
- Any rule the default suite does not implement, and any rule whose applicability depends on the (unselected) safety class — **unknown**.

### 7.6 Acceptance-level dependency

The applicable acceptance level is not selected (`safety_class: unknown`). Criterion 8 demands "no remaining critical/high findings" (100 %) and criterion 9 demands 100 % freedom from compiler warnings/errors; without a selected class and a completed mapping, applicability of even the automated results to the deliverable is **not authorised**.

---

## 8. Explicit non-claim and obligations status

**MISRA C++:2023 compliance for this slice is UNKNOWN and is NOT claimed.** The reasons are cumulative:

1. The in-repo rule mapping is a **draft with no active CSV** (§3.3) — all rules are unmapped.
2. The CodeQL extraction is **focused and incomplete**; dependency and macro findings are retained, and `runtime_tests.cpp`/the full target were not analysed (§6, §7.5).
3. The **manual/audit** obligations and **undecidable** rules were not executed (§7.4).
4. clang-tidy — a tool named by `code_analysis.rst` — **did not run** (§7.1).
5. The candidate test-file hits are **framework-macro artifacts**, and the repository-header/internal findings (`string_registry.*`, `service_interface_identifier.hpp`, `registry_string_view.hpp`) remain **unclassified and undispositioned** (§6.2).
6. The **safety class is unknown**, so the applicable acceptance level is unselected (§7.6).
7. No tool has a released **tool qualification** report for this use (§3.5).
8. Human reviews are **unanswered** and engineering acceptance is **pending** (§1.3).

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` (draft) | **UNKNOWN — NOT CLAIMED** |
| MISRA rule→tool mapping | `misra_mapping.rst`; `code_analysis.rst:32` | **DRAFT / INACTIVE** — no CSV, no active linkage |
| Static code analysis, findings classified Critical/High/Medium/Low | `verification_process.rst:228-248` (`gd_req__verification_sca_classification`) | **NOT DONE** — no authorised classification; clang-tidy not run |
| Freedom from SCA critical/high findings (criterion 8) | `verification_plan.rst:328-331` | **NOT MEASURED to goal** — focused findings unresolved |
| Freedom from compiler warnings & errors (criterion 9) | `verification_plan.rst:332-335` | **PARTIAL** — focused GCC/Clang exit 0 (§7.1); no Bazel build; `runtime_tests.cpp` uncompiled |
| Manual/audit MISRA rules | collector blocker; `inspection_checklist.rst` (draft) | **NOT EXECUTED / NOT FILLED** |
| `static-code-analysis` recorded as TestType | `verification_plan.rst`; `verification_process.rst:20-54` | **NOT RECORDED** — test metadata record only `DerivationTechnique`/`Description` (`process_checks/result.json:1061-1080`) |
| Unit/component testing executed, results recorded | `verification_plan.rst`; `verification_guideline.rst` | **PARTIAL / STALE SCOPE** — identifier suite 91/0 in a local unprotected host run; `runtime_tests.cpp` (33 macros) not executed |
| Tool identification / evaluation / qualification | `tool_management.rst:32-49` | **NOT ESTABLISHED** for this slice |
| Independence of verification / review | `verification_process.rst:141-152` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Native acceptance | `.llm_tmp/context/obligations/source-index.json` | **`not_inferred` for every entry** |
| Obligation-collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **RETAINED, NOT PASSED** — several `findings_or_execution_failure` |

**Explicit non-satisfaction statement.** Missing tools, unknown applicability, the draft/inactive mapping, incomplete extraction, unresolved framework/header/dependency findings, the unselected safety class, and the unanswered human reviews mean **none of the checked obligations may be treated as satisfied**. The retained CodeQL MISRA result shows *retention*, not passing.

---

## 9. Notice preservation

- No source, build, test, config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was created, edited, or deleted by this iteration; **only this report was written**.
- The header flagged by the task (`score/socom/impl/service_identifier.hpp`) retains its Apache-2.0/SPDX header (`:1-12`) and was left unchanged because it is already balanced (§4). The sibling `service_identifier.cpp`, `service_interface_identifier.hpp`, `registry_string_view.hpp`, the candidate test file, and the BUILD files likewise retain their Apache-2.0 / SPDX headers (`:1-12`).
- All 38 files under `.llm_tmp/overnight/prior-reports/` and all 22 earlier files under `.llm_tmp/overnight/reports/` were preserved unchanged; this document is the 23rd `reports/` entry.
- This report carries the Apache-2.0 header. **No licensed MISRA rule text is reproduced** (§5).

---

## 10. Pending human review checklist

- [ ] **Resolve the instruction conflict (§4):** the recorded "extra closing brace at line 39" is not present in this checkout and the review-draft boundary forbade a source write; confirm that writing only this report was intended, and locate/correct any distinct "cancelled draft" revision that still carries the brace.
- [ ] **Complete and activate the MISRA mapping (§3.3):** fill `_assets/misra_2023.csv`, uncomment the `csv-table`, and raise `misra_mapping.rst` from `:status: draft` to `valid` by an authorised change; until then all rules are unmapped.
- [ ] **Authorise the licensing/mapping substitution (§5):** confirm that using the licensed CodeQL coding-standards `2.61.0` pack's internal rule annotations (rather than the inactive S-CORE mapping) is acceptable evidence, and confirm the "public Apache-2.0 repo, no upload" scope.
- [ ] **Reconcile the correction in §6.3:** confirm the current reading that `service_interface_identifier.hpp` and `registry_string_view.hpp` now carry findings, and retire the earlier "clean" claim.
- [ ] **Decide the CodeQL posture:** run a **full-target** extraction (not a focused executable) that includes `runtime_tests.cpp` and the remaining units, and qualify the compiled queries.
- [ ] **Disposition the repository findings (§6.2):**
      `string_registry.cpp` / `string_registry.hpp` (6.7.1, 7.0.1, 0.1.1, 21.6.1); the `std::hash` specializations in `service_interface_identifier.hpp` (5.10.1, 6.9.2) and `registry_string_view.hpp` (4.1.2, 5.10.1, 8.2.5, 8.2.7) — justify in-source per `code_analysis.rst:51`, refactor, or record an accepted deviation, by an authorised change.
- [ ] **Disposition the candidate test-file findings (§6.2/§6.4)** as gtest `TEST_F` macro artifacts: record an accepted deviation or adopt macro-aware tooling; do not patch the test framework or silently suppress the rules.
- [ ] **Execute and record the manual/audit MISRA obligations (§7.4)** and fill the implementation inspection checklist `IMPL_02_01`/`IMPL_02_02` (`inspection_checklist.rst`, currently draft).
- [ ] **Record the SCA finding classification** (Critical/High/Medium/Low) per `gd_req__verification_sca_classification`, by the quality manager together with a committer.
- [ ] **Repair and run clang-tidy** (`.clang-tidy` config rejected by `--verify-config`, exit 1) and add `static-code-analysis` as a `TestType` where verified identifiers exist — no invented links.
- [ ] **Refresh the measurements:** run `bazel test //score/socom/test/unit:socom_test` (and the broader `//score/...` set) so `runtime_tests.cpp` and the identifier suite are actually compiled and executed natively; do not re-report the focused 91-test host artifact as coverage of the whole tree.
- [ ] **Select the safety class**, schedule independent human review (approver ≠ author, `gd_req__verification_independence`), and record engineering acceptance; no compliance claim may be made before that.
- [ ] **Keep the wider #84 public `Service_interface_identifier` restructure, FindService wildcard handling, and the config minor-wildcard narrowing out of this bounded slice** until separately accepted.

---

*End of review draft. Local, unprotected, scoped. No engineering acceptance; human reviews unanswered; full native runtime tests pending. No MISRA C++:2023 compliance is claimed and no rule applicability is asserted.*
