<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — native analyzer configuration & changed-units plan (`analyzer_plan`) review draft

**Document type:** review draft (native analyzer-configuration review + changed-unit
inspection + retained-tool-artifact reading + tool/version/applicability gap register +
obligations status)
**Date:** 2026-10-02
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version handling in
socom* (issue #84)
**Run:** branch `fabro/run/01M3YRJEGXNY6CB81T7TKW774B`
**Status:** local, unprotected, scoped. **No engineering acceptance exists. Human reviews are
unanswered. Full native runtime tests remain pending.** Every statement below is either a direct
static reading of the working tree at the baseline-bound candidate paths, a reading of the
retained local/unprotected artifacts under `.llm_tmp/overnight/`, or an explicitly-labelled logical
consequence. Nothing here is published, reviewed, accepted, or a full native run.

> **Tool / write boundary actually observed.** This iteration used only `read_file`, `grep`,
> `glob`, and `write_file`. No `shell`, no delegation, no web access, no approval, no publishing,
> and no engineering acceptance was performed. The task's explicit final sentence — *"This is a
> review draft: only that report may be written."* — governs the write boundary, and it is the only
> file this iteration wrote. No source, build, test, config, `NOTICE`, `LICENSE`, `REUSE.toml`, or
> prior-report file was created, edited, or deleted. All prior reports under
> `.llm_tmp/overnight/prior-reports/` and `.llm_tmp/overnight/reports/` were preserved unchanged.
> The task also says "Inspect and correct the actual source before expanding tests"; §2 shows the
> named source is already correct and the write boundary forbids a source write in any case. The
> instruction conflict is recorded for the human reviewer (§9), not silently resolved.

> **Non-satisfaction rule applied throughout.** A successful obligation-collection node means the
> results were **retained**, not that the checks **passed**. Missing tools, unknown applicability,
> incomplete extraction, and unanswered human reviews are **not** treated as satisfied.

---

## 0. Summary

1. **The named GCC syntax failure is not present in the actual source (§2).**
   `score/socom/impl/service_identifier.hpp` is a 40-line, brace-balanced header. A `grep` for
   `[{}]` returns exactly four brace-bearing lines — `:19` (`namespace score::socom {`), `:29`
   (`struct Service_instance_identifier final {`), `:32` (`};`), `:38` (`}  // namespace
   score::socom`) — i.e. two openers and two closers, net balance `0`. Line `:39` is blank and
   `:40` is `#endif`. The retained focused GCC compile of the same translation unit exits `0`
   with empty `stderr`; the only nonzero compiler result retained by the run is a **clang**
   `-Werror` failure originating in the vendored googletest/libstdc++ 12 headers, outside the six
   candidate paths (`obligations/compiler_diagnostics/clang-compile.stderr:4`). The described
   defect matches the *earliest* prior reports (split-form double close), not this checkout.
   **No source edit was made, and none is required.**

2. **Native analyzer configuration review (§3).** The repo wires clang-tidy through a Bazel aspect
   (`static_analysis.bazelrc:20-24`; `tools/lint/linters.bzl:39-47`; entry point
   `bazel run //:clang-tidy.check`, `BUILD:118`) using `//:.clang-tidy`. That `.clang-tidy` uses a
   YAML folded block scalar (`Checks: >`) with `#` comment lines inside it; YAML does not treat
   those as comments inside a block scalar, so the comments fold into the check string and corrupt
   adjacent check names. The focused `clang-tidy --verify-config` run (clang-tidy 19.1.7) exits `1`
   with 15 unknown-check warnings for exactly that reason, plus two identifiers that are genuinely
   absent from this build (`clang-analyzer-alpha.security.ArrayBoundV2`; the
   `modernize-use-integer-sign-comparison` check and its `.IncludeStyle` option). Clang-tidy
   therefore produced **zero** findings on the changed units — that is "not run", never "clean".

3. **Compiler-warning posture (§3.2).** `.bazelrc:117` (`common --features=-treat_warnings_as_errors`)
   and `coverage.bazelrc:64-65` **disable** warnings-as-errors by default, while
   `verification_plan.rst:332-335` (criterion 9) demands freedom from compiler warnings & errors at
   100 %. Warnings-as-errors evidence is a separate, explicit invocation; a default CI green does
   not evidence criterion 9.

4. **CodeQL is collector-only and incompletely extracted (§3.3, §6).** No CodeQL file/workflow
   exists in the repository (`glob **/codeql*` returns nothing); `static-code-analysis.yml` runs
   only `//:clang-tidy.check` and `//:ruff.check`. The collector ran CodeQL 2.21.4 against a
   database built with a focused `codeql-build.sh`, which the artifacts themselves limit to a
   *"Focused linked executable, not full target extraction"*. Findings are therefore not a
   full-target result, and CodeQL MISRA applicability is unestablished because `misra_mapping.rst`
   is `:status: draft`.

5. **Changed units (§4).** The six candidate paths — `score/socom/BUILD`,
   `score/socom/impl/service_identifier.cpp`, `score/socom/impl/service_identifier.hpp`,
   `score/socom/test/unit/BUILD`, `score/socom/test/unit/runtime_tests.cpp`,
   `score/socom/test/unit/service_identifier_tests.cpp` — carry the bounded key change (identity
   `(instance, service id, major)`; `minor` excluded) and the associated tests (87 `TEST_F` key
   cases; 31 `TEST_F` + 1 `TEST` + 1 `TEST_P` runtime cases). Analyzer exposure is recorded in
   §4.2; no analyzer finding points into `service_identifier.cpp` or `service_identifier.hpp`.

6. **Tool/version/applicability gaps (§6) do not permit a MISRA-compliance claim.** The MISRA
   mapping is a draft; the CodeQL MISRA extraction is focused and its findings are dominated by
   googletest and by a gtest-macro `external-linkage` artifact on the retained test file; clang-tidy
   did not run; cppcheck findings are all in headers outside the candidate paths; and the native
   `bazel` lint/coverage/sanitizer/TSAN obligations all exit `127`. Tool confidence/qualification is
   additionally blocked (`tool_assurance` blockers: Coverity not adopted; qualification requires
   authorized humans).

7. **No obligation is satisfied (§7).** Every `source-index.json` entry is
   `native_acceptance: not_inferred`; authority is `engineering_acceptance: pending`,
   `human_reviews: unanswered`, `safety_class: unknown`. The retained results are scoped, partly
   stale, and largely blocked.

---

## 1. Binding, prior reports, host feedback, obligation artifacts

### 1.1 Issue and baseline

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` — *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:2-4` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` (unchanged) | `.llm_tmp/context/issue-snapshot.json:19-20` |
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |
| Branch | `fabro/run/01M3YRJEGXNY6CB81T7TKW774B` | environment |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**: service-instance identifier = `service id + major + minor + instance id`; service
identifier = `service id + major`; FindService = `service id + major + optional<minor> +
optional<instance>`; exclude `minor` and make it an instance property. There is no comment and no
acceptance record. Binding is **by baseline commit**, not by run HEAD.

### 1.2 Candidate paths and working-tree drift

From `.llm_tmp/context/candidate-files.json` (baseline blobs cross-checked against
`.llm_tmp/context/source-manifest.json`):

| File (repo-relative) | Baseline git blob | Draft sha256 (candidate-files) | Obligation working-tree sha256 | Reading |
|----------------------|-------------------|-------------------------------|--------------------------------|---------|
| `score/socom/BUILD` | `3477ea08…` | `dee82616…` | `68f4645a…` | differs from draft → changed |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e…` | `d766902e…` | `3c12b3f1…` | key orders by `(instance, id, major)`, `minor` excluded |
| `score/socom/impl/service_identifier.hpp` | `c8bae790…` | `96b33a1f…` | `bdce3fcb…` | 40 lines, brace-balanced (§2) |
| `score/socom/test/unit/BUILD` | `3c03a7b1…` | `9b3c5b34…` | `e909151e…` | `socom_test` globs `*.cpp`; deps wired |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab7…` | `5e35e24d…` | `9a2d6a15…` | 31 `TEST_F` + 1 `TEST` + 1 `TEST_P` |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(none — `null`)* | `45d07399…` | `4df2c63c…` | new file; **87 `TEST_F`** in the current tree |

The `service_identifier.hpp` column shows the working tree **drifted** from the draft snapshot
(`96b33a1f…` → `bdce3fcb…`); a hash is not a content diff and no hashing tool was available here,
but the drift is flagged so the candidate set is not mistaken for the current tree.
`glob **/service_identifier.hpp` returns exactly one path.

### 1.3 Prior reports read and preserved

- `.llm_tmp/overnight/reports/` — 19 files present and preserved: `api_review.md`, `bazel_plan.md`,
  `callsites.md`, `compatibility.md`, `concurrency_review.md`, `conversion_tests.md`,
  `coverage_tests_repair.md`, `invariants.md`, `key_fix.md`, `lifetime_review.md`,
  `lifetime_tests.md`, `ordering_tests.md`, `reproducer.md`, `runtime_disabled.md`,
  `runtime_enabled.md`, `scope.md`, `test_metadata.md`, `tool_findings_repair.md`,
  `unit_matrix.md`. This document adds `analyzer_plan.md` (20th).
- `.llm_tmp/overnight/prior-reports/` — 12 files present and preserved: `callsites.md`,
  `conversion_tests.md`, `invariants.md`, `key_fix.md`, `lifetime_tests.md`, `ordering_tests.md`,
  `reproducer.md`, `runtime_disabled.md`, `runtime_enabled.md`, `scope.md`, `test_metadata.md`,
  `unit_matrix.md`.
- The most directly relevant prior reports are `tool_findings_repair.md` (per-tool diagnostics on
  the candidate units), `bazel_plan.md` (native Bazel analyzer/lint/coverage plan and the
  unavailable-`bazel` table), `compatibility.md` (exact-major/minimum-minor vs the changed key),
  `api_review.md` (ABI/API neutrality), and `coverage_tests_repair.md` (the two added key tests).

### 1.4 Host validation feedback (`.llm_tmp/overnight/validation/`) — present, scoped, stale

| Artifact | Content |
|----------|---------|
| `check-result` | `0` (collector success marker only) |
| `measurement.json` | `check_ref: check_conversion_tests`, `mode: ubsan`, `origin: local_unprotected_measurement`, `initiator: Fabro host hook`, `engineering_acceptance: pending`, `full_native_tests: not_executed`, compiler `/usr/bin/x86_64-linux-gnu-g++-12` (sha `88315fd2…`); `changed_paths: ["score/socom/test/unit/service_identifier_tests.cpp"]`; `baseline_with_agent_tests` **85 / 28 / compile 0**; `candidate` **85 / 0 / compile 0** |
| `before-*` / `after-*` captures | focused identifier TU (`service_identifier.cpp` + `string_registry.cpp` + `service_identifier_tests.cpp`) with `g++-12 -std=c++17 -Wall -Wextra -Werror`; `after-compile.stderr` and `before-compile.stderr` empty |

The measurement is **stale** against the current 87-case tree and does **not** compile
`runtime_tests.cpp` or any Bazel target.

### 1.5 Obligation artifacts under `.llm_tmp/overnight/obligations/`

25 checks are retained (24 earlier + `rework_progress`), each with `origin:
local_unprotected_measurement`, `engineering_acceptance: pending`, and a `source_hashes` block plus
a `collector_identity` block recording tool paths and sha256. The relevant checks for this report
are `focused_clang_tidy`, `focused_cppcheck`, `codeql_misra`, `codeql_security`,
`compiler_diagnostics`, `focused_coverage`, `focused_asan_lsan`, `focused_tsan`,
`focused_memcheck`, `native_lint`, `format_precommit`, `native_*`, `cross_compilation`,
`process_checks`, `tool_assurance`, `secret_dependency_checks`, `rework_progress`.

### 1.6 Pinned obligation sources

All nine `.llm_tmp/context/obligations/source-index.json` entries were read with `authority.json`.
Statuses: `coding_guidelines`, `code_analysis`, `verification_plan`, `development_plan`,
`tool_management`, `verification_process`, `verification_guideline` are `:status: valid`;
**`misra_mapping` and `inspection_checklist` are `:status: draft`**. Every entry is
`native_acceptance: not_inferred`. `authority.json`: `engineering_acceptance: pending`,
`human_reviews: unanswered`, `safety_class: unknown`, `codeql_scope: "Public Apache-2.0
eclipse-score/inc_someip_gateway; no upload"`.

---

## 2. The recorded GCC syntax failure: inspection of the actual source

### 2.1 Finding (direct `read_file` + `grep` this iteration)

`score/socom/impl/service_identifier.hpp` is 40 lines and **brace-balanced**:

| Line | Content | Role |
|------|---------|------|
| 14–15 | `#ifndef SRC_SOCOM_SRC_SERVICE_IDENTIFIER` / `#define …` | include guard |
| 17 | `#include "score/socom/service_interface_identifier.hpp"` | include |
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 30–31 | `Service_interface_identifier interface;` / `Service_instance instance;` | members |
| 32 | `};` | closes the struct |
| 35 | `bool operator<(…);` (inside `/// \cond`) | declaration |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

`grep '[{}]'` on the file returns exactly `:19`, `:29`, `:32`, `:38`. Two openers, two closers, net
balance `0`. There is no third, unmatched closing brace and line 39 contains no text. The header
documents the minor exclusion (`:21-28`); the sibling `.cpp` uses the same nested form and is
balanced (`:18`, `:20`, `:30`, `:32`).

### 2.2 Retained artifacts corroborate a balanced, compiling unit

- `obligations/compiler_diagnostics/result.json`: `gcc-compile` **exit 0** (`:271`) and `gcc-tests`
  **exit 0** (`:293`) for the focused TU including `service_identifier.cpp` and
  `service_identifier_tests.cpp`; `clang-compile` **exit 1** (`:329`).
- `obligations/compiler_diagnostics/clang-compile.stderr:4` is the only retained compile error:
  `get_temporary_buffer<testing::TestInfo *>' is deprecated [-Werror,-Wdeprecated-declarations]`,
  instantiated from `.llm_tmp/googletest/googletest/src/gtest.cc:3068` via `std::stable_sort` — a
  vendored-dependency/libstdc++ 12 issue under `-Werror`, **not** a candidate-source syntax error.
- Host `validation/after-compile.stderr` and `before-compile.stderr` are empty.

### 2.3 Disposition

The described "extra closing brace at line 39" is a **stale, pre-correction description** that
matches the earliest prior reports (`prior-reports/scope.md`, `prior-reports/invariants.md`), which
quote the old split-form `}  // namespace socom` + `}  // namespace score`. The `reproducer`
iteration applied the correction and left line 39 blank. Applying the historical repair

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

to the already-balanced, already-nested file would be a no-op at best and a compilation break at
worst. Because the write boundary permits only this report, no source edit was made. If the
"cancelled draft" is a distinct revision that still carries the brace, it is **not** the file in
this checkout and must be located and corrected by an authorized iteration.

---

## 3. Native analyzer configuration review (repository-side)

### 3.1 clang-tidy

| Aspect | Value | Source |
|--------|-------|--------|
| Config file | `//:.clang-tidy` (287 lines) | repo root |
| Wiring | `lint_clang_tidy_aspect(binary = @llvm_toolchain//:clang-tidy, configs = [//:.clang-tidy], header_filter = "^(?!(third_party|external)/).*$", angle_includes_are_system = True)` | `tools/lint/linters.bzl:39-47` |
| Bazel flags | `--aspects=//tools/lint:linters.bzl%clang_tidy`, `--output_groups=+rules_lint_report,+rules_lint_human,+rules_lint_machine`, `--extra_toolchains=@llvm_toolchain//:cc-toolchain-x86_64-linux`, `--@aspect_rules_lint//lint:fail_on_violation=true`, `--keep_going` | `static_analysis.bazelrc:20-24` |
| Entry points | `bazel run //:clang-tidy.check` / `//:clang-tidy.fix` (via `use_clang_tidy_targets()`) | `BUILD:118`; `tools/lint/linters.bzl:98-110` |
| Policy | `WarningsAsErrors: clang-analyzer-*`; `HeaderFilterRegex: '^(?!(third_party|external)/).*'`; many `CheckOptions` | `.clang-tidy:164-287` |

**Observed verification outcome (retained artifact).** The collector ran

```
clang-tidy --verify-config --config-file=<snapshot>/.clang-tidy     (clang-tidy 19.1.7, sha 5f733fae…)
```

and it **exited 1** with 15 `unknown check` warnings
(`obligations/focused_clang_tidy/native-config.stderr`), and the retained blocker is *"Native
analyzer configuration incompatible; no replacement called MISRA"* (`result.json:235-236`). The
warning wording is diagnostic:

- Most warnings name a **comment merged with a check**, e.g.
  `unknown check '# --- autosar-severity-one --- bugprone-use-after-move'`,
  `unknown check '#modernize-type-traits'`, `unknown check 'Disabled because of too much noise'`,
  `unknown check 'will later be re-enabled with a campaign to fix findings modernize-unary-static-assert'`.
  The cause is the `Checks: >` **YAML folded block scalar** (`.clang-tidy:16-162`): YAML does not
  recognise `#` comment lines *inside* a block scalar, so every comment folds into the scalar and
  merges with the following check name unless a comma happens to separate them. The repository's
  intent (inline documentation of check groups) is therefore not achievable with `>` folding; a
  plain/comma-separated list or `Checks:` sequence is required.
- At least two identifiers are **genuinely unknown** to clang-tidy 19.1.7 independent of the
  folding: `clang-analyzer-alpha.security.ArrayBoundV2` (the `clang-analyzer-alpha.*` group was
  removed upstream) and `modernize-use-integer-sign-comparison`, whose presence is confirmed by a
  separate warning for the unknown check *option*
  `modernize-use-integer-sign-comparison.IncludeStyle` (`.clang-tidy:223-224`). This is
  clang-tidy-version / policy drift, not a candidate-source defect.

**Consequence for this slice.** Because `--verify-config` failed, the check performed **no
translation-unit analysis**, so there are **no clang-tidy findings** on the changed units. That is
*"not run"*, **not** *"clean"*. Fixing `.clang-tidy` or suppressing checks is outside the six
candidate paths and outside this review's write boundary; it needs an authorized change and an
accepted tool/config version.

### 3.2 Compiler warnings (criterion 9)

- `common --features=-treat_warnings_as_errors` (`.bazelrc:117`) and the coverage config's
  `--features=-treat_warnings_as_errors` / `--host_features=-treat_warnings_as_errors`
  (`coverage.bazelrc:64-65`) mean the **default** build/test is *not* warnings-as-errors.
- `verification_plan.rst:332-335` (criterion 9) requires freedom from compiler warnings & errors at
  **100 %**. Evidence therefore requires an explicit
  `--features=treat_warnings_as_errors` build (see `bazel_plan.md` §4 stage 3b), which has **not**
  been run.
- The only actual warnings-as-errors evidence this run produced is the **focused** GCC compile
  (`-Wall -Wextra -Werror`, exit 0) and the **focused** clang compile (exit 1 on the googletest
  dependency). Neither is a full-target criterion-9 measurement.

### 3.3 CodeQL (security + MISRA)

| Aspect | Value | Source |
|--------|-------|--------|
| Repo CI wiring | **none** — `static-code-analysis.yml:22-23` runs only `//:clang-tidy.check` and `//:ruff.check`; `glob **/codeql*` returns nothing | `.github/workflows/combined (glob)` |
| Collector CodeQL | `codeql 2.21.4` (sha `d38df35e…`) | `obligations/codeql_security/result.json:222` |
| Coding-standards pack | `codeql-coding-standards 2.61.0`; `codeql-suites/misra-cpp-default.qls` (sha `8b41feb7…`) | `obligations/codeql_misra/result.json:223-224` |
| Query suites | security: `codeql/cpp-queries@1.4.1:codeql-suites/cpp-security-and-quality.qls`; MISRA: `misra-cpp-default.qls` | `codeql_security/result.json:273`; `codeql_misra/result.json:277` |
| Database build | `codeql database create --language=cpp --command=<snapshot>/codeql-build.sh` (a **focused** build script) | `codeql_security/result.json:238-249`; `codeql_misra/result.json:242-253` |
| Extraction limit (self-declared) | *"Focused linked executable, not full target extraction; dependency findings retained"* | `codeql_security/result.json` limits; `codeql_misra/result.json` limits |
| MISRA blockers (self-declared) | *"MISRA applicability/mapping draft and incomplete"*, *"Default suite omits manual/audit obligations"*, *"Compiled query qualification and human deviations pending"* | `codeql_misra/result.json:235-239` |

Both CodeQL checks returned `status: findings_or_execution_failure` even though the `create` and
`analyze` commands exited `0`; that status is driven by the retained findings and the self-declared
limits/blockers. Neither run is a full-target extraction.

### 3.4 cppcheck

- Collector-only; no repository cppcheck config or CI job exists.
- Invocation (`obligations/focused_cppcheck/result.json:236-265`):
  `/usr/bin/cppcheck` (sha `d2268c85…`) `--std=c++17 --enable=warning,style,performance,portability
  --xml --xml-version=2 --error-exitcode=2 -I. score/socom/impl/service_identifier.cpp
  score/socom/impl/string_registry.cpp`.
- **Exit 2** (findings). Per `tool_findings_repair.md` §4.3, all 19 findings are `id="passedByValue"`
  (`severity="performance"`) and every `<location>` is in an **included header outside the
  candidate paths** (`registry_string_view.hpp` 13; `service_interface_identifier.hpp` 6); there is
  **no finding in `service_identifier.cpp`**. The collector records
  `limits: ["Optional complementary checks; no inferred MISRA rule coverage"]`.

### 3.5 Sanitizers / memory

| Check | Extraction | Result | Source |
|-------|-----------|--------|--------|
| `focused_asan_lsan` | focused identifier TU, `ASAN_OPTIONS=detect_leaks=1:halt_on_error=1`, `UBSAN_OPTIONS=halt_on_error=1` | **completed / exit 0** | `focused_asan_lsan/result.json` |
| `focused_tsan` | focused identifier TU | **failure** — tests exit **66** in one collection and **-11** in another; `FATAL: ThreadSanitizer: unexpected memory mapping` | `focused_tsan/result.json`; completed-stage capture |
| `focused_memcheck` | focused identifier TU | **exit 127** — `/tmp/score-someip84-obligation-tools/usr/bin/valgrind` missing | `focused_memcheck/result.json` |
| `native_sanitizers` / `native_tsan` | full `//score/... //tests/...` | **exit 127** — `bazel` missing | `native_sanitizers/result.json`; `native_tsan/result.json` |

The CI equivalent runs asan/lsan/ubsan and tsan over `//score/... //tests/...`
(`.github/workflows/build_and_test_host.yml:30-35`) and has **not** executed here.

### 3.6 Coverage

- Canonical config: `coverage --config=llvm_cov` (`coverage.bazelrc:22-68`; LLVM source-based
  coverage, `//tools/coverage:reporter_wrapper`, `--instrumentation_filter=^//score[/:]`); CI job
  `.github/workflows/coverage.yml`.
- Collector `focused_coverage` (gcc `--coverage`, `gcov-12` sha `dcaf103b…`, `gcovr` sha
  `59cd3ede…`) over `score/socom/impl/service_identifier.cpp` + `string_registry.cpp`:
  **36/36 lines = 100 %**, **11/14 branches = 78.6 %**; `complete_target_scope: false`;
  `safety_class: "unknown_requires_authorized_selection"` (`focused_coverage/result.json:339-357`).
  Platform goals are **QM 85 % / safety 100 %** (`verification_plan.rst:300-307`), so the focused
  branch figure is below the QM goal as well.
- The `native_coverage` collector env sets `COVERAGE_THRESHOLD=73`, which the collector itself
  labels *"Repository CI threshold 73 is not platform 85/100 line-and-branch acceptance"*.
- One collection retained an older, lower focused figure (28/36 = 77.8 %, 9/14 = 64.3 %, the
  pre-`coverage_tests_repair` state); the current `result.json` records the 100 %/78.6 % state.

### 3.7 Format / pre-commit / docs / traceability / performance

- `format_precommit`: **exit 127** — `/tmp/s-core-001/bin/bazel` missing, and separately
  `/tmp/score-someip84-obligation-tools/bin/pre-commit` and `…/bin/reuse` missing
  (`format_precommit/result.json:310,334,357`). Its own limit: *"Formatting/pre-commit mutations
  occur only in this disposable collector copy"*.
- `native_lint`: **exit 127** — `bazel` missing (`native_lint/result.json:261,288`); this is the
  check that would run `//:clang-tidy.check`.
- `native_build` / `native_tests` / `native_coverage` / `native_integration` / `native_docs` /
  `native_traceability` / `native_performance` / `cross_compilation`: **exit 127**, all
  `[Errno 2] No such file or directory: '/tmp/s-core-001/bin/bazel'`.
- `secret_dependency_checks`: `gitleaks` unavailable (sha `null`); lock/SBOM retained.
- `process_checks`: `completed_with_blockers`; blockers are *"Lexical metadata inventory cannot
  prove semantic requirement coverage"*, *"Safety/QM applicability and approved tailoring unknown"*,
  *"Independent inspection and acceptance required"*, *"External AoU and full integration
  verification require scoped review"* (`process_checks/result.json:235-240`).
- `tool_assurance`: `completed_with_blockers`; blockers are *"Tool confidence evaluation,
  qualification where applicable, and acceptance require authorized humans"*, *"Coverity not
  installed/adopted here; reconcile guideline/development-plan discrepancy"*, *"Memcheck is an
  optional complement, not a universal process mandate"* (`tool_assurance/result.json:235-239`).

### 3.8 CI wiring versus collector-only analyzers (summary)

| Analyzer | In repo CI? | Wired where | Collector check |
|----------|-------------|-------------|-----------------|
| clang-tidy | yes | `static-code-analysis.yml:23` → `//:clang-tidy.check` → aspect | `focused_clang_tidy`, `native_lint` |
| ruff | yes | `static-code-analysis.yml:23` → `//:ruff.check` | — |
| compiler warnings-as-errors | **no** (default off, `.bazelrc:117`) | explicit feature only | `compiler_diagnostics` (focused, `-Werror`) |
| asan/lsan/ubsan, tsan | yes | `build_and_test_host.yml:30-35` | `focused_*`, `native_*` |
| coverage (LLVM) | yes | `coverage.bazelrc`; `coverage.yml` | `focused_coverage`, `native_coverage` |
| CodeQL (security/MISRA) | **no** | collector-only | `codeql_security`, `codeql_misra` |
| cppcheck | **no** | collector-only | `focused_cppcheck` |
| valgrind/memcheck | **no** | collector-only | `focused_memcheck` |
| format/pre-commit/reuse | no (collector) | collector-only | `format_precommit` |

This table is the core of the "native analyzer configuration" review: two of the analyzers named by
`code_analysis.rst` (CodeQL and Coverity) are **not** in the repository CI, and CodeQL/Coverity are
collector-only or absent here.

---

## 4. Changed units and their analyzer exposure

### 4.1 Source

- **`score/socom/impl/service_identifier.hpp`** — `Service_instance_identifier{interface,
  instance}` (`:29-32`), out-of-line `operator<` declaration (`:35`, `\cond`-hidden), **no**
  `operator==`/`std::hash`. Brace-balanced (§2). Compiled into `//score/socom:socom` via
  `srcs = glob(["impl/**/*.cpp", "impl/**/*.hpp"])` (`score/socom/BUILD:24-41`) and re-exposed
  `testonly` via `//score/socom:impl_service_identifier` (`score/socom/BUILD:46-54`). A syntax error
  here would fail the library and `socom_test` and contradict criterion 9; the current file does
  not.
- **`score/socom/impl/service_identifier.cpp`** — the only operator is
  `operator<(Service_instance_identifier const&, Service_instance_identifier const&)` (`:20-30`),
  ordering by `std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major)`. Identity is
  `(instance, service id, major)`; `minor` is excluded, matching the minor-ignoring
  `Service_database` index (`runtime_impl.hpp:116-134`). The comment (`:21-27`) ties this to issue
  #84. This is the unit the focused analyzers actually saw.
- **`score/socom/BUILD`**, **`score/socom/test/unit/BUILD`** — target wiring (library + `testonly`
  header exposure + `socom_test` glob/deps). No analyzer finding targets the BUILD files; the
  clang-tidy aspect would lint the `cc_library`/`cc_test` targets if it could run.

### 4.2 Tests

- **`score/socom/test/unit/service_identifier_tests.cpp`** — new file (baseline blob `null`);
  **87 `TEST_F`** in the current tree under `ServiceInstanceIdentifierTest`, first at `:168`, last
  at `:2012`. The retained collections hash it at `4df2c63c…` (87 macros per `process_checks`),
  while the draft snapshot hash is `45d07399…` (85 cases) — the two `coverage_tests_repair`
  additions post-date the host measurement. Apache-2.0 header and `SetUp()`
  `DerivationTechnique`/`Description` properties preserved.
- **`score/socom/test/unit/runtime_tests.cpp`** — **31 `TEST_F` + 1 `TEST` (`:239`) + 1 `TEST_P`
  (`:1311`)**; the focused minor-only duplicate regression is
  `ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError` (`:402-431`).
- **Metadata exposure (analyzer/traceability relevant):** `process_checks` inventory records
  `runtime_tests.cpp` 33 test macros and `service_identifier_tests.cpp` 87 test macros, each with
  `DerivationTechnique` and `Description`; `TestType` and `Verifies`/`PartiallyVerifies`/
  `FullyVerifies` are deliberately unset because no verified native requirement/interface
  identifier exists (no invented links).

### 4.3 Analyzer findings that touch the changed units

| Tool | Finding | On a changed unit? | Assessment |
|------|---------|--------------------|------------|
| GCC (focused) | compile exit 0; tests exit 0 (85/85 retained) | yes (clean) | no candidate defect; criterion 9 only focused |
| Clang (focused) | `-Wdeprecated-declarations` from googletest/libstdc++ 12 under `-Werror` | no (dependency) | blocker outside the six paths |
| clang-tidy | none produced (`--verify-config` exit 1) | n/a | **not run**; config/version gap (§3.1) |
| cppcheck | 19 `passedByValue` (performance) | no (headers outside the six paths) | style noise; disposition needed |
| CodeQL security | 32 findings, **all** `uri` under `.llm_tmp/googletest/…` | no | dependency-only; focused extraction |
| CodeQL MISRA | `copy-and-move-…-self-assignment` in `gtest-filepath.h`; many `external-linkage-not-declared-in-header-file-misra` on `service_identifier_tests.cpp` (`TEST_F` lines) | dependency + macro artifact | gtest `TEST_F` expansion; needs human deviation, not a body fix |
| ASan/LSan/UBSan | focused tests exit 0 | yes (pass, focused) | single-threaded identifier scope |
| TSan | `FATAL: ThreadSanitizer: unexpected memory mapping` | n/a | environment/kernel blocker |
| coverage | 100 % line / 78.6 % branch over `service_identifier.cpp` + `string_registry.cpp` | partially | below QM/safety branch goal; focused scope only |

No analyzer finding points into `service_identifier.cpp` or `service_identifier.hpp`, and none
points into the author-written bodies of the key tests; the only in-scope-looking MISRA hits are
the gtest macro expansion.

---

## 5. Native analyzer execution plan (pending; exact, from pinned config)

The repository-pinned analyzer invocations (from `bazel_plan.md` §4, re-read against the configs
above). **None was executed this iteration**; `bazel` is absent (`/tmp/s-core-001/bin/bazel`).

```bash
# analyzer / lint (native_lint; clang-tidy 19.1.7 toolchain via @llvm_toolchain)
bazel --batch --output_user_root=<run>/bazel-cache run --jobs=2 //:clang-tidy.check
bazel --batch --output_user_root=<run>/bazel-cache run --jobs=2 //:ruff.check
# alternative aspect form
bazel --batch --output_user_root=<run>/bazel-cache test --config=clang-tidy //score/...

# criterion 9 evidence (the default disables warnings-as-errors: .bazelrc:117)
bazel --batch --output_user_root=<run>/bazel-cache build --jobs=2 \
    --features=treat_warnings_as_errors //score/socom/...

# sanitizers / TSAN (native_sanitizers, native_tsan)
bazel --batch --output_user_root=<run>/bazel-cache test --jobs=2 //score/... //tests/... \
    --build_tests_only --features=asan --features=lsan --features=ubsan_clang
bazel --batch --output_user_root=<run>/bazel-cache test --jobs=2 //score/... //tests/... \
    --build_tests_only --features=tsan

# coverage (native_coverage; platform goals are 85 %/100 %, not the collector's 73)
bazel --batch --output_user_root=<run>/bazel-cache coverage --jobs=2 //... --build_tests_only
```

Before a real clang-tidy run can be trusted, `.clang-tidy` must be repaired (unfold the `Checks:`
block; re-evaluate the two check identifiers absent from clang-tidy 19.1.7) by an **authorized**
change — this review may not edit it. CodeQL/MISRA must be run with a full-target extraction and a
non-draft rule mapping before any MISRA claim is possible; cppcheck/valgrind add complementary
coverage only.

---

## 6. Tool / version / applicability gaps (no MISRA-compliance claim)

| # | Gap | Evidence | Effect on this slice |
|---|-----|----------|----------------------|
| G1 | Repo `.clang-tidy` `Checks: >` folds `#` comments into check names | `focused_clang_tidy/native-config.stderr:1-14`; `.clang-tidy:16-162` | clang-tidy verifies as invalid; **zero** clang-tidy findings on the changed units |
| G2 | Two check identifiers absent from clang-tidy 19.1.7 (`clang-analyzer-alpha.security.ArrayBoundV2`, `modernize-use-integer-sign-comparison`/`.IncludeStyle`) | `native-config.stderr:4,10,15` | config/tool-version drift; needs authorized fix, not in-slice suppression |
| G3 | Warnings-as-errors disabled by default | `.bazelrc:117`; `coverage.bazelrc:64-65` | criterion 9 not evidenced by default runs |
| G4 | CodeQL not wired in repo CI | `static-code-analysis.yml:22-23`; `glob **/codeql*` empty | static-analysis coverage of the repo differs from the collector's |
| G5 | CodeQL extraction is focused, not full-target | `codeql_*/result.json` limits: *"Focused linked executable, not full target extraction"* | findings incomplete; dependency findings retained |
| G6 | MISRA mapping is `:status: draft` and the rule table is commented out | `misra_mapping.rst:18-31` | **no MISRA C++:2023 compliance can be claimed** |
| G7 | MISRA applicability/qualification pending; manual/audit suite omitted | `codeql_misra/result.json:235-239` | needs human deviation/qualification |
| G8 | CodeQL MISRA `external-linkage…` hits are gtest `TEST_F` macro artifacts | `codeql_misra/result.json:354…` (all on `service_identifier_tests.cpp`) | not fixable in the authored test body; needs accepted deviation or macro-aware tooling |
| G9 | cppcheck findings all outside the six paths | `tool_findings_repair.md` §4.3 | not a candidate defect; separate disposition |
| G10 | clang focused compile blocked by dependency deprecation | `clang-compile.stderr:4` | clang branch of criterion 9 unmet |
| G11 | valgrind unavailable | `tool_assurance/result.json:232-233`; `focused_memcheck` exit 127 | memory-check complement unmet |
| G12 | gitleaks unavailable | `tool_assurance/result.json:233` | secret scan unmet |
| G13 | TSan environment failure | `focused_tsan` tests exit 66/-11, `unexpected memory mapping` | concurrency check unmet |
| G14 | `bazel` absent; all native analyzer obligations exit 127 | `native_lint`, `native_*`, `cross_compilation`, `format_precommit` | native lint/coverage/sanitizer/TSAN not executed |
| G15 | pre-commit / reuse / clang-format unavailable | `format_precommit/result.json:334,357`; `tool_assurance` | format/pre-commit evidence unmet |
| G16 | Coverity not installed/adopted (guideline vs development-plan discrepancy) | `tool_assurance/result.json:237` | `code_analysis.rst` tool set incomplete |
| G17 | Tool confidence/qualification requires authorized humans | `tool_assurance/result.json:236` | `tool_management.rst` not established |
| G18 | CodeQL scope is public Apache-2.0 repo, no upload | `authority.json` | local-only analysis; not a platform result |

**Explicit non-claim.** G4–G8, G16, G17 and the draft mapping (G6) mean **MISRA C++:2023
compliance is UNKNOWN and is not claimed**. The focused, dependency-heavy, incompletely extracted
findings retained here cannot support a compliance statement in either direction, and the unknown
`safety_class` means the applicable acceptance level (QM 85 % vs safety 100 %) is not selected.

---

## 7. Obligations status (none satisfied)

### 7.1 Pinned state

`authority.json`: `engineering_acceptance: pending`, `human_reviews: unanswered`,
`safety_class: unknown`, `codeql_scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway; no
upload"`. Every `source-index.json` entry: `native_acceptance: not_inferred`.

### 7.2 Per-obligation status for this slice

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Freedom from compiler warnings & errors (criterion 9, 100 %) | `verification_plan.rst:332-335` | **NOT MEASURED (native)** — focused GCC compile+tests exit 0; clang focused compile blocked; default build disables warnings-as-errors |
| Static code analysis (clang-tidy / CodeQL), findings classified | `code_analysis.rst`; `verification_process.rst` (`gd_req__verification_sca_classification`) | **NOT SATISFIED** — clang-tidy config blocker (not run); cppcheck findings out of scope; CodeQL security dependency-only; CodeQL MISRA draft/qualification pending; no critical/high closure classification |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` (draft) | **UNKNOWN — NOT CLAIMED** (G6–G8) |
| Structural statement / branch coverage (criteria 1–2) | `verification_plan.rst:300-307` | **NOT MEASURED to goal** — focused 100 % line / 78.6 % branch, `complete_target_scope: false`; below safety 100 % and below QM 85 % branch; 73 is the CI threshold, not platform acceptance |
| Unit/component testing executed and recorded (criteria 6–7) | `verification_plan.rst:320-327`; `verification_guideline.rst` | **PARTIAL** — focused identifier TU 85/85 retained (87 in tree now); `runtime_tests.cpp` and full `socom_test` not run (native exit 127) |
| Sanitizer / concurrency checks | `code_analysis.rst`; `build_and_test_host.yml:30-35` | **PARTIAL / BLOCKED** — focused ASan/LSan/UBSan pass; TSan environment failure; native sanitizers exit 127 |
| Interface / requirements-based / resource / fault-injection test types | `verification_process.rst` | **NOT PERFORMED / applicability not inferred** — no harness; identifier-only tests must not be labelled platform validation |
| Boundary / equivalence derivation | `verification_process.rst` | **SOURCE-ONLY** — cases exist; only the focused TU executed |
| Fuzzy testing technique | `verification_plan.rst:265-270` | **NOT EXECUTED / NOT CLAIMED** |
| Linking tests to requirements (record properties) | `verification_process.rst` (`gd_req__verification_link_tests_cpp`) | **PARTIAL** — `DerivationTechnique`/`Description` present; `TestType`/`Verifies` deliberately unset (no invented identifiers) |
| Independence of verification / review by a different committer | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Implementation inspection checklist IMPL_01…IMPL_03 | `inspection_checklist.rst` (draft) | **NOT FILLED** |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** — `bazel`, `valgrind`, `gitleaks`, `pre-commit`, `reuse`, `clang-format` unavailable; clang-tidy config rejected; Coverity not adopted |
| Obligation collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **RETAINED, NOT PASSING** — 25 checks present; most blocked/failed |
| Native acceptance | `source-index.json` | **`not_inferred`** for every entry |

**Explicit non-satisfaction statement.** Missing tools, the unknown safety class and un-inferred
applicability, the incomplete CodeQL/cppcheck extraction, the below-goal focused coverage, the
dependency/macro-only analyzer findings, and the unanswered human reviews mean **none of the
checked obligations may be treated as satisfied**. A retained collection result shows *retention*,
not passing.

---

## 8. Measurement and validation status

- **Tools:** `read_file`, `grep`, `glob`, `write_file` only. No `shell`, delegation, web, approval,
  publishing, or engineering acceptance.
- **Measurements executed this iteration:** **none**. All numbers are readings of the retained
  artifacts and of the working tree; all expected behaviours are labelled source-derived.
- **Scope of the retained runs:** the compile/analyze/sanitize/coverage runs cover the **focused
  identifier translation unit** (`service_identifier.cpp` + `string_registry.cpp` +
  `service_identifier_tests.cpp`); they do not compile `runtime_tests.cpp` or the full
  `socom_test` / `//score/...` targets, and CodeQL uses a focused database. Full native runtime
  tests are `not_executed` (`validation/measurement.json`).
- **Staleness:** the retained host measurement is 85 cases; the working tree now has 87
  `TEST_F` in `service_identifier_tests.cpp` (`rework_progress` `source_changed_this_round: true`).
- **Reconciliation of the artifact set:** the earlier prior reports said
  `.llm_tmp/overnight/validation/` and `.llm_tmp/overnight/obligations/` were absent; they are
  **present now** and this report reads them directly. That changes availability, not passing.
- **Reproduction path for a later, permitted iteration (not executed here):** see §5.

---

## 9. Notice preservation

- No source, build, test, config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was created, edited, or
  deleted by this iteration; only this report was written.
- The header the task flagged (`score/socom/impl/service_identifier.hpp`) was inspected and left
  unchanged because it is already brace-balanced and otherwise well-formed (§2). The sibling
  `service_identifier.cpp`, both BUILD files, and both candidate test files retain their
  Apache-2.0/SPDX headers (`:1-12`).
- All 19 files under `.llm_tmp/overnight/reports/` and all 12 files under
  `.llm_tmp/overnight/prior-reports/` were preserved; this document is the 20th `reports/` entry.
- This report itself carries the Apache-2.0 header.

---

## 10. Pending human review checklist

- [ ] **Confirm §2**: `service_identifier.hpp` is brace-balanced (four brace lines `:19,:29,:32,:38`;
      line 39 blank); the recorded "extra closing brace at line 39" is stale or refers to a
      different revision. No source correction is required in this checkout.
- [ ] **Resolve the instruction conflict**: correct-the-source vs. review-draft-only-report; confirm
      that writing only this report was intended.
- [ ] **Repair `.clang-tidy` (G1/G2)** with an authorized change: unfold the `Checks: >` block so the
      `#` comments are not folded into check names, and re-evaluate
      `clang-analyzer-alpha.security.ArrayBoundV2` and `modernize-use-integer-sign-comparison` for the
      pinned clang-tidy version. Do **not** suppress checks inside this slice.
- [ ] **Decide whether criterion 9 uses the default build or the explicit
      `--features=treat_warnings_as_errors`** build (`.bazelrc:117` disables it by default).
- [ ] **Decide the CodeQL posture (G4–G8, G16):** full-target extraction, MISRA mapping completion
      (the mapping is `:status: draft`), human qualification/deviation, and whether Coverity is
      adopted or the guideline/plan discrepancy is resolved. No MISRA-compliance claim until then.
- [ ] **Disposition the cppcheck `passedByValue` findings (G9)** in `registry_string_view.hpp` and
      `service_interface_identifier.hpp` — acceptable performance style or a separate change.
- [ ] **Record a deviation (or macro-aware tooling) for the CodeQL MISRA `external-linkage` hits on
      `service_identifier_tests.cpp`** (gtest `TEST_F` expansion); do not patch the test framework or
      silently suppress the rule.
- [ ] **Restore the missing native tools** (`bazel` at the pinned path, `valgrind`, `gitleaks`,
      `pre-commit`, `reuse`, `clang-format`) and re-run §5 so `native_lint`, `native_coverage`,
      `native_sanitizers`, `native_tsan` and the warnings-as-errors build produce real results.
- [ ] **Re-run the coverage goal check** against the platform 85 %/100 % thresholds; do not report
      the collector's 73 threshold as platform acceptance.
- [ ] **Supply native requirement/interface identifiers** for traceability, or record applicability
      as unresolved (no invented links).
- [ ] **Run the full native suite** (`//score/...`, including `runtime_tests.cpp`, and the
      integration/QEMU set) and schedule independent human review (`gd_req__verification_independence`).
- [ ] **Keep the wider #84 public `Service_interface_identifier` restructure, FindService wildcard,
      and the config minor-wildcard narrowing out of this bounded slice** until separately accepted,
      and do not present the identifier-only tests as platform validation or claim an unmeasured
      fuzzy technique.
