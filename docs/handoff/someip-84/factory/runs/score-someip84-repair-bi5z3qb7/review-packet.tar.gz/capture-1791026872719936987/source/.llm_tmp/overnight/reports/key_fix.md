<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — registration-key correction (`key_fix`) review draft

**Document type:** review draft (actual-source inspection + registration-key correction
record + preserved-rule verification + obligations status).

**Date:** 2026-10-03
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version
handling in socom* (issue #84)
**Run / branch:** `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ`; current HEAD `5722740`
(`fabro(01M3ZRSDK2XQAF1H48VWTPKQNZ): node_d2fdb79acfbec37dfb74066b (success)`), per the
run environment and `.git/logs/HEAD:5`. Completed stages supplied with this task:
`node_3752dc1af9e2f3b0ee1454f2`, `node_51f7ccb6b2715b106cf242f4`,
`node_edd8fcbae2fee64d3bbd0c31`, `node_d2fdb79acfbec37dfb74066b` (all success).
**Verified baseline commit:** `f8a196c3b16d5172d898394ab99b0ed81346d63d`
(`.llm_tmp/context/source-manifest.json:3`).
**Status:** **local, unprotected, scoped.** No engineering acceptance exists. Human
reviews are unanswered. Full native runtime tests are pending. Nothing in this document
is acceptance, review, publication, or a full native run.

> **Tool / write boundary observed.** This iteration used only `read_file`, `grep`,
> `glob`, and `write_file`. No delegation, no web access, no approval, no publishing,
> and no engineering acceptance was performed. A single attempted `shell` invocation was
> refused by the environment ("Overnight tool/path boundary"); it produced no output and
> no change, and no shell-based measurement was obtained. The task permits changing only
> the six named candidate source paths and this report. Of those, **exactly one file was
> written — this report** (`/workspace/.llm_tmp/overnight/reports/key_fix.md`). No source,
> build, test, config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was created, edited, or
> deleted, and every prior report was preserved unchanged.

> **Why no source edit was made, although the six paths were writable.**
> 1. The task records "a measured GCC syntax failure: an extra closing brace in
>    `score/socom/impl/service_identifier.hpp` at line 39" and directs: "Inspect and
>    correct the actual source before expanding tests." Direct inspection of the *actual*
>    checkout shows the header is **already brace-balanced** and line 39 is **blank**
>    (§2). There is no unmatched closing brace to remove. Applying the historical repair
>    to the balanced file would be a no-op; deleting a brace would *introduce* a syntax
>    failure and a regression.
> 2. The task also asks to "Implement the smallest registration-key correction preserving
>    interface representation and exact-major/minimum-minor rules." That correction
>    (duplicate-key identity `(instance, service id, major)`; `minor` excluded) is
>    **already present** in `score/socom/impl/service_identifier.cpp:28-29` (§3); the
>    public interface representation and the exact-major / `client.minor <= server.minor`
>    compatibility rules are unchanged (§4); and the key-level and runtime-level
>    regressions are already present (§5).
>
>   The smallest correct change to already-correct source is therefore **no change**.
>   The minimal syntax repair is retained in §2.3 for reference only.

---

## 0. Summary

1. **Recorded syntax failure — inspected; not present in the actual source.**
   `score/socom/impl/service_identifier.hpp` is brace-balanced. A `grep` for `[{}]` on
   the file returns exactly four lines: `:19` (`namespace score::socom {`), `:29`
   (`struct Service_instance_identifier final {`), `:32` (`};`), and `:38` (the single
   `}  // namespace score::socom`). Two openers and two closers give a net brace balance
   of `0`; line 39 is empty and line 40 is `#endif`. There is **no third, unmatched
   closing brace** (§2). The described defect is a stale, pre-correction description;
   the `reproducer` iteration of this run already records the header as balanced
   (`.llm_tmp/overnight/reports/reproducer.md` §2).
2. **Registration-key correction — present and minimal.** The key's only operator,
   `operator<(Service_instance_identifier const&, Service_instance_identifier const&)`
   (`score/socom/impl/service_identifier.cpp:20-30`), compares `(instance, service id,
   major)`, so the **minor version is excluded** from the duplicate-server identity
   (`:28-29`). This makes the duplicate gate exactly as coarse as the deliberately
   minor-ignoring `Service_database` record index
   (`score/socom/impl/runtime_impl.hpp:116-134`).
3. **Interface representation and the exact-major / minimum-minor rules preserved.**
   `Service_interface_identifier{Id id; Version{std::uint16_t major; std::uint16_t
   minor;}}` is unchanged (`score/socom/service_interface_identifier.hpp:73-124`,
   `:80-88`); the exact-major and `client.minor <= server.minor` ("minimum-minor") rules
   remain enforced by `is_minor_version_compatible` / `is_interface_compatible`
   (`score/socom/impl/runtime_impl.cpp:133-146`), **not** by the key (§4).
4. **Tests and wiring present.** `score/socom/test/unit/service_identifier_tests.cpp`
   carries **87 `TEST_F`** cases under `ServiceInstanceIdentifierTest` (`:168`…`:2012`,
   counted this iteration by `grep`); `score/socom/test/unit/runtime_tests.cpp` carries
   **31 `TEST_F` + 1 `TEST` + 1 `TEST_P`** (`:239`…`:1311`), including the minor-only
   duplicate regression `ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError`
   (`:402-431`); both BUILD files already wire the test-only key header and the test
   framework. No BUILD change is required (§5).
5. **No obligation is satisfied.** No build, no test and no runtime ran here. The pinned
   obligation entries are `native_acceptance: not_inferred`; `authority.json` records
   `engineering_acceptance: pending`, `human_reviews: unanswered`,
   `safety_class: unknown`. `.llm_tmp/overnight/validation/` and
   `.llm_tmp/overnight/obligations/*/result.json` are **absent from this checkout**
   (§1.5, §7). Missing tools, unknown applicability, incomplete extraction, and
   unanswered human reviews are **not** treated as satisfied.

---

## 1. Binding to the verified baseline, prior reports, host feedback, obligations

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` | `.llm_tmp/context/issue-snapshot.json:2-4` |
| Title | *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:3` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` (unchanged) | `.llm_tmp/context/issue-snapshot.json:19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an
accepted obligation**. It distinguishes: service-instance identifier =
`service id + major + minor + instance id`; service identifier = `service id + major`;
FindService = `service id + major + optional<minor> + optional<instance>`; and proposes to
"exclude the minor version and make it a property of the service instance". The FindService
`major = FF` AUTOSAR case is called theoretically possible but not useful. There is **no
comment and no acceptance record** in the snapshot, so none of it is binding.

### 1.2 Verified baseline and current tree

| Item | Value | Source |
|------|-------|--------|
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |
| Current branch | `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ` | run environment |
| Current HEAD | `5722740` — `node_d2fdb79acfbec37dfb74066b (success)` | `.git/logs/HEAD:5` |

Binding is **by baseline commit**, not by run HEAD. Earlier reports reference other run IDs
on the same baseline commit, so they describe the same baseline and remain admissible prior
evidence. No local hashing tool was available, so the working tree was **not** re-hashed;
the direct source reads in §2–§5 are authoritative for this report.

### 1.3 In-scope candidate files (the only writable source paths)

From `.llm_tmp/context/candidate-files.json:1-25` (baseline blobs cross-checked against the
`files` array of `.llm_tmp/context/source-manifest.json`):

| File (repo-relative) | Baseline git blob | Baseline present | Current working tree |
|----------------------|-------------------|------------------|----------------------|
| `score/socom/BUILD` | `3477ea0851fdcd82ec6ea9d71424013cbdf41962` | yes | `testonly` `impl_service_identifier` exposure present (`:46-54`) |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e22355242009fe20dada2a9a0d0c7a9c7` | yes | key identity `(instance, id, major)`; `minor` excluded (`:28-29`) |
| `score/socom/impl/service_identifier.hpp` | `c8bae7908da9f087c518934f7b9f8d86db9a20ec` | yes | brace-balanced, 40 lines, `:39` blank (§2) |
| `score/socom/test/unit/BUILD` | `3c03a7b14286051f97fa5022206564bd63645171` | yes | `socom_test` globs `*.cpp`; deps wired (`:16-29`) |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab726db8bf994c960045d6fd7fdf84d7395` | yes | 31 `TEST_F` + 1 `TEST` + 1 `TEST_P`; minor-only regression `:402-431` |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(none — `null`)* | **no** (manifest expects a **new** file) | 87-case `TEST_F` matrix present |

The `null` baseline blob for `service_identifier_tests.cpp` is the manifest's expectation of
a **new** unit-test file; it exists on disk only as part of the un-merged working tree (the
task's "cancelled draft"), never in the baseline. `glob **/service_identifier*` returns
exactly three paths — `impl/service_identifier.cpp`, `impl/service_identifier.hpp`, and
`test/unit/service_identifier_tests.cpp` — so there is **no second, differently-braced copy**
of the header in this checkout. `glob **/*.{orig,rej,bak,patch,diff}` returns only the
unrelated `third_party/*.patch` files, so no leftover reject/patch file carries the defect.

### 1.4 Prior reports read and preserved

- `.llm_tmp/overnight/prior-reports/` — 38 files present, all preserved; `key_fix.md`,
  `invariants.md`, `callsites.md`, `reproducer.md`, `scope.md`, `unit_matrix.md`,
  `ordering_tests.md`, `conversion_tests.md`, `runtime_disabled.md`, `runtime_enabled.md`,
  `lifetime_tests.md`, and `test_metadata.md` were read; the remainder were cross-checked.
- `.llm_tmp/overnight/reports/` — read, not modified: `scope.md`, `callsites.md`,
  `invariants.md`, `reproducer.md` (the four earlier nodes of this run). This document adds
  `key_fix.md`.

Derived sequence across the preserved reports: `scope.md` (bounded the slice; identified the
key/index identity gap) → `invariants.md` (I-1…I-16; I-4 baseline key included `minor`, I-9
record index ignores it, I-11 the resulting gap) → `callsites.md` (call-site map) →
`reproducer.md` (header brace correction + focused red regression) → `key_fix.md` /
`unit_matrix.md` (drop `minor` from the ordering; expand the key tests) → `ordering_tests.md`
(property tests) → `runtime_disabled.md` / `runtime_enabled.md` / `lifetime_tests.md` (runtime
regressions) → `conversion_tests.md` (conversion boundaries) → `test_metadata.md` (record
properties).

**Reconciliation of the brace claims across prior reports.** The earliest reports
(`scope.md` §2, `invariants.md` §2, `callsites.md` §2) quote lines 38-39 as the split-form
double close (`}  // namespace socom` + `}  // namespace score`) and record the header as
**broken**; every later report records it as **already balanced**. The actual source read
this iteration (§2) matches the later set: the correction is already applied, and line 39 is
blank in place of the removed brace.

### 1.5 Host validation feedback and obligation-collection results

- **Host feedback under `.llm_tmp/overnight/validation/`: absent from this checkout.**
  `glob .llm_tmp/overnight/validation/**` returns no entries; there is no `validation/`
  directory and no host feedback to reconcile against.
- **Obligation-collection results under `.llm_tmp/overnight/obligations/`: absent from this
  checkout.** `glob .llm_tmp/overnight/obligations/**` returns no entries; no `*/result.json`
  exists. Earlier reports *retain summaries* of host artifacts (`check-result: 0`;
  `measurement.json` `origin: local_unprotected_measurement`, `initiator: Fabro host hook`,
  `engineering_acceptance: pending`, `full_native_tests: not_executed`; focused identifier-TU
  capture with 46 / 0 and later 83 / 0; focused coverage `service_identifier.cpp` 100 % line /
  50 % branch; sanitizer captures; clang-tidy configuration blocker; native/bazel legs failing
  to fetch toolchains). **Per the task rule, a successful collection node means results were
  retained, not that checks passed; here nothing is retained at all, so no obligation may be
  treated as satisfied on that basis.**
- Those retained summaries are also **scoped and stale**: they compiled only the focused
  identifier translation unit (`service_identifier.cpp` + `string_registry.cpp` +
  `service_identifier_tests.cpp`) with `g++-12 -std=c++17 -Wall -Wextra -Werror`; they did
  **not** compile `runtime_tests.cpp` or the full `socom_test` / `//score/...` targets.

### 1.6 Pinned obligation sources and authority (all read this iteration)

All nine entries of `.llm_tmp/context/obligations/source-index.json`, together with
`.llm_tmp/context/obligations/authority.json`, were read from
`.llm_tmp/context/obligations/`. Every entry is pinned `"native_acceptance": "not_inferred"`
— pinned, but its applicability to this slice is **not inferred**.

| id | pinned file (id → path) | status note |
|----|-------------------------|-------------|
| `coding_guidelines` | `docs/contribute/development/cpp/coding_guidelines.rst` | MISRA C++:2023 with C++17; `:status: valid` |
| `code_analysis` | `docs/contribute/development/cpp/code_analysis.rst` | clang-tidy + gcc/clang warnings + Coverity; sanitizers; `:status: valid` |
| `misra_mapping` | `docs/contribute/development/cpp/misra_2023_rule_mapping.rst` | **`:status: draft`**; rule table not a valid obligation |
| `verification_plan` | `docs/platform_management_plan/software_verification.rst` | `:status: valid`; quality criteria incl. criterion 9 "Freedom from compiler warnings & errors" |
| `development_plan` | `docs/platform_management_plan/software_development.rst` | `:status: valid`; C++17, GCC host compiler, QCC target, Bazel |
| `tool_management` | `docs/platform_management_plan/tool_management.rst` | `:status: valid`; tools identified / evaluated / qualified by a human |
| `verification_process` | `process/process_areas/verification/guidance/verification_process_reqs.rst` | `:status: valid`; `gd_req__verification_link_tests_cpp`, `_independence`, `_checks_extended`, `_external_aou`, `_sca_classification` |
| `verification_guideline` | `process/process_areas/verification/guidance/verification_guideline.rst` | `:status: valid`; traceability, independence, documented results |
| `inspection_checklist` | `score/component_example/docs/detailed_design/chklst_impl_inspection.rst` | **`:status: draft`**; blank `IMPL_01_01`…`IMPL_03_02` template |

**Authority record** (`.llm_tmp/context/obligations/authority.json:1-7`):
`engineering_acceptance: pending`; `human_reviews: unanswered`; `safety_class: unknown`;
`codeql_scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload"`; instruction
*"Restart the failed queue for one complete pass through all obligations"*.

**Safety-class note (recorded, not resolved).** The pinned platform documents carry
`:safety: ASIL_B`, while `authority.json` records `safety_class: unknown` and no authorized
selection exists. The document attribute is **not** a selection of the slice's safety class
and must not be inferred as one.

---

## 2. The recorded syntax failure: inspection of the actual source

### 2.1 Finding (re-verified this iteration by direct `read_file` + `grep`)

`score/socom/impl/service_identifier.hpp` is **brace-balanced**. It is 40 lines; a `grep` for
`[{}]` returns exactly four matches:

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`) and two closers (`:32`, `:38`) mean net brace balance `0`. There is
**no third, unmatched closing brace**, and line 39 contains no text at all. The sibling
`score/socom/impl/service_identifier.cpp` is balanced the same way (braces at `:18`, `:20`,
`:30`, `:32`). The task's "extra closing brace … at line 39" is therefore a **stale,
pre-correction description** that matches the earliest prior reports (which quote lines 38-39
as the split-form `}  // namespace socom` + `}  // namespace score`), not this checkout. The
`reproducer` iteration applied the correction; the removed brace left line 39 blank, exactly
as observed here.

### 2.2 Repository convention (evidence)

The tree uses two internally-consistent styles:

- **Nested open + single close:** `namespace score::socom {` … one
  `}  // namespace score::socom`. This is the public
  `service_interface_identifier.hpp` (`:25` / `:164`), `error.hpp`, and the key header itself.
- **Split open + double close:** `namespace score {` + `namespace socom {` … `}  // namespace
  socom` + `}  // namespace score`. This is `impl/runtime_impl.hpp`.

`impl/service_identifier.hpp` follows the **nested** form consistently and is balanced.

### 2.3 Minimal repair (retained for reference only; not applied because not needed)

Should the imbalance ever reappear, the minimal correction — matching the sibling `.cpp` and
the nested form — is:

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

Applying it to the already-balanced file would be a no-op; deleting a brace to "fix" the
file would *create* the reported defect.

### 2.4 Why it would matter if present

The header is compiled into `//score/socom:socom` (`score/socom/BUILD:24-41`; its `srcs`
globs `impl/**/*.cpp` and `impl/**/*.hpp`) and re-exposed to `//score/socom/test/unit` via the
`testonly` library `impl_service_identifier` (`score/socom/BUILD:46-54`;
`score/socom/test/unit/BUILD:24`). A syntax error here would fail both the library and the
whole `socom_test` target, contradicting S-CORE quality criterion 9, "Freedom from compiler
warnings & errors, 100 %" (`verification_plan.rst`). The current balanced state removes that
blocker at the source level; that is **not** a compile measurement (§8).

---

## 3. The bounded registration-key correction

### 3.1 The change (present in `score/socom/impl/service_identifier.cpp:20-30`)

```cpp
return std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major) <
       std::tie(rhs.instance, rhs.interface.id, rhs.interface.version.major);
```

This is the smallest change that makes the duplicate-server registration key consistent with
the record index. `std::set` uniqueness is `!(a < b) && !(b < a)`, so identity is exactly
`(instance, service id, major)` and **the minor version is excluded**. The ordering relies
only on already-available operators: `Service_instance::operator<`
(`service_interface_identifier.hpp:69-71`) and `Registry_string_view::operator<`
(`registry_string_view.hpp:141-143`).

For contrast, the pre-correction (baseline) ordering reported by `prior-reports/invariants.md`
I-4 was `std::tie(lhs.instance, lhs.interface) < std::tie(rhs.instance, rhs.interface)`,
delegating to `Service_interface_identifier::operator<` / `Version::operator<`
(`service_interface_identifier.hpp:140-143`, `:159-162`) and therefore including `minor`. The
baseline blob is not re-readable here, so that is a prior-report reading, not a direct re-read.

The key type itself is unchanged in representation:
`Service_instance_identifier{ Service_interface_identifier interface; Service_instance
instance; }` (`impl/service_identifier.hpp:29-32`), with `operator<` as its only operator
(`:35`; declaration hidden with `\cond`) and **no** `operator==`/`std::hash`. It is used only
as the `std::set` element type
(`using Service_identifiers = Mutexed_variable<std::set<Service_instance_identifier>>`,
`impl/runtime_impl.hpp:56`), constructed at `runtime_impl.cpp:443` and inserted under the key
mutex at `:449-454`.

### 3.2 What is preserved (as the task requires)

| Rule | Evidence | Preserved |
|------|----------|-----------|
| Interface representation | `Service_interface_identifier{Id id; Version{major, minor}}`, both fields `std::uint16_t` (`score/socom/service_interface_identifier.hpp:73-124`, `:80-88`) | yes |
| Exact-major | `major` is an identity component of the key (`service_identifier.cpp:28-29`) and of `is_interface_compatible` (`runtime_impl.cpp:144`) | yes |
| Minimum-minor (client minor ≤ server minor) | `is_minor_version_compatible` (`runtime_impl.cpp:133-136`) and `is_interface_compatible` (`:138-146`); **not** part of the key | yes |
| `Service_database` minor-ignoring index | `Minor_version_ignoring_key_equal` / `Minor_version_ignoring_hash` (`runtime_impl.hpp:116-134`) untouched | yes |
| Public/ABI surface | the key stays an `impl/`-only type (`score/socom/BUILD:17-41`, `:46-54`) | yes |
| Ordering-only identity | no `operator==`/`std::hash` added for the key; `operator<` remains the single rule | yes |

### 3.3 Why this direction (source-derived, not accepted)

- `Service_database` already defines record identity as `id + major + instance` and resolves
  both server and client connectors through it (`runtime_impl.hpp:116-134`;
  `runtime_impl.cpp:313-324`, call sites `:496`, `:530`).
- The single-server-per-record precondition is asserted, not tolerant
  (`SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)`, `runtime_impl.cpp:369`), followed by
  `m_server.emplace(...)` at `:371`.
- Therefore the duplicate gate must be **at least as coarse as** record identity. Excluding
  `minor` from the key is the minimal way to achieve that: two configurations sharing
  `id + major + instance` but differing only in `minor` now collide at the set insertion in
  `Runtime_impl::make_server_connector` (`runtime_impl.cpp:443`, `:449-454`) and the second is
  rejected with `Construction_error::duplicate_service` (`:451-452`), instead of reaching the
  single-`std::optional` server path.

This does **not** settle the wider open questions (whether `minor` should move onto
`Service_instance`, whether a minor-only collision should supersede, FindService wildcard
handling, the config `0xFFFFFFFF` minor narrowing). Those remain deferred.

---

## 4. Interface representation and compatibility rules

- **Public identifier.** `Service_interface_identifier` is a struct with `Id id` and
  `Version version`, and `Version` holds `std::uint16_t major` and `std::uint16_t minor`
  (`score/socom/service_interface_identifier.hpp:73-124`, `:80-88`). Its `operator==` /
  `operator<` and `std::hash` still include both `major` and `minor` (`:130-162`,
  `:181-190`). This is untouched by the key change.
- **Exact-major.** `is_interface_compatible` requires `server.version.major ==
  client.version.major` (`runtime_impl.cpp:144`).
- **Minimum-minor.** `is_minor_version_compatible` is `client.version.minor <=
  server.version.minor` (`runtime_impl.cpp:133-136`), applied at the client bind and server
  connect paths. It is **not** encoded in the registration key.
- **Record index.** `Service_database::m_service_records` groups by `id + major` and ignores
  `minor` via `Minor_version_ignoring_key_equal` / `Minor_version_ignoring_hash`
  (`runtime_impl.hpp:116-134`).

The key change therefore coarsens only the duplicate-server gate; it does not alter the
public type, the compatibility semantics, or the record index.

---

## 5. Tests and build wiring

### 5.1 Key-level tests

`score/socom/test/unit/service_identifier_tests.cpp` (new file per the manifest; Apache-2.0
header present) carries an **87-case** identity/ordering matrix under
`ServiceInstanceIdentifierTest` (counted this iteration by `grep`; cases span `:168`…`:2012`),
including:

- irreflexivity (`SameIdentifierIsNotLessThanItself`, `:168`);
- minor exclusion at adjacency, `uint16` extremes, sweeps and set-find
  (`KeysDifferingOnlyInMinorVersionAreDuplicates` `:174`,
  `MinorVersionBoundariesAreDuplicates` `:182`, `AllMinorVersionsCollapseToSingleKey` `:192`,
  `MinorHighBitVariantsAreEquivalent` `:203`, `MinorVersionNeverAffectsOrdering` `:430`,
  `SetFindLocatesMinorVariantAndCountsItOnce` `:1034`,
  `StdSetCollapsesFiveMinorVariantsOfEveryIdentity` `:1321`);
- major including `0`/`65535` boundaries and adjacency
  (`KeysDifferingInMajorVersionAreDistinct` `:217`,
  `MajorVersionBoundariesAreDistinct` `:225`, `MajorVersionSweepProducesDistinctKeys` `:235`,
  `AdjacentMajorVersionBoundariesAreDistinct` `:246`);
- service-id and instance identity, plus distinct-set sizes;
- combined matrices (2x2x2 and 3x3x3 with minor collapse, `:358`…`:419`);
- equivalence and ordering consistency (equivalence ⇔ `(instance, id, major)`, transitivity,
  exactly-one-direction ordering, set iteration vs an independent tuple reference,
  `:420`…`:536`);
- strict-weak-ordering property checks over deterministic 36-key and 64-key domains
  (`:537`…`:735`, `:1055`…`:1148`, `:1456`…`:1488`);
- text/registry → public-identifier → internal-key conversion boundaries
  (`:784`…`:1054`, `:1149`…`:1200`, `:1531`…`:1600`).

The record metadata is set in `SetUp()` (`:42-65`):
`DerivationTechnique = "boundary-values,equivalence-classes"` and a `Description`. `TestType`
and the `Verifies`/`PartiallyVerifies`/`FullyVerifies` links are deliberately **not** set,
because no verified native requirement/interface identifier exists for this slice and
inventing one is prohibited. The type declares no `operator==`/hash, so "equality" is defined
as mutual non-ordering (`!(a<b) && !(b<a)`), which is exactly the `std::set` equivalence.

### 5.2 Runtime-level regression

`score/socom/test/unit/runtime_tests.cpp:402-431`
(`ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError`) exercises the
real registration entry point: it builds two `Service_interface_identifier`s that share id
(`"TestInterface"`), major (`1`) and instance (`"TestInterface"`) and differ only in `minor`
(2 vs 3), calls `Runtime::make_server_connector()` twice via the public `Runtime` interface,
and expects the second call to equal
`score::MakeUnexpected(Construction_error::duplicate_service)`. The file also carries
same-configuration disabled (`:440`), different-major (`:471`), enabled-duplicate (`:694`),
lifetime/reuse (`:371`, `:986`, `:1021`), and service-id/instance/major slot isolation
(`:1253`, `:1197`, `:1141`) cases, plus the metadata helper `record_registration_key_metadata`
(`:264-267`). Both connectors remain disabled, so the duplicate is rejected at construction
and never reaches the single-server `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)` path.

### 5.3 Boundary / equivalence coverage versus the host addendum

- **Boundary values:** major `0`, `1`, `0x7FFF`, `0x8000`, `0xFFFE`, `65535`; minor `0`, `1`,
  `2`, `3`, `0x7FFF`, `0x8000`, `65535` are covered by the key tests.
- **Equivalence classes:** minor-only (equivalent) versus service-id / instance / major
  differences (distinct) are covered, including combined matrices and deterministic multi-key
  domains.
- **Still absent / unknown applicability (explicit pending work):** no fuzz harness, no
  fault-injection harness, and no full feature-/platform-level reference-hardware tests exist
  in this workspace; no fuzzy technique was executed. These identifier-only tests must
  **not** be presented as platform validation. The minimum-minor rule is exercised by other
  suites (`interface_compatibility_tests.cpp`, `client_tests.cpp`), not by this key slice.

### 5.4 Build wiring (no BUILD change required)

- `score/socom/BUILD:46-54` defines the `testonly` `impl_service_identifier` library exposing
  `impl/service_identifier.hpp` to `//score/socom/test/unit:__pkg__`, depending on `:socom`.
- `score/socom/test/unit/BUILD:16-29` defines `socom_test` with
  `srcs = glob(include = ["*.cpp"])` and depends on `//score/socom:impl_service_identifier`,
  `//score/socom:mock`, `//score/socom/test/framework:socom_test_framework`, and googletest.

Therefore both test files are already collected and the internal key header is visible to the
test package; **no BUILD change was required or made.**

---

## 6. Files changed / state of the six candidate paths

This iteration wrote **only this report** (`key_fix.md`). No candidate source path needed a
change:

| Candidate path | State | This iteration |
|----------------|-------|----------------|
| `score/socom/impl/service_identifier.hpp` | brace-balanced, nested namespace, documents minor exclusion | unchanged (verified) |
| `score/socom/impl/service_identifier.cpp` | `operator<` identity `(instance, id, major)`, minor excluded | unchanged (verified) |
| `score/socom/BUILD` | `testonly impl_service_identifier` exposure present | unchanged |
| `score/socom/test/unit/BUILD` | `socom_test` globs `*.cpp`, deps wired | unchanged |
| `score/socom/test/unit/runtime_tests.cpp` | minor-only duplicate regression present | unchanged |
| `score/socom/test/unit/service_identifier_tests.cpp` | 87-case key matrix present | unchanged |
| `.llm_tmp/overnight/reports/key_fix.md` | **new — this report** | written |

No file outside the six candidate paths and this report was written; no `NOTICE`, `LICENSE`,
or `REUSE.toml` file was created, edited, or deleted; all prior reports were preserved.

---

## 7. Obligations status (none satisfied)

### 7.1 Pinned state

All nine pinned sources in `.llm_tmp/context/obligations/` were read this iteration (§1.6);
every `source-index.json` entry is `"native_acceptance": "not_inferred"`. `authority.json`
records `engineering_acceptance: pending`, `human_reviews: unanswered`, `safety_class:
unknown`, `codeql_scope: Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload`, and
the instruction *"Restart the failed queue for one complete pass through all obligations"*.

### 7.2 Status for this slice (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Freedom from compiler warnings & errors (100 %) | `verification_plan.rst` (criterion 9) | **NOT MEASURED** — header is brace-balanced by inspection (§2), but nothing was compiled; no host artifact is present |
| Static code analysis (clang-tidy / CodeQL), findings classified | `code_analysis.rst`; `verification_process.rst` (`gd_req__verification_sca_classification`) | **NOT PERFORMED** — no tool, no build; a prior clang-tidy attempt was blocked on configuration; CodeQL MISRA applicability unestablished (draft mapping) |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` | **UNKNOWN — NOT CLAIMED** — mapping is `:status: draft`; not applied |
| Structural statement / branch coverage goals | `verification_plan.rst` (criteria 1-2) | **NOT MEASURED** — no test execution; prior coverage capture is out of this checkout and below the platform goals |
| Unit/component testing executed, results recorded | `verification_plan.rst` (criteria 6-7); `verification_guideline.rst` | **NOT EXECUTED** — 0 tests run; the prior key-TU run is stale and excludes `runtime_tests.cpp` |
| Interface / requirements-based / resource / fault-injection test types | `verification_process.rst`; `verification_plan.rst` | **NOT PERFORMED / applicability not inferred** — no harness; identifier-only tests must not be labelled platform validation |
| Boundary / equivalence derivation | `verification_process.rst` | **SOURCE-ONLY** — cases exist (§5.3) but were not executed |
| Fuzzy testing technique | `verification_plan.rst` | **NOT EXECUTED / NOT CLAIMED** — no harness and no measurement |
| Linking tests to requirements (record properties) | `verification_process.rst` (`gd_req__verification_link_tests_cpp`) | **PARTIAL / NOT DONE** — `DerivationTechnique`/`Description` recorded; `TestType` and `Verifies` cannot be set without inventing identifiers |
| External-component AoUs verified | `verification_process.rst` (`gd_req__verification_external_aou`) | **NOT SATISFIED** — no integration/static verdict; no AoU register |
| Independence of verification / review by a different committer | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Implementation inspection checklist IMPL_01…IMPL_03 | `inspection_checklist.rst` | **NOT FILLED** — draft template, no inspection |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** for this slice; no tool run here |
| Obligation collection results retained | `.llm_tmp/overnight/**/result.json` | **ABSENT in this checkout** — no `result.json` present |
| Native acceptance | `source-index.json` | **`not_inferred` for every entry** |

**Explicit non-satisfaction statement.** Missing tools (no build/test in this task), the
unknown safety class and un-inferred applicability, the incomplete extraction of host
artifacts, the absent obligation-collection results, and the unanswered human reviews mean
**none of the checked obligations may be treated as satisfied**. A collection node that
retained results would only show *retention*, not passing; here there are no retained results
at all. In particular, the absence of `.llm_tmp/overnight/validation/` and
`.llm_tmp/overnight/**/result.json` is **not** evidence that the corresponding checks passed.

---

## 8. Measurement and validation status

- **Tools:** `read_file`, `grep`, `glob`, `write_file` only. No delegation, web, approval,
  publishing, or engineering acceptance. A single attempted `shell` invocation was refused by
  the environment and had no effect.
- **Executed measurements:** **none** this iteration. No build, no `bazel test`, no runtime.
  The brace census (§2), the key identity (§3) and the expected test behaviour (§5) are static
  source readings and strict-weak-ordering consequences, not observed results.
- **Test inventory (read, not run):** `service_identifier_tests.cpp` has **87 `TEST_F`** under
  `ServiceInstanceIdentifierTest` (`:168`…`:2012`, verified by `grep`); `runtime_tests.cpp` has
  **31 `TEST_F`** (`:279`…`:1253`) **+ 1 `TEST`** (`:239`) **+ 1 `TEST_P`** (`:1311`),
  verified by `grep`.
- **Regression target (source-derived, not executed):**
  `RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError`
  (`runtime_tests.cpp:402-431`) and the key-level minor-collapse cases
  (`service_identifier_tests.cpp:174`, `:182`, `:192`, `:203`, …) assert that a second
  registration differing only in `minor` is rejected as `duplicate_service`. On a key that
  includes `minor` they would fail; on the working-tree key they should pass. This is a
  `std::set` / strict-weak-ordering consequence, not an observed result.
- **Scope:** local, unprotected, scoped. This is a bounded correction/verification record, not
  an accepted engineering decision. Full native runtime tests and human review remain pending.
- **Reproduction path for a later, permitted iteration (not executed here):**

  ```bash
  bazel test //score/socom/test/unit:socom_test
  # focused key-level:
  bazel test //score/socom/test/unit:socom_test --test_filter='ServiceInstanceIdentifierTest.*'
  # focused runtime regression:
  bazel test //score/socom/test/unit:socom_test \
      --test_filter='RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError'
  # integration / cross / docs / traceability (per the pinned plans)
  bazel test --config=qemu-integration //tests/integration_test/...
  ```

  Expected on the working-tree key: the minor-only key tests collapse to one set element and
  the runtime regression returns `Construction_error::duplicate_service`. On a key that
  includes `minor`, both focused checks would fail. These expectations are source-derived, not
  measured.

---

## 9. Notice preservation

- No source, build, test, config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was created,
  edited, or deleted by this iteration; only this report was written. Every existing
  Apache-2.0 / SPDX notice header is untouched, and all 38 prior-report files under
  `.llm_tmp/overnight/prior-reports/` plus the four earlier files under
  `.llm_tmp/overnight/reports/` were preserved.
- The header the task flagged (`score/socom/impl/service_identifier.hpp`) was inspected and
  left unchanged because it is already brace-balanced and otherwise well-formed (§2). The
  sibling `service_identifier.cpp`, both BUILD files, and both candidate test files likewise
  retain their Apache-2.0 / SPDX headers.
- This report itself carries the Apache-2.0 header. No licensed MISRA rule text is reproduced;
  only native rule/query identifiers, file locations, and prior-report readings are cited.
- The duplicate key remains an `impl/`-only type; the `testonly`
  `//score/socom:impl_service_identifier` library exposes it to `//score/socom/test/unit`
  only, so no public header or notice surface changed.

---

## 10. Pending human review checklist

- [ ] **Confirm the §2 inspection:** the header is already brace-balanced (braces at `:19`,
      `:29`, `:32`, `:38`; line 39 blank; single nested close `}  // namespace score::socom`),
      so the recorded syntax failure is stale and no source edit is required. If the "cancelled
      draft" is a different revision that still carries the extra brace, locate it and
      authorize its correction; no such file exists in this checkout.
- [ ] **Resolve the instruction conflict:** the task directs correcting the source, while the
      actual source contains no defect; confirm that a no-op (report only) is the intended
      outcome here.
- [ ] **Confirm the bounded key decision in §3:** `minor` is **not** part of the
      duplicate-server registration key; identity `(instance, service id, major)`; interface
      representation and the exact-major / minimum-minor rules unchanged.
- [ ] **Confirm the baseline binding in §1.2-1.3** (issue #84 ↔ commit `f8a196c3…`) and that
      `prior-reports/invariants.md` I-4's baseline ordering (`minor` included) still describes
      the committed baseline.
- [ ] **Confirm `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)`** (`runtime_impl.cpp:369`) is the
      authoritative single-server invariant, so the key must be at least as coarse as the
      record index.
- [ ] **Confirm the key test matrix (§5.1)** and the runtime regressions (§5.2) are the intended
      coverage, and that the boundary/equivalence cases satisfy the host addendum (§5.3). Do
      **not** present the identifier-only tests as platform validation or claim an unmeasured
      fuzzy technique.
- [ ] **Keep the #84 public `Service_interface_identifier` restructure, FindService wildcard
      handling, and the config minor-wildcard narrowing out of this bounded slice** until
      separately accepted.
- [ ] **Supply native requirement source IDs and traceability metadata** (no invented links),
      or record applicability as unresolved.
- [ ] **Supply the missing artifacts** (`.llm_tmp/overnight/obligations/*/result.json` and
      `.llm_tmp/overnight/validation/`) into this checkout; do not infer passing from absence
      or from prior reports' retained summaries.
- [ ] **Run the full native suite** (`bazel test //score/socom/test/unit:socom_test` and the
      broader `//score/...` set), including `runtime_tests.cpp`, record results, and schedule
      independent human review (the approver must differ from the author, per
      `gd_req__verification_independence`).
- [ ] **Select a safety class** via the authorized role; do not infer the slice's class from the
      `:safety: ASIL_B` attribute on the pinned platform documents (§1.6).

---

*End of registration-key correction review draft. Local, unprotected, scoped. No engineering
acceptance; human reviews unanswered; full native runtime tests pending. Every statement is a
local reading of the working tree, a prior report's recorded reading, or an explicitly-labelled
logical consequence — none is acceptance, review approval, publication, or a full native run.*
