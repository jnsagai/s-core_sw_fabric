<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — native test-metadata review and verified requirement-link record (`test_metadata`)

**Document type:** review draft (actual-source inspection + S-CORE test-metadata review +
verified requirement-link inventory + current host-measurement reconciliation)
**Date:** 2026-10-02
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version handling in
socom*. This iteration covers the **test metadata and verified requirement links** of that work.
**Run:** `fabro/run/01M3YRJEGXNY6CB81T7TKW774B`; per the environment's recent-commit list HEAD is
`1206f55` (`fabro(…): node_752868eb24b56f82737549dd (success)`), on top of
`30d1338` (node_3c836be9f362f38d7263c8da), `858cb72` (node_dee137f989ad16364f9e1784) … The run
branch is `fabro/run/01M3YRJEGXNY6CB81T7TKW774B`.
**Status:** local, unprotected, scoped. **No engineering acceptance exists. Human reviews are
unanswered. Full native runtime tests remain pending.** Nothing here is a published, reviewed,
accepted, or full native-run engineering artifact.

> **Tool / write boundary observed.** Only `read_file`, `grep`, `glob` and `write_file` were used;
> no `shell`, delegation, web access, approval, publishing, or engineering acceptance was performed.
> The task permits changing only the six named candidate source paths and this report. This iteration
> wrote **exactly one file — this report**. None of the six candidate paths was changed, because the
> recorded brace defect is **not present in the actual source** (§2) and the source-supported
> metadata the task asks for is **already present** in the two candidate test files (§4). No
> `NOTICE`, `LICENSE`, `REUSE.toml`, config, production-source, BUILD, or prior-report file was
> created, edited, or deleted; every prior report and every host artifact was preserved (§9).

> **Recorded syntax-failure premise — inspected; the defect is not present in the actual source, and
> the retained host compile independently refutes it.** The task states the cancelled draft has "a
> measured GCC syntax failure: an extra closing brace in
> `score/socom/impl/service_identifier.hpp` at line 39". Direct inspection of the working tree shows
> the header is **brace-balanced** (§2): the only brace-bearing lines are `:19`
> (`namespace score::socom {`), `:29` (`struct Service_instance_identifier final {`), `:32` (`};`)
> and `:38` (the single `}  // namespace score::socom`); line `:39` is **blank** and line `:40` is
> `#endif`. Independently, the retained host `after-compile` compiled a translation unit that
> includes this header with `g++-12 -std=c++17 -Wall -Wextra -Werror` and exited `0` with empty
> stderr, which is incompatible with a surviving syntax error. **No source correction was applied
> and none is required**; re-introducing a broken brace state so it could be "fixed" would be a
> regression. The six writable source paths were available; the smallest correct edit was the empty
> edit.

---

## 0. Summary

1. **Recorded syntax failure — inspected; not present in the actual source.** The header is
   brace-balanced: `grep '[{}]'` returns exactly four lines (`:19`, `:29`, `:32`, `:38`) and line
   `:39` is empty. A repository-wide `glob` finds a single `service_identifier.hpp`, so there is no
   second, differently-braced copy. The description matches only the earliest, pre-correction
   reports, not this checkout. **No header edit was made** (§2).
2. **Native test-metadata convention reviewed.** The pinned `verification_process.rst` requires C++
   tests to link to requirements through gtest **record properties**
   (`gd_req__verification_link_tests_cpp`, `:56-75`); `gd_req__verification_checks` (`:178-196`)
   requires `TestType` and `DerivationTechnique` to be set and `Description` non-empty;
   `gd_req__verification_checks_extended` (`:198-212`) makes a `requirements-based` /
   `interface-test` `TestType` conditional on a real requirement/interface link; and
   `verification_plan.rst` fixes the allowed identifier sets (`:167-207`, `:245-268`) (§3).
3. **The source-supported metadata is present in the two candidate test files and was verified
   this iteration (no change needed).** `service_identifier_tests.cpp` records
   `DerivationTechnique = "boundary-values,equivalence-classes"` and a non-empty `Description` in
   the fixture `SetUp()` (`:42-65`); `runtime_tests.cpp` records
   `DerivationTechnique = "design-analysis,equivalence-classes"` plus a per-case `Description`
   through the fixture helper `RuntimeTest::record_registration_key_metadata` (`:253-267`), called by
   all **25** duplicate-server registration-key cases. The header, the `.cpp` and the two BUILD files
   carry their Apache-2.0 / SPDX license metadata and the `testonly` / `tags = ["unit"]` build
   metadata already (§4). **No additional source-supported metadata value exists to record**, and
   `TestType` / the `Verifies` links cannot be validly set without inventing a native identifier
   (§3, §5).
4. **No verified native requirement identifier exists for this slice, and none was invented.**
   The only real `:id:` requirements in the repository are the stakeholder requirement
   `stkh_req__someip_gw__interoperability` and the TC8 set
   (`feat_req__tc8_conformance__conformance`, `comp_req__tc8_conformance__*`). None scopes socom
   registration-key / version handling. `docs/requirements/component/index.rst` and
   `docs/requirements/feature/index.rst` are placeholder indexes with no requirement directives,
   and no `:reqtype: Interface` need exists anywhere. `TestType` and the
   `PartiallyVerifies`/`FullyVerifies` links therefore remain **deliberately unset and explicit**
   in both test files; the gap is recorded, not fabricated (§5).
5. **Latest host validation is now present, retained and green for the focused identifier
   translation unit only.** `.llm_tmp/overnight/validation/` holds `check-result = 0`,
   `measurement.json` (`check_ref: check_conversion_tests`, `mode: ubsan`,
   `engineering_acceptance: pending`, `full_native_tests: not_executed`; candidate
   `compile_exit 0 / test_exit 0 / 85 tests / 0 failures`; `baseline_with_agent_tests`
   `85 tests / 28 failures`), `after.json` (85 / 0) and `before.json` (85 / 28), plus the
   compile/test command and stdout/stderr captures (§6). This is a **local, unprotected, scoped**
   measurement; it does **not** compile `runtime_tests.cpp` or the full `socom_test` / `//score/...`
   targets.
6. **No obligation is satisfied.** `.llm_tmp/overnight/obligations/*/result.json` is **absent**
   from this checkout; `authority.json` records `engineering_acceptance: pending`,
   `human_reviews: unanswered`, `safety_class: unknown`. Missing tools, unknown applicability,
   incomplete extraction and unanswered human reviews are **not** treated as satisfied (§7, §8).

---

## 1. Binding to the verified baseline, prior reports, host feedback, obligations

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` | `.llm_tmp/context/issue-snapshot.json:2-4` |
| Title | *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:3` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` (unchanged) | `.llm_tmp/context/issue-snapshot.json:19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**: service-instance identifier = `service id + major + minor + instance id`; service
identifier = `service id + major`; FindService = `service id + major + optional<minor> +
optional<instance>`; and the proposal to "exclude the minor version and make it a property of the
service instance". The FindService `major = FF` AUTOSAR case is called theoretically possible but
not useful. There is **no comment and no acceptance record** in the snapshot, so none of it is
binding.

### 1.2 Verified baseline

| Item | Value | Source |
|------|-------|--------|
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |
| Working branch | `fabro/run/01M3YRJEGXNY6CB81T7TKW774B` | environment |
| Current HEAD | `1206f55` — `node_752868eb24b56f82737549dd (success)` | environment recent-commit list (no shell available to re-read `.git`) |

Binding is **by baseline commit**, not by run HEAD. Earlier reports reference other run IDs on the
same baseline commit (`01M3YGTGYFEN406VDEVVTJTRWV`, `01M3XZAQ65TTE35XSGXC4JAMAH`,
`01M3XT7NQ04S4MTFRMTT2401XK`, `01M3WX09X84XFM5X08QY2944DF`, and before them
`01M3WSTF1DAJA248NQ5QQGQG52`/`a282596` and `01M3WWRQWT262FTYS52X80YPTP`/`e12e7cb`), so all of them
describe the same baseline and remain admissible prior evidence for this slice.

### 1.3 In-scope candidate files (the only writable source paths)

From `.llm_tmp/context/candidate-files.json:1-25` (baseline blobs cross-checked against the `files`
array of `.llm_tmp/context/source-manifest.json`):

| File (repo-relative) | Baseline git blob | Baseline present | This iteration |
|----------------------|-------------------|------------------|----------------|
| `score/socom/BUILD` | `3477ea0851fdcd82ec6ea9d71424013cbdf41962` | yes | inspected, **unchanged** (testonly key exposure `:46-54` present) |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e22355242009fe20dada2a9a0d0c7a9c7` | yes | inspected, **unchanged** (identity `(instance, id, major)`; issue-#84 rationale comment; license header) |
| `score/socom/impl/service_identifier.hpp` | `c8bae7908da9f087c518934f7b9f8d86db9a20ec` | yes | inspected, **unchanged** (already brace-balanced, §2) |
| `score/socom/test/unit/BUILD` | `3c03a7b14286051f97fa5022206564bd63645171` | yes | inspected, **unchanged** (`glob(include = ["*.cpp"])`, `tags = ["unit"]`, deps wired) |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab726db8bf994c960045d6fd7fdf84d7395` | yes | inspected, **unchanged** (record-property metadata already present, §4.3) |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(none — `null`)* | no (manifest expects a **new** file) | inspected, **unchanged** (record-property metadata already present, §4.2) |

The `null` baseline blob for `service_identifier_tests.cpp` is the manifest's expectation of a
**new** unit-test file; it exists on disk only as part of the un-merged working tree (the
"cancelled draft"), never in the baseline. The five present baseline blobs also appear in the
`files` array of `.llm_tmp/context/source-manifest.json`.

**Manifest-hash note (explicit).** The `sha256` values in `.llm_tmp/context/candidate-files.json`
are a **start-of-task snapshot**; the current working tree has evolved inside the allowed six paths
(later nodes of this run added the two empty-text conversion cases and the metadata block), so the
recorded values for `service_identifier_tests.cpp` (`45d07399…`) and `runtime_tests.cpp`
(`5e35e24d…`) no longer match the measured tree. The retained host `measurement.json.source_hashes`
records the measured content (`service_identifier_tests.cpp` = `65c10517…`, `runtime_tests.cpp` =
`9a2d6a15…`). No local hash tool was available; neither value was independently recomputed here.
The candidate set is bound by **path and baseline blob**, not by the stale start-of-task hash.

### 1.4 Pinned obligation sources read this iteration

All nine entries of `.llm_tmp/context/obligations/source-index.json` are present in
`.llm_tmp/context/obligations/`, together with `authority.json`; the document-status lines were
re-read directly:

| id | file | status note |
|----|------|-------------|
| `coding_guidelines` | `coding_guidelines.rst` | `:status: valid`; MISRA C++:2023 with C++17 |
| `code_analysis` | `code_analysis.rst` | `:status: valid`; clang-tidy + gcc/clang warnings + Coverity; sanitizers; coverage |
| `misra_mapping` | `misra_mapping.rst` | **`:status: draft`**; the rule table is commented out |
| `verification_plan` | `verification_plan.rst` | `:status: valid`, `:safety: ASIL_B`; TestType / DerivationTechnique tables (`:167-207`, `:245-268`) and quality criteria 1-9 |
| `development_plan` | `development_plan.rst` | `:status: valid`; C++17, GCC host compiler, Bazel |
| `tool_management` | `tool_management.rst` | `:status: valid`; tools must be identified / evaluated / qualified |
| `verification_process` | `verification_process.rst` | `:status: valid`; `gd_req__verification_link_tests_cpp` (`:56-75`), `gd_req__verification_independence` (`:141-152`), `gd_req__verification_checks` (`:178-196`), `gd_req__verification_checks_extended` (`:198-212`) |
| `verification_guideline` | `verification_guideline.rst` | `:status: valid`; traceability, independence, documented results |
| `inspection_checklist` | `inspection_checklist.rst` | **`:status: draft`**; blank `IMPL_01…IMPL_03` template |

Every entry in `source-index.json` is pinned with `"native_acceptance": "not_inferred"` — pinned,
but its applicability to this slice is **not inferred**. `authority.json` records
`"engineering_acceptance": "pending"`, `"human_reviews": "unanswered"`, `"safety_class":
"unknown"`, `"codeql_scope": "Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload"`, and
the instruction "Restart the failed queue for one complete pass through all obligations".

### 1.5 Prior reports read and preserved

- `.llm_tmp/overnight/prior-reports/` — **12 files present** (verified by `glob`), all preserved.
  The metadata-relevant ones were read this iteration: `test_metadata.md` (the earlier review of
  this same topic), plus `scope.md`, `invariants.md`, `callsites.md`, `reproducer.md`, `key_fix.md`,
  `unit_matrix.md`, `ordering_tests.md`, `conversion_tests.md`, `runtime_disabled.md`,
  `runtime_enabled.md`, `lifetime_tests.md`. Earlier reports cite a 13th sibling
  `repair_unit_matrix.md` and host files `coverage_tests_repair.md`, `tool_findings_repair.md`,
  `obligation-addendum.md`; **none of those four is present** in this checkout, so their content is
  available only as quoted by the other reports.
- `.llm_tmp/overnight/reports/` (this run's earlier nodes, read and preserved): `scope.md`,
  `callsites.md`, `invariants.md`, `reproducer.md`, `key_fix.md`, `unit_matrix.md`,
  `ordering_tests.md`, `runtime_disabled.md`, `runtime_enabled.md`, `lifetime_tests.md`,
  `conversion_tests.md`. This document adds `reports/test_metadata.md`; it does **not** overwrite the
  same-named file under `prior-reports/`.

Derived sequence: `scope.md` (bounded the slice) → `invariants.md` (I-4 baseline key included
`minor`; I-9 record index ignores `minor`; I-11 the resulting gap) → `callsites.md` → `reproducer.md`
(header brace correction + focused red regression) → `key_fix.md` / `unit_matrix.md` (drop `minor`
from the ordering; expand key tests) → `ordering_tests.md` → runtime/lifetime reports →
`conversion_tests.md` → `test_metadata.md` (record properties) → **this report** (metadata re-review
on the current, host-measured tree).

### 1.6 Host validation feedback and obligation-collection results

- **Host feedback is present in this checkout** under `.llm_tmp/overnight/validation/`
  (`measurement.json`, `before.json`, `after.json`, `check-result`, and the `before`/`after`
  compile/test command + stdout/stderr captures). It is summarised and reconciled in §6.
- **Obligation-collection results are absent.** `glob .llm_tmp/overnight/obligations/*` and a
  repository-wide `glob **/result.json` return nothing; no
  `.llm_tmp/overnight/obligations/*/result.json` exists here. Per the task rule, a successful
  collection node means results were **retained**, not that checks **passed**; here nothing is
  retained at all, so **nothing may be treated as satisfied on that basis**.

### 1.7 Host addendum (task context, not acceptance)

Earlier reports quote `prior-reports/obligation-addendum.md` (not present in this checkout) stating
it "is task context, not engineering acceptance or an approved tailoring decision". It asks the
review to cover the `verification_process.rst` test types and derivation techniques; to keep unknown
applicability and unexecuted applicable checks explicit; to **not** label identifier-only tests as
full platform validation and **not** to claim a fuzzy technique without a measurement; to permit
concrete boundary/equivalence regression cases within the six source paths; and to record that there
is **no authority to invent native links, select a safety classification, accept risk/deviations, or
answer the independent human gate.** This report honours that in §3-§8.

---

## 2. The recorded syntax failure: inspection of the actual source

### 2.1 Finding (direct `read_file` + `grep` this iteration)

`score/socom/impl/service_identifier.hpp` is **brace-balanced**. It is 40 lines:

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

`grep '[{}]'` on the file returns exactly four matches — `:19`, `:29`, `:32`, `:38`. Two openers and
two closers give net brace balance `0`; `:39` contains no text at all. `grep 'namespace'` returns only
`:19` and `:38` (the matched nested form, not the split `namespace socom` / `namespace score` pair).
A `glob **/service_identifier.hpp` returns exactly one path, so there is no second,
differently-braced copy. The task's "extra closing brace … at line 39" is therefore a **stale,
pre-correction description** that matches the earliest prior reports (which quote lines 38-39 as the
split-form double close); the `reproducer` iteration applied the correction and every later report —
and this direct read — shows the balanced state.

### 2.2 Independent corroboration from the retained host measurement

The host validation retained in this checkout compiled this header as a transitive include of
`service_identifier.cpp` (which `#include "service_identifier.hpp"`) with
`/usr/bin/x86_64-linux-gnu-g++-12 -std=c++17 -Wall -Wextra -Werror`; the `after-compile.command.json`
records `exit_code: 0` and `after-compile.stderr` is **empty** (no diagnostic for the header). A
surviving unmatched brace would have made that compilation fail. This is a local, unprotected,
scoped capture, not acceptance, but it is decisive on the *syntax* question.

### 2.3 Minimal repair (retained for reference only; not applied because not needed)

Should the imbalance ever reappear, the minimal correction — matching the sibling `.cpp` — is:

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

Applying this to the already-balanced file would be a no-op at best and a regression at worst. No
production source was edited, and the recorded "inspect and correct the actual source before
expanding tests" precondition is met without a write because there is no actual source defect. The
file was **not** "corrected" merely to produce a diff.

---

## 3. Native test conventions and allowed metadata identifiers

The pinned authority is `verification_process.rst` (`:status: valid`):

- `gd_req__verification_link_tests` (`:20-54`) names the metadata — **Verifies**
  (`PartiallyVerifies`, `FullyVerifies`), **Description**, **TestType**, **DerivationTechnique** —
  and fixes their allowed values.
- `gd_req__verification_link_tests_cpp` (`:56-75`) states verbatim: *"For linking C++ tests to
  requirements **record properties** shall be used. Attributes which are common for all test cases
  can be specified in the Setup Function (SetUp()), the other attributes which are specific for each
  test case need to be specified within the test case."* The referenced `verification_template_cpp`
  is **not present** in the pinned sources or this repository, so the property spelling is derived
  from the requirement text and from the two candidate files that already implement it.
- `gd_req__verification_checks` (`:178-196`) requires `TestType` and `DerivationTechnique` to be set
  and `Description` non-empty; in a Unit Test, if `Partially/FullyVerifies` are set they shall link
  to at least one Component Requirement.
- `gd_req__verification_checks_extended` (`:198-212`): a `requirements-based` `TestType` requires a
  requirement link; an `interface-test` `TestType` requires an interface link.
- `gd_req__verification_methods_multiple` (`:125-139`): several derivation techniques may be
  combined in one property.
- `verification_plan.rst` fixes the identifiers:
  `TestType ∈ {static-code-analysis, structural-statement-coverage, structural-branch-coverage,
  walkthrough, inspection, interface-test, requirements-based, resource-usage}` (`:167-207`) and
  `DerivationTechnique ∈ {requirements-analysis, design-analysis, boundary-values,
  equivalence-classes, fuzz-testing, error-guessing, explorative-testing}` (`:245-268`).

**Native in-repo convention (verified this iteration).** A repository-wide `grep 'RecordProperty'`
(over `score/**`) returns **only** the two candidate test files:
`service_identifier_tests.cpp:50-51` and `runtime_tests.cpp:265-266`. No other C++ test in this
repository uses gtest record properties; the de-facto convention elsewhere is prose comments plus
the Bazel `tags = ["unit"]`. Because the pinned process mandates record properties for C++ tests,
this slice uses them rather than inventing a comment schema. A repository-wide `grep` for
requirement-link comments (`req__`, `@verifies`, `Verifies`, `TestType`, …) in `score/**` finds
**nothing**, confirming that no in-tree C++ source links to requirements by any other mechanism.

---

## 4. Metadata present in the six candidate files (verified; no source-supported addition is missing)

### 4.1 Production and build files — license/build metadata present, no test record properties applicable

| Candidate path | Metadata present (verified) |
|----------------|------------------------------|
| `score/socom/impl/service_identifier.hpp` | Apache-2.0 / SPDX header (`:1-12`); inner documentation comment (`:21-28`) states the identity semantics and the intentional minor exclusion. `RecordProperty` is a gtest-only facility and is not applicable to a production header. |
| `score/socom/impl/service_identifier.cpp` | Apache-2.0 / SPDX header (`:1-12`); rationale comment (`:21-27`) links the change to issue #84 and to `is_interface_compatible`. No gtest record properties apply. |
| `score/socom/BUILD` | Apache-2.0 / SPDX header (`:1-12`); the test-only exposure library `impl_service_identifier` carries `testonly = True` and package-scoped visibility (`:46-54`); the production `socom` library carries `features = COMPILER_WARNING_FEATURES` (`:34`). |
| `score/socom/test/unit/BUILD` | Apache-2.0 / SPDX header (`:1-12`); the `socom_test` target carries `size = "small"`, `linkstatic = True`, `tags = ["unit"]` and the required deps (`:16-29`). |

### 4.2 `score/socom/test/unit/service_identifier_tests.cpp` — metadata present and host-confirmed

The Apache-2.0 header is at `:1-12`. The `ServiceInstanceIdentifierTest` fixture (class at `:40`)
records, in `SetUp()` (`:42-65`):

```cpp
RecordProperty("DerivationTechnique", "boundary-values,equivalence-classes");
RecordProperty(
    "Description",
    "Deterministic identity, ordering, boundary and equivalence-class checks for the "
    "Service_instance_identifier duplicate-server registration key (issue #84): the key "
    "identity is (instance, service id, major) and the minor version is not part of it.");
```

Placed per `gd_req__verification_link_tests_cpp` (common attributes in `SetUp()`), using only
identifiers allowed by `verification_plan.rst`. The file holds **85 `TEST_F`** cases under that
fixture (`:168` … `:1929`, counted this iteration by `grep`; the two cases added by later nodes of
this run are `ConvertedEmptyTextInterfacePathsAgreeAtVersionBoundaries` at `:1882` and
`ConvertedEmptyTextInstancePathsAgreeWithRegistryPath` at `:1929`), all concerning the same
registration-key contract, so the fixture-wide attributes correctly describe every case. The block
at `:57-64` explicitly documents why `TestType` and the `Verifies` links are omitted. The file ends
at `}  // namespace score::socom` (`:1965`).

The retained host JUnit report `after.json` independently shows both properties on **all 85** cases
(e.g. `after.json:28-29`), so this metadata is **measured/verified for the identifier translation
unit** as well as source-present.

### 4.3 `score/socom/test/unit/runtime_tests.cpp` — metadata present and source-supported

The Apache-2.0 header is at `:1-12`. The shared `RuntimeTest` fixture (class at `:244`) carries a
small protected helper (`:253-267`):

```cpp
void record_registration_key_metadata(std::string const& description) {
    RecordProperty("DerivationTechnique", "design-analysis,equivalence-classes");
    RecordProperty("Description", description);
}
```

Its doc comment (`:253-263`) states both the derivation rationale and the explicit omission of
`TestType` / `Verifies` for the same reason as the key file. A `grep
'record_registration_key_metadata'` returns the definition at `:264` and **25 call sites**:
`:335`, `:351`, `:372`, `:403`, `:442`, `:473`, `:507`, `:540`, `:575`, `:609`, `:643`, `:695`,
`:728`, `:765`, `:798`, `:834`, `:871`, `:906`, `:953`, `:987`, `:1048`, `:1094`, `:1142`,
`:1198`, `:1254`. Each call passes a per-case `Description`, which is exactly the "per-case
attributes in the test case" half of `gd_req__verification_link_tests_cpp`. The `DerivationTechnique`
combines `design-analysis` (the key derives from the `Runtime_impl` registration-key design and its
lifetime) and `equivalence-classes` (same `(instance, service id, major)` is a duplicate; a
different component is a distinct key) — both allowed identifiers.

The file structure verified this iteration: **1 `TEST`** (`:239`), **31 `TEST_F`**
(`:279`…`:1253`), **1 `TEST_P`** (`:1311`). The 25 metadata-carrying cases are the duplicate/lifetime
registration-key cases; the unrelated bridge/factory tests and the `RuntimeBridgeTest`
parameterised case deliberately receive **no** registration-key metadata, because their subject is
not the key.

### 4.4 What was considered for addition and why nothing was added

The task asks to "add verified metadata … when source-supported". The following candidates were
evaluated and rejected because they are **not** source-supported:

| Candidate addition | Verdict |
|--------------------|---------|
| `DerivationTechnique` / `Description` record properties | **Already present** in both test files (§4.2, §4.3); re-adding would duplicate. |
| `TestType = requirements-based` | **Forbidden** — needs a Component Requirement link; the only real requirement ids scope TC8/stakeholder, not socom registration (§5). `gd_req__verification_checks_extended` explicitly forbids it without a requirement link. |
| `TestType = interface-test` | **Forbidden** — needs an interface link; no `:reqtype: Interface` need exists (§5). |
| `TestType = structural-statement-coverage` / `structural-branch-coverage` | **Not source-supported** — no coverage measurement is retained for this slice in this checkout; the tests are not a coverage-tool artifact. Setting it would be an unmeasured claim. |
| `TestType = static-code-analysis` / `walkthrough` / `inspection` / `resource-usage` / `fault-injection` | **Inapplicable / false** — these unit tests exercise code at runtime; they are not a static analysis, walkthrough, inspection, resource evaluation, or fault-injection harness. |
| `PartiallyVerifies` / `FullyVerifies` link | **Prohibited** — would require inventing a native requirement identifier (§5). |
| License / build metadata on the BUILD and source files | **Already present** (§4.1). |
| A new comment linking the header to issue #84 | **Cosmetic only**, not S-CORE metadata; the semantics are already documented at `:21-28`, and the sibling `.cpp` already carries the explicit issue reference. Not added, to keep the change surgical. |

Consequently **no candidate source file was modified**. The missing `TestType` and requirement-link
identities remain **explicit** rather than filled with an invented value.

---

## 5. Verified requirement-link inventory and missing identities

### 5.1 Verified requirement-link inventory (nothing applicable to this slice)

A repository-wide search of the `:id:`/`req__` directives yields exactly the following real
requirement identifiers:

| Identifier (verified `:id:`) | Source | Applicable to this slice? |
|------------------------------|--------|---------------------------|
| `stkh_req__someip_gw__interoperability` | `docs/requirements/stakeholder.rst:24` | no — wire-level interoperability |
| `feat_req__tc8_conformance__conformance` | `docs/tc8_conformance/requirements.rst:25` | no — TC8 wire conformance |
| `comp_req__tc8_conformance__sd_offer_format` | `docs/tc8_conformance/requirements.rst:56` | no |
| `comp_req__tc8_conformance__sd_cyclic_timing` | `docs/tc8_conformance/requirements.rst:76` | no |
| `comp_req__tc8_conformance__sd_find_response` | `docs/tc8_conformance/requirements.rst:95` | no |
| `comp_req__tc8_conformance__sd_sub_lifecycle` | `docs/tc8_conformance/requirements.rst:114` | no |
| `comp_req__tc8_conformance__sd_phases_timing` | `docs/tc8_conformance/requirements.rst:136` | no |
| `comp_req__tc8_conformance__msg_resp_header` | `docs/tc8_conformance/requirements.rst:159` | no |
| `comp_req__tc8_conformance__msg_error_codes` | `docs/tc8_conformance/requirements.rst:181` | no |
| `comp_req__tc8_conformance__evt_subscription` | `docs/tc8_conformance/requirements.rst:205` | no |

The other `:id:` values in the repository are architecture/decision definitions rather than
requirement directives — `feat__someip_gateway` (`docs/architecture/features.rst:20`),
`comp__gatewayd` / `comp__serializer` / `comp__null_serializer` / `comp__someipd`
(`docs/architecture/components.rst`), `logic_arc_int__someip__serializer`
(`docs/architecture/components.rst:32`), and the `dec_rec__*` decisions — none of which is a linkable
requirement. `docs/requirements/component/index.rst` and `docs/requirements/feature/index.rst` are
placeholder indexes (toctree only) with no requirement directives; `grep req__` over
`docs/requirements/` finds no socom requirement, and a `grep` for `:reqtype:` finds only
`Functional` needs (the TC8 set plus the stakeholder requirement) — **no `:reqtype: Interface` need
exists**. Therefore there is **no verified native requirement identifier** for
`PartiallyVerifies`/`FullyVerifies`, and **no verified interface identifier** for an
`interface-test` `TestType`.

### 5.2 Missing identities (explicit)

| Missing identity | Why | Consequence |
|------------------|-----|-------------|
| Component requirement for socom registration-key / version handling | `docs/requirements/component/` holds only a placeholder index; no `comp_req__socom__*` exists | `PartiallyVerifies`/`FullyVerifies` unset; `TestType=requirements-based` unset |
| Interface requirement/identifier for `Service_instance_identifier` | no `:reqtype: Interface` need exists | `TestType=interface-test` unset |
| Human review / independence record | `authority.json`: `human_reviews: "unanswered"` | `gd_req__verification_independence` unmet |
| Obligation-collection `result.json` | `.llm_tmp/overnight/obligations/` absent from this checkout | no obligation retained, so none satisfied on that basis |

Native identifiers must be supplied by a human reviewer before these fields can be completed; the
slice remains metadata-incomplete until then. **No identifier was invented anywhere in this
change.** A `grep` across the two candidate test files confirms they contain no `comp_req__`,
`feat_req__`, or `stkh_req__` string.

---

## 6. Latest host validation feedback and measurement status

### 6.1 Retained artifacts in this checkout

| Artifact | Content |
|----------|---------|
| `validation/check-result` | `0` (the check reported success for the file it measured) |
| `validation/measurement.json` | `check_ref: check_conversion_tests`, `status: completed`, `mode: ubsan`, `changed_paths: ["score/socom/test/unit/service_identifier_tests.cpp"]`, `origin: local_unprotected_measurement`, `initiator: Fabro host hook`, `engineering_acceptance: pending`, `full_native_tests: not_executed`, compiler `/usr/bin/x86_64-linux-gnu-g++-12` (`compiler_sha256: 88315fd2…c196d3`) |
| `candidate` (from `measurement.json:2052-2058`) | `compile_exit: 0`, `test_exit: 0`, `tests: 85`, `failures: 0`, `disabled: 0` |
| `baseline_with_agent_tests` (`:2045-2051`) | `compile_exit: 0`, `test_exit: 1`, `tests: 85`, `failures: 28`, `disabled: 0` |
| `validation/after-compile.command.json` | focused `g++-12 -std=c++17 -Wall -Wextra -Werror -pthread -I. … score/socom/impl/service_identifier.cpp score/socom/impl/string_registry.cpp score/socom/test/unit/service_identifier_tests.cpp <gtest>` plus `-fsanitize=undefined -fno-sanitize-recover=all`; `exit_code: 0` |
| `validation/after-compile.stderr` | empty |
| `validation/after-test.command.json` | runs the built binary with `--gtest_output=json:…/after.json`; `exit_code: 0` |
| `validation/after.json` | JUnit report: `ServiceInstanceIdentifierTest`, **85 tests / 0 failures / 0 disabled**; every case carries `DerivationTechnique: "boundary-values,equivalence-classes"` and the fixture `Description` (e.g. `:28-29`) |
| `validation/before.json` | JUnit report: same suite, **85 tests / 28 failures** (the same agent tests against the uncorrected, minor-including key) |

### 6.2 Interpretation

The focused candidate translation unit compiles (with `-Werror` and UBSan) and all 85 key cases
pass, while the same tests against the baseline-with-agent-tests key fail 28. The recorded test
metadata (`DerivationTechnique`, `Description`) is observable in the JUnit output on every case, so
it is **verified by measurement for the identifier file**. This corroborates that the metadata is
correctly wired through `RecordProperty`. It is **local and unprotected** and is **not** acceptance.

### 6.3 Scope caveats

The retained measurement is a **focused, scoped** capture: it exercised only the identifier
translation unit (`service_identifier.cpp` + `string_registry.cpp` +
`service_identifier_tests.cpp` + googletest), **not** `runtime_tests.cpp` and **not** the full
`socom_test` / `//score/...` targets. The metadata present in `runtime_tests.cpp` is therefore
**source-derived but unmeasured** in this checkout. The full native suite, other sanitizer/coverage
runs, and static analysis remain pending. A `check-result` of `0` is a retained local measurement,
not engineering acceptance.

---

## 7. Files changed / state of the six candidate paths

This iteration wrote **only this report** (`.llm_tmp/overnight/reports/test_metadata.md`). No
candidate source path needed a change:

| Candidate path | State | This iteration |
|----------------|-------|----------------|
| `score/socom/impl/service_identifier.hpp` | brace-balanced, nested namespace, documents minor exclusion | **unchanged** (verified, §2) |
| `score/socom/impl/service_identifier.cpp` | `operator<` identity `(instance, id, major)`, minor excluded; issue-#84 rationale comment | **unchanged** (verified) |
| `score/socom/BUILD` | `testonly impl_service_identifier` exposure present | **unchanged** (verified) |
| `score/socom/test/unit/BUILD` | `socom_test` globs `*.cpp`, `tags = ["unit"]`, deps wired | **unchanged** (verified) |
| `score/socom/test/unit/runtime_tests.cpp` | record-property metadata present (helper `:253-267`, 25 calls) | **unchanged** (verified, §4.3) |
| `score/socom/test/unit/service_identifier_tests.cpp` | 85 `TEST_F`; `SetUp()` metadata `:42-65`; host-confirmed | **unchanged** (verified, §4.2) |
| `.llm_tmp/overnight/reports/test_metadata.md` | **new — this report** | written |

No file outside the six candidate paths and this report was written; no `NOTICE`, `LICENSE`, or
`REUSE.toml` file was created, edited, or deleted; all prior reports and host artifacts were
preserved.

---

## 8. Obligations status (none satisfied)

### 8.1 Pinned state from `authority.json`

| Field | Value |
|-------|-------|
| `codeql_scope` | Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload |
| `engineering_acceptance` | **pending** |
| `human_reviews` | **unanswered** |
| `safety_class` | **unknown** |
| `instruction` | "Restart the failed queue for one complete pass through all obligations" |

All nine pinned sources in `.llm_tmp/context/obligations/` were read this iteration (§1.4); every
`source-index.json` entry is `"native_acceptance": "not_inferred"`. `misra_mapping.rst` and
`inspection_checklist.rst` are `:status: draft`.

### 8.2 Status table

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Linking C++ tests to requirements via record properties | `verification_process.rst` (`gd_req__verification_link_tests_cpp`, `:56-75`) | **PARTIAL** — `DerivationTechnique` + `Description` recorded in `service_identifier_tests.cpp:50-55` (host-confirmed on all 85 cases) and in the 25 runtime key cases (`runtime_tests.cpp:253-267`); `TestType` and `Partially/FullyVerifies` unset because no verified native identifier exists (§5) |
| Test-metadata consistency checks | `verification_process.rst` (`gd_req__verification_checks` `:178-196`, `_extended` `:198-212`) | **NOT SATISFIED** — `TestType` cannot be validly set without an invented/unavailable link; the gap is recorded explicitly |
| Freedom from compiler warnings & errors (100 %) | `verification_plan.rst:332-335` (criterion 9) | **PARTIALLY MEASURED** — the focused candidate TU compiles with `g++-12 -Wall -Wextra -Werror -fsanitize=undefined` and passes (85/0); but only the focused TU, not the full `//score/...` build, and `runtime_tests.cpp` is not compiled by that run |
| Static code analysis (clang-tidy / CodeQL), findings classified | `code_analysis.rst`; `gd_req__verification_sca_classification` | **NOT PERFORMED** — no tool, no build in this iteration |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` (`:status: draft`) | **UNKNOWN** — mapping not applied |
| Structural statement / branch coverage goals | `verification_plan.rst` (criteria 1-2) | **NOT MEASURED** — no coverage run retained here |
| Unit/component testing executed, results recorded | `verification_plan.rst` (criteria 6-7); `verification_guideline.rst` | **PARTIAL / FOCUSED ONLY** — the retained host run executes 85 focused key cases (0 failures) against a baseline of 85/28; it does not build `//score/socom/test/unit:socom_test` or `//score/...` |
| Interface / requirements-based / resource / fault-injection test types | `verification_process.rst:20-54`; `verification_plan.rst:167-240` | **NOT PERFORMED / applicability not inferred** — identifier-only tests are not platform validation |
| Boundary / equivalence derivation | `verification_process.rst:43-50` | **METADATA-TAGGED / EXECUTED FOR THE KEY FILE ONLY** — tagged `boundary-values,equivalence-classes` and green in the focused run; the runtime cases are tagged `design-analysis,equivalence-classes` but are unmeasured |
| Fuzzy testing technique | `verification_plan.rst:265-270` | **NOT EXECUTED / NOT CLAIMED** — no harness, no measurement |
| Independence of verification / review by a different committer | `gd_req__verification_independence` (`:141-152`) | **NOT DONE** — human reviews unanswered |
| Implementation inspection checklist IMPL_01…IMPL_03 | `inspection_checklist.rst` (`:status: draft`) | **NOT FILLED** — draft template, no inspection |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** for this slice |
| Obligation-collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **ABSENT** — no result files in this checkout |
| Native acceptance | `source-index.json` | **not_inferred** for every entry |

**Explicit non-satisfaction statement.** Missing tools (no full build/test by this iteration), the
unknown safety class and un-inferred applicability, the incomplete extraction of host artifacts,
the absent obligation-collection results, and the unanswered human reviews mean **none of the
checked obligations may be treated as satisfied**. The presence of `.llm_tmp/overnight/validation/`
is a **local, unprotected, scoped** measurement of one focused translation unit; the absence of
`.llm_tmp/overnight/obligations/*/result.json` is likewise **not** evidence that the corresponding
checks passed. In particular, `TestType` being unset is a **known, recorded gap**, not a pass.

### 8.3 Host-addendum honesty

This report does **not** label the identifier-only tests as full platform validation and does
**not** claim that a fuzzy or fault-injection technique was executed. No fuzz/fault-injection
harness and no full feature/platform reference-hardware tests exist in this workspace; those remain
explicit pending work. No native requirement identifier was invented. The `structural-*-coverage`
`TestType` values were deliberately not claimed because no coverage measurement is retained here.

---

## 9. Notice preservation

- No source, build, test, config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was created, edited, or
  deleted by this iteration; only this report was written. Every existing Apache-2.0 / SPDX notice
  header in the candidate set is untouched: the two `.cpp` test files, `service_identifier.cpp`,
  `service_identifier.hpp`, and both BUILD files all retain their `:1-12` headers.
- The header the task flagged (`score/socom/impl/service_identifier.hpp`) was inspected and left
  unchanged because it is already brace-balanced and otherwise well-formed (§2).
- This report itself carries the Apache-2.0 header.
- The duplicate-server registration key remains an `impl/`-only type exposed only to
  `//score/socom/test/unit` through the `testonly` `//score/socom:impl_service_identifier` library,
  so no public header or notice surface changed.
- Every prior report under `.llm_tmp/overnight/prior-reports/` and `.llm_tmp/overnight/reports/`,
  and every host artifact under `.llm_tmp/overnight/validation/`, was preserved; the host artifacts
  were read only.

---

## 10. Pending human review checklist

- [ ] **Confirm §2:** `score/socom/impl/service_identifier.hpp` is already brace-balanced
      (`:19`, `:29`, `:32`, `:38`; line 39 blank); the "extra closing brace at line 39" is the
      stale pre-correction description, so no header edit was made. Re-check before any compile if
      the state ever changes.
- [ ] **Confirm the metadata already present** in `service_identifier_tests.cpp:42-65` and
      `runtime_tests.cpp:253-267` is the intended interpretation of
      `gd_req__verification_link_tests_cpp` (record properties; common attributes in `SetUp()`,
      per-case attributes in the test case), and that leaving `TestType`/`Verifies` unset pending a
      verified native link is acceptable (§4.4).
- [ ] **Supply the native requirement/interface identifiers** for this slice (a socom
      `comp_req__*` and, if `interface-test` is intended, an interface need), or record
      applicability as unresolved, so that `TestType` and `PartiallyVerifies`/`FullyVerifies` can
      be completed without invention (§5).
- [ ] **Confirm the metadata placement/format** against the `verification_template_cpp`, which is
      not available in the pinned sources or this repository.
- [ ] **Compile and run `runtime_tests.cpp`** (`bazel test //score/socom/test/unit:socom_test`) —
      the record properties there are unmeasured — and record results; run the broader
      `//score/...` set, including the native runtime tests.
- [ ] **Supply the missing obligation results** (`.llm_tmp/overnight/obligations/*/result.json`)
      and resolve the `engineering_acceptance: pending` / `human_reviews: unanswered` state.
- [ ] **Schedule independent human review** (the approver must differ from the author, per
      `gd_req__verification_independence`).
- [ ] **Do not treat the identifier-only/registration-key tests as platform validation**; provide a
      fuzz/fault-injection harness and full feature/platform reference-hardware tests separately,
      and do not claim an unmeasured fuzzy technique.
- [ ] **Keep the #84 public `Service_interface_identifier` restructure, FindService wildcard
      handling, and the config minor-wildcard narrowing out of this bounded slice** until
      separately accepted.
