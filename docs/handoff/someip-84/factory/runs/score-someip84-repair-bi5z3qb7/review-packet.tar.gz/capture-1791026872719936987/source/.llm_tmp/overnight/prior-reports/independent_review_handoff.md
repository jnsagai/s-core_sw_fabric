<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — independent-review handoff (duplicate-server registration-key slice)

**Document type:** review draft — **unanswered independent-review handoff**. Author/approver
separation, safety/security/quality role assignments, tool-qualification acceptance, deviation
disposition, test independence, and integration/release decision requests. Every decision field in
this document is intentionally **blank / UNANSWERED**.

**Date:** 2026-10-02
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version handling in
socom* (issue #84)
**Branch / run:** `fabro/run/01M3YRJEGXNY6CB81T7TKW774B`
**Baseline commit:** `f8a196c3b16d5172d898394ab99b0ed81346d63d`
(`.llm_tmp/context/source-manifest.json:3`)
**Status:** local, unprotected, scoped. **No engineering acceptance exists. Human reviews are
unanswered. Full native runtime tests are pending.** Nothing in this document is acceptance,
approval, publication, or a full native run.

> **Write boundary actually observed.** This iteration used only `read_file`, `grep`, `glob`, and
> `write_file`. No `shell`, no `edit_file`, no delegation, no web access, no approval, no publishing,
> and no engineering acceptance was performed. The task contains a conflict: *"Inspect and correct
> the actual source before expanding tests"* vs. the explicit, more specific final sentence *"This is
> a review draft: only that report may be written."* Following the explicit write boundary,
> **exactly one file was written — this report**
> (`/workspace/.llm_tmp/overnight/reports/independent_review_handoff.md`). No source, build, test,
> config, `NOTICE`, `LICENSE`, `REUSE.toml`, host-validation, obligation, or prior-report file was
> created, edited, or deleted.
>
> **The conflict is moot on the facts.** The described defect — *"a measured GCC syntax failure: an
> extra closing brace in `score/socom/impl/service_identifier.hpp` at line 39"* — is **not present
> in this checkout** (§3). The header is brace-balanced and line 39 is blank. There is no actual
> source to correct; applying the historical repair would be a no-op at best and a regression at
> worst. The exact minimal repair is retained in §3.3 for the event the imbalance ever reappears.
> No test was expanded: the draft's suites already exist on disk (§4).
>
> **Non-satisfaction rule applied throughout.** A successful obligation-collection node means results
> were **retained**, not that checks **passed**. Missing tools, unknown applicability, incomplete
> extraction, an inactive/draft rule mapping, and unanswered human reviews are **not** treated as
> satisfied. A tool that produced **no** finding because it **did not run** is recorded as *"not
> run"*, never as *"clean"*. **No AI-authored report and no green native/focused run counts as human
> approval.** Every review gate in §8 remains open.

---

## 0. Purpose and reader guide

This document is the **handoff artifact for the independent human review gate**. It is not a
verification report, not an approval, and not evidence that anything passed. It:

1. pins the reviewed artifact set and its exact hashes (§1–§2);
2. disposes of the recorded brace defect by direct inspection (§3);
3. inventories the current source and test state (§4);
4. records the retained host/obligation evidence and its limits (§5);
5. separates what is **not** satisfied from what merely **ran** (§6);
6. lists the open design/semantic questions the human reviewer must settle (§7);
7. lays out the **unanswered review gates** — author/approver separation, safety/security/quality
   roles, tool qualification acceptance, deviations, test independence, and integration/release
   decisions — each with the role that must answer it (§8);
8. records what this draft explicitly does **not** claim (§9), the notice preservation (§10), and
   the measurement/reproduction status (§11).

A reviewer should be able to take §8 and drive the human gate to closure without re-reading the
whole corpus, using §1–§7 as the evidence base.

---

## 1. Binding, scope, and authority

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` — *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:2-4` |
| State | `open`, 0 comments, no milestone / assignee / labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG`, created/updated `2026-04-14T13:23:24Z` | `.llm_tmp/context/issue-snapshot.json:8,19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**. It distinguishes *service-instance identifier* = `service id + major + minor +
instance id`; *service identifier* = `service id + major`; *FindService* = `service id + major +
optional<minor> + optional<instance>`; and proposes to "exclude the minor version and make it a
property of the service instance". There is **no comment and no acceptance record**, so none of it is
binding. Binding is **by baseline commit**, not by run HEAD.

### 1.2 Bounded candidate source paths (the only writable paths in the broader task)

From `.llm_tmp/context/candidate-files.json:1-25`:

1. `score/socom/BUILD`
2. `score/socom/impl/service_identifier.cpp`
3. `score/socom/impl/service_identifier.hpp`
4. `score/socom/test/unit/BUILD`
5. `score/socom/test/unit/runtime_tests.cpp`
6. `score/socom/test/unit/service_identifier_tests.cpp` — baseline blob `null`; the manifest
   expects a **new** file (the un-merged "cancelled draft").

### 1.3 Pinned obligation sources and authority (all read this iteration)

All nine entries of `.llm_tmp/context/obligations/source-index.json` were read together with
`authority.json`. Every entry is pinned `"native_acceptance": "not_inferred"` — pinned, but its
applicability to this slice is **not inferred**.

| id | file | status note |
|----|------|-------------|
| `coding_guidelines` | `coding_guidelines.rst` | `:status: valid`; **MISRA C++:2023 with C++17**; `score::Result` error model, avoid exceptions/aborts |
| `code_analysis` | `code_analysis.rst` | `:status: valid`; clang-tidy + GCC/Clang warnings + Coverity; ASan/LSan/TSan/UBSan/Memcheck; gcov/gcovr. *"If for any technical reason any MISRA finding can not be addressed it needs to be justified appropriately … explained why it does not have any impact on the safety of the code and finally documented within the source code"* (`:51`) |
| `misra_mapping` | `misra_mapping.rst` | **`:status: draft`** — the `csv-table` is commented out (`:26-31`), `_assets/misra_2023.csv` absent; **no rule applicability asserted** |
| `verification_plan` | `verification_plan.rst` | `:status: valid`; TestType/DerivationTechnique tables; **quality criteria 1–9** (`:292-335`) |
| `development_plan` | `development_plan.rst` | `:status: valid`; C++17, GCC host compiler, QCC target, Bazel |
| `tool_management` | `tool_management.rst` | `:status: valid`; tools identified → evaluated → qualified (if TCL LOW) → **released/rejected by an authorized human** |
| `verification_process` | `verification_process.rst` | `:status: valid`; `gd_req__verification_link_tests(_cpp)`, `_independence`, `_checks(_extended)`, `_external_aou`, `_sca_classification`, `_ci_reference_execution` |
| `verification_guideline` | `verification_guideline.rst` | `:status: valid`; traceability, independence, documented results, release pass-rate rules |
| `inspection_checklist` | `inspection_checklist.rst` | **`:status: draft`** — blank `IMPL_01_01`…`IMPL_03_02` template; names the inspection roles (content responsible / reviewer / moderator) |

**Authority record** (`.llm_tmp/context/obligations/authority.json`):

| Field | Value |
|-------|-------|
| `engineering_acceptance` | **pending** |
| `human_reviews` | **unanswered** |
| `safety_class` | **unknown** |
| `codeql_scope` | Public Apache-2.0 `eclipse-score/inc_someip_gateway`; **no upload** |
| `instruction` | "Restart the failed queue for one complete pass through all obligations" |

### 1.4 Quality criteria that govern any release decision (excerpt, `verification_plan.rst:292-335`)

| # | Criterion | Goal QM | Goal Safety |
|---|-----------|---------|-------------|
| 1 | Structural statement (line) coverage | 85 % | 100 % |
| 2 | Structural branch coverage | 85 % | 100 % |
| 3 | Coverage of software detailed design | n/a | 100 % |
| 4 | Coverage of software architecture design | 100 % | 100 % |
| 5 | Verification coverage of requirements | 100 % | 100 % |
| 6 | Relative amount of executed tests | 100 % | 100 % |
| 7 | Relative amount of passed tests | 100 % | 100 % |
| 8 | Freedom from static-analysis violations (critical/high) | 100 % | 100 % |
| 9 | Freedom from compiler warnings & errors | 100 % | 100 % |

---

## 2. Reviewed artifact set and hashes

The **tool-measured working-tree `sha256`** values below are quoted from the retained
`.llm_tmp/overnight/obligations/*/result.json` (`source_hashes`); the context-snapshot value is shown
for drift awareness only. The context snapshot and the measured tree **disagree**, so the snapshot's
prose cannot be assumed to describe the current file.

| Path | Tool-measured sha256 | Context-snapshot sha256 | Role |
|------|----------------------|-------------------------|------|
| `score/socom/impl/service_identifier.hpp` | `bdce3fcbc3cd78a8ecaece1ea36107d464011ab81c9bc39932d0be617befaea9` | `96b33a1fee4d54577ae9bc46c313409a0d59336f76df85ef1925ffebdd1a2119` | key type (in scope) |
| `score/socom/impl/service_identifier.cpp` | `3c12b3f1dd3f1fa66cdf43766f374d7d067637bf8f11aba604c4e2688351f11a` | `d766902e4bda5306095a6e5326ea91d28df3a6e1ef4e77dc9ba47556ed559a9a` | key comparator (in scope) |
| `score/socom/test/unit/service_identifier_tests.cpp` | `4df2c63c4c2ea1a816898d8c33c506add3235509d85edfc51c535ab2aa1587a4` | `45d073998108df76c8f4534508d65f02cead28aa568cd5c45b5a3d8a4fd36a25` | 87-case key suite (in scope) |
| `score/socom/test/unit/runtime_tests.cpp` | `9a2d6a154683a2b7ff9d51b7241e4fb74c1a8ef483895830cb409a8f5a1d3127` | `5e35e24d0abcfa361b5a5283a005b307b86026a970464a3423be7c6eed66631e` | 33-case runtime suite (in scope) |
| `score/socom/BUILD` | `68f4645a21e495fac43929fb125f7ba0b9e29fc84c0401fdb95238ffb7fd2cc8` | `dee826163ac5e6336d51a293136b424696c2884aa1b2592395e1e06423c0ba44` | build wiring (in scope) |
| `score/socom/test/unit/BUILD` | `e909151e822370bebe8d59b86369bddeb4d6cacfa02f10061bf6e134671ff9d4` | `9b3c5b341211e2c387858fd1fe5c669a6a422b6e8b5e80fce35ba22c61186799` | build wiring (in scope) |

The retained inventory for the two test files (`process_checks/result.json:244-263`) is:
`runtime_tests.cpp` = **33 test macros** (`1 TEST + 31 TEST_F + 1 TEST_P`), record properties
`DerivationTechnique`, `Description`; `service_identifier_tests.cpp` = **87 test macros**, same two
record properties.

---

## 3. The recorded syntax failure — inspection of the actual source

### 3.1 Finding (re-verified this iteration by direct `read_file` + `grep`)

`score/socom/impl/service_identifier.hpp` is **brace-balanced**. `grep '[{}]'` returns exactly four
brace-bearing lines:

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`) and two closers (`:32`, `:38`): net brace balance `0`. There is **no
third, unmatched closing brace**, and line 39 contains no text. `glob **/service_identifier.hpp`
returns exactly one path, so no second, differently-braced copy exists in this checkout. The sibling
`impl/service_identifier.cpp` uses the same nested form and is balanced (`:18`, `:20`, `:30`, `:32`).

### 3.2 Disposition

The described defect is a **stale, pre-correction description** that matches the earliest prior
reports (which quote the split form `}  // namespace socom` + `}  // namespace score`). The
`reproducer` iteration corrected it and left line 39 blank. **No correction was applied, and none is
required.** The retained focused GCC compiles corroborate a compiling unit (§5), but that is a
scoped/focused reading, **not** a full native criterion-9 measurement.

### 3.3 Minimal historical repair (reference only; NOT applied)

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

Applying this to the already-balanced file would be a no-op; deleting a brace would *create* the
reported defect. **Human action requested:** confirm §3.1; if the "cancelled draft" is a *different*
revision that still carries the extra brace, it is not the file in this checkout and must be located
and corrected by an authorized iteration.

---

## 4. Current as-is state of the bounded slice

All line references are readings of the working tree at the baseline-bound candidate paths.

- **Key type.** `Service_instance_identifier` =
  `{ Service_interface_identifier interface; Service_instance instance; }`
  (`score/socom/impl/service_identifier.hpp:29-32`), with an out-of-line `operator<` declaration
  (`:35`, hidden with `\cond`) and **no** `operator==`/`std::hash`.
- **Key role.** Duplicate-server registration key only:
  `using Service_identifiers = Mutexed_variable<std::set<Service_instance_identifier>>`
  (`impl/runtime_impl.hpp:56`), held as `Runtime_impl::m_service_identifiers`.
- **Current identity (`minor` excluded).** `impl/service_identifier.cpp:28-29` orders by
  `std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major) <
  std::tie(rhs.instance, rhs.interface.id, rhs.interface.version.major)`, so identity is exactly
  `(instance, service id, major)`. `std::set` uniqueness is `!(a<b) && !(b<a)`.
- **Baseline identity (pre-draft).** Per `prior-reports/invariants.md` I-4, the baseline ordering
  included `minor` (`(instance, id, major, minor)`). The baseline blob is not in this working tree;
  that item is a prior-report reading, not a direct re-read.
- **Insertion / duplicate rejection.** `Runtime_impl::make_server_connector` builds the identifier
  (`runtime_impl.cpp:443`), inserts under the key mutex (`:449-454`), and returns
  `Construction_error::duplicate_service` when `insert(...).second` is false (`:452`).
- **Record index (minor-ignoring).** `Service_database` indexes by `id + major` via
  `Minor_version_ignoring_key_equal` / `Minor_version_ignoring_hash`
  (`runtime_impl.hpp:116-134`), consumed by `get_record` (`runtime_impl.cpp:313-324`).
- **Single-server precondition.** `Service_record::register_server_connector` asserts
  `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)` then `m_server.emplace(...)`
  (`runtime_impl.cpp:369`, `:371`). The assert's terminate-vs-compiled-out semantics live in the
  external `score_baselibs`/`futurecpp` and are **undetermined in this checkout**.
- **Compatibility rules (separate from identity).** `is_minor_version_compatible` =
  `client.minor <= server.minor`; `is_interface_compatible` requires equal `id`, equal `major`, then
  the minor rule (`runtime_impl.cpp:133-146`). These are **not** part of the key.
- **Public interface unchanged.** `Service_interface_identifier{Id id; Version{major, minor}}`, both
  `std::uint16_t` (`service_interface_identifier.hpp:73-124`), still minor-aware `==`/`<`/`hash`.
- **Tests.** `service_identifier_tests.cpp`: 87 `TEST_F` under `ServiceInstanceIdentifierTest`;
  `runtime_tests.cpp`: 33 macros including the minor-only duplicate regression
  `ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError` (`:402-431`). See
  §5.4 and §8.5 for the execution state.

### 4.1 The static invariant gap (I-11)

On the baseline, the key included `minor` while the record index ignores it. Two server connectors
for the same `id + major + instance` with different minor versions then produced distinct keys (both
passing the duplicate gate) but resolved to the same `Service_record` on enable, reaching
`ASSERT(!m_server)` (undefined behaviour where the assert does not terminate). The working-tree key
change closes this gap *at the key level*. This is a **source-derived reading, not a reproduced
runtime result**. **Human decision requested:** confirm this is the intended regression target (§7).

---

## 5. Retained measurement and obligation evidence (retention ≠ passing)

### 5.1 Host validation under `.llm_tmp/overnight/validation/`

| Artifact | Content | Limit |
|----------|---------|-------|
| `check-result` | `0` | collector success marker only |
| `measurement.json` | `origin: local_unprotected_measurement`; `initiator: Fabro host hook`; `engineering_acceptance: pending`; `full_native_tests: not_executed`; compiler `g++-12` (`88315fd2…`); `baseline_with_agent_tests` = 85 tests / 28 failures / compile 0; `candidate` = 85 tests / 0 failures / compile 0; `changed_paths` = `service_identifier_tests.cpp` only | focused identifier TU, **stale by two cases** (85 executed vs 87 on disk); never compiles `runtime_tests.cpp` or any Bazel target |
| `before.json` / `after.json` | 85/28 red baseline (minor-aware key) / 85/0 green candidate | same scope/staleness |
| `*-compile.command.json`, `*-compile.stderr` | focused `g++-12 -std=c++17 -Wall -Wextra -Werror`; `after-compile.stderr` empty; compile exit 0 | focused TU only |

### 5.2 Obligation-collection results under `.llm_tmp/overnight/obligations/` (25 checks)

`grep`/`glob` confirm 25 `result.json` files. Representative statuses (read from the artifacts and
prior reports):

| Check | Retained status | Reading |
|-------|-----------------|---------|
| `compiler_diagnostics` | `findings_or_execution_failure`; GCC compile+tests exit 0 (87/0); **Clang exit 1** on `-Wdeprecated-declarations` in libstdc++-12/vendored gtest | focused; Clang branch of criterion 9 blocked by a dependency |
| `focused_coverage` | `completed`; line **36/36 = 100 %**, branch **11/14 = 78.6 %**; `complete_target_scope: false`; `safety_class: unknown_requires_authorized_selection` | **branch below both platform goals** (QM 85 / safety 100) |
| `focused_asan_lsan` | `completed`; ASan/LSan/UBSan exit 0 | focused single-threaded identifier scope only |
| `focused_tsan` | `findings_or_execution_failure`; tests exit `-11` (SIGSEGV) | environment failure, **not** a clean race result |
| `focused_memcheck` | `findings_or_execution_failure`; exit 127 | `valgrind` unavailable |
| `focused_cppcheck` | `findings_or_execution_failure`; exit 2; 19 × `passedByValue` | all locations in headers **outside** the candidate paths |
| `focused_clang_tidy` | `findings_or_execution_failure`; `--verify-config` exit 1; 15 unknown-check warnings | **no analysis ran → "not run", never "clean"** |
| `codeql_security` | `findings_or_execution_failure`; 32 findings, **all** under `.llm_tmp/googletest/**`; `level: null` | focused linked executable; dependency-only |
| `codeql_misra` | `findings_or_execution_failure`; large set dominated by googletest + gtest `TEST_F` macro expansion + out-of-slice `string_registry.*`; `level: null`; mapping `:status: draft` | **no MISRA compliance claim possible** |
| `native_build`, `native_tests`, `native_coverage`, `native_lint`, `native_sanitizers`, `native_tsan`, `native_integration`, `native_docs`, `native_performance`, `native_traceability`, `cross_compilation`, `format_precommit` | `findings_or_execution_failure`; **exit 127** (`[Errno 2] … '/tmp/s-core-001/bin/bazel'`; some tool-absent) | **no native build/test/coverage/QEMU/cross/trace run** |
| `secret_dependency_checks` | `findings_or_execution_failure`; gitleaks exit 127; 29-dep inventory + `lock_sha256 c90b245b…`; blocker *"dependency inventory is not a vulnerability scan"* | secret scan **not run**; no CVE mapping |
| `tool_assurance` | retained; probes record `bazel`, `valgrind`, `gitleaks`, `clang-format`, `pre-commit`, `reuse` unavailable; blocker *"Tool confidence evaluation, qualification where applicable, and acceptance require authorized humans"* | tool execution ≠ qualification |
| `process_checks` | `completed_with_blockers`; blockers: *"Lexical metadata inventory cannot prove semantic requirement coverage"*, *"Safety/QM applicability and approved tailoring unknown"*, *"Independent inspection and acceptance required"*, *"External AoU and full integration verification require scoped review"* | directly names this handoff |
| `rework_progress` | `completed`; `source_changed_this_round: true`; `rework_requested: false`; stop reason *"One complete pass requested; unresolved findings stay pending"* | one pass; nothing resolved |

### 5.3 Independent retention statement

Because the collector results are **retained**, not automatically passing, and because several
checks failed to run, this handoff does **not** treat any check in §5.2 as passed. In particular, the
absence of `.llm_tmp/overnight/obligations/native_*` results is **not** evidence that native checks
passed; the retained rows show explicit non-runs and failures.

### 5.4 Execution state of the candidate test suites (read, not run here)

- `service_identifier_tests.cpp` (87 macros) was executed green **only in focused host/collector
  runs** (GCC 87/0, ASan/LSan/UBSan exit 0); it has **never** been compiled or run as a Bazel target.
- `runtime_tests.cpp` (33 macros) has **never** been compiled or executed by any retained artifact.
- The retained host measurement executed the earlier 85-case state, so even the identifier evidence
  is stale relative to the current 87-macro file.

---

## 6. Explicit non-satisfaction of obligations

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Freedom from compiler warnings & errors (criterion 9, 100 %) | `verification_plan.rst:332-335` | **PARTIAL / NOT SATISFIED** — focused GCC clean; Clang blocked by a dependency; no native warnings-as-errors build |
| Static code analysis executed, findings classified | `code_analysis.rst`; `verification_process.rst` (`gd_req__verification_sca_classification`) | **NOT DONE** — clang-tidy did not run; CodeQL focused/dependency-only; **no QM+committer classification** |
| Freedom from SCA critical/high (criterion 8) | `verification_plan.rst:328-331` | **NOT MEASURED** — no authorized classification |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` (`:status: draft`) | **UNKNOWN — NOT CLAIMED**; no rule applicability asserted |
| Structural statement coverage (criterion 1) | `verification_plan.rst:300-303` | focused TU 36/36 = 100 %; **not** full-target |
| Structural branch coverage (criterion 2) | `verification_plan.rst:304-307` | **NOT MET** (78.6 % < 85 % QM, < 100 % safety); no deviation accepted |
| Unit/component tests executed & recorded (criteria 6–7) | `verification_plan.rst:320-327`; `verification_guideline.rst` | **PARTIAL / STALE** — focused 87/0; `runtime_tests.cpp` never executed |
| Interface / requirements-based / resource / fault-injection test types | `verification_process.rst`; `verification_plan.rst:167-240` | **NOT PERFORMED / applicability not inferred**; no fuzz/fault-injection harness exists |
| Fuzzy testing technique | `verification_plan.rst:265-270` | **NOT EXECUTED / NOT CLAIMED** |
| Linking tests to requirements (record properties) | `verification_process.rst` (`gd_req__verification_link_tests_cpp`) | **PARTIAL** — `DerivationTechnique`/`Description` set; `TestType` and `Verifies`/`PartiallyVerifies`/`FullyVerifies` unset (no honest target) |
| External-component AoUs verified | `verification_process.rst:214-226` | **NOT SATISFIED** — no integration/static-analysis verdict; no AoU register |
| CI reference-integration execution | `verification_process.rst:250-264` | **NOT SATISFIED / open TODO** |
| Implementation inspection checklist IMPL_01…IMPL_03 | `inspection_checklist.rst` (`:status: draft`) | **NOT FILLED** |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** — missing tools, collector-vs-pin drift, no Tool Verification Report |
| Independence of verification / review | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Deviation / risk acceptance | `authority.json` | **NONE** — every draft pending |
| Native acceptance | `.llm_tmp/context/obligations/source-index.json` | **`not_inferred` for every entry** |

**Explicit non-satisfaction statement.** Missing tools (`bazel`, `valgrind`, `gitleaks`,
`clang-format`, `pre-commit`, `reuse`), the non-running clang-tidy, the focused/incomplete CodeQL
extraction, the draft/inactive MISRA mapping, the unmet branch goal, the unexecuted runtime suite,
the stale host measurement, the absent secret/vulnerability scans, the unknown safety class, the
un-inferred applicability, and the unanswered human reviews mean **none of the checked obligations
may be treated as satisfied**.

---

## 7. Open semantic/design questions the reviewer must settle

These come from the retained reports and directly affect whether the change can be accepted.

1. **Minor in the duplicate key, or not?** The draft excludes `minor`, so two servers sharing
   `id + major + instance` collide as `duplicate_service`. If the key must keep `minor`, the
   `Service_database` index must stop ignoring minor (or the register path must tolerate
   replacement) to remove the assert/UB path. Which is authoritative?
2. **Two servers, one `id + major + instance`, different minor.** Reject as duplicate, let the later
   replace the earlier, or allow both with negotiation? `m_server` is a single `std::optional`, so
   the last is inexpressible today.
3. **Status of `ASSERT(!m_server)`.** Genuine invariant (the duplicate gate must cover every
   collision the record index can produce) or defensive check that should tolerate re-registration?
4. **Scope of the #84 restructure.** Introduce `Service_identifier = id + major` plus
   minor-as-instance-property (public API change), or keep `Service_interface_identifier{major,
   minor}` and only fix the internal key? This draft assumes the latter.
5. **Version widths and wildcard.** socom uses `uint16` major/minor; the SOME/IP config declares
   `service_version_major: uint8` and `service_version_minor: uint32 = 0xFFFFFFFF`, narrowed by
   unchecked `static_cast<uint16_t>` at several sites. Under the coarsened key, a wildcard-derived
   `0xFFFF` server and a concrete-minor server now collide. How is the wildcard mapped?
6. **Ordering vs identity.** `operator<` is used only for `std::set` membership; no `operator==`/hash.
   Is a total order meaningful, or should the internal key be an equality/hash key?
7. **Error semantics.** Should a minor-only collision report `duplicate_service`, or a more specific
   error? The `error.hpp:55` comment ("Service identifier already exists") is narrower than the key.
8. **Documentation/contract.** `Runtime::make_server_connector`'s doc (`runtime.hpp:176-178`) says
   duplicates are judged by *"the configuration.interface and instance parameters"*, but the public
   `operator==` includes `minor` while the key does not. Authorize a documentation correction?
9. **Design-doc traceability.** No design element in `score/socom/docs/design/` records the key,
   its minor-excluding identity, or duplicate rejection; the behaviour is documented only in code
   comments. Is intentionally-undocumented acceptable?
10. **Runtime regression acceptance.** Confirm the minor-only duplicate regression and the
    service-id slot-isolation cases are wanted, and that the public
    `Runtime::make_server_connector()` path is acceptable — noting none has been compiled or run
    natively in this checkout.

Derived-form equivalents carried from `prior-reports/invariants.md` §5 (Q-A … Q-E) remain open.

---

## 8. The unanswered independent-review gates (the handoff)

> **Rule for every gate below: no AI-authored report, no green focused/collector run, and no green
> native run counts as approval.** Only a named human in the stated role, on the record, closes a
> gate. Every "Decision" field is **blank / UNANSWERED** in this draft.

### 8.1 Author / approver separation — `rl__committer` ≠ author

- **Binding requirement.** `gd_req__verification_independence`
  (`verification_process.rst:141-152`): *"The approver of a pull request shall differ from the
  author(s) of the pull request in all pull requests."* `verification_plan.rst:505-528` adds: unit
  tests may be developed by the same `rl__contributor` who wrote the unit code, but a level of
  independence is achieved **because the review process demands a review by a `rl__committer`
  different from the PR author**.
- **Current state.** `authority.json` records `human_reviews: unanswered`. No author, reviewer, or
  approver is named anywhere in the retained corpus. All evidence in this checkout was produced by
  the Fabro host hook / this run's agents.
- **Gate.** The reviewer/approver must be a different named person from the author of this slice.

| Field | Value |
|-------|-------|
| Author (content responsible) | **UNFILLED** |
| Reviewer (must differ) | **UNFILLED** |
| Approver (`rl__committer`, must differ) | **UNFILLED** |
| Independence evidence | **UNANSWERED** |

### 8.2 Role assignments — safety / security / quality

- **Role identifiers in the pinned sources:** `rl__contributor`, `rl__committer`,
  `rl__testing_community`, `rl__project_lead`, `rl__safety_manager`, `rl__security_manager`,
  `rl__quality_manager` (`development_plan.rst:84-85`, `verification_plan.rst:492-532`,
  `verification_process.rst:246`, `verification_guideline.rst:133,140`).
- **SCA classification.** `gd_req__verification_sca_classification`
  (`verification_process.rst:228-248`) requires findings be rated Critical/High/Medium/Low, either by
  a tool suggestion or **manually by `rl__quality_manager` together with `rl__committer`**. The
  retained tools carried **no** such rating (`level: null`), and no classification exists.
- **Inspection roles.** `inspection_checklist.rst:47-51` names *content responsible (author)*,
  *reviewer* (must differ), and *moderator* (a committer who is the safety/security/quality manager
  initiating the inspection). The checklist is `:status: draft` and blank.
- **Safety class.** `authority.json` records `safety_class: unknown`; `verification_plan.rst` sets
  different QM vs. safety goals (e.g. branch 85 % vs. 100 %), so **no goal level is selectable until
  the class is chosen**.

| Gate | Required role | Decision | Status |
|------|---------------|----------|--------|
| Safety classification / ASIL-QM selection | safety manager + project lead | **(blank)** | **UNANSWERED** |
| Security assessment acceptance | security manager | **(blank)** | **UNANSWERED** |
| SCA finding classification (Critical/High/Medium/Low) | quality manager + committer | **(blank)** | **UNANSWERED** |
| Implementation inspection IMPL_01_01…IMPL_03_02 | content responsible + reviewer + moderator | **(blank)** | **UNFILLED** |
| Risk acceptance (safety-critical pass rate < 100 %) | project lead | **(blank)** | **UNANSWERED** |

### 8.3 Tool qualification acceptance — `tool_management.rst`

- **Process.** Tools are identified (name/UID + version + configuration, independent of location) →
  evaluated (tool impact, tool error detection, TCL) → qualified if TCL is LOW (requirements,
  malfunction/threat analysis, measures, tests, report) → **released or rejected by an authorized
  human**. The work product is a Tool Verification Report; the process is `identified → evaluated →
  qualified → released/rejected`.
- **Current state.** No Tool Verification Report, impact rating, error-detection rating, confidence
  level, or qualification argument exists for any tool. Six required tools are absent
  (`bazel`, `valgrind`, `gitleaks`, `clang-format`, `pre-commit`, `reuse`); `Coverity` named in
  `code_analysis.rst` is not installed/adopted; and there is **collector-vs-pin version drift** (e.g.
  clang-tidy 19.1.7 used to judge a repo pinned to LLVM 22.1.7; GCC 12.3.0 vs. pinned 12.2.0).
- **Rule.** **Tool execution does not qualify a tool.** A tool that "ran" or "did not run" cannot be
  marked qualified without the owner's evaluation and, where TCL is LOW, qualification.

| Gate | Required role | Decision | Status |
|------|---------------|----------|--------|
| Admit collector-tool evidence vs. pinned toolchain (version drift) | safety/quality + tool owner | **(blank)** | **UNANSWERED** |
| Tool impact / error-detection / TCL for T1–T11 + collector harness | authorized evaluator | **(blank)** | **UNANSWERED** |
| Qualification where TCL LOW | authorized engineer + reviewer | **(blank)** | **UNANSWERED** |
| Tool Verification Report `released` / `rejected` | authorized human | **(blank)** | **PENDING** |
| Reconcile Coverity discrepancy (`code_analysis.rst` names it; not adopted) | quality manager | **(blank)** | **UNANSWERED** |

### 8.4 Deviation and false-positive acceptance — no self-acceptance

`code_analysis.rst:51` requires any unaddressable MISRA finding to be justified — explained as having
no safety impact — and **documented within the source code**. The draft register below is bound to
exact rule/finding/hash and carries alternatives, risk, compensating checks, and review/expiry
triggers. **None is accepted; none may be self-accepted; this draft accepts none.**

| Id | Type (proposed) | Rule / tool | Scope | Status |
|----|-----------------|-------------|-------|--------|
| DD-1 | False positive (gtest macro) / deviation alternative | MISRA 6.5.1 `external-linkage-not-declared-in-header-file-misra` | candidate test file (`4df2c63c…`) | **DRAFT / NOT ACCEPTED** |
| DD-2 | False positive (gtest macro) | MISRA 9.3.1 `switch-body-compound-condition` | candidate test file | **DRAFT / NOT ACCEPTED** |
| DD-3a | False positive (gtest macro) | MISRA 7.0.1 `no-conversion-from-bool` | candidate test file | **DRAFT / NOT ACCEPTED** |
| DD-3b | Deviation requested (out of slice) | MISRA 7.0.1 | `string_registry.cpp` (`f486e72a…`) | **DRAFT / NOT ACCEPTED** |
| DD-4 | Deviation requested (out of slice) | MISRA 21.6.1 `dynamic-memory-should-not-be-used` | `string_registry.hpp` (`909ca6a4…`) | **DRAFT / NOT ACCEPTED** |
| DD-5 | Deviation requested (out of slice) | MISRA 6.7.1 `local-variable-static-storage-duration` | `string_registry.cpp` | **DRAFT / NOT ACCEPTED** |
| DD-6 | False positive (RAII) / deviation | MISRA 0.1.1 `unnecessary-write-to-local-object` | `string_registry.cpp` | **DRAFT / NOT ACCEPTED** |
| DD-7 | Deviation requested (performance style) | cppcheck `passedByValue` ×19 | `registry_string_view.hpp`, `service_interface_identifier.hpp` (out of slice) | **DRAFT / NOT ACCEPTED** |
| DD-8 | False positive (dependency/toolchain) | Clang `-Wdeprecated-declarations` under `-Werror` | libstdc++-12 / vendored gtest | **DRAFT / NOT ACCEPTED** |
| DD-9 | False positive (dependency) | CodeQL security ×32 | `.llm_tmp/googletest/**` | **DRAFT / NOT ACCEPTED** |
| FP-1 | Not reproducible / stale defect | "extra `}` at `service_identifier.hpp:39`" | header `bdce3fcb…` | **DRAFT / NOT ACCEPTED** |

| Gate | Required role | Decision | Status |
|------|---------------|----------|--------|
| DD-1 / DD-2 / DD-3a / DD-6: false positive vs. formal deviation | quality manager + committer | **(blank)** | **UNANSWERED** |
| DD-3b / DD-4 / DD-5 / DD-7: deviation vs. in-source justification vs. refactor | safety/quality + committer | **(blank)** | **UNANSWERED** |
| DD-8 / DD-9: dependency/toolchain disposition | security/quality + committer | **(blank)** | **UNANSWERED** |
| FP-1: confirm stale, or locate a distinct broken revision | content responsible | **(blank)** | **UNANSWERED** |
| Review/expiry triggers enforced; re-open on bound-hash change | process owner | **(blank)** | **PENDING** |

### 8.5 Test independence and traceability

- **Binding requirements.** `gd_req__verification_link_tests(_cpp)`: use gtest `RecordProperty`, with
  common attributes allowed in `SetUp()`. `gd_req__verification_checks`
  (`verification_process.rst:178-196`): `TestType` and `DerivationTechnique` **shall be set**;
  `Description` non-empty; a Unit Test's `Partially/FullyVerifies` must link to at least one
  Component Requirement. `gd_req__verification_checks_extended` (`:198-212`): a `requirements-based`
  `TestType` needs a requirement link; an `interface-test` needs an interface link.
- **Current state.** Both candidate test files record only `DerivationTechnique` and `Description`
  (`process_checks/result.json:244-263`). `TestType` is unset, and no
  `PartiallyVerifies`/`FullyVerifies` link exists. No `comp_req__socom__*` exists; `docs/**` has
  **no `:reqtype: Interface`** need; component/feature requirement indices are placeholder
  toctrees; no `aou_req__*` is defined. Inventing identifiers is prohibited.
- **Coverage-driven tests.** The two newest key cases (`:1982`, `:2012`) are documented as
  coverage-driven, not requirement-derived; the key suite's single fixture-wide `Description` is
  shared by 87 cases. This is a traceability-quality observation.

| Gate | Required role | Decision | Status |
|------|---------------|----------|--------|
| Supply `comp_req__socom__*` / interface need, or record approved tailoring | requirements owner + committer | **(blank)** | **UNANSWERED** |
| Decide `TestType` (and per-case `Description` policy) | reviewer + committer | **(blank)** | **UNANSWERED** |
| Confirm runtime/minor-only regressions and public-path acceptability | reviewer + testing community | **(blank)** | **UNANSWERED** |
| Test authorship independence for this slice | `rl__testing_community` | **(blank)** | **UNANSWERED** |

### 8.6 Integration and release decisions

- **Integration levels** (`verification_plan.rst:121-150`): Level 1 unit/component (S-CORE),
  Level 2 feature integration (S-CORE), Level 3 platform integration on reference hardware (S-CORE
  reference tests as an *optional base*; **"The full Platform Integration Testing will be executed by
  the integrator"**). Target-device integration and validation are the **distributor's**
  obligation (`verification_plan.rst:604-608`); AoU-linked requirements "will not be executed on the
  final product environment as part of the project scope" (`verification_guideline.rst:197-203`).
  **The reference hardware is not yet decided** (`verification_plan.rst:610`).
- **Current state.** The QEMU/native integration leg (`bazel test --config=qemu-integration …`)
  exited 127 (bazel missing) even though KVM/QEMU prerequisites are present. Cross-compilation
  (`x86_64-linux`, `aarch64-linux`, QNX) exited 127 with a QNX-entitlement blocker. No daemon was
  built or run. No requirement or interface link exists, so the traceability gate would show this
  slice as unlinked even if it ran.
- **Release/pass-rate rules** (`verification_guideline.rst:127-153`): any failing test requires an
  ISSUE; the safety-critical pass rate must be **100 %**; for QM, if the rate is < 100 % the
  `rl__project_lead` decides releasability, and < 95 % is recommended as not acceptable; skipped or
  non-executed test cases must be documented in the release notes and do **not** count toward
  requirement coverage. The CI traceability gate is `continue-on-error: true` with thresholds
  defaulting to 0 — **a nonblocking gate is not acceptance**.

| Gate | Required role | Decision | Status |
|------|---------------|----------|--------|
| Accept S-CORE vs. integrator split and "reference hardware not yet decided" | project lead + integrator liaison | **(blank)** | **UNANSWERED** |
| Restore tools and run native/QEMU/cross/trace legs | engineering owner | **(blank)** | **UNFILLED** |
| Record skipped/not-executed tests and rationale for release | project lead + quality manager | **(blank)** | **UNANSWERED** |
| Release decision (with criterion 2 branch shortfall and unexecuted runtime suite) | project lead + quality manager | **(blank)** | **NOT TAKEN** |
| Verify external-component AoUs (incl. `SCORE_LANGUAGE_FUTURECPP_ASSERT` semantics, FlatBuffers wildcard) | safety/security + owner | **(blank)** | **UNANSWERED** |
| Keep the wider #84 public restructure / FindService wildcard / config wildcard out of scope until separately accepted | committer | **(blank)** | **UNANSWERED** |

### 8.7 Cross-cutting gate: instruction conflict

| Gate | Required role | Decision | Status |
|------|---------------|----------|--------|
| Resolve "inspect and correct the actual source" vs. "only that report may be written"; confirm inspection-only (source already correct) was intended | process owner | **(blank)** | **UNANSWERED** |

---

## 9. What this handoff explicitly does NOT claim

- **No engineering acceptance, review approval, publication, or upload.** `codeql_scope` forbids
  upload; nothing was uploaded.
- **No MISRA C++:2023 compliance and no assertion that any numbered rule "applies"** — the mapping
  is `:status: draft` with the table commented out.
- **No safety-class / ASIL / QM selection, no FMEA/DFA acceptance, no risk acceptance, no
  deviation** — every entry in §8.4 is a draft; none is accepted.
- **No claim that identifier-only or key-level tests are platform, feature, or interface
  validation**, and **no fuzzy-testing claim** (no harness, no measurement).
- **No invented native requirement or interface identifiers.**
- **No claim that clang-tidy, the native Bazel suite, TSan, memcheck, QEMU integration,
  cross-compilation, coverage-to-goal, secret scanning, or dependency-vulnerability scanning
  passed** — each is blocked, failed, or did not run.
- **No AI or native successful run counts as human approval.**

---

## 10. Notice preservation

- **Only this report was written.** No source, build, test, config, `NOTICE`, `LICENSE`, or
  `REUSE.toml` file was created, edited, or deleted by this iteration.
- The flagged header `score/socom/impl/service_identifier.hpp` was inspected and left unchanged
  because it is already brace-balanced and otherwise well-formed (§3); it retains its Apache-2.0 /
  SPDX header (`:1-12`). The sibling `service_identifier.cpp`, both `BUILD` files, and both candidate
  test files likewise retain their Apache-2.0 / SPDX headers.
- All 12 files under `.llm_tmp/overnight/prior-reports/`, all earlier files under
  `.llm_tmp/overnight/reports/`, and all host/obligation artifacts under
  `.llm_tmp/overnight/validation/` and `.llm_tmp/overnight/obligations/` were read only and are
  preserved unchanged. This document is a new `reports/` entry.
- This report itself carries the Apache-2.0 header. No licensed MISRA rule text is reproduced; only
  native rule/query identifiers, source hashes, and file locations are cited.

---

## 11. Measurement, validation status, and reproduction path

- **Tools used this iteration:** `read_file`, `grep`, `glob`, `write_file` only. No `shell`,
  delegation, web, approval, publishing, or engineering acceptance.
- **Measurements executed this iteration:** **none.** No build, no test, no scan, no analysis. Every
  number above is a reading of the retained artifacts or of the working tree, or an
  explicitly-labelled logical consequence.
- **Scope of retained runs:** focused identifier translation unit (plus vendored googletest); no
  `runtime_tests.cpp`; no Bazel/native target; `full_native_tests: not_executed`
  (`validation/measurement.json`).
- **Reproduction path for a later, authorized iteration (NOT run here):**

  ```bash
  bazel build //score/...
  bazel test //score/...
  bazel test //score/socom/test/unit:socom_test
  bazel test //score/socom/test/unit:socom_test --test_filter='ServiceInstanceIdentifierTest.*'
  bazel test //score/socom/test/unit:socom_test \
      --test_filter='RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError'
  bazel test --config=qemu-integration //quality/... //tests/integration_test/...
  bazel build --config=x86_64-linux //score/... //tests/...
  bazel build --config=aarch64-linux //score/... //tests/...
  bazel run //:docs
  bazel run //:traceability_gate -- --metrics-json _build/metrics.json --need-type=comp_req
  gitleaks dir . --redact=100 --report-format=json   # requires gitleaks
  # full-target CodeQL extraction (not the focused linked executable)
  codeql database create <db> --language=cpp --command='<full build>'
  codeql database analyze <db> codeql/cpp-queries:codeql-suites/cpp-security-and-quality.qls --format=sarif-latest
  ```

  Expected (source-derived, **not** observed): the minor-only key tests collapse to one set element
  and the runtime regression returns `Construction_error::duplicate_service`; on a key that includes
  `minor`, both focused checks would fail.

---

## 12. Handoff summary / sign-off sheet (all fields UNSIGNED)

| # | Review gate | Required role(s) | State |
|---|-------------|------------------|-------|
| 1 | Author/approver separation | author, reviewer, `rl__committer` (approver ≠ author) | **UNANSWERED** |
| 2 | Safety classification | safety manager + project lead | **UNANSWERED** |
| 3 | Security acceptance | security manager | **UNANSWERED** |
| 4 | SCA classification (Critical/High/Medium/Low) | quality manager + committer | **UNANSWERED** |
| 5 | Tool impact / error-detection / TCL + qualification | authorized evaluator | **UNANSWERED** |
| 6 | Tool Verification Report released/rejected | authorized human | **PENDING** |
| 7 | Deviations DD-1…DD-9, FP-1 | safety/quality/security + committer | **DRAFT / NOT ACCEPTED** |
| 8 | Requirement/interface links and `TestType` | requirements owner + reviewer + committer | **UNANSWERED** |
| 9 | Integration/release decision (criteria 1–9) | project lead + quality manager | **NOT TAKEN** |
| 10 | Instruction conflict (correct-source vs. report-only) | process owner | **UNANSWERED** |

**Bottom line.** The bounded registration-key change and its tests exist locally and are internally
consistent; the recorded brace defect is **not present in the current source**; and **no obligation
is satisfied and no human review has occurred**. This document exists so that the named humans in the
roles above can answer the gates on the record. **A green AI/native run must never be substituted for
those answers.**

---

*End of independent-review handoff. Local, unprotected, scoped. No engineering acceptance; human
reviews unanswered; full native runtime tests pending; no MISRA compliance, safety classification,
tool qualification, deviation, or risk acceptance is claimed, and this handoff does not act as the
independent reviewer.*
