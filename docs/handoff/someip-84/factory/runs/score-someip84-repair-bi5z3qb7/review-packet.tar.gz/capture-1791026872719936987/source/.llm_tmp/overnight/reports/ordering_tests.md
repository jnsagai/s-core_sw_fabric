<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — property-style ordering/equality cases for the registration key (`ordering_tests`)

**Document type:** review draft (actual-source inspection + brace-defect reconciliation + property-test verification record + retained-host-measurement reconciliation + obligations status).
**Date:** 2026-10-03
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version handling in socom* (issue #84).
**Run / branch:** `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ`; current HEAD `844c0f7` — `fabro(01M3ZRSDK2XQAF1H48VWTPKQNZ): node_c56852d541a0b6bf71cacf06 (success)` (run environment).
**Verified baseline commit:** `f8a196c3b16d5172d898394ab99b0ed81346d63d` (`.llm_tmp/context/source-manifest.json:3`).
**Status:** **local, unprotected, scoped.** No engineering acceptance exists. Human reviews are unanswered. Full native runtime tests remain pending. Every statement below is a direct `read_file`/`grep`/`glob` reading of this checkout, a reading of a retained artifact under `.llm_tmp/overnight/validation/`, or an explicitly-labelled logical consequence. Nothing here is published, reviewed, accepted, or a full native run.

> **Tool / write boundary actually observed.** Only `read_file`, `grep`, `glob` and `write_file` were used. No `shell`, no delegation, no web access, no approval, no publishing, and no engineering acceptance was performed. The task permits changing only the six named candidate source paths and this report. Of those, **this iteration wrote exactly one file — this report** (`/workspace/.llm_tmp/overnight/reports/ordering_tests.md`). No source, build, test, config, `NOTICE`, `LICENSE` or `REUSE.toml` file was created, edited or deleted, and **every prior report was preserved unchanged**.
>
> **Premise reconciliation — the stated brace defect is not present in the actual source, and the requested property cases already exist.** The task states the cancelled draft has "a measured GCC syntax failure: an extra closing brace in `score/socom/impl/service_identifier.hpp` at line 39", directs "inspect and correct the actual source before expanding tests", and asks to "add property-style deterministic cases for strict weak ordering and equality of registration identifiers." Direct inspection of the *actual* working tree (§2) shows the header is **already brace-balanced** (openers `:19`, `:29`; closers `:32`, `:38`; line `:39` blank), and `score/socom/test/unit/service_identifier_tests.cpp` **already carries ten `Property*` cases**, including the exact combined-domain strict-weak-ordering and identifier-equality laws requested (§4). Both requested property cases are listed as executed and passing in the retained host capture (§5). The only write primitive permitted by the task is whole-file `write_file` (no append/targeted edit), so "adding" the already-present laws would require rewriting the host-measured-green 87-case file merely to duplicate coverage — gratuitous churn with non-zero regression risk. This iteration therefore **re-verified and mapped** the existing cases and applied **no source change**; the source correction is already present and the minimal repair is retained for reference only (§2.4).

---

## 0. Summary

1. **Recorded syntax failure — inspected; not present.** `score/socom/impl/service_identifier.hpp` is brace-balanced: two opening braces (`namespace score::socom {` at `:19`, `struct Service_instance_identifier final {` at `:29`) and two closing braces (`};` at `:32`, the single `}  // namespace score::socom` at `:38`); line `:39` is blank and `:40` is `#endif`. Net brace balance `0`; separate `grep`s for `{` and `}` return exactly `:19/:29` and `:32/:38` (§2). No correction was applied because none is required; deleting a brace would *introduce* the reported defect.
2. **The requested property cases already exist and are host-measured green.** Ten deterministic `Property*` cases quantify over three fixed key domains (36-, 64- and combined 100-key), asserting the strict-weak-ordering contract (irreflexivity, asymmetry, strict-order transitivity, equivalence transitivity), the induced equivalence relation, and equality ⇔ the independent `(instance, service id, major)` identity tuple (§4). The retained `after.json` records `ServiceInstanceIdentifierTest` **87 tests / 0 failures**, including both combined-domain cases (§5).
3. **The registration key excludes the minor version.** `operator<` orders by `(instance, service id, major)` (`score/socom/impl/service_identifier.cpp:28-29`), matching the deliberately minor-ignoring `Service_database` index (`score/socom/impl/runtime_impl.hpp:116-134`); the public `Service_interface_identifier`/`Version` representation is unchanged (`score/socom/service_interface_identifier.hpp:74-124`).
4. **Host feedback is present in this checkout** under `.llm_tmp/overnight/validation/`: `check-result` = `0`; `measurement.json` (`check_ref: check_lifetime_tests`, `mode: plain`, `changed_paths: []`, `origin: local_unprotected_measurement`, `initiator: Fabro host hook`, `engineering_acceptance: pending`, `full_native_tests: not_executed`, compiler `/usr/bin/x86_64-linux-gnu-g++-12`) with `baseline_with_agent_tests` 87 tests / 30 failures and `candidate` 87 tests / 0 failures; `before.json` 87/30; `after.json` 87/0; compile/test command captures with exit 0/1 and 0/0 respectively (§5).
5. **The obligation-collection results are absent** — `glob **/result.json` across the workspace returns nothing; there is no `.llm_tmp/overnight/obligations/*/result.json` in this checkout (§6). Retention or absence of a result is **not** a passed check.
6. **No obligation is satisfied.** All nine `source-index.json` entries are `native_acceptance: not_inferred`; `authority.json` records `engineering_acceptance: pending`, `human_reviews: unanswered`, `safety_class: unknown` (§6).

---

## 1. Binding to the baseline, prior reports, host feedback and obligations

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` | `.llm_tmp/context/issue-snapshot.json:2-4` |
| Title | *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:3` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` (unchanged) | `.llm_tmp/context/issue-snapshot.json:19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted obligation**. It distinguishes service-instance identifier = `service id + major + minor + instance id`; service identifier = `service id + major`; FindService = `service id + major + optional<minor> + optional<instance>`; and proposes to "exclude the minor version and make it a property of the service instance to be able to better compare and index compatible service instances." The FindService `major = FF` AUTOSAR case is called theoretically possible but not useful. There is **no comment and no acceptance record**, so none of it is binding.

### 1.2 Verified baseline and current tree

| Item | Value | Source |
|------|-------|--------|
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |
| Current branch | `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ` | run environment |
| Current HEAD | `844c0f7` — `node_c56852d541a0b6bf71cacf06 (success)` | run environment |

Binding is **by baseline commit**, not by run HEAD. Earlier reports reference other run IDs on the same baseline commit (`01M3YRJEGXNY6CB81T7TKW774B`, `01M3YGTGYFEN406VDEVVTJTRWV`, `01M3XZAQ65TTE35XSGXC4JAMAH`, `01M3XT7NQ04S4MTFRMTT2401XK`, `01M3WX09X84XFM5X08QY2944DF`), so all describe the same baseline and remain admissible prior evidence. No local hashing tool was available; the direct source reads in §2–§4 are authoritative for this report.

### 1.3 In-scope candidate files (the only writable source paths)

From `.llm_tmp/context/candidate-files.json:1-25` (baseline blobs cross-checked against the `files` array of `.llm_tmp/context/source-manifest.json`):

| File (repo-relative) | Baseline git blob | Baseline present | This iteration |
|----------------------|-------------------|------------------|----------------|
| `score/socom/BUILD` | `3477ea0851fdcd82ec6ea9d71424013cbdf41962` | yes | inspected, **unchanged** — `testonly` `impl_service_identifier` exposure present (`:46-54`) |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e22355242009fe20dada2a9a0d0c7a9c7` | yes | inspected, **unchanged** — `minor` already excluded (`:28-29`) |
| `score/socom/impl/service_identifier.hpp` | `c8bae7908da9f087c518934f7b9f8d86db9a20ec` | yes | inspected, **unchanged** — already brace-balanced (§2) |
| `score/socom/test/unit/BUILD` | `3c03a7b14286051f97fa5022206564bd63645171` | yes | inspected, **unchanged** — `socom_test` globs `*.cpp`, deps wired (`:16-29`) |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab726db8bf994c960045d6fd7fdf84d7395` | yes | inspected, **unchanged** — minor-only regression `:402-431` |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(none — `null`)* | no (manifest expects a **new** file) | inspected, **unchanged** — 87 `TEST_F` incl. ten `Property*` cases (§4) |

The `null` baseline blob for `service_identifier_tests.cpp` is the manifest's expectation of a **new** unit-test file; it exists on disk only as part of the un-merged working tree (the task's "cancelled draft"), never in the baseline. `glob **/service_identifier.hpp` returns exactly one path, so there is no second, differently-braced copy of the header in this checkout.

### 1.4 Pinned obligation sources and authority (all read this iteration)

All nine entries of `.llm_tmp/context/obligations/source-index.json` were read from `.llm_tmp/context/obligations/`, together with `authority.json`:

| id | repository @ commit | status note |
|----|---------------------|-------------|
| `coding_guidelines` | `score` @ `e2373d82…` | `:status: valid`; MISRA C++:2023 with C++17 |
| `code_analysis` | `score` @ `e2373d82…` | `:status: valid`; clang-tidy + gcc/clang warnings + Coverity; sanitizers; gcov/gcovr |
| `misra_mapping` | `score` @ `e2373d82…` | **`:status: draft`**; the rule table is not a valid obligation |
| `verification_plan` | `score` @ `e2373d82…` | `:status: valid`; TestType/DerivationTechnique tables; quality criteria 1-9 (criterion 9, "Freedom from compiler warnings & errors, 100 %") |
| `development_plan` | `score` @ `e2373d82…` | `:status: valid`; C++17, GCC host compiler, QCC target, Bazel |
| `tool_management` | `score` @ `e2373d82…` | `:status: valid`; tools identified / evaluated / qualified |
| `verification_process` | `process_description` @ `98d1d5f4…` | `:status: valid`; `gd_req__verification_link_tests_cpp`, `_independence`, `_checks_extended`, `_external_aou`, `_sca_classification` |
| `verification_guideline` | `process_description` @ `98d1d5f4…` | `:status: valid`; traceability, independence, documented results |
| `inspection_checklist` | `module_template` @ `c4d4ad09…` | **`:status: draft`**; blank `IMPL_01_01`…`IMPL_03_02` template |

Every `source-index.json` entry is pinned `"native_acceptance": "not_inferred"` — pinned, but its applicability to this slice is **not inferred**. `authority.json` records `engineering_acceptance: pending`, `human_reviews: unanswered`, `safety_class: unknown`, `codeql_scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload"`, and the instruction *"Restart the failed queue for one complete pass through all obligations"*.

### 1.5 Prior reports, host feedback, and obligation-collection results available in *this* checkout

- `.llm_tmp/overnight/prior-reports/` — 38 files present, all preserved; `ordering_tests.md`, `key_fix.md`, `reproducer.md`, `scope.md`, `invariants.md`, `callsites.md`, `unit_matrix.md`, `conversion_tests.md`, `runtime_disabled.md`, `runtime_enabled.md`, `lifetime_tests.md`, `test_metadata.md` and `design_inspection_draft.md` were read; the remainder were cross-checked by name.
- `.llm_tmp/overnight/reports/` (this run) — pre-existing: `scope.md`, `invariants.md`, `callsites.md`, `reproducer.md`, `key_fix.md`, `unit_matrix.md`, `runtime_disabled.md`, `runtime_enabled.md`, `lifetime_tests.md`. All preserved. This document adds `ordering_tests.md`.
- `.llm_tmp/overnight/validation/` — **present** in this checkout: `check-result` = `0`; `measurement.json`, `before.json`, `after.json`, and the four `*-compile.command.json` / `*-test.command.json` captures. Read and reconciled in §5.
- `.llm_tmp/overnight/obligations/*/result.json` — **absent**: `glob **/result.json` over the whole workspace returns nothing (§6).
- Earlier prior reports record that earlier snapshots had no `validation/` directory at all; in the current checkout it is populated. The presence of retained artifacts is **not** acceptance, and the absence of `obligations/*/result.json` is **not** evidence that those checks passed.

Derived sequence across the preserved reports (all on baseline `f8a196c3…`): `scope.md` (bounded the slice; identified the key/index identity gap) → `invariants.md` → `callsites.md` → `reproducer.md` (brace correction + focused red regression) → `key_fix.md` / `unit_matrix.md` (drop `minor`; expand the key tests) → **`ordering_tests.md`** (property tests over the deterministic domains) → runtime/lifetime reports → `conversion_tests.md` → `test_metadata.md` → repair reports → review artifacts. This iteration re-verifies the `ordering_tests` step against the actual, host-measured tree.

### 1.6 Host addendum (task context, not acceptance)

The host addendum (available only as quoted by prior reports) states it "is task context, not engineering acceptance or an approved tailoring decision." It asks the review to cover the `verification_process.rst` test types and derivation techniques; to keep unknown applicability and unexecuted applicable checks explicit; to **not** label identifier-only tests as full platform validation and **not** to claim a fuzzy technique without a measurement; permits concrete boundary/equivalence regression cases within the six source paths; and records that there is no authority to invent native links, select a safety classification, accept risk/deviations, or answer the independent human gate. This report honours that in §4, §6 and §7.

---

## 2. The recorded syntax failure: inspection of the actual source

### 2.1 Finding (direct `read_file` + `grep` this iteration)

`score/socom/impl/service_identifier.hpp` is **brace-balanced**. It is 40 lines; a `grep` for `{` on the file returns exactly two lines and a `grep` for `}` returns exactly two:

| Line | Content | Role |
|------|---------|------|
| 14 | `#ifndef SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard begin |
| 17 | `#include "score/socom/service_interface_identifier.hpp"` | include |
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 21-28 | doc comment | states that `minor` is intentionally not part of the identity |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 30-31 | `Service_interface_identifier interface;` / `Service_instance instance;` | members |
| 32 | `};` | closes the struct |
| 34-36 | `/// \cond` / `bool operator<(…)` / `/// \endcond` | the single operator declaration |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`) and two closers (`:32`, `:38`) give net brace balance `0`. There is **no third, unmatched closing brace**, and line `:39` contains no text at all. The sibling `impl/service_identifier.cpp` uses the same nested form (`:18` / `:32`) and is balanced. The task's "extra closing brace … at line 39" is therefore a **stale, pre-correction description** that matches the earliest prior reports (which quote lines 38-39 as the split form `}  // namespace socom` + `}  // namespace score`); the `reproducer` iteration applied the correction and left line 39 blank, exactly as observed here.

### 2.2 Repository convention (evidence)

The tree uses two internally consistent styles:

- **Nested open + single close:** `namespace score::socom {` … one `}  // namespace score::socom`. This is the sibling `impl/service_identifier.cpp` (`:18` / `:32`), the public `service_interface_identifier.hpp` (`:25` / `:164`) and `impl/service_identifier.hpp` itself.
- **Split open + double close:** `namespace score {` + `namespace socom {` … `}  // namespace socom` + `}  // namespace score`. This is `impl/runtime_impl.hpp`.

`impl/service_identifier.hpp` follows the **nested** form consistently and is balanced.

### 2.3 Independent corroboration from the retained host measurement

The host validation retained in this checkout compiled `score/socom/impl/service_identifier.cpp` — which `#include`s this header — as part of the focused identifier translation unit with `/usr/bin/x86_64-linux-gnu-g++-12 -std=c++17 -Wall -Wextra -Werror -pthread -I.`; `after-compile.command.json` and `before-compile.command.json` both record `exit_code: 0` (§5). A surviving unmatched brace would have failed that compile. This is a local, unprotected, focused capture — corroboration, **not** a full native build.

### 2.4 Correction status

**No correction was applied, and none is required**, because the actual source already uses the corrected nested form. The minimal repair documented for the event the imbalance ever reappears is retained for completeness only:

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

Applying this to the already-balanced file would be a no-op; deleting a brace to "fix" it would *create* the reported defect. If a distinct "cancelled draft" revision elsewhere still carries the extra brace, it is not the file in this checkout and must be located and corrected by an authorized iteration; this report records the discrepancy for human disposition rather than speculating.

### 2.5 Why the brace (and its absence) matters

The header is compiled into `//score/socom:socom` via the `impl/**` source glob (`score/socom/BUILD:24-41`) and re-exposed to `//score/socom/test/unit` through the `testonly` `impl_service_identifier` library (`score/socom/BUILD:46-54`; `score/socom/test/unit/BUILD:24`). A syntax error here would fail both the library and the unit-test target and contradict S-CORE quality criterion 9 ("Freedom from compiler warnings & errors, 100 %", `verification_plan.rst`). The balanced state removes that blocker at the source level; the focused host compile in §2.3 is scoped corroboration, not a full native measurement.

---

## 3. Semantics under test

The duplicate-server registration key is `Service_instance_identifier { Service_interface_identifier interface; Service_instance instance; }` (`score/socom/impl/service_identifier.hpp:29-32`). Its only operator is the out-of-line `operator<` (`:35`), defined as (`score/socom/impl/service_identifier.cpp:28-29`):

```cpp
return std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major) <
       std::tie(rhs.instance, rhs.interface.id, rhs.interface.version.major);
```

Therefore:

- identity (`std::set` equivalence `!(a<b) && !(b<a)`) = **`(instance, service id, major)`**;
- **`minor` is excluded** — it is a compatibility selector enforced separately by the minor-compatibility / `is_interface_compatible` rules, not an identity component;
- the key agrees with the deliberately minor-ignoring `Service_database` record index (`Minor_version_ignoring_key_equal` / `Minor_version_ignoring_hash`, `score/socom/impl/runtime_impl.hpp:116-134`);
- the comparator component order is `instance → service id → major`; both string components compare through `Registry_string_view::operator<`, delegating to `std::string_view` comparison, so the key order equals the lexicographic order of the `(instance.id, interface.id, major)` tuple.

`Service_instance_identifier` declares **no `operator==` and no `std::hash`**; the only identity notion is `std::set` equivalence. "Equality of registration identifiers" in this slice therefore means exactly that mutual-non-ordering equivalence, checked against the independent `(instance, service id, major)` tuple. The test fixture encodes this as `Identity = std::tuple<std::string_view, std::string_view, std::uint16_t>` (`score/socom/test/unit/service_identifier_tests.cpp:84`) with helpers `identity_of` (`:86-90`) and `equivalent` (`:104-107`).

At the registration entry point, `Runtime_impl::make_server_connector` builds `Service_instance_identifier const identifier{configuration.get_interface(), instance}` (`runtime_impl.cpp:443`), inserts it under the key mutex (`:449-453`), and returns `Construction_error::duplicate_service` when `insert(...).second` is false (`:451-452`); a `Final_action` erases the key (`:456-463`).

---

## 4. Property-style deterministic cases for strict weak ordering and equality

### 4.1 The requested property cases already exist

`score/socom/test/unit/service_identifier_tests.cpp` carries **ten** property-style cases, all deterministic (pure functions of compile-time constants; no randomness, no time dependence) and all quantifying over finite key domains rather than asserting isolated examples:

| Line | Test | Property checked |
|------|------|------------------|
| 634 | `PropertyStrictWeakOrderingAxiomsHoldOnDeterministicDomain` | irreflexivity, asymmetry and strict-order transitivity over the 36-key domain |
| 662 | `PropertyEquivalenceMatchesIdentityTupleOnDeterministicDomain` | equivalence is reflexive/symmetric/transitive and coincides exactly with equality of `(instance, service id, major)` |
| 687 | `PropertyOrderingIsDeterministicTotalAndTupleConsistent` | determinism, totality (exactly one of `<`, `>`, equivalent) and agreement of `<` with the identity-tuple order |
| 712 | `PropertyEquivalenceClassesMatchDistinctIdentityTupleCount` | 12 identity classes; `std::set` size equals distinct identity-tuple count |
| 735 | `PropertySetUniquenessIsIndependentOfInsertionOrder` | forward vs. reversed insertion yield identical canonical sets and enumeration order |
| 1055 | `PropertySortedDomainMatchesSortedIdentityTuples` | sorted key domain matches sorted, de-duplicated identity tuples |
| 1087 | `PropertyStrictWeakOrderingAxiomsOnVersionBoundaryDomain` | irreflexivity/asymmetry + strict-order transitivity over the 64-key sign-bit boundary domain |
| 1115 | `PropertyIdentityEqualityClassesOnVersionBoundaryDomain` | equivalence ⇔ identity tuple over the 64-key boundary domain; 16 identity classes |
| 1456 | `PropertyStrictWeakOrderingOnCombinedRegistrationKeyDomain` | over the 100-key combined domain: irreflexivity, asymmetry, strict-order transitivity **and equivalence transitivity** |
| 1488 | `PropertyIdentifierEqualityOnCombinedRegistrationKeyDomain` | over the 100-key combined domain: equality is reflexive/symmetric and coincides exactly with the identity tuple; 20 identity classes |

The two combined-domain cases (`:1456`, `:1488`) are precisely the "strict weak ordering" and "equality of registration identifiers" property cases the task names. Both are listed as executed and passing in the retained host `after.json` (§5.1).

### 4.2 Domains

- `registration_key_domain()` (fixture, `:115-128`): cartesian product `{service_id_a, service_id_b} × {instance_id_a, instance_id_b} × {0, 1, 65535} × {0, 1, 65535}` = **36 keys**.
- `registration_key_boundary_domain()` (fixture, `:139-154`): `{service_id_a, service_id_b} × {instance_id_a, instance_id_b} × {0, 0x7FFF, 0x8000, 0xFFFF} × {0, 0x7FFF, 0x8000, 0xFFFF}` = **64 keys**.
- Combined domain (built inline in `:1456` / `:1488`): concatenation of the two = **100 keys**, with `2 × 2 × {0, 1, 0x7FFF, 0x8000, 0xFFFF}` = **20** identity classes (`:1514`).

All three are pure functions of compile-time constants and are enumerated in a fixed order.

### 4.3 Why these are property-style but still deterministic

They quantify over a finite deterministic domain and assert algebraic laws (the strict-weak-ordering contract and the induced equivalence relation) plus the identity-tuple correspondence, rather than asserting isolated example outcomes. They are deterministic unit tests, **not** randomized or property-based fuzzing; no fuzzy technique is claimed as executed.

### 4.4 This iteration's action: verify, not duplicate

The requested cases are **already present** and are exactly the ones the retained host capture measured green (§5). The permitted tool set provides only `write_file` (a whole-file overwrite) — there is no append or targeted-edit primitive — so satisfying "add" by duplicating already-present laws would require rewriting the entire host-measured-green 87-case file, introducing non-zero regression risk for zero semantic gain. The minimal, surgical action is therefore to **re-verify** the existing property cases against the source and the retained host measurement and record the result, which this section and §5 do. No candidate source path was rewritten. If the intent is genuinely *additional* cases beyond the existing ten, that should be done under an edit-capable workflow (or after explicitly confirming that overwriting the measured-green file is acceptable); the exact new laws to add are then a human decision, not a silent duplication.

What is deliberately **not** claimed:

- Nothing was compiled or executed by this iteration (no `shell`). The host measurement in §5 is a retained artifact, not produced here.
- These cases exercise the comparator/identity only. They are **not** platform validation; no fuzz or fault-injection harness exists in this workspace, and no fuzzy/explorative technique was executed.
- They do not settle the open design questions (whether `minor` should ever distinguish, duplicate vs. supersede, `ASSERT(!m_server)` authority, the #84 public-interface restructure, FindService wildcard, config `0xFFFFFFFF` narrowing). Those remain pending human decisions.

### 4.5 Runtime-level regression (present, unexecuted here)

`score/socom/test/unit/runtime_tests.cpp:402-431` (`ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError`) drives the real registration entry point: it builds two `Service_interface_identifier`s sharing id (`"TestInterface"`), major (`1`) and instance (`"TestInterface"`) and differing only in `minor` (2 vs 3), calls `Runtime::make_server_connector()` twice, and expects the second to equal `score::MakeUnexpected(Construction_error::duplicate_service)`. Both connectors remain disabled, so the duplicate is rejected at construction and never reaches the single-server precondition (`SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)`, `runtime_impl.cpp:369-371`). The file carries 31 `TEST_F` + 1 `TEST` + 1 `TEST_P`; its record metadata helper is at `:264-267`. It was **not** compiled by the retained host measurement (§5) and remains unexecuted here.

---

## 5. Host measurement and validation status

### 5.1 Retained artifacts in this checkout

`.llm_tmp/overnight/validation/` is populated. The artifacts read this iteration:

| Artifact | Content |
|----------|---------|
| `validation/check-result` | `0` |
| `validation/measurement.json` | `check_ref: check_lifetime_tests`, `status: completed`, `mode: plain`, `changed_paths: []`, `origin: local_unprotected_measurement`, `initiator: Fabro host hook`, `engineering_acceptance: pending`, `full_native_tests: not_executed`, compiler `/usr/bin/x86_64-linux-gnu-g++-12`; `baseline_with_agent_tests` = compile_exit 0 / test_exit 1 / **87 tests / 30 failures**; `candidate` = compile_exit 0 / test_exit 0 / **87 tests / 0 failures** |
| `validation/after.json` | `ServiceInstanceIdentifierTest`, **87 tests / 0 failures / 0 disabled / 0 errors**, timestamp `2026-10-03T03:39:52Z`; both `PropertyStrictWeakOrderingOnCombinedRegistrationKeyDomain` (`:836`) and `PropertyIdentifierEqualityOnCombinedRegistrationKeyDomain` (`:848`) present |
| `validation/before.json` | `ServiceInstanceIdentifierTest`, **87 tests / 30 failures**, timestamp `2026-10-03T03:39:45Z` (the same suite against the uncorrected, minor-including key) |
| `validation/after-compile.command.json` | focused `g++-12 -std=c++17 -Wall -Wextra -Werror -pthread -I.` over `service_identifier.cpp`, `string_registry.cpp`, `service_identifier_tests.cpp` + vendored googletest; `exit_code: 0` |
| `validation/after-test.command.json` | runs the `after` binary with `--gtest_output=json:…after.json`; `exit_code: 0` |
| `validation/before-compile.command.json` | same focused compile; `exit_code: 0` |
| `validation/before-test.command.json` | runs the `before` binary; `exit_code: 1` |

### 5.2 Interpretation

The retained measurement is a **focused, scoped** capture: it exercised only the identifier translation unit (`service_identifier.cpp` + `string_registry.cpp` + `service_identifier_tests.cpp` + vendored googletest), not `runtime_tests.cpp` and not the full `socom_test` / `//score/...` targets. Its `after.json` line/test names match the current file (87 cases, first case at `:168`), so the capture is current for the identifier translation unit. It is green in the candidate (`test_exit: 0`, 0/87) and red in the baseline-with-agent-tests (`test_exit: 1`, 30/87), which is source-consistent with the minor-excluding key: the agent tests fail against the uncorrected (minor-including) production key and pass against the corrected key.

It is **local and unprotected** and is **not** acceptance. It does not cover `runtime_tests.cpp`, the full native suite, sanitizers, coverage or static analysis.

### 5.3 Reproduction path for a later, permitted run (not executed here)

```bash
bazel test //score/socom/test/unit:socom_test
# focused key-level:
bazel test //score/socom/test/unit:socom_test --test_filter='ServiceInstanceIdentifierTest.*'
# focused property cases:
bazel test //score/socom/test/unit:socom_test \
    --test_filter='ServiceInstanceIdentifierTest.Property*'
# focused runtime regression:
bazel test //score/socom/test/unit:socom_test \
    --test_filter='RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError'
# integration / cross / docs / traceability (per the pinned plans)
bazel test --config=qemu-integration //tests/integration_test/...
```

### 5.4 Scope

Local, unprotected, scoped. This is a bounded source-inspection and property-test verification record, not an accepted engineering decision. Full native runtime tests and human review remain pending.

---

## 6. Obligations status (none satisfied)

### 6.1 Pinned state

`authority.json`: `engineering_acceptance: pending`, `human_reviews: unanswered`, `safety_class: unknown`, `codeql_scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload"`. Every `source-index.json` entry is `"native_acceptance": "not_inferred"`. `misra_mapping.rst` and `inspection_checklist.rst` are `:status: draft`.

### 6.2 Status for this slice

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Freedom from compiler warnings & errors (100 %) | `verification_plan.rst` (criterion 9) | **PARTIAL / NOT FULLY MEASURED** — header is brace-balanced (§2) and the retained focused host compile of the identifier TU exits `0` (§5), but no full native build was run and the runtime TU is not covered |
| Static code analysis (clang-tidy / CodeQL), findings classified | `code_analysis.rst`; `verification_process.rst` (`gd_req__verification_sca_classification`) | **NOT PERFORMED** — no tool run by this iteration; prior clang-tidy attempt blocked on configuration; CodeQL MISRA applicability unestablished (draft mapping) |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` (draft) | **UNKNOWN — NOT CLAIMED** — mapping not applied |
| Structural statement / branch coverage goals | `verification_plan.rst` (criteria 1-2) | **NOT MEASURED** — no coverage run by this iteration |
| Unit/component testing executed, results recorded | `verification_plan.rst` (criteria 6-7); `verification_guideline.rst` | **PARTIAL** — retained focused host run is 87/87 green for the identifier TU (§5); the runtime suite and the full target are unmeasured |
| Interface / requirements-based / resource / fault-injection test types | `verification_process.rst`; `verification_plan.rst` | **NOT PERFORMED / applicability not inferred** — no harness; identifier-only tests must not be labelled platform validation |
| Derivation techniques (boundary-values / equivalence-classes / fuzzy / error-guessing / explorative) | `verification_process.rst` | **SOURCE-ONLY / HOST-MEASURED for boundary+equivalence** on the identifier TU; **NOT EXECUTED / NOT CLAIMED** for fuzzy/explorative |
| Linking tests to requirements (record properties) | `verification_process.rst` (`gd_req__verification_link_tests_cpp`) | **PARTIAL / NOT DONE** — `DerivationTechnique`/`Description` recorded in `SetUp()` (`service_identifier_tests.cpp:42-65`; `runtime_tests.cpp:264-267`); `TestType` and the `Verifies` links deliberately unset (no verified native identifier; inventing one is prohibited) |
| External-component AoUs verified | `verification_process.rst` (`gd_req__verification_external_aou`) | **NOT SATISFIED** — no integration/static verdict; no AoU register |
| Independence of verification / review by a different committer | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Implementation inspection checklist IMPL_01…IMPL_03 | `inspection_checklist.rst` (draft) | **NOT FILLED** — draft template, no inspection |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** for this slice |
| Obligation collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **ABSENT from this checkout** — `glob **/result.json` returns nothing |
| Native acceptance | `source-index.json` | **`not_inferred` for every entry** |

**Explicit non-satisfaction statement.** Missing tools, the unknown safety class and un-inferred applicability, the absent obligation-collection results, and the unanswered human reviews mean **none of the checked obligations may be treated as satisfied**. The retained host result is green, but it is a local, unprotected, scoped capture; a retained result is not a passed check, and there are no obligation-collection result files at all. In particular, the presence of `.llm_tmp/overnight/validation/` is **not** evidence of acceptance, and the absence of `.llm_tmp/overnight/obligations/*/result.json` is **not** evidence that those checks passed.

---

## 7. Files changed / unchanged (candidate set)

This iteration wrote **only this report**:

| Candidate path | This iteration |
|----------------|----------------|
| `score/socom/test/unit/service_identifier_tests.cpp` | **Unchanged** — inspected; already carries 87 `TEST_F`, including the ten `Property*` cases (`:634`…`:755`, `:1055`…`:1139`, `:1456`…`:1516`); host-measured green (§5) |
| `score/socom/impl/service_identifier.hpp` | **Unchanged** — inspected; already brace-balanced (`:19`, `:29`, `:32`, `:38`; `:39` blank) |
| `score/socom/impl/service_identifier.cpp` | **Unchanged** — already excludes `minor`; identity `(instance, id, major)` |
| `score/socom/BUILD` | **Unchanged** — test-only `impl_service_identifier` exposure already present |
| `score/socom/test/unit/BUILD` | **Unchanged** — `socom_test` globs `*.cpp` and already depends on `//score/socom:impl_service_identifier` |
| `score/socom/test/unit/runtime_tests.cpp` | **Unchanged** — runtime duplicate/lifetime cases already present, incl. the minor-only regression `:402-431` |
| `.llm_tmp/overnight/reports/ordering_tests.md` | **New — this report** |

No file outside the six candidate paths and this report was written; no `NOTICE`, `LICENSE` or `REUSE.toml` file was created, edited or deleted; all prior reports, and every retained host artifact under `.llm_tmp/overnight/validation/`, were read only and preserved.

---

## 8. Notice preservation

- Only `.llm_tmp/overnight/reports/ordering_tests.md` (this report) was written. No candidate source path was changed, so every existing Apache-2.0 / notice header in the candidate set is untouched. Every candidate file retains its Apache-2.0 header (`score/socom/BUILD:1-12`, `impl/service_identifier.cpp:1-12`, `impl/service_identifier.hpp:1-12`, `test/unit/BUILD:1-12`, `test/unit/runtime_tests.cpp:1-12`, `test/unit/service_identifier_tests.cpp:1-12`).
- No `NOTICE`, `LICENSE`, `REUSE.toml`, config, production-source, BUILD or prior-report file was created, edited or deleted. All prior reports under `.llm_tmp/overnight/reports/` and `.llm_tmp/overnight/prior-reports/`, and all host artifacts under `.llm_tmp/overnight/validation/`, were preserved.
- The duplicate-server registration key remains an `impl/`-only type exposed only to `//score/socom/test/unit` through the `testonly` `//score/socom:impl_service_identifier` library, so no public header or notice surface changed.
- This report itself carries the Apache-2.0 header. No licensed MISRA rule text is reproduced; only native identifiers, source locations and retained artifacts are cited.

---

## 9. Pending human review checklist

- [ ] **Confirm §2:** the actual `service_identifier.hpp` is brace-balanced (single nested close `}  // namespace score::socom`; line 39 blank); the "extra brace at line 39" appears only in pre-correction descriptions; no source edit for the syntax failure is required, and re-introducing the broken state would be a regression.
- [ ] **Resolve the wording conflict:** "correct the actual source before expanding tests" vs. an already-correct source and already-present tests; confirm that verify-only (no-op source, report only) was the intended outcome here, and locate any distinct "cancelled draft" revision if it still carries the brace.
- [ ] **Confirm §3:** `minor` is **not** part of the duplicate-server registration key; identity is `(instance, service id, major)`; equality is `std::set` equivalence (no `operator==`/hash).
- [ ] **Review §4:** confirm the ten pre-existing property cases (36-, 64- and combined 100-key domains; strict weak ordering incl. equivalence transitivity; equality ⇔ identity tuple) are the wanted coverage, and decide whether *additional* cases are wanted. If so, they should be added under an edit-capable workflow rather than by overwriting the host-measured-green 87-case file.
- [ ] **Confirm §5:** the retained host measurement is 87 tests / 0 failures with `check-result: 0` for the identifier TU, `before.json` 87/30, and that it does **not** cover `runtime_tests.cpp` or the full native target.
- [ ] **Confirm the runtime regression** `ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError` (`runtime_tests.cpp:402-431`) and that using the public `Runtime::make_server_connector()` path is acceptable.
- [ ] **Run** `bazel test //score/socom/test/unit:socom_test` (and the broader `//score/...` set) on the native host to turn the source-derived expectations into measurements, including `runtime_tests.cpp`.
- [ ] **Supply native requirement/interface identifiers and traceability metadata** (no invented links), or record applicability as unresolved.
- [ ] **Provide a working clang-tidy/MISRA configuration and a sanitizer-capable environment** (or accept the limitation), then record the native build/test/lint/docs/coverage/sanitizer/integration results.
- [ ] **Keep the #84 public `Service_interface_identifier` restructure, FindService wildcard handling, and the config minor-wildcard narrowing out of this bounded slice** until separately accepted.
- [ ] **Do not treat the identifier-only/registration-key tests as platform validation**; provide a fuzz / fault-injection harness separately if required.
- [ ] **Supply the missing obligation results** (`.llm_tmp/overnight/obligations/*/result.json`) into this checkout, and resolve the `engineering_acceptance: pending` / `human_reviews: unanswered` state via an independent reviewer (the approver must differ from the author, per `gd_req__verification_independence`).

---

*End of property-style ordering/equality verification record. Local, unprotected, scoped. No engineering acceptance; human reviews unanswered; full native runtime tests pending. Every statement is a local reading of the working tree, a retained host artifact, a prior report's recorded reading, or an explicitly-labelled logical consequence — none is acceptance, review approval, publication, or a full native run.*
