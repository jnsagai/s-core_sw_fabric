<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — registration / teardown concurrency review of the bounded duplicate-server registration-key slice

**Document type:** review draft (actual-source concurrency inspection + register/teardown ordering +
locking + assertion audit + proposed tests + obligations status)
**Date:** 2026-10-02
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version handling in
socom* (issue #84) — this document reviews **concurrency assumptions, locking and assertions across
registration and teardown**.
**Run:** `fabro/run/01M3YRJEGXNY6CB81T7TKW774B` (branch of the same name).
**Status:** local, unprotected, scoped. **No engineering acceptance exists. Human reviews are
unanswered. Full native runtime tests remain pending.** Every statement below is either a direct
static reading of this checkout, or an explicitly-labelled logical consequence or proposal.
Nothing here is compiled by this iteration, executed, reviewed, accepted, published, or a full
native run.

> **Tool / write boundary actually observed.** Only `read_file`, `grep`, `glob`, and `write_file`
> were available and were the only tools used. No `shell`, no delegation, no web access, no
> approval, no publishing, and no engineering acceptance was performed. The task's explicit final
> sentence — *"This is a review draft: only that report may be written."* — is the operative write
> boundary, and it resolves the task's other direction ("Inspect and correct the actual source
> before expanding tests") in favour of **inspection only**. Accordingly **exactly one file was
> written: this report.** No source, build, test, config, `NOTICE`, `LICENSE`, `REUSE.toml`, or
> prior-report file was created, edited, or deleted. All prior reports were preserved unchanged.
>
> **Premise reconciliation — the recorded syntax failure is not in this checkout.** The task states
> *"a measured GCC syntax failure: an extra closing brace in
> `score/socom/impl/service_identifier.hpp` at line 39."* Direct inspection of the actual source
> (§2) shows exactly two opening braces (`:19`, `:29`) and two closing braces (`:32`, `:38`), net
> balance `0`; `:39` is **blank** and `:40` is `#endif`. Host evidence in this checkout corroborates
> the balanced state: the GCC focused compile of the identifier translation unit (which includes
> the header transitively) exits `0` with empty `stderr`
> (`.llm_tmp/overnight/obligations/compiler_diagnostics/gcc-compile.command.json` `exit_code: 0`;
> empty `gcc-compile.stderr`/`.stdout`). Because (a) the write boundary forbids source edits this
> iteration and (b) there is no defect in the actual file to correct, **no production source was
> edited.** The minimal historical repair is retained in §2.3 for reference only.
>
> **No test was expanded or executed.** All tests proposed in §7 are *proposals*; none was written
> or run. The reference to the "expanded tests" in the task is already satisfied on disk by the
> existing suites (§7.4), which this iteration read but did not compile or execute.

---

## 0. Summary

1. **No lock-order inversion is visible in the registration/teardown paths** (§4). The duplicate
   key set has a dedicated mutex (A) distinct from the runtime record mutex (B), the connector
   mutex (C), and the bridge mutex (D). This iteration found **no nested acquisition** of these
   locks at any call site: A is taken only in `make_server_connector`; B only in
   `register_connector`/record final actions; C/Cc only inside the connector `Impl`s; D is
   deliberately released around bridge callbacks. The registration/teardown ordering is therefore
   *single-lock-at-a-time* by construction, and deadlock-by-lock-order is not reachable through the
   sites reviewed. This is a static reading, **not** a ThreadSanitizer result (§8).
2. **The critical correctness property is cross-lock, not cross-thread-lock** (§3, §4). The
   single-server precondition `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)`
   (`runtime_impl.cpp:369`, under B) is guaranteed only because the duplicate key is held under A
   *continuously* from construction (`runtime_impl.cpp:449-454`) to destruction
   (`:456-463`), and because the key identity `(instance, service id, major)` equals the record
   identity `(id, major, instance)` (the record index ignores `minor`, `runtime_impl.hpp:116-134`).
   If either half were broken (finer key, as on the reported baseline; or a key released before the
   record is unregistered), a second connector for the same record could pass the gate and reach
   the assert. This document records that as the invariant to preserve, not as an observed defect.
3. **Teardown ordering is correct today but fragile in expression** (§5). `Impl` declares
   `m_registration` (`server_connector_impl.hpp:162`) *before* `m_final_action` (`:163`), so the
   key-erasing `Final_action` is destroyed **before** the server registration. Correctness relies on
   `~Impl(){ disable(); }` (`server_connector_impl.cpp:53`) having already reset `m_registration` in
   the destructor *body*. Any future path that leaves `m_registration` non-null at member
   destruction would free the key while `Service_record::m_server` is still set. This matches the
   `lifetime_review.md` CE-4 finding; this review frames it as an **assertion/ordering** hazard.
4. **Several concurrency assumptions are documented in comments but not enforced or measured**
   (§6): enable/disable non-concurrency, one `Connect` per server connector, the client-endpoint
   weak-token handshake, and `send_all`'s copy-then-send. The defensive asserts exist, but none is
   exercised concurrently by any retained artifact.
5. **Coverage attribution is stale.** `runtime_impl.cpp` cites `RuntimeMultiThreadingTest.
   BridgesAndSubscribeFindServiceHaveNoRaceConditions` (`:82`, `:216`, `:295`) and
   `CreationOfMultipleServerAndClientConnectorsHasNoRaceCondition` (`:102`) as "Sporadically
   covered", but **neither test exists anywhere in the tree** (grep over `/workspace` finds them
   only in those comments). The real concurrency suite is the separate
   `//score/socom/test/stress:socom_stress_test` (14 `TEST_F` across three files), which is **not
   part of `socom_test`** and was **not executed** by any retained artifact (§8).
6. **No obligation is satisfied** (§8). The retained obligation results are *retained*, not
   *passed*: `native_*` and `cross_compilation` exit `127` (`bazel` absent), `focused_tsan`
   compiled only the identifier translation unit and exited `66`/`-11`, and `focused_memcheck`'s
   `valgrind` is absent. The identifier suite is 85 cases in `after.json` while the working tree has
   87 `TEST_F` (`process_checks/result.json` reports `test_macros: 87`), so even that artifact is
   stale. `authority.json` records `engineering_acceptance: pending`, `human_reviews: unanswered`,
   `safety_class: unknown`.

---

## 1. Binding, evidence, and prior work

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` | `.llm_tmp/context/issue-snapshot.json:2-4` |
| Title | *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:3` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**: service-instance identifier = `service id + major + minor + instance id`; service
identifier = `service id + major`; FindService = `service id + major + optional<minor> +
optional<instance>`; and the proposal to "exclude the minor version and make it a property of the
service instance". No acceptance record exists in the snapshot, so none of it is binding.

### 1.2 Baseline and candidate set

| Item | Value | Source |
|------|-------|--------|
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |
| Candidate files | `score/socom/BUILD`, `impl/service_identifier.{cpp,hpp}`, `test/unit/BUILD`, `test/unit/runtime_tests.cpp`, `test/unit/service_identifier_tests.cpp` | `.llm_tmp/context/candidate-files.json:2-25` |

The manifest treats `service_identifier_tests.cpp` as a **new** file (baseline blob `null`). **The
three `score/socom/test/stress/*.cpp` files and all `impl/*.cpp` concurrency sources are outside
the six candidate paths**; this review reads them as evidence but any change to them would need
separate authorization.

**Content-hash caution.** The candidate `sha256` values no longer match the host-measured working
tree (e.g. candidate `service_identifier.hpp` `96b33a1f…` vs host `bdce3fcb…`;
`runtime_tests.cpp` `5e35e24d…` vs host `9a2d6a15…`; `service_identifier_tests.cpp` `45d07399…` vs
host `4df2c63c…`, per `.llm_tmp/overnight/obligations/process_checks/result.json:7-212`). The
working tree has moved relative to the candidate snapshot, so the snapshot's *description* of a
brace defect cannot be assumed to describe the current file; the direct read in §2 is
authoritative.

### 1.3 Retained host / obligation evidence read this iteration

- `.llm_tmp/overnight/validation/`: `check-result` = `0`; `measurement.json` (checked:
  `origin: local_unprotected_measurement`, `initiator: Fabro host hook`,
  `engineering_acceptance: pending`, `full_native_tests: not_executed`,
  compiler `/usr/bin/x86_64-linux-gnu-g++-12`, `baseline_with_agent_tests` = 85 tests / 28
  failures / compile exit 0, `candidate` = 85 tests / 0 failures / compile exit 0);
  `before.json` = 85/28; `after.json` = 85/0. **Scope caveat:** all of these cover only the focused
  identifier translation unit.
- `.llm_tmp/overnight/obligations/`: `compiler_diagnostics` (GCC `exit_code: 0`, empty
  `stderr`; the whole check is `findings_or_execution_failure` because a clang leg fails on a
  googletest/libstdc++ deprecation outside the candidate paths), `focused_tsan`,
  `focused_memcheck`, `native_*`, `cross_compilation`, `process_checks`
  (`completed_with_blockers`), `tool_assurance`, etc. Per the task rule, retention is not passing.
- Prior reports under `.llm_tmp/overnight/reports/` read and preserved: `scope.md`,
  `invariants.md`, `callsites.md`, `reproducer.md`, `key_fix.md`, `unit_matrix.md`,
  `ordering_tests.md`, `conversion_tests.md`, `runtime_disabled.md`, `runtime_enabled.md`,
  `lifetime_tests.md`, `test_metadata.md`, `coverage_tests_repair.md`, `tool_findings_repair.md`,
  `compatibility.md`, and the immediately preceding `lifetime_review.md`. This document adds
  `concurrency_review.md`; nothing was overwritten. The `.llm_tmp/overnight/prior-reports/`
  directory (12 files) was also preserved.

### 1.4 Pinned obligation sources

All nine entries of `.llm_tmp/context/obligations/source-index.json` are present, together with
`authority.json`. Every entry is `"native_acceptance": "not_inferred"`. `authority.json` records
`engineering_acceptance: pending`, `human_reviews: unanswered`, `safety_class: unknown`,
`codeql_scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload"`.

---

## 2. Premise: the recorded syntax failure

### 2.1 Finding (direct `read_file` + `grep`)

`score/socom/impl/service_identifier.hpp` is **brace-balanced**, 40 lines:

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers, two closers, net `0`. The task's "extra closing brace … at line 39" matches a stale,
pre-correction description; the `reproducer` iteration records the correction and the removed
brace left line 39 blank, exactly as observed here.

### 2.2 Measured corroboration (present, scoped, not acceptance)

- `.llm_tmp/overnight/obligations/compiler_diagnostics/gcc-compile.command.json`: `g++-12
  -std=c++17 -Wall -Wextra -Werror -pthread` over `service_identifier.cpp` +
  `string_registry.cpp` + `service_identifier_tests.cpp` + googletest, `exit_code: 0`; the
  `gcc-compile.stderr` and `gcc-compile.stdout` files are empty.
- `.llm_tmp/overnight/validation/after-compile.command.json` / `before-compile.command.json`:
  same shape, exit `0`.

A genuine unmatched brace would make these fail. They are scoped/unprotected, so they corroborate
the static reading but are **not** a full native build.

### 2.3 Minimal historical repair (reference only; NOT applied)

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

Applying this to the already-balanced file is a no-op at best and a regression at worst. **No
source was edited.** If the "cancelled draft" is a different revision that still carries the extra
brace (see the §1.2 hash caution), it is not the file in this checkout and must be located and
corrected by an authorized iteration.

---

## 3. Registration ordering

All line references are readings of this working tree.

### 3.1 `Runtime_impl::make_server_connector` (`runtime_impl.cpp:440-467`)

1. `Service_instance_identifier const identifier{configuration.get_interface(), instance};`
   (`:443`). Constructing the identifier interns the service id and instance id in the process-wide
   registries (`String_registry`, `string_registry.cpp:23/35/49`, each under its own mutex R).
2. Callback validation (`:445-447`) — no lock; returns `callback_missing` before touching the key.
3. **Lock A** (`m_service_identifiers->mutex`): `insert(identifier)`; on `false` return
   `duplicate_service`; unlock at end of scope (`:449-454`).
4. Build the key-erasing `Final_action` capturing `identifier` by value and a `weak_ptr` to the key
   set (`:456-463`).
5. Construct `SC_impl` and move the `Final_action` into it; return (`:465-466`).

Properties (static readings):

- **RC-1 — the duplicate check is atomic.** The only two mutations of the key set are the insert
  (`:451`) and the erase (`:460-461`), both under A. There is no read-then-write window, so for two
  concurrent `make_server_connector` calls on the same identity **exactly one** `insert` returns
  `true`. This is a `std::set`/mutex consequence, not an observed result.
- **RC-2 — no lock is held across user-visible work.** A is released before `SC_impl` is
  constructed and before any callback. R is released before A is taken (the identifier is fully
  built first). No nesting R→A either.
- **RC-3 — the key is reserved before the connector exists.** A second construction for the same
  slot is refused even while the first connector is still being built. This is intentional (the
  key tracks "any (Disabled, Enabled) Server_connector", `service_identifier.hpp:23-24`).
- **RC-4 — `m_service_identifiers` is read without A.** The `shared_ptr` member
  (`runtime_impl.hpp:228-229`) is initialized at construction and never reassigned, so concurrent
  reads are safe *provided* the `Runtime_impl` is published before threads use it (the factory
  contract). This is an assumption, not enforced locally.

### 3.2 `Impl::enable` → `Runtime_impl::register_connector`
(`server_connector_impl.cpp:55-78`; `runtime_impl.cpp:526-551`)

1. Reset promises, create `m_stop_block_token` and `m_all_clients_disconnected_block_token`
   (`:66-71`) — **no lock**.
2. `m_runtime.register_connector(interface, instance, Listen_endpoint{*this, m_stop_block_token})`
   (`:72-73`). Inside: **Lock B** (`m_runtime_mutex`) → `get_record` (`runtime_impl.cpp:530`,
   `:313-324`) → `register_server_connector` (`:531`, `:366-382`): assert `!m_server` (`:369`),
   `m_server.emplace(...)` (`:371`), build the record-unregistering `Final_action` (`:372-377`);
   unlock B (`:532`); if a client is present, `connect_client(...)` **outside B** (`:534-548`).
3. `SCORE_LANGUAGE_FUTURECPP_ASSERT(m_registration != nullptr)` (`:75`); assign `m_registration`
   (`:72`).

Properties (static readings):

- **RC-5 — `assert(!m_server)` and `m_server.emplace` are atomic under B.** There is no window
  between the check and the write for a competing holder of B.
- **RC-6 — the assert's precondition is supplied by A, not B.** Only one connector can hold the
  key for a record (RC-1), and the key is held continuously from `make_server_connector` until the
  connector is destroyed, so no second server can reach `register_server_connector` for the same
  record in between. This holds **because key identity == record identity** (the record index
  ignores `minor`, `runtime_impl.hpp:116-134`; the key orders by `(instance, id, major)`,
  `service_identifier.cpp:28-29`). This is the cross-lock invariant; on the reported baseline key
  (which included `minor`) it did not hold and both servers could reach the assert (prior-reports
  `invariants.md` I-11).
- **RC-7 — `connect_client` runs outside B.** The copied `Interfaced_client` keeps the
  `Server_indication` alive; the client-side lambda re-checks its own weak stop token
  (`client_connector_impl.cpp:144-155`) before use. This avoids an obvious lock-order hazard but the
  token check is only weakly synchronized with the client destructor (§6).

---

## 4. Locking map and ordering

### 4.1 Locks in scope

| Id | Lock | Site | Guards | Held across user callback? |
|----|------|------|--------|----------------------------|
| A | key mutex (`Mutexed_variable::mutex`) | `runtime_impl.hpp:50-56`, `:228-229`; used `runtime_impl.cpp:450`, `:460` | duplicate-server key `std::set` | no |
| B | `Runtime_impl::m_runtime_mutex` | `runtime_impl.hpp:220-221`, `:136`, `:94`; used `runtime_impl.cpp:495`, `:529`, `:374`, `:392` | `Service_database` records + server/client optionals | no (released before `connect_client`) |
| C | `server_connector::Impl::m_mutex` | `server_connector_impl.hpp:153`; used `server_connector_impl.cpp:87,123,146,163,181,203,219,226,295,344` | subscriber/update-requester/event-info tables, `m_client`, tokens | no (released before callbacks) |
| Cc | `client_connector::Impl::m_mutex` | `client_connector_impl.hpp:95`; used `client_connector_impl.cpp:39,105,111,178,196` | `m_server`, `m_registration`, `m_stop_block_token` | no |
| D | `Runtime_impl::m_bridge_mutex` | `runtime_impl.hpp:223`; used `runtime_impl.cpp:483,554,583,591,598` | bridge maps | no (`register_bridge`/`get_bridge_requests` explicitly unlock around callbacks, `:181/:192`, `:285/:287`) |
| R | `String_registry::m_mutex` | `string_registry.cpp:23,35,49` | process-wide id registries | no |
| DD | deadlock-detector mutex | `temporary_thread_id_add.cpp:22-33` | thread-id list | n/a |

### 4.2 Ordering / nesting

This iteration found **no site that holds one of A/B/C/Cc/D while acquiring another**. In
particular:

- A is taken only in `make_server_connector` (`:450`) and its `Final_action` (`:460`); neither
  touches B/C/Cc/D.
- B is taken in the two `register_connector` overloads and the two record `Final_action`s; none of
  those acquires A/C/Cc/D while holding B. `connect_client` (which can re-enter the runtime) runs
  **after** `lock.unlock()`.
- C/Cc are taken inside the connector `Impl`s and released before any user callback; the callback
  path (`send`/`receive`) acquires the *other* connector's mutex only after release.
- D is taken in `register_bridge`/`stop_registration`/`get_bridge_reported_instances` and is
  explicitly unlocked around bridge callbacks (`runtime_impl.cpp:181`, `:192`, `:285`, `:287`).

**RCC-1 (static):** lock-order inversion among A/B/C/Cc/D is not reachable through the sites
reviewed. This is *not* a ThreadSanitizer or lock-order-inversion tool result (§8), and a global
claim would require the full native concurrency run.

**RCC-2 (static):** the registration/teardown ordering is the real invariant, not the lock order:
the key (A) is acquired **before** the record is touched (B) at enable, and released **after** the
record is unregistered at teardown. Because A is independent of B, a lock-order tool would not see
this ordering; it must be preserved by construction. See §5.

### 4.3 The cross-lock single-server invariant

`Service_record` holds a single `std::optional` server (`runtime_impl.hpp:70`) and
`register_server_connector` asserts `!m_server` (`runtime_impl.cpp:369`). The gate that keeps this
true is A (server connectors only), while B protects the record itself. The invariant is:

> For every record, at most one live server connector exists at any instant, and it holds the key
> for that record's identity; therefore no `register_server_connector` for the same record can run
> concurrently with another.

This is preserved because key identity == record identity (RC-6). If the key were finer than the
record identity (the reported baseline), A would not serialize the two registrations and the assert
would be reachable. **Preserving key/record identity equality is therefore a concurrency
requirement, not merely an identity nicety.**

---

## 5. Teardown ordering

### 5.1 `~Impl` → `disable` (`server_connector_impl.cpp:53`, `:80-114`)

1. `disable()`: if `m_registration != nullptr`, `m_registration.reset()` (`:85`). The registration
   `Final_action` (`runtime_impl.cpp:372-377`) takes B and resets `m_server`.
2. Under **C**: reset `m_stop_block_token`, `m_all_clients_disconnected_block_token`,
   `unsubscribe_event()` (`:86-91`).
3. `m_stop_complete_promise.get_future().wait()` (`:106`) — waits for the stop handshake.
4. `send_all(Service_state_change{not_available, ...})` (`:109`) — copies `m_client` under C,
   unlocks, then sends to the client (`server_connector_impl.hpp:167-176`).
5. `m_all_clients_disconnected_promise.get_future().wait()` (`:110`).
6. `assert(m_registration == nullptr)` (`:112`).
7. Destructor body ends; members are destroyed in reverse declaration order
   (`server_connector_impl.hpp:146-164`): `m_credentials`, **`m_final_action`** (key erase under A),
   **`m_registration`** (already null), `m_client`, tables, tokens, promises, `m_mutex`, ..., `m_runtime`.

### 5.2 Ordering claims

- **RCC-3 (correct today):** because `disable()` runs in the destructor *body* and resets
  `m_registration`, the server is unregistered (B) **before** the key is erased (A). A new
  `make_server_connector` for the same slot must take A, which is only released by the key-erasing
  `Final_action`; therefore the new connector can only be constructed **after** the old record's
  `m_server` is cleared. This closes the registration/teardown ordering.
- **RCC-4 (fragile expression):** member declaration order is the *reverse* of the intended
  execution order (`m_registration` declared before `m_final_action`). Correctness depends entirely
  on step 1 above. If a future refactor ever destroys an enabled `Impl` without `disable()`
  clearing `m_registration`, the key would be released while `m_server` is still set, and the next
  enable for that record would reach `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)`. This mirrors
  `lifetime_review.md` CE-4. Recommended hardening (proposed, not applied): declare
  `m_final_action` **before** `m_registration`, or otherwise assert the erase-after-unregister
  order.
- **RCC-5 (disabled connector):** if `m_registration` is null, `disable()` is a no-op and only the
  key erase runs. Fine.
- **RCC-6 (runtime destroyed first):** the key's `weak_ptr` guard (`runtime_impl.cpp:456-463`)
  skips the erase if the runtime is gone. This is a lifetime guard (see `lifetime_review.md` CE-1),
  and it also means the key erase is a no-op after runtime destruction — no lock is touched.

---

## 6. Assertions and un-enforced concurrency assumptions

### 6.1 Assertion audit (concurrency-relevant)

| Assertion | Site | Lock | What would violate it |
|-----------|------|------|-----------------------|
| `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)` | `runtime_impl.cpp:369` | B (caller) | two servers for one record (gate must stay ≥ record identity, §4.3) |
| `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_client.has_value())` | `server_connector_impl.cpp:234` | C | a second `Connect` to one server connector |
| `SCORE_LANGUAGE_FUTURECPP_ASSERT(m_registration != nullptr)` | `server_connector_impl.cpp:75` | none | enable/disable called concurrently or out of contract |
| `SCORE_LANGUAGE_FUTURECPP_ASSERT(m_registration == nullptr)` | `server_connector_impl.cpp:112` | none | same |
| `SCORE_LANGUAGE_FUTURECPP_ASSERT(is_interface_compatible(...))` | `runtime_impl.cpp:508`, `:536` | none (after B unlock) | defensive; record narrowing should make it unreachable |
| `SCORE_LANGUAGE_FUTURECPP_ASSERT(id < m_subscriber.size())` etc. | `server_connector_impl.cpp:121,144,161,179,199-201,292-293,342` | C (mostly) | table/id mismatch; `m_configuration` is const so the index checks are read-only |
| `SCORE_LANGUAGE_FUTURECPP_ASSERT(bridge_lock.owns_lock())` | `runtime_impl.cpp:170,225,258` | D | internal lock-state protocol |
| `SCORE_LANGUAGE_FUTURECPP_ASSERT(m_registration)` | `client_connector_impl.cpp:174` | none | `set_registration` after a failed register |

**Assertion semantics are external.** Whether `SCORE_LANGUAGE_FUTURECPP_ASSERT` terminates, logs,
or is compiled out is defined in `score_baselibs` and is **not established in this checkout**. Where
it does not terminate, the code after a violated assert (e.g. `m_server.emplace`) silently replaces
or corrupts state. This matters for RCC-3/RCC-4 and is recorded as unknown.

### 6.2 Assumptions documented but not enforced

- **AS-1 — enable/disable are not concurrent.** The in-source comments
  (`server_connector_impl.cpp:56-60`, `:83-84`) justify the unlocked `m_registration` accesses by
  the API's `unique_ptr` type conversion. Nothing enforces it; a caller that invokes the static
  `enable`/`disable` on the same raw object from two threads races on `m_registration` and the
  promises. The public headers (`server_connector.hpp`, `runtime.hpp`) state **no** thread-safety
  contract for concurrent `make_server_connector`/`enable`/`disable` calls.
- **AS-2 — exactly one `Connect` per server connector.** `receive(message::Connect)`
  (`server_connector_impl.cpp:225-248`) asserts `!m_client` and emplaces under C; the comment says
  it "should have been checked already in Runtime" (`:233`). The check is effectively the
  client-side single-client rule (`register_client_connector` → `duplicate_client`,
  `runtime_impl.cpp:386-388`). If a client endpoint were delivered twice, the assert is the only
  guard.
- **AS-3 — weak-token handshake for client destruction.** `client_connector::Impl`'s connect
  lambda checks `weak_stop_token.lock()` (`client_connector_impl.cpp:146-153`) and
  `set_id_mappings_and_server` re-checks `m_stop_block_token` under Cc (`:177-193`). The source
  comments themselves call these "non deterministic behavior of thread scheduling" and exclude the
  false branches from coverage (`:163-165`, `:182-186`). There is a residual window where the lock
  succeeds just before the destructor resets the token.
- **AS-4 — `send_all` copy-then-send.** `send_all` copies `m_client` under C, unlocks, and only
  then dereferences the copied `Client_connector_endpoint` (`server_connector_impl.hpp:167-176` →
  `endpoint.hpp:29-31` → `client_connector::Impl::receive`). Safety depends on the disable
  handshake (§5.1) having serialized client teardown; it is not independently protected.
- **AS-5 — `m_service_identifiers` publication.** Read without A (RC-4). Safe only under the
  factory publication contract.
- **AS-6 — failed-insert never leaks.** `is_valid` runs *before* the insert (`runtime_impl.cpp:445`
  then `:449`), so `callback_missing` does not leak a key. If `SC_impl` construction threw, the
  function is `noexcept` and would terminate (no unwinding guarantee); recorded, not a defect claim.

### 6.3 Stale coverage attribution (concrete, static)

`runtime_impl.cpp` cites non-existent tests as coverage for its race-prone branches:

- `:82` and `:216` — `// Sporadically covered by TEST_F(RuntimeMultiThreadingTest,
  BridgesAndSubscribeFindServiceHaveNoRaceConditions)`
- `:102` — `// Sporadically covered by TEST_F(RuntimeMultiThreadingTest,
  CreationOfMultipleServerAndClientConnectorsHasNoRaceCondition)`
- `:295` — `// TEST_F(RuntimeMultiThreadingTest, BridgesAndSubscribeFindServiceHaveNoRaceConditions)`

`grep` over `/workspace` finds these names **only in those comments**; no such `TEST_F` exists.
The current `RuntimeMultiThreadingTest` (`test/stress/runtime_multi_threading_tests.cpp`) contains
`CreationOfServerAndClientConnectorsHasNoRaceCondition`, `…CallsCallbacksInCorrectOrder`,
`BridgesWhichCreateServerConnectorsAndClientConnectorsHaveNoRaceCondition`, and
`BridgesAndClientConnectorsHaveNoRaceCondition` — a different set. The comments therefore assert
coverage that the suite does not provide, and the referenced cases are unavailable to the
collector's metadata inventory.

### 6.4 Existing concurrency suite and its strength

- The real concurrency tests live in `.llm_tmp`-external `score/socom/test/stress/`:
  `runtime_multi_threading_tests.cpp` (4 `TEST_F`), `client_multi_threading_tests.cpp` (5
  `TEST_F`), `connection_multi_threading_tests.cpp` (5 `TEST_F`) — **14 `TEST_F` total** — plus
  `score/socom/test/unit/multi_connection_tests.cpp` (2 `TEST_F`). They are a separate Bazel
  target, `//score/socom/test/stress:socom_stress_test` (`test/stress/BUILD:16-31`, `tags =
  ["component"]`, with `tsan.supp`), and are **not** part of `socom_test`
  (`test/unit/BUILD:16-29`, `srcs = glob(["*.cpp"])` only).
- **Strength limitation (static):** `multi_threaded_test_template`
  (`test/framework/src/multi_threaded_test_template.cpp:61-88`) stops each loop thread on
  `Or{Timeout(5s), And{Num_iterations(100), caller_stop_condition}}`. A stress test can therefore
  finish **after 100 iterations even if the caller's success condition was never met**, so some
  cases can pass without exercising the intended interleaving. This is an observation about test
  strength, not a defect claim.
- **No retained artifact executes them** (§8): `native_*`/`cross_compilation` exit `127`
  (`bazel` absent), and `focused_tsan` compiled only the identifier translation unit.

---

## 7. Proposed tests (proposals only — none written or run)

These are *proposals* for authorized follow-up work. They are phrased so they can be added to the
in-scope candidate `score/socom/test/unit/runtime_tests.cpp`; any addition to the out-of-candidate
`test/stress/` suite would need separate authorization. None of them is a safety-acceptance claim,
and none was compiled or executed here.

### 7.1 Registration-race tests (unit, `RuntimeTest`)

1. **`ConcurrentDuplicateRegistrationsHaveExactlyOneWinner`** — spawn N threads that each call
   `runtime->make_server_connector(configuration, instance, callbacks_i)` for the same identity;
   join and assert exactly one result `has_value()` and N-1 equal
   `MakeUnexpected(Construction_error::duplicate_service)`. Detects any read-then-write (TOCTOU) in
   the A-protected insert and any missing lock.
2. **`ConcurrentDuplicateRegistrationsThenEnableWinner`** — as (1), then
   `Disabled_server_connector::enable` the winner. A second valid connector reaching enable would
   violate `ASSERT(!m_server)`; the test would terminate rather than return, so it doubles as the
   guard for RCC-3/RCC-6 under concurrency.
3. **`ConcurrentDistinctKeysAllSucceed`** — N threads register N distinct
   `(instance, service id, major)` identities; assert all succeeds and the key set holds exactly N
   entries (via N subsequent duplicates all refused). Detects false collisions from an incorrectly
   synchronized comparator.
4. **`ConcurrentRegisterAndFindServiceUnaffected`** — one thread repeatedly
   `make_server_connector`/destroy while another calls the public discovery/bridge path; assert no
   crash and that the key change did not alter discovery. Frames the §7 invariant that the key is a
   duplicate gate only.

### 7.2 Teardown-race tests (unit, `RuntimeTest`)

5. **`ConcurrentMakeAndDestroySameSlotConvergesToFreeSlot`** — one thread loops
   `make_server_connector` + immediate destroy for a fixed identity while another does the same for
   a *different* identity; join, then assert a fresh registration for the first identity succeeds.
   Detects a key leaked by a failed concurrent construct/destroy. (This exercises ordering RCC-3
   under interleaving.)
6. **`ConcurrentEnableAndDestroyDifferentSlotsIsRaceFree`** — two threads each
   make→enable→destroy a distinct slot; assert both complete without termination. Exercises the
   B-vs-A teardown ordering for independent records.

### 7.3 Stress/TSAN proposals (out-of-candidate; authorization required)

7. **`ConcurrentServerConnectorRegistrationStress`** in
   `test/stress/runtime_multi_threading_tests.cpp` using `multi_threaded_test_template`, with the
   caller stop condition requiring at least one success and one duplicate per iteration (to work
   around the §6.4 strength limitation). Must be run under the stress target's TSAN configuration
   (`test/stress/BUILD:20-23`) to have evidential value.
8. **`ConcurrentServerAndClientConnectorLifetimeStress`** — overlapping client connect/disconnect
   and server enable/disable on matching identities, to exercise AS-3/AS-4 under TSAN.

### 7.4 Tests already on disk (read, not executed)

- `score/socom/test/unit/runtime_tests.cpp`: **31 `TEST_F` + 1 `TEST` (`:239`) + 1 `TEST_P`
  (`:1311`)**, per `process_checks/result.json` (`test_macros: 33`) — including the minor-only
  regression `ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError`
  (`:402-431`) and the enabled/slot-isolation cases (`:694`, `:726`, `:986`, `:1021`, `:1045`,
  `:1091`, `:1141`, `:1197`, `:1253`). These are the suite referenced by the task's "expanded
  tests"; they are single-threaded and do **not** cover the hazards in §6.
- `service_identifier_tests.cpp`: **87 `TEST_F`** in the working tree (`process_checks/result.json`
  `test_macros: 87`), while `after.json` executed only 85 — a 2-test staleness gap
  (`:1982`, `:2012`).

### 7.5 Hardening proposals (source, not applied)

- Declare `m_final_action` **before** `m_registration` in `server_connector_impl.hpp:162-163`, or
  otherwise assert/express that the key erase must follow server unregister (RCC-4).
- Add a guard in `remove_client()` (`server_connector_impl.cpp:217-223`) that `m_client` is engaged
  before `unsubscribe_event(*m_client)` (AS-2/AS-4 robustness).
- Document the single-threaded-per-connector contract (AS-1) in `server_connector.hpp` /
  `runtime.hpp`, since the code relies on it.
- Remove or re-point the stale coverage comments in `runtime_impl.cpp:81-82`, `:101-102`,
  `:215-216`, `:295` (CC-6.3) so coverage attribution matches existing tests.

None of these is applied here; each would require authorization and (for code changes) a build/test
cycle this review cannot run.

---

## 8. Obligations and measurement status (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Freedom from compiler warnings & errors (100 %) | `verification_plan.rst` (criterion 9) | **PARTIAL, NOT SATISFIED** — GCC focused identifier TU exit `0` (empty stderr); clang leg fails on a googletest/libstdc++ deprecation outside the candidate paths; no Bazel build; `runtime_tests.cpp`/stress not compiled |
| Static code analysis (clang-tidy / CodeQL), findings classified | `code_analysis.rst`; `verification_process.rst` | **NOT SATISFIED** — `focused_clang_tidy` exit `1` (config); CodeQL mapping is draft; findings not classified by an authorized owner |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` (`:status: draft`) | **UNKNOWN** — not applied |
| Structural statement / branch coverage goals | `verification_plan.rst` | **NOT SATISFIED** — focused coverage `score/socom/impl/` only, 100 % line / 78.6 % branch, `complete_target_scope: false`, `safety_class: unknown_requires_authorized_selection`; below the 85/100 goals on branch |
| Unit/component testing executed, results recorded | `verification_plan.rst`; `verification_guideline.rst` | **PARTIAL, STALE** — 85 identifier tests 0/0 in `after.json`; 87 in tree; `runtime_tests.cpp` and the 14 stress `TEST_F` never executed |
| Concurrency / race verification (TSAN) | `code_analysis.rst` (sanitizers); `verification_process.rst` | **NOT SATISFIED** — `focused_tsan` compiled only the identifier TU and exited `66`/`-11`; `native_tsan` exit `127` (`bazel` absent); no stress-suite TSAN run |
| Interface / requirements / resource / fault-injection test types | `verification_process.rst`; `verification_plan.rst` | **NOT PERFORMED / applicability not inferred** — identifier/runtime-key tests are not platform validation |
| Boundary / equivalence derivation | `verification_process.rst` | **SOURCE-ONLY** for the concurrency cases; identifier keys executed |
| Fuzzy / fuzz testing technique | `verification_plan.rst` | **NOT EXECUTED / NOT CLAIMED** |
| Linking tests to requirements (record properties) | `verification_process.rst` (`gd_req__verification_link_tests*`) | **PARTIAL** — `DerivationTechnique`/`Description` recorded; `TestType`/`Verifies` unset (no invented identifiers) |
| Independence of verification / review | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Implementation inspection checklist | `inspection_checklist.rst` (`:status: draft`) | **NOT FILLED** |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** — `valgrind`/`gitleaks` unavailable; TSAN environment failing |
| Obligation collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **RETAINED, NOT PASSED** — present, several `findings_or_execution_failure` (native_*, cross_compilation, focused_tsan/memcheck/clang_tidy/cppcheck, compiler_diagnostics clang leg, format_precommit) |
| Native acceptance | `source-index.json` | **`not_inferred` for every entry** |

**Explicit non-satisfaction statement.** Missing tools (`bazel`, `valgrind`, `gitleaks`), failing
or blocked focused checks (clang, TSAN, memcheck, clang-tidy, cppcheck), the un-inferred
applicability, the stale identifier measurement, and the unanswered human reviews mean **none of
the checked obligations may be treated as satisfied**. A retained collection node proves
*retention*, not passing.

**Measurement executed by this iteration: none.** No build, no test, no runtime, no sanitizer. The
ordering, locking, assertion, and proposed-test statements above are static readings or
explicitly-labelled logical consequences; the host GCC compile note in §2.2 is a *retained* artifact,
not produced here.

**Reproduction path for a later, authorized iteration (not run here):**

```bash
bazel test //score/socom/test/unit:socom_test
bazel test //score/socom/test/unit:socom_test --test_filter='RuntimeTest.*'
# concurrency suite (separate target; must be executed under TSAN to be meaningful):
bazel test //score/socom/test/stress:socom_stress_test
bazel test --config=tsan //score/socom/test/stress:socom_stress_test   # if such a config exists
```

---

## 9. Notice preservation

- **Only this report was written.** No source, build, test, config, `NOTICE`, `LICENSE`,
  `REUSE.toml`, or prior-report file was created, edited, or deleted. All Apache-2.0 / SPDX headers
  on every file read remain untouched (`score/socom/impl/service_identifier.{hpp,cpp}:1-12`,
  `runtime_impl.{hpp,cpp}:1-12`, `server_connector_impl.{hpp,cpp}:1-12`,
  `client_connector_impl.{hpp,cpp}:1-12`, `test/unit/runtime_tests.cpp:1-12`,
  `test/stress/*.cpp:1-12`, and the `BUILD` files).
- The header the task flagged (`score/socom/impl/service_identifier.hpp`) was inspected and left
  unchanged because it is already brace-balanced and otherwise well-formed (§2).
- This report itself carries the Apache-2.0 header.
- The duplicate key remains an `impl/`-only type exposed to `//score/socom/test/unit` only through
  the `testonly` `//score/socom:impl_service_identifier` library; no public header or notice
  surface changed.

---

## 10. Pending human review checklist

- [ ] **Resolve the premise discrepancy (§2):** the "extra closing brace at line 39" does not exist
      in this checkout (line `:39` blank; header balanced; GCC focused compile exits `0`). Confirm
      no source edit is required, or point to the actual "cancelled draft" revision (cf. the §1.2
      hash mismatch) if it is a different artifact.
- [ ] **Confirm the single-lock, no-inversion reading (§4)** and authorize a lock-order/TSAN run of
      the runtime and stress suites; the static reading is not a race-detector result.
- [ ] **Ratify the cross-lock single-server invariant (§4.3):** key identity must stay equal to
      record identity so that A continues to protect B's `ASSERT(!m_server)`; do not re-fine the
      key without re-examining concurrency.
- [ ] **Adjudicate the teardown-order fragility (RCC-4):** approve declaring `m_final_action` before
      `m_registration` (or an equivalent guard) so the erase-after-unregister order is expressed,
      not incidental.
- [ ] **Resolve the assertion semantics** of `SCORE_LANGUAGE_FUTURECPP_ASSERT` in `score_baselibs`
      (terminate vs compiled out) — it determines whether a violated precondition is UB.
- [ ] **Confirm the un-enforced assumptions (§6.2)** are acceptable contract, or request
      enforcement/documentation (AS-1 enable/disable; AS-2 one `Connect`; AS-3 weak-token handshake;
      AS-4 `send_all` copy).
- [ ] **Correct the stale coverage attribution (§6.3):** remove or re-point the
      `BridgesAndSubscribeFindServiceHaveNoRaceConditions` /
      `CreationOfMultipleServerAndClientConnectorsHasNoRaceCondition` comments in
      `runtime_impl.cpp`.
- [ ] **Approve or reject the proposed tests (§7)** and the out-of-candidate stress additions; none
      was written here and none is a safety-acceptance claim.
- [ ] **Refresh the measurements (§8):** run `bazel test //score/socom/test/unit:socom_test` and
      `//score/socom/test/stress:socom_stress_test` (under TSAN), so `runtime_tests.cpp` and the 14
      stress `TEST_F` — and the two newest identifier tests (`:1982`, `:2012`) — are actually
      compiled and executed; do not re-report the 85-test focused identifier artifact as coverage
      of the current tree.
- [ ] **Re-baseline the candidate set (§1.2):** candidate-manifest hashes no longer match the
      working tree.
- [ ] **Schedule independent human review** (approver ≠ author, `gd_req__verification_independence`)
      and do not treat the retained obligation results as passing.
