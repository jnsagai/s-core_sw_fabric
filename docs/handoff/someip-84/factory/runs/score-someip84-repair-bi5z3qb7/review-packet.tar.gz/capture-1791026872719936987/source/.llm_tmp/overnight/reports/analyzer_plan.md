<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — native analyzer configuration & changed-unit plan (`analyzer_plan`) review draft

**Document type:** review draft (actual-source inspection + native-analyzer-configuration review
+ changed-unit inspection + retained host-measurement and obligation-artifact reading +
tool/version/applicability gap register + obligations status).

**Date:** 2026-10-03
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version handling in
socom* (issue #84)
**Run / branch:** `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ` (environment)
**Verified baseline commit:** `f8a196c3b16d5172d898394ab99b0ed81346d63d`
(`.llm_tmp/context/source-manifest.json:3`)
**Status:** **local, unprotected, scoped.** No engineering acceptance exists. Human reviews are
unanswered. Full native runtime tests are pending. Nothing in this document is acceptance, review,
publication, or a full native run.

> **Tool / write boundary observed.** This iteration used only `read_file`, `grep`, `glob`, and
> `write_file`. No `shell`, no `edit_file`, no delegation, no web access, no approval, no publishing,
> and no engineering acceptance was performed. The task's final sentence — *"This is a review draft:
> only that report may be written."* — is the explicit write boundary, and it governs: **exactly one
> file was written, this report** (`/workspace/.llm_tmp/overnight/reports/analyzer_plan.md`). No
> source, build, test, config, `NOTICE`, `LICENSE`, `REUSE.toml`, or prior-report file was created,
> edited, or deleted, and no test was expanded.
>
> **The task also directs "Inspect and correct the actual source before expanding tests."** Direct
> inspection shows the named source is already correct: `score/socom/impl/service_identifier.hpp` is
> a 40-line, brace-balanced header (§2). The only file that `glob **/service_identifier*` resolves is
> `impl/service_identifier.{hpp,cpp}` and `test/unit/service_identifier_tests.cpp`; there is **no
> second, differently-braced copy** anywhere in this checkout. The write boundary forbade a source
> edit, and it was moot because no defect is present. The instruction conflict is recorded for the
> human reviewer (§10), not silently resolved.
>
> **Non-satisfaction rule applied throughout.** A successful obligation-collection node means results
> were **retained**, not that checks **passed**. Missing tools, unknown applicability, incomplete
> extraction, a draft rule mapping, and unanswered human reviews are **not** treated as satisfied. A
> tool that produced no finding because it did not run is *"not run"*, never *"clean"*.

---

## 0. Summary

1. **The recorded "extra closing brace at line 39" is not present in the actual source (§2).**
   `score/socom/impl/service_identifier.hpp` is 40 lines and brace-balanced: openers at `:19`
   (`namespace score::socom {`) and `:29` (`struct Service_instance_identifier final {`), closers at
   `:32` (`};`) and `:38` (`}  // namespace score::socom`). Line `:39` is blank, `:40` is `#endif`.
   Net brace balance `0`; no third unmatched closer exists. The host validation **actually measured**
   the flagged translation unit compiling with `g++-12 -std=c++17 -Wall -Wextra -Werror
   -fsanitize=undefined` and **exiting 0** (§1.4), which is impossible if a stray `}` were present.
   **No source correction was applied, and none is required.**
2. **Host validation and obligation artifacts are now present in this checkout (§1.4, §1.5)** and are
   read directly here (earlier reports called them absent). The focused measurement is a genuine
   red→green for the slice: `baseline_with_agent_tests` **91 tests / 33 failures / compile 0** vs
   `candidate` **91 tests / 0 failures / compile 0** (`validation/measurement.json` tail;
   `validation/before.json`; `validation/after.json`); `validation/check-result` = `0`.
3. **The working key is the corrected one (§4).** `operator<` orders by
   `(instance, service id, major)` and excludes `minor`
   (`score/socom/impl/service_identifier.cpp:28-29`), matching the minor-ignoring
   `Service_database` index (`impl/runtime_impl.hpp:116-134`). The key-level tests now number
   **91 `TEST_F`** (`service_identifier_tests.cpp:168`…`:2181`, re-counted this iteration by `grep`);
   `runtime_tests.cpp` carries **1 `TEST` + 31 `TEST_F` + 1 `TEST_P`** (`:239`…`:1311`).
4. **Native analyzer configuration review (§3).** clang-tidy remains **not runnable as configured**:
   `//:.clang-tidy` still uses a YAML folded block scalar (`Checks: >`,
   `.clang-tidy:16-162`) with `#` comment lines inside it, and the focused `--verify-config` run
   (clang-tidy 19.1.7) still exits `1` with the blocker *"Native analyzer configuration
   incompatible; no replacement called MISRA"* (`obligations/focused_clang_tidy/result.json:1052-1055`;
   `.clang-tidy:85` `clang-analyzer-alpha.security.ArrayBoundV2`; `.clang-tidy:112,223`
   `modernize-use-integer-sign-comparison`). The native `//:clang-tidy.check` leg **timed out**
   (exit `124`, `obligations/native_lint/result.json:1077-1079`), so it likewise produced no
   findings. **Zero clang-tidy findings on the changed units is "not run", never "clean".**
5. **Native Bazel analyzers/sanitizers now execute and pass (§3.5–§3.7).** *This is a material change
   from the prior `analyzer_plan` draft, which recorded `bazel` as absent (exit `127`).* Here:
   `bazel build //...` exit `0` (`native_build`); `bazel test //... --build_tests_only` exit `0`
   (`native_tests`); ASan/LSan/UBSan over `//score/... //tests/...` exit `0` (`native_sanitizers`);
   TSan over the same set exit `0` (`native_tsan`); `bazel coverage //... --build_tests_only` exit `0`
   (`native_coverage`, threshold 73); x86_64/aarch64 cross builds exit `0` (`cross_compilation`, QNX
   SDK blocker retained). Focused GCC and Clang compiles both exit `0`
   (`compiler_diagnostics`), and focused memcheck now exits `0` (`focused_memcheck`).
6. **CodeQL remains collector-only and incompletely extracted (§3.3).** The repository CI runs only
   `//:clang-tidy.check` and `//:ruff.check`
   (`.github/workflows/static-code-analysis.yml:23`); no CodeQL workflow exists. The security suite's
   findings are **all** under `.llm_tmp/googletest/...`; the MISRA suite's in-source findings are the
   `cpp/misra/external-linkage-not-declared-in-header-file-misra` hits on the gtest `TEST_F` macro
   expansion lines of `service_identifier_tests.cpp`, plus a `copy-and-move-assignments-…` hit in a
   vendored gtest header. Both runs carry the self-declared limit *"Focused linked executable, not
   full target extraction; dependency findings retained"*.
7. **No MISRA-compliance claim is possible (§6).** `misra_mapping.rst` is `:status: draft`
   (`:20`) with its rule table commented out (`:26-31`); CodeQL MISRA carries blockers *"MISRA
   applicability/mapping draft and incomplete"*, *"Default suite omits manual/audit obligations"*,
   *"Compiled query qualification and human deviations pending"*. cppcheck explicitly limits itself to
   *"Optional complementary checks; no inferred MISRA rule coverage"*.
8. **No obligation is satisfied (§7).** Every `source-index.json` entry is
   `native_acceptance: not_inferred`; `authority.json` records `engineering_acceptance: pending`,
   `human_reviews: unanswered`, `safety_class: unknown`. Retained results are scoped and partly
   blocked; retention ≠ passing.

---

## 1. Binding, prior reports, host feedback, obligation artifacts

### 1.1 Issue and baseline

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` — *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:2-4` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` (unchanged) | `.llm_tmp/context/issue-snapshot.json:19-20` |
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |
| Branch | `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ` | environment |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**: service-instance identifier = `service id + major + minor + instance id`; service
identifier = `service id + major`; FindService = `service id + major + optional<minor> +
optional<instance>`; exclude `minor` and make it an instance property. There is no comment and no
acceptance record. Binding is **by baseline commit**, not by run HEAD.

### 1.2 Candidate paths (cross-checked against `candidate-files.json` and `source-manifest.json`)

| File (repo-relative) | Baseline git blob | Current working tree |
|----------------------|-------------------|----------------------|
| `score/socom/BUILD` | `3477ea08…` | `socom` library `:24-41` (globs `impl/**`), `testonly` `impl_service_identifier` `:46-54` |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e…` | 33 lines; `operator<` identity `(instance, id, major)`, `minor` excluded (`:20-30`) |
| `score/socom/impl/service_identifier.hpp` | `c8bae790…` | 40 lines, brace-balanced (`:19,:29,:32,:38`), `:39` blank (§2) |
| `score/socom/test/unit/BUILD` | `3c03a7b1…` | `socom_test` globs `*.cpp`; deps wired |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab7…` | 1 `TEST` + 31 `TEST_F` + 1 `TEST_P` (`:239`…`:1311`) |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(none — `null`)* | new file; **91 `TEST_F`** (`:168`…`:2181`) |

`score/socom/impl/service_identifier.hpp` carries submission sha256
`bdce3fcbc3cd78a8ecaece1ea36107d464011ab81c9bc39932d0be617befaea9` and
`service_identifier_tests.cpp` carries `de79767c4653feca7b5b2fcf93f5a791bcc64ae4b554dc2ef35a8756536391e6`
in the obligation `source_hashes` blocks (`obligations/focused_clang_tidy/result.json:126-127,190`;
`obligations/codeql_misra/result.json:190`). This iteration had no hashing tool, so those hashes are
quoted from the retained artifacts, not re-measured.

### 1.3 Prior reports read and preserved

- `.llm_tmp/overnight/prior-reports/` — **38 files present, all preserved**; the directly relevant
  predecessor is `prior-reports/analyzer_plan.md`, plus `tool_findings_repair.md`, `bazel_plan.md`,
  `misra_applicability.md`, `misra_manual_review.md`, `finding_classification.md`,
  `tool_assurance_review.md`, `native_build_review.md`, `sanitizer_review.md`, `coverage_review.md`,
  `coverage_tests_repair.md`, `compatibility.md`, `api_review.md`, `callsites.md`, `invariants.md`,
  `key_fix.md`, `reproducer.md`, `scope.md`, `unit_matrix.md`, `ordering_tests.md`,
  `conversion_tests.md`, `runtime_disabled.md`, `runtime_enabled.md`, `lifetime_tests.md`,
  `test_metadata.md`, `review_packet.md`, `verification_report_draft.md`.
- `.llm_tmp/overnight/reports/` — **20 files present and preserved** before this write
  (`api_review.md`, `bazel_plan.md`, `callsites.md`, `compatibility.md`, `concurrency_review.md`,
  `conversion_tests.md`, `coverage_tests_repair.md`, `invariants.md`, `key_fix.md`,
  `lifetime_review.md`, `lifetime_tests.md`, `ordering_tests.md`, `repair_conversion_tests.md`,
  `reproducer.md`, `runtime_disabled.md`, `runtime_enabled.md`, `scope.md`, `test_metadata.md`,
  `tool_findings_repair.md`, `unit_matrix.md`). This document is the 21st entry.

The prior `analyzer_plan.md` draft (run `01M3YRJEGXNY6CB81T7TKW774B`) is accurate for its snapshot but
stated `.llm_tmp/overnight/validation/` and `.llm_tmp/overnight/obligations/` were absent and that
`bazel` exited `127`. Those two facts are now **superseded**: both trees are present and complete
native Bazel legs ran (§1.5, §3.5–§3.7). The retained readings are preserved; the superseding
measurements are recorded below.

### 1.4 Host validation feedback (`.llm_tmp/overnight/validation/`) — present this iteration

| Artifact | Content |
|----------|---------|
| `check-result` | `0` |
| `measurement.json` | `check_ref: check_conversion_tests`, `status: completed`, `mode: ubsan`, `changed_paths: ["score/socom/test/unit/service_identifier_tests.cpp"]`, `origin: local_unprotected_measurement`, `initiator: Fabro host hook`, `engineering_acceptance: pending`, `full_native_tests: not_executed`; compiler `/usr/bin/x86_64-linux-gnu-g++-12` (sha `88315fd2…`); **`baseline_with_agent_tests`: 91 / 33 / compile 0**; **`candidate`: 91 / 0 / compile 0** (`measurement.json:2039-2058`) |
| `before.json` / `after.json` | gtest JSON for `ServiceInstanceIdentifierTest`: `before` 91 tests / 33 failures; `after` 91 tests / 0 failures (`:1-9`, tail) |
| `before-*` / `after-*` capture | `after-compile.command.json` = `g++-12 -std=c++17 -Wall -Wextra -Werror -fsanitize=undefined -fno-sanitize-recover=all` over `service_identifier.cpp` + `string_registry.cpp` + `service_identifier_tests.cpp`, **exit 0**; `after-compile.stderr`, `before-compile.stderr`, `after-test.stderr` all **empty** |

The measured red→green is the direct consequence of the key excluding `minor` (§4): 33 key tests fail
against the pre-correction ordering and pass against the working ordering. The measurement is still
**focused and scoped** (one identifier translation unit; no `runtime_tests.cpp`, no full native
run); it is local, unprotected, and does not constitute acceptance.

### 1.5 Obligation artifacts (`.llm_tmp/overnight/obligations/`) — present this iteration

25 checks are retained, each `origin: local_unprotected_measurement` and
`engineering_acceptance: pending`. Statuses re-read this iteration:

| Check | Status | Key retained fact |
|-------|--------|-------------------|
| `native_build` | completed | `bazel build --jobs=2 //...` exit `0` (`:1078`) |
| `native_tests` | completed | `bazel test --jobs=2 //... --build_tests_only` exit `0` (`:1079`) |
| `native_sanitizers` | completed | ASan/LSan/UBSan over `//score/... //tests/...` exit `0` (`:1083`) |
| `native_tsan` | completed | TSan over `//score/... //tests/...` exit `0` (`:1081`) |
| `native_coverage` | completed | `bazel coverage //...` exit `0`; limit *"Repository CI threshold 73 is not platform 85/100 line-and-branch acceptance"* |
| `cross_compilation` | completed_with_blockers | x86_64 + aarch64 exit `0`; blocker *"QNX SDK entitlement and target execution not configured"* |
| `native_lint` | findings_or_execution_failure | `//:clang-tidy.check` **exit 124 (timeout)**; `//:ruff.check` exit `0` |
| `focused_clang_tidy` | findings_or_execution_failure | `--verify-config` exit `1`; blocker *"Native analyzer configuration incompatible; no replacement called MISRA"* |
| `focused_cppcheck` | findings_or_execution_failure | exit `2`; limit *"Optional complementary checks; no inferred MISRA rule coverage"* |
| `codeql_security` | findings_or_execution_failure | create/analyze exit `0`; findings dependency-only; limit *"Focused linked executable, not full target extraction"* |
| `codeql_misra` | findings_or_execution_failure | blockers *"MISRA applicability/mapping draft and incomplete"*, *"Default suite omits manual/audit obligations"*, *"Compiled query qualification and human deviations pending"* |
| `compiler_diagnostics` | completed | GCC + Clang compile/tests exit `0`; limits *"Focused executable only; GCC 12.3 / Clang 19 differ from native toolchain pins"* |
| `focused_coverage` | completed | 36/36 lines = 100 %; 11/14 branches = 78.6 %; `complete_target_scope: false` |
| `focused_asan_lsan` | completed | focused identifier TU exit `0` |
| `focused_tsan` | findings_or_execution_failure | focused tests exit `66` (ThreadSanitizer environment failure) |
| `focused_memcheck` | completed | focused memcheck exit `0`; limit *"Optional complementary focused memory analysis"* |
| `format_precommit` | findings_or_execution_failure | one command exit `1`; `mod tidy`/lockfile exit `0`; limit *"Formatting/pre-commit mutations occur only in this disposable collector copy"* |
| `native_integration` | findings_or_execution_failure | `--config=qemu-integration` exit `1` |
| `native_docs` / `native_traceability` / `native_performance` | findings_or_execution_failure | exit `2`/`1`/failure respectively |
| `secret_dependency_checks` | findings_or_execution_failure | secret/dependency scan incomplete |
| `process_checks` | completed_with_blockers | *"Lexical metadata inventory cannot prove semantic requirement coverage"*, *"Safety/QM applicability and approved tailoring unknown"*, *"Independent inspection and acceptance required"*, *"External AoU and full integration verification require scoped review"* |
| `tool_assurance` | completed_with_blockers | *"Tool confidence evaluation, qualification where applicable, and acceptance require authorized humans"*, *"Coverity not installed/adopted here"*, *"Memcheck is an optional complement"* |
| `rework_progress` | completed | source changed this round |

**Retention ≠ passing.** The completed native legs above ran against a **captured source snapshot** in
the collector's `native-workspace`; their `source_hashes` include the candidate files, but the
platform's `native_acceptance` is `not_inferred` and the runs are local and unprotected.

### 1.6 Pinned obligation sources

All nine `.llm_tmp/context/obligations/source-index.json` entries were read with `authority.json`.
`coding_guidelines` (`:status: valid`; MISRA C++:2023 with C++17, `coding_guidelines.rst:20,30-36,74`),
`code_analysis` (`:status: valid`; clang-tidy + compiler warnings + Coverity, `code_analysis.rst:20,34-72`),
`verification_plan`, `development_plan`, `tool_management`, `verification_process`,
`verification_guideline` are `:status: valid`; **`misra_mapping` and `inspection_checklist` are
`:status: draft`** (`misra_mapping.rst:20`; rule table commented out `:26-31`). Every entry marks
`"native_acceptance": "not_inferred"`. `authority.json`: `engineering_acceptance: pending`,
`human_reviews: unanswered`, `safety_class: unknown`, `codeql_scope: "Public Apache-2.0
eclipse-score/inc_someip_gateway; no upload"`.

---

## 2. The recorded syntax failure: inspection of the actual source

### 2.1 Finding (direct `read_file` + `grep` this iteration)

`score/socom/impl/service_identifier.hpp` is 40 lines and **brace-balanced**:

| Line | Content | Role |
|------|---------|------|
| 14–15 | `#ifndef SRC_SOCOM_SRC_SERVICE_IDENTIFIER` / `#define …` | include guard |
| 17 | `#include "score/socom/service_interface_identifier.hpp"` | include |
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 21–28 | doc comment | states `minor` is intentionally not part of the identity |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 30–31 | `Service_interface_identifier interface;` / `Service_instance instance;` | members |
| 32 | `};` | closes the struct |
| 34–36 | `/// \cond` / operator declaration / `/// \endcond` | single out-of-line declaration |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`) and two closers (`:32`, `:38`): net brace balance `0`. There is **no
third, unmatched closing brace**, and line `:39` contains no text. The sibling
`impl/service_identifier.cpp` uses the same nested form (`:18`/`:32`) and is balanced.

### 2.2 Measured corroboration this iteration

The host validation **measured** this unit: `after-compile.command.json` compiles
`score/socom/impl/service_identifier.cpp` + `score/socom/impl/string_registry.cpp` +
`score/socom/test/unit/service_identifier_tests.cpp` (the test file includes
`score/socom/impl/service_identifier.hpp` at `:26`) through `g++-12 -std=c++17 -Wall -Wextra -Werror
-fsanitize=undefined` and **exits 0**, with empty `after-compile.stderr`. A surviving unmatched `}`
would fail that compile. Both the focused GCC and Clang legs of `compiler_diagnostics` exit `0`
(`:1238`, `:1274`) and `compiler_diagnostics` is `completed` (`:1299`). `glob
**/service_identifier*` resolves exactly one header, so there is no differently-braced copy.

### 2.3 Disposition

The described defect is a **stale, pre-correction description** matching the earliest prior reports
(which quote the old split-form `}  // namespace socom` + `}  // namespace score`). The `reproducer`
iteration applied the correction; every later report and the actual source read here show the nested,
balanced form. Applying the historical repair

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

to the already-balanced file would be a no-op at best and a compilation break at worst. Because the
write boundary permits only this report, no source edit was made. If the "cancelled draft" is a
distinct revision that still carries the brace, it is **not** the file in this checkout and must be
located and corrected by an authorized iteration.

---

## 3. Native analyzer configuration review (repository-side)

### 3.1 clang-tidy

| Aspect | Value | Source |
|--------|-------|--------|
| Config | `//:.clang-tidy`; `Checks: >` folded block scalar with `#` comments inside (`:16-162`) | repo root |
| Wiring | `lint_clang_tidy_aspect(binary=@llvm_toolchain//:clang-tidy, configs=[//:.clang-tidy], header_filter="^(?!(third_party|external)/).*$", angle_includes_are_system=True)` | `tools/lint/linters.bzl:39-47` |
| Bazel flags | `--aspects=//tools/lint:linters.bzl%clang_tidy`, `--extra_toolchains=@llvm_toolchain//:cc-toolchain-x86_64-linux`, `--@aspect_rules_lint//lint:fail_on_violation=true`, `--keep_going` | `static_analysis.bazelrc:20-24` |
| Entry points | `bazel run //:clang-tidy.check` / `//:clang-tidy.fix` via `use_clang_tidy_targets()` | `BUILD:118` |
| CI | `static-code-analysis.yml:23` runs `//:clang-tidy.check` | `.github/workflows` |

**Observed outcome (retained artifacts this iteration).**
- `focused_clang_tidy`: `clang-tidy --verify-config` (clang-tidy 19.1.7) **exits 1**
  (`result.json:1077`), and the blocker is *"Native analyzer configuration incompatible; no
  replacement called MISRA"* (`:1052-1055`). The config still contains the identifiers that caused
  the verification failure in the prior draft: `clang-analyzer-alpha.security.ArrayBoundV2`
  (`.clang-tidy:85`) and `modernize-use-integer-sign-comparison` / its `.IncludeStyle` option
  (`.clang-tidy:112,223`). Because `--verify-config` fails, the run performed **no translation-unit
  analysis** and produced **zero** clang-tidy findings on the changed units — *"not run"*.
- `native_lint`: the real `//:clang-tidy.check` leg **timed out** (exit `124`, reason *"Command timed
  out; owned process group stopped"*, `result.json:1077-1079`); the `//:ruff.check` leg exits `0`.
  Therefore clang-tidy produced **no findings** through the native path either.
- Cause (unchanged from the prior draft): YAML does not treat `#` inside a folded block scalar as a
  comment, so each comment folds into the check string and corrupts the adjacent check name. Fixing
  `.clang-tidy` is **outside the six candidate paths** and outside this review's write boundary; it
  needs an authorized change and an accepted clang-tidy version.

### 3.2 Compiler warnings (criterion 9)

- `common --features=-treat_warnings_as_errors` (`.bazelrc:117`) means the **default** build/test is
  not warnings-as-errors. `verification_plan.rst:332-335` (criterion 9) requires freedom from compiler
  warnings & errors at **100 %**; that needs an explicit
  `--features=treat_warnings_as_errors` invocation, which the retained native legs do not contain.
- Warnings-as-errors evidence that **was** measured: the focused GCC and Clang builds both exit `0`
  under `-Wall -Wextra -Werror` (`compiler_diagnostics:1238,1274`; `validation/after-compile.command.json`
  exit 0). This is a **focused translation unit**, not a full-target criterion-9 measurement. The
  retained `compiler_diagnostics` limits note *"Focused executable only; GCC 12.3 / Clang 19 differ
  from native toolchain pins"* (`:1301-1304`).

### 3.3 CodeQL (security + MISRA)

| Aspect | Value | Source |
|--------|-------|--------|
| Repo CI wiring | **none** — CI runs only `//:clang-tidy.check` + `//:ruff.check`; no CodeQL workflow exists | `.github/workflows/static-code-analysis.yml:23` |
| Collector CodeQL | `codeql 2.21.4` (`/home/jefferson/.local/share/s-core-tools/codeql-2.21.4`) | `codeql_security/result.json:1057` |
| Coding-standards pack | `codeql-coding-standards-2.61.0`, `misra-cpp-default.qls` | `codeql_misra/result.json:1094` |
| Query suites | security `codeql/cpp-queries@1.4.1:…cpp-security-and-quality.qls`; MISRA `misra-cpp-default.qls` | `codeql_security/result.json:1090`; `codeql_misra/result.json:1094` |
| Database build | `codeql database create --language=cpp --command=…/codeql-build.sh` (focused) | `codeql_security/result.json:1055-1066` |
| Extraction limit | *"Focused linked executable, not full target extraction; dependency findings retained"* | `codeql_security/result.json:1756-1758`; `codeql_misra` same |
| MISRA blockers | *"MISRA applicability/mapping draft and incomplete"*, *"Default suite omits manual/audit obligations"*, *"Compiled query qualification and human deviations pending"* | `codeql_misra/result.json:1052-1056` |

**Where findings point (this iteration).**
- `codeql_security`: every finding `uri` is under `.llm_tmp/googletest/...`; no finding targets
  `service_identifier.cpp` / `.hpp` (which appear only in `source_hashes` at `:126-127`). Findings are
  dependency-only; the run is a focused extraction.
- `codeql_misra`: rule ids observed are `cpp/misra/copy-and-move-assignments-shall-handle-self-assignment`
  (in `.llm_tmp/googletest/googletest/include/gtest/internal/gtest-filepath.h`) and
  `cpp/misra/external-linkage-not-declared-in-header-file-misra` on many `TEST_F` lines of
  `score/socom/test/unit/service_identifier_tests.cpp` (e.g. `:2181`, `:2150`, `:2103`, …). The
  latter is a **gtest macro-expansion artifact**, not an authored-body defect; it is not fixable in
  the test body.

Because the mapping is a draft and the extraction is focused/dependency-heavy, **no MISRA-compliance
statement is possible in either direction**.

### 3.4 cppcheck

- Collector-only; no repository cppcheck config or CI job.
- Invocation: `/usr/bin/cppcheck --std=c++17 --enable=warning,style,performance,portability --xml
  --xml-version=2 --error-exitcode=2 -I. score/socom/impl/service_identifier.cpp
  score/socom/impl/string_registry.cpp` → **exit 2** (`focused_cppcheck/result.json:1053-1082`).
- The retained limit is explicit: *"Optional complementary checks; no inferred MISRA rule coverage"*
  (`:1086-1088`). Findings (per prior `tool_findings_repair.md`) are `passedByValue` performance
  notes located in included headers outside the candidate paths; they are not candidate defects.

### 3.5 Sanitizers / TSan / memcheck

| Check | Scope | Result (retained) |
|-------|-------|-------------------|
| `focused_asan_lsan` | focused identifier TU | exit `0` |
| `native_sanitizers` | `bazel test //score/... //tests/... --features=asan,lsan,ubsan_clang` | **exit 0** |
| `native_tsan` | `bazel test //score/... //tests/... --features=tsan` | **exit 0** |
| `focused_tsan` | focused identifier TU | **exit 66** — *"FATAL: ThreadSanitizer: unexpected memory mapping"* environment failure |
| `focused_memcheck` | focused identifier TU | **exit 0** now (valgrind present) |

The CI equivalents are wired in `.github/workflows/build_and_test_host.yml:30-35` (ASan/LSan/UBSan and
TSan matrices). The native sanitizer/TSan legs **completed here**; the focused TSan leg still fails
for an environment/kernel reason, which is recorded as a blocker, not a pass.

### 3.6 Coverage

- Canonical config: `coverage --config=llvm_cov` (repo `coverage.bazelrc`; CI `.github/workflows/coverage.yml`).
- `native_coverage`: `bazel coverage //... --build_tests_only` **exit 0** under
  `COVERAGE_THRESHOLD=73`, limit *"Repository CI threshold 73 is not platform 85/100 line-and-branch
  acceptance"*.
- `focused_coverage` (gcc `--coverage`, `gcov-12`/`gcovr`) over `service_identifier.cpp` +
  `string_registry.cpp`: **36/36 lines = 100 %**, **11/14 branches = 78.6 %**,
  `complete_target_scope: false`, `safety_class: "unknown_requires_authorized_selection"`. Platform
  goals are **QM 85 % / safety 100 %** (`verification_plan.rst:300-307`), so the focused branch figure
  is below the QM goal as well; the CI threshold 73 is **not** platform acceptance.

### 3.7 Format / pre-commit / integration / docs / traceability / performance

- `format_precommit`: one command exits `1`, `mod tidy`/lockfile exit `0`; limit *"Formatting/pre-commit
  mutations occur only in this disposable collector copy"*.
- `native_integration`: `bazel test --config=qemu-integration //quality/... //tests/integration_test/...`
  exit `1`.
- `native_docs`, `native_traceability`, `native_performance`: `findings_or_execution_failure` (exit
  `2`/`1`/failure).
- `secret_dependency_checks`: `findings_or_execution_failure`.
- `process_checks` / `tool_assurance`: `completed_with_blockers` (see §1.5).

### 3.8 CI wiring versus collector-only analyzers (summary)

| Analyzer | In repo CI? | Wired where | Collector check |
|----------|-------------|-------------|-----------------|
| clang-tidy | yes | `static-code-analysis.yml:23` → `//:clang-tidy.check` → aspect | `focused_clang_tidy` (**verify-config fails**), `native_lint` (**timeout**) |
| ruff | yes | `static-code-analysis.yml:23` → `//:ruff.check` | — |
| compiler warnings-as-errors | **no** (default off, `.bazelrc:117`) | explicit feature only | `compiler_diagnostics` (focused, `-Werror`, exit 0) |
| ASan/LSan/UBSan, TSan | yes | `build_and_test_host.yml:30-35` | `focused_*`, `native_sanitizers` (0), `native_tsan` (0) |
| coverage (LLVM) | yes | `coverage.bazelrc`; `coverage.yml` | `focused_coverage`, `native_coverage` (exit 0, threshold 73) |
| CodeQL (security/MISRA) | **no** | collector-only | `codeql_security` (googletest-only), `codeql_misra` (draft/artifact) |
| cppcheck | **no** | collector-only | `focused_cppcheck` (exit 2, no MISRA inference) |
| valgrind/memcheck | **no** | collector-only | `focused_memcheck` (exit 0, optional) |
| format/pre-commit/reuse | no (collector) | collector-only | `format_precommit` |
| cross compile | yes (host) | `build_and_test_cross_compilation.yml` | `cross_compilation` (x86/arm 0, QNX blocker) |

Two of the analyzers named by `code_analysis.rst` (CodeQL and Coverity) are **not** in the repository
CI; CodeQL is collector-only, and Coverity is not installed/adopted (`tool_assurance` blocker).

---

## 4. Changed units and their analyzer exposure

### 4.1 Source

- **`score/socom/impl/service_identifier.hpp`** — `Service_instance_identifier{interface, instance}`
  (`:29-32`), out-of-line `operator<` declaration (`:35`, `\cond`-hidden), no `operator==`/`std::hash`.
  Brace-balanced (§2). Compiled into `//score/socom:socom` via
  `srcs = glob(["impl/**/*.cpp", "impl/**/*.hpp"])` (`score/socom/BUILD:24-41`) and re-exposed
  `testonly` via `//score/socom:impl_service_identifier` (`:46-54`).
- **`score/socom/impl/service_identifier.cpp`** — the only operator is
  `operator<(Service_instance_identifier const&, Service_instance_identifier const&)` (`:20-30`),
  ordering by `std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major)`. Identity is
  `(instance, service id, major)`; `minor` is excluded, matching the minor-ignoring `Service_database`
  index (`impl/runtime_impl.hpp:116-134`). This is the unit the focused analyzers actually saw.
- **`score/socom/BUILD`**, **`score/socom/test/unit/BUILD`** — target wiring (library + `testonly`
  header exposure + `socom_test` glob/deps). No analyzer finding targets the BUILD files.

### 4.2 Tests

- **`score/socom/test/unit/service_identifier_tests.cpp`** — new file (baseline blob `null`); **91
  `TEST_F`** under `ServiceInstanceIdentifierTest` (`:168`…`:2181`, re-counted this iteration by
  `grep`). Metadata in `SetUp()` (`:42-65`): `DerivationTechnique = "boundary-values,equivalence-classes"`
  and a `Description`; `TestType` and `Verifies`/`PartiallyVerifies`/`FullyVerifies` are deliberately
  unset because no verified native requirement/interface identifier exists (no invented links).
- **`score/socom/test/unit/runtime_tests.cpp`** — **1 `TEST`** (`:239`) + **31 `TEST_F`**
  (`:279`…`:1253`) + **1 `TEST_P`** (`:1311`), re-counted this iteration. The focused minor-only
  duplicate regression is `ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError`
  (`:402-431`); the metadata helper is at `:264-267`.

### 4.3 Analyzer findings that touch the changed units

| Tool | Finding | On a changed unit? | Assessment |
|------|---------|--------------------|------------|
| GCC (focused, `-Werror`, UBSan) | compile + 91 tests exit 0 | yes (clean, focused) | red→green measured; not full native |
| Clang (focused, `-Werror`) | compile + tests exit 0 | yes (clean, focused) | GCC 12.3 / Clang 19 differ from native pins |
| clang-tidy | none produced (`--verify-config` exit 1; native leg timed out) | n/a | **not run**; config/version gap (§3.1) |
| cppcheck | `passedByValue` performance notes | no (headers outside six paths) | no inferred MISRA coverage |
| CodeQL security | all `uri` under `.llm_tmp/googletest/...` | no | dependency-only; focused extraction |
| CodeQL MISRA | `external-linkage-…` on `service_identifier_tests.cpp` `TEST_F` lines; `copy-and-move-…-self-assignment` in a vendored gtest header | macro artifact / dependency | needs human deviation or macro-aware tooling |
| ASan/LSan/UBSan | native + focused exit 0 | yes (focus + native) | — |
| TSan | native exit 0; focused exit 66 | yes (native) | focused env failure recorded |
| coverage | focused 100 % line / 78.6 % branch; native threshold 73 | partially | below QM/safety branch goal; focused scope only |

No analyzer finding points into `service_identifier.cpp` or `service_identifier.hpp`, and none points
into the authored bodies of the key tests; the only in-scope-looking MISRA hits are the gtest macro
expansion.

---

## 5. Native analyzer execution plan (partially executed; clang-tidy still pending)

The repository-pinned invocations (from `bazel_plan.md` §4 and the retained `native_*` commands).
The sanitizer, coverage, build, test and cross legs **were executed here** (exit `0`, §3.5–§3.7). The
clang-tidy leg is still **not producing findings** and must be repaired before it can be trusted.

```bash
# analyzer / lint (native_lint): clang-tidy.check TIMED OUT (124) here; ruff.check exit 0
bazel --batch --output_user_root=<run>/bazel-cache run --jobs=2 //:clang-tidy.check
bazel --batch --output_user_root=<run>/bazel-cache run --jobs=2 //:ruff.check

# criterion 9 evidence (default disables warnings-as-errors: .bazelrc:117) - NOT YET RUN
bazel --batch --output_user_root=<run>/bazel-cache build --jobs=2 \
    --features=treat_warnings_as_errors //score/socom/...

# sanitizers / TSAN - ran here, exit 0
bazel --batch --output_user_root=<run>/bazel-cache test --jobs=2 //score/... //tests/... \
    --build_tests_only --features=asan --features=lsan --features=ubsan_clang
bazel --batch --output_user_root=<run>/bazel-cache test --jobs=2 //score/... //tests/... \
    --build_tests_only --features=tsan

# coverage - ran here, exit 0 (threshold 73 is not platform acceptance)
bazel --batch --output_user_root=<run>/bazel-cache coverage --jobs=2 //... --build_tests_only
```

Before a real clang-tidy run can be trusted, `.clang-tidy` must be repaired (unfold the `Checks:`
block; re-evaluate the two check identifiers absent from clang-tidy 19.1.7) by an **authorized**
change — this review may not edit it for the same reason it may not edit the candidate sources. The
criterion-9 warnings-as-errors build has **not** been run.

---

## 6. Tool / version / applicability gaps (no MISRA-compliance claim)

| # | Gap | Evidence | Effect on this slice |
|---|-----|----------|----------------------|
| G1 | Repo `.clang-tidy` `Checks: >` folds `#` comments into check names | `focused_clang_tidy/result.json:1052-1055`; `.clang-tidy:16-162` | clang-tidy verifies as invalid; **zero** clang-tidy findings on the changed units |
| G2 | Two check identifiers absent from clang-tidy 19.1.7 (`clang-analyzer-alpha.security.ArrayBoundV2`; `modernize-use-integer-sign-comparison`/`.IncludeStyle`) | `.clang-tidy:85,112,223` | config/tool-version drift; needs authorized fix |
| G3 | Native `//:clang-tidy.check` timed out | `native_lint/result.json:1077-1079` (exit 124) | native static-analysis leg produced no findings |
| G4 | Warnings-as-errors disabled by default | `.bazelrc:117` | criterion 9 not evidenced by default builds |
| G5 | CodeQL not wired in repo CI | `static-code-analysis.yml:23`; no CodeQL workflow | repo static-analysis coverage differs from the collector's |
| G6 | CodeQL extraction is focused, not full-target | `codeql_*/result.json` limit *"Focused linked executable, not full target extraction"* | findings incomplete; dependencies retained |
| G7 | MISRA mapping is `:status: draft`, rule table commented out | `misra_mapping.rst:20,26-31` | **no MISRA C++:2023 compliance can be claimed** |
| G8 | MISRA applicability/qualification pending; manual/audit suite omitted | `codeql_misra/result.json:1052-1056` | needs human deviation/qualification |
| G9 | CodeQL MISRA `external-linkage…` hits are gtest `TEST_F` macro artifacts | `codeql_misra/result.json` (many on `service_identifier_tests.cpp`, e.g. `:1165,2181`) | not fixable in the authored test body |
| G10 | cppcheck findings outside the six paths; no MISRA rule coverage inferred | `focused_cppcheck/result.json:1086-1088` | not a candidate defect; separate disposition |
| G11 | Focused TSan environment failure | `focused_tsan/result.json:1114,1119-1121` (exit 66) | focused concurrency check unmet (native TSan exit 0) |
| G12 | Coverity not installed/adopted (guideline vs plan discrepancy) | `tool_assurance/result.json:1052-1056` | `code_analysis.rst` tool set incomplete |
| G13 | Tool confidence/qualification requires authorized humans | `tool_assurance/result.json:1053` | `tool_management.rst` not established |
| G14 | Focused compiler legs differ from native toolchain pins (GCC 12.3 / Clang 19) | `compiler_diagnostics/result.json:1301-1304` | focused evidence is not native-pin evidence |
| G15 | Integration/QEMU leg fails; QNX SDK entitlement missing | `native_integration/result.json:1080`; `cross_compilation/result.json:1052-1054` | QNX target execution unmet |
| G16 | Docs/traceability/performance/secret legs failing-incomplete | `native_docs`, `native_traceability`, `native_performance`, `secret_dependency_checks` | those obligations not satisfied |
| G17 | Coverage threshold 73 is not platform 85/100 | `native_coverage/result.json:1117-1119`; `focused_coverage` 78.6 % branch | coverage goal not established |
| G18 | CodeQL scope is public Apache-2.0 repo, no upload | `authority.json` | local-only analysis; not a platform result |

**Explicit non-claim.** G6–G9, G13 and the draft mapping (G7) mean **MISRA C++:2023 compliance is
UNKNOWN and is not claimed**. The focused, dependency-heavy, incompletely extracted findings retained
here cannot support a compliance statement in either direction, and the unknown `safety_class` means
the applicable acceptance level (QM 85 % vs safety 100 %) is not selected. The passing native
build/test/sanitizer/TSan/coverage legs are **not** a MISRA result and **not** engineering acceptance.

---

## 7. Obligations status (none satisfied)

### 7.1 Pinned state

`authority.json`: `engineering_acceptance: pending`, `human_reviews: unanswered`,
`safety_class: unknown`, `codeql_scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway; no
upload"`. Every `source-index.json` entry: `native_acceptance: not_inferred`.

### 7.2 Per-obligation status for this slice

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Freedom from compiler warnings & errors (criterion 9, 100 %) | `verification_plan.rst:332-335` | **NOT MEASURED (native)** — focused GCC/Clang `-Werror` exit 0; `--features=treat_warnings_as_errors` full build not run |
| Static code analysis (clang-tidy / CodeQL), findings classified | `code_analysis.rst`; `verification_process.rst` (`gd_req__verification_sca_classification`) | **NOT SATISFIED** — clang-tidy config invalid + native timeout; cppcheck limited; CodeQL focused/dependency-only; MISRA draft; no critical/high closure classification |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` (draft) | **UNKNOWN — NOT CLAIMED** (G6–G9, G13) |
| Structural statement / branch coverage (criteria 1–2) | `verification_plan.rst:300-307` | **NOT MEASURED to goal** — native coverage exit 0 at threshold 73; focused 100 % line / 78.6 % branch, `complete_target_scope: false` |
| Unit/component testing executed and recorded (criteria 6–7) | `verification_plan.rst`; `verification_guideline.rst` | **PARTIAL** — focused identifier TU 91/91 (host measurement), `native_tests //...` exit 0; `full_native_tests: not_executed` and the platform acceptance is `not_inferred` |
| Sanitizer / concurrency checks | `code_analysis.rst`; `build_and_test_host.yml:30-35` | **PARTIAL** — native ASan/LSan/UBSan and TSan exit 0; focused TSan exit 66 |
| Interface / requirements-based / resource / fault-injection test types | `verification_process.rst` | **NOT PERFORMED / applicability not inferred** — no harness; identifier-only tests must not be labelled platform validation |
| Boundary / equivalence derivation | `verification_process.rst` | **MEASURED (focused)** — 91 key cases cover the boundary/equivalence matrix; native scope broader |
| Fuzzy testing technique | `verification_plan.rst` | **NOT EXECUTED / NOT CLAIMED** |
| Linking tests to requirements (record properties) | `verification_process.rst` (`gd_req__verification_link_tests_cpp`) | **PARTIAL** — `DerivationTechnique`/`Description` present; `TestType`/`Verifies` deliberately unset (no invented identifiers) |
| External-component AoUs verified | `verification_process.rst` (`gd_req__verification_external_aou`) | **NOT SATISFIED** — no integration/static verdict; no AoU register |
| Independence of verification / review by a different committer | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Implementation inspection checklist IMPL_01…IMPL_03 | `inspection_checklist.rst` (draft) | **NOT FILLED** |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** — see G1–G18 |
| Obligation collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **RETAINED, NOT PASSING** — 25 checks present; several blocked/failed |
| Native acceptance | `source-index.json` | **`not_inferred`** for every entry |

**Explicit non-satisfaction statement.** The invalid clang-tidy configuration, the focused/limited
CodeQL and cppcheck scope, the draft MISRA mapping, the unknown safety class and un-inferred
applicability, the QNX/integration/docs/traceability gaps, and the unanswered human reviews mean
**none of the checked obligations may be treated as satisfied**. A retained collection result shows
*retention*, not passing.

---

## 8. Measurement and validation status

- **Tools:** `read_file`, `grep`, `glob`, `write_file` only. No `shell`, delegation, web, approval,
  publishing, or engineering acceptance. **No measurement was executed by this iteration**; every
  number below is a reading of a retained artifact or a static source reading.
- **Executed by the host (retained):** focused GCC/Clang `-Werror` builds + tests (exit 0) and the
  UBSan red→green measurement (baseline 91/33 → candidate 91/0); `bazel build //...` (0),
  `bazel test //...` (0), native ASan/LSan/UBSan (0), native TSan (0), native coverage (0),
  x86_64/aarch64 cross builds (0). clang-tidy and CodeQL/cppcheck are blocked/limited as above.
- **Test inventory (read, not run here):** `service_identifier_tests.cpp` = **91 `TEST_F`**
  (`:168`…`:2181`); `runtime_tests.cpp` = **1 `TEST` + 31 `TEST_F` + 1 `TEST_P`** (`:239`…`:1311`).
- **Regression target (measured by the host, focused):**
  `RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError`
  (`runtime_tests.cpp:402-431`) and the key-level minor-collapse cases; the host measurement confirms
  the red→green transition on the key TU.
- **Scope:** local, unprotected, scoped. This draft has not been reviewed, accepted, published, or
  reproduced on a full native runtime with acceptance. Unit/integration execution and human review
  remain pending.
- **Source writes:** none. The recorded syntax failure is absent (§2) and the write boundary permits
  only this report.

---

## 9. Notice preservation

- No source, build, test, config, `NOTICE`, `LICENSE`, `REUSE.toml`, or prior-report file was created,
  edited, or deleted by this iteration; **only this report was written**. Every existing Apache-2.0 /
  SPDX notice header is untouched, and all 38 files under `.llm_tmp/overnight/prior-reports/` plus the
  20 earlier files under `.llm_tmp/overnight/reports/` were preserved.
- The header the task flagged (`score/socom/impl/service_identifier.hpp`) was inspected and left
  unchanged because it is already brace-balanced and otherwise well-formed (§2). The sibling
  `service_identifier.cpp`, both BUILD files, and both candidate test files retain their Apache-2.0 /
  SPDX headers (`:1-12`).
- This report itself carries the Apache-2.0 header. No licensed MISRA rule text is reproduced; only
  native rule/query identifiers, file locations, and retained-artifact readings are cited.
- Any future implementation in this slice must carry the Apache-2.0 header on new files, per
  `.github/instructions/code-style.md` and `REUSE.toml`.

---

## 10. Pending human review checklist

- [ ] **Confirm §2:** `service_identifier.hpp` is brace-balanced (braces at `:19`, `:29`, `:32`,
      `:38`; line 39 blank), the focused `-Werror` compile is measured exit 0, and the recorded
      *"extra closing brace at line 39"* is stale or refers to a different revision. If the
      "cancelled draft" is a distinct revision that still carries the brace, locate it and authorize
      its correction; no such file exists in this checkout.
- [ ] **Resolve the instruction conflict:** correct-the-source vs. review-draft-only-report; confirm
      that writing only this report was intended.
- [ ] **Repair `.clang-tidy` (G1/G2)** with an authorized change: unfold the `Checks: >` block so the
      `#` comments are not folded into check names, and re-evaluate
      `clang-analyzer-alpha.security.ArrayBoundV2` and `modernize-use-integer-sign-comparison` for the
      pinned clang-tidy version. Do **not** suppress checks inside this slice.
- [ ] **Re-run `//:clang-tidy.check`** (it timed out, G3) and record whether it now produces findings;
      do not report "clean" for a run that did not complete.
- [ ] **Decide whether criterion 9 uses the default build or the explicit
      `--features=treat_warnings_as_errors`** build (`.bazelrc:117` disables it by default).
- [ ] **Decide the CodeQL posture (G5–G9, G12, G13):** full-target extraction, MISRA mapping completion
      (the mapping is `:status: draft`), human qualification/deviation, and whether Coverity is adopted
      or the guideline/plan discrepancy is resolved. **No MISRA-compliance claim until then.**
- [ ] **Record a deviation (or macro-aware tooling) for the CodeQL MISRA `external-linkage` hits on
      `service_identifier_tests.cpp`** (gtest `TEST_F` expansion); do not patch the test framework or
      silently suppress the rule.
- [ ] **Disposition the cppcheck `passedByValue` findings** in the included headers outside the six
      paths — acceptable performance style or a separate change.
- [ ] **Close the QNX/integration/docs/traceability/performance/secret gaps (G15/G16)** and re-run
      `--config=qemu-integration`.
- [ ] **Re-map coverage** against the platform 85 %/100 % thresholds; do not report the collector's 73
      threshold as platform acceptance (G17).
- [ ] **Supply native requirement/interface identifiers** for traceability, or record applicability as
      unresolved (no invented links).
- [ ] **Schedule independent human review** (the approver must differ from the author, per
      `gd_req__verification_independence`) and select a safety class via the authorized role; do not
      infer the slice's class from the `:safety: ASIL_B` attribute on the pinned platform documents.
- [ ] **Keep the wider #84 public `Service_interface_identifier` restructure, FindService wildcard, and
      the config minor-wildcard narrowing out of this bounded slice** until separately accepted, and do
      not present the identifier-only tests as platform validation or claim an unmeasured fuzzy
      technique.

---

*End of native analyzer configuration & changed-unit review draft. Local, unprotected, scoped. No
engineering acceptance; human reviews unanswered; full native runtime tests pending. Every statement is
a local reading of the working tree, a retained-artifact reading, or an explicitly-labelled logical
consequence — none is acceptance, review approval, publication, or a full native run.*
