<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — duplicate construction while the first server connector is enabled (`runtime_enabled`)

**Document type:** review draft (actual-source inspection + enabled-server runtime-test verification record + premise reconciliation + obligations status).

**Date:** 2026-10-03
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version handling in socom* (issue #84)
**Run / branch:** `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ`; current HEAD `6395811`
(`fabro(01M3ZRSDK2XQAF1H48VWTPKQNZ): node_e1068dcef1948a0f0ba444d9 (success)`, `.git/logs/HEAD:9`).
Earlier nodes of this run: `b7d55bb` (start), `95fe5f9` (`node_51f7ccb6b2715b106cf242f4`),
`8e1610e` (`node_3752dc1af9e2f3b0ee1454f2`), `a31f5fc` (`node_edd8fcbae2fee64d3bbd0c31`),
`5722740` (`node_d2fdb79acfbec37dfb74066b`), `406474b` (`node_c732605366498064fa626567`),
`c77468a` (`node_a32bd61da26b7020f0cf537b`), `4c9e0b0` (`node_4950ecb53dec3bcb35ccbd4a`)
(`.git/logs/HEAD:1-9`).
**Verified baseline commit:** `f8a196c3b16d5172d898394ab99b0ed81346d63d`
(`.llm_tmp/context/source-manifest.json:3`).
**Status:** **local, unprotected, scoped.** No engineering acceptance exists. Human reviews are
unanswered. Full native runtime tests remain pending. Nothing in this document is acceptance,
review, publication, or a full native run.

> **Tool / write boundary observed.** This iteration used only `read_file`, `grep`, `glob`, and
> `write_file`. No `shell`, no `edit_file`, no delegation, no web access, no approval, no publishing,
> and no engineering acceptance was performed. The task permits changing only the six named candidate
> source paths and this report. Of those, **exactly one file was written — this report**
> (`/workspace/.llm_tmp/overnight/reports/runtime_enabled.md`). No source, build, test, config,
> `NOTICE`, `LICENSE`, or `REUSE.toml` file was created, edited, or deleted, and every prior report
> (including `.llm_tmp/overnight/prior-reports/runtime_enabled.md`) was preserved unchanged.
>
> **Premise reconciliation (inspect before editing).** The task records "a measured GCC syntax
> failure: an extra closing brace in `score/socom/impl/service_identifier.hpp` at line 39" and directs
> that the actual source be corrected before the tests are expanded. Direct inspection of the *actual*
> source this iteration (`read_file` + `grep`, §2) shows the header is **already brace-balanced**: the
> only brace-bearing lines are `:19` (`namespace score::socom {`), `:29`
> (`struct Service_instance_identifier final {`), `:32` (`};`), and `:38`
> (the single `}  // namespace score::socom`); line `:39` is **blank** and `:40` is `#endif`. Two
> openers and two closers give net brace balance `0`. A `glob` for `**/service_identifier.hpp` returns
> exactly one path, so there is no second, differently-braced copy. Independently, the host
> measurement present in this checkout compiled a translation unit that includes this header with
> `g++-12 -std=c++17 -Wall -Wextra -Werror`, compile exit `0` (§1.5, §2.2) — which is incompatible
> with a syntax error. Re-introducing or "removing" a brace that does not exist would break
> compilation; the smallest correction to already-correct source is **no change**. The recorded defect
> matches the earliest preserved prior reports, which quote the pre-correction split-form close; the
> `reproducer` iteration of this run already records the header as balanced.
>
> **The requested enabled-server tests are already present on disk.** `score/socom/test/unit/runtime_tests.cpp`
> already carries **seven focused enabled-server duplicate/refusal cases** and **three enabled-server
> equivalence-class counterparts** (§4), each comparing the returned value against the genuine error
> result `score::MakeUnexpected(Construction_error::duplicate_service)` rather than a bare boolean
> assertion. This iteration verified and mapped them rather than appending duplicates; duplicating an
> existing deterministic suite would add complexity without coverage.

---

## 0. Summary

1. **Recorded syntax failure — inspected; not present in the actual source, and refuted by the host measurement.** `score/socom/impl/service_identifier.hpp` has exactly two opening braces (`:19`, `:29`) and two closing braces (`:32`, `:38`), net balance `0`; `:39` is empty and `:40` is `#endif`. A `glob` returns a single copy of the header. The host focused compile, which includes this header, exited `0` under `-Werror` (§2). The described defect is the stale, pre-correction description recorded by the earliest prior reports; a `reproducer` iteration applied the single-close correction and it is present in this working tree.
2. **Registration-key correction — present and consistent.** `Service_instance_identifier::operator<` orders by `(instance, service id, major)` and deliberately excludes `minor` (`score/socom/impl/service_identifier.cpp:28-29`), agreeing with the minor-ignoring `Service_database` record index (`score/socom/impl/runtime_impl.hpp:116-134`) (§3). No change to the header or `.cpp` was required or made.
3. **Enabled-server duplicate runtime tests — present and verified.** `runtime_tests.cpp` carries seven enabled-server duplicate/refusal cases (E1–E7) and three enabled-server equivalence-class counterparts (C1–C3) (§4), including the minor boundaries (`0` vs `65535`), the descending minor order (`3` then `2`), the repeated refusal with the slot held while the incumbent stays enabled, the distinct-major counterpart, and the enabled erase/disable-after-destruction lifetime halves. Every duplicate expectation compares against the **genuine error result** `score::MakeUnexpected(Construction_error::duplicate_service)`; no bare `EXPECT_FALSE(has_value())` is used for the duplicate outcome anywhere in `score/socom/test/unit/` (§4.4). No new test was needed.
4. **Gate mechanism.** `Runtime_impl::make_server_connector` builds the key `Service_instance_identifier{configuration.get_interface(), instance}` (`runtime_impl.cpp:443`), inserts it into `m_service_identifiers` under a mutex (`:449-454`), and returns `Construction_error::duplicate_service` when the insert is a duplicate (`:451-453`). The key is erased only by the connector's destruction `Final_action` (`:456-463`), so **enabling a connector does not release the slot**; a second construction for the same `(instance, service id, major)` is still refused while the first connector is enabled. The header comment calls the key set "only used to check if any (Disabled, Enabled) Server_connector for the given interface and instance already exists" (`service_identifier.hpp:23-24`).
5. **Host measurement present but scoped.** `check-result` is `0` and `measurement.json` records `check_ref: check_unit_matrix`, `status: completed`, `mode: plain`, `changed_paths: []`, `origin: local_unprotected_measurement`, `initiator: Fabro host hook`, `engineering_acceptance: pending`, `full_native_tests: not_executed`, compiler `/usr/bin/x86_64-linux-gnu-g++-12`; candidate `{compile_exit:0, test_exit:0, tests:87, failures:0}`; `baseline_with_agent_tests {compile_exit:0, test_exit:1, tests:87, failures:30}`. The compile command names only `score/socom/impl/service_identifier.cpp`, `score/socom/impl/string_registry.cpp`, and `score/socom/test/unit/service_identifier_tests.cpp` (plus googletest sources); **`runtime_tests.cpp` is not compiled or executed by any host measurement here** (§1.5, §5). The 87/0 result therefore says nothing about the enabled-server runtime tests in §4.
6. **No obligation is treated as satisfied** (§6): `.llm_tmp/overnight/obligations/` is **absent from this checkout** (`glob` returns no entries, no `*/result.json`); every pinned `source-index.json` entry is `native_acceptance: not_inferred`; `authority.json` records `engineering_acceptance: pending`, `human_reviews: unanswered`, `safety_class: unknown`; and full native runtime tests remain unexecuted. A retained collection result would only show *retention*, not passing; here nothing is retained at all.

---

## 1. Binding to the verified baseline, prior reports, host feedback, obligations

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` | `.llm_tmp/context/issue-snapshot.json:2-4` |
| Title | *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:3` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` (unchanged) | `.llm_tmp/context/issue-snapshot.json:19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**: service-instance identifier = `service id + major + minor + instance id`; service
identifier = `service id + major`; FindService = `service id + major + optional<minor> +
optional<instance>`; and the proposal to "exclude the minor version and make it a property of the
service instance". The FindService `major = FF` AUTOSAR case is called theoretically possible but not
useful. There is **no comment and no acceptance record** in the snapshot, so none of it is binding.

### 1.2 Verified baseline and current tree

| Item | Value | Source |
|------|-------|--------|
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |
| Current branch | `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ` | environment |
| Current HEAD | `6395811` — `node_e1068dcef1948a0f0ba444d9 (success)` | `.git/logs/HEAD:9` |

Binding is **by baseline commit**, not by run HEAD. Earlier reports reference other run IDs on the same
baseline commit (`01M3YRJEGXNY6CB81T7TKW774B`, `01M3YGTGYFEN406VDEVVTJTRWV`,
`01M3XZAQ65TTE35XSGXC4JAMAH`, `01M3XT7NQ04S4MTFRMTT2401XK`, `01M3WX09X84XFM5X08QY2944DF`, and
before them `01M3WSTF1DAJA248NQ5QQGQG52`/`a282596` and `01M3WWRQWT262FTYS52X80YPTP`/`e12e7cb`), so
all of them describe the same baseline and remain admissible as prior evidence for this run's slice.
No hashing tool is available in this task, so the current working tree was **not** re-hashed; the
direct source reads in §2–§4 are authoritative for this report.

### 1.3 In-scope candidate files (the only writable source paths)

From `.llm_tmp/context/candidate-files.json:1-25` (baseline blobs cross-checked against the `files`
array of `.llm_tmp/context/source-manifest.json`):

| File (repo-relative) | Baseline git blob | Baseline present | This iteration |
|----------------------|-------------------|------------------|----------------|
| `score/socom/BUILD` | `3477ea0851fdcd82ec6ea9d71424013cbdf41962` | yes | inspected, **unchanged** (`testonly impl_service_identifier` at `:46-54`) |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e22355242009fe20dada2a9a0d0c7a9c7` | yes | inspected, **unchanged** (`minor` already excluded, `:28-29`) |
| `score/socom/impl/service_identifier.hpp` | `c8bae7908da9f087c518934f7b9f8d86db9a20ec` | yes | inspected, **unchanged** (already brace-balanced, §2) |
| `score/socom/test/unit/BUILD` | `3c03a7b14286051f97fa5022206564bd63645171` | yes | inspected, **unchanged** (`socom_test` globs `*.cpp`, deps wired, `:16-29`) |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab726db8bf994c960045d6fd7fdf84d7395` | yes | inspected, **unchanged** — enabled-server duplicate cases already present (§4) |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(none — `null`)* | no (manifest expects a **new** file) | inspected, **unchanged** (87-case key matrix, §5) |

The `null` baseline blob for `service_identifier_tests.cpp` is the manifest's expectation of a **new**
unit-test file; it exists on disk only as part of the un-merged working tree (the task's "cancelled
draft"), never in the baseline. `glob **/service_identifier*` returns exactly three paths —
`impl/service_identifier.cpp`, `impl/service_identifier.hpp`, and `test/unit/service_identifier_tests.cpp`
— so there is **no second, differently-braced copy** of the header in this checkout.

### 1.4 Prior reports read and preserved

- `.llm_tmp/overnight/prior-reports/` — 38 files present, all preserved; `runtime_enabled.md`,
  `runtime_disabled.md`, `reproducer.md`, `key_fix.md`, `unit_matrix.md`, `invariants.md`,
  `callsites.md`, `scope.md`, `ordering_tests.md`, `lifetime_tests.md`, `conversion_tests.md`,
  `test_metadata.md`, `coverage_review.md`, `coverage_tests_repair.md`, `misra_applicability.md`,
  `misra_manual_review.md`, `tool_findings_repair.md`, `finding_classification.md`,
  `design_inspection_draft.md`, `deviation_drafts.md`, `verification_report_draft.md`,
  `evidence_inventory.md`, `independent_review_handoff.md`, and `review_packet.md` were read; the
  remainder were cross-checked. The prior `runtime_enabled.md` (a per-run record of an earlier run on
  the same baseline) was read and is **not** overwritten.
- `.llm_tmp/overnight/reports/` — read, not modified: `scope.md`, `callsites.md`, `invariants.md`,
  `reproducer.md`, `key_fix.md`, `unit_matrix.md`, `runtime_disabled.md` (the earlier nodes of this
  run). This document adds `runtime_enabled.md`.

Derived sequence across the preserved reports: `scope.md` (bounded the slice) → `invariants.md`
(I-4 baseline key included `minor`; I-9 record index ignores `minor`; I-11 the resulting gap) →
`callsites.md` (call-site map) → `reproducer.md` (header brace correction + focused red regression) →
`key_fix.md`/`unit_matrix.md` (drop `minor` from the ordering; expand the key tests) →
`ordering_tests.md` → runtime drafts (`runtime_disabled.md` = both connectors disabled;
`runtime_enabled.md` = first connector enabled; `lifetime_tests.md` = slot reuse/isolation) →
`conversion_tests.md` → `test_metadata.md`.

**Reconciliation of the conflicting brace claims across prior reports.** The earliest prior reports
quote lines 38-39 as a split-form double close (`}  // namespace socom` + `}  // namespace score`) and
record the header as **broken**. `prior-reports/reproducer.md` records that it **applied the
correction**, and every later report records the header as **already balanced**. The actual source read
this iteration (§2) matches the **later** set.

### 1.5 Host validation feedback and obligation-collection results (present in this checkout)

- **Host feedback under `.llm_tmp/overnight/validation/`: PRESENT (16 files).**
  - `check-result` = `0`.
  - `measurement.json`: `check_ref: check_unit_matrix`; `status: completed`; `mode: plain`;
    `changed_paths: []`; `origin: local_unprotected_measurement`; `initiator: Fabro host hook`;
    `engineering_acceptance: pending`; `full_native_tests: not_executed`; compiler
    `/usr/bin/x86_64-linux-gnu-g++-12`; `baseline_with_agent_tests` =
    `{compile_exit:0, test_exit:1, tests:87, failures:30}`; `candidate` =
    `{compile_exit:0, test_exit:0, tests:87, failures:0}`.
  - `after.json` = 87 tests / 0 failures; `before.json` = 87 tests / 30 failures; all 87 belong to
    the single suite `ServiceInstanceIdentifierTest` (`after.json:9-18`).
  - `after-compile.command.json` (exit `0`): `g++-12 -std=c++17 -Wall -Wextra -Werror -pthread` over
    **only** `score/socom/impl/service_identifier.cpp`, `score/socom/impl/string_registry.cpp`,
    `score/socom/test/unit/service_identifier_tests.cpp`, plus the googletest sources.
    `after-compile.stderr` is empty.
  - **Scope of the measurement:** it compiles only the focused identifier translation unit.
    `runtime_tests.cpp` is **not** in the compile command and the `RuntimeTest` suite does **not**
    appear in the output. The 87/0 result therefore says nothing about the enabled-server runtime tests
    in §4, and it is a `local_unprotected_measurement` with `engineering_acceptance: pending` and
    `full_native_tests: not_executed` — never native acceptance.
  - The measurement's recorded `source_hashes` differ from the `sha256` values in
    `.llm_tmp/context/candidate-files.json` (consistent with in-run draft edits by earlier nodes); no
    local hash tool was available here to recompute either value.
- **Obligation-collection results under `.llm_tmp/overnight/obligations/`: ABSENT from this checkout.**
  `glob .llm_tmp/overnight/obligations/**` returns no entries and no `*/result.json`. **Per the task
  rule, a successful collection node means results were retained, not that checks passed; here nothing
  is retained at all, so no obligation may be treated as satisfied on that basis.**

### 1.6 Pinned obligation sources and authority (all read this iteration)

All nine entries of `.llm_tmp/context/obligations/source-index.json` are present in
`.llm_tmp/context/obligations/`, together with `authority.json`; every entry is marked
`"native_acceptance": "not_inferred"` — pinned, but its applicability to this slice is **not
inferred**:

| id | pinned file (from `source-index.json`) | status note |
|----|----------------------------------------|-------------|
| `coding_guidelines` | `docs/contribute/development/cpp/coding_guidelines.rst` | `:status: valid`; MISRA C++:2023 with C++17 |
| `code_analysis` | `docs/contribute/development/cpp/code_analysis.rst` | `:status: valid`; clang-tidy + gcc/clang warnings + Coverity; sanitizers |
| `misra_mapping` | `docs/contribute/development/cpp/misra_2023_rule_mapping.rst` | **`:status: draft`**; rule table not a valid obligation |
| `verification_plan` | `docs/platform_management_plan/software_verification.rst` | `:status: valid`; quality criteria incl. criterion 9 "Freedom from compiler warnings & errors, 100 %" (`:332-335`) |
| `development_plan` | `docs/platform_management_plan/software_development.rst` | `:status: valid`; C++17, GCC host compiler, QCC target, Bazel |
| `tool_management` | `docs/platform_management_plan/tool_management.rst` | `:status: valid`; tools identified / evaluated / qualified / released-or-rejected by a human |
| `verification_process` | `process/process_areas/verification/guidance/verification_process_reqs.rst` | `:status: valid`; `gd_req__verification_link_tests_cpp` (`:56-75`), `_independence`, `_checks_extended`, `_external_aou`, `_sca_classification` |
| `verification_guideline` | `process/process_areas/verification/guidance/verification_guideline.rst` | `:status: valid`; traceability, independence, documented results |
| `inspection_checklist` | `score/component_example/docs/detailed_design/chklst_impl_inspection.rst` | **`:status: draft`**; blank `IMPL_01_01`…`IMPL_03_02` template |

**Authority record** (`.llm_tmp/context/obligations/authority.json:1-7`):
`engineering_acceptance: pending`; `human_reviews: unanswered`; `safety_class: unknown`;
`codeql_scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload"`; instruction
*"Restart the failed queue for one complete pass through all obligations"*.

**Safety-class note (recorded, not resolved).** The pinned platform documents carry `:safety: ASIL_B`
(e.g. `verification_plan.rst:19`, `coding_guidelines.rst`, `code_analysis.rst`,
`development_plan.rst`, `tool_management.rst`, `misra_mapping.rst`, `inspection_checklist.rst`), while
`authority.json` records `safety_class: unknown` and no authorized selection exists. The document
attribute is **not** a selection of the slice's safety class and must not be inferred as one.

---

## 2. The recorded syntax failure: inspection of the actual source

### 2.1 Finding (re-verified this iteration by direct `read_file` + `grep`)

`score/socom/impl/service_identifier.hpp` is **brace-balanced**. It is 40 lines; a `grep` for
brace-bearing lines returns exactly four matches:

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`) and two closers (`:32`, `:38`) give net brace balance `0`; **there is no
third, unmatched closing brace**, and line 39 contains no text at all. A `glob` for
`**/service_identifier.hpp` returns exactly one path (`score/socom/impl/service_identifier.hpp`), so
there is no second, differently-braced copy in the tree. The described defect is therefore the
**stale, pre-correction** description of the earliest prior reports, not the file that is compiled.

The sibling `score/socom/impl/service_identifier.cpp` uses the same nested form (`:18` / `:32`) and is
balanced.

### 2.2 Independent measured refutation (host artifact present in this checkout)

The host "after" compile (`.llm_tmp/overnight/validation/after-compile.command.json`, exit `0`) passed
`score/socom/impl/service_identifier.cpp` and `score/socom/test/unit/service_identifier_tests.cpp` to
`g++-12 -std=c++17 -Wall -Wextra -Werror`; `after-compile.stderr` is empty. Both sources include this
header (`service_identifier.cpp:14` includes `"service_identifier.hpp"`; the key tests include
`score/socom/impl/service_identifier.hpp` at `service_identifier_tests.cpp:26` and construct
`Service_instance_identifier`). A C++ source that includes a header with an extra closing brace cannot
compile under `-Werror`, so the recorded "measured GCC syntax failure" does **not** describe this
snapshot. This is nonetheless a *focused-translation-unit* compile, not a Bazel build of
`//score/socom:socom` (§5).

### 2.3 Correction status

**No correction was applied, and none is required.** The minimal repair — matching the sibling `.cpp`
— would be, **only if the split-form imbalance ever reappeared**:

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

Applying this to the already-balanced file would be a no-op; re-introducing a broken brace merely to
"fix" it would be a regression. No production source was edited.

### 2.4 Why the brace (and its absence) matters

The header is compiled into `//score/socom:socom` (its `srcs` globs `impl/**/*.cpp` and
`impl/**/*.hpp`, `score/socom/BUILD:24-41`) and re-exposed to `//score/socom/test/unit` through the
`testonly` `impl_service_identifier` library (`score/socom/BUILD:46-54`;
`score/socom/test/unit/BUILD:24`). A syntax error here would fail both the library and the whole
`socom_test` target, contradicting S-CORE quality criterion 9, "Freedom from compiler warnings &
errors, 100 %" (`verification_plan.rst:332-335`). The currently balanced state removes that blocker
**at the source level and in the focused host compile**; it is **not** a Bazel build measurement (§5).

---

## 3. Key semantics under test

The duplicate-server registration key is
`Service_instance_identifier { Service_interface_identifier interface; Service_instance instance; }`
(`score/socom/impl/service_identifier.hpp:29-32`). Its only operator is the out-of-line `operator<`
(`:35`), defined as (`score/socom/impl/service_identifier.cpp:28-29`):

```cpp
return std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major) <
       std::tie(rhs.instance, rhs.interface.id, rhs.interface.version.major);
```

Therefore:

- identity (`std::set` equivalence `!(a<b) && !(b<a)`) = **`(instance, service id, major)`**;
- **`minor` is excluded** — it selects a compatible instance and is enforced separately by
  `is_interface_compatible`, not treated as identity;
- the key agrees with the deliberately minor-ignoring `Service_database` record index
  (`runtime_impl.hpp:116-134`: `Minor_version_ignoring_key_equal` / `Minor_version_ignoring_hash`);
- `Service_instance_identifier` declares no `operator==` and no `std::hash`; the only identity notion
  is `std::set` equivalence.

The gate is applied at construction, before any connector is created, in
`Runtime_impl::make_server_connector` (`score/socom/impl/runtime_impl.cpp:440-467`): the key is built
at `:443`, inserted into `m_service_identifiers` under its own mutex at `:449-454`, and a collision
returns `Construction_error::duplicate_service` at `:451-453`. The key is erased only when the
connector is destroyed, by the `Final_action` installed at `:456-463`. **Enabling a connector does not
erase the key** — the header comment calls the key set "only used to check if any (Disabled, Enabled)
Server_connector for the given interface and instance already exists"
(`service_identifier.hpp:23-24`). Consequently, while the first connector is enabled, a second
construction for the same `(instance, service id, major)` is still refused at construction. This is
the property the enabled-server tests pin.

`Runtime::make_server_connector()` returns `Result<Disabled_server_connector::Uptr>`
(`runtime.hpp`); a server instance is represented by a server connector, and an *enabled* server
instance is the connector returned by `Disabled_server_connector::enable(std::move(disabled))`
(`server_connector.hpp:116-118`). "A duplicate involving an enabled server" is therefore realised as:
construct the first connector, **enable it**, then attempt the second `make_server_connector()` for the
same key.

---

## 4. Enabled-server runtime tests

### 4.1 How "the first server is enabled" is realised (present tests)

Each enabled case constructs the first connector through the public `Runtime::make_server_connector()`,
asserts the result has a value, converts it with
`Disabled_server_connector::enable(std::move(...))`, asserts the enabled pointer is non-null, and then
attempts the second `make_server_connector()` for the colliding key. Because the duplicate is refused
at the registration-key gate *before any connector is created*, the single-server
`SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)` path in `Service_record::register_server_connector()`
(`runtime_impl.cpp:369`) is never reached.

### 4.2 Duplicate/refusal cases with the first connector enabled (present)

All in the candidate path `score/socom/test/unit/runtime_tests.cpp` (Apache-2.0 header preserved,
`:1-12`).

| # | Test (lines) | Scenario (first enabled) | Expected (source-derived) |
|---|--------------|--------------------------|---------------------------|
| E1 | `ConstructDuplicateWhileFirstConnectorEnabledReturnsDuplicateServiceError` (`:694-720`) | Identical configuration | First valid & enabled; second → genuine `duplicate_service` |
| E2 | `ConstructDuplicateDifferingOnlyInMinorVersionWhileFirstConnectorEnabledReturnsDuplicateServiceError` (`:726-758`) | Share `id + major + instance`; minor `2` vs `3` | First valid & enabled; second → `duplicate_service` |
| E3 | `ConstructDuplicateMinorBoundariesWhileFirstConnectorEnabledReturnsDuplicateServiceError` (`:832-864`) | Minor `0` vs `65535` (16-bit extremes) | First valid & enabled; second → `duplicate_service` |
| E4 | `ConstructDuplicateWithSmallerMinorWhileFirstConnectorEnabledReturnsDuplicateServiceError` (`:869-900`) | Minor `3` then `2` (descending) | First valid & enabled; second → `duplicate_service` |
| E5 | `ConstructDuplicateRepeatedlyWhileFirstConnectorEnabledKeepsSlotHeld` (`:905-945`) | Identical duplicates attempted twice; then a different instance | Second and third → `duplicate_service`; different instance valid & non-null |
| E6 | `ConstructDuplicateAfterEnabledConnectorDestroyedReturnsValidServerConnector` (`:986-1019`) | Enabled incumbent; duplicate refused; incumbent destroyed; recreate | Duplicate → `duplicate_service`; recreate valid & non-null |
| E7 | `ConstructDuplicateAfterEnabledConnectorDestroyedWithChangedMinorVersionReturnsValidServerConnector` (`:1091-1134`) | Enabled incumbent; changed-minor duplicate refused; incumbent destroyed; changed-minor recreate | Duplicate while enabled → `duplicate_service`; recreate valid & non-null |

### 4.3 Equivalence-class counterparts with the first connector enabled (present)

| # | Test (lines) | Scenario (first enabled) | Expected |
|---|--------------|--------------------------|----------|
| C1 | `ConstructDifferentInstanceWhileFirstConnectorEnabledReturnsDistinctServerConnectors` (`:763-790`) | Different instance | Both valid & non-null |
| C2 | `ConstructDifferentServiceIdWhileFirstConnectorEnabledReturnsDistinctServerConnectors` (`:796-826`) | Different service id | Both valid & non-null |
| C3 | `ConstructDifferentMajorWhileFirstConnectorEnabledReturnsDistinctServerConnectors` (`:951-981`) | Same `id + instance`, major `1` vs `2` | Both valid & non-null |

E1–E7 are the **duplicate** cases the task asks for: a second (or repeated) construction for the same
`(instance, service id, major)` is refused while the first connector is **enabled**. C1–C3 are the
equivalence-class counterparts showing the gate is not over-broad: a component that must stay
distinguishing (instance, service id, major) still does.

### 4.4 "Preserve genuine error results rather than assertions" — verified

Every duplicate expectation in the enabled cases compares the returned value against the **genuine
error result**, not a bare boolean:

```cpp
score::Result<Disabled_server_connector::Uptr> const duplicate_service =
    score::MakeUnexpected(Construction_error::duplicate_service);
EXPECT_EQ(duplicate_service, second);      // E1 (:717-719), E2 (:755-757), E3 (:861-863), E4 (:897-899)
EXPECT_EQ(duplicate_service, third);       // E5 (:927-938)
EXPECT_EQ(duplicate_service, duplicate);   // E6 (:1010-1012), E7 (:1110-1126)
```

The `MakeUnexpected(Construction_error::duplicate_service)` sites in the file are at `:346`, `:362`,
`:381`, `:429`, `:463`, `:600`, `:634`, `:662`, `:718`, `:756`, `:862`, `:898`, `:928`, `:1011`,
`:1065`, `:1111`, `:1158`, `:1211`, `:1270` (19 sites; `:280` is the unrelated `callback_missing`
expectation and `:689` is a comment). A `grep` for `EXPECT_FALSE`/`ASSERT_FALSE` across
`score/socom/test/unit/` returns **no** match, so no duplicate outcome is expressed as a bare boolean.

This matters because on the pre-correction key (minor included) the second construction would **not**
return an error at all: it would succeed, and enabling it would reach the single-server precondition
(`SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)`) — a genuine termination, not a returned error. The tests
therefore preserve the real error result instead of asserting a success the actual source would not
produce.

### 4.5 Related lifetime / slot-isolation cases (present, first connector enabled where noted)

The file additionally carries enabled-lifetime and slot-isolation cases that exercise the erase half
of the key contract: `ConstructDuplicateAfterEnabledConnectorDestroyedReturnsValidServerConnector`
(`:986-1019`), `ConstructDuplicateAfterEnabledConnectorDestroyedWithChangedMinorVersionReturnsValidServerConnector`
(`:1091-1134`), and the still-alive-slot isolation cases `DestroyingOneMajorSlotKeepsOtherMajorSlotOccupied`
(`:1141-1191`), `DestroyingOneInstanceSlotKeepsOtherInstanceSlotOccupied` (`:1197-1245`), and
`DestroyingOneServiceIdSlotKeepsOtherServiceIdSlotOccupied` (`:1253-1304`). The disabled-connector
counterparts (`:402-431`, `:440-465`, `:573-602`, `:607-636`, `:642-679`) and the factory-level
predecessors (`:334-348`, `:350-369`, `:371-390`) remain present and were recorded by the earlier
`runtime_disabled` report.

### 4.6 Why no new test was written this iteration

The enabled-server coverage above already spans every identity dimension the key can vary — identical
key, minor-only (ascending, descending, and the two 16-bit extremes), repeated refusal with the slot
held, distinct instance, distinct service id, and distinct major — plus the enabled erase-after-
destruction lifetime halves. Appending further cases would duplicate an existing deterministic suite
and add complexity without coverage, contrary to the surgical-change requirement. The requested tests
are therefore **verified and retained, not duplicated**. They are, however, **not compiled or
executed** by any measurement in this checkout (§5).

### 4.7 Build wiring (no BUILD change required)

- `score/socom/BUILD:46-54` defines the `testonly` `impl_service_identifier` library exposing
  `impl/service_identifier.hpp` to `//score/socom/test/unit:__pkg__`, depending on `:socom`.
- `score/socom/test/unit/BUILD:16-29` defines `socom_test` with `srcs = glob(include = ["*.cpp"])`
  and depends on `//score/socom:impl_service_identifier`, `//score/socom:mock`,
  `//score/socom/test/framework:socom_test_framework`, and googletest.

`runtime_tests.cpp` already includes `score/socom/runtime.hpp`, `score/socom/server_t.hpp`,
`score/socom/socom_mocks.hpp`, `score/socom/service_interface_definition.hpp`, and `<utility>`
(`:14-30`), and the enabled cases use only the already-linked helpers `create_runtime()`,
`create_server_callbacks()` (declared in `score/socom/test/framework/inc/score/socom/socom_mocks.hpp:66,71`),
`Server_connector_callbacks_mock`, `Server_service_interface_definition`, `to_num_of_methods` and
`to_num_of_events`. Therefore the cases are collected by the existing test target; **no BUILD change
was required or made.**

### 4.8 What is deliberately *not* claimed

- These tests have **not been compiled or executed** here (no `shell`/`bazel`). The retained host
  measurement covered only the focused identifier TU and did **not** compile `runtime_tests.cpp`.
- They exercise the registration-key gate only. They are **not** platform validation, and no
  boundary/equivalence technique is claimed as *executed*. No fuzz, fault-injection, or
  reference-hardware harness exists in this workspace.
- They do not settle the open design questions (whether `minor` should ever distinguish, supersede vs
  reject, `ASSERT(!m_server)` authority, the #84 public-interface restructure, FindService wildcard,
  config `0xFFFFFFFF` narrowing). Those remain pending human decisions.

---

## 5. Measurement and validation status

- **Tools:** `read_file`, `grep`, `glob`, `write_file` only. No `shell`, delegation, web, approval,
  publishing, or engineering acceptance.
- **Executed measurements by this iteration:** **none**. No build, no `bazel test`, no runtime. Every
  statement is a static reading of the working tree at the baseline-bound candidate paths, a direct
  reading of the host artifacts, or an explicitly-labelled strict-weak-ordering / lifetime
  consequence.
- **Host measurements read (not produced here), and their exact scope:**
  `.llm_tmp/overnight/validation/` is present (`check-result` `0`; `measurement.json`
  `check_ref: check_unit_matrix`, `changed_paths: []`, candidate `87/0`, baseline-with-agent-tests
  `87/30`, `origin: local_unprotected_measurement`, `initiator: Fabro host hook`,
  `engineering_acceptance: pending`, `full_native_tests: not_executed`, compiler `g++-12`). The
  compile/run covers **only** the focused `ServiceInstanceIdentifierTest` translation unit
  (`service_identifier.cpp` + `string_registry.cpp` + `service_identifier_tests.cpp`). It does **not**
  cover `runtime_tests.cpp`, the `RuntimeTest` suite, the `socom_test` Bazel target, or the broader
  `//score/...` set. It must not be re-reported as full native results or as engineering acceptance,
  and it does not measure the §4 runtime cases.
- **Test inventory (read, not run):** `score/socom/test/unit/runtime_tests.cpp` has **31 `TEST_F`**
  (`:279`…`:1253`) plus **1 `TEST`** (`RuntimeFactoryTest.DefaultConstructorWorks`, `:239`) and **1
  `TEST_P`** (`RuntimeBridgeTest.CreationOfClientsWillRequestServiceFunction`, `:1311`, with
  `INSTANTIATE_TEST_SUITE_P` at `:1323`). Of the 31 `TEST_F`, ten involve an enabled first connector:
  the seven duplicate/refusal cases E1–E7 (§4.2) and the three distinctness counterparts C1–C3 (§4.3).
  `score/socom/test/unit/service_identifier_tests.cpp` carries **87 `TEST_F`** under
  `ServiceInstanceIdentifierTest` (`:168`…`:2012`, verified this iteration by `grep`). All counts are
  static readings; the suites were not executed here.
- **Scope:** local, unprotected, scoped. This is a bounded source-inspection and test-verification
  record, not an accepted engineering decision. Full native runtime tests and human review remain
  pending.
- **Reproduction path for a later, permitted iteration (not executed here):**

  ```bash
  bazel test //score/socom/test/unit:socom_test
  # focused enabled-server duplicate regressions:
  bazel test //score/socom/test/unit:socom_test \
      --test_filter='RuntimeTest.ConstructDuplicateWhileFirstConnectorEnabledReturnsDuplicateServiceError'
  bazel test //score/socom/test/unit:socom_test \
      --test_filter='RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionWhileFirstConnectorEnabledReturnsDuplicateServiceError'
  bazel test //score/socom/test/unit:socom_test \
      --test_filter='RuntimeTest.ConstructDuplicateMinorBoundariesWhileFirstConnectorEnabledReturnsDuplicateServiceError'
  bazel test //score/socom/test/unit:socom_test \
      --test_filter='RuntimeTest.ConstructDuplicateWithSmallerMinorWhileFirstConnectorEnabledReturnsDuplicateServiceError'
  bazel test //score/socom/test/unit:socom_test \
      --test_filter='RuntimeTest.ConstructDuplicateRepeatedlyWhileFirstConnectorEnabledKeepsSlotHeld'
  bazel test //score/socom/test/unit:socom_test \
      --test_filter='RuntimeTest.ConstructDifferentMajorWhileFirstConnectorEnabledReturnsDistinctServerConnectors'
  ```

  Expected on the corrected key: the duplicate cases return `Construction_error::duplicate_service`
  while the first connector stays enabled, and the equivalence-class counterparts return two distinct
  valid connectors. On a key that includes `minor`, the minor-only cases would instead construct a
  second connector and fail. These expectations are source-derived, not measured.

---

## 6. Obligations status (none satisfied)

### 6.1 Pinned state from `authority.json`

| Field | Value |
|-------|-------|
| `codeql_scope` | Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload |
| `engineering_acceptance` | **pending** |
| `human_reviews` | **unanswered** |
| `safety_class` | **unknown** |
| `instruction` | "Restart the failed queue for one complete pass through all obligations" |

All nine pinned sources in `.llm_tmp/context/obligations/` were consulted this iteration (§1.6); every
`source-index.json` entry is `"native_acceptance": "not_inferred"`.

### 6.2 Obligation status for this slice (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Freedom from compiler warnings & errors (100 %) | `verification_plan.rst` (criterion 9, `:332-335`) | **PARTIALLY MEASURED / NOT SATISFIED** — the focused identifier TU compiled with `g++-12 -std=c++17 -Wall -Wextra -Werror` exit 0 and empty stderr (it includes the internal header, §2.2), but `runtime_tests.cpp` and `//score/socom:socom` were not compiled by any Bazel build here |
| Static code analysis (clang-tidy / CodeQL), findings classified | `code_analysis.rst`; `verification_process.rst` (`gd_req__verification_sca_classification`) | **NOT PERFORMED** — no tool, no build |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` (`:status: draft`) | **UNKNOWN — NOT CLAIMED** — mapping is draft; not applied |
| Structural statement / branch coverage goals | `verification_plan.rst` (criteria 1-2) | **NOT MEASURED** — no coverage run; prior coverage captures are out of this checkout |
| Unit/component testing executed, results recorded | `verification_plan.rst` (criteria 6-7); `verification_guideline.rst` | **NOT SATISFIED** — the host run executed only the 87 identifier tests; the §4 runtime tests executed 0 times here |
| Interface / requirements-based / resource / fault-injection test types | `verification_process.rst`; `verification_plan.rst` | **NOT PERFORMED / applicability not inferred** — no harness; identifier/runtime-key tests must not be labelled platform validation |
| Boundary / equivalence derivation | `verification_process.rst` | **SOURCE-ONLY** — enabled cases exist (§4) and `DerivationTechnique` is recorded, but the runtime cases were not executed |
| Fuzzy testing technique | `verification_process.rst` | **NOT EXECUTED / NOT CLAIMED** — no harness and no measurement |
| Linking tests to requirements (record properties) | `verification_process.rst` (`gd_req__verification_link_tests_cpp`, `:56-75`) | **PARTIAL / NOT DONE** — `DerivationTechnique`/`Description` are recorded in the test sources (`service_identifier_tests.cpp:42-65`; `runtime_tests.cpp:264-267`); `TestType`/`Verifies` cannot be set without inventing identifiers |
| External-component AoUs verified | `verification_process.rst` (`gd_req__verification_external_aou`) | **NOT SATISFIED** — no integration/static verdict; no AoU register |
| Independence of verification / review by a different committer | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Implementation inspection checklist IMPL_01…IMPL_03 | `inspection_checklist.rst` (`:status: draft`) | **NOT FILLED** — draft template, no inspection |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** for this slice; no tool run here |
| Obligation collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **ABSENT in this checkout** — directory not present |
| Native acceptance | `source-index.json` | **`not_inferred`** for every entry |

**Explicit non-satisfaction statement.** Missing tools (no Bazel build/test in this task), the unknown
safety class and un-inferred applicability, the incomplete extraction of host artifacts (focused TU
only), the absent obligation-collection results, and the unanswered human reviews mean **none of the
checked obligations may be treated as satisfied**. A collection node that retained results would only
show *retention*, not passing; here there are no retained results at all. In particular, the absence of
`.llm_tmp/overnight/obligations/*/result.json` and the focused-only scope of
`.llm_tmp/overnight/validation/` are **not** evidence that the corresponding checks passed.

### 6.3 Host-addendum honesty

This report does **not** label identifier-only / registration-key tests as full platform validation,
and does **not** claim that a fuzzy or fault-injection technique was executed. No fuzz/fault-injection
harness and no full feature/platform reference-hardware tests exist in this workspace; those remain
explicit pending work. Concrete boundary/equivalence regression cases exist within the six candidate
source paths.

---

## 7. Files changed / state of the six candidate paths

| Candidate path | State | This iteration |
|----------------|-------|----------------|
| `score/socom/impl/service_identifier.hpp` | brace-balanced, nested namespace, documents minor exclusion | inspected, **unchanged** (§2) |
| `score/socom/impl/service_identifier.cpp` | `operator<` identity `(instance, id, major)`, minor excluded | inspected, **unchanged** (§3) |
| `score/socom/BUILD` | `testonly impl_service_identifier` exposure present | inspected, **unchanged** |
| `score/socom/test/unit/BUILD` | `socom_test` globs `*.cpp`, deps wired | inspected, **unchanged** |
| `score/socom/test/unit/runtime_tests.cpp` | enabled-server duplicate + equivalence-class cases present (§4); Apache-2.0 header intact | inspected, **unchanged** |
| `score/socom/test/unit/service_identifier_tests.cpp` | 87-case key matrix present | inspected, **unchanged** |
| `.llm_tmp/overnight/reports/runtime_enabled.md` | **new — this report** | written |

No file outside the six candidate paths and this report was written; no `NOTICE`, `LICENSE`, or
`REUSE.toml` file was created, edited, or deleted; all prior reports under
`.llm_tmp/overnight/prior-reports/` and the pre-existing `.llm_tmp/overnight/reports/*` were
preserved.

---

## 8. Notice preservation

- Every candidate source retains its Apache-2.0 / SPDX header (`:1-12`). `score/socom/test/unit/runtime_tests.cpp`
  retains its header verbatim; all pre-existing cases are unchanged.
- No `NOTICE`, `LICENSE`, or `REUSE.toml` file was created, edited, or deleted.
- All 38 prior reports under `.llm_tmp/overnight/prior-reports/` and the seven pre-existing
  `.llm_tmp/overnight/reports/*` (this run's earlier nodes) were preserved; this iteration only added
  `.llm_tmp/overnight/reports/runtime_enabled.md`. The earlier `prior-reports/runtime_enabled.md` was
  **not** overwritten.
- The header the task flagged (`score/socom/impl/service_identifier.hpp`) was inspected and left
  unchanged because it is already brace-balanced and otherwise well-formed (§2).
- The duplicate key remains an `impl/`-only type; the `testonly` `//score/socom:impl_service_identifier`
  library exposes it to `//score/socom/test/unit` only, so no public header or notice surface changed.
- This report itself carries the Apache-2.0 header.

---

## 9. Pending human review checklist

- [ ] **Confirm the §2 inspection**: the header is already brace-balanced (single nested close
      `}  // namespace score::socom`; line 39 blank) and the host focused compile exited 0 under
      `-Werror`, so the recorded syntax failure is stale and no source edit was required; re-check
      before any compile if the state ever changes. If the "cancelled draft" is a different revision
      that still carries the extra brace, locate it and authorize its correction; it is not the file in
      this checkout.
- [ ] **Confirm the key decision in §3**: `minor` is **not** part of the duplicate-server registration
      key; identity is `(instance, service id, major)`; the key persists while the connector is
      **enabled** and is erased only on destruction; interface representation and the exact-major /
      client-minor ≤ server-minor compatibility rules are unchanged.
- [ ] **Confirm the enabled-server runtime coverage in §4**: the seven duplicate/refusal cases E1–E7
      and the three equivalence-class counterparts C1–C3, each comparing against the genuine
      `duplicate_service` error result. Note explicitly that these tests were **not** executed by the
      host measurement in this checkout and that `runtime_tests.cpp` is not compiled by the focused
      identifier-TU measurement.
- [ ] **Resolve the instruction conflict**: the task directs correcting the source and drafting new
      tests, while the actual source contains no defect and the requested enabled-server tests already
      exist; confirm that report-only (no source edit, no duplicate test) is the intended outcome here.
- [ ] **Confirm the baseline binding** in §1.2-1.3 (issue #84 ↔ commit `f8a196c3…`) and that
      `prior-reports/invariants.md` I-4's baseline ordering (`minor` included) still describes the
      committed baseline.
- [ ] **Keep the #84 public `Service_interface_identifier` restructure**, FindService wildcard
      handling, and the config minor-wildcard (`0xFFFFFFFF`) narrowing out of this bounded slice until
      separately accepted; do **not** present the identifier-only or registration-key tests as platform
      validation or claim an unmeasured fuzzy technique.
- [ ] **Supply native requirement source IDs and traceability metadata** (no invented links), or record
      applicability as unresolved.
- [ ] **Supply the missing obligation results** (`.llm_tmp/overnight/obligations/*/result.json`) and
      resolve the `engineering_acceptance: pending` / `human_reviews: unanswered` state; do not infer
      passing from absence.
- [ ] **Run the full native suite** (`bazel test //score/socom/test/unit:socom_test` and the broader
      `//score/...` set), including `runtime_tests.cpp`, and record results; schedule independent human
      review (the approver must differ from the author, per `gd_req__verification_independence`).
- [ ] **Select a safety class** via the authorized role; do not infer the slice's class from the
      `:safety: ASIL_B` attribute on the pinned platform documents (§1.6).

---

*End of `runtime_enabled` review draft. Local, unprotected, scoped. No engineering acceptance; human
reviews unanswered; full native runtime tests pending. Every statement is a local reading of the
working tree, a prior report's recorded reading, a host artifact present in this checkout, or an
explicitly-labelled logical consequence — none is acceptance, review approval, publication, or a full
native run.*
