<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — design inspection draft (duplicate-server registration-key slice)

**Document type:** review draft — implementation inspection against specification, design,
external libraries, static/dynamic analysis, manual coding checks and interface/traceability
consistency, plus drafted remaining safety-analysis (FMEA/DFA) impact questions.

**Date:** 2026-10-03
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version handling in
socom* (issue #84)
**Run:** branch `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ` (this iteration's environment)
**Status:** local, unprotected, scoped. **No engineering acceptance exists. Human reviews are
unanswered. Full native runtime tests remain pending human adjudication.** Every statement below is
either a direct `read_file`/`grep`/`glob` reading of this checkout, a direct reading of a retained
artifact under `.llm_tmp/overnight/`, or an explicitly-labelled logical consequence. Nothing here is
published, reviewed, accepted, or a substitute for the S-CORE gates.

> **Write boundary actually observed (stated first, as required).** The task text contains two
> directions that conflict: it says *"Inspect and correct the actual source before expanding
> tests"* and *"The cancelled draft has a measured GCC syntax failure: an extra closing brace in
> `score/socom/impl/service_identifier.hpp` at line 39"*, but its explicit final sentence says
> *"This is a review draft: only that report may be written."* Only `read_file`, `grep`, `glob` and
> `write_file` were available and used; there was no `shell`, no `edit_file`, no delegation, no web
> access, no approval, and no publishing. Following the explicit, more specific write boundary,
> **exactly one file was written — this report.** No source, build, test, config, `NOTICE`,
> `LICENSE`, `REUSE.toml`, or prior-report file was created, edited, or deleted.
>
> **The conflict is moot on the facts: the described syntax failure is not present in the actual
> source (§2).** Direct inspection shows `score/socom/impl/service_identifier.hpp` is
> brace-balanced: openers at `:19` (`namespace score::socom {`) and `:29`
> (`struct Service_instance_identifier final {`); closers at `:32` (`};`) and `:38`
> (`}  // namespace score::socom`); line `:39` is **empty**; line `:40` is `#endif`. Two openers,
> two closers, net balance `0`; `grep '[{}]'` returns exactly those four lines and
> `grep 'namespace'` returns exactly `:19` and `:38`. There is no third, unmatched closing brace to
> remove. Applying a historical split-form repair to the already-nested file would be a no-op at
> best and a regression at worst. No test was expanded in this iteration either, because the
> draft's suites already exist on disk (§5).
>
> **Non-satisfaction rule applied throughout.** A successful obligation-collection node means the
> results were **retained**, not that the checks **passed**. Missing tools, unknown applicability,
> incomplete extraction, an inactive/draft rule mapping, and unanswered human reviews are **not**
> treated as satisfied. A tool that produced **no** finding because it **did not run** (or timed
> out) is recorded as *"not run / not completed"*, never as *"clean"*.

---

## 0. Summary

1. **The recorded "extra closing brace at line 39" is not present in the actual source (§2).**
   The header is 40 lines and brace-balanced (braces at `:19`, `:29`, `:32`, `:38`; line `:39`
   blank). The retained focused GCC compile of the candidate identifier translation unit exits `0`
   with empty `stderr`; a surviving unmatched brace would have failed it. The description matches
   the earliest prior reports' pre-correction split-form double close, not this checkout. **No
   source correction was applied and none is required**; the review-draft boundary forbids a source
   write in any case.
2. **Implementation against specification (§3): the bounded key change is present and internally
   consistent, but the "specification" it follows is an unaccepted issue-#84 proposal, not a
   verified requirement.** `operator<` orders by `(instance, service id, major)` with `minor`
   deliberately excluded (`service_identifier.cpp:20-30`), so the duplicate-server identity now
   matches the minor-ignoring `Service_database` record index (`runtime_impl.hpp:116-134`).
3. **Design inspection (§4): the change closes an invariant gap but rests on two cross-lock /
   lifetime properties** — key identity equal to record identity (so the single-server
   `ASSERT(!m_server)` stays unreachable), and key/registration teardown ordering. It does **not**
   implement the wider public-identifier restructure.
4. **External libraries (§6): no library is qualified, and the load-bearing AoU is undetermined.**
   The key/error path depends on `score_baselibs` (`SCORE_LANGUAGE_FUTURECPP_ASSERT` semantics,
   `score::Result`, `mw::log`) and, in the focused runs, on vendored googletest; the assert's
   terminate-vs-compiled-out semantics are external and unknown. No external-component AoU is
   integration-tested or statically analysed here.
5. **Static/dynamic analysis (§7): materially more executed than in the prior drafts, but still
   partial and not "clean".** The retained host set now records a full native `bazel build //...`
   exit 0, a full native `bazel test //...` run in which `//score/socom/test/unit:socom_test`
   **PASSED** (21/29 executed, 8 skipped), ASan/UBSan/LSan native tests 19/19, and gcov coverage at
   the repository threshold 73. But **TSan is not clean** (focused TSan exits 66; native TSan only
   ran 5/27 and the stress target shows `NO STATUS`), clang-tidy timed out (124) and the focused
   clang-tidy config was rejected, cppcheck reported only out-of-scope `passedByValue` advisories,
   CodeQL security/MISRA findings are dependency-only with a **draft** MISRA mapping, the
   docs/traceability gate **failed** (`schema_version None`, and the docs build died on a missing
   git remote while listing our new tests as *"missing some properties"*), reuse lint **failed**
   (2 files missing licensing), the format gate timed out, secret scanning flagged a private-key
   artifact outside the slice, and native QEMU integration failed (exit 1). Performance benchmarks
   timed out. None of these is "clean".
6. **Manual coding checks (§8): a construct-by-construct inspection finds no confirmed
   safety-relevant defect in the changed comparator, but records actionable findings** (missing
   `noexcept`; documentation narrower than the new semantics; content-ordered `<` vs pointer-based
   `==`/`hash`; teardown-declaration-order fragility). No MISRA C++:2023 compliance is claimed,
   because `misra_mapping.rst` is `:status: draft`.
7. **Interface/traceability consistency (§9): the implementation and its code comments agree, but
   the design docs and the requirement model are silent, so the traceability chain is broken at
   both ends.** The retained docs/traceability run corroborates this: it lists
   `RuntimeTest__…` and `ServiceInstanceIdentifierTest__…` under *"Tests missing some properties"*,
   i.e. the `TestType`/`Verifies` links are absent for exactly this slice.
8. **Remaining safety-analysis impact questions are drafted, not answered (§10).** Per the task,
   this draft does **not** act as the independent reviewer and does not select a safety class,
   accept risk, or answer the human gate.
9. **No obligation is satisfied (§11).** Every `source-index.json` entry is
   `native_acceptance: not_inferred`; `authority.json` records `engineering_acceptance: pending`,
   `human_reviews: unanswered`, `safety_class: unknown`.

---

## 1. Binding, candidate set, sources read

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` | `.llm_tmp/context/issue-snapshot.json:2-4` |
| Title | *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:3` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` | `.llm_tmp/context/issue-snapshot.json:19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**. It distinguishes: service-instance identifier = `service id + major + minor + instance
id`; service identifier = `service id + major`; FindService = `service id + major +
optional<minor> + optional<instance>`; and proposes to "exclude the minor version and make it a
property of the service instance". The FindService `major = FF` AUTOSAR case is called theoretically
possible but not useful. There is **no comment and no acceptance record**, so none of it is
binding. Binding is **by baseline commit**, not by run HEAD.

### 1.2 Verified baseline

| Item | Value | Source |
|------|-------|--------|
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:2-3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |
| Current branch | `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ` | environment |

Binding is **by baseline commit `f8a196c3…`**, not by the run HEAD; earlier reports on the same
baseline therefore remain admissible prior evidence.

### 1.3 In-scope candidate files (the only writable source paths in the broader task)

From `.llm_tmp/context/candidate-files.json:1-25` (baseline blobs cross-checked against the `files`
array of `.llm_tmp/context/source-manifest.json`):

| File (repo-relative) | Baseline git blob | Current working tree (read this iteration) |
|----------------------|-------------------|--------------------------------------------|
| `score/socom/BUILD` | `3477ea08…` | `socom` library `:24-41`; `testonly` `impl_service_identifier` `:46-54` |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e…` | key identity `(instance, id, major)`; `minor` excluded (`:20-30`) |
| `score/socom/impl/service_identifier.hpp` | `c8bae790…` | brace-balanced, 40 lines, `:39` blank (§2) |
| `score/socom/test/unit/BUILD` | `3c03a7b1…` | `socom_test` globs `*.cpp`; deps wired (`:16-29`) |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab7…` | 33 test macros; minor-only regression `:402-431` |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(none — `null`)* | 91 `TEST_F`; the manifest expects a **new** file |

`glob **/service_identifier.hpp` returns exactly one path, so there is no second, differently-braced
copy of the header in this checkout.

### 1.4 Pinned process/platform sources read

All nine entries of `.llm_tmp/context/obligations/source-index.json` are present together with
`authority.json`:

| id | repository @ commit | status note |
|----|---------------------|-------------|
| `coding_guidelines` | `score` @ `e2373d82…` | `:status: valid`; **MISRA C++:2023 with C++17** |
| `code_analysis` | `score` @ `e2373d82…` | `:status: valid`; clang-tidy + gcc/clang warnings + Coverity; ASan/LSan/TSan/UBSan/Memcheck; gcov/gcovr |
| `misra_mapping` | `score` @ `e2373d82…` | **`:status: draft`**; rule table inactive |
| `verification_plan` | `score` @ `e2373d82…` | `:status: valid`; TestType and DerivationTechnique tables; quality criteria 1–9 |
| `development_plan` | `score` @ `e2373d82…` | `:status: valid`; C++17, GCC host compiler, QCC target, Bazel |
| `tool_management` | `score` @ `e2373d82…` | `:status: valid`; identify / evaluate / qualify / approve |
| `verification_process` | `process_description` @ `98d1d5f4…` | `:status: valid`; link-tests, independence, checks, external-AoU, SCA-classification requirements |
| `verification_guideline` | `process_description` @ `98d1d5f4…` | `:status: valid`; traceability, independence, documented results |
| `inspection_checklist` | `module_template` @ `c4d4ad09…` | **`:status: draft`**; blank `IMPL_01_01`…`IMPL_03_02` template |

Every entry is pinned with `"native_acceptance": "not_inferred"`. `authority.json` records
`codeql_scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload"`,
`engineering_acceptance: pending`, `human_reviews: unanswered`, `safety_class: unknown`.

### 1.5 Prior reports, host feedback, obligation-collection results (read this iteration)

- `.llm_tmp/overnight/prior-reports/` — present and preserved, including
  `design_inspection_draft.md`, `scope.md`, `key_fix.md`, `invariants.md`, `callsites.md`,
  `reproducer.md`, `unit_matrix.md`, `ordering_tests.md`, `conversion_tests.md`,
  `runtime_disabled.md`, `runtime_enabled.md`, `lifetime_tests.md`, `test_metadata.md`,
  `finding_classification.md`, `deviation_drafts.md`, `api_review.md`, `compatibility.md`,
  `coverage_review.md`, `lifetime_review.md`, `concurrency_review.md`, `sanitizer_review.md`,
  `security_review.md`, `integration_aou_review.md`, `tool_assurance_review.md`,
  `misra_manual_review.md`, `traceability_review.md`, `independent_review_handoff.md`.
- `.llm_tmp/overnight/reports/` — earlier reports present and preserved (this document is added;
  nothing was overwritten).
- `.llm_tmp/overnight/validation/` — present: `check-result` = `0`; `measurement.json`
  (`origin: local_unprotected_measurement`, `initiator: Fabro host hook`,
  `engineering_acceptance: pending`, `full_native_tests: not_executed`, `mode: ubsan`,
  `check_ref: check_conversion_tests`, `changed_paths: [score/socom/test/unit/service_identifier_tests.cpp]`,
  compiler `/usr/bin/x86_64-linux-gnu-g++-12`,
  compiler sha256 `88315fd2…`); `before.json` = **91 tests / 33 failures / 0 disabled**;
  `after.json` = **91 tests / 0 failures / 0 disabled**; `after-compile.command.json` exit `0` and
  `after-compile.stderr` empty. The four JSON captures are the `ServiceInstanceIdentifierTest`
  suite only (see §1.6 scope caveat).
- `.llm_tmp/overnight/obligations/*/result.json` — present (24 checks). **Retention is not
  passing**; statuses are summarised in §7. Notably, several checks that prior drafts recorded as
  machine-blocked now ran: `native_build` exit 0, `native_tests` exit 0 with 21/29 executed and
  passing, `native_sanitizers` exit 0 with 19/19 passing, `native_coverage` exit 0,
  `native_tsan` exit 0 (but only 5/27 executed). Others still fail: `native_traceability` docs
  exit 2 / gate exit 1, `native_docs` exit 2, `native_integration` exit 1, `native_lint` clang-tidy
  exit 124, `native_performance` exit 124 ×2, `format_precommit` format exit 124 / reuse exit 1,
  `focused_clang_tidy` exit 1, `focused_cppcheck` exit 2, `focused_tsan` exit 66,
  `secret_dependency_checks` exit 1, `codeql_security` / `codeql_misra`
  `findings_or_execution_failure`.

### 1.6 Scope caveat carried into every section below

The **focused** identifier measurement compiles only
`service_identifier.cpp` + `string_registry.cpp` + `service_identifier_tests.cpp` + vendored
googletest with g++-12 `-std=c++17 -Wall -Wextra -Werror` (+ UBSan). It executes the
91 `ServiceInstanceIdentifierTest` cases; it does **not** execute `runtime_tests.cpp`. The **native**
runs (`native_tests`, `native_sanitizers`, `native_tsan`) do build and run
`//score/socom/test/unit:socom_test`, which contains `runtime_tests.cpp`; those are protected by the
host sandbox but are still local, unprotected captures rather than an accepted full native run.
`process_checks/result.json` counts 91 test macros in `service_identifier_tests.cpp` and 33 in
`runtime_tests.cpp`. A green retained marker is therefore evidence for the compiled target, but it
is not engineering acceptance.

### 1.7 Host addendum (task context, not acceptance)

The host addendum (quoted in earlier reports) states it "is task context, not engineering acceptance
or an approved tailoring decision". It asks the inspection to cover the `verification_process` test
types and derivation techniques; to keep unknown applicability and unexecuted checks explicit; to
**not** label identifier-only tests as full platform validation and **not** to claim a fuzzy
technique without a measurement; and to record that there is **no authority to invent native links,
select a safety classification, accept risk/deviations, or answer the independent human gate.** This
draft honours that in §3–§11.

---

## 2. The recorded GCC syntax failure — inspection of the actual source

### 2.1 Finding (re-verified this iteration by direct `read_file` + `grep`)

`score/socom/impl/service_identifier.hpp` is **brace-balanced**:

| Line | Content | Role |
|------|---------|------|
| 14 | `#ifndef SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard begin |
| 17 | `#include "score/socom/service_interface_identifier.hpp"` | include |
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 21–28 | doc comment | states that `minor` is intentionally not part of the identity |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 30–31 | `Service_interface_identifier interface;` / `Service_instance instance;` | members |
| 32 | `};` | closes the struct |
| 34–36 | `/// \cond` / `bool operator<(…)` / `/// \endcond` | the single operator declaration |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`) and two closers (`:32`, `:38`) give net brace balance `0`. There is **no
third, unmatched closing brace**, and line `:39` contains no text at all. The sibling
`impl/service_identifier.cpp` uses the same nested form (brace lines `:18`, `:20`, `:30`, `:32`) and
is balanced. The public `service_interface_identifier.hpp` uses the nested form as well; the split
`namespace score { namespace socom {` form appears in `impl/runtime_impl.hpp`.

### 2.2 Independent (retained) corroboration — read, not produced here

- `.llm_tmp/overnight/validation/after-compile.command.json` compiles `service_identifier.cpp`
  (which includes this header) with `/usr/bin/x86_64-linux-gnu-g++-12 -std=c++17 -Wall -Wextra
  -Werror`, **exit 0**; `after-compile.stderr` is empty.
- `.llm_tmp/overnight/obligations/compiler_diagnostics/result.json` status `completed`; all eight
  recorded compile/test commands exit `0`; `limits` note "Focused executable only …".
- `.llm_tmp/overnight/obligations/native_build/result.json` status `completed`, `bazel build //…
  --jobs=2` **exit 0** (the full native build now succeeds; the earlier "No space left on device"
  toolchain failure no longer reproduces in this capture).
- The remaining Clang/lint failures are dependency diagnostics or configuration blocks, not a header
  syntax error (see §7).

A genuine unmatched brace would have failed every focused GCC compile and the full native build.
These are scoped, unprotected, focused runs — corroboration, **not** a full native criterion-9
measurement.

### 2.3 Disposition

The described defect is a **stale, pre-correction description** that matches the earliest prior
reports (which quote lines 38–39 as the old split form `}  // namespace socom` + `}  // namespace
score`). The `reproducer` iteration applied the correction and left line 39 blank, exactly as
observed here. **No correction was applied; none is required.** Two independent reasons prevented a
source write, either of which is sufficient: (a) there is no defect in the actual source, and (b)
this review draft may write only this report. If a distinct "cancelled draft" revision elsewhere
still carries the extra brace, it is not the file in this checkout and must be located and corrected
by an authorized iteration.

---

## 3. Implementation inspection against the specification

### 3.1 The changed implementation (exact constructs)

```cpp
// score/socom/impl/service_identifier.hpp:29-35
struct Service_instance_identifier final {
    Service_interface_identifier interface;
    Service_instance instance;
};

/// \cond
bool operator<(Service_instance_identifier const& lhs, Service_instance_identifier const& rhs);
/// \endcond
```

```cpp
// score/socom/impl/service_identifier.cpp:20-30
bool operator<(Service_instance_identifier const& lhs, Service_instance_identifier const& rhs) {
    // ... rationale comment (minor excluded; identity = service id + major; issue #84) ...
    return std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major) <
           std::tie(rhs.instance, rhs.interface.id, rhs.interface.version.major);
}
```

`std::set` uniqueness is `!(a < b) && !(b < a)`, so the duplicate-server identity on this tree is
exactly `(instance, service id, major)` and **the minor version is excluded**.

### 3.2 Conformance to the (unaccepted) issue-#84 design

| #84 use case / proposal | State in this tree | Verdict |
|-------------------------|--------------------|---------|
| "service identifier = `service id + major`" | Realized **only internally**: the duplicate key and the `Service_database` index both use `(id, major)` (+ instance) | **Partially realized, internally only** |
| "exclude the minor version and make it a property of the service instance" | `minor` is excluded from the internal registration key, but still lives on `Service_interface_identifier::Version` (public) | **Not realized as a public-type change** |
| service-instance identifier = `service id + major + minor + instance id` | The key drops `minor`; `Service_instance` carries no version | **Diverges from this use case** |
| FindService `service id + major + optional<minor> + optional<instance>` | Not implemented; discovery is untouched | **Not implemented** |
| FindService `major = FF` wildcard | Not implemented; `major` is an exact identity component | **Not implemented** |

**Important framing.** The "Partially realized" row is a *source reading*, not an acceptance. The
only thing the bounded slice actually does is drop `minor` from the internal duplicate key. The
issue body is an open proposal with **0 comments and no acceptance record**; there is no verified
native requirement it implements. The implementation therefore cannot be said to "satisfy the
specification" in the S-CORE sense — it follows an unaccepted design direction, and it must be
traced to a native requirement (or the gap recorded) before acceptance (§9).

### 3.3 The red/green regression actually retained

The retained host measurement exercises the behaviour change directly:

| Capture | Tests | Failures | Compile exit |
|---------|-------|----------|--------------|
| `validation/before.json` (baseline key, minor included) | 91 | **33** | 0 |
| `validation/after.json` (candidate key, minor excluded) | 91 | **0** | 0 |

This is consistent with the minor-exclusion matrix in `service_identifier_tests.cpp`: on a
minor-including key, `KeysDifferingOnlyInMinorVersionAreDuplicates` and 32 siblings fail; on the
candidate key they pass. This is a **local, unprotected, focused** measurement, not acceptance, and
it covers only the identifier TU (see §1.6). The native run additionally exercises
`runtime_tests.cpp` (§7), but that too remains unprotected.

---

## 4. Design inspection

### 4.1 The change and the design it encodes

- **Key type.** `Service_instance_identifier` is `{ Service_interface_identifier interface;
  Service_instance instance; }` (`impl/service_identifier.hpp:29-32`), with an out-of-line
  `operator<` (`:35`) and **no** `operator==`/`std::hash` (ordering-only identity).
- **Key role.** It is the duplicate-server registration key only:
  `using Service_identifiers = Mutexed_variable<std::set<Service_instance_identifier>>`
  (`impl/runtime_impl.hpp:56`).
- **Insertion / duplicate rejection.** `Runtime_impl::make_server_connector` builds
  `Service_instance_identifier const identifier{configuration.get_interface(), instance}`
  (`runtime_impl.cpp:443`), then, under the key mutex, inserts (insert at `:451`) and returns
  `Construction_error::duplicate_service` when `insert(...).second` is false (`:449-454`). A
  `Final_action` capturing the identifier and a `weak_ptr` erases it (`:456-463`).
- **Record index.** `Service_database` indexes records by `id + major` and ignores minor, via
  `Minor_version_ignoring_key_equal` / `Minor_version_ignoring_hash`
  (`runtime_impl.hpp:116-134`), consumed by `get_record` (`runtime_impl.cpp:313-324`).
- **Single-server precondition.** `Service_record::register_server_connector` asserts
  `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)` then `m_server.emplace(...)`
  (`runtime_impl.cpp:366-382`; assert `:369`, emplace `:371`).
- **Compatibility rule (separate from identity).** `is_minor_version_compatible` is
  `client.minor <= server.minor`; `is_interface_compatible` requires equal `id`, equal `major`, then
  the minor rule (`runtime_impl.cpp:133-146`). These are not part of the key.

### 4.2 The invariant the change closes

On the baseline, the key included `minor` while the record index ignores it. Two server connectors
for the same `id + major + instance` with different minor versions then produced distinct keys (both
passing the duplicate gate) but resolved to the same `Service_record` on enable, reaching
`SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)` (undefined behaviour where the assert does not
terminate). The working-tree key change makes the key as coarse as the record index, closing this
gap at the key level. This is a **source-derived reading, not a reproduced runtime failure**; the
single-server path is not directly forced by the retained tests (both connectors in the regression
stay disabled, so the duplicate is rejected at construction and never reaches the assert).

### 4.3 Design properties the change now depends on

1. **Key identity == record identity.** The assert stays unreachable only while the registration key
   is at least as coarse as the `Service_database` index. Re-fining the key without re-examining the
   index would reopen the gap (FMEA-2).
2. **Teardown ordering.** The key-erase `Final_action` is declared after other member state in
   `Runtime_impl`; `disable()`/destruction order determines whether a record can outlive its key
   (see the lifetime reports). This is adjacent to, not introduced by, the key change (FMEA-3).
3. **Non-owning views.** The key holds `Registry_string_view`s; the registry must outlive the key
   (static-destruction-order path) (FMEA-4).

### 4.4 What the design change is NOT

It does not implement the wider #84 restructure (public `Service_interface_identifier` / minor as
instance property), FindService wildcard handling, or config minor-wildcard narrowing. It does not
change the public type, the compatibility rules, or the record index. Those remain deferred and
must be adjudicated separately.

### 4.5 Discovery/design-document gap

No element in `score/socom/docs/design/` records the registration-key identity, the
minor-ignoring index, or the duplicate-server rejection semantics. The docs/traceability run
(§7, §9) lists this slice's tests as *"missing some properties"*, consistent with the absent
requirement/design anchors. This is a **design-documentation defect**, not a code defect.

---

## 5. Tests and build wiring (present on disk; executed in part)

### 5.1 Key-level tests

`score/socom/test/unit/service_identifier_tests.cpp` (new file per the manifest; Apache-2.0 header
present) carries a **91-case** identity/ordering matrix under `ServiceInstanceIdentifierTest`
(counted by `process_checks` and confirmed by `validation/*.json`), including:

- irreflexivity (`SameIdentifierIsNotLessThanItself`);
- minor exclusion at adjacency, `uint16` extremes, sweeps, and set-find
  (`KeysDifferingOnlyInMinorVersionAreDuplicates`, `MinorVersionBoundariesAreDuplicates`,
  `AllMinorVersionsCollapseToSingleKey`, `MinorHighBitVariantsAreEquivalent`,
  `MinorVersionNeverAffectsOrdering`, `SetFindLocatesMinorVariantAndCountsItOnce`,
  `StdSetCollapsesFiveMinorVariantsOfEveryIdentity`);
- major including `0`/`65535` boundaries and adjacency
  (`KeysDifferingInMajorVersionAreDistinct`, `MajorVersionBoundariesAreDistinct`,
  `MajorVersionLadderOrdersNumericallyAndDistinctly`, `MajorVersionOrderMatchesUnsignedNumericOrder`);
- service id and instance identity, plus distinct-set sizes and ladder orderings;
- combined matrices (2×2×2 and 3×3×3 with minor collapse) and strict-weak-ordering property checks
  over deterministic domains (`PropertyStrictWeakOrdering…`, `PropertyIdentifierEquality…`,
  `EquivalenceCoincidesWithIdentityOverFixtureCrossProduct`);
- text/registry → public-identifier → internal-key conversion boundaries, including config minor
  narrowing (`ConvertedConfigMinorNarrowingBoundariesCollapseAndDistinguish`).

The record metadata is set in `SetUp()` (`:42-65`):
`DerivationTechnique = "boundary-values,equivalence-classes"` and a `Description`. `TestType` and
the `Verifies`/`PartiallyVerifies`/`FullyVerifies` links are deliberately **not** set, because no
verified native requirement/interface identifier exists for this slice and inventing one is
prohibited. The type declares no `operator==`/hash, so "equality" is defined as mutual non-ordering
(`!(a<b) && !(b<a)`), which is exactly the `std::set` equivalence.

### 5.2 Runtime-level regression

`score/socom/test/unit/runtime_tests.cpp:402-431`
(`ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError`) exercises the real
registration entry point: it builds two `Service_interface_identifier`s that share id
(`"TestInterface"`), major (`1`) and instance (`"TestInterface"`) and differ only in `minor`
(2 vs 3), calls `Runtime::make_server_connector()` twice via the public `Runtime` interface, and
expects the second call to equal `score::MakeUnexpected(Construction_error::duplicate_service)`.
Both connectors remain disabled, so the duplicate is rejected at construction and never reaches the
single-server assert. The file records `DerivationTechnique = "design-analysis,equivalence-classes"`
via `record_registration_key_metadata` (`:264-267`); `TestType`/`Verifies` are again absent. The
file holds 33 test macros in total and **does execute natively** in `native_tests` (§7).

### 5.3 Boundary / equivalence coverage versus the host addendum

- **Boundary values:** major `0`, `1`, `0x7FFF`, `0x8000`, `0xFFFE`, `65535`; minor `0`, `1`, `2`,
  `3`, `0x7FFF`, `0x8000`, `65535` are covered by the key tests.
- **Equivalence classes:** minor-only (equivalent) versus service-id / instance / major differences
  (distinct) are covered, including combined matrices and deterministic multi-key domains.
- **Still absent / unknown applicability:** no fuzz harness, no fault-injection harness, and no
  full feature-/platform-level reference-hardware tests exist in this workspace; no fuzzy technique
  was executed. These identifier-only tests must **not** be presented as platform validation. The
  minimum-minor rule is exercised by other suites (`interface_compatibility_tests.cpp`,
  `client_tests.cpp`), not by this key slice.

### 5.4 Build wiring

- `score/socom/BUILD:46-54` defines the `testonly` `impl_service_identifier` library exposing
  `impl/service_identifier.hpp` to `//score/socom/test/unit:__pkg__`, depending on `:socom`.
- `score/socom/test/unit/BUILD:16-29` defines `socom_test` with `srcs = glob(include = ["*.cpp"])`
  and depends on `//score/socom:impl_service_identifier`, `//score/socom:mock`,
  `//score/socom/test/framework:socom_test_framework`, and googletest.

No BUILD change was required or made.

---

## 6. External libraries / assumptions of use

The slice is not self-contained; it rests on external components whose AoUs are **undetermined** in
this workspace:

1. **`score_baselibs`** — `SCORE_LANGUAGE_FUTURECPP_ASSERT` (from
   `@score_baselibs//score/language/futurecpp`, `score/socom/BUILD:37`). The single-server
   invariant's outcome (terminate vs compiled-out state overwrite) depends on this external macro's
   semantics and build configuration. *Question:* what is the qualified AoU, and what does a build
   with assertions disabled do to FMEA-2/FMEA-3?
2. **`score::Result` / `Construction_error`** — the error path
   (`@score_baselibs//score/result`, `score/socom/BUILD:39`). The duplicate path returns a `Result`
   error; its observable contract at the daemon boundary is external.
3. **`score::mw::log`** — the daemon logs and skips on `duplicate_service`; log behaviour is
   external.
4. **Vendored googletest** — the focused runs compile `.llm_tmp/googletest/...`; the Clang failure
   and CodeQL security/MISRA findings are almost entirely inside this vendored dependency, i.e. the
   tool verdicts are dominated by an external component, not by the changed code.
5. **FlatBuffers config schema** — `service_version_major: uint8` /
   `service_version_minor: uint32 = 0xFFFFFFFF` narrow to socom's `uint16` fields at several
   conversion sites; the wildcard's meaning is not resolved here (§10, FMEA-7).

No external-component AoU is integration-tested or statically analysed to an accepted verdict in
this slice.

---

## 7. Static and dynamic analysis — status from the retained obligation results

All entries below are `read_file`/`grep` readings of `.llm_tmp/overnight/obligations/*/result.json`
and their stdout/stderr/stdout companions. **A retained result is not a passed check**; the status
column is this draft's classification of what the artifact actually shows.

| Obligation | Retained evidence | This draft's status |
|------------|-------------------|---------------------|
| `compiler_diagnostics` | status `completed`; 8 commands all exit 0; `limits`: "Focused executable only; GCC 12.3 / Clang 19 differ from native toolchain pins" | Focused GCC compile/tests pass; **not** full native criterion 9 |
| `native_build` | status `completed`; `bazel build --jobs=2 //...` exit 0 | Full native build **succeeds in this capture**; dependency deprecation warnings only |
| `native_tests` | status `completed`; `bazel test //... --build_tests_only` exit 0; retained stdout: 21/29 executed, **21 pass**, 8 skipped; `//score/socom/test/unit:socom_test PASSED` | **Native unit/component tests execute and pass** in this capture (incl. `runtime_tests.cpp`); argv contains `--build_tests_only`, which is noted as an ambiguity; still local/unprotected |
| `native_sanitizers` | status `completed`; exit 0; stdout: 19/19 executed pass incl. `socom_test` | ASan/UBSan/LSan native run **passes** |
| `native_coverage` | status `completed`; coverage + report exit 0; `limits`: "Repository CI threshold 73 is not platform 85/100 line-and-branch acceptance" | Coverage produced at repo threshold; **platform coverage criteria not demonstrated** |
| `focused_coverage` | status `completed`; `service_identifier.cpp` line 3/3 = 100 %, branch 1/2 = 50 %; `string_registry.cpp` line 33/33 = 100 %, branch 10/12 = 83.3 %; overall line 36/36 = 100 %, branch 11/14 = 78.6 % | Branch coverage **below** the 85 %/100 % platform goals; no deviation accepted |
| `focused_asan_lsan` | status `completed`; compile + tests exit 0; stdout: 91/91 pass | Focused ASan/LSan **passes** |
| `focused_memcheck` | status `completed`; compile + memcheck exit 0; stdout: 91/91 pass | Focused memcheck **passes** |
| `native_tsan` | status `completed`; `bazel test --features=tsan` exit 0; retained stdout: **5/27 executed, 19 pass, 8 skipped**, `//score/socom/test/stress:socom_stress_test NO STATUS` | **Incomplete**: not the whole suite; stress target did not report |
| `focused_tsan` | status `findings_or_execution_failure`; compile exit 0, tests **exit 66**; stderr: `ThreadSanitizer: unexpected memory mapping` | **NOT CLEAN** — TSan aborted in this environment |
| `focused_clang_tidy` | status `findings_or_execution_failure`; `clang-tidy --verify-config` **exit 1**; blocker: "Native analyzer configuration incompatible; no replacement called MISRA" | clang-tidy **did not run** (configuration rejected) |
| `native_lint` | status `findings_or_execution_failure`; clang-tidy **exit 124 (timed out)**; ruff exit 0 | clang-tidy **not completed**; not "clean" |
| `focused_cppcheck` | status `findings_or_execution_failure`; exit 2; stderr contains only `passedByValue` **performance** advisories located in `registry_string_view.hpp` / `service_interface_identifier.hpp` (pre-existing headers; not the changed comparator) | No candidate-comparator defect; advisory findings out of scope |
| `codeql_security` | status `findings_or_execution_failure`; database/analyze exit 0; 30 findings, **all located in `.llm_tmp/googletest/...`**; `limits`: "Focused linked executable, not full target extraction; dependency findings retained" | Dependency-only; **no candidate-path security finding**, but applicability/completeness not established |
| `codeql_misra` | status `findings_or_execution_failure`; exit 0; large finding set dominated by vendored googletest (`gtest.cc` etc.); `misra_mapping.rst` is `:status: draft` | **Not a MISRA verdict**; rule↔query mapping inactive |
| `format_precommit` | status `findings_or_execution_failure`; git-init/git-add exit 0; `bazel test //:format.check` **exit 124 (timeout)**; `pre-commit run --all-files` exit 0; **`reuse lint` exit 1** (2 files missing licensing: `.bazel_config`, `third_party/score_baselibs/restore_qnx8_poll_workaround.patch`); `bazel mod tidy` / lockfile exit 0 | Format check **not completed**; **reuse lint fails** on non-slice files |
| `secret_dependency_checks` | status `findings_or_execution_failure`; exit 1; `secret-findings.json` contains `generic-api-key`/`private-key` hits. The `generic-api-key` hits are **self-referential** (paths/snippets inside `.llm_tmp/overnight/obligations/*/result.json`); one `private-key` hit is in `quality/integration_testing/environments/qnx8_qemu/init_x86_64.build` | No confirmed secret in the six candidate paths; several out-of-scope hits and a pre-existing private-key-like artifact require human disposition |
| `native_traceability` | status `findings_or_execution_failure`; unit/component tests exit 0; `bazel run //:docs` **exit 2**; `//:traceability_gate` **exit 1** with stderr `Error: unsupported schema_version None (expected '2')` | Traceability gate **FAILED** |
| `native_docs` | status `findings_or_execution_failure`; `bazel run //:docs` **exit 2**; stderr shows the source-code linker aborts because no git remote is configured, and lists `RuntimeTest__…` / `ServiceInstanceIdentifierTest__…` as *"Tests missing some properties"* | Docs/needs export incomplete |
| `native_integration` | status `findings_or_execution_failure`; `bazel test --config=qemu-integration //quality/... //tests/integration_test/...` **exit 1** | QEMU integration **FAILED** |
| `native_performance` | status `findings_or_execution_failure`; benchmarks and profiling both **exit 124 (timeout)** | Performance **not measured** |
| `cross_compilation` | status `completed_with_blockers`; x86_64 and aarch64 builds exit 0; blocker: "QNX SDK entitlement and target execution not configured; no credential acquired" | Cross-builds OK; **QNX target not verified** |
| `tool_assurance` | status `completed_with_blockers`; tool inventory lists g++, clang++, clang-tidy, bazel, codeql, gcov, gcovr, cppcheck, clang-format, pre-commit, reuse, qemu, perf, valgrind, gitleaks all `available: true`; blockers: lexical metadata cannot prove semantic coverage; safety/QM applicability unknown; independent inspection required | Tools identified; **evaluation/qualification and approval not established** |
| `process_checks` | status `completed_with_blockers`; `test_macros` = 33 (`runtime_tests.cpp`) and 91 (`service_identifier_tests.cpp`); record properties `DerivationTechnique`, `Description`; blockers: metadata inventory cannot prove semantic requirement coverage | Metadata present; **requirement links absent** |
| `rework_progress` | status `completed`; `source_changed_this_round: false`, `rework_requested: false`, `stop_reason: "One complete pass requested; unresolved findings stay pending"` | This run is a review pass; unresolved findings remain |

**Net assessment.** Compiler diagnostics, the full native build, the native unit suite (including
`runtime_tests.cpp`), ASan/UBSan/LSan, focused memcheck and the native x86/aarch64 cross-builds are
green **in these local captures**. TSan, clang-tidy, cppcheck, CodeQL (security and MISRA),
format/reuse, docs, traceability, secret scanning, QEMU integration and performance are **not
clean**. Under the S-CORE rule, none of these may be reported as satisfying its obligation.

---

## 8. Manual coding checks (construct-by-construct)

**Method and limits.** `coding_guidelines.rst` (`:status: valid`) selects **MISRA C++:2023 designed
for C++17** and requires `score::Result`-based error handling, avoiding exceptions. Because
`misra_mapping.rst` is `:status: draft` with the rule table inactive, **no numbered MISRA rule is
asserted to "apply"** in the S-CORE sense; this is a manual construct inspection only. The
`inspection_checklist.rst` (`:status: draft`, blank) defines the intended slots `IMPL_01_01`…;
this draft is **input** to that inspection, not a filled checklist.

| # | Topic | Construct / reading | Disposition |
|---|-------|---------------------|-------------|
| MF-1 | Ordering | `Registry_string_view::operator<` is **content**-based while `operator==`/`std::hash` are **pointer**-based; consistency relies on `String_registry` interning by content | **Invariant to preserve** (not an observed defect) |
| MF-2 | Error handling | The comparator is **not declared `noexcept`** although it cannot throw and is called from a `noexcept` function (`runtime_impl.cpp:440`) | **Manual finding** — a source change would need authorization; adding it also removes one coverage `throw` edge |
| MF-3 | Documentation | `Construction_error::duplicate_service` is commented only "Service identifier already exists" (`error.hpp:55`), now narrower than the minor-ignoring key | **Manual finding** |
| MF-4 | Ordering | Key is deliberately ordering-only (no `operator==`/hash); future equality-container use must keep identity `(instance, id, major)` | Design note |
| MF-5 | Concurrency | The single-server assert is safe only while key identity == record identity; do not re-fine the key without re-examining concurrency | **Invariant to preserve** |
| MF-6 | Lifetime/teardown | Key-erase `Final_action` ordering determines erase-after-unregister behaviour | Recorded hazard (FMEA-3) |
| MF-7 | Initialization | The key is a non-default-constructible aggregate; the sole production use supplies both members | OK (static) |
| MF-8 | Lifetime | Non-owning views must not outlive `String_registry`; the static-destruction-order path is untested | Unresolved |
| MF-9 | Traceability | `DerivationTechnique`/`Description` set; `TestType`/`Verifies` unset (no verified identifier) | Unresolved (human); corroborated by docs run |
| MF-10 | Measurement | Focused identifier measurement 91/0 vs native `socom_test` pass; coverage branch 78.6 % | Unresolved (below platform goal) |

Additional documentation surfaces that diverge from the implemented semantics (recorded, not
applied): `Runtime::make_server_connector`'s doc says duplicates are judged by *"the
configuration.interface and instance parameters"* (`runtime.hpp:170-191`), but public
`Service_interface_identifier::operator==` includes `minor` while the registration key does not; and
the `duplicate_service` enum comment above (MF-3). Both are documentation edits requiring
authorization.

**No confirmed safety-relevant defect in the changed comparator was found by these manual checks.**
That is a statement about *static inspection*, not a compliance or safety claim.

---

## 9. Interface and traceability consistency

### 9.1 Requirement / interface inventory

The repository defines stakeholder `stkh_req__someip_gw__interoperability`, feature
`feat_req__tc8_conformance__conformance`, and eight `comp_req__tc8_conformance__*`; there is **no
`comp_req__socom__*`** and **no `:reqtype: Interface` need** for this slice. The component/feature
requirement indexes are placeholder toctrees. There is therefore no honest native requirement for
the key tests to link to.

### 9.2 Test metadata conformance

| Rule element | Recorded value | Verdict |
|--------------|----------------|---------|
| Record-properties mechanism | `RecordProperty` used in both candidate test files | **Met (mechanism)** |
| `DerivationTechnique` set, allowed value(s) | `boundary-values,equivalence-classes` (key); `design-analysis,equivalence-classes` (runtime) | **Met** |
| `Description` non-empty | present in both | **Met** (the key file uses one fixture-wide sentence — a quality observation) |
| `TestType` set | **absent in both** | **NOT MET** |
| `PartiallyVerifies`/`FullyVerifies` | **absent everywhere** | **Not set** — a Unit Test link must target a Component Requirement, and none exists |

`gd_req__verification_checks_extended` forbids `requirements-based` / `interface-test` `TestType`
without a real requirement/interface link; no honest link exists, and inventing one is prohibited.
Leaving `TestType` unset is therefore a **recorded incompleteness, not a pass** — and the retained
docs run independently reports these cases as *"Tests missing some properties"*.

### 9.3 Interface-name / design consistency

- The internal key type and `operator<` are consistent between header and `.cpp`, and the code
  comments accurately describe the implemented semantics.
- The **design documents are silent** on the registration key / version identity / duplicate-server
  rejection, and there is no requirement to trace to. The chain is broken at both ends:
  requirement → implementation (no `comp_req`); design → implementation (no design element);
  test → requirement/design (hence no honest `PartiallyVerifies`/`FullyVerifies` target).
- Public interface names (`Service_interface_identifier`, `Service_instance`) are unchanged; the
  key remains `impl/`-only, so no public UID/header surface changed.
- The docs/traceability gate ran and **failed**: `bazel run //:docs` exit 2 (no git remote for the
  source-code linker) and `bazel run //:traceability_gate` exit 1
  (`unsupported schema_version None (expected '2')`). A nonblocking/absent gate is **not**
  acceptance, and its failure is not evidence of a pass.

---

## 10. Remaining safety-analysis (FMEA / DFA) impact questions — drafted, not answered

This section is **draft input**. Per the task, this review **does not act as the independent
reviewer**, does **not** select a safety class (`safety_class: unknown`), does **not** accept risk
or deviations, and does **not** answer the human gate. Failure modes are stated as *possibilities to
be dispositioned*, not as accepted defects.

### 10.1 FMEA-style failure modes to disposition

| Id | Failure mode (local effect) | Potential system effect | Change-related? | Question for the authorized reviewer |
|----|-----------------------------|-------------------------|-----------------|--------------------------------------|
| FMEA-1 | The comparator's non-throwing contract is not expressed (`noexcept` absent, MF-2); if a compare component ever threw, `std::set::insert` inside the `noexcept` `make_server_connector` would terminate | Service offer aborts instead of returning a `Result` error | Pre-existing pattern, surfaced by the key path | Should `noexcept` be added, and does that alter the applicable MISRA/coding rationale? |
| FMEA-2 | Key identity and record-index identity could diverge again (future re-fining of the key) | Two servers for one record reach `ASSERT(!m_server)`; depending on `SCORE_LANGUAGE_FUTURECPP_ASSERT` semantics, terminate or silent overwrite | **The change closes this**; a future change could reopen it | Confirm key identity must stay `(instance, id, major)` as a concurrency/safety property, with a guard/regression |
| FMEA-3 | `Impl` member/`Final_action` ordering could release the key before the record is unregistered if `disable()` ever stops clearing `m_registration` | A new connector passes the duplicate gate, then the single-server assert is violated on enable | Pre-existing fragility; adjacent to key lifetime | Approve an explicit ordering guard/assert or a declaration-order fix |
| FMEA-4 | Key/registration views are non-owning; a key outliving `String_registry` (static destruction order) dangles | Undefined behaviour at or after process shutdown | Pre-existing contract | Is the registry-outlives-key contract a verified assumption, and is an ordered-shutdown regression required? |
| FMEA-5 | Enabled connector outliving its `Runtime`: the server-registration `Final_action` captures the destroyed `Service_record` | Use-after-free / dangling `m_runtime_mutex` | Pre-existing; the key's `weak_ptr` guard covers only the key erase | Decide whether an enabled connector may outlive the runtime; correct the contract/test or extend the guard |
| FMEA-6 | `Service_database` records are never erased | Monotonic memory growth over many distinct identities | Pre-existing, adjacent | Is permanent record retention acceptable for the target duty cycle, or is cleanup required? |
| FMEA-7 | Config minor wildcard `0xFFFFFFFF` narrows to `0xFFFF` and now collides with a concrete-minor server under the coarsened key | A previously distinct server configuration is rejected as `duplicate_service` (daemon logs and skips → silently unoffered service) | **Interaction introduced by the change** | Adjudicate wildcard representation/validation/error semantics; is the new collision intended? |
| FMEA-8 | A `duplicate_service` at a daemon boundary is logged and skipped | A collision surfaces as a silently unoffered service rather than an actionable failure | Pre-existing; widened by FMEA-7 | Confirm the desired externally observable behaviour before integration acceptance |
| FMEA-9 | TSan did not complete (focused exit 66 "unexpected memory mapping"; native only 5/27 executed) | Data races on the key/registration path remain unverified | Evidence gap, not a code change | What TSan evidence, on the real target/environment, is required to close concurrency verification? |

### 10.2 DFA-style dependency/impact questions

1. **Assert semantics dependency.** The outcome of `ASSERT(!m_server)` (terminate vs compiled-out
   overwrite) depends on `score_baselibs` `futurecpp`, external and undetermined here. *Question:*
   what is the qualified AoU for `SCORE_LANGUAGE_FUTURECPP_ASSERT`, and does a compiled-out build
   turn FMEA-2/FMEA-3 into silent state corruption?
2. **Interning dependency (MF-1).** Content-ordered `<` and pointer-based `==`/`hash` coincide only
   because `String_registry` interns by content. *Question:* is interning a verified invariant (with
   a regression), and what detects a break?
3. **Configuration-data flow.** Config → socom narrows `uint32 minor` → `uint16` unchecked at
   several conversion sites. *Question:* where is the wildcard/sentinel meant to be resolved, and
   what are the residual/accumulated effects of the `0xFFFF` collapse under the new key?
4. **Cross-component flow.** `make_server_connector` is a public virtual called by `someipd`,
   `gatewayd` and the IPC binding. *Question:* what is the impact of an earlier `duplicate_service`
   on the offer/discovery chain, and is that behaviour traceable to a requirement?
5. **Resource-lifetime flow (FMEA-6).** *Question:* what is the maximum distinct-identity
   population expected, and does permanent record retention meet it?
6. **Verification-independence flow.** All execution evidence is local and unprotected, and the
   author and reviewer roles are unfilled. *Question (process):* who is the independent approver,
   and what evidence closes the independence requirement?

### 10.3 Explicit non-answers

No severity (Critical/High/Medium/Low), no ASIL/QM selection, no FMEA/DFA acceptance, no risk
acceptance and no deviation decision is made in this draft. Those require a Quality Manager
together with a committer. The failure-mode list is review input for that role, not its output.

---

## 11. Obligations status (none satisfied)

### 11.1 Pinned state

`authority.json`: `engineering_acceptance: pending`, `human_reviews: unanswered`,
`safety_class: unknown`, `codeql_scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway; no
upload"`. Every `source-index.json` entry is `"native_acceptance": "not_inferred"`.

### 11.2 Status for this slice

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Freedom from compiler warnings & errors (100 %, criterion 9) | `verification_plan.rst` | **PARTIAL / NOT SATISFIED** — focused GCC exit 0 with empty stderr; full native build exit 0; Clang dependency deprecation block observed historically; no criterion-9 full-native measurement signed off |
| Static code analysis executed, findings classified | `code_analysis.rst`; SCA-classification requirement | **NOT SATISFIED** — clang-tidy did not complete (config rejected / timeout); CodeQL security dependency-only and incomplete extraction; MISRA mapping draft; cppcheck advisory-only; **no authorized classification** |
| Freedom from SCA critical/high (criterion 8) | `verification_plan.rst` | **NOT MEASURED** — no authorized classification |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` (`:status: draft`) | **UNKNOWN — NOT CLAIMED**; rule↔tool mapping inactive |
| Implementation inspection checklist `IMPL_01_01`… | `inspection_checklist.rst` (`:status: draft`) | **NOT FILLED** — this draft is input, not a filled inspection |
| Structural statement coverage goal | `verification_plan.rst` (criterion 1) | **MET for the focused TU only** — 36/36 lines; not signed off |
| Structural branch coverage goal | `verification_plan.rst` (criterion 2) | **NOT MET** — 11/14 = 78.6 %, below both QM 85 % and safety 100 %; no deviation accepted |
| Unit/component testing executed and recorded (criteria 6-7) | `verification_plan.rst` | **PARTIAL** — focused identifier 91/0; native `socom_test` PASSED (includes `runtime_tests.cpp`); all local/unprotected, no acceptance |
| Interface / requirements-based / resource / fault-injection test types | `verification_process.rst` | **NOT PERFORMED / applicability not inferred** — no harness |
| Boundary / equivalence derivation | `verification_process.rst` | **EXECUTED (focused) / PARTIAL** |
| Fuzzy testing technique | `verification_plan.rst` | **NOT EXECUTED / NOT CLAIMED** — no harness, no measurement |
| Linking tests to requirements via record properties | `verification_process.rst` | **PARTIAL** — `DerivationTechnique`/`Description` set; `TestType`/`Verifies` unset (no verified link); docs run confirms "missing some properties" |
| External AoUs verified | `verification_process.rst` | **NOT SATISFIED** — no integration/static verdict; no AoU register |
| Tool identification / evaluation / qualification | `tool_management.rst` | **IDENTIFIED, NOT QUALIFIED** — `tool_assurance` `completed_with_blockers` |
| Independence of verification / review | `verification_process.rst` | **NOT DONE** — human reviews unanswered |
| Docs / traceability gate | repository CI | **FAILED** — docs exit 2 (no git remote); traceability gate exit 1 (`schema_version None`) |
| Sanitizers | `code_analysis.rst` | **PARTIAL** — ASan/LSan/UBSan and memcheck pass; **TSan not clean/complete** |
| Secret / dependency checks | CI | **NOT CLEAN** — gitleaks exit 1; hits are out-of-slice (vendored/retained artifacts, plus a private-key-like QNX env file) |
| Format / reuse | CI | **NOT CLEAN** — format check timed out; `reuse lint` exit 1 (2 non-slice files) |
| QEMU integration | CI | **FAILED** — exit 1 |
| Performance | `verification_plan.rst` | **NOT MEASURED** — benchmarks/profiling timed out (124) |
| Cross-compilation | `development_plan.rst` | **PARTIAL** — x86_64/aarch64 build; QNX target not executed (blocker) |
| Obligation-collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **RETAINED, NOT PASSING** — mix of `completed`, `completed_with_blockers`, `findings_or_execution_failure` |
| Native acceptance | `source-index.json` | **`not_inferred` for every entry** |

**Explicit non-satisfaction statement.** The non-running/timeout tools (clang-tidy), the
dependency-only or incomplete CodeQL extraction, the draft/inactive MISRA mapping, the blank
inspection checklist, the failed docs/traceability/reuse/format gates, the incomplete TSan and
performance runs, the failed QEMU integration, the unverified external AoUs, the below-goal branch
coverage, the unknown safety class and un-inferred applicability, and the unanswered human reviews
mean **none of the checked obligations may be treated as satisfied**. A successful collection node
proves *retention*, not passing; here the retained results include explicit failures and non-runs.

---

## 12. What this draft deliberately does NOT claim

- No engineering acceptance, review approval, publication, or upload.
- No MISRA C++:2023 compliance and no statement that any numbered rule "applies" (mapping is draft).
- No safety class / ASIL / QM selection, no FMEA/DFA acceptance, no risk acceptance, no deviation.
- No claim that identifier-only / key-level tests are platform, feature or interface validation.
- No fuzzy-testing claim (no harness, no measurement).
- No invented native requirement or interface identifiers.
- No claim that TSan, clang-tidy, CodeQL, the format/reuse gate, the docs/traceability gate, the
  QEMU integration leg, or the performance benchmarks passed; each is blocked, incomplete, or failed.
- No assertion that the wider #84 public `Service_interface_identifier` restructure, FindService
  wildcard handling, or config minor-wildcard narrowing is in scope.

---

## 13. Files changed / notice preservation

This iteration wrote **only this report** (`.llm_tmp/overnight/reports/design_inspection_draft.md`).

| Candidate path | State | This iteration |
|----------------|-------|----------------|
| `score/socom/impl/service_identifier.hpp` | brace-balanced; line 39 blank; documents minor exclusion | **unchanged** (verified, §2) |
| `score/socom/impl/service_identifier.cpp` | `operator<` identity `(instance, id, major)`, minor excluded | **unchanged** |
| `score/socom/BUILD` | `testonly` `impl_service_identifier` exposure present | **unchanged** |
| `score/socom/test/unit/BUILD` | `socom_test` globs `*.cpp`; deps wired | **unchanged** |
| `score/socom/test/unit/runtime_tests.cpp` | minor-only regression present | **unchanged** |
| `score/socom/test/unit/service_identifier_tests.cpp` | 91-case key matrix present | **unchanged** |
| `.llm_tmp/overnight/reports/design_inspection_draft.md` | **new — this report** | written |

- No source, build, test, config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was created, edited, or
  deleted; every existing Apache-2.0 / SPDX header is untouched. Every file under
  `.llm_tmp/overnight/prior-reports/`, every earlier file under `.llm_tmp/overnight/reports/`, and
  every host/obligation artifact under `.llm_tmp/overnight/validation/` and
  `.llm_tmp/overnight/obligations/` was read only and preserved.
- The flagged header `score/socom/impl/service_identifier.hpp` retains its Apache-2.0/SPDX header
  (`:1-12`) and was left unchanged because it is already balanced (§2). The sibling `.cpp`, both
  BUILD files, and both candidate test files retain their Apache-2.0/SPDX headers.
- No licensed MISRA rule text is reproduced; only native rule/query identifiers, source hashes and
  file locations are cited.
- This report itself carries the Apache-2.0 header.

---

## 14. Pending human review checklist

- [ ] **Confirm §2:** `service_identifier.hpp` is brace-balanced (braces at `:19,:29,:32,:38`;
      line `:39` blank; net balance 0); the recorded "extra closing brace at line 39" is stale or
      refers to a different revision. No source correction is required in this checkout.
- [ ] **Resolve the instruction conflict:** "inspect and correct the actual source" vs. "only that
      report may be written"; confirm that inspection-only (with the source already correct) was the
      intended outcome, and locate any distinct "cancelled draft" revision if it still carries the
      brace.
- [ ] **Ratify the implementation-vs-specification reading (§3):** the bounded change follows the
      unaccepted issue-#84 direction `service id + major`; confirm it is intended, and that the
      public type / IPC / compatibility rules stay unchanged in this slice.
- [ ] **Confirm the design invariants (§4):** key identity must equal record identity so the
      single-server `ASSERT(!m_server)` stays unreachable; the registration-teardown ordering; the
      discovery semantics stay confined to the `std::set` gate.
- [ ] **Add the missing design documentation (§4.5, §9.3):** the registration-key identity
      (`instance + service id + major`, `minor` excluded), the duplicate-server rejection path and
      the public-vs-internal version asymmetry in `score/socom/docs/design/`, or record that the
      behaviour is intentionally undocumented.
- [ ] **Adjudicate the manual findings (§8):** MF-2 (`noexcept` on the comparator), MF-3
      (`duplicate_service` comment), MF-1 (interning invariant), MF-5 (key/record identity), MF-6
      (teardown order), MF-8 (view lifetime). Each source change needs authorization and a build/test
      cycle.
- [ ] **Author the missing requirement/interface links (§9):** add the `socom` component
      requirement(s) (and any feature/interface need) so `TestType` and the `PartiallyVerifies`/
      `FullyVerifies` links can be completed without invention; or record an approved
      tailoring/deviation. The docs run currently reports this slice as "missing some properties".
- [ ] **Complete and activate the MISRA mapping and the inspection checklist**
      (`misra_mapping.rst`, `inspection_checklist.rst`), and complete the mandated SCA
      classification by the Quality Manager together with a committer.
- [ ] **Repair and re-run the failing tools:** clang-tidy configuration/timeout; TSan
      (`unexpected memory mapping`) so the full suite runs under TSan; CodeQL full-target
      extraction; the docs/traceability gate (configure a git remote; fix `schema_version`);
      `format.check`; `reuse lint` (2 files missing licensing — confirm whether in scope); gitleaks
      disposition for the out-of-slice private-key-like QNX artifact; the QEMU integration leg; and
      the performance benchmarks.
- [ ] **Confirm the coverage position:** focused TU line 100 % / branch 78.6 % versus the platform
      85 %/100 % goals; decide whether to add branch cases or record an approved deviation. Do not
      re-report the repo CI threshold 73 as platform coverage.
- [ ] **Verify the external-component AoUs (§6)**, including the
      `SCORE_LANGUAGE_FUTURECPP_ASSERT` semantics and the FlatBuffers wildcard default, by
      integration test or static analysis.
- [ ] **Answer the drafted FMEA/DFA impact questions (§10)** as the authorized safety engineer /
      committer, selecting the safety class and recording risk/deviation decisions.
- [ ] **Schedule independent human review** (approver ≠ author) and record engineering acceptance;
      no compliance/safety claim may be made before that, and no report may be uploaded
      (`codeql_scope`: no upload).

---

*End of design-inspection draft. Local, unprotected, scoped. No engineering acceptance; human
reviews unanswered; full native runtime tests pending human adjudication; no MISRA compliance,
safety classification, FMEA/DFA acceptance, risk acceptance, or deviation is claimed, and this draft
does not act as the independent reviewer.*
