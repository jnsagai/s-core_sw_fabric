<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — MISRA C++:2023 applicability assessment (`misra_applicability`) review draft

**Document type:** review draft (pinned-requirement reading + licensed-source reading +
measured-CodeQL-result reading + MISRA C++:2023 applicability assessment)
**Date:** 2026-10-02
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version handling
in socom* (issue #84)
**Run:** branch `fabro/run/01M3YRJEGXNY6CB81T7TKW774B`
**Status:** local, unprotected, scoped. **No engineering acceptance exists. Human reviews are
unanswered. Full native runtime tests remain pending.** Every statement below is either a direct
static reading of this checkout / the retained artifacts under `.llm_tmp/overnight/`, or an
explicitly-labelled logical consequence. Nothing here is published, reviewed, accepted, or a full
native run. **No MISRA C++:2023 compliance is claimed.**

> **Tool / write boundary actually observed.** The permitted tools were `read_file`, `grep`,
> `glob`, and `write_file`; every read and the single write used only those. No `shell` command
> executed; one attempted `shell` call was rejected by the environment with the message
> *"Overnight tool/path boundary"* and performed no action. No delegation, no web access, no
> approval, no publishing, and no engineering acceptance was performed. **Only this report was
> written.** No source, build, test, config, `NOTICE`, `LICENSE`, `REUSE.toml`, or prior-report
> file was created, edited, or deleted.
>
> **Source-correction instruction vs. review-draft boundary.** The task records "a measured GCC
> syntax failure: an extra closing brace in `score/socom/impl/service_identifier.hpp` at line 39"
> and directs "Inspect and correct the actual source before expanding tests". Direct inspection of
> the *actual* checkout (§4) shows the header is **already brace-balanced** and line 39 is blank;
> the retained focused GCC compile exits `0`. The task's final sentence — *"This is a review draft:
> only that report may be written."* — forbids a source write in any case. The two instructions
> conflict; the conflict is recorded for the human reviewer (§11) and the source was left unchanged.

> **Non-satisfaction rule applied throughout.** A successful obligation-collection node means the
> results were **retained**, not that the checks **passed**. Missing tools, unknown applicability,
> incomplete extraction, and unanswered human reviews are **not** treated as satisfied. A draft
> rule mapping, an inactive CSV, and a default query suite that omits manual/audit obligations are
> recorded as gaps, not as passes.

---

## 0. Summary

1. **The governing MISRA C++:2023 requirement is valid; the rule mapping is a draft with no active
   CSV (§3).** `coding_guidelines.rst` is `:status: valid` and selects **MISRA C++:2023 with
   C++17** (`:30-36`, `:74`). `misra_mapping.rst` is `:status: draft` and its `csv-table` is
   **commented out**, referencing `_assets/misra_2023.csv` (`:26-31`); `glob **/_assets/**` and
   `glob **/*misra*` return no such CSV / no second mapping file. In-repo, therefore, **no MISRA
   rule is mapped to any tool**; the only active mapping evidence in the retained artifacts is the
   licensed CodeQL coding-standards pack's own annotations (§6, §7).
2. **Licensed source references are identified, and proprietary rule text is not reproduced
   (§6).** The measured run used the licensed **CodeQL coding-standards 2.61.0** pack and its
   `misra-cpp-default.qls` suite, under the recorded scope *"Public Apache-2.0
   eclipse-score/inc_someip_gateway only"* with **no upload** (`authority.json`; `codeql_misra/result.json`
   `licensing` block). Only rule identifiers, tool query IDs, and locations are cited; the MISRA
   rule statements themselves (licensed, proprietary) are deliberately not reproduced.
3. **The measured CodeQL MISRA result is real but scoped and incomplete (§7).** Database create and
   analyze both exit `0`; the suite loaded **218 compiled rule queries** and exported SARIF. The
   collector nonetheless records `status: findings_or_execution_failure` with three self-declared
   blockers — draft/incomplete applicability mapping, manual/audit obligations omitted, and
   pending compiled-query qualification/human deviations — and the extraction limit *"Focused
   linked executable, not full target extraction; dependency findings retained"*.
4. **Findings land in three buckets (§7).** (a) *Dependency* locations under
   `.llm_tmp/googletest/**` (not project code, not in scope). (b) *Candidate test file*
   `score/socom/test/unit/service_identifier_tests.cpp`, dominated by the gtest `TEST_F`
   macro-expansion artifact. (c) *Other project production* files in the focused build —
   `score/socom/impl/string_registry.cpp` (9 locations) and `score/socom/string_registry.hpp`
   (1 location) — which are **outside the six candidate paths but inside the repository**. No
   finding lands in `service_identifier.cpp`, `service_identifier.hpp`, `runtime_tests.cpp`,
   `service_interface_identifier.hpp`, or `registry_string_view.hpp`.
5. **Applicability is largely unresolved (§8).** The candidate slice's own two units are clean in
   this extraction, but the safety class is `unknown`, the mapping is unmapped, the extraction is
   focused, the manual/audit rules were not run, and the candidate test file's hits are
   framework-macro artifacts. **MISRA C++:2023 compliance is UNKNOWN and is not claimed.**
6. **No obligation is satisfied (§9).** Every `source-index.json` entry is
   `native_acceptance: not_inferred`; authority is `engineering_acceptance: pending`,
   `human_reviews: unanswered`, `safety_class: unknown`.

---

## 1. Binding, prior reports, host feedback, obligation artifacts

### 1.1 Issue and baseline

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` — *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:2-4` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` | `.llm_tmp/context/issue-snapshot.json:19-20` |
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |
| Branch | `fabro/run/01M3YRJEGXNY6CB81T7TKW774B` | environment |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**: service-instance identifier = `service id + major + minor + instance id`; service
identifier = `service id + major`; FindService = `service id + major + optional<minor> +
optional<instance>`; exclude `minor` and make it an instance property. There is no comment and no
acceptance record. Binding is **by baseline commit**, not by run HEAD.

### 1.2 Candidate paths (the only writable source paths)

From `.llm_tmp/context/candidate-files.json:1-25`, cross-checked against
`.llm_tmp/context/source-manifest.json`:

1. `score/socom/BUILD`
2. `score/socom/impl/service_identifier.cpp`
3. `score/socom/impl/service_identifier.hpp`
4. `score/socom/test/unit/BUILD`
5. `score/socom/test/unit/runtime_tests.cpp`
6. `score/socom/test/unit/service_identifier_tests.cpp` (baseline blob `null` — a **new** file)

`glob **/service_identifier.hpp` returns exactly one path, so there is no second, differently
braced header in this checkout. The focused CodeQL extraction compiled `service_identifier.cpp`,
`string_registry.cpp`, and `service_identifier_tests.cpp` (plus vendored googletest); it did **not**
compile `runtime_tests.cpp` or the full `//score/...` targets.

### 1.3 Prior reports read and preserved

- `.llm_tmp/overnight/prior-reports/` — 12 files, read and preserved (`scope.md`,
  `invariants.md`, `callsites.md`, `reproducer.md`, `key_fix.md`, `unit_matrix.md`,
  `ordering_tests.md`, `runtime_disabled.md`, `runtime_enabled.md`, `lifetime_tests.md`,
  `conversion_tests.md`, `test_metadata.md`).
- `.llm_tmp/overnight/reports/` — 20 files, read and preserved (`analyzer_plan.md`,
  `api_review.md`, `bazel_plan.md`, `callsites.md`, `compatibility.md`, `concurrency_review.md`,
  `conversion_tests.md`, `coverage_review.md`, `coverage_tests_repair.md`, `invariants.md`,
  `key_fix.md`, `lifetime_review.md`, `lifetime_tests.md`, `ordering_tests.md`, `reproducer.md`,
  `runtime_disabled.md`, `runtime_enabled.md`, `scope.md`, `test_metadata.md`,
  `tool_findings_repair.md`). This document adds `misra_applicability.md` (21st).

The most directly relevant prior report is **`tool_findings_repair.md`** (per-tool diagnostics and
the no-defect determination), with **`analyzer_plan.md`** for the analyzer-configuration and
tool/applicability gap register. Where those reports summarised an *earlier* `codeql_misra`
collection as "googletest + gtest-macro findings only", §7 below records the **re-collected**
result I read directly, which additionally flags repository production files
`string_registry.cpp`/`string_registry.hpp`.

### 1.4 Host validation feedback (`.llm_tmp/overnight/validation/`) — present, scoped, stale

| Artifact | Content |
|----------|---------|
| `check-result` | `0` (collector success marker only) |
| `measurement.json` | `origin: local_unprotected_measurement`, `initiator: Fabro host hook`, `engineering_acceptance: pending`, `full_native_tests: not_executed`, compiler `/usr/bin/x86_64-linux-gnu-g++-12`; `baseline_with_agent_tests` **85 tests / 28 failures / compile 0**; `candidate` **85 tests / 0 failures / compile 0** |
| `after.json` | 85 tests, 0 failures, 0 disabled, 0 errors |
| `before-*` / `after-*` captures | focused identifier TU, `g++-12 -std=c++17 -Wall -Wextra -Werror`; `after-compile.stderr` and `before-compile.stderr` empty |

The measurement is **focused and stale**: `process_checks/result.json` records **87** test macros in
`service_identifier_tests.cpp` and **33** in `runtime_tests.cpp` for the current tree, while the host
measurement compiled the earlier 85-case state and did **not** compile `runtime_tests.cpp` or any
Bazel target.

### 1.5 Obligation artifacts under `.llm_tmp/overnight/obligations/`

25 checks are retained, each `origin: local_unprotected_measurement`,
`engineering_acceptance: pending`, with `source_hashes` + `collector_identity`. Relevant here:
`codeql_misra`, `codeql_security`, `focused_cppcheck`, `focused_clang_tidy`, `compiler_diagnostics`,
`focused_coverage`, `focused_asan_lsan`, `focused_tsan`, `focused_memcheck`, `native_lint`,
`format_precommit`, `native_*`, `cross_compilation`, `process_checks`, `tool_assurance`,
`secret_dependency_checks`, `rework_progress`. `rework_progress` records
`source_changed_this_round: true`, `rework_requested: false`, stop reason *"One complete pass
requested; unresolved findings stay pending"*.

### 1.6 Pinned obligation sources

All nine `.llm_tmp/context/obligations/source-index.json` entries were read with `authority.json`:

| id | file | status |
|----|------|--------|
| `coding_guidelines` | `coding_guidelines.rst` | `:status: valid`; **MISRA C++:2023 with C++17** |
| `code_analysis` | `code_analysis.rst` | `:status: valid`; MISRA/ISO26262-based SCA |
| `misra_mapping` | `misra_mapping.rst` | **`:status: draft`; rule table commented out** |
| `verification_plan` | `verification_plan.rst` | `:status: valid`; test types, criteria 1–9 |
| `development_plan` | `development_plan.rst` | `:status: valid` |
| `tool_management` | `tool_management.rst` | `:status: valid`; identify/evaluate/qualify |
| `verification_process` | `verification_process.rst` | `:status: valid`; SCA classification |
| `verification_guideline` | `verification_guideline.rst` | `:status: valid` |
| `inspection_checklist` | `inspection_checklist.rst` | **`:status: draft`; blank template** |

`authority.json`: `codeql_scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload"`,
`engineering_acceptance: pending`, `human_reviews: unanswered`, `safety_class: unknown`,
`instruction: "Restart the failed queue for one complete pass through all obligations"`. Every
entry is `native_acceptance: not_inferred`.

---

## 2. What "applicable" means for this draft

Because `misra_mapping.rst` is a draft with no active CSV (§3), this report does **not** claim that
a MISRA C++:2023 rule is "applicable to the deliverable" in the process sense. It records, per
observed rule, only:

- **Rule identifier** (e.g. `6.5.1`) — from the licensed pack's directory / `external/misra/id/...`
  annotation, not from the S-CORE mapping;
- **Enforcement class implied by the pack** (the pack marks queries as decidable / undecidable and
  as required / advisory / mandatory; where I only observed the query fire I do not assert a class);
- **Where it landed** in the focused extraction;
- **Whether it can support a compliance statement** — here, **no**.

The applicable acceptance level (QM vs. safety) is also not selected (`safety_class: unknown`), so
even a clean automated result could not be translated into an acceptance decision.

---

## 3. Governing MISRA C++:2023 requirements (pinned)

### 3.1 Coding guidelines — valid, MISRA C++:2023 with C++17

`coding_guidelines.rst` (`:status: valid`, `:id: doc__cpp_coding_guidelines`, `:safety: ASIL_B`)
states at `:30-36` that S-CORE adheres to **MISRA C++:2023**, designed for C++17, and at `:74` that
**C++17 is the selected standard**. It states the further S-CORE rules relevant to any MISRA
assessment of this slice:

- Error handling via `score::Result`, avoid value-encoded errors, avoid throwing exceptions
  (they are hardwired to abort); aborts are a last resort (`:117-129`).
- C++20 features may be used only after explicit process-community evaluation (`:76-80`).

### 3.2 Code analysis — valid, MISRA-based SCA with mandated disposition

`code_analysis.rst` (`:status: valid`) requires a Static Code Analysis concept based on **MISRA and
ISO 26262** in accordance with the coding guidelines (`:30`), with a **rule mapping** to tool
rules/queries (`:32`), and states at `:51`: *"If for some technical reason any MISRA finding can
not be addressed it needs to be justified appropriately … and finally documented within the source
code."* The named tool set is clang-tidy + GCC/Clang compiler warnings + Coverity (`:34-47`).

### 3.3 The rule mapping — draft, no active CSV

`misra_mapping.rst`:

- `:status: draft` (`:20`), `:safety: ASIL_B`, `:version: 1`.
- The only content is a `csv-table` directive **inside an RST comment block** (`:26-31`):
  `.. csv-table:: MISRA C++:2023 Rule Mapping` with `:file: _assets/misra_2023.csv`.
- `glob **/_assets/**` returns **no entries**, and `glob **/*misra*` returns only
  `misra_mapping.rst`; the referenced CSV is **absent** and the table is **inactive**.

**Consequence:** in-repo, there is **no active linkage from MISRA rules to tool rules/queries**.
The mapping is effectively *unmapped for every MISRA rule* until the draft is completed, the CSV is
supplied, and the document reaches `:status: valid` by an authorized change.

### 3.4 Verification process — static analysis is a verification method and its findings must be classified

- `verification_plan.rst:175-178` lists **`static-code-analysis`** as a verification method
  (`TestType`) applicable at Unit/Component level for QM & ASIL B.
- `verification_plan.rst:328-335`: criterion 8 = freedom from static code analysis violations
  (critical/high) at 100 %; criterion 9 = freedom from compiler warnings & errors at 100 %.
- `verification_process.rst:228-248` (`gd_req__verification_sca_classification`) requires SCA
  findings to be classified Critical / High / Medium / Low, by the tool suggestion or manually by
  the quality manager together with a committer.
- `verification_process.rst:20-54` (`gd_req__verification_link_tests*`) fixes the test record
  properties (`TestType`, `DerivationTechnique`, `Description`, `Verifies`).

### 3.5 Tool management — identification / evaluation / qualification

`tool_management.rst` (`:status: valid`) requires every tool to be identified, evaluated
(tool confidence level) and, where the TCL is LOW, **qualified**, with a released Tool Verification
Report (`:32-37`, `:87-153`). No MISRA-capable tool has a released tool verification report for
this slice, so tool confidence is not established here.

---

## 4. Recorded GCC syntax failure: inspection of the actual source

`score/socom/impl/service_identifier.hpp` read directly from the working tree is **brace-balanced**
(40 lines):

| Line | Content | Role |
|------|---------|------|
| 14–15 | `#ifndef SRC_SOCOM_SRC_SERVICE_IDENTIFIER` / `#define …` | include guard |
| 17 | `#include "score/socom/service_interface_identifier.hpp"` | include |
| 19 | `namespace score::socom {` | one opening brace |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

`grep '[{}]'` on the file returns exactly `:19`, `:29`, `:32`, `:38` — two openers, two closers,
net balance `0`; there is no third, unmatched closing brace and line 39 is blank. This matches the
**later** prior reports (`key_fix.md` §2, `tool_findings_repair.md` §2, `analyzer_plan.md` §2); the
task's "extra closing brace at line 39" matches the **earliest** reports' split-form close
(`}  // namespace socom` + `}  // namespace score`), which the `reproducer` iteration corrected.

Retained tool corroboration:

- `obligations/compiler_diagnostics/result.json`: `gcc-compile` **exit 0**, `gcc-tests` **exit 0**
  (focused TU including `service_identifier.cpp` and `service_identifier_tests.cpp`);
  `clang-compile` **exit 1**.
- The only retained nonzero compiler result is a **clang** `-Werror` failure from the vendored
  googletest / libstdc++ 12 headers (`clang-compile.stderr:4`,
  `-Wdeprecated-declarations` on `get_temporary_buffer`), **outside the six candidate paths**.

**Disposition.** The described defect is **not present** in this checkout; the minimal historical
repair (replacing a split double close with the single nested `}  // namespace score::socom`) would
be a no-op at best and a compile break at worst. No source edit was made (and the review-draft
boundary forbids one). If a distinct "cancelled draft" revision still carries the brace, it is not
this file and must be located and corrected by an authorized iteration.

---

## 5. Measurement status of the MISRA-relevant tools

| Check | Retained result | Reading |
|-------|-----------------|---------|
| CodeQL MISRA | `codeql_misra/result.json`; `analyze.stderr` | create **exit 0**, analyze **exit 0**; **218** compiled queries loaded; SARIF exported; status `findings_or_execution_failure` (findings + limits + blockers) |
| CodeQL security | `codeql_security/result.json` | retains findings; per `tool_findings_repair.md` §4.5 all `uri`s under `.llm_tmp/googletest/**` |
| clang-tidy (focused) | `focused_clang_tidy/result.json`; `native-config.stderr` | **exit 1** on `--verify-config`; blocker *"Native analyzer configuration incompatible; no replacement called MISRA"* — **no TU analysis, not "clean"** |
| cppcheck (focused) | `focused_cppcheck/result.json`; `cppcheck.stdout` | **exit 2**; 19 `passedByValue` (performance) findings, all in headers outside the candidate paths (`registry_string_view.hpp`, `service_interface_identifier.hpp`) |
| GCC focused compile/tests | `compiler_diagnostics/result.json` | compile **exit 0**, tests **exit 0** |
| Clang focused compile | `compiler_diagnostics/result.json` | **exit 1** on a dependency deprecation under `-Werror` |
| native lint / coverage / docs / traceability / sanitizers / tsan / performance / integration; cross-compilation; format/pre-commit | `native_*/result.json`, `cross_compilation/result.json`, `format_precommit/result.json` | **exit 127** — `/tmp/s-core-001/bin/bazel` missing; `pre-commit`, `reuse`, `clang-format`, `valgrind`, `gitleaks` also unavailable |
| host validation | `validation/check-result` = `0`; `measurement.json`; `after.json` | candidate 85 / 0 / compile 0; `full_native_tests: not_executed` |

None of these is a MISRA measurement except the CodeQL MISRA extraction; the others are context for
the non-satisfaction statement.

---

## 6. Licensed source references (and why rule text is not reproduced)

| Aspect | Value | Source |
|--------|-------|--------|
| Licensed analysis pack | **CodeQL coding-standards `2.61.0`**; `qlpack.yml` sha `3d06c897…` | `codeql_misra/result.json:223-224` |
| Query suite | `codeql-suites/misra-cpp-default.qls`, sha `8b41feb7…` | `codeql_misra/result.json:224,277` |
| Query engine | CodeQL `2.21.4`, sha `d38df35e…` | `codeql_misra/result.json:222` |
| Recorded licensing scope | *"Public Apache-2.0 eclipse-score/inc_someip_gateway only"* | `codeql_misra/result.json:302-305` |
| Recorded licensing source | `https://docs.github.com/en/code-security/concepts/code-scanning/codeql/codeql-cli` | `codeql_misra/result.json:304` |
| Authority scope | `codeql_scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload"` | `.llm_tmp/context/obligations/authority.json` |

The **MISRA C++:2023 rule text is licensed / proprietary**. This report therefore cites only:

- **MISRA rule identifiers** and **CodeQL rule/query identifiers** and their **locations**; and
- the pack's own machine-readable annotations (e.g. `external/misra/id/rule-6-5-1`,
  `external/misra/enforcement/decidable`, `external/misra/obligation/...`) that CodeQL attaches to
  each rule.

It does **not** reproduce the standard's rule statements, rationale, or examples. A short
paraphrase of the tool's own check name (already published by the tool) is used only as a label; the
authoritative text must be read in the licensed MISRA C++:2023 document.

The mapping used here is therefore the **licensed pack's internal mapping** (query → MISRA rule
identifier), **not** the S-CORE `misra_mapping.rst`, which is inactive (§3.3). This is a
methodological substitution that a reviewer must accept before the assessment has process standing.

---

## 7. Measured CodeQL MISRA results (as retained)

### 7.1 Run shape

- `database create --language=cpp --command=<focused codeql-build.sh> --threads=1 --ram=6000`
  → **exit 0**.
- `database analyze <db> misra-cpp-default.qls --format=sarif-latest` → **exit 0**;
  `analyze.stderr` shows `Loaded … [1/218] … [218/218]` compiled queries, per-query evaluation, and
  `Exported results to SARIF`.
- `status: findings_or_execution_failure`; blockers (`result.json:235-239`):
  *"MISRA applicability/mapping draft and incomplete"*, *"Default suite omits manual/audit
  obligations"*, *"Compiled query qualification and human deviations pending"*.
- Limit (tail, `limits`): *"Focused linked executable, not full target extraction; dependency
  findings retained"*.
- Findings are ordered by query; the `result.json` is ~117.9k lines, dominated by dependency
  locations. **Counts below for repository files are exact (direct `grep`/`read_file`); the
  dependency and test-file sets are described by rule and sample location, not claimed as an
  exhaustive per-rule census** (no counting tool was available under the read-only boundary).

### 7.2 Findings on repository production files (outside the six candidate paths)

| MISRA rule | CodeQL query id | Location(s) | Note |
|-----------|-----------------|-------------|------|
| **6.7.1** | `cpp/misra/local-variable-static-storage-duration` | `score/socom/impl/string_registry.cpp:66`, `:71` | the two function-local `static String_registry registry;` singletons (deliberate) |
| **7.0.1** | `cpp/misra/no-conversion-from-bool` | `score/socom/impl/string_registry.cpp:28,42,45,59,62` | `bool` pairing in the `insert` return pairs; also fires on the candidate test file |
| **0.1.1** | `cpp/misra/unnecessary-write-to-local-object` | `score/socom/impl/string_registry.cpp:23`, `:35` | the `std::lock_guard const locked{…}` RAII locals; also fires on googletest `gtest.cc` |
| **21.6.1** | `cpp/misra/dynamic-memory-should-not-be-used` | `score/socom/string_registry.hpp:37` | reported at the `String_registry` class (member `std::forward_list<std::string>`); also fires on `gtest-filepath.h` |

Evidence: `codeql_misra/result.json:35692-35727` (6.7.1); `:74543-74640` (7.0.1);
`:117412-117449` (0.1.1); `:67541-67556` (21.6.1). Rule numbers are taken from the licensed pack's
query paths, confirmed in `analyze.stderr` (e.g. `RULE-6-7-1/LocalVariableStaticStorageDuration`,
`RULE-7-0-1/NoConversionFromBool`, `RULE-0-1-1/UnnecessaryWriteToLocalObject`,
`RULE-21-6-1/DynamicMemoryShouldNotBeUsed`).

These are **repository production files but not candidate paths** for this slice. They are recorded
because an honest MISRA assessment of the focused extraction must not omit them, and because the
prior `tool_findings_repair.md` summary did not mention them.

### 7.3 Findings on the candidate test file (framework-macro artifacts)

| MISRA rule | CodeQL query id | Location(s) | Note |
|-----------|-----------------|-------------|------|
| **6.5.1** | `cpp/misra/external-linkage-not-declared-in-header-file-misra` | `score/socom/test/unit/service_identifier_tests.cpp` — many `TEST_F` lines (samples `:2012`, `:1982`, `:1929`, `:1882`, …, `:671`) | gtest `TEST_F` expansion synthesises externally-linked registration entities; **not authored in the test body** |
| **9.3.1** | `cpp/misra/switch-body-compound-condition` | same file, e.g. `:672-673`, `:640`, `:636`, `:560`, `:531` | macro/defaulted-body artifact |
| **7.0.1** | `cpp/misra/no-conversion-from-bool` | same file (e.g. around `:74649` in the result) | as above |

Evidence: `codeql_misra/result.json:348…` (6.5.1), `:11455…` and `:11716…` (9.3.1). These are
recorded as **remaining findings requiring an accepted human deviation or macro-aware tooling**
(`tool_findings_repair.md` §4.6, `analyzer_plan.md` G8); they cannot be fixed inside the authored
test body, and silently suppressing the rule is prohibited.

### 7.4 Findings in dependencies (not project code)

`cpp/misra/copy-and-move-assignments-shall-handle-self-assignment` (Dir **15.8.1**) at
`.llm_tmp/googletest/googletest/include/gtest/internal/gtest-filepath.h:80,84`;
`dynamic-memory-should-not-be-used` and many others across
`.llm_tmp/googletest/googletest/{include,src}/**` (e.g. `gtest.cc`, `gtest.h`,
`gtest-death-test.cc`, `gtest-port.h`). These are the vendored test framework, retained only
because the extraction is focused; they are **not** project code and do **not** bear on the slice's
compliance.

### 7.5 The candidate keys units are clean in this extraction

Direct `grep` confirms **zero** CodeQL MISRA locations in `score/socom/impl/service_identifier.cpp`,
`score/socom/impl/service_identifier.hpp`, `score/socom/service_interface_identifier.hpp`,
`score/socom/registry_string_view.hpp`, or any other `score/socom/impl/*` file except
`string_registry.cpp`. `runtime_tests.cpp` has **zero** because it was **not extracted**. "Clean"
here means "no query produced a result in a focused, incomplete extraction" — **not** a compliance
statement.

---

## 8. Applicability assessment (bounded slice)

### 8.1 What is covered

| Area | Status | Evidence |
|------|--------|----------|
| `service_identifier.cpp` / `service_identifier.hpp` (slice production code) | **No finding** in the focused extraction; GCC focused compile+tests exit 0 | §4, §7.5 |
| `service_identifier_tests.cpp` (slice test code) | Findings present but are **gtest macro-expansion artifacts** | §7.3 |
| `string_registry.cpp` / `string_registry.hpp` (focused-build production, outside slice) | Findings present (6.7.1, 7.0.1, 0.1.1, 21.6.1) | §7.2 |
| Dependency (`googletest`) | Findings present; out of scope | §7.4 |

### 8.2 Unmapped rules (explicit)

Because `misra_mapping.rst` is a draft with **no active CSV** (§3.3):

- **Every** MISRA C++:2023 rule is **unmapped in-repo**. There is no S-CORE-authorised statement
  that a given MISRA rule is covered by `misra-cpp-default.qls`, by clang-tidy, by a compiler, or by
  a manual check.
- The only active mapping is the licensed pack's built-in query annotations; those cover **only the
  compiled subset** of rules the pack ships, which is **not** a statement of applicability to this
  unit or this safety class.
- The **218** loaded queries do **not** represent the complete MISRA C++:2023 rule set; they are one
  vendor's compiled subset, and the collector itself records that the default suite
  **omits manual/audit obligations**.

### 8.3 Manual / audit / undecidable rules (explicit)

- The collector's own blocker *"Default suite omits manual/audit obligations"* means the
  **manual/audit** class of MISRA obligations was **not executed** and cannot be inferred from this
  extraction. It remains **manual and unperformed**.
- MISRA marks many rules as **undecidable** (the pack annotates some queries
  `external/misra/enforcement/undecidable`); an automated query cannot by itself discharge those.
  No manual review filled that gap here (`inspection_checklist.rst` IMPL_02_02 is a **draft, blank
  template**).
- `code_analysis.rst:51` requires any unaddressed MISRA finding to be **justified and documented in
  the source**; no such in-source justification exists for the §7.2 / §7.3 findings, and adding one
  is outside this review's write boundary.

### 8.4 Not extracted / not assessed (explicit "unknown", not "clean")

- `score/socom/test/unit/runtime_tests.cpp` — not in the focused extraction.
- The full `//score/...` (and `//tests/...`) target set — `native_lint`/`native_build`/`native_tests`
  exit 127; **not** analysed.
- clang-tidy on the changed units — config rejected (`--verify-config` exit 1); **not run**.
- Any rule the default suite does not implement, and any rule whose applicability depends on the
  (unselected) safety class — **unknown**.

### 8.5 Acceptance-level dependency

The applicable acceptance level is not selected (`safety_class: unknown`,
`focused_coverage` `safety_class: "unknown_requires_authorized_selection"`). Criterion 8 demands
"no remaining critical/high findings" (100 %) and criterion 9 demands 100 % freedom from compiler
warnings/errors; without a selected class and a completed mapping, applicability of even the
automated results to the deliverable is **not authorised**.

---

## 9. Explicit non-claim and obligations status

**MISRA C++:2023 compliance for this slice is UNKNOWN and is NOT claimed.** The reasons are
cumulative:

1. The in-repo rule mapping is a **draft with no active CSV** (§3.3) — all rules are unmapped.
2. The CodeQL extraction is **focused and incomplete**; dependency and macro findings are retained,
   and `runtime_tests.cpp`/the full target were not analysed (§6, §7, §8.4).
3. The **manual/audit** obligations and **undecidable** rules were not executed (§8.3).
4. clang-tidy — a tool named by `code_analysis.rst` — **did not run** (§5).
5. The candidate test-file hits are **framework-macro artifacts**, not authored defects, and need an
   accepted human deviation (§7.3).
6. The **safety class is unknown**, so the applicable acceptance level is unselected (§8.5).
7. No tool has a released **tool qualification** report for this use (§3.5).
8. Human reviews are **unanswered** and engineering acceptance is **pending** (§1.6).

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` (draft) | **UNKNOWN — NOT CLAIMED** |
| MISRA rule→tool mapping | `misra_mapping.rst`; `code_analysis.rst:32` | **DRAFT / INACTIVE** — no CSV, no active linkage |
| Static code analysis, findings classified Critical/High/Medium/Low | `verification_process.rst:228-248` (`gd_req__verification_sca_classification`) | **NOT DONE** — no authorised classification; clang-tidy not run |
| Freedom from SCA critical/high findings (criterion 8) | `verification_plan.rst:328-331` | **NOT MEASURED to goal** — focused findings unresolved |
| Freedom from compiler warnings & errors (criterion 9) | `verification_plan.rst:332-335` | **PARTIAL** — focused GCC exit 0; focused clang blocked on a dependency; warnings-as-errors disabled by default |
| `static-code-analysis` verification method recorded as TestType | `verification_plan.rst:175-178`; `verification_process.rst:20-54` | **NOT RECORDED** — test metadata intentionally omit TestType (no invented identifiers) |
| Manual/audit MISRA rules | collector blocker; `inspection_checklist.rst` (draft) | **NOT EXECUTED / NOT FILLED** |
| Tool identification / evaluation / qualification | `tool_management.rst:32-153` | **NOT ESTABLISHED** |
| Independence of verification / review | `verification_process.rst:141-152` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Native acceptance | `.llm_tmp/context/obligations/source-index.json` | **`not_inferred` for every entry** |

**Explicit non-satisfaction statement.** Missing tools, unknown applicability, the draft/inactive
mapping, incomplete extraction, unresolved framework/dependency findings, the unselected safety
class, and the unanswered human reviews mean **none of the checked obligations may be treated as
satisfied**. The retained CodeQL MISRA result shows *retention*, not passing.

---

## 10. Notice preservation

- No source, build, test, config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was created, edited, or
  deleted by this iteration; **only this report was written**.
- The flagged header `score/socom/impl/service_identifier.hpp` retains its Apache-2.0/SPDX header
  (`:1-12`) and was left unchanged because it is already balanced (§4).
- All 12 files under `.llm_tmp/overnight/prior-reports/` and all 20 earlier files under
  `.llm_tmp/overnight/reports/` were preserved unchanged; this document is the 21st `reports/`
  entry.
- This report carries the Apache-2.0 header. No licensed MISRA rule text is reproduced (§6).

---

## 11. Pending human review checklist

- [ ] **Resolve the instruction conflict (§4):** the recorded brace defect is not present in the
      actual source and the review-draft boundary forbade a source write; confirm that writing only
      this report was intended, and locate/correct any distinct "cancelled draft" revision that
      still carries the brace.
- [ ] **Complete and activate the MISRA mapping (§3.3):** fill `misra_2023.csv`, uncomment the
      `csv-table`, and raise `misra_mapping.rst` from `:status: draft` to `valid` by an authorised
      change; until then all rules are unmapped.
- [ ] **Authorise the licensing/mapping substitution (§6):** confirm that using the licensed CodeQL
      coding-standards pack's internal rule annotations (rather than the inactive S-CORE mapping) is
      acceptable evidence, and confirm the "public Apache-2.0 repo, no upload" scope.
- [ ] **Decide the CodeQL posture:** run a **full-target** extraction (not a focused executable),
      include `runtime_tests.cpp` and the remaining units, and qualify the compiled queries.
- [ ] **Disposition the repository production findings (§7.2)** in `string_registry.cpp` /
      `string_registry.hpp` (rules 6.7.1, 7.0.1, 0.1.1, 21.6.1): justify in-source per
      `code_analysis.rst:51`, refactor, or record an accepted deviation — by an authorised change.
- [ ] **Disposition the candidate test-file findings (§7.3)** (rule 6.5.1 and others) as gtest
      `TEST_F` macro artifacts: record an accepted deviation or adopt macro-aware tooling; do not
      patch the test framework or silently suppress the rules.
- [ ] **Execute and record the manual/audit MISRA obligations** (§8.3) and fill the implementation
      inspection checklist `IMPL_02_01`/`IMPL_02_02` (`inspection_checklist.rst`, currently draft).
- [ ] **Record the SCA finding classification** (Critical/High/Medium/Low) per
      `gd_req__verification_sca_classification` by the quality manager together with a committer.
- [ ] **Select the safety class** so the applicable acceptance level (QM vs. safety) and the QM
      85 % / safety 100 % coverage goals can be applied.
- [ ] **Repair and run clang-tidy** (`.clang-tidy` `Checks: >` folding and the two stale check
      identifiers) and add `static-code-analysis` as a `TestType` where identifiers exist — no
      invented links.
- [ ] **Schedule independent human review** (`gd_req__verification_independence`, approver ≠ author)
      and record engineering acceptance; no compliance claim may be made before that.
- [ ] **Keep the wider #84 public `Service_interface_identifier` restructure, FindService wildcard,
      and the config minor-wildcard narrowing out of this bounded slice** until separately accepted.

---

*End of review draft. Local, unprotected, scoped. No engineering acceptance; human reviews
unanswered; full native runtime tests pending.*
