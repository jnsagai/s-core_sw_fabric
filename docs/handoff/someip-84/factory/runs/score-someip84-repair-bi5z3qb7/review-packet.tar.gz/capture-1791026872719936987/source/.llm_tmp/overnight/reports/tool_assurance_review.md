<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — tool assurance review (duplicate-server registration key)

**Document type:** review draft — tool identification register, exact
versions/configuration/digests, tool-impact & error-detection question sheet,
confidence/qualification evidence inventory, and non-satisfaction record
**Date:** 2026-10-03
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version handling in
socom* (issue #84)
**Run / branch:** `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ`
**Verified baseline commit:** `f8a196c3b16d5172d898394ab99b0ed81346d63d`
(`.llm_tmp/context/source-manifest.json:3`)
**Status:** local, unprotected, scoped. **No engineering acceptance exists. Human reviews are
unanswered. Full native runtime tests remain pending.** Tool *execution* is not tool
*qualification*: everything below is an identification/evaluation **draft for owner decision**,
never an accepted result.

> **Tool / write boundary actually observed.** This iteration used only `read_file`, `grep`,
> `glob`, and `write_file`. No `shell`, no delegation, no web access, no approval, no publishing,
> and no engineering acceptance. The task's explicit final sentence — *"This is a review draft:
> only that report may be written."* — governs the write boundary; accordingly **exactly one file
> was written — this report.** No source, build, test, config, `NOTICE`, `LICENSE`, `REUSE.toml`,
> or prior-report file was created, edited, or deleted. Every prior report under
> `.llm_tmp/overnight/prior-reports/` and every earlier file under
> `.llm_tmp/overnight/reports/` was preserved unchanged.

> **Instruction conflict, recorded not silently resolved.** The task also says *"Inspect and
> correct the actual source before expanding tests."* §2 shows the named file
> (`score/socom/impl/service_identifier.hpp`) is already brace-balanced and line 39 is blank, so
> there is nothing to correct on the facts; and the write boundary permits only this report, so a
> source write is not permitted in any case. No test was expanded. The conflict is carried to the
> human reviewer (§11).

> **Non-satisfaction rule applied throughout.** A successful obligation-collection node means the
> results were **retained**, not that the checks **passed**. Missing tools, unknown applicability,
> incomplete extraction, and unanswered human reviews are **not** treated as satisfied. Tool
> execution alone does not qualify any tool; owner acceptance stays pending. A tool that produced
> no finding because it did not run (or timed out, or rejected its configuration) is recorded as
> *"not run"*, never as *"clean"*.

---

## 0. Summary

1. **This checkout is materially better equipped than the earlier tool-assurance draft, and the
   earlier draft's central claim — eight missing tools and a blanket `exit 127` for every native
   obligation — is superseded.** The current `tool_assurance` collector inventories **15 tools,
   all `available: true`**, including Bazel, Valgrind, gitleaks, clang-format, pre-commit and
   reuse (§3.1). The native Bazel legs therefore executed: `native_build`, `native_tests`
   (build-only), `native_coverage`, `native_sanitizers` (ASan/LSan/UBSan), `native_tsan`,
   x86_64+aarch64 `cross_compilation` all report a retained `exit 0` (§6). **This is more
   retention, not more acceptance.**
2. **Tool identification is possible for a mixed set of collector tools and repository-pinned
   tools, and the two sets disagree on versions.** The collector ran GCC `12.3.0`, Clang /
   clang-tidy / clang-format `19.1.7`, Bazel `8.6.0`, CodeQL `2.21.4`, gcov `12.3.0`, gcovr `5.0`,
   cppcheck `2.7`, pre-commit `4.6.2`, reuse `6.2.0`, QEMU `6.2.0`, perf `6.8.12`, Valgrind
   `3.18.1`, gitleaks `8.30.1` (§3.1). The repository pins a different toolchain: LLVM `22.1.7`
   via `toolchains_llvm 1.8.0` and GCC `12.2.0` via `score_bazel_cpp_toolchains 1.0.3`, with QCC
   `12.2.0`/SDP `8.0.4`, Bazel `8.6.0`, GoogleTest `1.18.0` (§3.3). **This drift is itself a
   tool-assurance finding:** the clang-tidy binary that rejected the repo `.clang-tidy` is three
   major versions older than the pinned one, and the host GCC minor differs from the pin.
3. **The only analyzers that ran to completion produced no in-scope finding.** clang-tidy
   `19.1.7` rejected the repo `.clang-tidy` (`--verify-config` exit `1`, 15 warnings) so it
   analyzed **nothing**; the native `//:clang-tidy.check` leg **timed out** (`124`); cppcheck
   flagged only `passedByValue` notes in included headers outside the six candidate paths; CodeQL
   security flagged only vendored googletest; CodeQL MISRA is a focused, draft-mapping run whose
   in-scope-looking hits are gtest macro/header artifacts (§6).
4. **Named-but-unavailable / not-adopted capability remains a blocker.** Coverity is named by
   `code_analysis.rst` but is **not installed/adopted**; the QNX SDP entitlement/credentials are
   **not configured** (so QCC target execution is unmeasured); there is **no adopted vulnerability
   database or dependency-scan receipt**; and the CodeQL runs are collector-only with no
   repository-CI receipt (§3.5, §6).
5. **No tool has a Tool Verification Report, an impact rating, an error-detection rating, a
   confidence level, or a qualification argument in the retained evidence.**
   `tool_management.rst` requires each tool to be identified, evaluated and — when TCL is LOW —
   qualified and then *released* by an authorized human. §5 and §7 draft the questions; they are
   deliberately left **unanswered**, because the safety class is `unknown`,
   `human_reviews: unanswered`, and `engineering_acceptance: pending` (§1.4).
6. **No obligation in this slice is satisfied.** Every `source-index.json` entry is
   `native_acceptance: not_inferred`; the retained tool results are scoped/blocked; the
   qualification and release steps are human-only and pending (§10). The current `rework_progress`
   collector records `source_changed_this_round: false`, `rework_requested: false`, stop reason
   *"One complete pass requested; unresolved findings stay pending"*.

---

## 1. Binding, sources read, host feedback

### 1.1 Issue and baseline

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` — *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:2-4` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG`, created/updated `2026-04-14T13:23:24Z` | `.llm_tmp/context/issue-snapshot.json:8,19-20` |
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |

The issue body is a **design proposal, not an accepted obligation**
(`.llm_tmp/context/issue-snapshot.json:5`). Binding is by baseline commit, not by run HEAD.

### 1.2 Bounded slice and the six candidate paths

The bounded slice is the **duplicate-server registration key**: `Service_instance_identifier`
identity is `(instance, service id, major)` and `minor` is deliberately excluded, matching the
minor-ignoring `Service_database` index. Directly read this iteration:

- `score/socom/impl/service_identifier.hpp:29-32` — `Service_instance_identifier{interface, instance}`;
  out-of-line `operator<` declaration at `:35`.
- `score/socom/impl/service_identifier.cpp:20-30` — `operator<` over
  `std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major)`.

Six candidate paths are named by `.llm_tmp/context/candidate-files.json:1-25`:
`score/socom/BUILD`, `score/socom/impl/service_identifier.cpp`,
`score/socom/impl/service_identifier.hpp`, `score/socom/test/unit/BUILD`,
`score/socom/test/unit/runtime_tests.cpp`, `score/socom/test/unit/service_identifier_tests.cpp`.
`glob **/service_identifier.hpp` returns exactly one path, so there is no second, differently
braced copy of the header in this checkout.

### 1.3 Prior reports read and preserved

`.llm_tmp/overnight/prior-reports/` (38 files) and `.llm_tmp/overnight/reports/` (32 files
present before this write) were read/grepped and preserved. The most relevant to tool assurance
are the **current-run** `reports/tool_findings_repair.md` (per-tool diagnostics vs. the candidate
paths), `reports/analyzer_plan.md` (native analyzer configuration + changed-unit exposure), and
`reports/bazel_plan.md` (pinned native invocations, retained exit codes, and the availability
change). Their conclusions are consistent with this draft: no executed *accepted* native
measurement, clang-tidy never ran, and no qualification exists.

### 1.4 Authority / pinned process sources

`.llm_tmp/context/obligations/authority.json`: `engineering_acceptance: pending`,
`human_reviews: unanswered`, `safety_class: unknown`, `codeql_scope: "Public Apache-2.0
eclipse-score/inc_someip_gateway; no upload"`. Every `source-index.json` entry is
`native_acceptance: not_inferred`. Pinned sources read include `tool_management.rst` (the 3-step
identification → evaluation → qualification → approval process), `code_analysis.rst`
(static/dynamic tool set), `verification_plan.rst` (quality criteria 8–9, tools list),
`development_plan.rst` (SW development tools), `verification_process.rst` (SCA classification),
and `inspection_checklist.rst` (draft). `misra_mapping.rst` and `inspection_checklist.rst` are
`:status: draft`.

### 1.5 Host feedback under `.llm_tmp/overnight/validation/` (present, scoped, local)

| Artifact | Content |
|----------|---------|
| `check-result` | `0` — collector success marker only |
| `before.json` | `ServiceInstanceIdentifierTest`: 91 tests / 33 failures |
| `after.json` | 91 tests / 0 failures |
| `measurement.json` | `check_ref: check_conversion_tests`, `status: completed`, `mode: ubsan`, `changed_paths: ["score/socom/test/unit/service_identifier_tests.cpp"]`, `origin: local_unprotected_measurement`, `initiator: Fabro host hook`, `engineering_acceptance: pending`, `full_native_tests: not_executed`, compiler `/usr/bin/x86_64-linux-gnu-g++-12` (`compiler_sha256: 88315fd2…`); `baseline_with_agent_tests` 91/33/compile 0; `candidate` 91/0/compile 0 (`:2039-2058`); config digests at `:8-2037` |

The measurement is **focused** (one identifier translation unit; no `runtime_tests.cpp`, not
Bazel) and is **local, unprotected, scoped** — it is not native acceptance and does not qualify
GCC, gtest, Bazel, or any analyzer.

### 1.6 Retained obligation artifacts (the collector tree)

`.llm_tmp/overnight/obligations/*/result.json` now exists for 25 collectors. Each carries
`origin: local_unprotected_measurement` and `engineering_acceptance: pending`; most carry a
`check_ref: recollect_*` and a `reused_from` host path, i.e. they are **retained/recollected host
captures**, not fresh executions of this iteration. A successful collection node means the results
were **retained**, not that the checks passed. §6 reads their statuses and exit codes.

---

## 2. The recorded GCC syntax failure — inspection of the actual source

**Finding: the described defect is not present in this checkout; no correction is required, and
none is permitted here.**

`score/socom/impl/service_identifier.hpp` (read directly this iteration) is 40 lines and
brace-balanced:

| Line | Content | Role |
|------|---------|------|
| 14–15 | `#ifndef SRC_SOCOM_SRC_SERVICE_IDENTIFIER` / `#define …` | include guard |
| 17 | `#include "score/socom/service_interface_identifier.hpp"` | include |
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 30–31 | `Service_interface_identifier interface;` / `Service_instance instance;` | members |
| 32 | `};` | closes the struct |
| 35 | `bool operator<(…);` (inside `/// \cond`) | declaration |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`) and two closers (`:32`, `:38`) give net brace balance `0`. Retrieval
from the retained tool artifacts corroborates a compiling unit:

- `obligations/compiler_diagnostics/gcc-compile.stderr` is **empty** and the recorded
  `gcc-compile` is `"exit_code": 0` with `gcc-tests` also `0` (`compiler_diagnostics/result.json`,
  status `completed`); the Clang `clang-compile.stderr` is likewise empty with `clang-tests`
  green.
- `validation/after-compile.stderr` and `validation/before-compile.stderr` are empty; the
  compiler is the collector GCC at sha `88315fd2…`.

The description matches the **earliest** prior reports, which quote the old split form
`}  // namespace socom` + `}  // namespace score`. Applying the historical repair to the already
nested, balanced file would be a no-op at best and a compile break at worst. Because the write
boundary permits only this report, no source edit was made. **Tool-assurance consequence:** the
collector GCC is the *error-detection mechanism* that would have caught this class of defect, and
in the retained run it reports clean — but the retained compile is focused and non-native (§6), so
the detection claim is scoped.

---

## 3. Tool identification register

### 3.1 Tools present in the collector environment (all `available: true`)

Values below are read from `obligations/tool_assurance/result.json` (`tool_inventory`
`:1391-1467`) and the matching `version-*.stdout`. `sha256` is the hash of the resolved
executable recorded by the collector.

| # | Tool | Purpose (pinned source) | Path (collector) | Version (verbatim) | sha256 | Available |
|---|------|-------------------------|------------------|--------------------|--------|-----------|
| T1 | GCC / g++ | Host C++ compiler, linker, warnings, unit-test binaries (`development_plan.rst`) | `/usr/bin/x86_64-linux-gnu-g++-12` | `12.3.0` (Ubuntu 12.3.0-1ubuntu1~22.04.3) | `88315fd2d961a1f4e4070b104d7bd4c7670df19d9949409879ba269466c196d3` | yes |
| T2 | Clang / clang++ | Second compiler for warning coverage (`code_analysis.rst`) | `/home/jefferson/.local/share/s-core-tools/llvm-19.1.7/usr/lib/llvm-19/bin/clang++` | `Ubuntu clang version 19.1.7` | `7969846391c1fe04f816c26bd7d6a09171e9330378c9ec8fd6c841dafec66faa` | yes |
| T3 | clang-tidy | Static analysis (`code_analysis.rst`; `development_plan.rst`) | `…/llvm-19.1.7/usr/lib/llvm-19/bin/clang-tidy` | `Ubuntu LLVM version 19.1.7` | `5f733fae7fdb5ac7122ea1e8fcfb4723a7cbf68b5d779f2f8ead6eb276c03f0c` | yes (ran, but config rejected — §6.4) |
| T4 | Bazel | Build system, test/coverage runner (`development_plan.rst`) | `…/score-someip84-tools-0ptca_j_/bin/bazel` | `bazel 8.6.0` | `9860da9c9386bbc023feed8f43af3105d338727d77b644fa6aeca45a4a11957c` | yes |
| T5 | CodeQL CLI | Static security analysis (`code_analysis.rst`; `development_plan.rst`) | `/home/jefferson/.local/share/s-core-tools/codeql-2.21.4/codeql/codeql` | `2.21.4` | `d38df35e9275fce177e76cc6d4b5fc031ba7e9be4e7d224d0be7d6b7d0a21cc1` | yes |
| T6 | CodeQL coding-standards pack | MISRA query pack | `…/codeql-coding-standards-2.61.0/codeql-suites/misra-cpp-default.qls` | `2.61.0` (pack, from path in `codeql_misra` argv) | — (suite/pack, not hashed this run) | yes |
| T7 | gcov | Statement/branch coverage collection (`verification_plan.rst`) | `/usr/bin/gcov-12` | `12.3.0` | `dcaf103b28775592ac023067bf7af4c1f4e2e7605e8d4fd65600e0b0f7e2dbe4` | yes |
| T8 | gcovr | Coverage report aggregation (`verification_plan.rst`) | `/usr/bin/gcovr` | `5.0` | `59cd3edebe1a6e9a8df26b0ffc01906c444758c58411214ff0e466c8170cfbb0` | yes |
| T9 | cppcheck | Complementary static analysis | `/usr/bin/cppcheck` | `2.7` | `d2268c85b26850db5f36f7a3a7a2ae0106377810f4f93988bf4ab636481b4d89` | yes (findings out of scope — §6.5) |
| T10 | clang-format | Formatting check | `…/score-someip84-tools-0ptca_j_/bin/clang-format` | `19.1.7` | `e93c5619a694d44706a778143bf8ebe8c135fa6a408415cd1fc2d106e04d9491` | yes |
| T11 | pre-commit | Pre-commit hook runner | `…/score-someip84-tools-0ptca_j_/bin/pre-commit` | `4.6.2` | `904701a1f05f3e3a8071fd79dbae40e76cc1df56f6161a1148a50da64acaa234` | yes |
| T12 | reuse | REUSE/licence lint | `…/score-someip84-tools-0ptca_j_/bin/reuse` | `6.2.0` | `9ffc7483c7360a9adb71e0742b55d8b3eb7a332b4112785fa525849ad72a3aa8` | yes |
| T13 | QEMU system | Integration test emulation (`native_integration`) | `/usr/bin/qemu-system-x86_64` | `6.2.0` (Debian 1:6.2+dfsg-2ubuntu6.31) | `55862c768c21fa7d3e72ca1b24797d8ab5b406eb5ef4c9ab9c2280f4e0b8f330` | yes |
| T14 | perf | Resource/performance measurement (`native_performance`) | `/usr/bin/perf` | `6.8.12` | `2d0953085bf720a25efbe24f853e97d27b1f12f18a398255ff82cbafde254dad` | yes |
| T15 | Valgrind | Focused memcheck (`focused_memcheck`) | `…/score-someip84-tools-0ptca_j_/bin/valgrind` | `3.18.1` | `4652774bd116cb49951ef74115ad4237cad5021b2bd4d80002f09d986ec438b9` | yes |
| T16 | gitleaks | Secret scan (`secret_dependency_checks`) | `…/score-someip84-tools-0ptca_j_/bin/gitleaks` | `8.30.1` | `88f91962aa2f93ac6ab281d553b9e125f5197bbbce38f9f2437f7299c32e5509` | yes |

(The collector's `commands` array records labels `version-0` … `version-14`, i.e. **15** probed
binaries; GCC and gcov share the `12.3.0` version string and the LLVM family shares `19.1.7`.
T6 is the MISRA query pack named in the `codeql_misra` argv, not a separate `version-*` probe.)

### 3.2 Collector harness (the tool that produced every obligation artifact)

The `tool_assurance` result records `result_path`/`reused_from`
`…/runs/score-someip84-factory-oicrb03_/obligation-results/tool_assurance-…/result.json`, with
`check_ref: recollect_tool_assurance`, `origin: local_unprotected_measurement`,
`engineering_acceptance: pending`, and a `source_hashes` map that includes the Valgrind payload
under `…/score-someip84-tools-0ptca_j_/valgrind/…`. The collector harness scripts themselves are
**not** in the repository and have **no Tool Verification Report**; the earlier draft's harness
digests (`.llm_tmp/overnight/prior-reports/tool_assurance_review.md` §3.1) cannot be re-derived
here because no hashing tool is available to this iteration. These are the tools whose malfunction
(a mis-snapshotted tree, a mis-parsed exit code, an incomplete extraction) would silently corrupt
every retained result; they are identified here by run-dir path only.

### 3.3 Repository-pinned tool configuration vs. collector-observed tools (drift)

**The tools that judged the code are not all the tools the repository pins.**

| Function | Repository pin | Collector-observed | Drift / significance |
|----------|----------------|--------------------|----------------------|
| C++ compiler (host) | GCC `12.2.0` (`MODULE.bazel:100,115`) | GCC `12.3.0` (`version-0.stdout`) | Minor drift; `compiler_diagnostics` records the limit *"GCC 12.3 / Clang 19 differ from native toolchain pins"* |
| C++ compiler (2nd) / tidy / format | LLVM `22.1.7` via `toolchains_llvm 1.8.0` (`MODULE.bazel:165,185`) | Clang / clang-tidy / clang-format `19.1.7` (`version-1/2/8.stdout`) | **Major drift** — the `.clang-tidy` verdict was produced by a three-major-versions-older binary than the pinned one; "unknown check" results cannot be transferred to the pinned tool |
| Target compiler | QCC `12.2.0`, SDP `8.0.4` (`MODULE.bazel:117-148`) | not present / no SDP entitlement | Cross/QNX obligations blocked; target warnings/sanitizers unmeasured (`cross_compilation` blocker) |
| Build system | Bazel `8.6.0` (`.bazelversion:1`) | Bazel `8.6.0` (`version-3.stdout`) | **No drift**; the native legs are Bazel `8.6.0` runs |
| Coverage | `score_coverage 0.2.0` (`MODULE.bazel:199`) + LLVM source coverage (`coverage.bazelrc`); documented gcov/gcovr | gcov `12.3.0` + gcovr `5.0` (focused TU only) | Methodology differs (gcov on host GCC vs LLVM instrumentation); figures not comparable to a native coverage run |
| Static analysis (security) | "GitHub CodeQL" per `development_plan.rst`; repo CI runs only clang-tidy+ruff | local CodeQL `2.21.4`, public Apache-2.0 repo, **no upload** (`authority.json`) | Documented CI tool ≠ collector tool; **no CI scanning receipt retained**; no CodeQL workflow in `.github/workflows/static-code-analysis.yml` |
| Static analysis (Coverity) | Named in `code_analysis.rst` | not installed / not adopted | Explicit `tool_assurance` blocker: *"Coverity not installed/adopted here; reconcile guideline/development-plan discrepancy"* (`tool_assurance/result.json:1054`) |
| Memcheck | Not mandated | Valgrind `3.18.1` present | `tool_assurance` blocker: *"Memcheck is an optional complement, not a universal process mandate"* (`:1055`) |

The drift matters because a tool's identity is *name + version + configuration*, independent of
location (`tool_management.rst`). A verdict from LLVM 19.1.7 is not evidence about the LLVM
22.1.7 tool the repository will use on the reference environment.

### 3.4 Configuration digests actually snapshotted

From `validation/measurement.json` `source_hashes` (`:8-2037`; third tuple element is the file
mode, decimal `420`/`436`):

| Configuration file | sha256 | Mode |
|--------------------|--------|------|
| `.bazelrc` | `3e377eee390155ccd7f47d104a75b516c6cb23bf81261bfb26a18bd5eedc2931` | `420` |
| `.bazelversion` | `4a0dcdd04283b2bb2122080f03d0058cf6ad7a98731afab1530d59a7f3737dfe` | `436` |
| `.clang-format` | `9c0ec2489877fcb41446602f1674bdacda2646e512e15fe143647b03de465cf5` | `420` |
| `.clang-tidy` | `0b655840f7e72ea394afb9df41a2ec50a0a8525a0a3d7ddff0b95879d6075be0` | `420` |
| `tools/lint/linters.bzl` | `4155f398de558f0581706e8270d7b809794d55de8234c9abaeec719fa7d62dc0` | `420` |

The tool-facing configs are the repository's; the executing binaries are the collector's — hence
the drift in §3.3. Note `.clang-tidy` is a folded `Checks: >` block scalar containing `#` comment
lines, which is the root cause of the `--verify-config` rejection (§6.4).

### 3.5 Named-but-unavailable / not-adopted capability (blockers, not passes)

| Capability | Status | Consequence |
|------------|--------|-------------|
| Coverity | not installed / not adopted (`tool_assurance` blocker) | `code_analysis.rst` tool set incomplete; guideline/plan discrepancy unresolved |
| QNX SDP entitlement + target execution | not configured (`cross_compilation` blocker: *"QNX SDK entitlement and target execution not configured; no credential acquired"*) | QCC `12.2.0`/SDP `8.0.4` target warnings/sanitizers/execution unmeasured |
| Vulnerability database / dependency-scan receipt | absent (`secret_dependency_checks` blocker) | gitleaks ran (exit `1`) but the dependency *inventory* is not a vulnerability scan |
| Repository-CI CodeQL receipt | absent (no CodeQL workflow) | documented "GitHub CodeQL" ≠ the collector's local no-upload run |

**Rule applied:** absent/unadopted capability is **not** a satisfied obligation; each row is a
*blocker*, not a *pass*, and none may be re-interpreted as "no finding".

---

## 4. Exact collector invocations and readiness

`tool_assurance/result.json:1057-1387` records **15** version queries (`version-0` … `version-14`),
each `exit_code: 0`. Representative exact argv (verbatim from the result):

- `version-0`: `["/usr/bin/x86_64-linux-gnu-g++-12", "--version"]`, exit 0.
- `version-1`: `["…/llvm-19.1.7/usr/lib/llvm-19/bin/clang++", "--version"]`, exit 0.
- `version-2`: `["…/clang-tidy", "--version"]`, exit 0.
- `version-3`: `["…/score-someip84-tools-0ptca_j_/bin/bazel", "--version"]`, exit 0.
- `version-4`: `["…/codeql-2.21.4/codeql/codeql", "version"]`, exit 0.
- `version-5`/`version-6`/`version-7`: `gcov-12` / `gcovr` / `cppcheck` `--version`, exit 0.
- `version-8`/`version-9`/`version-10`: `clang-format` / `pre-commit` / `reuse` version, exit 0.
- `version-11`/`version-12`/`version-13`/`version-14`: `qemu-system-x86_64` / `perf` /
  `valgrind` / `gitleaks` version, exit 0.

The collector env sets `USE_BAZEL_VERSION=8.6.0`, `LD_LIBRARY_PATH=…/llvm-19.1.7/…`,
`VALGRIND_LIB=…/score-someip84-tools-0ptca_j_/valgrind/usr/libexec/valgrind` and a
`…/score-someip84-tools-0ptca_j_/bin` PATH that provides bazel/clang-format/pre-commit/reuse/
valgrind/gitleaks (`native_build/result.json:1065-1075`).

The focused compile/test commands (from `compiler_diagnostics/result.json:1053-1297`) are e.g.
`g++-12 -std=c++17 -Wall -Wextra -Werror -pthread -I. … service_identifier.cpp string_registry.cpp
service_identifier_tests.cpp … .llm_tmp/googletest/…/gtest-all.cc …/gtest_main.cc -o …/gcc`. This
is a **focused translation unit**, not a Bazel target; it does not include `runtime_tests.cpp`.

**Readiness conclusion:** all 15 probed tools are present and version-queryable, so the earlier
"missing tool / exit 127" register is superseded. Presence is *execution readiness*, **not**
qualification: T3 still cannot run as configured, and the qualification/release steps are
human-only (§7).

---

## 5. Tool-impact and error-detection questions (draft; for authorized humans)

`tool_management.rst` prescribes the ISO 26262-style sequence: **step 1** tool impact (YES if a
malfunction/threat could violate a safety or security requirement), **step 2** tool error
detection (NO if the malfunction cannot be guaranteed to be detected or prevented), **step 3**
TCL = LOW when impact YES *and* detection NO; LOW requires qualification. The following is a
**draft question sheet — no answer is asserted**, because the safety class is `unknown` and the
relevant human roles are unanswered.

| Tool | Step 1 — could a malfunction/threat violate a safety or security requirement? | Step 2 — could that malfunction be detected or prevented by other measures? | Draft TCL (unconfirmed) |
|------|--------------------------------------------------------------------------------|-----------------------------------------------------------------------------|--------------------------|
| T1 GCC 12.3.0 | Candidate YES: a miscompilation or a swallowed warning could ship an incorrect binary past criterion 9. Decide against the `unknown` safety class. | Candidate partial: focused tests + analyzers + coverage; but the only retained measurement is one scoped TU whose tests derive from the same source. No independent oracle retained. | Candidate LOW → qualification likely needed |
| T2 Clang 19.1.7 | Candidate YES (same class as T1). | Same as T1; the retained focused clang compile/tests are green but scoped, and the version drifts from the pin. | Candidate LOW |
| T3 clang-tidy 19.1.7 | Candidate YES: undetected static-analysis/MISRA classes could violate coding/safety requirements. | Candidate NO: no complementary rule engine covers the same rules; the run produced **zero** findings because the config was rejected and the native leg timed out. | Candidate LOW → qualification/deviations |
| T4 Bazel 8.6.0 | Candidate YES: an incorrectly hermetic build could mask defects or produce non-reproducible artifacts. | Candidate partial: hermeticity is the point, and the native legs ran, but they are local/unprotected and `native_tests` only built tests. | Unresolved |
| T5/T6 CodeQL 2.21.4 + pack 2.61.0 | Candidate YES: security/MISRA findings could be missed. | Candidate partial: the collector itself records *"Compiled query qualification and human deviations pending"* and a draft mapping; extraction is focused. | Candidate LOW/unresolved |
| T7/T8 gcov 12.3.0 / gcovr 5.0 | Candidate YES: under-reported coverage could hide untested safety code. | Candidate partial: the platform goals are independently stated (85 %/100 %); tool could under/over-count branch coverage; the focused run measured only two files. | Candidate LOW/unresolved |
| T9 cppcheck 2.7 | Candidate YES if used as evidence; it is a complementary tool. | Candidate partial: overlaps compilers/tidy. Findings were all out-of-scope headers. | Unresolved (adoption intent unclear) |
| T10 clang-format 19.1.7 | Candidate YES for style/format gates. | Candidate partial: `//:format.check` timed out (124); `pre-commit` ran. | Unresolved |
| T11 pre-commit 4.6.2 | Candidate YES: hook malfunction could mask a hygiene failure. | Candidate partial: the pre-commit leg exited 0 but the `//:format.check` leg it wraps timed out. | Unresolved |
| T12 reuse 6.2.0 | Candidate YES for licensing compliance. | Candidate partial: `reuse lint` exited 1; two out-of-scope files are non-compliant. | Unresolved |
| T13 QEMU 6.2.0 | Candidate YES for integration claims on emulated hardware. | Candidate partial: emulation ≠ reference hardware; the QEMU leg exited 1. | Unresolved |
| T14 perf 6.8.12 | Candidate YES for resource-usage claims. | Candidate partial: environment-dependent; both perf legs timed out (124). | Unresolved |
| T15 Valgrind 3.18.1 | Candidate YES for memory-safety claims (optional complement). | Candidate partial: focused memcheck exited 0, scoped to the identifier TU. | Unresolved |
| T16 gitleaks 8.30.1 | Candidate YES for secret-exposure claims. | Candidate partial: findings are collector-artifact false positives + an out-of-scope QNX file; no vuln DB. | Unresolved |
| Collector harness (§3.2) | Candidate YES: a mis-snapshot/mis-parse would corrupt all retained results. | Candidate NO other than re-running and cross-checking hashes. | Candidate LOW → verify |
| Coverity / QNX QCC+target | Not evaluable — tool/capability absent. | n/a | **Unresolved; cannot be qualified without the tool/capability** |

**Explicit caution.** These are *draft candidate* judgments for orientation only. They are **not**
impact ratings, not error-detection determinations, not confidence levels, and not qualifications.
Only the authorized roles (safety/security/quality manager and committers, per
`verification_process.rst` and the `inspection_checklist.rst` role table) may set them.

---

## 6. Analyzer/tool-by-tool evidence inventory (what was actually retained)

All obligations are `origin: local_unprotected_measurement`, `engineering_acceptance: pending`.
"Retained" ≠ "passed"; `exit 0` is a local, unprotected capture, not acceptance.

### 6.1 GCC (T1) — focused, clean, non-native

`compiler_diagnostics` status `completed`: `gcc-compile` exit `0` and `gcc-tests` exit `0`, both
`stderr` empty; host measurement (`validation/after.json`) 91 tests / 0 failures / compile exit 0.
**Scope:** focused identifier TU, not `runtime_tests.cpp`, not Bazel. Evidences nothing about GCC
qualification.

### 6.2 Clang (T2) — focused, clean, superseding the prior blocker

The current retained `compiler_diagnostics/clang-compile.stderr` is **empty** and
`clang-tests.json` records 91 tests / 0 failures, i.e. the Clang focused compile/run is `exit 0`.
The earlier `-Wdeprecated-declarations`/googletest blocker recorded by the prior-run report is
**superseded** for this checkout. The clang branch of criterion 9 is still **focused and
non-native** and uses a drifted tool version (§3.3).

### 6.3 CodeQL security (T5) — dependency-only, focused extraction

`codeql_security` status `findings_or_execution_failure`; `database-create` and `analyze` exit `0`
with `blockers: []`, and **32 findings** whose every `uri` is under `.llm_tmp/googletest/…`
(`cpp/fixme-comment`, `cpp/commented-out-code`, `cpp/large-parameter`, `cpp/equality-on-floats`,
`cpp/unused-static-*`, `cpp/rule-of-two`, `cpp/include-non-header`, `cpp/trivial-switch`,
`cpp/loop-variable-changed`, `cpp/path-injection`). Self-declared limit: *"Focused linked
executable, not full target extraction; dependency findings retained."* No in-scope finding. Not a
full-target result.

### 6.4 clang-tidy (T3) — did not run (config rejected) and native leg timed out

`focused_clang_tidy/native-config.stderr` records exit `1` with 15 `--verify-config` warnings,
e.g. `unknown check '# --- autosar-severity-one --- bugprone-use-after-move'`,
`unknown check 'clang-analyzer-alpha.security.ArrayBoundV2'`,
`unknown check 'modernize-use-integer-sign-comparison'`, and `unknown check option
'modernize-use-integer-sign-comparison.IncludeStyle'`. Retained blocker: *"Native analyzer
configuration incompatible; no replacement called MISRA"* (`focused_clang_tidy/result.json:1052`).
Because `--verify-config` failed, **zero** translation units were analyzed. The native
`//:clang-tidy.check` leg additionally **timed out** (`exit 124`, `native_lint/result.json:1077-1079`).
That is **"not run", never "clean".** Contributing causes: (a) the `Checks: >` folded block scalar
folds `#` comments into check names; (b) genuine version drift between clang-tidy 19.1.7
(collector) and the pinned LLVM 22.1.7 (§3.3). Both require an authorized fix outside the candidate
paths; suppressing checks is prohibited.

### 6.5 cppcheck (T9) — findings outside the candidate paths

`focused_cppcheck` exit `2`. All findings are `id="passedByValue"` (severity `performance`,
CWE-398) located in included headers outside the six candidate paths
(`score/socom/registry_string_view.hpp` and `score/socom/service_interface_identifier.hpp`), with
`file0="score/socom/impl/service_identifier.cpp"`. They are style/performance noise, not
correctness defects; disposition is pending. Retained limit: *"Optional complementary checks; no
inferred MISRA rule coverage."*

### 6.6 Sanitizers — ASan/LSan/UBSan and native TSan pass; focused TSan environment failure

- `focused_asan_lsan`: compile exit `0`, tests exit `0`, stderr empty — focused identifier scope.
- `native_sanitizers`: `bazel test //score/... //tests/... --build_tests_only
  --features=asan,lsan,ubsan_clang` exit `0` (build-only).
- `native_tsan`: `bazel test … --features=tsan` exit `0` (build-only).
- `focused_tsan`: compile exit `0`, tests exit `66`, stderr
  `FATAL: ThreadSanitizer: unexpected memory mapping 0x…`. This is the known TSan/kernel-ASLR
  incompatibility, not a reported data race; the focused identifier tests are single-threaded.
  Environment blocker.
- `focused_memcheck`: Valgrind `3.18.1` present; memcheck exit `0` with empty stderr — focused
  scope only; retained limit *"Optional complementary focused memory analysis"*.

### 6.7 Coverage (T7/T8) — below platform goals, focused scope

`focused_coverage/result.json:1156-1174`: over `service_identifier.cpp` + `string_registry.cpp`,
line `36/36 = 100 %`, branch `11/14 = 78.6 %`, `complete_target_scope: false`,
`safety_class: "unknown_requires_authorized_selection"`, platform goals `QM 85 / safety 100`.
Branch coverage is below even the QM goal; the `native_coverage` collector's
`COVERAGE_THRESHOLD=73` is explicitly *"Repository CI threshold 73 is not platform 85/100
line-and-branch acceptance"*.

### 6.8 CodeQL MISRA (T6) — draft mapping; in-scope hits are gtest macros

`codeql_misra` status `findings_or_execution_failure`; blockers (`:1052-1056`): *"MISRA
applicability/mapping draft and incomplete"*, *"Default suite omits manual/audit obligations"*,
*"Compiled query qualification and human deviations pending"*. Findings are (a)
`cpp/misra/copy-and-move-assignments-shall-handle-self-assignment` in
`.llm_tmp/googletest/…/gtest-filepath.h` (dependency); (b)
`cpp/misra/external-linkage-not-declared-in-header-file-misra` on
`service_identifier_tests.cpp` `TEST_F` lines (`:1165-2987`, `startColumn 8`) — the gtest `TEST_F`
macro expansion, not the authored bodies; and (c)
`cpp/misra/identifiers-used-in-the-controlling-expression-of` in
`.llm_tmp/googletest/…/gtest-port.h` (dependency). `misra_mapping.rst` is `:status: draft`. **No
MISRA C++:2023 compliance can be claimed.**

### 6.9 Secret/dependency scan — tool present, scan incomplete

`secret_dependency_checks` status `findings_or_execution_failure`; `gitleaks dir … --redact=100`
exit `1`; blocker: *"No adopted vulnerability database/ecosystem mapping or GitHub dependency scan
receipt; dependency inventory is not a vulnerability scan."* The companion
`tool_findings_repair.md` records the findings as collector-artifact false positives plus one
out-of-scope QNX build file. A dependency inventory and a `lock_sha256` were retained. Not a
vulnerability scan.

### 6.10 Native build / tests / lint / docs / traceability / performance / integration

| Check | Exact command (retained argv) | Exit | Status |
|-------|-------------------------------|------|--------|
| `native_build` | `build --jobs=2 //...` | `0` | completed |
| `native_tests` | `test --jobs=2 //... --build_tests_only` (**builds; does not run**) | `0` | completed |
| `native_coverage` | `coverage --jobs=2 //... --build_tests_only`; `run @score_coverage//:generate_coverage_html` | `0`; `0` | completed (CI threshold 73 ≠ platform 85/100) |
| `native_lint` | `run //:clang-tidy.check`; `run //:ruff.check` | `124` (timeout); `0` | findings_or_execution_failure |
| `cross_compilation` | `build --config=x86_64-linux`; `build --config=aarch64-linux` | `0`; `0` | completed_with_blockers (QNX SDK/credential) |
| `native_integration` | `test --config=qemu-integration //quality/... //tests/integration_test/...` | `1` | findings_or_execution_failure |
| `native_docs` | `run //:docs` | `2` | findings_or_execution_failure |
| `native_traceability` | `test //:unit_tests //:component_tests`; `run //:docs`; `run //:traceability_gate … --need-type=comp_req` | `0`; `2`; `1` | findings_or_execution_failure |
| `native_performance` | `test --config=perf-tests //tests/benchmarks/...`; `--config=perf-tests-flamegraphs` | `124`; `124` | findings_or_execution_failure |
| `format_precommit` | `git init`; `git add --all`; `test //:format.check`; `pre-commit run --all-files`; `reuse lint`; `mod tidy`; `mod deps --lockfile_mode=error` | `0`,`0`,`124`,`0`,`1`,`0`,`0` | findings_or_execution_failure (mutations only in disposable copy) |
| `process_checks` | (no commands; lexical metadata inventory) | — | completed_with_blockers |
| `tool_assurance` | 15 × `<tool> version/--version` | all `0` | completed_with_blockers |
| `rework_progress` | (no commands) | — | completed; `source_changed_this_round: false`, `rework_requested: false` |

`process_checks` metadata inventory: `runtime_tests.cpp` 33 test macros and
`service_identifier_tests.cpp` 91 test macros, each with `DerivationTechnique` and `Description`;
`TestType`/`Verifies` deliberately unset (no invented requirement IDs). Blockers: *"Lexical
metadata inventory cannot prove semantic requirement coverage"*, *"Safety/QM applicability and
approved tailoring unknown"*, *"Independent inspection and acceptance required"*, *"External AoU
and full integration verification require scoped review"*.

---

## 7. Confidence / qualification evidence inventory (what exists vs. what is required)

`tool_management.rst` defines the work product as a **Tool Verification Report** per tool, using
the template `gd_temp__tool_management_verif_rpt_template`, checked with
`gd_chklst__tool_cr_review`, and advanced through statuses `identified → evaluated → qualified →
released` (or `rejected`). The following inventory maps what this run has against each stage.

| Stage (tool_management.rst) | Required evidence | Present in this slice? |
|-----------------------------|-------------------|------------------------|
| Identification | name/UID + version + location; configuration per `doc__config_mgt_plan` | **Partial.** Present for the 15 collector tools (§3.1) and the repository pins (§3.3); config digests captured (§3.4). No per-tool UID/report file. |
| Evaluation | tool impact (Y/N), tool error detection (Y/N), TCL (HIGH/LOW) | **Absent.** Only draft *questions* here (§5); no authorized rating. Safety class `unknown` blocks the judgment. |
| Qualification (if TCL LOW) | tool requirements, malfunction/threat analysis, safety/security measures, test cases, test report; report updated to `qualified` | **Absent.** No requirement set, no malfunction analysis, no qualification test report. |
| Approval | authorized human releases (`released`) or rejects (`rejected`) | **Absent/pending.** `tool_assurance` blocker *"Tool confidence evaluation, qualification where applicable, and acceptance require authorized humans"*; `engineering_acceptance: pending`, `human_reviews: unanswered`. |

### 7.1 Positive evidence that does exist (for a later report)

- Exact tool executables and sha256 digests (T1–T16, §3.1).
- Exact versions for the 15 probed tools (§3.1, §4).
- Repository toolchain pins and dependency versions (§3.3).
- Snapshotted configuration digests for `.bazelrc`, `.bazelversion`, `.clang-format`,
  `.clang-tidy`, `tools/lint/linters.bzl` (§3.4).
- Retained, scoped execution records for GCC, clang, clang-tidy (config-verify), cppcheck, CodeQL
  security/MISRA, ASan/LSan/UBSan, TSan, Valgrind memcheck, gcov/gcovr, Bazel build/test-build/
  coverage, x86_64+aarch64 cross builds, QEMU prerequisites, perf/format/pre-commit/reuse/gitleaks
  version or run records (§6).

### 7.2 Gaps that preclude any qualification claim

- No tool requirement, malfunction/threat analysis, or qualification test report for any tool.
- No error-detection argument (nothing proves a malfunction would be caught).
- Version drift between collector and pinned toolchain (§3.3).
- Named-but-unavailable/unadopted capability (Coverity, QNX SDP/target, vulnerability DB) (§3.5).
- Unknown safety class → the applicable rigor/acceptance level is unselected.
- Unanswered human reviews → no independence, no approval.

**Statement.** Tool *execution* (or non-execution) does **not** qualify any tool. Owner acceptance
stays pending; nothing here may be marked `qualified` or `released`.

---

## 8. Observed findings that touch (or appear to touch) the bounded slice

| Tool | Finding | On a candidate path? | Tool-assurance reading |
|------|---------|----------------------|------------------------|
| GCC 12.3.0 | compile exit 0; tests exit 0 (91/91 retained) | yes (clean) | confirms no syntax defect (§2); focused only |
| Clang 19.1.7 | compile exit 0; tests exit 0 (91/91 retained) | yes (clean) | focused only; version drifts from pin |
| clang-tidy 19.1.7 | none produced (`--verify-config` exit 1; native leg timed out 124) | n/a | **not run**; version/config drift (§3.3, §6.4) |
| cppcheck 2.7 | `passedByValue` notes | no (headers) | out-of-scope style noise; no MISRA inference |
| CodeQL security 2.21.4 | 32 findings, all under `.llm_tmp/googletest/…` | no | dependency-only; focused extraction |
| CodeQL MISRA 2.61.0 | self-assignment + controlling-expression (gtest headers); `external-linkage` on `TEST_F` lines | macro/header artifact | needs human deviation / macro-aware tooling |
| ASan/LSan/UBSan | focused + native build legs exit 0 | yes (pass, focused/build) | single-threaded identifier scope |
| TSan | native build leg exit 0; focused tests exit 66 (`unexpected memory mapping`) | n/a | environment/kernel blocker |
| Valgrind memcheck | focused exit 0 | yes (pass, focused) | optional complement |
| gcovr 5.0 | 100 % line / 78.6 % branch, two files | partial | below QM/safety branch goal; focused |
| gitleaks 8.30.1 | exit 1; collector-artifact false positives + out-of-scope QNX file | no | no vuln DB; not a dependency scan |

No finding points into `service_identifier.cpp`, `service_identifier.hpp`, or the author-written
test bodies; the only in-scope-looking MISRA hits are the gtest macro/header expansion.

---

## 9. Notice, licence and write-surface preservation

- No source, build, test, config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was created, edited,
  or deleted by this iteration; **only this report was written.**
- The flagged header `score/socom/impl/service_identifier.hpp` was inspected and left unchanged
  because it is already balanced and well-formed (§2); its Apache-2.0 / SPDX header (`:1-12`) is
  intact, as are those of the sibling `.cpp`, both BUILD files, and both candidate test files.
- All 38 files under `.llm_tmp/overnight/prior-reports/` and all 32 earlier files under
  `.llm_tmp/overnight/reports/` were preserved unchanged; this document is a new `reports/` entry
  and overwrites nothing.
- This report itself carries the Apache-2.0 header. No licensed MISRA rule text is reproduced;
  only native rule/query identifiers, file locations, and retained-artifact readings are cited.

---

## 10. Obligations status for the tool-assurance slice (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Tools identified (name/UID + version + configuration) | `tool_management.rst` | **PARTIAL/DRAFT** — 15 present tools + 3 not-adopted/absent capability identified with versions/digests (§3); no per-tool verification-report work product |
| Tool impact determined | `tool_management.rst` | **NOT DONE** — only draft questions (§5); safety class `unknown` |
| Tool error detection determined | `tool_management.rst` | **NOT DONE** |
| Tool confidence level / qualification where required | `tool_management.rst` | **NOT DONE** — no requirements, malfunction analysis, or qualification tests |
| Tool Verification Report released/rejected | `tool_management.rst` | **PENDING** — owner acceptance outstanding |
| Freedom from static-analysis findings (critical/high) | `verification_plan.rst`; criterion 8 | **NOT SATISFIED** — clang-tidy not run (config/tool), cppcheck out of scope, CodeQL focused/dependency-only, no classification/closure |
| Freedom from compiler warnings & errors 100 % | `verification_plan.rst`; criterion 9 | **NOT MEASURED (native)** — focused GCC/Clang clean; Bazel native build exit 0 but no `--features=treat_warnings_as_errors` evidence; default build disables warnings-as-errors |
| Coverage goals (85 % QM / 100 % safety) | `verification_plan.rst` | **NOT MEASURED to goal** — focused 100 % line / 78.6 % branch; native threshold 73; `complete_target_scope: false` |
| Unit/component tests executed & recorded | `verification_plan.rst` | **PARTIAL** — focused 91/91 retained; `native_tests` only built; full native runtime suite not executed |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` (draft) | **UNKNOWN — NOT CLAIMED** |
| Secret/vulnerability scanning | `code_analysis.rst`; dependency hygiene | **NOT SATISFIED** — no vuln DB; gitleaks findings are out-of-scope/artifacts |
| Independence of verification / review | `verification_process.rst` | **NOT DONE** — human reviews unanswered |
| Native acceptance | `.llm_tmp/context/obligations/source-index.json` | **`not_inferred`** for every entry |

**Explicit non-satisfaction statement.** The not-adopted/absent capability (Coverity, QNX SDP,
vulnerability DB), the collector-vs-pinned version drift, the un-inferred applicability, the
incomplete/focused extraction, the unknown safety class, and the unanswered human reviews mean
**none of the checked obligations may be treated as satisfied**. A retained collection result shows
*retention*, not passing, and tool execution does not qualify a tool.

---

## 11. Pending human review checklist (owner acceptance required)

- [ ] **Confirm §2**: `service_identifier.hpp` is brace-balanced (brace lines `:19,:29,:32,:38`;
      line 39 blank). The recorded "extra closing brace at line 39" is stale / refers to a
      different revision. No source correction is required in this checkout; resolve the
      "correct-the-source vs. review-draft-only" instruction conflict for the record.
- [ ] **Accept or reject the collector-vs-pinned tool drift (§3.3)**: decision needed on whether
      clang/clang-tidy/clang-format 19.1.7 evidence is admissible for the LLVM `22.1.7` pin, and
      whether the GCC 12.2.0/12.3.0 minor difference is acceptable.
- [ ] **Repair the `.clang-tidy` `Checks: >` folded block** and re-evaluate the identifiers absent
      from the pinned LLVM version, via an authorized change; do not suppress checks in this slice.
- [ ] **Re-run `//:clang-tidy.check`** (it timed out, exit 124) and record whether it produces
      findings; do not report "clean" for a run that did not complete.
- [ ] **Reconcile the Coverity discrepancy** (`code_analysis.rst` names it; it is not
      installed/adopted): adopt, tailor-out with rationale, or remove.
- [ ] **Locate or provide** the documented "GitHub CodeQL" CI integration vs. the local, no-upload
      CodeQL 2.21.4 collector run (§3.3).
- [ ] **Complete the tool-impact / error-detection / TCL evaluation (§5)** for T1–T16 and the
      collector harness, and qualify where TCL is LOW, using
      `gd_temp__tool_management_verif_rpt_template` and `gd_chklst__tool_cr_review`.
- [ ] **Close the QNX entitlement gap** (QCC/SDP target execution) and the vulnerability-database
      gap so the cross/QNX and secret-scan obligations can produce real results.
- [ ] **Provide TSan-capable environment or an accepted exclusion**, and re-run the focused
      sanitizer set on the current tree (91 cases, test-file hash `de79767c…`).
- [ ] **Run the full native suite** (`//score/...` including `runtime_tests.cpp`, plus the
      integration/QEMU set) and record pass/fail and coverage against the platform goals; do not
      report the 73 threshold as acceptance.
- [ ] **Disposition** the cppcheck `passedByValue` findings and the CodeQL MISRA gtest-macro/header
      hits (accepted deviation or macro-aware tooling) — outside the bounded slice.
- [ ] **Keep the wider #84 public `Service_interface_identifier` restructure, FindService wildcard
      and config minor-wildcard narrowing out of this bounded slice** until separately accepted,
      and do not present the identifier-only tests as platform validation.

---

## 12. Method and truthfulness statement

- **Tools used:** `read_file`, `grep`, `glob`, `write_file` only. No `shell`, delegation, web,
  approval, publishing, or engineering acceptance.
- **Measurements executed this iteration:** none. Every number is a reading of the retained
  collector/validation artifacts or of the working tree; expected behaviours are labelled as
  source-derived.
- **Scope:** local, unprotected, scoped. The retained compile/analyze/sanitize/memcheck/coverage
  runs cover the focused identifier translation unit; several native legs are build-only
  (`--build_tests_only`); full native runtime tests are `not_executed`
  (`validation/measurement.json:2042`).
- **Truthfulness:** no finding is suppressed or reclassified; absent/unadopted capability,
  rejected configs and timed-out runs are recorded as blocked/not-run, not as clean passes; no
  invented requirement identifiers or qualifications appear.
