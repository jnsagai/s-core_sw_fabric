<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — module verification report and release-evidence archive index (review draft)

**Document type:** review draft — module verification report (scope, exact test IDs,
pass/fail/skipped/unexecuted results, source hashes, coverage, analyzer findings, earlier
attempts, deviations) + release-evidence archive index + obligations status.

**Date:** 2026-10-02
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version handling
in socom* (issue #84)
**Run / branch:** `fabro/run/01M3YRJEGXNY6CB81T7TKW774B` (latest observed commit `248116e`,
`fabro(01M3YRJEGXNY6CB81T7TKW774B): node_cffc406622ac0fe3ca90dbf0 (success)`)
**Baseline commit:** `f8a196c3b16d5172d898394ab99b0ed81346d63d`
**Status:** **local, unprotected, scoped.** No engineering acceptance exists. Human reviews are
unanswered. Full native runtime tests are pending. Nothing in this document is acceptance,
approval, publication, or a full native run.

> **Tool / write boundary actually observed.** This iteration used only `read_file`, `grep`,
> `glob`, and `write_file`. No `shell`, no `edit_file`, no delegation, no web access, no
> approval, no publishing, and no engineering acceptance was performed. The task says to
> *"inspect and correct the actual source before expanding tests"* but its explicit, more
> specific final sentence says *"This is a review draft: only that report may be written."*
> Following the explicit write boundary, **only this report was written.** No source, build,
> test, config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was created, edited, or deleted; no
> test was expanded; all prior reports under `.llm_tmp/overnight/reports/` and
> `.llm_tmp/overnight/prior-reports/` are preserved.
>
> **The instruction's source-correction precondition is moot on the facts.** The described
> defect — *"a measured GCC syntax failure: an extra closing brace in
> `score/socom/impl/service_identifier.hpp` at line 39"* — is **not present in the current
> working tree** (§2). The header is already brace-balanced; line 39 is blank. There is no
> actual source to correct, and applying the historical repair to an already-balanced file
> would be a no-op at best and a regression at worst.
>
> **Non-satisfaction rule applied throughout.** A successful obligation-collection node means
> results were **retained**, not that checks **passed**. Missing tools, unknown applicability,
> incomplete extraction, an inactive/draft rule mapping, and unanswered human reviews are
> **not** treated as satisfied. A tool that produced no finding because it **did not run** is
> recorded as *"not run"*, never as *"clean"*. Every unexecuted applicable check and every
> unaccepted deviation remains a **blocker** (§9, §11).

---

## 0. Executive summary

1. **The coupled module change is present and internally consistent.** The duplicate-server
   registration key `Service_instance_identifier` orders by `(instance, service id, major)`
   with `minor` deliberately excluded (`score/socom/impl/service_identifier.cpp:28-29`),
   matching the minor-ignoring `Service_database` index (`runtime_impl.hpp:116-134`) and
   closing invariant gap I-11 (baseline key included `minor`).
2. **87 identifier-suite cases and 33 runtime-suite cases exist** — exact IDs in §4. The
   **87 identifier cases were compiled and executed green** in the retained focused runs
   (`compiler_diagnostics` `gcc-tests` 87/0; `focused_coverage` 87/0; `focused_asan_lsan`
   87/0). The **33 runtime cases were never executed** by any retained artifact — they are
   **UNEXECUTED**, not passing.
3. **Two independent measured results corroborate the key correction:**
   - focused GCC on the current 87-case file: **87 tests / 0 failures / compile exit 0**;
   - host hook `check_conversion_tests`: `baseline_with_agent_tests` = **85 tests / 28
     failures / compile exit 0** vs `candidate` = **85 tests / 0 failures / compile exit 0**
     — i.e. the minor-aware key fails the minor-collapse regressions and the corrected key
     passes them. That host measurement is **stale by two cases** (85 executed vs 87 on disk).
4. **Coverage (focused TU only): line 36/36 = 100.0 %; branch 11/14 = 78.6 %.** Line meets
   both platform goals (QM 85 / safety 100); **branch meets neither goal** (below QM by
   6.4 pp, below safety by 21.4 pp). The three uncovered branches are compiler-generated
   `throw`/guard edges. `complete_target_scope: false`.
5. **Analyzer findings are dominated by out-of-scope artifacts.** CodeQL security retains 32
   findings, all under `.llm_tmp/googletest/**`; CodeQL MISRA retains a large dependency +
   gtest-macro + out-of-slice-production set; cppcheck retains 19 out-of-slice
   `passedByValue` findings; clang-tidy produced **no** findings because it **did not run**
   (`--verify-config` exit 1). No Critical/High/Medium/Low rating exists for any finding
   (tool `level` is `null`; no QM+committer classification).
6. **The only in-scope compiler deviation** is a Clang `-Wdeprecated-declarations` error under
   `-Werror` originating in libstdc++-12 / vendored googletest — a dependency/toolchain
   blocker, not a candidate-source defect.
7. **No obligation is satisfied.** `bazel`, `valgrind`, `gitleaks`, `clang-format`,
   `pre-commit`, and `reuse` are unavailable; the native build/test/integration/coverage/
   traceability legs all exit 127; TSan fails with SIGSEGV; the MISRA mapping and inspection
   checklist are `:status: draft`; `engineering_acceptance: pending`; `human_reviews:
   unanswered`; `safety_class: unknown`.

---

## 1. Binding, scope, and authority

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` — *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:2-4` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG`, created/updated `2026-04-14T13:23:24Z` | `.llm_tmp/context/issue-snapshot.json:8,19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**. It distinguishes service-instance identifier = `service id + major + minor +
instance id`, service identifier = `service id + major`, and FindService = `service id + major
+ optional<minor> + optional<instance>`, and proposes excluding `minor` from identity. There is
**no comment and no acceptance record**, so none of it is binding. Binding is **by baseline
commit**, not by run HEAD.

### 1.2 Bounded candidate paths (the only writable source paths)

From `.llm_tmp/context/candidate-files.json`:

1. `score/socom/BUILD`
2. `score/socom/impl/service_identifier.cpp`
3. `score/socom/impl/service_identifier.hpp`
4. `score/socom/test/unit/BUILD`
5. `score/socom/test/unit/runtime_tests.cpp`
6. `score/socom/test/unit/service_identifier_tests.cpp` (baseline blob `null` — a **new** file)

### 1.3 Pinned obligation sources and authority

All nine `.llm_tmp/context/obligations/source-index.json` entries were read with
`authority.json`:

| id | file | status note |
|----|------|-------------|
| `coding_guidelines` | `coding_guidelines.rst` | `:status: valid`; MISRA C++:2023 with C++17 |
| `code_analysis` | `code_analysis.rst` | `:status: valid`; clang-tidy + gcc/clang warnings + Coverity; sanitizers; gcov/gcovr |
| `misra_mapping` | `misra_mapping.rst` | **`:status: draft`** — rule table commented out, `_assets/misra_2023.csv` absent |
| `verification_plan` | `verification_plan.rst` | `:status: valid`; TestType/DerivationTechnique tables; quality criteria 1–9 |
| `development_plan` | `development_plan.rst` | `:status: valid`; C++17, GCC host, QCC target, Bazel |
| `tool_management` | `tool_management.rst` | `:status: valid`; tools identified / evaluated / qualified |
| `verification_process` | `verification_process.rst` | `:status: valid`; `gd_req__verification_link_tests_cpp`, `_independence`, `_checks(_extended)`, `_external_aou`, `_sca_classification` |
| `verification_guideline` | `verification_guideline.rst` | `:status: valid`; traceability, independence, documented results |
| `inspection_checklist` | `inspection_checklist.rst` | **`:status: draft`** — blank `IMPL_01_01`…`IMPL_03_02` template |

Every entry is pinned `"native_acceptance": "not_inferred"`. `authority.json` records:
`codeql_scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload"`,
`engineering_acceptance: "pending"`, `human_reviews: "unanswered"`, `safety_class:
"unknown"`, and the instruction *"Restart the failed queue for one complete pass through all
obligations"*.

---

## 2. The recorded GCC syntax failure — inspection of the actual source

`score/socom/impl/service_identifier.hpp` read from the working tree is **brace-balanced** and
exactly 40 lines. `grep '[{}]'` returns exactly four brace-bearing lines:

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`) and two closers (`:32`, `:38`): net brace balance `0`. There is **no
third, unmatched closing brace**, and line 39 contains no text. `glob
**/service_identifier.hpp` returns exactly one path, so there is no second, differently-braced
copy in this checkout. The sibling `impl/service_identifier.cpp` uses the same nested form and
is balanced (`:18`, `:20`, `:30`, `:32`).

**Disposition.** The described defect is a stale, pre-correction description that matches the
earliest prior reports (which quote the split form `}  // namespace socom` + `}  // namespace
score`). The `reproducer` iteration corrected it and left line 39 blank. **No correction was
applied, and none is required.** The minimal historical repair is retained below for reference
only:

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

**Independent evidence (retained, not produced here).** The tool-measured `gcc-compile` exits
`0` with empty `stderr` and `gcc-tests` exits `0`; the host measurement records
`compile_exit = 0`. A surviving unmatched brace would make these fail. These are focused,
scoped, unprotected captures — corroboration, **not** a full native build.

---

## 3. Changed production source and its hashes

The coupled change is the registration-key comparator:

```cpp
// score/socom/impl/service_identifier.cpp:20-30
bool operator<(Service_instance_identifier const& lhs, Service_instance_identifier const& rhs) {
    // ... rationale comment: minor excluded; identity = service id + major (issue #84) ...
    return std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major) <
           std::tie(rhs.instance, rhs.interface.id, rhs.interface.version.major);
}
```

`std::set` uniqueness is `!(a < b) && !(b < a)`, so identity is exactly
`(instance, service id, major)` and the minor version is excluded. The key type is
`Service_instance_identifier{ Service_interface_identifier interface; Service_instance
instance; }` (`impl/service_identifier.hpp:29-32`), an `impl/`-only type with `operator<`
(declaration `:35`, `\cond`-hidden) and **no** `operator==`/`std::hash`.

### 3.1 Source hashes (tool-measured working tree vs context snapshot)

The **tool-measured** `sha256` values are quoted from the retained `source_hashes` blocks in
`.llm_tmp/overnight/obligations/*/result.json`. The context-snapshot values
(`.llm_tmp/context/candidate-files.json`) are shown for drift awareness only.

| Path | Tool-measured sha256 | Context snapshot sha256 | Role |
|------|----------------------|-------------------------|------|
| `score/socom/impl/service_identifier.hpp` | `bdce3fcbc3cd78a8ecaece1ea36107d464011ab81c9bc39932d0be617befaea9` | `96b33a1fee4d54577ae9bc46c313409a0d59336f76df85ef1925ffebdd1a2119` | key type (in scope) |
| `score/socom/impl/service_identifier.cpp` | `3c12b3f1dd3f1fa66cdf43766f374d7d067637bf8f11aba604c4e2688351f11a` | `d766902e4bda5306095a6e5326ea91d28df3a6e1ef4e77dc9ba47556ed559a9a` | key comparator (in scope) |
| `score/socom/test/unit/service_identifier_tests.cpp` | `4df2c63c4c2ea1a816898d8c33c506add3235509d85edfc51c535ab2aa1587a4` | `45d073998108df76c8f4534508d65f02cead28aa568cd5c45b5a3d8a4fd36a25` | 87-case key suite (in scope) |
| `score/socom/test/unit/runtime_tests.cpp` | `9a2d6a154683a2b7ff9d51b7241e4fb74c1a8ef483895830cb409a8f5a1d3127` | `5e35e24d0abcfa361b5a5283a005b307b86026a970464a3423be7c6eed66631e` | 33-case runtime suite (in scope) |
| `score/socom/BUILD` | `68f4645a21e495fac43929fb125f7ba0b9e29fc84c0401fdb95238ffb7fd2cc8` | `dee826163ac5e6336d51a293136b424696c2884aa1b2592395e1e06423c0ba44` | build wiring (in scope) |
| `score/socom/test/unit/BUILD` | `e909151e822370bebe8d59b86369bddeb4d6cacfa02f10061bf6e134671ff9d4` | `9b3c5b341211e2c387858fd1fe5c669a6a422b6e8b5e80fce35ba22c61186799` | build wiring (in scope) |
| `score/socom/impl/string_registry.cpp` | `f486e72a96429fea4b06f505b96b4fa00aa831a6834959169e409200e8ee8fbb` | — | measured TU member (out of slice) |
| `score/socom/string_registry.hpp` | `909ca6a47b1e7bb76bc05f3f05144ee6c80350fe4643df61d5efe4ef5f38693f` | — | out of slice |
| `score/socom/registry_string_view.hpp` | `6640b529ea626c50944e1afe6240f84ac02551901c5a12ca846ea1ba37f18647` | — | out of slice |
| `score/socom/service_interface_identifier.hpp` | `b3c1f1a61fe91d8b6adb3a02dd745eb6c60fec0bfb78f581571fc6a88b972782` | — | public identifier (unchanged) |

### 3.2 Tool / dependency hashes

| Artifact | sha256 |
|----------|--------|
| `/usr/bin/x86_64-linux-gnu-g++-12` | `88315fd2d961a1f4e4070b104d7bd4c7670df19d9949409879ba269466c196d3` |
| `clang++` (19.1.7) | `7969846391c1fe04f816c26bd7d6a09171e9330378c9ec8fd6c841dafec66faa` |
| `clang-tidy` (19.1.7) | `5f733fae7fdb5ac7122ea1e8fcfb4723a7cbf68b5d779f2f8ead6eb276c03f0c` |
| `codeql` (2.21.4) | `d38df35e9275fce177e76cc6d4b5fc031ba7e9be4e7d224d0be7d6b7d0a21cc1` |
| `/usr/bin/gcov-12` | `dcaf103b28775592ac023067bf7af4c1f4e2e7605e8d4fd65600e0b0f7e2dbe4` |
| `/usr/bin/cppcheck` | `d2268c85b26850db5f36f7a3a7a2ae0106377810f4f93988bf4ab636481b4d89` |
| `MODULE.bazel.lock` | `c90b245bc0f8aadea595e2d3bc618325e064b371d88544bcb787b1afb28564b6` |

**Hash-drift note.** The working tree has moved relative to the context snapshot (e.g. header
`bdce3fcb…` vs `96b33a1f…`; key tests `4df2c63c…` vs `45d07399…`). The direct read and the
tool-measured hash are authoritative for this report; the snapshot's description of a brace
defect cannot be assumed to describe the current file.

---

## 4. Test inventory — exact IDs, results, and execution state

Execution-state legend: **PASS** = executed green in a retained artifact; **FAIL** = executed
red in a retained artifact; **UNEXECUTED** = no retained artifact compiled or ran it;
**SKIPPED** = explicitly disabled. Scope legend: **focused** = compiled/run in the focused
identifier executable, not a Bazel target.

### 4.1 Key / identifier suite — `score/socom/test/unit/service_identifier_tests.cpp`

Fixture `ServiceInstanceIdentifierTest`; **87 `TEST_F`** (baseline blob `null`; new file).
All 87 are **PASS (focused)** in `compiler_diagnostics` `gcc-tests` (`87/0`), `focused_coverage`
(`87/0`), and `focused_asan_lsan` (`exit 0`). **UNEXECUTED natively** (no `bazel`).

| # | Test ID | Line | # | Test ID | Line |
|---|---------|------|---|---------|------|
| 1 | `SameIdentifierIsNotLessThanItself` | 168 | 45 | `ConvertedKeyCollapsesConfigMinorsThatNarrowAlike` | 884 |
| 2 | `KeysDifferingOnlyInMinorVersionAreDuplicates` | 174 | 46 | `ConvertedKeyIsDeterministicAcrossRepeatedConversions` | 911 |
| 3 | `MinorVersionBoundariesAreDuplicates` | 182 | 47 | `EmptyServiceIdIsDistinctAndOrdersFirst` | 927 |
| 4 | `AllMinorVersionsCollapseToSingleKey` | 192 | 48 | `EmptyInstanceIdIsDistinctAndOrdersFirst` | 943 |
| 5 | `MinorHighBitVariantsAreEquivalent` | 203 | 49 | `EmptyIdKeysCollapseAcrossMinorVersions` | 959 |
| 6 | `KeysDifferingInMajorVersionAreDistinct` | 217 | 50 | `ServiceIdPrefixOrderingIsLexicographic` | 970 |
| 7 | `MajorVersionBoundariesAreDistinct` | 225 | 51 | `InstanceIdPrefixOrderingIsLexicographic` | 985 |
| 8 | `MajorVersionSweepProducesDistinctKeys` | 235 | 52 | `MajorHighBitAdjacencyIsOrdered` | 998 |
| 9 | `AdjacentMajorVersionBoundariesAreDistinct` | 246 | 53 | `KeysDifferingInInstanceAndMinorAreDistinct` | 1009 |
| 10 | `KeysDifferingInServiceIdAreDistinct` | 262 | 54 | `KeysDifferingInMajorAndMinorAreDistinct` | 1021 |
| 11 | `DistinctServiceIdsProduceDistinctKeys` | 270 | 55 | `SetFindLocatesMinorVariantAndCountsItOnce` | 1034 |
| 12 | `EqualServiceIdTextProducesEquivalentKeys` | 281 | 56 | `PropertySortedDomainMatchesSortedIdentityTuples` | 1055 |
| 13 | `ServiceIdOrderingIsLexicographic` | 296 | 57 | `PropertyStrictWeakOrderingAxiomsOnVersionBoundaryDomain` | 1087 |
| 14 | `KeysDifferingInInstanceAreDistinct` | 310 | 58 | `PropertyIdentityEqualityClassesOnVersionBoundaryDomain` | 1115 |
| 15 | `DistinctInstancesProduceDistinctKeys` | 318 | 59 | `ConvertedInstanceTextPathsAgreeAtBoundaries` | 1149 |
| 16 | `EqualInstanceTextProducesEquivalentKeys` | 329 | 60 | `ConvertedPublicIdentityDistinguishesMinorBoundariesWhileKeyCollapses` | 1187 |
| 17 | `InstanceOrderingIsLexicographic` | 342 | 61 | `ServiceIdLadderOrdersLexicographicallyAndDistinctly` | 1218 |
| 18 | `ServiceInstanceMajorMatrixProducesDistinctKeys` | 358 | 62 | `InstanceIdLadderOrdersLexicographicallyAndDistinctly` | 1241 |
| 19 | `ServiceInstanceMajorMatrixCollapsesMinorVersions` | 372 | 63 | `MajorVersionLadderOrdersNumericallyAndDistinctly` | 1264 |
| 20 | `ThreeByThreeByThreeMatrixProducesDistinctKeys` | 388 | 64 | `MinorVariantsCompareIdenticallyAgainstWholeDomain` | 1292 |
| 21 | `ThreeByThreeByThreeMatrixCollapsesMinorVersions` | 402 | 65 | `StdSetCollapsesFiveMinorVariantsOfEveryIdentity` | 1321 |
| 22 | `KeyEquivalenceDependsOnInstanceServiceIdAndMajor` | 420 | 66 | `EquivalenceIsCompatibleWithStrictOrder` | 1343 |
| 23 | `MinorVersionNeverAffectsOrdering` | 430 | 67 | `OrderingAgreesWithTupleOrderOnMixedBoundaryDomain` | 1363 |
| 24 | `OrderingOrderIsInstanceThenServiceIdThenMajor` | 441 | 68 | `SingleComponentChangesBreakEquivalenceAcrossAllBases` | 1407 |
| 25 | `OrderingIsTransitive` | 460 | 69 | `PropertyStrictWeakOrderingOnCombinedRegistrationKeyDomain` | 1456 |
| 26 | `EquivalenceIsTransitive` | 473 | 70 | `PropertyIdentifierEqualityOnCombinedRegistrationKeyDomain` | 1488 |
| 27 | `MajorDifferenceOutweighsMinorDifference` | 486 | 71 | `ConvertedInterfaceConstructionPathsAgreeAtEveryVersionBoundary` | 1531 |
| 28 | `InstanceIsThePrimaryOrderingComponent` | 496 | 72 | `ConvertedInstanceRegistryIdPathAgreesWithTextPaths` | 1564 |
| 29 | `MajorIsTheTertiaryOrderingComponent` | 506 | 73 | `ConvertedKeyRetainsConfigWidthMajorBoundaries` | 1590 |
| 30 | `DistinctKeysAreOrderedInExactlyOneDirection` | 516 | 74 | `ServiceIdOrderingIsLexicographicNotNumeric` | 1625 |
| 31 | `StrictWeakOrderingHoldsAcrossMinorVariants` | 537 | 75 | `InstanceIdOrderingIsLexicographicNotNumeric` | 1641 |
| 32 | `SortingAgreesWithIndependentTupleOrder` | 563 | 76 | `MajorVersionByteBoundariesAreDistinctAndOrdered` | 1656 |
| 33 | `SetUniquenessMatchesDistinctIdentityTupleCount` | 588 | 77 | `MajorVersionOrderMatchesUnsignedNumericOrder` | 1680 |
| 34 | `SetIterationFollowsInstanceThenServiceIdThenMajor` | 609 | 78 | `MinorVariantsBoundDistinctIdentitiesWithoutBreakingOrder` | 1702 |
| 35 | `PropertyStrictWeakOrderingAxiomsHoldOnDeterministicDomain` | 634 | 79 | `MinorSweepCollapsesPerIdentityAtEveryMajorBoundary` | 1728 |
| 36 | `PropertyEquivalenceMatchesIdentityTupleOnDeterministicDomain` | 662 | 80 | `SetInsertionResultMatchesEquivalenceAcrossMinorVariants` | 1754 |
| 37 | `PropertyOrderingIsDeterministicTotalAndTupleConsistent` | 687 | 81 | `EquivalenceCoincidesWithIdentityOverFixtureCrossProduct` | 1777 |
| 38 | `PropertyEquivalenceClassesMatchDistinctIdentityTupleCount` | 712 | 82 | `OrderingIsAntiSymmetricOverFixtureCrossProduct` | 1818 |
| 39 | `PropertySetUniquenessIsIndependentOfInsertionOrder` | 735 | 83 | `KeyIdentityIsStableUnderRepeatedMinorRewritesOfTheSameIdentity` | 1851 |
| 40 | `PublicIdentifierIdentityDistinguishesMajorAndMinorBoundaries` | 784 | 84 | `ConvertedEmptyTextInterfacePathsAgreeAtVersionBoundaries` | 1882 |
| 41 | `ConvertedKeyRetainsInstanceServiceIdMajorAndStoresMinor` | 813 | 85 | `ConvertedEmptyTextInstancePathsAgreeWithRegistryPath` | 1929 |
| 42 | `ConvertedKeyMinorBoundariesCollapseToSingleIdentity` | 833 | 86 | `FreshDynamicServiceIdStringViewRegistersAndCollapses` | 1982 |
| 43 | `ConvertedKeyMajorBoundariesStayDistinct` | 847 | 87 | `FreshDynamicServiceIdRvalueRegistersAndCollapses` | 2012 |
| 44 | `ConvertedKeyTextAndRegistryConstructionAgreeAtBoundaries` | 861 | | | |

Record properties (both files): `DerivationTechnique` and `Description` only. `TestType`,
`PartiallyVerifies`, `FullyVerifies` are deliberately unset (no verified native
requirement/interface identifier exists; inventing one is prohibited).

### 4.2 Runtime suite — `score/socom/test/unit/runtime_tests.cpp`

**33 test macros: 1 `TEST` + 31 `TEST_F` + 1 `TEST_P`.** Status:
**UNEXECUTED** — no retained artifact compiled or ran this file (the host measurement
`changed_paths` is only `service_identifier_tests.cpp`; CodeQL extracted a focused executable
that excluded it; `native_tests`/`native_build` exit 127).

| # | Test ID | Kind | Line |
|---|---------|------|------|
| 1 | `RuntimeFactoryTest.DefaultConstructorWorks` | TEST | 239 |
| 2 | `RuntimeTest.RegisterServiceBridgeWithIncompleteCallbacksReturnsCallbacksMissing` | TEST_F | 279 |
| 3 | `RuntimeTest.RegisterServiceBridgeWitCallbacksReturnsRegistration` | TEST_F | 287 |
| 4 | `RuntimeTest.BridgeReceivesRequestServiceFunctionCallForUnknownService` | TEST_F | 295 |
| 5 | `RuntimeTest.BridgeDoesNotReceiveRequestServiceFunctionCallForKnownService` | TEST_F | 303 |
| 6 | `RuntimeTest.BridgeCreatesServerConnectorInRequestServiceFunctionCallbackAtClientConnectorCreation` | TEST_F | 311 |
| 7 | `RuntimeTest.ConstructDuplicateReturnsDuplicateServiceError` | TEST_F | 334 |
| 8 | `RuntimeTest.ConstructDuplicateMultipleTimesReturnsDuplicateServiceError` | TEST_F | 350 |
| 9 | `RuntimeTest.CreatingServerConnectorDeletingItAndRecreatingReturnsValidServerConnector` | TEST_F | 371 |
| 10 | `RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError` | TEST_F | 402 |
| 11 | `RuntimeTest.ConstructDuplicateSameConfigurationWhileBothConnectorsDisabledReturnsDuplicateServiceError` | TEST_F | 440 |
| 12 | `RuntimeTest.ConstructDifferentMajorWhileBothConnectorsDisabledReturnsDistinctServerConnectors` | TEST_F | 471 |
| 13 | `RuntimeTest.ConstructDifferentInstanceWhileBothConnectorsDisabledReturnsDistinctServerConnectors` | TEST_F | 505 |
| 14 | `RuntimeTest.ConstructDifferentServiceIdWhileBothConnectorsDisabledReturnsDistinctServerConnectors` | TEST_F | 538 |
| 15 | `RuntimeTest.ConstructDuplicateMinorBoundariesWhileBothConnectorsDisabledReturnsDuplicateServiceError` | TEST_F | 573 |
| 16 | `RuntimeTest.ConstructDuplicateWithSmallerMinorWhileBothConnectorsDisabledReturnsDuplicateServiceError` | TEST_F | 607 |
| 17 | `RuntimeTest.ConstructDuplicateRepeatedlyWhileBothConnectorsDisabledKeepsSlotHeld` | TEST_F | 642 |
| 18 | `RuntimeTest.ConstructDuplicateWhileFirstConnectorEnabledReturnsDuplicateServiceError` | TEST_F | 694 |
| 19 | `RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionWhileFirstConnectorEnabledReturnsDuplicateServiceError` | TEST_F | 726 |
| 20 | `RuntimeTest.ConstructDifferentInstanceWhileFirstConnectorEnabledReturnsDistinctServerConnectors` | TEST_F | 763 |
| 21 | `RuntimeTest.ConstructDifferentServiceIdWhileFirstConnectorEnabledReturnsDistinctServerConnectors` | TEST_F | 796 |
| 22 | `RuntimeTest.ConstructDuplicateMinorBoundariesWhileFirstConnectorEnabledReturnsDuplicateServiceError` | TEST_F | 832 |
| 23 | `RuntimeTest.ConstructDuplicateWithSmallerMinorWhileFirstConnectorEnabledReturnsDuplicateServiceError` | TEST_F | 869 |
| 24 | `RuntimeTest.ConstructDuplicateRepeatedlyWhileFirstConnectorEnabledKeepsSlotHeld` | TEST_F | 905 |
| 25 | `RuntimeTest.ConstructDifferentMajorWhileFirstConnectorEnabledReturnsDistinctServerConnectors` | TEST_F | 951 |
| 26 | `RuntimeTest.ConstructDuplicateAfterEnabledConnectorDestroyedReturnsValidServerConnector` | TEST_F | 986 |
| 27 | `RuntimeTest.ConnectorDestroyedAfterRuntimeDoesNotCrash` | TEST_F | 1021 |
| 28 | `RuntimeTest.ConstructDuplicateAfterDisabledConnectorDestroyedWithChangedMinorVersionReturnsValidServerConnector` | TEST_F | 1045 |
| 29 | `RuntimeTest.ConstructDuplicateAfterEnabledConnectorDestroyedWithChangedMinorVersionReturnsValidServerConnector` | TEST_F | 1091 |
| 30 | `RuntimeTest.DestroyingOneMajorSlotKeepsOtherMajorSlotOccupied` | TEST_F | 1141 |
| 31 | `RuntimeTest.DestroyingOneInstanceSlotKeepsOtherInstanceSlotOccupied` | TEST_F | 1197 |
| 32 | `RuntimeTest.DestroyingOneServiceIdSlotKeepsOtherServiceIdSlotOccupied` | TEST_F | 1253 |
| 33 | `RuntimeBridgeTest.CreationOfClientsWillCallRequestServiceFunction` | TEST_P | 1311 |

The `native_tests` target would also compile the other `score/socom/test/unit/*.cpp` files
(globs `*.cpp`); those are likewise **UNEXECUTED** natively.

### 4.3 Pass / fail / skipped summary

| Suite / state | Tests | Pass | Fail | Skipped | Unexecuted | Evidence |
|---------------|-------|------|------|---------|-----------|----------|
| Key suite, focused GCC (current 87-case file) | 87 | 87 | 0 | 0 | 0 | `compiler_diagnostics/gcc-tests.json` |
| Key suite, focused coverage (current) | 87 | 87 | 0 | 0 | 0 | `focused_coverage/tests.json` |
| Key suite, focused ASan/LSan/UBSan (current) | 87 | 87 | 0 | 0 | 0 | `focused_asan_lsan` exit 0 |
| Key suite, host hook (stale 85-case state) | 85 | 85 | 0 | 0 | 0 | `validation/after.json` |
| Key suite, host hook **baseline key (minor included)** | 85 | 57 | **28** | 0 | 0 | `validation/before.json` |
| Runtime suite (33 cases) | 33 | — | — | — | **33** | no artifact |
| Broader `socom_test` / `//score/...` | — | — | — | — | **all** | `native_tests` exit 127 |

The 28 baseline failures are the minor-version-collapse regressions (e.g.
`KeysDifferingOnlyInMinorVersionAreDuplicates`, `MinorVersionBoundariesAreDuplicates`,
`AllMinorVersionsCollapseToSingleKey`, `MinorHighBitVariantsAreEquivalent`,
`ServiceInstanceMajorMatrixCollapsesMinorVersions`,
`ThreeByThreeByThreeMatrixCollapsesMinorVersions`,
`KeyEquivalenceDependsOnInstanceServiceIdAndMajor`, `MinorVersionNeverAffectsOrdering`,
`EquivalenceIsTransitive`, the `Property*` equivalence checks). They fail on the **minor-aware**
key and pass on the corrected key — the direct measured evidence for the slice.

---

## 5. Coverage

Measured from `focused_coverage/result.json` (`check_ref: recollect_focused_coverage`,
`status: completed`), production filter `score/socom/impl/`, tests/third-party excluded:

| Metric | Measured | QM goal (`verification_plan.rst` criterion 1–2) | Safety goal | Verdict |
|--------|----------|--------------------------------------------------|-------------|---------|
| Line / statement | **36/36 = 100.0 %** | 85 % | 100 % | meets QM and safety |
| Branch | **11/14 = 78.6 %** | 85 % | 100 % | **meets neither** |

Per-file split:

| File | Line | Branch |
|------|------|--------|
| `score/socom/impl/service_identifier.cpp` | 3/3 (100 %) | 1/2 (50 %) |
| `score/socom/impl/string_registry.cpp` | 33/33 (100 %) | 10/12 (83.3 %) |
| **Total** | **36/36 (100 %)** | **11/14 (78.6 %)** |

**Uncovered branches (3, all compiler-generated).**

1. `service_identifier.cpp:28` — `throw` edge of the `std::tie` comparison (count 0). This is
   the only uncovered **changed** branch; there are **no uncovered changed lines**
   (`:20` count 1091415, `:28` 1091415, `:29` 2182830).
2. `string_registry.cpp:66` — exception edge of the function-local static guard (count 0).
3. `string_registry.cpp:71` — exception edge of the function-local static guard (count 0).

An earlier retained capture recorded 28/36 lines (77.8 %) and 9/14 branches (64.3 %); the two
dynamic-registration cases (#86 `FreshDynamicServiceIdStringViewRegistersAndCollapses` `:1982`,
#87 `FreshDynamicServiceIdRvalueRegistersAndCollapses` `:2012`) close the reachable
`string_registry.cpp:38-42` / `:55-59` gap.

**Scope limits.** `complete_target_scope: false`; the figure is the focused identifier
executable only. `native_coverage` (`bazel coverage`) is `findings_or_execution_failure`
(exit 127). The repository CI line threshold 73 is a *different* gate and is **not** the
platform acceptance basis. The safety class is `unknown`; no deviation is accepted.

---

## 6. Analyzer findings

No tool retained a Critical/High/Medium/Low rating (CodeQL `level: null` everywhere; cppcheck
emits only `performance`; the compiler emits `error`; clang-tidy ran no analysis). Per
`gd_req__verification_sca_classification` (`verification_process.rst:228-248`), classification
requires a Quality Manager together with a committer; **none exists**.

| Check | Command outcome | Findings | Scope / scope limit | Status |
|-------|-----------------|----------|---------------------|--------|
| Compiler — GCC (focused) | `g++-12 -std=c++17 -Wall -Wextra -Werror`, **compile exit 0**, `gcc-tests` **87/0, exit 0** | none | focused TU | clean focused, **not** full-target criterion 9 |
| Compiler — Clang (focused) | **compile exit 1** | 1 error: `-Wdeprecated-declarations` (`get_temporary_buffer<testing::TestInfo*>`) in libstdc++-12 `bits/stl_tempbuf.h:263` via `gtest.cc:3068` | dependency (libstdc++ + vendored googletest) | **blocker, not candidate defect** |
| clang-tidy | `--verify-config` **exit 1**; 15 `unknown check` warnings | **no analysis — NOT RUN** | repository `.clang-tidy` (`Checks: >` folds `#` comments into check names) | **NOT RUN ≠ clean** |
| cppcheck | **exit 2** | 19 × `passedByValue` (`severity=performance`, CWE 398) | every location in out-of-slice headers `registry_string_view.hpp` (`:127,134,141,148,155,162,173`) and `service_interface_identifier.hpp` (`:37,41,48,99,105,113`) | retained; out of scope |
| CodeQL security (2.21.4, `cpp-security-and-quality.qls`) | db-create + analyze **exit 0**, `scan_runs: 1` | **32**, all under `.llm_tmp/googletest/**` (`cpp/fixme-comment` 1, `cpp/commented-out-code` 7, `cpp/large-parameter` 1, `cpp/equality-on-floats` 2, `cpp/unused-static-function` 2, `cpp/unused-static-variable` 1, `cpp/rule-of-two` 1, `cpp/include-non-header` 9, `cpp/trivial-switch` 2, `cpp/loop-variable-changed` 2, `cpp/path-injection` 4) | focused linked executable; **no project/candidate finding** (`level: null`) | retained, dependency-only |
| CodeQL MISRA (coding-standards 2.61.0, `misra-cpp-default.qls`) | analyze **exit 0**; 218 queries loaded | large findings set (dominated by googletest; also gtest `TEST_F` macro expansion in the candidate test file; plus out-of-slice `string_registry.cpp`/`.hpp`); `level: null` | focused extraction; **`runtime_tests.cpp` not extracted** | retained; **mapping `:status: draft`** |
| Sanitizers — ASan/LSan/UBSan | compile **exit 0**, tests **exit 0** | none | focused identifier executable | **PASS (focused)** |
| Sanitizers — TSan | compile exit 0, tests **exit -11 (SIGSEGV)** | no usable result | focused; single-threaded tests | **environment failure** |
| memcheck (valgrind) | **exit 127** (`valgrind` missing) | none produced | n/a | **tool unavailable** |
| gitleaks (secret scan) | **exit 127** (`gitleaks` missing) | none produced | repo | **NOT RUN** |
| dependency inventory | retained | 29 direct Bazel deps + `lock_sha256 c90b245b…`; collector blocker: *"dependency inventory is not a vulnerability scan"* | module-wide | **inventory, not a scan** |
| format / pre-commit / reuse | **exit 127** (`bazel`/`pre-commit`/`reuse`/`clang-format` missing) | none | disposable collector copy | **NOT RUN** |

**Key point.** No finding lands in `score/socom/impl/service_identifier.cpp` or `.hpp`; the
candidate test-file MISRA findings are gtest `TEST_F` macro-expansion artifacts; the
`string_registry.*` MISRA findings are repository production code **outside** the six candidate
paths and are retained (no in-source justification exists, and adding one is outside this
review's write boundary). None of these is a compliance statement.

---

## 7. Release-evidence archive index

All paths are under this checkout. A retention marker is **not** a pass. Artifacts whose results
failed or did not run are marked accordingly.

### 7.1 Host validation

| Artifact | Key content | Status |
|----------|-------------|--------|
| `.llm_tmp/overnight/validation/check-result` | `0` (collector success marker only) | retention marker |
| `.llm_tmp/overnight/validation/measurement.json` | `check_ref: check_conversion_tests`; `origin: local_unprotected_measurement`; `initiator: Fabro host hook`; `mode: ubsan`; `engineering_acceptance: pending`; `full_native_tests: not_executed`; compiler `g++-12` (`88315fd2…`); `baseline_with_agent_tests` 85/28/compile 0; `candidate` 85/0/compile 0; `changed_paths: [service_identifier_tests.cpp]` (hash `65c10517…`, 85-case state) | **completed; stale** (executed 85 vs 87 on disk) |
| `.llm_tmp/overnight/validation/before.json` | baseline-with-agent-tests JUnit: 85 tests / 28 failures | red baseline (minor-aware key) |
| `.llm_tmp/overnight/validation/after.json` | candidate JUnit: 85 tests / 0 failures | green candidate (corrected key) |
| `.llm_tmp/overnight/validation/{before,after}-{compile,test}.{command.json,stdout,stderr}` | focused compile/test captures; `after-compile.stderr` empty; compile of `service_identifier.cpp` (transitively includes the flagged header) | corroborates balanced header |

### 7.2 Obligation-collection results (`.llm_tmp/overnight/obligations/<check>/`)

| Check dir | Status | What it evidences |
|-----------|--------|-------------------|
| `compiler_diagnostics/` | `findings_or_execution_failure` | GCC compile+tests exit 0 (87/0); Clang compile exit 1 (dependency deprecation) |
| `focused_coverage/` | `completed` | 36/36 lines (100 %), 11/14 branches (78.6 %) |
| `focused_asan_lsan/` | `completed` | focused ASan/LSan/UBSan exit 0 |
| `focused_tsan/` | `findings_or_execution_failure` | tests exit -11 (SIGSEGV) |
| `focused_memcheck/` | `findings_or_execution_failure` | exit 127 (valgrind missing) |
| `focused_cppcheck/` | `findings_or_execution_failure` | exit 2; 19 out-of-slice `passedByValue` |
| `focused_clang_tidy/` | `findings_or_execution_failure` | `--verify-config` exit 1; blocker *"Native analyzer configuration incompatible; no replacement called MISRA"*; **no analysis** |
| `codeql_security/` | `findings_or_execution_failure` | 32 dependency-only findings; `scan_runs: 1` |
| `codeql_misra/` | `findings_or_execution_failure` | large dependency/macro/out-of-slice set; `level: null` |
| `native_build/` | `findings_or_execution_failure` | exit 127 (`bazel` missing) |
| `native_tests/` | `findings_or_execution_failure` | exit 127 (`bazel` missing) |
| `native_coverage/` | `findings_or_execution_failure` | exit 127; limit *"Repository CI threshold 73 is not platform 85/100 line-and-branch acceptance"* |
| `native_lint/` | `findings_or_execution_failure` | exit 127 |
| `native_sanitizers/` | `findings_or_execution_failure` | exit 127 |
| `native_tsan/` | `findings_or_execution_failure` | exit 127 |
| `native_integration/` | `findings_or_execution_failure` | exit 127; QEMU/KVM prerequisites present |
| `native_docs/` | `findings_or_execution_failure` | exit 127 |
| `native_performance/` | `findings_or_execution_failure` | exit 127 |
| `native_traceability/` | `findings_or_execution_failure` | exit 127 |
| `cross_compilation/` | `findings_or_execution_failure` | exit 127 |
| `format_precommit/` | `findings_or_execution_failure` | exit 127; mutations confined to disposable copy |
| `secret_dependency_checks/` | `findings_or_execution_failure` | gitleaks exit 127; 29-dep inventory + `lock_sha256 c90b245b…` |
| `tool_assurance/` | retained (no status field; blockers present) | tool paths + hashes; `valgrind`, `gitleaks`, `reuse`, `pre-commit`, `clang-format`, `bazel` unavailable; blocker *"Tool confidence evaluation, qualification where applicable, and acceptance require authorized humans"* |
| `process_checks/` | `completed_with_blockers` | metadata inventory: `runtime_tests.cpp` 33 macros, `service_identifier_tests.cpp` 87 macros; blockers include *"Lexical metadata inventory cannot prove semantic requirement coverage"* and *"Independent inspection and acceptance required"* |
| `rework_progress/` | `completed` | `source_changed_this_round: true`, `rework_requested: false`, stop reason *"One complete pass requested; unresolved findings stay pending"* |

### 7.3 Reports (read and preserved)

`.llm_tmp/overnight/prior-reports/` — 12 files: `callsites.md`, `conversion_tests.md`,
`invariants.md`, `key_fix.md`, `lifetime_tests.md`, `ordering_tests.md`, `reproducer.md`,
`runtime_disabled.md`, `runtime_enabled.md`, `scope.md`, `test_metadata.md`, `unit_matrix.md`.

`.llm_tmp/overnight/reports/` — the earlier reports of this run, all preserved:
`analyzer_plan.md`, `api_review.md`, `bazel_plan.md`, `callsites.md`, `compatibility.md`,
`concurrency_review.md`, `conversion_tests.md`, `coverage_review.md`, `coverage_tests_repair.md`,
`cross_target_review.md`, `design_inspection_draft.md`, `deviation_drafts.md`,
`finding_classification.md`, `integration_aou_review.md`, `invariants.md`, `key_fix.md`,
`lifetime_review.md`, `lifetime_tests.md`, `misra_applicability.md`, `misra_manual_review.md`,
`native_build_review.md`, `ordering_tests.md`, `performance_review.md`, `reproducer.md`,
`runtime_disabled.md`, `runtime_enabled.md`, `sanitizer_review.md`, `scope.md`,
`security_review.md`, `test_metadata.md`, `tool_assurance_review.md`, `tool_findings_repair.md`,
`traceability_review.md`, `unit_matrix.md`. **This document adds `verification_report_draft.md`.**

---

## 8. Earlier attempts (chronology of this slice)

Derived sequence across the preserved reports; all on the same baseline commit
`f8a196c3…`:

1. `scope.md` — bounded the slice to the duplicate-server registration key; identified I-11
   (key included `minor` while the record index ignored it).
2. `invariants.md` (I-1…I-16) — I-4 baseline ordering `(instance, id, major, minor)`; I-9
   record index ignores `minor`; I-11 the resulting assert/UB gap.
3. `callsites.md` — call-site map (`Runtime_impl::make_server_connector`,
   `Service_record::register_server_connector`, the key set).
4. `reproducer.md` — key-level regression + test-only header exposure + the header brace
   correction (this iteration made the header balanced and left line 39 blank).
5. `key_fix.md` / `unit_matrix.md` — drop `minor` from the ordering; expand key tests.
6. `ordering_tests.md`, `conversion_tests.md` — property and conversion-boundary tests.
7. `runtime_disabled.md`, `runtime_enabled.md`, `lifetime_tests.md` — runtime duplicate /
   lifetime regressions (never executed in any retained artifact).
8. Later host-side iterations referenced but not present here: `repair_unit_matrix.md`,
   `coverage_tests_repair.md`, `tool_findings_repair.md`, a host addendum
   `obligation-addendum.md` (recorded only as quoted by other prior reports).
9. `coverage_review.md` — branch coverage shortfall; reached 36/36 lines after the two
   dynamic-registration tests.
10. `finding_classification.md` / `misra_applicability.md` / `misra_manual_review.md` —
    analyzer reconciliation and the draft MISRA mapping.
11. `security_review.md`, `tool_assurance_review.md`, `integration_aou_review.md`,
    `traceability_review.md`, `design_inspection_draft.md`, `deviation_drafts.md` — security
    posture, tool qualification, AoU questions, traceability gaps, and draft dispositions.

The only measured outcome change across these attempts is the key-level test outcome:
baseline (minor included) 85/28 red → candidate 85/0 and 87/0 green, plus coverage rising from
28/36 lines, 9/14 branches to 36/36 lines, 11/14 branches.

---

## 9. Deviations and unexecuted applicable checks (all remain blockers)

No deviation is accepted, and none may be self-accepted. The draft dispositions recorded in
`deviation_drafts.md` (bound to exact rule id, location, and source hash) remain
**DRAFT / pending**:

| Id | Finding | Scope | Draft disposition (not accepted) |
|----|---------|-------|----------------------------------|
| DD-1 | MISRA 6.5.1 `external-linkage-not-declared-in-header-file-misra` | candidate test file (gtest `TEST_F` macro) | false positive as to authored body / deviation alternative |
| DD-2 | MISRA 9.3.1 `switch-body-compound-condition` | candidate test file (macro) | false positive (macro artifact) |
| DD-3a | MISRA 7.0.1 `no-conversion-from-bool` | candidate test file (macro) | false positive (macro artifact) |
| DD-3b | MISRA 7.0.1 `no-conversion-from-bool` | `string_registry.cpp` (out of slice) | deviation requested (no in-source justification) |
| DD-4 | MISRA 21.6.1 `dynamic-memory-should-not-be-used` | `string_registry.hpp` (out of slice) | deviation requested |
| DD-5 | MISRA 6.7.1 `local-variable-static-storage-duration` | `string_registry.cpp` (out of slice) | deviation requested |
| DD-6 | MISRA 0.1.1 `unnecessary-write-to-local-object` | `string_registry.cpp` (out of slice) | false positive (RAII) / deviation alternative |
| DD-7 | cppcheck `passedByValue` ×19 | `registry_string_view.hpp`, `service_interface_identifier.hpp` (out of slice) | deviation requested (performance style) |
| DD-8 | Clang `-Wdeprecated-declarations` under `-Werror` | libstdc++-12 / vendored googletest | dependency false positive / toolchain decision |
| DD-9 | CodeQL security 32 findings | `.llm_tmp/googletest/**` | dependency false positive |
| FP-1 | Recorded "extra `}` at `service_identifier.hpp:39`" | header hash `bdce3fcb…` | not reproducible / stale defect |

**Unexecuted or non-passing applicable checks (blockers).**

- **Runtime suite (33 tests) — UNEXECUTED** and no Bazel `socom_test`/`//score/...` run.
- **Criterion 2 branch coverage — NOT MET** (78.6 % < 85 % QM and < 100 % safety); no
  deviation accepted.
- **Clang compile — FAILED** on a dependency deprecation; criteria-9 warnings-as-errors native
  build **not run**.
- **clang-tidy — NOT RUN** (config rejected).
- **TSan — no usable result** (SIGSEGV); **memcheck — unavailable**.
- **gitleaks secret scan — NOT RUN**; **dependency-vulnerability scan — NOT PERFORMED**
  (inventory ≠ scan).
- **native_build / native_tests / native_integration / native_coverage / native_lint /
  native_docs / native_traceability / native_sanitizers / native_tsan / native_performance /
  cross_compilation / format_precommit — exit 127** (`bazel`/tooling missing).
- **MISRA mapping and inspection checklist — `:status: draft`**; no rule applicability
  asserted.
- **SCA classification — NOT DONE** (no QM+committer class).
- **Independence — NOT DONE** (human reviews unanswered).

---

## 10. Obligations status (none satisfied)

| Obligation / check | Pinned source | Status |
|--------------------|---------------|--------|
| Freedom from compiler warnings & errors (criterion 9, 100 %) | `verification_plan.rst` | **PARTIAL / NOT SATISFIED** — focused GCC clean (87/0); Clang blocked by a dependency; no native warnings-as-errors build |
| Static code analysis executed, findings classified | `code_analysis.rst`; `verification_process.rst` (`gd_req__verification_sca_classification`) | **PARTIAL / NOT DONE** — clang-tidy not run; CodeQL focused/dependency-heavy; no authorized class |
| Freedom from SCA critical/high (criterion 8) | `verification_plan.rst` | **NOT MEASURED** — no classification |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` (`:status: draft`) | **UNKNOWN — NOT CLAIMED** |
| Structural statement (line) coverage (criterion 1) | `verification_plan.rst` | **MET for focused TU only** (36/36 = 100 %); not full target |
| Structural branch coverage (criterion 2) | `verification_plan.rst` | **NOT MET** (11/14 = 78.6 %) |
| Unit/component testing executed, recorded (criteria 6–7) | `verification_plan.rst`; `verification_guideline.rst` | **PARTIAL / STALE** — 87/0 focused; runtime suite unexecuted; host measurement 85-case |
| Interface / requirements-based / resource / fault-injection test types | `verification_process.rst` | **NOT PERFORMED / applicability not inferred** |
| Fuzzy testing technique | `verification_plan.rst` | **NOT EXECUTED / NOT CLAIMED** |
| Linking tests to requirements (record properties) | `verification_process.rst` (`gd_req__verification_link_tests_cpp`) | **PARTIAL** — `DerivationTechnique`/`Description` set; `TestType`/`Verifies` unset (no invented identifiers) |
| External AoUs verified | `verification_process.rst` | **NOT SATISFIED** |
| Implementation inspection checklist IMPL_01…IMPL_03 | `inspection_checklist.rst` (`:status: draft`) | **NOT FILLED** |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** |
| Independence of verification / review | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** |
| Deviation / risk acceptance | `authority.json` | **NONE** — all drafts pending |
| Obligation collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **RETAINED, NOT PASSING** |
| Native acceptance | `source-index.json` | **`not_inferred` for every entry** |

**Explicit non-satisfaction statement.** Missing tools (`bazel`, `valgrind`, `gitleaks`,
`clang-format`, `pre-commit`, `reuse`), the non-running clang-tidy, the focused/incomplete
CodeQL extraction, the draft/inactive MISRA mapping, the unmet branch goal, the unexecuted
runtime suite, the stale host measurement, the unknown safety class and un-inferred
applicability, and the unanswered human reviews mean **none of the checked obligations may be
treated as satisfied**.

---

## 11. Notice preservation

- **Only this report was written.** No source, build, test, config, `NOTICE`, `LICENSE`, or
  `REUSE.toml` file was created, edited, or deleted.
- The flagged header `score/socom/impl/service_identifier.hpp` was inspected and is already
  brace-balanced (§2); it retains its Apache-2.0/SPDX header (`:1-12`), as do the sibling
  `.cpp` (`:1-12`), both `BUILD` files, and both candidate test files.
- All 12 files under `.llm_tmp/overnight/prior-reports/`, all 34 earlier files under
  `.llm_tmp/overnight/reports/`, and all host/obligation artifacts under
  `.llm_tmp/overnight/validation/` and `.llm_tmp/overnight/obligations/` were read only and are
  preserved unchanged.
- This report itself carries the Apache-2.0 header. No licensed MISRA rule text is reproduced;
  only native rule/query identifiers, source hashes, and file locations are cited.

---

## 12. Pending human review checklist

- [ ] **Confirm §2:** `service_identifier.hpp` is brace-balanced (braces at `:19,:29,:32,:38`;
      line 39 blank), so the recorded "extra closing brace at line 39" is stale and no source
      correction is required in this checkout. If a distinct "cancelled draft" revision still
      carries the brace, locate and correct it by an authorized iteration.
- [ ] **Resolve the instruction conflict:** "inspect and correct the actual source" vs. "only
      that report may be written"; confirm inspection-only was intended.
- [ ] **Confirm the coupled key decision:** `minor` is **not** part of the duplicate-server
      registration key; identity `(instance, service id, major)`; interface representation and
      the exact-major / minimum-minor rules unchanged.
- [ ] **Refresh the measurement:** run `bazel test //score/socom/test/unit:socom_test` (and the
      broader `//score/...` set) so `runtime_tests.cpp` and all 87 key cases are compiled and
      executed; do not re-report the 85-case focused artifact as coverage of the current tree.
- [ ] **Decide the criterion-2 plan:** document the branch-coverage deviation, or authorize a
      coverage-exclusion policy, or a source change (`noexcept` alone leaves 84.6 %); select the
      safety class.
- [ ] **Repair and run clang-tidy** (unfold the `.clang-tidy` `Checks: >` block); **run a
      full-target CodeQL extraction** including `runtime_tests.cpp`; **complete/activate the
      MISRA mapping** and the inspection checklist.
- [ ] **Complete the mandated SCA classification** (`gd_req__verification_sca_classification`)
      by the Quality Manager together with a committer; treat the draft dispositions in §9 as
      review aids only.
- [ ] **Run a secret scan** (provide `gitleaks` or equivalent) and adopt a
      dependency-vulnerability process (CVE/OSV/GHSA mapping or SBOM scanner over `lock_sha256
      c90b245b…`).
- [ ] **Restore guarded tools** (`bazel`, `valgrind`, `clang-format`, `pre-commit`, `reuse`) and
      re-run the native build/test/coverage/analyzer/integration/traceability checks.
- [ ] **Supply native requirement/interface identifiers** for traceability (no invented links),
      or record applicability unresolved.
- [ ] **Schedule independent human review** (approver ≠ author, `gd_req__verification_independence`)
      and record engineering acceptance; **do not upload** any report/SARIF/database
      (`codeql_scope`: no upload).
- [ ] **Keep the wider #84 restructure** (public `Service_interface_identifier`, FindService
      wildcard, config `0xFFFFFFFF` minor narrowing) out of this bounded slice until separately
      accepted; do not present the identifier-only tests as platform validation or claim an
      unmeasured fuzzy technique.

---

*End of verification-report draft. Local, unprotected, scoped. No engineering acceptance; human
reviews unanswered; full native runtime tests pending; the runtime suite is unexecuted, branch
coverage is below both platform goals, and no deviation or risk decision is accepted. All
unexecuted applicable checks and deviations remain blockers.*
