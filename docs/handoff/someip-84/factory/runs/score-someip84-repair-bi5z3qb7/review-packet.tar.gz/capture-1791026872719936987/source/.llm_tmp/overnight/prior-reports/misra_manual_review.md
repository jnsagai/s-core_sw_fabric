<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — manual coding-guideline inspection of the changed
# duplicate-server registration-key implementation (`misra_manual_review`)

**Document type:** review draft (actual-source manual inspection of the changed
implementation against the pinned C++ coding guideline; initialization / lifetimes /
conversions / ordering / error handling / concurrency; verified-identifier register;
obligations status)

**Date:** 2026-10-02
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version
handling in socom* (issue #84)
**Run:** branch `fabro/run/01M3YRJEGXNY6CB81T7TKW774B`
**Status:** local, unprotected, scoped. **No engineering acceptance exists. Human
reviews are unanswered. Full native runtime tests remain pending.** Every statement
below is either a direct static reading of this checkout, a reading of a retained
artifact under `.llm_tmp/overnight/`, or an explicitly-labelled logical consequence.
Nothing here is published, reviewed, accepted, or a full native run. **No MISRA
C++:2023 compliance is claimed, and no MISRA rule identifier is asserted to
"apply" to this slice** (§7).

> **Tool / write boundary actually observed.** Only `read_file`, `grep`, `glob`, and
> `write_file` were available and were the only tools used. No `shell`, no delegation,
> no web access, no approval, no publishing, and no engineering acceptance was
> performed. The task ends with *"This is a review draft: only that report may be
> written."* **This iteration wrote exactly one file — this report.** No source,
> build, test, config, `NOTICE`, `LICENSE`, `REUSE.toml`, or prior-report file was
> created, edited, or deleted. Every prior report under
> `.llm_tmp/overnight/prior-reports/` and every earlier report under
> `.llm_tmp/overnight/reports/` was preserved unchanged.
>
> **Source-correction instruction vs. review-draft boundary (recorded, not silently
> resolved).** The task records *"a measured GCC syntax failure: an extra closing
> brace in `score/socom/impl/service_identifier.hpp` at line 39"* and directs *"Inspect
> and correct the actual source before expanding tests."* Direct inspection of the
> *actual* checkout (§2) shows the header is **already brace-balanced**; line 39 is
> blank and line 40 is `#endif`. There is no unmatched brace to remove. The task's
> final sentence forbids a source write in any case. The two instructions conflict;
> the conflict is recorded for the human reviewer (§11) and **no source was edited.**
> No test was expanded either, because the draft's expanded suites already exist on
> disk (read, not executed, §8).
>
> **Non-satisfaction rule applied throughout.** A successful obligation-collection node
> means the results were **retained**, not that the checks **passed**. Missing tools,
> unknown applicability, incomplete extraction, an inactive rule mapping, a blank
> inspection checklist, and unanswered human reviews are **not** treated as satisfied
> (§9).

---

## 0. Summary

1. **The changed implementation is the registration-key comparator only, and its
   manual inspection finds no confirmed safety-relevant defect in the six named
   implementation topics.** The changed constructs are
   `Service_instance_identifier` (`score/socom/impl/service_identifier.hpp:29-32`) and
   its `operator<` (`score/socom/impl/service_identifier.cpp:20-30`). The comparator
   orders by `(instance, service id, major)` and deliberately excludes `minor`.
2. **Initialization is safe and compile-enforced** (§5.1). The key is an aggregate of
   two class-typed members declared `interface` then `instance`; the sole production
   use aggregate-initializes both (`runtime_impl.cpp:443`), and the type is not
   default-constructible, so there is no path to an indeterminate member.
3. **Lifetimes are non-owning but valid under the registry contract** (§5.2). The key
   stores two `Registry_string_view`s into the process-wide, append-only
   `String_registry` singletons. The registry-validity contract is explicit
   (`registry_string_view.hpp:29-30`) and currently satisfied; the residual
   static-destruction-order hazard and the key-`weak_ptr` guard are recorded.
4. **No conversion or narrowing is performed by the changed code** (§5.3). The
   comparator reads a `std::uint16_t` and two `Registry_string_view`s through
   `std::tie`; no casts, no arithmetic, no width change. (The out-of-slice config
   `uint32 → uint16` narrowing is untouched.)
5. **Ordering is a valid strict weak ordering** (§5.4): lexicographic `std::tie`
   over three components each carrying a strict weak order. The one latent
   inconsistency is that `Registry_string_view::operator<` is **content**-based while
   `operator==`/`std::hash` are **pointer**-based (`registry_string_view.hpp:127-129`,
   `:141-143`, `:186-193`); they coincide only because `String_registry` interns by
   content. Recorded as an invariant to preserve, not a confirmed defect.
6. **Error handling is `Result`-based and leak-free on the failure path** (§5.5):
   `duplicate_service` is returned (`runtime_impl.cpp:451-452`), consistent with
   `coding_guidelines.rst:117-129`; `is_valid` runs before key insertion, so a
   `callback_missing` return does not leak a key. Two manual findings: the comparator
   is not declared `noexcept` though it cannot throw (MF-2), and the
   `Construction_error::duplicate_service` comment is now narrower than the key it
   guards (MF-3).
7. **Concurrency is lock-disciplined** (§5.6): the comparator is a pure read invoked
   only under the key mutex; the registry views it reads are immutable-by-append. The
   cross-lock single-server invariant (key identity == record index identity) is the
   property this change establishes; the teardown-declaration-order fragility is a
   related, unmodified hazard.
8. **No obligation is satisfied** (§9). `misra_mapping.rst` is `:status: draft` with a
   commented-out table and no CSV; `inspection_checklist.rst` is `:status: draft` and
   blank; `authority.json` records `engineering_acceptance: pending`,
   `human_reviews: unanswered`, `safety_class: unknown`; every `source-index.json`
   entry is `native_acceptance: not_inferred`. The retained CodeQL MISRA extraction
   carries its own blockers (draft mapping; default suite omits manual/audit
   obligations; query qualification/human deviations pending).

---

## 1. Binding, evidence, and prior work

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` — *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:2-4` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` | `.llm_tmp/context/issue-snapshot.json:19-20` |
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an
accepted obligation**: service-instance identifier = `service id + major + minor +
instance id`; service identifier = `service id + major`; FindService = `service id +
major + optional<minor> + optional<instance>`; and the proposal to "exclude the minor
version and make it a property of the service instance". There is no comment and no
acceptance record, so none of it is binding. Binding is **by baseline commit**, not by
run HEAD.

### 1.2 Candidate set (the only writable source paths)

From `.llm_tmp/context/candidate-files.json`:

1. `score/socom/BUILD`
2. `score/socom/impl/service_identifier.cpp`
3. `score/socom/impl/service_identifier.hpp`
4. `score/socom/test/unit/BUILD`
5. `score/socom/test/unit/runtime_tests.cpp`
6. `score/socom/test/unit/service_identifier_tests.cpp` (manifest baseline blob `null`
   — a **new** file)

`glob **/service_identifier.*` returns exactly two files
(`impl/service_identifier.{cpp,hpp}`); `glob **/*.{orig,rej,bak}` returns nothing, so
there is no second, differently-braced copy and no leftover patch/reject in this
checkout.

### 1.3 Pinned obligation sources and authority (read this iteration)

All nine entries of `.llm_tmp/context/obligations/source-index.json` are present
together with `authority.json`:

| id | file | status |
|----|------|--------|
| `coding_guidelines` | `coding_guidelines.rst` | `:status: valid`; **MISRA C++:2023, C++17** (`:30-36`, `:74`) |
| `code_analysis` | `code_analysis.rst` | `:status: valid`; MISRA/ISO 26262-based SCA |
| `misra_mapping` | `misra_mapping.rst` | **`:status: draft`; rule `csv-table` commented out** (`:20`, `:26-31`) |
| `verification_plan` | `verification_plan.rst` | `:status: valid`; quality criteria 1-9 |
| `development_plan` | `development_plan.rst` | `:status: valid` |
| `tool_management` | `tool_management.rst` | `:status: valid`; identify / evaluate / qualify |
| `verification_process` | `verification_process.rst` | `:status: valid`; SCA classification, test links |
| `verification_guideline` | `verification_guideline.rst` | `:status: valid` |
| `inspection_checklist` | `inspection_checklist.rst` | **`:status: draft`, blank `IMPL_01_01`…`IMPL_03_02`** |

Every entry is `native_acceptance: not_inferred`. `authority.json` records
`codeql_scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload"`,
`engineering_acceptance: pending`, `human_reviews: unanswered`, `safety_class:
unknown`, and the instruction *"Restart the failed queue for one complete pass
through all obligations"*.

### 1.4 Prior reports and retained host/collector evidence read

- `.llm_tmp/overnight/prior-reports/` — 12 files, all read and preserved (`scope.md`,
  `invariants.md`, `callsites.md`, `reproducer.md`, `key_fix.md`, `unit_matrix.md`,
  `ordering_tests.md`, `conversion_tests.md`, `runtime_disabled.md`, `runtime_enabled.md`,
  `lifetime_tests.md`, `test_metadata.md`).
- `.llm_tmp/overnight/reports/` — read and preserved; this document is an additional
  entry. The most directly relevant are `key_fix.md` (key correction),
  `ordering_tests.md`, `lifetime_review.md` (CE-1…CE-6), `concurrency_review.md`
  (RCC-1…RCC-6, AS-1…AS-6), and `misra_applicability.md` (mapping and CodeQL reading).
- `.llm_tmp/overnight/validation/` — present: `check-result` = `0`;
  `measurement.json` (`origin: local_unprotected_measurement`, `initiator: Fabro host
  hook`, `engineering_acceptance: pending`, `full_native_tests: not_executed`,
  compiler `/usr/bin/x86_64-linux-gnu-g++-12`; `baseline_with_agent_tests` 85 tests /
  28 failures / compile 0; `candidate` 85 tests / 0 failures / compile 0);
  `after.json` 85/0; focused `before-*`/`after-*` GCC compile captures.
- `.llm_tmp/overnight/obligations/` — present; **per the task rule, retention is not
  passing.** Relevant statuses: `compiler_diagnostics`
  `findings_or_execution_failure` with `gcc-compile` exit `0`, `gcc-tests` exit `0`,
  `clang-compile` exit `1`; `codeql_misra` `findings_or_execution_failure`
  (database-create and analyze exit `0`), blockers *"MISRA applicability/mapping draft
  and incomplete"*, *"Default suite omits manual/audit obligations"*, *"Compiled query
  qualification and human deviations pending"*, limit *"Focused linked executable, not
  full target extraction; dependency findings retained"* (`codeql_misra/result.json:235-239`,
  `:117942-117944`); `focused_cppcheck`, `focused_clang_tidy`,
  `native_*`, `cross_compilation`, `format_precommit` all
  `findings_or_execution_failure`.

**Decisive scope caveat.** Every retained code measurement compiles the focused
identifier translation unit only
(`service_identifier.cpp` + `string_registry.cpp` + `service_identifier_tests.cpp` +
vendored googletest). **`runtime_tests.cpp` is not compiled or executed by any retained
artifact**, and `process_checks/result.json` records 87 test macros in
`service_identifier_tests.cpp` and 33 in `runtime_tests.cpp`, while the host
measurement executed only 85 identifier tests — i.e. the retained measurement is also
stale relative to the working tree. A retained green marker is therefore **not**
evidence for the runtime path this report inspects.

### 1.5 Host addendum (task context, not acceptance)

The host addendum (available only as quoted by prior reports) states it is *"task
context, not engineering acceptance or an approved tailoring decision"*; it asks that
unknown applicability and unexecuted checks stay explicit, that identifier-only tests
not be labelled platform validation, that no fuzzy technique be claimed without a
measurement, and that there is **no authority to invent native links, select a safety
classification, accept risk/deviations, or answer the independent human gate.** This
report honours that.

---

## 2. Premise: the recorded syntax failure

### 2.1 Finding (re-verified this iteration by direct `read_file` + `grep`)

`score/socom/impl/service_identifier.hpp` is **brace-balanced**. `grep '[{}]'` on the
file returns exactly four lines:

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace (nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers and two closers give net brace balance `0`. There is **no third,
unmatched closing brace**, and line 39 contains no text. The task's "extra closing
brace … at line 39" therefore matches a **pre-correction** description recorded in the
earliest prior reports (which quote lines 38-39 as the split-form `}  // namespace
socom` + `}  // namespace score`); the `reproducer` iteration applied the correction
and left line 39 blank. The `clang-compile` leg of `compiler_diagnostics` exits `1`,
but on a **googletest/libstdc++ `-Wdeprecated-declarations`** dependency error outside
the candidate paths — not on this header. The GCC legs exit `0`.

### 2.2 Minimal historical repair (reference only; NOT applied)

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

Applying this to the already-balanced file would be a no-op at best and a compile
break at worst. **No source was edited**, both because the defect is not present and
because the review-draft boundary forbids a write. If a distinct "cancelled draft"
revision still carries the brace, it is not the file in this checkout and must be
located and corrected by an authorized iteration.

---

## 3. What "manual coding-guideline inspection" means here (and its limits)

### 3.1 Method

`coding_guidelines.rst` (`:status: valid`) selects **MISRA C++:2023 designed for
C++17** (`:30-36`) and C++17 as the project standard (`:74`); it additionally requires
error handling through `score::Result`, avoidance of exceptions, and aborts only as a
last resort (`:117-129`). Because the in-repo **MISRA rule→tool mapping is a draft with
no active CSV** (`misra_mapping.rst:20`, `:26-31`; `glob **/_assets/**` returns
nothing), this report cannot and does not state that a numbered MISRA rule "applies to
the deliverable" in the process sense. It performs a **manual, construct-by-construct
inspection** of the changed implementation against the six named topics, records the
source construct and its evidence, and marks each outcome as one of:

- **OK (static):** the construct is correct by direct reading and the reasoning is
  given;
- **INVARIANT to preserve:** correct today only because of a stated precondition;
- **MANUAL FINDING:** a concrete, actionable item for the author/reviewer (no
  severity is asserted as accepted — no authorized SCA classification exists);
- **UNRESOLVED:** cannot be closed without a tool run, native test, or human decision.

### 3.2 The changed implementation (exact constructs)

`score/socom/impl/service_identifier.hpp:29-35`:

```cpp
struct Service_instance_identifier final {
    Service_interface_identifier interface;
    Service_instance instance;
};

/// \cond
bool operator<(Service_instance_identifier const& lhs, Service_instance_identifier const& rhs);
/// \endcond
```

`score/socom/impl/service_identifier.cpp:20-30`:

```cpp
bool operator<(Service_instance_identifier const& lhs, Service_instance_identifier const& rhs) {
    return std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major) <
           std::tie(rhs.instance, rhs.interface.id, rhs.interface.version.major);
}
```

The key is used as the element type of `std::set<Service_instance_identifier>`
(`runtime_impl.hpp:56`), inserted under a dedicated mutex and erased only by a
`Final_action` that is constructed in `make_server_connector`
(`runtime_impl.cpp:449-454`, `:456-463`).

---

## 4. Manual inspection by topic

All line references are readings of this working tree. Each sub-section states the
construct, the inspection, and the disposition.

### 4.1 Initialization

**Constructs.** The key is an aggregate of two class-typed members, declared
`interface` then `instance`; no user-declared constructors, no default member
initializers, no base classes, public members (`service_identifier.hpp:29-32`). The
sole production construction is `Service_instance_identifier const identifier{
configuration.get_interface(), instance};` (`runtime_impl.cpp:443`).

**Inspection.**
- The aggregate initializer supplies both members in declaration order, so neither
  member is left uninitialized; `Service_interface_identifier` requires a `Version`
  and `Service_instance` requires an id, and both are supplied.
- Because neither member type has a default constructor
  (`service_interface_identifier.hpp:37,41,48,53,99,105,113,121`), the key is **not
  default-constructible**; `Service_instance_identifier x;` does not compile. This
  removes the usual "indeterminate member" hazard by construction.
- No static-storage-duration object is introduced by the changed code, so there is no
  initialization-order fiasco in the key itself. (The two `String_registry`
  singletons are function-local statics in `string_registry.cpp:65-73` — a
  static-storage-duration construct, but they are pre-existing and not part of the
  changed key code; the licensed pack flags that singleton at
  `cpp/misra/local-variable-static-storage-duration`, `string_registry.cpp:66,71`,
  §7.)
- The comparator’s `std::tie` temporaries are reference tuples bound to members of the
  arguments; they are value-initialized by the call and outlive only the comparison
  expression.

**Disposition:** **OK (static).** No initialization defect in the changed code.

### 4.2 Lifetimes

**Constructs.** The key stores `Registry_string_view`s (non-owning, via
`interface.id` and `instance.id`); `Registry_string_view` explicitly documents "It is
the programmer's responsibility to ensure that Registry_string_view does not outlive
the String_registry it is referring to" (`registry_string_view.hpp:25-30`). The set is
owned by `Runtime_impl` (`m_service_identifiers`, `runtime_impl.hpp:228-229`);
`Final_action` captures a **copy** of the identifier and a `weak_ptr` to the set
(`runtime_impl.cpp:456-463`).

**Inspection.**
- The referenced registries are function-local statics with program duration
  (`string_registry.cpp:65-73`), and entries are only added, never erased:
  `emplace`/`emplace_front`/`insert` (`:26`, `:39-40`, `:56-57`); there is no
  `erase`/`clear`. `m_dynamic_allocated` is a `std::forward_list<std::string>`
  (`string_registry.hpp:76`), whose node addresses are stable across later
  `emplace_front`, and the `std::unordered_set<std::string_view>` holds views into
  those stable strings, so rehashing does not invalidate the viewed characters.
  Therefore a key that lives no longer than the process keeps valid views.
- The key-erasing `Final_action` executes after `Runtime_impl` may already be gone; it
  first attempts `identifiers.lock()` and skips the erase when the `weak_ptr` is
  expired (`runtime_impl.cpp:458-462`), so no comparison/`erase` runs against a
  destroyed set.
- **Residual hazard (recording only):** if a key outlives the registry itself (e.g. an
  object with static storage duration destroyed after the function-local statics),
  the captured views dangle. This is the documented contract, unchanged by the key
  edit, and no retained test covers it.
- The related `lifetime_review.md` CE-1 (an **enabled** connector outliving the
  `Runtime` resets a `Registration` whose `Final_action` captures a `Service_record`
  inside the destroyed `Runtime_impl`) is about the server registration, not the key;
  it is unaffected by this comparator change and remains a pending human decision.

**Disposition:** **INVARIANT to preserve** (registry outlives key) + **UNRESOLVED**
(program-exit/static-destruction ordering is not tested or decided).

### 4.3 Conversions

**Constructs.** The comparator reads `lhs.interface.version.major`, whose type is
`std::uint16_t` (`service_interface_identifier.hpp:83`), plus two
`Registry_string_view`s, through `std::tie` (`service_identifier.cpp:28-29`).
`Registry_string_view::operator<` delegates to `std::string_view::operator<`
(`registry_string_view.hpp:141-143`).

**Inspection.**
- There is **no explicit or implicit narrowing, cast, or arithmetic** in the changed
  code. The `std::uint16_t` member is compared as an integer; the only promotion is
  the value-preserving integer promotion performed by the built-in `<`. No
  signed/unsigned mixing (all three components are non-negative unsigned or string
  views).
- No `reinterpret_cast`, no C-style cast, no boolean-as-integer conversion. (The only
  `reinterpret_cast` in the wider file set is the pointer hash for
  `Registry_string_view` at `registry_string_view.hpp:192`, pre-existing, guarded by a
  `NOLINTNEXTLINE(cppcoreguidelines-pro-type-reinterpret-cast)` and a comment.)
- The out-of-scope config narrowing (`uint32 minor` in the SOME/IP config →
  `uint16 minor` in socom) is untouched by this change and remains a documented open
  question.

**Disposition:** **OK (static).** No conversion concern introduced by the changed
code. (The licensed pack’s `cpp/misra/no-conversion-from-bool` rule fires only in
`string_registry.cpp` and the gtest-macro test file — §7 — not here.)

### 4.4 Ordering

**Constructs.** `std::tie(instance, service id, major) < std::tie(instance, service
id, major)` (`service_identifier.cpp:28-29`), used as the sole `std::set` comparator.

**Inspection.**
- `std::tie(a,b,c) < std::tie(d,e,f)` is the standard lexicographic tuple comparison,
  equivalent to `a<d || (!(d<a) && (b<e || (!(e<b) && c<f)))`. It is a **strict weak
  ordering** whenever each component’s `<` is:
  - `Service_instance::operator<` → `lhs.id < rhs.id` (`service_interface_identifier.hpp:69-71`),
    which is the content-lexicographic `std::string_view` order — strict weak;
  - `Registry_string_view::operator<` (`registry_string_view.hpp:141-143`) — strict
    weak;
  - built-in `std::uint16_t` `<` — strict weak.
  Component-wise lexicographic composition of strict weak orderings is a strict weak
  ordering, so the comparator satisfies the `std::set` `Compare` requirement
  (irreflexive, asymmetric, transitive, and transitivity of equivalence).
- The **key identity** is exactly `(instance, service id, major)`: `std::set`
  uniqueness is `!(a<b) && !(b<a)`, and `minor` never enters the tie, so two keys
  differing only in `minor` are equivalent (rejected as `duplicate_service` by
  `runtime_impl.cpp:451-452`). This matches the `Service_database` record index, which
  groups by `id + major` and ignores `minor` via
  `Minor_version_ignoring_key_equal` / `Minor_version_ignoring_hash`
  (`runtime_impl.hpp:116-134`).
- **MF-1 — latent consistency point (INVARIANT).** The comparator uses only `<`, and
  `Registry_string_view::operator<` is **content**-based, whereas `operator==` is
  **pointer+length**-based (`registry_string_view.hpp:127-129`) and `std::hash` hashes
  the pointer (`:186-193`). The gate (`std::set`, content order) and the
  `Service_database` `unordered_map` (pointer hash/equal) therefore coincide **only
  because `String_registry` interns by content** (`string_registry.cpp`). This is
  correct today, but it is a precondition the comparator relies on and does not
  itself enforce; if interning were ever broken, the two structures could disagree and
  weaken the single-server invariant. Recorded as an invariant to preserve, not a
  confirmed defect.
- **MF-4 — ordering identity has no `operator==`/`std::hash`.** `Service_instance_identifier`
  is intentionally ordering-only (declaration `service_identifier.hpp:35`; no
  `operator==`, no `std::hash`). That is sufficient for `std::set` but means the key
  cannot be used in an equality/hash container without adding them; any such future use
  must keep the identity `(instance, id, major)` to stay consistent with the record
  index. Design note, not a defect.
- The comparator’s declaration is visible to the `std::set` instantiation because
  `runtime_impl.hpp:30` includes `service_identifier.hpp`; the single definition is
  linked from `service_identifier.cpp` (external linkage, declared in a header — so
  the "external linkage not declared in a header" pattern, if it applied, is satisfied
  for this symbol; the `cpp/misra/external-linkage-not-declared-in-header-file-misra`
  finding in the artifact lands on the gtest `TEST_F` macro expansion, §7).

**Disposition:** **OK (static)** for strict-weak-ordering/identity; **INVARIANT**
(MF-1) and **design note** (MF-4).

### 4.5 Error handling

**Constructs.** `make_server_connector` validates callbacks, then inserts the key and
returns `MakeUnexpected(Construction_error::duplicate_service)` when the insert fails
(`runtime_impl.cpp:440-467`); the comparator returns `bool`.

**Inspection.**
- `coding_guidelines.rst:117-129` requires error handling through `score::Result`,
  discourages value-encoded errors, and treats aborts as a last resort. The duplicate
  path returns a typed `Result` error rather than aborting — **consistent** with the
  guideline.
- **No key leak on the error path:** `is_valid(callbacks)` is evaluated **before** the
  key insert (`:445-447` before `:449`), so a `callback_missing` return does not
  reserve a key.
- The comparator cannot signal failure and must not; it performs no allocation and no
  I/O.
- **MF-2 — comparator is not declared `noexcept`.** The declaration
  (`service_identifier.hpp:35`) and definition (`service_identifier.cpp:20`) omit
  `noexcept`, even though every operation involved (`std::string_view` comparison,
  `std::uint16_t` comparison, `std::tuple::operator<`) is non-throwing in C++17. The
  comparator is invoked by `std::set::insert` from a `noexcept` function
  (`make_server_connector … noexcept`, `runtime_impl.cpp:440`), so a throw would
  terminate. Marking it `noexcept` would express the non-throwing contract and match
  the sibling `Registry_string_view::operator<` (`noexcept`,
  `registry_string_view.hpp:141`). (`Service_instance::operator<` at
  `service_interface_identifier.hpp:69` is likewise not `noexcept`.) **Not applied**
  (review-only). This is a manual finding, not a confirmed rule violation.
- **MF-3 — error documentation narrower than behaviour.**
  `Construction_error::duplicate_service` is commented "Service identifier already
  exists" (`error.hpp:55`), but the key now also collapses two configurations that
  differ only in `minor`. The comment is misleading relative to the current identity.
  Documentation-only; a fix would be a separate authorized change.
- `is_interface_compatible` (`runtime_impl.cpp:138-146`) remains a defensive check and
  is not part of the key; correctness relies on the record narrowing the interface
  first, as its comment states.

**Disposition:** **OK (static)** for `Result`-based propagation and leak-freedom;
**MANUAL FINDINGS** MF-2, MF-3.

### 4.6 Concurrency

**Constructs.** The comparator is called from `std::set<Service_instance_identifier>`
operations inside `make_server_connector` under mutex A
(`m_service_identifiers->mutex`, `runtime_impl.cpp:450`) and in the erase `Final_action`
under the same mutex (`:460`). The views it reads point into the `String_registry`
guarded by mutex R (`string_registry.cpp:23,35,49`).

**Inspection (static).**
- The comparator is a **pure read of its arguments and of immutable registry data**;
  it takes no lock and mutates nothing. In production it is only ever invoked under
  mutex A, so all `set` mutations (`insert` at `:451`, `erase` at `:461`) are
  serialized.
- **Registry reads are race-free by append-only design:** existing entries are never
  erased or mutated, and the storage that holds the characters (`std::forward_list`
  nodes) is stable across later `emplace_front` (`string_registry.cpp:39`, `:56`;
  `string_registry.hpp:76`). Two threads comparing different entries therefore read
  disjoint, immutable character buffers; a concurrent insert of a new entry does not
  move existing ones.
- **Publication:** `m_service_identifiers` is initialized at `Runtime_impl`
  construction and never reassigned (`runtime_impl.hpp:228-229`); concurrent reads of
  the `shared_ptr` are safe under the factory-publication contract (prior
  `concurrency_review.md` AS-5 / RC-4). Not changed by this slice.
- **The cross-lock single-server invariant (MF-5, INVARIANT).** `Service_record` holds
  a single `std::optional` server and `register_server_connector` asserts
  `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)` under mutex B
  (`runtime_impl.cpp:369`, `:371`). That assert stays unreachable **only because** the
  A-guarded key identity `(instance, id, major)` equals the record index identity
  `(id, major, instance)` and the key is held continuously from construction to
  destruction. The changed comparator is what establishes this; a future re-finer key
  would re-open the path. This is the main concurrency property to preserve.
- **MF-6 — teardown-declaration-order fragility (related, unmodified).** `Impl`
  declares `m_registration` (`server_connector_impl.hpp:162`) before `m_final_action`
  (`:163`), so the key-erasing `Final_action` is destroyed before the server
  registration; correctness depends on `~Impl(){ disable(); }` having already reset
  `m_registration`. This is `lifetime_review.md` CE-4 / `concurrency_review.md` RCC-4,
  not introduced here, but directly relevant to the key’s lifetime contract and left
  to human disposition.
- **Not measured.** No retained sanitizer/TSAN artifact exercises the changed unit’s
  runtime path: `focused_tsan` compiled only the identifier TU and exited `66`/`-11`
  (environment); `native_tsan` exit `127` (`bazel` absent). The static reading is
  therefore **not** a race-detector result.

**Disposition:** **OK (static)** for lock discipline and pure-read comparator;
**INVARIANT** MF-5; recorded hazard MF-6; **UNRESOLVED** (no TSAN/stress measurement).

---

## 5. Findings register

Severity is deliberately **not** assigned an accepted class: `verification_process.rst`
requires SCA findings to be classified by the quality manager together with a committer
(`gd_req__verification_sca_classification`), and no such authorized classification
exists. The column is a review aid only.

| Id | Topic | Finding | Evidence | Disposition |
|----|-------|---------|----------|-------------|
| MF-1 | Ordering | `<` is content-based while `==`/`hash` are pointer-based; consistency relies on `String_registry` interning | `registry_string_view.hpp:127-129,141-143,186-193`; `string_registry.cpp:26,39-45`; `runtime_impl.hpp:116-134` | INVARIANT to preserve |
| MF-2 | Error handling | Comparator not declared `noexcept` although it cannot throw and is called from a `noexcept` function | `service_identifier.hpp:35`; `service_identifier.cpp:20`; `runtime_impl.cpp:440-451` | MANUAL FINDING |
| MF-3 | Error handling | `duplicate_service` doc comment narrower than the actual key semantics | `error.hpp:55`; `service_identifier.cpp:28-29` | MANUAL FINDING |
| MF-4 | Ordering | Key is ordering-only: no `operator==`/`std::hash`; future equality-container use would need them | `service_identifier.hpp:29-35` | Design note |
| MF-5 | Concurrency | Single-server assert is safe only while key identity == record index identity | `runtime_impl.cpp:369,371`; `service_identifier.cpp:28-29`; `runtime_impl.hpp:116-134` | INVARIANT to preserve |
| MF-6 | Concurrency/lifetime | Key-erase `Final_action` declared after `m_registration`, so erase-before-unregister order is implicit | `server_connector_impl.hpp:162-163`; `runtime_impl.cpp:456-463` | Recorded hazard (same as CE-4/RCC-4) |
| MF-7 | Initialization | Key is a non-default-constructible aggregate; production init supplies both members | `service_identifier.hpp:29-32`; `runtime_impl.cpp:443` | OK (static) |
| MF-8 | Lifetimes | Views must not outlive the registry; static-destruction-order path untested | `registry_string_view.hpp:25-30`; `string_registry.cpp:65-73`; `runtime_impl.cpp:456-463` | UNRESOLVED |
| MF-9 | Traceability | `DerivationTechnique`/`Description` recorded; `TestType`/`Verifies` unset (no verified identifiers) | `service_identifier_tests.cpp:42-65`; `runtime_tests.cpp:264-267` | UNRESOLVED (human) |
| MF-10 | Measurement | No retained artifact compiles `runtime_tests.cpp`; identifier measurement stale (85 vs 87) | `process_checks/result.json` (`test_macros` 87 / 33); `validation/measurement.json` (85) | UNRESOLVED |

---

## 6. Verified guideline identifiers (and what is NOT verified)

Per the task instruction, guideline identifiers are cited **only where verified**:

1. **No S-CORE MISRA rule is verified as mapped.** `misra_mapping.rst` is
   `:status: draft` and its only content is a commented-out `csv-table` referencing an
   absent `_assets/misra_2023.csv` (`:20`, `:26-31`). There is therefore **no
   S-CORE-authorized statement that any MISRA C++:2023 rule is covered by any tool**,
   and this report asserts none. Which rules "apply" to this slice is **unresolved**
   (also because `safety_class: unknown`).
2. **The only verified rule identifiers are the licensed CodeQL coding-standards
   pack’s own annotations, and only for findings that actually fired in the retained
   focused extraction** (`codeql_misra/results.sarif`, `analyze.stderr`). These are
   tool-internal mappings, **not** an S-CORE applicability decision:

   | MISRA rule id (pack annotation) | CodeQL query id | Location(s) in the focused extraction |
   |---------------------------------|-----------------|----------------------------------------|
   | `6.7.1` local-variable-static-storage-duration | `cpp/misra/local-variable-static-storage-duration` | `score/socom/impl/string_registry.cpp:66`, `:71` |
   | `7.0.1` no-conversion-from-bool | `cpp/misra/no-conversion-from-bool` | `score/socom/impl/string_registry.cpp`, and the gtest `TEST_F` file |
   | `0.1.1` unnecessary-write-to-local-object | `cpp/misra/unnecessary-write-to-local-object` | `score/socom/impl/string_registry.cpp:23`, `:35` (also googletest) |
   | `21.6.1` dynamic-memory-should-not-be-used | `cpp/misra/dynamic-memory-should-not-be-used` | `score/socom/string_registry.hpp:37` |
   | `6.5.1` external-linkage-not-declared-in-header-file-misra | `cpp/misra/external-linkage-not-declared-in-header-file-misra` | `score/socom/test/unit/service_identifier_tests.cpp` — gtest `TEST_F` macro expansion |
   | `9.3.1` switch-body-compound-condition | `cpp/misra/switch-body-compound-condition` | same test file — macro/defaulted-body artifact |
   | `15.8.1` copy-and-move-assignments-shall-handle-self-assignment | `cpp/misra/copy-and-move-assignments-shall-handle-self-assignment` | `.llm_tmp/googletest/**` (dependency, out of scope) |

3. **The changed implementation files are clean in that extraction.** A `grep` of
   `codeql_misra/results.sarif` for `service_identifier.cpp` / `service_identifier.hpp`
   returns **no** result, i.e. no CodeQL MISRA query produced a finding in the changed
   key files. This is "no finding in a focused, incomplete extraction", **not** a
   compliance statement and not evidence that any specific rule was satisfied (§ rule 1
   above).
4. **Rule statements are not reproduced.** The MISRA C++:2023 rule text is licensed;
   this report cites identifiers, query ids, and locations only, and does not reproduce
   rule text or rationale.
5. **`coding_guidelines.rst` document facts cited** (not numbered rules): MISRA
   C++:2023 with C++17 (`:30-36`, `:74`); `score::Result` error handling, avoid
   throwing, aborts last resort (`:117-129`). The document id is
   `doc__cpp_coding_guidelines`, `:safety: ASIL_B`.

The blank, draft `inspection_checklist.rst` (`:status: draft`) defines the intended
manual-inspection slots `IMPL_02_01` (static/dynamic analysis verified) and
`IMPL_02_02` (manual checks derived from the coding guideline find no safety-critical
error) (`:97-108`). This report is **input** to that inspection, not a filled checklist;
`IMPL_02_02` remains **unfilled** and its "no safety-critical error" judgement is a
human responsibility.

---

## 7. Tool evidence read (and why none of it satisfies a MISRA obligation)

| Check | Retained result | Reading |
|-------|-----------------|---------|
| CodeQL MISRA | `codeql_misra/result.json` | database-create and analyze exit `0`; SARIF exported; status `findings_or_execution_failure`; blockers: draft/incomplete mapping, default suite omits manual/audit obligations, query qualification/human deviations pending; limit: focused linked executable, not full target extraction |
| CodeQL security | `codeql_security/result.json` | retains findings; per prior reports all locations under `.llm_tmp/googletest/**` |
| clang-tidy (focused) | `focused_clang_tidy/result.json` | status `findings_or_execution_failure`; `--verify-config` exit `1` — config blocker, **no TU analysis, not "clean"** |
| cppcheck (focused) | `focused_cppcheck/result.json` | status `findings_or_execution_failure`; performance findings in headers outside the changed files |
| GCC focused compile/tests | `compiler_diagnostics/result.json` | `gcc-compile` exit `0`, `gcc-tests` exit `0`; whole check is `findings_or_execution_failure` because `clang-compile` exit `1` on a googletest/libstdc++ dependency error outside the candidate paths |
| native / cross / sanitizer / tsan / memcheck / format | `native_*/result.json`, `cross_compilation`, `format_precommit` | exit `127` (`bazel`/tools absent) or environment failure; **not measured** |
| host validation | `validation/check-result` = `0`; `measurement.json` | identifier TU only; candidate 85/0; `full_native_tests: not_executed`; stale vs 87 macros on disk |

None of these is a MISRA-rule measurement of the changed comparator, and none covers
`runtime_tests.cpp`.

---

## 8. Obligations status (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` (draft) | **UNKNOWN — NOT CLAIMED**; mapping inactive, no S-CORE rule↔tool linkage |
| MISRA rule→tool mapping | `misra_mapping.rst`; `code_analysis.rst` | **DRAFT / INACTIVE** — no CSV, table commented out |
| Manual coding-guideline inspection (`IMPL_02_02`) | `inspection_checklist.rst` (draft) | **DRAFTED HERE AS INPUT; NOT A FILLED/ACCEPTED INSPECTION**; human judgement pending |
| Static/dynamic analysis verified (`IMPL_02_01`) | `inspection_checklist.rst` | **NOT DONE** — CodeQL focused+draft; clang-tidy config-blocked; no authorized finding classification |
| SCA finding classification (Critical/High/Medium/Low) | `verification_process.rst` (`gd_req__verification_sca_classification`) | **NOT DONE** — no authorized owner |
| Freedom from compiler warnings & errors (100 %, criterion 9) | `verification_plan.rst` | **PARTIAL / NOT SATISFIED** — focused GCC exit 0; clang leg exits 1 on a dependency; no Bazel build; `runtime_tests.cpp` uncompiled |
| Unit/component testing executed, results recorded | `verification_plan.rst`; `verification_guideline.rst` | **PARTIAL, STALE** — 85 identifier tests in `validation/after.json`; tree has 87; runtime suite (33 macros) not executed |
| Boundary/equivalence derivation | `verification_process.rst` | **SOURCE-ONLY** (cases exist; not executed here) |
| Linking tests to requirements (record properties) | `verification_process.rst` (`gd_req__verification_link_tests_cpp`) | **PARTIAL** — `DerivationTechnique`/`Description` set; `TestType`/`Verifies` unset (no invented identifiers) |
| Independence of verification / review | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** for this slice |
| Native acceptance | `source-index.json` | **`not_inferred` for every entry** |
| Obligation-collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **RETAINED, NOT PASSED** — several `findings_or_execution_failure` |

**Explicit non-satisfaction statement.** Missing tools, the unknown safety class and
un-inferred applicability, the draft/inactive rule mapping, the blank inspection
checklist, the focused/incomplete CodeQL extraction, the never-compiled runtime suite,
the stale identifier measurement, and the unanswered human reviews mean **none of the
checked obligations may be treated as satisfied**. A retained collection node proves
*retention*, not passing.

---

## 9. Measurement and validation status

- **Tools:** `read_file`, `grep`, `glob`, `write_file` only. No `shell`, delegation,
  web, approval, publishing, or engineering acceptance.
- **Measurements executed by this iteration: none.** No build, no `bazel test`, no
  runtime. The brace census (§2), the source-construct inspection (§3-§5), and the
  strict-weak-ordering / leak-freedom / lock-discipline statements are static readings
  or explicitly-labelled logical consequences.
- **Test inventory (read, not run):** `service_identifier_tests.cpp` — 87 test macros
  per `process_checks/result.json`; `runtime_tests.cpp` — 33 test macros (31 `TEST_F`
  + 1 `TEST` + 1 `TEST_P`). The focused minor-only regression
  `RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError`
  is present at `runtime_tests.cpp:402-431`.
- **Reproduction path for a later, permitted iteration (not executed here):**

  ```bash
  bazel test //score/socom/test/unit:socom_test
  bazel test //score/socom/test/unit:socom_test --test_filter='ServiceInstanceIdentifierTest.*'
  bazel test //score/socom/test/unit:socom_test --test_filter='RuntimeTest.*'
  # static analysis (tool-dependent, after fixing .clang-tidy config):
  codeql database create db --language=cpp --command=<build>
  codeql database analyze db misra-cpp-default.qls --format=sarif-latest
  ```

  Expected on the corrected key (source-derived, not measured): minor-only duplicates
  collapse to one set element and the runtime regression returns
  `Construction_error::duplicate_service`.
- **Scope:** local, unprotected, scoped. Full native runtime tests and human review
  remain pending.

---

## 10. Notice preservation

- No source, build, test, config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was
  created, edited, or deleted by this iteration; **only this report was written.**
- All Apache-2.0 / SPDX headers on the files read are untouched:
  `service_identifier.{hpp,cpp}:1-12` (2025 copyright), `service_identifier_tests.cpp:1-12`
  (2025 copyright), `runtime_tests.cpp`, `runtime_impl.{hpp,cpp}`,
  `service_interface_identifier.hpp`, `registry_string_view.hpp`, `string_registry.{hpp,cpp}`,
  `final_action.hpp`, `error.hpp`, and the `BUILD` files.
- All 12 files under `.llm_tmp/overnight/prior-reports/` and all earlier files under
  `.llm_tmp/overnight/reports/` were preserved unchanged.
- This report carries the Apache-2.0 header. No licensed MISRA rule text is
  reproduced.

---

## 11. Pending human review checklist

- [ ] **Resolve the instruction conflict (§2):** the recorded "extra closing brace at
      line 39" is not present in this checkout and the review-draft boundary forbade a
      source write; confirm that writing only this report was intended, and locate any
      distinct "cancelled draft" revision if it still carries the brace.
- [ ] **Adopt or reject the manual findings:** MF-2 (add `noexcept` to the comparator,
      and consider `Service_instance::operator<`), MF-3 (update the
      `duplicate_service` comment to match the minor-ignoring key) — both require an
      authorized source change and a build/test cycle this review cannot run.
- [ ] **Confirm the invariants:** MF-1 (content-based `<` vs pointer-based
      `==`/`hash`; interning precondition) and MF-5 (key identity must stay equal to
      the record index identity so the single-server assert stays unreachable).
- [ ] **Adjudicate the recorded hazards:** MF-6 / CE-4 / RCC-4 (declare
      `m_final_action` before `m_registration`, or express the erase-after-unregister
      order) and MF-8 (static-destruction-order path for the non-owning views).
- [ ] **Complete and activate the MISRA mapping** (`misra_mapping.rst`): supply
      `_assets/misra_2023.csv`, uncomment the table, and raise `:status` to `valid` by
      an authorized change; until then no rule applicability can be stated.
- [ ] **Fill the implementation inspection checklist** `IMPL_02_01` / `IMPL_02_02`
      (`inspection_checklist.rst`, currently draft/blank) using this report as input,
      and record the SCA finding classification per
      `gd_req__verification_sca_classification`.
- [ ] **Repair and run the analyzers:** fix the `.clang-tidy` configuration
      (`--verify-config` exits 1) and run a **full-target** CodeQL extraction (not a
      focused executable) that includes `runtime_tests.cpp` and the remaining units;
      qualify the compiled queries and disposition the retained findings in
      `string_registry.cpp`/`string_registry.hpp` and the gtest-macro hits.
- [ ] **Refresh the measurements:** run `bazel test //score/socom/test/unit:socom_test`
      (and the broader `//score/...` set) so `runtime_tests.cpp` and the two newest
      identifier tests are actually compiled and executed; do not re-report the 85-test
      focused artifact as coverage of the current tree.
- [ ] **Supply traceability metadata** (`TestType`/`Verifies`) where verified native
      identifiers exist — no invented links — or record the applicability as unresolved.
- [ ] **Select the safety class**, schedule independent human review (approver ≠
      author, `gd_req__verification_independence`), and record engineering acceptance;
      no compliance claim may be made before that.
- [ ] **Keep the wider #84 public `Service_interface_identifier` restructure,
      FindService wildcard handling, and the config minor-wildcard narrowing out of
      this bounded slice** until separately accepted.

---

*End of review draft. Local, unprotected, scoped. No engineering acceptance; human
reviews unanswered; full native runtime tests pending. No MISRA C++:2023 compliance is
claimed and no rule applicability is asserted.*
