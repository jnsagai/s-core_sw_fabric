<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — cross-target review (`cross_target_review`)

**Document type:** review draft (x86_64/aarch64 Linux cross-build result review +
documented QNX/toolchain obligations + S-CORE-vs-integrator boundary + actual-source
inspection + obligations status)

**Date:** 2026-10-02

**Repository:** `eclipse-score/inc_someip_gateway`

**Slice:** bounded duplicate-server registration-key handling within *Revise version
handling in socom* (issue #84)

**Run:** branch `fabro/run/01M3YRJEGXNY6CB81T7TKW774B`

**Status:** local, unprotected, scoped. **No engineering acceptance exists. Human
reviews are unanswered. Full native runtime tests remain pending. No cross-target
build or target execution has succeeded.** Every statement below is either a direct
reading of this checkout at the baseline-bound candidate paths, a direct reading of a
retained artifact under `.llm_tmp/overnight/`, or an explicitly-labelled logical
consequence. Nothing here is published, reviewed, accepted, or a full native run.

> **Tool / write boundary actually observed.** Only `read_file`, `grep`, `glob`, and
> `write_file` were used. No `shell`, no delegation, no web access, no approval, no
> publishing, and no engineering acceptance was performed. The task's explicit final
> sentence — *"This is a review draft: only that report may be written."* — is the
> operative write boundary. Accordingly **exactly one file was written: this report**
> (`/workspace/.llm_tmp/overnight/reports/cross_target_review.md`). No source, build,
> test, config, `NOTICE`, `LICENSE`, `REUSE.toml`, host-validation, or prior-report
> file was created, edited, or deleted. Every earlier report under
> `.llm_tmp/overnight/reports/` and every file under `.llm_tmp/overnight/prior-reports/`
> was preserved unchanged.
>
> **The recorded GCC syntax failure is not present in the actual source
> (re-verified this iteration).** The task records *"a measured GCC syntax failure:
> an extra closing brace in `score/socom/impl/service_identifier.hpp` at line 39"* and
> directs *"Inspect and correct the actual source before expanding tests."* Direct
> `read_file` + `grep` on the current working tree (§2) show the header is
> **brace-balanced**: openers at `:19` (`namespace score::socom {`) and `:29`
> (`struct Service_instance_identifier final {`); closers at `:32` (`};`) and `:38`
> (`}  // namespace score::socom`). Line `:39` is **empty**; `:40` is `#endif`. Two
> openers, two closers, net balance `0`; `glob '**/service_identifier.hpp'` returns a
> single path. There is no unmatched closing brace to remove, so applying the recorded
> repair would be a no-op at best and a compile break at worst. **No source write was
> made and none is required.** The conflict between "correct the actual source" and
> "only that report may be written" is recorded for human disposition (§2.3, §11).
>
> **Non-satisfaction rule applied throughout.** A successful obligation-collection
> node means the results were **retained**, not that the checks **passed**. Missing
> tools, unknown applicability, incomplete extraction, ungranted SDK entitlements, and
> unanswered human reviews are **not** treated as satisfied. A check that produced
> **no** finding because it **did not run** is recorded as *"not run"*, never as
> *"clean"*. In particular, *no QNX credential was acquired and no qualification is
> inferred anywhere in this report*.

---

## 0. Summary

1. **The x86_64-linux and aarch64-linux cross-builds did not run.** The retained
   `cross_compilation` collector attempted exactly two builds —
   `bazel build --config=x86_64-linux //score/... //tests/...` and
   `bazel build --config=aarch64-linux //score/... //tests/...` — and **both exited
   `127`** with `[Errno 2] No such file or directory: '/tmp/s-core-001/bin/bazel'`.
   The check status is `findings_or_execution_failure`; its `commands[]` carry no
   stdout/stderr from a compiler. This is an **unavailable-driver blocker, not a
   build, not a pass, and not a finding about the candidate code** (§3).

2. **The `cross_compilation` result's own blocker text names QNX, although the
   commands it ran are Linux-only.** The retained `blockers` array is
   `["QNX SDK entitlement and target execution not configured; no credential
   acquired"]`, while the two recorded commands use `--config=x86_64-linux` and
   `--config=aarch64-linux`. The Linux legs therefore failed for the trivial reason
   that `bazel` was absent; QNX was not attempted by this collector at all, and its
   entitlement remains an untested blocker (§3.4, §5).

3. **QNX is a *documented but unexecuted* obligation.** The repository documents a
   full QNX path — CI workflow `build_and_test_qnx.yml` (reusable
   `eclipse-score/cicd-workflows/.../qnx-build.yml@8d80e8df… # v.0.0.3`, matrix
   `x86_64-qnx`/`aarch64-qnx`, targets `//score/... //tests/...`, test targets
   `//quality/... //tests/integration_test/...`), the credential helper
   `.github/tools/qnx_credential_helper.py`, `SCORE_QNX_LICENSE`/`SCORE_QNX_USER`/
   `SCORE_QNX_PASSWORD` secrets, `.bazelrc` `x86_64-qnx`/`aarch64-qnx` configs, QCC
   + imagefs toolchains in `MODULE.bazel`, a QNX8 QEMU integration environment, and
   QNX patches under `third_party/`. **None of it executed in this run**, because no
   `bazel` was available and no QNX SDK entitlement/credentials were configured
   (§5).

4. **The bounded slice is Level-1-only; target/platform integration is the
   integrator's obligation.** S-CORE's verification plan defines three levels and
   states the *"integration of the platform on a target device and the respective
   verification and validation should be considered by the distributor of the
   platform"*, with S-CORE running reference-hardware tests only "as a starting
   point" and *"The reference hardware is not yet decided."* The duplicate-server
   registration-key change is a `socom` internal identity change with unit tests; it
   has no feature requirement, no platform test, and no target execution (§6).

5. **No obligation is satisfied.** Every `source-index.json` entry is
   `native_acceptance: not_inferred`; `authority.json` records
   `engineering_acceptance: pending`, `human_reviews: unanswered`,
   `safety_class: unknown`. The retained obligation results are scoped, and the
   native/cross-target ones are execution failures (§8).

---

## 1. Binding to the baseline, issue, prior reports, and retained host artifacts

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` — *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:2-4` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` (unchanged) | `.llm_tmp/context/issue-snapshot.json:19-20` |
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |
| Branch | `fabro/run/01M3YRJEGXNY6CB81T7TKW774B` | environment |

The issue body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not
an accepted obligation**. It distinguishes service-instance identifier = `service id +
major + minor + instance id`, service identifier = `service id + major`, FindService =
`service id + major + optional<minor> + optional<instance>`, and proposes to exclude
`minor` and make it a property of the service instance. The FindService `major = FF`
AUTOSAR case is called theoretically possible but not useful. There is no comment and
no acceptance record, so none of the proposal binds this review. Binding is **by
baseline commit**, not by run HEAD.

### 1.2 In-scope candidate files

From `.llm_tmp/context/candidate-files.json:1-25`:

| File (repo-relative) | Baseline git blob | Baseline present | Working-tree state read this iteration |
|----------------------|-------------------|------------------|----------------------------------------|
| `score/socom/BUILD` | `3477ea0851fdcd82ec6ea9d71424013cbdf41962` | yes | `socom` `:17-41`; `testonly` `impl_service_identifier` `:46-54` |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e22355242009fe20dada2a9a0d0c7a9c7` | yes | order key `(instance, service id, major)`; `minor` excluded (`:28-29`) |
| `score/socom/impl/service_identifier.hpp` | `c8bae7908da9f087c518934f7b9f8d86db9a20ec` | yes | brace-balanced, 40 lines, `:39` blank (§2) |
| `score/socom/test/unit/BUILD` | `3c03a7b14286051f97fa5022206564bd63645171` | yes | `socom_test` globs `*.cpp`; visibility to `//tests/integration_test` |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab726db8bf994c960045d6fd7fdf84d7395` | yes | 31 `TEST_F` + 1 `TEST` + 1 `TEST_P` (`test_macros: 33`) |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(none — `null`)* | no (manifest expects a new file) | 87 test macros (`process_checks/result.json:254-262`) |

The `null` baseline blob is the manifest's expectation of a **new** unit-test file;
it exists only in the un-merged working tree (the "cancelled draft").

**Working-tree drift is recorded, not reconstructed.** The candidate-snapshot hashes
in `candidate-files.json` differ from the hashes the obligation collectors recorded for
the tree they snapshotted: e.g. `service_identifier.cpp` candidate `d766902e…` vs
collector `3c12b3f1…`; `service_identifier.hpp` candidate `96b33a1f…` vs collector
`bdce3fcb…`; `service_identifier_tests.cpp` candidate `45d07399…` vs collector
`4df2c63c…` (`obligations/cross_compilation/result.json:126-127,190`;
`candidate-files.json:6-25`). A hash is not a content diff; the drift is flagged so the
candidate set is not mistaken for the collector's tree. No hashing tool was available.

### 1.3 Prior reports read and preserved

`.llm_tmp/overnight/reports/` (30 files) and `.llm_tmp/overnight/prior-reports/`
(12 files) were read/grepped and preserved unchanged. For this cross-target review the
most load-bearing earlier reports are:

- `reports/bazel_plan.md` — the exact native/cross-target invocation plan, including
  Stage 7 (`--config=x86_64-linux`, `--config=aarch64-linux`) and the pinned collector
  argv; it already records that every native/cross leg exited `127`.
- `reports/native_build_review.md` — native-build/toolchain identity and the
  unavailable-driver register.
- `reports/integration_aou_review.md` — the S-CORE-vs-integrator split (§3), the QEMU
  non-run, the external-AoU review (§8), and the cross-compilation finding I-9.
- `reports/compatibility.md` — the exact-major / minimum-minor analysis against the
  changed key and the untested-path register.
- `reports/scope.md`, `reports/reproducer.md`, `reports/key_fix.md` — the bounded
  slice, the brace reconciliation, and the key semantics.

No earlier report delivers a dedicated **cross-target** review; this document is that
review. It does not supersede the integration/AoU review; it narrows onto the
x86_64/aarch64 Linux cross-build result and the documented QNX/integrator obligations.

### 1.4 Retained host validation and obligation-collection results (present, scoped)

`.llm_tmp/overnight/validation/`:

| Artifact | Content (retained) |
|----------|--------------------|
| `check-result` | `0` (collector success marker only) |
| `before.json` / `after.json` | `ServiceInstanceIdentifierTest`: **85 tests / 28 failures** before, **85 tests / 0 failures** after |
| `measurement.json` | `check_ref: check_conversion_tests`, `mode: ubsan`, `origin: local_unprotected_measurement`, `initiator: Fabro host hook`, `engineering_acceptance: pending`, `full_native_tests: not_executed`, compiler `/usr/bin/x86_64-linux-gnu-g++-12`, `baseline_with_agent_tests` 85/28, `candidate` 85/0 |
| `before-compile.stderr` / `after-compile.stderr` | empty (no recorded syntax failure) |

This is the **focused host identifier translation unit only** (`g++-12 -std=c++17
-Wall -Wextra -Werror`, candidate additionally `-fsanitize=undefined
-fno-sanitize-recover=all`). It is not a Bazel build, does not compile
`runtime_tests.cpp`, and does not touch any cross target. It is stale by two cases:
`process_checks/result.json` records **87** macros for
`service_identifier_tests.cpp`, the retained `after.json` executed **85**.

`.llm_tmp/overnight/obligations/` retains 24 checks. **Retention is not passing.** The
cross-target-relevant ones:

| Check | Retained status | Cross-target relevance |
|-------|-----------------|------------------------|
| `cross_compilation` | `status: findings_or_execution_failure`; both legs `exit 127`; blocker *"QNX SDK entitlement and target execution not configured; no credential acquired"* | **Direct subject of this review** |
| `native_build` | `exit 127` (`'/tmp/s-core-001/bin/bazel'` missing) | No native or cross build |
| `native_integration` | `exit 127`; prereqs `kvm_exists: true`, `qemu: /usr/bin/qemu-system-x86_64` | No QEMU/target execution |
| `native_tests`, `native_coverage`, `native_lint`, `native_sanitizers`, `native_tsan`, `native_docs`, `native_traceability`, `native_performance`, `format_precommit` | `exit 127` (bazel/tool missing) | No native verification leg |
| `tool_assurance` | `completed_with_blockers`; `bazel`, `valgrind`, `gitleaks`, `reuse`, `pre-commit`, `clang-format` unavailable | Tool qualification unestablished |
| `process_checks` | `completed_with_blockers`; blockers include *"External AoU and full integration verification require scoped review"*, *"Safety/QM applicability and approved tailoring unknown"* | Confirms missing integration/AoU coverage |

### 1.5 Pinned obligation sources and authority

All nine entries of `.llm_tmp/context/obligations/source-index.json` are present with
`authority.json`; every entry is `"native_acceptance": "not_inferred"`.
`authority.json` records:

| Field | Value |
|-------|-------|
| `codeql_scope` | Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload |
| `engineering_acceptance` | **pending** |
| `human_reviews` | **unanswered** |
| `safety_class` | **unknown** |
| `instruction` | "Restart the failed queue for one complete pass through all obligations" |

`misra_mapping` and `inspection_checklist` are `:status: draft`; the others are
`:status: valid`. Cross-target-relevant pinned content: `development_plan.rst:160-167`
(GCC host compiler; *"QCC … from Blackberry offered together with its Posix conform
Operating System QNX is planned to be used for target compilation"*);
`verification_plan.rst:590-610` (POSIX simulation environments on aarch64/x86_64 in
Linux and QNX flavours; reference hardware not decided); `verification_process.rst:214-264`
(external AoU verification, CI reference integration). This document treats QCC as
*planned*, never as qualified.

---

## 2. Actual-source state of the bounded slice (inspection only)

### 2.1 The recorded syntax failure is not present

`score/socom/impl/service_identifier.hpp` is 40 lines and **brace-balanced**:

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace (C++17 nested form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`), two closers (`:32`, `:38`): net balance `0`. The "extra
closing brace … at line 39" matches the **stale, pre-correction** description in the
earliest prior reports (which quoted the split form `}  // namespace socom` + `}
// namespace score`); the `reproducer` iteration applied the correction and left line
39 blank. The sibling `impl/service_identifier.cpp` uses the same nested form
(`:18`/`:32`) and is balanced. Retained corroboration: `compiler_diagnostics`
`gcc-compile` `exit_code: 0` with empty `stderr` and `gcc-tests` `exit_code: 0`
(`obligations/compiler_diagnostics/result.json`); `validation/after-compile.stderr`
empty. The only nonzero compiler exit retained is clang `exit 1`, a
googletest/libstdc++ `-Wdeprecated-declarations` dependency error **outside** the six
candidate paths.

### 2.2 The registration key is present and minimal

`score/socom/impl/service_identifier.cpp:20-30` orders by
`std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major)`, so the
duplicate-server identity is `(instance, service id, major)` and **`minor` is
excluded**, matching the deliberately minor-ignoring `Service_database` index. The
public `Service_interface_identifier{Id, Version{major, minor}}` representation and the
exact-major / `client.minor <= server.minor` compatibility rules are unchanged and are
not part of the key. The key type is `impl/`-only, reached only through the `testonly`
`//score/socom:impl_service_identifier` library. This slice is unit-level only and has
no target-specific code path.

### 2.3 Disposition

Because the actual source is already correct and the write boundary permits only this
report, **no source edit was made**. If the "cancelled draft" is a *distinct* revision
that still carries an extra brace, it is not the file in this checkout; it would have
to be located and corrected by an authorized iteration. The conflict between
"correct the actual source" and "only that report may be written" is carried to the
human reviewer (§11) rather than silently resolved.

---

## 3. x86_64/aarch64 Linux cross-build results

### 3.1 Exact retained invocation and outcome

From `obligations/cross_compilation/result.json:238-303` (and the per-leg command
files `x86.command.json`, `arm.command.json`):

| Leg | argv (abridged) | cwd | timeout | exit | reason |
|-----|-----------------|-----|---------|------|--------|
| `x86` | `/tmp/s-core-001/bin/bazel --batch --output_user_root=<run>/bazel-cache build --jobs=2 --config=x86_64-linux //score/... //tests/...` | `<run>/native-workspace` | 390 s | **127** | `[Errno 2] No such file or directory: '/tmp/s-core-001/bin/bazel'` |
| `arm` | `/tmp/s-core-001/bin/bazel --batch --output_user_root=<run>/bazel-cache build --jobs=2 --config=aarch64-linux //score/... //tests/...` | `<run>/native-workspace` | 390 s | **127** | `[Errno 2] No such file or directory: '/tmp/s-core-001/bin/bazel'` |

`check_ref: recollect_cross_compilation`; `origin: local_unprotected_measurement`;
`engineering_acceptance: pending`; `status: findings_or_execution_failure`;
`blockers: ["QNX SDK entitlement and target execution not configured; no credential
acquired"]` (`result.json:235-237,298`). The `commands[]` entries carry **no captured
compiler output**, only the launch error.

### 3.2 What this does and does not establish

- **Establishes:** the cross-build legs were *attempted* and the collector *retained*
  the attempt. That is retention, not execution.
- **Does not establish:** that `//score/...` (or the slice) compiles for
  `x86_64-linux` or `aarch64-linux`; that any target artifact exists; that any feature
  or platform-level behaviour holds; or that a QNX build works.
- The failure is an **unavailable-driver blocker** (`bazel` absent at
  `/tmp/s-core-001/bin/bazel`, recorded as `null` in every collector's
  `collector_identity`), not a code defect and not a clean run. Per the non-satisfaction
  rule, this is *"not run"*, never *"passed"*.

### 3.3 What the repository intends these legs to do

`.github/workflows/build_and_test_cross_compilation.yml:17-50` runs a matrix
`bazel-config: ["x86_64-linux", "aarch64-linux"]` on `ubuntu-24.04` and executes
`bazel build --config <config> //score/... //tests/...`. It carries two open TODOs:
build all targets `//...` "once python toolchain issue is resolved" (`:45-46`) and *"Run
tests on QEMU"* (`:50`). So even in CI the cross legs are **build-only**; they do not
run the cross-target tests, and they do not cover QNX.

### 3.4 The Linux/QNX coupling in the recorded blocker

The retained blocker text names QNX entitlement, but the two commands are Linux-only.
The accurate reading is:

1. the **Linux** legs failed solely because `bazel` was missing; and
2. **QNX** was not attempted by this collector, so its entitlement/SDK status is an
   *additional, independently unverified* blocker, not the cause of the two recorded
   `exit 127`s.

Both halves matter: the Linux legs are still pending after restoring `bazel`, and QNX
requires a separate, credentialed path (§5). Neither may be reported as passed.

---

## 4. Documented cross-target configuration (for a later authorized run)

Read directly from `.bazelrc:27-71`:

| Config | Platform | Toolchains | `TARGET_ARCH` |
|--------|----------|------------|---------------|
| `x86_64-linux` | `@score_bazel_platforms//:x86_64-linux` | `@score_gcc_x86_64_toolchain//:all` | `x86_64` |
| `aarch64-linux` | `@score_bazel_platforms//:aarch64-linux-gcc_12.2.0-posix` | `@score_gcc_aarch64_toolchain//:all` | `aarch64` |
| `x86_64-qnx` | `@score_bazel_platforms//:x86_64-qnx-sdp_8.0.0-posix` | `@score_qcc_x86_64_toolchain//:all`, `@score_qnx_x86_64_ifs_toolchain//:all` | `x86_64` |
| `aarch64-qnx` | `@score_bazel_platforms//:aarch64-qnx-sdp_8.0.0-posix` | `@score_qcc_aarch64_toolchain//:all`, `@score_qnx_aarch64_ifs_toolchain//:all` | `aarch64` |

- `common:_toolchain_common` pins the host to `x86_64-linux` and adds
  `@score_gcc_x86_64_toolchain` (`:45-46`).
- `common --credential_helper=*.qnx.com=%workspace%/.github/tools/qnx_credential_helper.py`
  (`:71`).
- `test:qemu-integration` and `test:x86_64-qnx`/`test:aarch64-qnx` force the
  linux-sandbox strategy for `*integration_test*` rules and run under
  `@score_itf//scripts:run_under_qemu` (`:73-85`).

From `MODULE.bazel`: GCC toolchains at `version = "12.2.0"` for x86_64/aarch64 Linux
(`:83-116`); QCC toolchains `score_qcc_x86_64_toolchain` / `score_qcc_aarch64_toolchain`
with `target_os = "qnx"`, `sdp_version = "8.0.4"`, `version = "12.2.0"`
(`:117-157`); QNX imagefs toolchains and the Linux ext4 imagefs toolchain
(`:342-363`). These are **declare-in-Bazel** facts; whether the QCC/SDP packages can
actually be fetched depends on the QNX entitlement, which is not configured here.

Bazel version is pinned to `8.6.0` (`USE_BAZEL_VERSION` in every collector env;
`.bazelversion`). The intended cross-target commands (from `reports/bazel_plan.md` §4.2
Stage 7, matching the collector argv) are:

```bash
bazel build --config=x86_64-linux  //score/... //tests/...
bazel build --config=aarch64-linux //score/... //tests/...
# QNX (requires entitlement + credentials; NOT attempted and NOT to be attempted without authorization):
bazel build --config=x86_64-qnx    //score/... //tests/...
bazel build --config=aarch64-qnx   //score/... //tests/...
```

---

## 5. Documented QNX obligations (unexecuted; entitlement is a hard blocker)

### 5.1 What is documented

| Obligation / artifact | Location | Content |
|-----------------------|----------|---------|
| QNX CI job | `.github/workflows/build_and_test_qnx.yml:17-40` | Reusable `eclipse-score/cicd-workflows/.github/workflows/qnx-build.yml@8d80e8df… # v.0.0.3`; matrix `x86_64-qnx`/`aarch64-qnx`; build `//score/... //tests/...`; test `//quality/... //tests/integration_test/...`; `credential-helper: ".github/tools/qnx_credential_helper.py"` |
| QNX secrets | same file, `:37-40` | `score-qnx-license` ← `secrets.SCORE_QNX_LICENSE`; `score-qnx-user` ← `SCORE_QNX_USER`; `score-qnx-password` ← `SCORE_QNX_PASSWORD` |
| PR gating | `.github/workflows/ci_pull_request_target.yml:23-31` | QNX job runs only in the merge queue or when the PR carries the `test-qnx` label (`:26`) |
| Cache warm-up | `.github/workflows/cache_maintenance.yml:34-46` | Same QNX secrets; variants include `--config=x86_64-qnx //quality/... //score/... //tests/...` and `--config=aarch64-qnx …` |
| Credential helper | `.github/tools/qnx_credential_helper.py:29-79` | Reads `SCORE_QNX_USER`/`SCORE_QNX_PASSWORD` (or `.netrc`), logs into `https://www.qnx.com/account/login.html`, returns the `myQNX` cookie for `*.qnx.com` downloads |
| Bazel configs | `.bazelrc:59-71,82-85` | `x86_64-qnx`/`aarch64-qnx` platforms + QCC/imagefs toolchains; `test:*qnx` run under QEMU |
| Toolchains | `MODULE.bazel:117-157,342-363` | QCC SDP `8.0.4`, version `12.2.0`; QNX IFS imagefs toolchains |
| QEMU integration env | `quality/integration_testing/environments/qnx8_qemu/BUILD:16-37`, `qemu_config.json` | `init_x86_64.build`, `qcrypto.conf`, QEMU config (tap0 `169.254.158.190`, 2 cores, 1 GiB) — a QNX8 x86_64 QEMU environment |
| Source patches | `third_party/boost-asio_qnx.patch`, `third_party/vsomeip-qnx8.patch`, `third_party/score_baselibs/restore_qnx8_poll_workaround.patch` (in the measurement source inventory), `third_party/score_itf-qemu-ping-timeout.patch` | QNX-specific patches to dependencies/tooling |
| Target compiler | `.llm_tmp/context/obligations/development_plan.rst:165-167` | "QCC the qualify-able compiler/linker from Blackberry … is **planned** to be used for target compilation" |

### 5.2 Why this is a blocker, not a status

- **The entitlement is not configured.** `cross_compilation/result.json:235-237`
  records *"QNX SDK entitlement and target execution not configured; no credential
  acquired"*. No QNX artifact, log, or target result is retained anywhere in
  `.llm_tmp/overnight/obligations/`.
- **The QNX legs were never attempted** by the obligation collector (only the two
  Linux configs appear in `commands[]`). The QNX workflow is a *CI-only* path that
  requires repository secrets this workspace does not hold.
- **No credential was acquired and none may be.** This review does **not** read
  `.netrc`, set `SCORE_QNX_*`, invoke `qnx_credential_helper.py`, contact `qnx.com`,
  or otherwise obtain access. It performs no download and no target execution.
- **No qualification is inferred.** QCC being "qualify-able" and "planned"
  (`development_plan.rst:165-167`) is not a tool-qualification record; the
  `tool_assurance` check is `completed_with_blockers` with `bazel`/`valgrind`/
  `gitleaks`/`reuse`/`pre-commit`/`clang-format` unavailable. Tool qualification is
  unestablished.
- **Target execution is absent.** No QNX image was built, no QEMU QNX boot was
  observed, and (separately) even the Linux QEMU leg `native_integration` exited `127`
  despite `kvm_exists: true` and `qemu: /usr/bin/qemu-system-x86_64`.

### 5.3 QNX obligation status

| QNX item | Status here |
|----------|-------------|
| QNX SDK entitlement | **NOT CONFIGURED / unknown** — no credential acquired; do not infer |
| QNX toolchain availability (QCC/SDP 8.0.4) | **NOT VERIFIED** — declared in `MODULE.bazel`, never fetched |
| `x86_64-qnx` build | **NOT RUN** |
| `aarch64-qnx` build | **NOT RUN** |
| QNX integration tests (`//quality/...`) | **NOT RUN** |
| QNX8 QEMU target execution | **NOT RUN** |
| QNX-specific patches applied/validated | **NOT VERIFIED** |
| QCC tool qualification | **NOT ESTABLISHED** — "planned" only |

---

## 6. Integrator obligations and the S-CORE boundary

### 6.1 The three verification levels

`verification_plan.rst:121-150` defines:

1. **Software unit / component verification** — based on detailed design, component
   architecture, component requirements.
2. **Software integration verification (feature level)** — based on feature
   architecture and feature requirements.
3. **Software platform verification (Platform Integration Testing)** — on reference
   hardware, based on stakeholder requirements.

The bounded registration-key slice is a `socom`-internal identity change exercised only
at Level 1 (unit tests). There is no feature requirement and no feature/platform test
for version handling in this checkout (`reports/integration_aou_review.md` §9 records
the empty feature/component requirement indices).

### 6.2 The explicit integrator split

- `verification_plan.rst:64-67`: *"The integration of the platform on a target device
  and the respective verification and validation should be considered by the
  distributor of the platform. On target integration tests that are running on a
  reference hardware in context of this project can be taken as a starting point."*
- `verification_plan.rst:145-150`: *"The full Platform Integration Testing will be
  executed by the integrator. S-CORE project only executes tests on reference
  hardware. These tests serve as an optional base for the integrator … S-CORE will
  implement Platform Integration Tests for stakeholder requirements for demonstration,
  but these are not intended to completely covering all stakeholder requirements."*
- `verification_plan.rst:590-610`: the POSIX simulation environment covers aarch64 and
  x86_64 with **QNX and Linux** flavours, and *"The reference hardware is not yet
  decided."* The referenced AoUs `aou_req__platform__testing` and
  `aou_req__platform__test_completion` are cited but **not defined in this checkout**.

### 6.3 S-CORE reference vs final-product integrator obligations

| Obligation | Owner | Status here |
|------------|-------|-------------|
| Cross-build x86_64/aarch64 Linux (`//score/... //tests/...`) | S-CORE reference CI | **NOT RUN** (`exit 127`, §3) |
| QNX x86_64/aarch64 build + integration tests | S-CORE reference CI (entitlement-gated) | **NOT RUN / entitlement blocker** (§5) |
| QEMU POSIX-target simulation tests | S-CORE reference CI | **NOT RUN** (`exit 127`) |
| Reference-hardware platform tests | S-CORE (optional base) | **NOT RUN / reference hardware not decided** |
| External-component AoU verification (`gd_req__verification_external_aou`, `verification_process.rst:214-226`) | S-CORE process automation | **NOT SATISFIED** — no integration test or static-analysis verdict (`reports/integration_aou_review.md` §8) |
| CI reference-integration execution (`gd_req__verification_ci_reference_execution`, `:250-264`) | S-CORE | **NOT SATISFIED / applicability TODO** in the pinned requirement itself |
| Full platform integration + validation on the final target device | **Integrator / distributor** | **OUT OF PROJECT SCOPE**; unknown and not inferable here |

**Conclusion.** The QNX and final-product target obligations cannot be satisfied from
this workspace: the entitlement is not configured, no credential may be acquired, and
target execution is unavailable. They are recorded as **pending/blocked**, never as
passed, and no qualification claim is made.

---

## 7. What a later authorized iteration would need

This is a plan, not an executed measurement. It is retained so the gaps are actionable.

1. **Restore the Bazel driver** at the pinned `/tmp/s-core-001/bin/bazel` with
   `USE_BAZEL_VERSION=8.6.0` (or document the replacement), then re-run the two Linux
   legs:
   `bazel build --config=x86_64-linux //score/... //tests/...` and
   `bazel build --config=aarch64-linux //score/... //tests/...` — recording real
   compiler output, not just an exit code.
2. **Reconcile the working-tree drift** (§1.2) and the 85-vs-87 test-macro discrepancy
   before trusting any re-run.
3. **Obtain an authorized QNX SDK entitlement** through the approved secret/credential
   channel — this review must not and does not do so. Only after an entitled CI/env
   exists may the `x86_64-qnx`/`aarch64-qnx` builds and `//quality/...
   //tests/integration_test/...` runs be attempted.
4. **Target execution** on QNX (QEMU imagefs or reference hardware) remains the
   integrator's obligation; S-CORE provides only the reference base.
5. **Do not** report any of the retained `exit 127` collectors, the focused host
   identifier run, or `check-result: 0` as cross-target success.

---

## 8. Obligations status (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Cross-compilation x86_64-linux | `development_plan.rst`; `.bazelrc:49-52` | **NOT RUN** — `exit 127`, missing `bazel`; retention ≠ pass |
| Cross-compilation aarch64-linux | `development_plan.rst`; `.bazelrc:54-57` | **NOT RUN** — `exit 127`, missing `bazel` |
| QNX x86_64/aarch64 build + test | `development_plan.rst:165-167`; `.github/workflows/build_and_test_qnx.yml` | **NOT RUN / SDK entitlement blocker**; no credential acquired |
| Target/QNX execution | `verification_plan.rst:590-610` | **NOT RUN** — target execution not configured; integrator-owned |
| Platform Integration Testing / reference hardware | `verification_plan.rst:138-150,590-610` | **NOT RUN** — reference hardware not decided; full scope is the integrator's |
| External-component AoU verification | `verification_process.rst:214-226` | **NOT SATISFIED** — no integration/static-analysis verdict |
| CI reference integration execution | `verification_process.rst:250-264` | **NOT SATISFIED / open TODO** |
| Freedom from compiler warnings & errors (100 %) | `verification_plan.rst:332-335` | **NOT MEASURED cross-target** — focused GCC host TU clean; clang blocked on a dependency; no cross build |
| Unit/component tests executed and recorded | `verification_plan.rst:320-327` | **NOT EXECUTED under Bazel** — `native_tests` `exit 127`; focused host TU only, stale (85 vs 87) |
| Integration (QEMU) | `verification_process.rst` | **NOT RUN** — `native_integration` `exit 127` despite kvm/qemu present |
| Tool identification/evaluation/qualification | `tool_management.rst` | **NOT ESTABLISHED** — `bazel`/`valgrind`/`gitleaks`/`reuse`/`pre-commit`/`clang-format` unavailable; QCC "planned" only |
| Independence of verification / review | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Native acceptance | `.llm_tmp/context/obligations/source-index.json` | **`not_inferred` for every entry** |

**Explicit non-satisfaction statement.** The missing cross-target driver (`bazel`), the
ungranted QNX SDK entitlement, the absent target execution, the non-running QEMU and
static-analysis legs, the unknown safety class and un-inferred applicability, the
incomplete extraction of host artifacts, and the unanswered human reviews mean **none
of the checked obligations may be treated as satisfied**. A successful collection node
proves *retention*, not passing — and here the cross-target nodes did not even execute.

---

## 9. Measurement and validation status

- **Tools used:** `read_file`, `grep`, `glob`, `write_file` only. No `shell`,
  delegation, web, approval, publishing, or engineering acceptance. **No QNX
  credential was acquired; no network access to `qnx.com` was made.**
- **Executed measurements by this iteration:** **none**. No build, no test, no daemon,
  no QEMU, no cross compile, no target execution.
- **Retained cross-target-relevant measurements (scoped, unprotected):**
  `cross_compilation` — both legs `exit 127`; `native_build`/`native_tests`/
  `native_integration`/`native_performance` — `exit 127`; focused host identifier TU —
  85 tests 0 failures (candidate) vs 85/28 (baseline), `compile_exit: 0`, UBSan;
  `full_native_tests: not_executed`.
- **Test inventory (read, not run):** `service_identifier_tests.cpp` = 87 test macros
  (`process_checks/result.json:254-262`), retained host run 85;
  `runtime_tests.cpp` = 33 test macros (31 `TEST_F` + 1 `TEST` + 1 `TEST_P`).
- **Scope:** local, unprotected, scoped. No cross-target artifact exists; the QNX
  entitlement and target execution remain blockers; full native runtime tests and human
  review remain pending.

---

## 10. Notice preservation

- **Only this report was written.** No source, build, test, config, `NOTICE`,
  `LICENSE`, `REUSE.toml`, host-validation, or prior-report file was created, edited,
  or deleted. All `reports/` and `prior-reports/` files were preserved unchanged.
- The header the task flagged (`score/socom/impl/service_identifier.hpp`) retains its
  Apache-2.0/SPDX comment (`:1-12`) and was left unchanged because it is already
  balanced (§2). The sibling `service_identifier.cpp`, both BUILD files, and both
  candidate test files retain their Apache-2.0/SPDX headers; the workflow, credential
  helper, `.bazelrc`, `MODULE.bazel`, and QNX integration environment read here also
  carry Apache-2.0/SPDX notices.
- The duplicate key remains an `impl/`-only type exposed only through the `testonly`
  `//score/socom:impl_service_identifier` library, so no public header or notice
  surface changed.
- This report itself carries the Apache-2.0 header. No licensed QNX/SOME/IP/AUTOSAR
  text is reproduced; only repository-relative file locations and native identifiers
  are cited.

---

## 11. Pending human review checklist

- [ ] **Confirm §2:** `service_identifier.hpp` is brace-balanced (brace lines
      `:19,:29,:32,:38`; line 39 blank; net balance 0); the recorded "extra closing
      brace at line 39" is stale or refers to a different revision. No correction is
      required in this checkout. If a distinct "cancelled draft" revision still carries
      the brace, locate and correct it by an authorized iteration.
- [ ] **Resolve the instruction conflict:** "Inspect and correct the actual source"
      vs. "this is a review draft: only that report may be written". Confirm that
      writing only this report, with a no-op on already-correct source, is intended.
- [ ] **Restore the native driver** (`bazel` at `USE_BAZEL_VERSION=8.6.0`) and re-run
      the two Linux cross-builds, capturing real compiler output.
- [ ] **Decide the QNX path:** provide an authorized QNX SDK entitlement/credentials
      through the approved channel and run `build_and_test_qnx.yml`'s matrix, or record
      an approved deferral/tailoring. **Do not** treat the declared QCC/SDP toolchains
      or the "qualify-able" language as a qualification.
- [ ] **Confirm the S-CORE/integrator split for this slice (§6):** the bounded slice is
      Level-1-only; full platform integration and target-device validation remain the
      integrator's obligation; the reference hardware is not yet decided and the
      referenced platform AoUs are not defined in this checkout.
- [ ] **Reconcile the drift and staleness:** candidate-snapshot vs. collector hashes
      (§1.2) and the 85-vs-87 test-macro difference, then re-run the focused host
      validation on the current tree.
- [ ] **Do not infer passing from retained collection nodes:** the cross-compilation,
      native, QEMU, and QNX legs all failed to run or were never attempted; `check-result: 0`
      is a retention marker only.
- [ ] **Keep the wider #84 public `Service_interface_identifier` restructure, FindService
      wildcard handling, and the config minor-wildcard narrowing out of this bounded
      slice**, and do not present identifier-only tests as platform/target validation.
- [ ] **Schedule independent human review** (approver ≠ author, per
      `gd_req__verification_independence`) and record engineering acceptance; no
      compliance or qualification claim may be made before that.

---

*End of review draft. Local, unprotected, scoped. No engineering acceptance; human
reviews unanswered; full native runtime tests pending; x86_64/aarch64 Linux cross-builds
not executed; QNX SDK entitlement unknown and no credential acquired; no target
execution performed; no qualification inferred.*
