<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — registration-key correction (`key_fix`) review draft

**Document type:** review draft (actual-source inspection + registration-key
correction record + preserved-rule verification)
**Date:** 2026-10-02
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version
handling in socom*
**Run:** `fabro/run/01M3YRJEGXNY6CB81T7TKW774B`; HEAD `236f629`
(`fabro(01M3YRJEGXNY6CB81T7TKW774B): node_d2fdb79acfbec37dfb74066b (success)`), per
`.git/logs/HEAD:5` and the environment. Four earlier stages of this run committed
`8934e94` (start), `84ea712` (`node_51f7ccb6b2715b106cf242f4`), `56304d4`
(`node_3752dc1af9e2f3b0ee1454f2`), `a616495` (`node_edd8fcbae2fee64d3bbd0c31`), and
`236f629` (`node_d2fdb79acfbec37dfb74066b`).
**Status:** local, unprotected, scoped. **No engineering acceptance exists. Human
reviews are unanswered. Full native runtime tests remain pending.** Every statement
below is either a direct static reading of this checkout at the baseline-bound candidate
paths or an explicitly-labelled logical consequence. Nothing here is published,
reviewed, accepted, or a full native run.

> **Tool / write boundary actually observed.** Only `read_file`, `grep`, `glob`, and
> `write_file` were available and were the only tools used. No `shell`, no delegation,
> no web access, no approval, no publishing, and no engineering acceptance was
> performed. The task permits changing only the six named candidate source paths and
> this report. Of those, **this iteration wrote exactly one file — this report.** No
> source, build, test, config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was created,
> edited, or deleted. Every prior report under `.llm_tmp/overnight/prior-reports/` and
> every earlier report under `.llm_tmp/overnight/reports/` was preserved unchanged.
>
> **Why no source edit was made, though the six paths were writable.**
> 1. The task records "a measured GCC syntax failure: an extra closing brace in
>    `score/socom/impl/service_identifier.hpp` at line 39" and directs: "Inspect and
>    correct the actual source before expanding tests." Direct inspection of the
>    *actual* checkout shows the header is **already brace-balanced** and line 39 is
>    **blank** (§2). There is no unmatched closing brace to remove.
> 2. The task also asks to "implement the smallest registration-key correction
>    preserving interface representation and exact-major/minimum-minor rules." That
>    correction (identity `(instance, service id, major)`; `minor` excluded from the
>    duplicate key) is **already present** in
>    `score/socom/impl/service_identifier.cpp:28-29` (§3), the public interface
>    representation and compatibility rules are unchanged (§4), and the key-level and
>    runtime-level regressions are already present (§5).
>
>   The smallest correction to already-correct source is therefore **no change**.
>   Re-introducing or "removing" a brace that does not exist would break compilation;
>   rewriting the already-minor-excluding key would be a no-op at best. The minimal
>   syntax repair is retained in §2.3 for reference only.

---

## 0. Summary

1. **Recorded syntax failure — inspected; not present in the actual source.**
   `score/socom/impl/service_identifier.hpp` is brace-balanced. A `grep` for brace
   characters (`[{}]`) on the file returns exactly four lines: `:19`
   (`namespace score::socom {`), `:29` (`struct Service_instance_identifier final {`),
   `:32` (`};`), and `:38` (the single `}  // namespace score::socom`). Two openers and
   two closers give a net brace balance of `0`; line 39 is empty and line 40 is
   `#endif`. There is **no third, unmatched closing brace** (§2). The tabulated
   `[{}]` line numbers are the direct output of this iteration's `grep`, not a
   restatement of a prior report.
2. **Registration-key correction — present and minimal.** The key's only operator,
   `operator<(Service_instance_identifier const&, Service_instance_identifier const&)`
   (`score/socom/impl/service_identifier.cpp:20-30`), compares `(instance, service id,
   major)`, so the **minor version is excluded** from the duplicate-server identity
   (`:28-29`). This makes the duplicate gate exactly as coarse as the deliberately
   minor-ignoring `Service_database` record index
   (`score/socom/impl/runtime_impl.hpp:102-138`, `:116-134`), closing the gap recorded
   as I-11 in the prior reports (§3).
3. **Interface representation and the exact-major / minimum-minor rules preserved.**
   `Service_interface_identifier{Id id; Version{std::uint16_t major; std::uint16_t
   minor;}}` is unchanged (`score/socom/service_interface_identifier.hpp:73-124`,
   `:80-88`); the exact-major and `client.minor <= server.minor` ("minimum-minor")
   rules remain enforced by `is_minor_version_compatible` / `is_interface_compatible`
   (`score/socom/impl/runtime_impl.cpp:133-146`), **not** by the key (§4).
4. **Tests and wiring present.** `score/socom/test/unit/service_identifier_tests.cpp`
   carries **83 `TEST_F`** cases under `ServiceInstanceIdentifierTest`
   (`:168`…`:1851`, counted this iteration by `grep`);
   `score/socom/test/unit/runtime_tests.cpp` carries **31 `TEST_F` + 1 `TEST` + 1
   `TEST_P`**, including the minor-only duplicate regression
   `ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError`
   (`:402-431`); both BUILD files already wire the test-only key header and the test
   framework. No BUILD change is required (§5).
5. **No obligation is satisfied.** No tool ran beyond reading; no build, no test. The
   pinned obligation entries are `native_acceptance: not_inferred`; `authority.json`
   records `engineering_acceptance: pending`, `human_reviews: unanswered`,
   `safety_class: unknown`. `.llm_tmp/overnight/validation/` and
   `.llm_tmp/overnight/obligations/*/result.json` are **absent from this checkout**
   (§1.5, §7). Missing tools, unknown applicability, incomplete extraction, and
   unanswered human reviews are **not** treated as satisfied.

---

## 1. Binding to the verified baseline, prior reports, host feedback, obligations

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` | `.llm_tmp/context/issue-snapshot.json:2-4` |
| Title | *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:3` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` (unchanged) | `.llm_tmp/context/issue-snapshot.json:19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an
accepted obligation**. It distinguishes: service-instance identifier =
`service id + major + minor + instance id`; service identifier =
`service id + major`; FindService = `service id + major + optional<minor> +
optional<instance>`; and proposes to "exclude the minor version and make it a property
of the service instance". The FindService `major = FF` AUTOSAR case is called
theoretically possible but not useful. There is **no comment and no acceptance
record** in the snapshot, so none of it is binding.

### 1.2 Verified baseline

| Item | Value | Source |
|------|-------|--------|
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |
| Current branch | `fabro/run/01M3YRJEGXNY6CB81T7TKW774B` | `.git/HEAD:1` |
| Current HEAD | `236f629` — `fabro(…): node_d2fdb79acfbec37dfb74066b (success)` | `.git/logs/HEAD:5` |

Binding is **by baseline commit**, not by run HEAD. Earlier reports reference other
run IDs on the same baseline commit (`01M3YGTGYFEN406VDEVVTJTRWV`,
`01M3XZAQ65TTE35XSGXC4JAMAH`, `01M3XT7NQ04S4MTFRMTT2401XK`, `01M3WX09X84XFM5X08QY2944DF`,
and before them `01M3WSTF1DAJA248NQ5QQGQG52` / `a282596` and
`01M3WWRQWT262FTYS52X80YPTP` / `e12e7cb`), so all of them describe the same baseline
and are admissible as prior evidence.

### 1.3 In-scope candidate files (the only writable source paths)

From `.llm_tmp/context/candidate-files.json:1-25` (baseline blobs cross-checked
against the `files` array of `.llm_tmp/context/source-manifest.json`):

| File (repo-relative) | Baseline git blob | Baseline present | Current working tree |
|----------------------|-------------------|------------------|----------------------|
| `score/socom/BUILD` | `3477ea0851fdcd82ec6ea9d71424013cbdf41962` | yes | `testonly` `impl_service_identifier` exposure present (`:46-54`) |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e22355242009fe20dada2a9a0d0c7a9c7` | yes | key identity `(instance, id, major)`; `minor` excluded (`:28-29`) |
| `score/socom/impl/service_identifier.hpp` | `c8bae7908da9f087c518934f7b9f8d86db9a20ec` | yes | brace-balanced, 40 lines, `:39` blank (§2) |
| `score/socom/test/unit/BUILD` | `3c03a7b14286051f97fa5022206564bd63645171` | yes | `socom_test` globs `*.cpp`; deps wired (`:16-29`) |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab726db8bf994c960045d6fd7fdf84d7395` | yes | 31 `TEST_F` + 1 `TEST` + 1 `TEST_P`; minor-only regression `:402-431` |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(none — `null`)* | **no** (manifest expects a **new** file) | 83-case `TEST_F` matrix present |

The `null` baseline blob for `service_identifier_tests.cpp` is the manifest's
expectation of a **new** unit-test file; it exists on disk only as part of the
un-merged working tree (the "cancelled draft"), never in the baseline. The five present
baseline blobs also appear in the `files` array of
`.llm_tmp/context/source-manifest.json`, which binds the candidate set to the baseline
commit. `glob` over `**/service_identifier.hpp` returns exactly one path, so there is
no second, differently-braced copy of the header in this checkout.

### 1.4 Prior reports read and preserved

- `.llm_tmp/overnight/prior-reports/` — present, all read and preserved:
  `callsites.md`, `conversion_tests.md`, `invariants.md`, `key_fix.md`,
  `lifetime_tests.md`, `ordering_tests.md`, `reproducer.md`, `runtime_disabled.md`,
  `runtime_enabled.md`, `scope.md`, `test_metadata.md`, `unit_matrix.md`. Several
  reports additionally cite `repair_unit_matrix.md`, `coverage_tests_repair.md`,
  `tool_findings_repair.md`, and a host addendum `obligation-addendum.md`; **none of
  those four files is present in this checkout**, so their content is available only
  as quoted by the other prior reports.
- `.llm_tmp/overnight/reports/` — read, not modified: `scope.md`, `callsites.md`,
  `invariants.md`, `reproducer.md` (the four earlier nodes of this run). This document
  adds `key_fix.md`.

Derived sequence across the preserved reports: `scope.md` (bounded the slice) →
`invariants.md` (I-4 baseline key included `minor`; I-9 record index ignores `minor`;
I-11 the resulting gap) → `callsites.md` (call-site map) → `reproducer.md` (header
brace correction + focused red regression) → `key_fix.md` / `unit_matrix.md` (drop
`minor` from the ordering; expand key tests) → `ordering_tests.md` → runtime/lifetime
reports → `conversion_tests.md` → `test_metadata.md`.

**Reconciliation of the conflicting brace claims across prior reports.** The earliest
reports (`prior-reports/scope.md` §2, `prior-reports/invariants.md` §2) quote lines
38-39 as the split-form double close (`}  // namespace socom` + `}  // namespace
score`) and record the header as **broken**. Every later report records the header as
**already balanced**. The actual source read this iteration (§2) matches the **later**
set: the correction was applied by the `reproducer` iteration, and the write left line
39 blank in place of the removed brace.

### 1.5 Host validation feedback and obligation-collection results

- **Host feedback under `.llm_tmp/overnight/validation/`: absent from this checkout.**
  `glob` over `.llm_tmp/overnight/validation/**` returns no entries; there is no
  `validation/` directory and no host feedback to reconcile against.
- **Obligation-collection results under `.llm_tmp/overnight/obligations/`: absent from
  this checkout.** `glob` over `.llm_tmp/overnight/obligations/**` returns no entries;
  no `*/result.json` exists. Earlier reports *retain summaries* of host artifacts
  (`check-result: 0`; `measurement.json` `origin: local_unprotected_measurement`,
  `initiator: Fabro host hook`, `mode: ubsan`, `engineering_acceptance: pending`,
  `full_native_tests: not_executed`, `check_ref: check_conversion_tests`; candidate
  46 tests / 0 failures / compile exit 0; `baseline_with_agent_tests` 46 / 15 / exit 0;
  a later capture with 83 / 0 and 83 / 28; focused coverage `service_identifier.cpp`
  100 % line / 50 % branch; asan/lsan/memcheck 46/46; tsan environment failure;
  clang-tidy config blocker; `native_*` / `cross_compilation` / `native_performance`
  failing to fetch toolchains with `No space left on device`). **Per the task rule, a
  successful collection node means results were retained, not that checks passed; here
  nothing is retained at all, so no obligation may be treated as satisfied on that
  basis.**
- Those retained summaries are also **scoped and stale**: they compiled only the
  focused identifier translation unit (`service_identifier.cpp` +
  `string_registry.cpp` + `service_identifier_tests.cpp`) with `g++-12 -std=c++17
  -Wall -Wextra -Werror`; they did **not** compile `runtime_tests.cpp` or the full
  `socom_test` / `//score/...` targets, and the recorded
  `service_identifier_tests.cpp` hash predates later expansions (the current file has
  83 `TEST_F`, not the 46-case state the earliest capture compiled).

### 1.6 Host addendum (task context, not acceptance)

`prior-reports/obligation-addendum.md` (present only as quoted by other prior reports)
states it "is task context, not engineering acceptance or an approved tailoring
decision". It asks the review to cover the `verification_process.rst` test types
(fault injection, interface, requirements, resource) and derivation techniques
(requirements/design/boundary/equivalence/fuzzy/error-guessing/explorative); to keep
`security_review`, `traceability_review`, `integration_aou_review`, and
`verification_report_draft` distinguishing configured module tests from any absent
fuzz/fault-injection harness or full feature/platform reference-hardware tests; to
leave unknown applicability and unexecuted checks explicit; to **not** label
identifier-only tests as full platform validation and **not** to claim a fuzzy
technique without a measurement; to permit concrete missing boundary/equivalence
regression cases within the six source paths; and to record that there is **no
authority to invent native links, select a safety classification, accept
risk/deviations, or answer the independent human gate.** This report honours that in
§4, §5, and §7.

---

## 2. Syntax failure: inspection of the actual source

### 2.1 Finding (re-verified this iteration by direct `read_file` + `grep`)

`score/socom/impl/service_identifier.hpp` is **brace-balanced**. It is 40 lines:

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

A `grep` for `[{}]` on the file returns exactly `:19`, `:29`, `:32`, `:38`. Two
openers (`:19`, `:29`) and two closers (`:32`, `:38`) mean net brace balance `0`. There
is **no third, unmatched closing brace**, and line 39 contains no text at all. The
task's "extra closing brace … at line 39" is therefore a **stale, pre-correction
description** that matches the earliest prior reports (which quote lines 38-39 as the
split-form `}  // namespace socom` + `}  // namespace score`), not this checkout. The
`reproducer` iteration applied the correction; the removed brace left line 39 blank,
exactly as observed here.

### 2.2 Repository convention (evidence)

The tree uses two internally-consistent styles:

- **Nested open + single close:** `namespace score::socom {` … one
  `}  // namespace score::socom`. This is sibling `impl/service_identifier.cpp`
  (`:18` / `:32`), the public `service_interface_identifier.hpp` (`:25` / `:164`),
  `registry_string_view.hpp` (`:20` / `:177`), and `error.hpp` (`:23` / `:63`).
- **Split open + double close:** `namespace score {` + `namespace socom {` … `}  //
  namespace socom` + `}  // namespace score`. This is `impl/runtime_impl.hpp`
  (`:32-33` / `:232-233`).

`impl/service_identifier.hpp` follows the **nested** form consistently and is balanced.
Its `.cpp` sibling is balanced the same way (the `[{}]`-bearing lines are `:18`, `:20`,
`:30`, `:32`).

### 2.3 Minimal repair (retained for reference only; not applied because not needed)

Should the imbalance ever reappear, the minimal correction — matching the sibling
`.cpp` — is:

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

Applying this to the already-balanced file would be a no-op; re-introducing a broken
state merely to "fix" it would be a regression. No other structural change is
required.

### 2.4 Why it would matter if present

The header is compiled into `//score/socom:socom` (`score/socom/BUILD:24-41`; its
`srcs` globs `impl/**/*.cpp` and `impl/**/*.hpp`) and re-exposed to
`//score/socom/test/unit` via the `testonly` library `impl_service_identifier`
(`score/socom/BUILD:46-54`; `score/socom/test/unit/BUILD:24`). A syntax error here
would fail both the library and the whole `socom_test` target, contradicting S-CORE
quality criterion 9, "Freedom from compiler warnings & errors, 100 %"
(`verification_plan.rst:332-335`). The current balanced state removes that blocker at
the source level; that is **not** a compile measurement (§8).

---

## 3. The bounded registration-key correction

### 3.1 The change (present in `score/socom/impl/service_identifier.cpp:20-30`)

```cpp
return std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major) <
       std::tie(rhs.instance, rhs.interface.id, rhs.interface.version.major);
```

This is the smallest change that makes the duplicate-server registration key
consistent with the record index. `std::set` uniqueness is `!(a < b) && !(b < a)`, so
identity is exactly `(instance, service id, major)` and **the minor version is
excluded**. The ordering relies only on already-available operators:
`Service_instance::operator<` (`service_interface_identifier.hpp:69-71`) and
`Registry_string_view::operator<` (`registry_string_view.hpp:141-143`).

For contrast, the pre-correction (baseline) ordering reported by
`prior-reports/invariants.md` I-4 was `std::tie(lhs.instance, lhs.interface) <
std::tie(rhs.instance, rhs.interface)`, delegating to
`Service_interface_identifier::operator<` / `Version::operator<`
(`service_interface_identifier.hpp:140-143`, `:159-162`) and therefore including
`minor`; baseline identity `(instance, id, major, minor)`. The baseline blob is not in
this working tree, so that is a prior-report reading, not a direct re-read.

The key type itself is unchanged in representation:
`Service_instance_identifier{ Service_interface_identifier interface; Service_instance
instance; }` (`impl/service_identifier.hpp:29-32`), with `operator<` as its only
operator (`:35`; declaration hidden with `\cond`) and **no** `operator==`/`std::hash`.
It is used only as the `std::set` element type
(`using Service_identifiers = Mutexed_variable<std::set<Service_instance_identifier>>`,
`impl/runtime_impl.hpp:56`), constructed at `runtime_impl.cpp:443` and inserted under
the key mutex at `:449-454`.

### 3.2 What is preserved (as the task requires)

| Rule | Evidence | Preserved |
|------|----------|-----------|
| Interface representation | `Service_interface_identifier{Id id; Version{major, minor}}`, both fields `std::uint16_t` (`score/socom/service_interface_identifier.hpp:73-124`, `:80-88`) | yes |
| Exact-major | `major` is an identity component of the key (`service_identifier.cpp:28-29`) and of `is_interface_compatible` (`runtime_impl.cpp:144`) | yes |
| Minimum-minor (client minor ≤ server minor) | `is_minor_version_compatible` (`runtime_impl.cpp:133-136`) and `is_interface_compatible` (`:138-146`); **not** part of the key | yes |
| `Service_database` minor-ignoring index | `Minor_version_ignoring_key_equal` / `Minor_version_ignoring_hash` (`runtime_impl.hpp:116-134`) untouched | yes |
| Public/ABI surface | the key stays an `impl/`-only type (`score/socom/BUILD:17-41`, `:46-54`) | yes |
| Ordering-only identity | no `operator==`/`std::hash` added for the key; `operator<` remains the single rule | yes |

### 3.3 Why this direction (source-derived, not accepted)

- `Service_database` already defines record identity as `id + major + instance` and
  resolves both server and client connectors through it
  (`runtime_impl.hpp:102-138`; `runtime_impl.cpp:313-324`).
- The single-server-per-record precondition is asserted, not tolerant
  (`SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)`, `runtime_impl.cpp:369`), followed by
  `m_server.emplace(...)` at `:371`.
- Therefore the duplicate gate must be **at least as coarse as** record identity.
  Excluding `minor` from the key is the minimal way to achieve that: two
  configurations sharing `id + major + instance` but differing only in `minor` now
  collide at the set insertion in `Runtime_impl::make_server_connector`
  (`runtime_impl.cpp:443`, `:449-454`) and the second is rejected with
  `Construction_error::duplicate_service`, instead of reaching the single-`std::optional`
  server path.

This does **not** settle the wider open questions (whether `minor` should move onto
`Service_instance`, whether a minor-only collision should supersede, FindService
wildcard handling, the config `0xFFFFFFFF` minor narrowing). Those remain deferred.

---

## 4. Interface representation and compatibility rules

- **Public identifier.** `Service_interface_identifier` is a struct with `Id id` and
  `Version version`, and `Version` holds `std::uint16_t major` and `std::uint16_t
  minor` (`score/socom/service_interface_identifier.hpp:73-124`, `:80-88`). Its
  `operator==`/`operator<` and `std::hash` still include both `major` and `minor`
  (`:130-162`, `:181-190`). This is untouched by the key change.
- **Exact-major.** `is_interface_compatible` requires `server.version.major ==
  client.version.major` (`runtime_impl.cpp:144`).
- **Minimum-minor.** `is_minor_version_compatible` is `client.version.minor <=
  server.version.minor` (`runtime_impl.cpp:133-136`), applied at the client bind and
  server connect paths (`:505-517`, `:534-544`). It is **not** encoded in the
  registration key.
- **Record index.** `Service_database::m_service_records` groups by `id + major` and
  ignores `minor` via `Minor_version_ignoring_key_equal` /
  `Minor_version_ignoring_hash` (`runtime_impl.hpp:116-134`).

The key change therefore coarsens only the duplicate-server gate; it does not alter the
public type, the compatibility semantics, or the record index.

---

## 5. Tests and build wiring

### 5.1 Key-level tests

`score/socom/test/unit/service_identifier_tests.cpp` (new file per the manifest;
Apache-2.0 header present) carries an **83-case** identity/ordering matrix under
`ServiceInstanceIdentifierTest` (counted this iteration by `grep`; cases span
`:168`…`:1851`), including:

- irreflexivity (`SameIdentifierIsNotLessThanItself`, `:168`);
- minor exclusion at adjacency, `uint16` extremes, sweeps, and set-find
  (`KeysDifferingOnlyInMinorVersionAreDuplicates` `:174`,
  `MinorVersionBoundariesAreDuplicates` `:182`,
  `AllMinorVersionsCollapseToSingleKey` `:192`,
  `MinorHighBitVariantsAreEquivalent` `:203`,
  `MinorVersionNeverAffectsOrdering` `:430`,
  `SetFindLocatesMinorVariantAndCountsItOnce` `:1034`,
  `StdSetCollapsesFiveMinorVariantsOfEveryIdentity` `:1321`);
- major including `0`/`65535` boundaries and adjacency
  (`KeysDifferingInMajorVersionAreDistinct` `:217`,
  `MajorVersionBoundariesAreDistinct` `:225`);
- service id and instance identity, plus distinct-set sizes;
- combined matrices (2x2x2 and 3x3x3 with minor collapse, `:358`…`:419`);
- equivalence and ordering consistency (equivalence ⇔ `(instance, id, major)`,
  transitivity, exactly-one-direction ordering, set iteration order vs an independent
  tuple reference, `:420`…`:536`);
- strict-weak-ordering property checks over deterministic 36-key and larger domains
  (`:537`…`:735`, `:1055`…`:1148`, `:1456`…`:1488`);
- text/registry → public-identifier → internal-key conversion boundaries
  (`:784`…`:1049`, `:1149`…`:1200`, `:1531`…`:1600`).

The record metadata is set in `SetUp()` (`:42-65`):
`DerivationTechnique = "boundary-values,equivalence-classes"` and a `Description`.
`TestType` and the `Verifies`/`PartiallyVerifies`/`FullyVerifies` links are
deliberately **not** set, because no verified native requirement/interface identifier
exists for this slice and inventing one is prohibited. The type declares no
`operator==`/hash, so "equality" is defined as mutual non-ordering
(`!(a<b) && !(b<a)`), which is exactly the `std::set` equivalence.

### 5.2 Runtime-level regression

`score/socom/test/unit/runtime_tests.cpp:402-431`
(`ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError`)
exercises the real registration entry point: it builds two
`Service_interface_identifier`s that share id (`"TestInterface"`), major (`1`) and
instance (`"TestInterface"`) and differ only in `minor` (2 vs 3), calls
`Runtime::make_server_connector()` twice via the public `Runtime` interface, and
expects the second call to equal
`score::MakeUnexpected(Construction_error::duplicate_service)`. The file also carries
same-configuration disabled (`:440-469`), different-major (`:471-504`), enabled-
duplicate (`:694`), lifetime/reuse (`:371`, `:986`, `:1021`), and service-id/instance/
major slot isolation (`:1253`, `:1197`, `:1141`) cases, plus the metadata helper
`record_registration_key_metadata` (`:264-267`). Both connectors remain disabled, so the
duplicate is rejected at construction and never reaches the single-server
`SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)` path.

### 5.3 Boundary / equivalence coverage versus the host addendum

For this bounded key slice, honouring the host addendum (§1.6):

- **Boundary values:** major `0`, `1`, `0x7FFF`, `0x8000`, `0xFFFE`, `65535`; minor
  `0`, `1`, `2`, `3`, `0x7FFF`, `0x8000`, `65535` are covered by the key tests.
- **Equivalence classes:** minor-only (equivalent) versus service-id / instance /
  major differences (distinct) are covered, including combined matrices and
  deterministic multi-key domains.
- **Still absent / unknown applicability (explicit pending work):** no fuzz harness, no
  fault-injection harness, and no full feature-/platform-level reference-hardware tests
  exist in this workspace; no fuzzy technique was executed. These identifier-only tests
  must **not** be presented as platform validation. The minimum-minor rule is
  exercised by other suites (`interface_compatibility_tests.cpp`, `client_tests.cpp`),
  not by this key slice.

### 5.4 Build wiring

- `score/socom/BUILD:46-54` defines the `testonly` `impl_service_identifier` library
  exposing `impl/service_identifier.hpp` to `//score/socom/test/unit:__pkg__`,
  depending on `:socom`.
- `score/socom/test/unit/BUILD:16-29` defines `socom_test` with
  `srcs = glob(include = ["*.cpp"])` and depends on
  `//score/socom:impl_service_identifier`, `//score/socom:mock`,
  `//score/socom/test/framework:socom_test_framework`, and googletest.

Therefore both new/expanded test files are already collected and the internal key
header is visible to the test package; **no BUILD change was required or made.**

---

## 6. Files changed / state of the six candidate paths

This iteration wrote **only this report** (`key_fix.md`). No candidate source path
needed a change:

| Candidate path | State | This iteration |
|----------------|-------|----------------|
| `score/socom/impl/service_identifier.hpp` | brace-balanced, nested namespace, documents minor exclusion | unchanged (verified) |
| `score/socom/impl/service_identifier.cpp` | `operator<` identity `(instance, id, major)`, minor excluded | unchanged (verified) |
| `score/socom/BUILD` | `testonly impl_service_identifier` exposure present | unchanged |
| `score/socom/test/unit/BUILD` | `socom_test` globs `*.cpp`, deps wired | unchanged |
| `score/socom/test/unit/runtime_tests.cpp` | minor-only duplicate regression present | unchanged |
| `score/socom/test/unit/service_identifier_tests.cpp` | 83-case key matrix present | unchanged |
| `.llm_tmp/overnight/reports/key_fix.md` | **new — this report** | written |

No file outside the six candidate paths and this report was written; no `NOTICE`,
`LICENSE`, or `REUSE.toml` file was created, edited, or deleted; all prior reports were
preserved.

---

## 7. Obligations status (none satisfied)

### 7.1 Pinned sources read this iteration

All nine entries of `.llm_tmp/context/obligations/source-index.json` are present in
`.llm_tmp/context/obligations/`, together with `authority.json`:

| id | file | status note |
|----|------|-------------|
| `coding_guidelines` | `coding_guidelines.rst` | `:status: valid`; MISRA C++:2023 with C++17 |
| `code_analysis` | `code_analysis.rst` | `:status: valid`; clang-tidy + gcc/clang warnings + Coverity; sanitizers |
| `misra_mapping` | `misra_mapping.rst` | **`:status: draft`**; the rule table is commented out |
| `verification_plan` | `verification_plan.rst` | `:status: valid`, `:safety: ASIL_B`; TestType/DerivationTechnique tables; quality criteria 1-9 (criterion 9 at `:332-335`) |
| `development_plan` | `development_plan.rst` | `:status: valid`; C++17, GCC host compiler, Bazel |
| `tool_management` | `tool_management.rst` | `:status: valid`; tools must be identified / evaluated / qualified |
| `verification_process` | `verification_process.rst` | `:status: valid`; `gd_req__verification_link_tests_cpp`, `gd_req__verification_independence`, SCA classification |
| `verification_guideline` | `verification_guideline.rst` | `:status: valid`; traceability, independence, documented results |
| `inspection_checklist` | `inspection_checklist.rst` | **`:status: draft`**; blank IMPL_01_01…IMPL_03_02 template |

Every entry in `source-index.json` is marked `"native_acceptance": "not_inferred"` —
pinned, but its applicability to this slice is **not inferred**. `authority.json`
records `"engineering_acceptance": "pending"`, `"human_reviews": "unanswered"`,
`"safety_class": "unknown"`, `"codeql_scope": "Public Apache-2.0
eclipse-score/inc_someip_gateway; no upload"`, and the instruction "Restart the failed
queue for one complete pass through all obligations".

### 7.2 Obligation status for this slice (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Freedom from compiler warnings & errors (100 %) | `verification_plan.rst:332-335` (criterion 9) | **NOT MEASURED** — header is brace-balanced by inspection (§2), but nothing was compiled; no host artifact is present |
| Static code analysis (clang-tidy / CodeQL), findings classified | `code_analysis.rst`; `verification_process.rst` (SCA classification) | **NOT PERFORMED** — no tool, no build; a prior clang-tidy attempt was blocked on configuration; CodeQL MISRA applicability unestablished (draft mapping) |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` | **UNKNOWN** — mapping is `:status: draft`; not applied |
| Structural statement / branch coverage goals | `verification_plan.rst:300-307` (criteria 1-2) | **NOT MEASURED** — no test execution; prior coverage capture is out of this checkout and below the 85 %/100 % platform goals |
| Unit/component testing executed, results recorded | `verification_plan.rst:320-327` (criteria 6-7); `verification_guideline.rst` | **NOT EXECUTED** — 0 tests run; the prior key-TU run is stale (46-case) and excludes `runtime_tests.cpp` |
| Interface / requirements-based / resource / fault-injection test types | `verification_process.rst`; `verification_plan.rst:167-240` | **NOT PERFORMED / applicability not inferred** — no harness; identifier-only tests must not be labelled platform validation |
| Boundary / equivalence derivation | `verification_process.rst` (derivation methods) | **SOURCE-ONLY** — cases exist (§5.3) but were not executed |
| Fuzzy testing technique | `verification_plan.rst:265-270` | **NOT EXECUTED / NOT CLAIMED** — no harness and no measurement |
| Linking tests to requirements (record properties) | `verification_process.rst` (`gd_req__verification_link_tests_cpp`) | **PARTIAL / NOT DONE** — `DerivationTechnique`/`Description` recorded; `TestType` and `Verifies` cannot be set without inventing identifiers |
| Independence of verification / review by a different committer | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Implementation inspection checklist IMPL_01…IMPL_03 | `inspection_checklist.rst` | **NOT FILLED** — draft template, no inspection |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** for this slice; no tool run here |
| Obligation collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **ABSENT in this checkout** — directory not present |
| Native acceptance | `source-index.json` | **not_inferred** for every entry |

**Explicit non-satisfaction statement.** Missing tools (no build/test in this task), the
unknown safety class and un-inferred applicability, the incomplete extraction of host
artifacts, the absent obligation-collection results, and the unanswered human reviews
mean **none of the checked obligations may be treated as satisfied**. A collection node
that retained results would only show *retention*, not passing; here there are no
retained results at all. In particular, the absence of
`.llm_tmp/overnight/validation/` and `.llm_tmp/overnight/obligations/*/result.json` is
**not** evidence that the corresponding checks passed.

---

## 8. Measurement and validation status

- **Tools:** `read_file`, `grep`, `glob`, `write_file` only. No `shell`, delegation,
  web, approval, publishing, or engineering acceptance.
- **Executed measurements:** **none** this iteration. No build, no `bazel test`, no
  runtime. The brace census (§2), the key identity (§3), and the expected test
  behaviour (§5) are static source readings and strict-weak-ordering consequences, not
  observed results.
- **Test inventory (read, not run):** `service_identifier_tests.cpp` has **83
  `TEST_F`** under `ServiceInstanceIdentifierTest` (`:168`…`:1851`);
  `runtime_tests.cpp` has **31 `TEST_F`** (`:279`…`:1253`) **+ 1 `TEST`** (`:239`)
  **+ 1 `TEST_P`** (`:1311`). All counts verified this iteration by `grep`.
- **Scope:** local, unprotected, scoped. This is a bounded correction/verification
  record, not an accepted engineering decision. Full native runtime tests and human
  review remain pending.
- **Reproduction path for a later, permitted iteration (not executed here):**

  ```bash
  bazel test //score/socom/test/unit:socom_test
  # focused key-level:
  bazel test //score/socom/test/unit:socom_test --test_filter='ServiceInstanceIdentifierTest.*'
  # focused runtime regression:
  bazel test //score/socom/test/unit:socom_test \
      --test_filter='RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError'
  ```

  Expected on the corrected key: the minor-only key tests collapse to one set element
  and the runtime regression returns `Construction_error::duplicate_service`. On a key
  that includes `minor`, both focused checks would fail. These expectations are
  source-derived, not measured.

---

## 9. Notice preservation

- No source, build, test, config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was
  created, edited, or deleted by this iteration. Every existing Apache-2.0 / notice
  header is untouched, and all prior reports under
  `.llm_tmp/overnight/prior-reports/` plus the four earlier reports under
  `.llm_tmp/overnight/reports/` were preserved.
- The header the task flagged (`score/socom/impl/service_identifier.hpp`) was inspected
  and left unchanged because it is already brace-balanced and otherwise well-formed
  (§2).
- This report carries the Apache-2.0 header.
- The duplicate key remains an `impl/`-only type; the `testonly`
  `//score/socom:impl_service_identifier` library exposes it to
  `//score/socom/test/unit` only, so no public header or notice surface changed.

---

## 10. Pending human review checklist

- [ ] **Confirm the §2 inspection:** the header is already brace-balanced (single
      nested close `}  // namespace score::socom`; line 39 blank), so the recorded
      syntax failure is stale and no source edit is required. Re-check before any
      compile if the state ever changes.
- [ ] **Resolve the instruction conflict:** the task directs correcting the source,
      while the actual source contains no defect; confirm that a no-op is the intended
      outcome here.
- [ ] **Confirm the bounded key decision in §3:** `minor` is **not** part of the
      duplicate-server registration key; identity `(instance, service id, major)`;
      interface representation and the exact-major / minimum-minor rules unchanged.
- [ ] **Confirm the baseline binding in §1.2-1.3** (issue #84 ↔ commit `f8a196c3…`)
      and that `prior-reports/invariants.md` I-4's baseline ordering (`minor` included)
      still describes the committed baseline.
- [ ] **Confirm `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)`** is the authoritative
      single-server invariant, so the key must be at least as coarse as the record
      index.
- [ ] **Confirm the key test matrix (§5.1)** and the runtime regressions (§5.2) are the
      intended coverage, and that the boundary/equivalence cases satisfy the host
      addendum (§1.6, §5.3). Do **not** present the identifier-only tests as platform
      validation or claim an unmeasured fuzzy technique.
- [ ] **Keep the #84 public `Service_interface_identifier` restructure, FindService
      wildcard handling, and the config minor-wildcard narrowing out of this bounded
      slice** until separately accepted.
- [ ] **Supply native requirement source IDs and traceability metadata** (no invented
      links), or record applicability as unresolved.
- [ ] **Supply the missing artifacts** (`.llm_tmp/overnight/obligations/*/result.json`
      and `.llm_tmp/overnight/validation/`) into this checkout; do not infer passing
      from absence or from prior reports' retained summaries.
- [ ] **Run the full native suite** (`bazel test //score/socom/test/unit:socom_test`
      and the broader `//score/...` set), including `runtime_tests.cpp`, record results,
      and schedule independent human review (the approver must differ from the author,
      per `gd_req__verification_independence`).
