<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — duplicate-server registration-key unit matrix (actual-source inspection + coverage map)

**Document type:** review draft (actual-source inspection + existing key-matrix coverage map + obligations status)
**Date:** 2026-10-02
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version handling in socom*
**Run:** `fabro/run/01M3YRJEGXNY6CB81T7TKW774B`; latest prior stage report in this run is
`reports/key_fix.md` at HEAD `236f629` (`node_d2fdb79acfbec37dfb74066b`). This iteration adds
`reports/unit_matrix.md` to the five stage reports already written by this run
(`scope.md`, `invariants.md`, `callsites.md`, `reproducer.md`, `key_fix.md`).
**Status:** local, unprotected, scoped. **No engineering acceptance exists. Human reviews are
unanswered. Full native runtime tests remain pending.** Every statement below is a static reading of
this working tree at the baseline-bound candidate paths, or an explicitly-labelled logical
consequence. Nothing here is compiled, executed, reviewed, published, accepted, or a full native run.

> **Tool / write boundary observed.** This iteration used only `read_file`, `grep`, `glob`, and
> `write_file`. No `shell`, no `edit_file`, no delegation, no web access, no approval, no publishing,
> and no engineering acceptance was performed. The task permits changing only the six named candidate
> source paths and this report. Of those, **this iteration wrote exactly one file — this report.** No
> source, build, test, config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was created, edited, or
> deleted, and every prior report was preserved (section 7).
>
> **Premise reconciliation (inspect before editing).** The task records "a measured GCC syntax
> failure: an extra closing brace in `score/socom/impl/service_identifier.hpp` at line 39" and directs
> that the actual source be corrected before the tests are expanded. Direct inspection of the actual
> working tree this iteration (direct `read_file` + `grep`, section 2) shows the header is **already
> brace-balanced**: the only brace-bearing lines are `:19` (`namespace score::socom {`), `:29`
> (`struct Service_instance_identifier final {`), `:32` (`};`) and `:38`
> (the single `}  // namespace score::socom`); line `:39` is **blank**. Two openers and two closers
> give a net brace balance of `0`; there is no third, unmatched closing brace. The described defect is
> therefore the **stale pre-correction description** that survives only in the earliest prior reports,
> not the file that is compiled. Re-introducing a broken brace so it could be "fixed" would be a
> regression, so the honest bounded action was to re-verify the actual source and then examine the
> requested test expansion, which is the real work of this iteration (section 4).
>
> **The requested key-matrix expansion is already present on disk.** The five requested dimensions
> (service IDs, instance IDs, major versions, minor boundaries, equality/ordering consistency) are
> already exercised by **83 `TEST_F`** cases in
> `score/socom/test/unit/service_identifier_tests.cpp`, including the ten-case seventh expansion
> recorded in `.llm_tmp/overnight/prior-reports/unit_matrix.md` (cases at `:1625`…`:1872`). This
> iteration verified and mapped that coverage rather than appending duplicates: duplicating an
> existing deterministic matrix adds no coverage, and no compiler was available to validate new
> appended code (section 4, section 5).

---

## 0. Summary

1. **Recorded syntax failure — inspected; not present.** `score/socom/impl/service_identifier.hpp` is
   40 lines with exactly four brace-bearing lines (`:19`, `:29`, `:32`, `:38`) and a blank `:39`.
   Net brace balance is `0`; no source edit was applied because none is required (section 2).
2. **Key semantics re-verified.** The duplicate-server key's only operator,
   `Service_instance_identifier::operator<`, orders by `(instance, service id, major)`, so the
   **minor version is excluded** from the identity
   (`score/socom/impl/service_identifier.cpp:28-29`), matching the deliberately minor-ignoring
   `Service_database` index (`score/socom/impl/runtime_impl.hpp:116-134`). The public
   `Service_interface_identifier`/`Version` representation, its `operator==`, `operator<` and
   `std::hash` remain untouched (section 3).
3. **Key matrix present and mapped.** `service_identifier_tests.cpp` carries **83 `TEST_F`** cases
   under `ServiceInstanceIdentifierTest` (`:168`…`:1851`); `runtime_tests.cpp` carries **31 `TEST_F` +
   1 `TEST` + 1 `TEST_P`**, including the runtime minor-only duplicate regression
   `ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError` (`:402-431`). Section 4
   maps the 83 key cases to the five requested dimensions and records that no new case was appended
   because the requested expansion already exists.
4. **Nothing was compiled or executed.** Every expected result is derived from the source ordering and
   from `std::set`/strict-weak-ordering semantics, not observed. `.llm_tmp/overnight/validation/` and
   `.llm_tmp/overnight/obligations/*/result.json` are **absent from this checkout**.
   **No obligation is treated as satisfied** (sections 5 and 6).

---

## 1. Binding to the verified baseline, prior reports, host feedback, obligations

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` | `.llm_tmp/context/issue-snapshot.json:2-4` |
| Title | *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:3` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` (unchanged) | `.llm_tmp/context/issue-snapshot.json:19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**: service-instance identifier = `service id + major + minor + instance id`; service
identifier = `service id + major`; FindService = `service id + major + optional<minor> +
optional<instance>`; and the proposal to "exclude the minor version and make it a property of the
service instance". The FindService `major = FF` AUTOSAR case is called theoretically possible but not
useful. There is **no comment and no acceptance record** in the snapshot, so none of it is binding.

### 1.2 Verified baseline

| Item | Value | Source |
|------|-------|--------|
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |
| Current branch | `fabro/run/01M3YRJEGXNY6CB81T7TKW774B` | environment |
| Completed nodes | `node_3752dc1af9e2f3b0ee1454f2`, `node_51f7ccb6b2715b106cf242f4`, `node_c732605366498064fa626567`, `node_d2fdb79acfbec37dfb74066b`, `node_edd8fcbae2fee64d3bbd0c31` | task context / `reports/*.md` |

Binding is **by baseline commit**, not by run HEAD. Earlier reports reference other run IDs on the same
baseline commit (`01M3YGTGYFEN406VDEVVTJTRWV`, `01M3XZAQ65TTE35XSGXC4JAMAH`,
`01M3XT7NQ04S4MTFRMTT2401XK`, `01M3WX09X84XFM5X08QY2944DF`, and before them
`01M3WSTF1DAJA248NQ5QQGQG52`/`a282596` and `01M3WWRQWT262FTYS52X80YPTP`/`e12e7cb`), so all of them
describe the same baseline and remain admissible prior evidence for this slice.

### 1.3 In-scope candidate files (the only writable source paths)

From `.llm_tmp/context/candidate-files.json:1-25` (baseline blobs cross-checked against the `files`
array of `.llm_tmp/context/source-manifest.json`):

| File (repo-relative) | Baseline git blob | Baseline present | This iteration |
|----------------------|-------------------|------------------|----------------|
| `score/socom/BUILD` | `3477ea0851fdcd82ec6ea9d71424013cbdf41962` | yes | inspected, **unchanged** — test-only `impl_service_identifier` exposure present (`:43-54`) |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e22355242009fe20dada2a9a0d0c7a9c7` | yes | inspected, **unchanged** — `minor` already excluded (`:28-29`) |
| `score/socom/impl/service_identifier.hpp` | `c8bae7908da9f087c518934f7b9f8d86db9a20ec` | yes | inspected, **unchanged** — already brace-balanced (`:39` blank, section 2) |
| `score/socom/test/unit/BUILD` | `3c03a7b14286051f97fa5022206564bd63645171` | yes | inspected, **unchanged** — `socom_test` globs `*.cpp`, deps wired (`:16-29`) |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab726db8bf994c960045d6fd7fdf84d7395` | yes | inspected, **unchanged** — minor-only runtime regression present (`:402-431`) |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(none — `null`)* | no (manifest expects a **new** file) | inspected, **unchanged** — 83-case matrix already present |

The `null` baseline blob for `service_identifier_tests.cpp` is the manifest's expectation of a **new**
unit-test file; it exists on disk only as part of the un-merged working tree (the "cancelled draft"),
never in the baseline.

### 1.4 Prior reports read and preserved

- `.llm_tmp/overnight/prior-reports/` — **12 files present**, all read and preserved: `scope.md`,
  `invariants.md`, `callsites.md`, `reproducer.md`, `key_fix.md`, `unit_matrix.md`, `ordering_tests.md`,
  `conversion_tests.md`, `runtime_disabled.md`, `runtime_enabled.md`, `lifetime_tests.md`,
  `test_metadata.md`. Other reports cite `repair_unit_matrix.md`, `coverage_tests_repair.md`,
  `tool_findings_repair.md`, and a host addendum `obligation-addendum.md`; **none of those is present
  in this checkout** (glob returns no entries), so their content is available only as quoted by the
  other reports.
- `.llm_tmp/overnight/reports/` — **5 files present** from this run, read and not modified: `scope.md`,
  `invariants.md`, `callsites.md`, `reproducer.md`, `key_fix.md`. This document adds `unit_matrix.md`.
- The earlier `.llm_tmp/overnight/prior-reports/unit_matrix.md` (the "seventh expansion") was **not**
  overwritten; it is the record that the 73 → 83 expansion was previously applied on this baseline.

Derived sequence across the preserved reports: `scope.md` (bounded the slice) → `invariants.md`
(I-4 baseline key included `minor`; I-9 record index ignores `minor`; I-11 the resulting gap) →
`callsites.md` (call-site map) → `reproducer.md` (header brace correction + focused red regression) →
`key_fix.md`/`unit_matrix.md` (drop `minor`; expand the key tests) → `ordering_tests.md` →
runtime/lifetime reports → `conversion_tests.md` → `test_metadata.md` → `repair_unit_matrix.md`.

### 1.5 Host validation feedback and obligation-collection results

- **Host feedback under `.llm_tmp/overnight/validation/`: absent from this checkout.** A `glob` over
  `.llm_tmp/overnight/**` and `**/validation/**` returns no entries; there is no host feedback to
  reconcile against.
- **Obligation-collection results under `.llm_tmp/overnight/obligations/`: absent from this
  checkout.** A repo-wide `glob **/result.json` returns no entries; no `*/result.json` exists. Earlier
  reports retain summaries of host artifacts (check-result `0`; `measurement.json`
  `origin: local_unprotected_measurement`, `mode: ubsan`, `engineering_acceptance: pending`,
  `full_native_tests: not_executed`; focused GCC compile/tests exit `0`; focused coverage
  `service_identifier.cpp` 100 % line / 50 % branch; asan/lsan/memcheck 46/46; tsan environment
  failure; clang-tidy configuration blocker; `native_*`/`cross_compilation` failing to fetch
  toolchains with `No space left on device`). **Per the task rule, a successful collection node means
  results were retained, not that checks passed; here nothing is retained at all, so no obligation may
  be treated as satisfied on that basis.**
- Those retained summaries are also **scoped and stale**: they compiled only the focused identifier
  translation unit (`service_identifier.cpp` + `string_registry.cpp` + `service_identifier_tests.cpp`)
  with `g++-12 -std=c++17 -Wall -Wextra -Werror`; they did **not** compile `runtime_tests.cpp` or the
  full `socom_test` / `//score/...` targets, and their recorded
  `service_identifier_tests.cpp` hash predates the later expansions (the current file has **83**
  `TEST_F`, not the 46-case state that capture compiled).

### 1.6 Host addendum (task context, not acceptance)

The host addendum (present only as quoted by prior reports) states it "is task context, not engineering
acceptance or an approved tailoring decision". It asks the review to cover the `verification_process`
test types and derivation techniques; to keep unknown applicability and unexecuted applicable checks
explicit; to **not** label identifier-only tests as full platform validation and **not** to claim a
fuzzy technique without a measurement; to permit concrete boundary/equivalence regression cases within
the six source paths; and to record that there is **no authority to invent native links, select a
safety classification, accept risk/deviations, or answer the independent human gate.** This report
honours that in sections 4.4 and 6.

---

## 2. The recorded syntax failure: inspection of the actual source

### 2.1 Finding (direct `read_file` + `grep` this iteration)

`score/socom/impl/service_identifier.hpp` is **brace-balanced**. It is 40 lines:

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

A `grep` for a brace character on the file returns exactly four matches: `:19`, `:29`, `:32`, `:38`.
Two openers and two closers give a net brace balance of `0`; `:39` contains no text at all. A `glob`
for `**/service_identifier*` returns exactly the header, its `.cpp` sibling, and the unit test file, so
there is no second, differently-braced copy in the tree. The task's "extra closing brace … at line 39"
therefore matches the **stale, pre-correction** description of the earliest prior reports (which quote
lines 38-39 as the split-form `}  // namespace socom` + `}  // namespace score`), not this snapshot.
The `reproducer` node of a preceding run applied the correction; every later report and the actual
source read here show the header as balanced.

### 2.2 Repository convention (evidence)

The tree uses two internally-consistent styles:

- **Nested open + single close:** `namespace score::socom {` … one `}  // namespace score::socom`.
  This is the sibling `impl/service_identifier.cpp` (`:18` / `:32`), the public
  `service_interface_identifier.hpp` (`:25` / `:164`), and `registry_string_view.hpp`.
- **Split open + double close:** `namespace score {` + `namespace socom {` … `}  // namespace socom` +
  `}  // namespace score`. This is `impl/runtime_impl.hpp` (`:32-33` / `:232-233`).

`impl/service_identifier.hpp` follows the **nested** form consistently and is balanced.

### 2.3 Why no source correction was applied

The minimal repair — matching the sibling `.cpp` — would be, **only if the imbalance reappeared**:

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

Applying it to the already-balanced file would be a no-op at best and a regression at worst; removing
or adding a brace merely to imitate a correction would break a header that compiles. No production
source was edited. The only candidate path considered for the requested expansion is the test file
(section 4).

### 2.4 Why the brace matters

The header is compiled into `//score/socom:socom` (its `srcs` globs `impl/**/*.cpp` and
`impl/**/*.hpp`, `score/socom/BUILD:24-41`) and re-exposed to `//score/socom/test/unit` via the
`testonly` `impl_service_identifier` library (`score/socom/BUILD:46-54`;
`score/socom/test/unit/BUILD:24`). A syntax error here would fail both the library and the whole
`socom_test` target, contradicting S-CORE quality criterion 9, "Freedom from compiler warnings &
errors, 100 %" (`verification_plan.rst:332-335`). The currently balanced state removes that blocker at
the source level; it is **not** a compile measurement (section 5).

---

## 3. Key semantics under test (as implemented)

The duplicate-server key is
`Service_instance_identifier { Service_interface_identifier interface; Service_instance instance; }`
(`score/socom/impl/service_identifier.hpp:29-32`). The only operator is the out-of-line `operator<`
(`:35`), defined as (`score/socom/impl/service_identifier.cpp:28-29`):

```cpp
return std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major) <
       std::tie(rhs.instance, rhs.interface.id, rhs.interface.version.major);
```

Therefore:

- identity (set equivalence) = **`(instance, service id, major)`**;
- **`minor` is ignored** — it is a compatibility selector enforced separately by
  `is_interface_compatible` (`runtime_impl.cpp:138-146`; `is_minor_version_compatible` at `:133-136`),
  not an identity component;
- `std::set` uniqueness (`!(a<b) && !(b<a)`) follows the same equivalence, so two keys that share
  `instance + id + major` (and differ only in minor) are duplicates.

The record index deliberately uses the same coarse identity (`Minor_version_ignoring_hash` /
`Minor_version_ignoring_key_equal`, `runtime_impl.hpp:116-134`), so the key gate covers every collision
the record index can produce. The duplicate is rejected in `Runtime_impl::make_server_connector`
(`runtime_impl.cpp:443`, insert/return `duplicate_service` at `:449-454`), before the single-server
precondition (`SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)`) in
`Service_record::register_server_connector` can be reached.

`Service_instance_identifier` declares **no `operator==` and no `std::hash`**. "Equality" in the tests
is therefore *set equivalence* — neither key orders before the other — which is the only identity
notion the type exposes. `Service_instance` and `Service_interface_identifier` do have content-based
`operator<` and `operator==` (`service_interface_identifier.hpp:61-71`, `:130-162`), which the tuple
ordering delegates to, and the full-version `std::hash` (`:170-190`) remains distinguishing.

---

## 4. Test matrix and coverage by requested dimension

File: `score/socom/test/unit/service_identifier_tests.cpp` (Apache-2.0 header present). Shared fixture
helpers:

- `make_identifier(service_id, major, minor, instance_id)` (`:92-100`) — builds one key through the
  public constructors (registry-deduplicated string ids);
- `identity_of(key)` (`:86-90`) — the `(instance, service id, major)` identity tuple `Identity`;
- `equivalent(lhs, rhs)` (`:104-107`) — `!(lhs < rhs) && !(rhs < lhs)`, i.e. the `std::set`
  equivalence;
- boundary constants `major_min = 0`, `major_max = 65535`, `minor_min = 0`, `minor_max = 65535`
  (`:77-80`);
- sort extremes `service_id_first = "AAA_first"`, `service_id_last = "ZZZ_last"`,
  `instance_id_first = "AAA_instance"`, `instance_id_last = "ZZZ_instance"` (`:69-75`);
- `registration_key_domain()` (36 keys, `:115-128`) and `registration_key_boundary_domain()`
  (64 keys, `:139-154`).

The suite contains **83 `TEST_F`** cases under `ServiceInstanceIdentifierTest` (`:168`…`:1851`,
counted this iteration by `grep`). The ten cases at `:1625`…`:1872` are the seventh-expansion block
already recorded in `.llm_tmp/overnight/prior-reports/unit_matrix.md`; this iteration **verified and
mapped** them rather than appending duplicates.

### 4.1 Coverage of the five requested dimensions

| Requested dimension | Representative existing cases (line) |
|---------------------|--------------------------------------|
| **Service IDs** | `KeysDifferingInServiceIdAreDistinct` (`:262`), `DistinctServiceIdsProduceDistinctKeys` (`:270`), `EqualServiceIdTextProducesEquivalentKeys` (`:281`), `ServiceIdOrderingIsLexicographic` (`:296`), `EmptyServiceIdIsDistinctAndOrdersFirst` (`:927`), `ServiceIdPrefixOrderingIsLexicographic` (`:970`), `ServiceIdLadderOrdersLexicographicallyAndDistinctly` (`:1218`), `ServiceIdOrderingIsLexicographicNotNumeric` (`:1625`) |
| **Instance IDs** | `InstanceIsThePrimaryOrderingComponent` (`:496`), `KeysDifferingInInstanceAreDistinct` (`:310`), `DistinctInstancesProduceDistinctKeys` (`:318`), `EqualInstanceTextProducesEquivalentKeys` (`:329`), `InstanceOrderingIsLexicographic` (`:342`), `EmptyInstanceIdIsDistinctAndOrdersFirst` (`:943`), `InstanceIdPrefixOrderingIsLexicographic` (`:985`), `InstanceIdLadderOrdersLexicographicallyAndDistinctly` (`:1241`), `InstanceIdOrderingIsLexicographicNotNumeric` (`:1641`) |
| **Major versions** | `KeysDifferingInMajorVersionAreDistinct` (`:217`), `MajorVersionBoundariesAreDistinct` (`:225`), `MajorVersionSweepProducesDistinctKeys` (`:235`), `AdjacentMajorVersionBoundariesAreDistinct` (`:246`), `MajorDifferenceOutweighsMinorDifference` (`:486`), `MajorIsTheTertiaryOrderingComponent` (`:506`), `MajorHighBitAdjacencyIsOrdered` (`:998`), `MajorVersionLadderOrdersNumericallyAndDistinctly` (`:1264`), `MajorVersionByteBoundariesAreDistinctAndOrdered` (`:1656`), `MajorVersionOrderMatchesUnsignedNumericOrder` (`:1680`) |
| **Minor boundaries** | `SameIdentifierIsNotLessThanItself` (`:168`), `KeysDifferingOnlyInMinorVersionAreDuplicates` (`:174`), `MinorVersionBoundariesAreDuplicates` (`:182`), `AllMinorVersionsCollapseToSingleKey` (`:192`), `MinorHighBitVariantsAreEquivalent` (`:203`), `MinorVersionNeverAffectsOrdering` (`:430`), `SetFindLocatesMinorVariantAndCountsItOnce` (`:1034`), `MinorVariantsCompareIdenticallyAgainstWholeDomain` (`:1292`), `StdSetCollapsesFiveMinorVariantsOfEveryIdentity` (`:1321`), `MinorVariantsBoundDistinctIdentitiesWithoutBreakingOrder` (`:1702`), `MinorSweepCollapsesPerIdentityAtEveryMajorBoundary` (`:1728`), `KeyIdentityIsStableUnderRepeatedMinorRewritesOfTheSameIdentity` (`:1851`) |
| **Equality/ordering consistency** | `KeyEquivalenceDependsOnInstanceServiceIdAndMajor` (`:420`), `OrderingOrderIsInstanceThenServiceIdThenMajor` (`:441`), `OrderingIsTransitive` (`:460`), `EquivalenceIsTransitive` (`:473`), `DistinctKeysAreOrderedInExactlyOneDirection` (`:516`), `StrictWeakOrderingHoldsAcrossMinorVariants` (`:537`), `SortingAgreesWithIndependentTupleOrder` (`:563`), `SetUniquenessMatchesDistinctIdentityTupleCount` (`:588`), `SetIterationFollowsInstanceThenServiceIdThenMajor` (`:609`), `PropertyStrictWeakOrderingAxiomsHoldOnDeterministicDomain` (`:634`), `PropertyEquivalenceMatchesIdentityTupleOnDeterministicDomain` (`:662`), `PropertyOrderingIsDeterministicTotalAndTupleConsistent` (`:687`), `PropertyEquivalenceClassesMatchDistinctIdentityTupleCount` (`:712`), `PropertySetUniquenessIsIndependentOfInsertionOrder` (`:735`), `PropertySortedDomainMatchesSortedIdentityTuples` (`:1055`), `PropertyStrictWeakOrderingAxiomsOnVersionBoundaryDomain` (`:1087`), `PropertyIdentityEqualityClassesOnVersionBoundaryDomain` (`:1115`), `EquivalenceIsCompatibleWithStrictOrder` (`:1343`), `OrderingAgreesWithTupleOrderOnMixedBoundaryDomain` (`:1363`), `SingleComponentChangesBreakEquivalenceAcrossAllBases` (`:1407`), `PropertyStrictWeakOrderingOnCombinedRegistrationKeyDomain` (`:1456`), `PropertyIdentifierEqualityOnCombinedRegistrationKeyDomain` (`:1488`), `SetInsertionResultMatchesEquivalenceAcrossMinorVariants` (`:1754`), `EquivalenceCoincidesWithIdentityOverFixtureCrossProduct` (`:1777`), `OrderingIsAntiSymmetricOverFixtureCrossProduct` (`:1818`) |

A further set of cases pins the public-identifier → internal-key conversion at version boundaries
(`:784`, `:813`, `:833`, `:847`, `:861`, `:884`, `:911`, `:1149`, `:1187`, `:1531`, `:1564`, `:1590`),
including the config `uint8`/`uint32` → socom `uint16` narrowing and the `0xFFFFFFFF` wildcard that
narrows to `0xFFFF`. Those open #84 questions (public type shape, FindService wildcard, config
minor-wildcard semantics) are **not** decided here.

### 4.2 Boundary values exercised

- major `0`, `1`, `2`, `9`, `0x7F`, `0x80`, `0xFF`, `0x100`, `0x7FFF`, `0x8000`, `0xFFFE`, `65535`;
- minor `0`, `1`, `2`, `3`, `0x7FFF`, `0x8000`, `0xFFFE`, `65535`;
- string ids: empty, strict prefixes, sort extremes `AAA_*`/`ZZZ_*`, numeric-suffix ladders
  (`"S1" < "S10" < "S2"`, `"I1" < "I10" < "I2"`).

### 4.3 Determinism

Every case is a pure function of compile-time constants: each domain is a fixed cartesian product
enumerated in a fixed order (no randomness, no time dependence, no allocation beyond `std::vector` /
`std::set`). The expected sizes (36, 64, 48, 72, 144, `majors.size() * minors.size()`) are exact for
the listed products.

### 4.4 Coverage honesty versus the host addendum

- **Derivation techniques:** the cases are **boundary** and **equivalence-class** derivations expressed
  as deterministic unit checks, extended by explicit strict-weak-ordering algebraic properties. **No
  fuzzy modelling was executed**, and no error-guessing or fault-injection harness exists in this
  workspace.
- **Test types:** these are **internal module/unit-level** checks only. They are **not** interface,
  requirements-based, resource, or full feature/platform reference-hardware tests and must not be
  presented as such.
- **Not run:** the suite was not executed by this iteration (section 5). `TestType` and the
  `Verifies`/`PartiallyVerifies`/`FullyVerifies` links remain deliberately unset because no verified
  native requirement/interface identifier exists for this slice and inventing one is prohibited.

---

## 5. Measurement and validation status

- **Tools:** `read_file`, `grep`, `glob`, `write_file` only. No `shell`, delegation, web access,
  approval, publishing, or engineering acceptance.
- **Executed measurements:** **none.** No build, no `bazel test`, no runtime. Every expected result in
  section 4 is derived from the source ordering and from `std::set`/strict-weak-ordering semantics, not
  observed. Section 2 is a static reading of the working tree.
- **Test inventory (read, not run):** `service_identifier_tests.cpp` has **83 `TEST_F`** under
  `ServiceInstanceIdentifierTest` (`:168`…`:1851`); `runtime_tests.cpp` has **31 `TEST_F`** plus
  `TEST(RuntimeFactoryTest, DefaultConstructorWorks)` (`:239`) and
  `TEST_P(RuntimeBridgeTest, CreationOfClientsWillCallRequestServiceFunction)` (`:1311`). All counts
  were verified this iteration by `grep`.
- **Code-level self-check (static, not a compile):** the existing suite uses only the standard headers
  it includes (`<algorithm>`, `<cstddef>`, `<cstdint>`, `<functional>`, `<limits>`, `<set>`, `<string>`,
  `<string_view>`, `<tuple>`, `<vector>`), the fixture helpers above, and fixed-width `std::uint16_t`
  literals; the file is brace-balanced and closes its namespace at `:1874`. This is a reading, not a
  measurement.
- **Scope:** local, unprotected, scoped. The key-identity matrix describes the current implementation;
  it does not by itself constitute acceptance of the `minor`-excluding decision.
- **Reproduction path for a later, permitted run (not executed here):**

  ```bash
  bazel test //score/socom/test/unit:socom_test
  # focused key-level:
  bazel test //score/socom/test/unit:socom_test --test_filter='ServiceInstanceIdentifierTest.*'
  # focused runtime regression:
  bazel test //score/socom/test/unit:socom_test \
      --test_filter='RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError'
  ```

  Expected on the current key: the minor-only key tests collapse to one set element, the ordering
  consistency checks hold, and the runtime regression returns `Construction_error::duplicate_service`.
  On a key that includes `minor`, the minor-collapse cases and the runtime regression would fail. These
  expectations are source-derived, not measured.

---

## 6. Obligations status (none satisfied)

### 6.1 Pinned state from `authority.json`

| Field | Value |
|-------|-------|
| `codeql_scope` | Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload |
| `engineering_acceptance` | **pending** |
| `human_reviews` | **unanswered** |
| `safety_class` | **unknown** |
| `instruction` | "Restart the failed queue for one complete pass through all obligations" |

All nine pinned sources in `.llm_tmp/context/obligations/` were consulted (`coding_guidelines.rst`,
`code_analysis.rst`, `misra_mapping.rst` — `:status: draft`, `verification_plan.rst`,
`development_plan.rst`, `tool_management.rst`, `verification_process.rst`,
`verification_guideline.rst`, `inspection_checklist.rst` — `:status: draft`); every
`source-index.json` entry is `"native_acceptance": "not_inferred"`.

### 6.2 Obligation status for this slice (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Freedom from compiler warnings & errors (100 %) | `verification_plan.rst` quality criterion 9; `coding_guidelines.rst` | **NOT MEASURED** — no compile was run; the brace blocker is absent in source (section 2) |
| Static code analysis (clang-tidy / CodeQL), findings classified | `code_analysis.rst`; `verification_process.rst` (SCA classification) | **NOT PERFORMED** — no tool, no build |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` (`:status: draft`) | **UNKNOWN** — mapping document is draft; not applied |
| Structural statement / branch coverage goals | `verification_plan.rst` quality criteria 1-2; `code_analysis.rst` | **NOT MEASURED** — no test execution; the retained host capture is below platform goals and is stale |
| Unit/component testing executed, results recorded | `verification_plan.rst` criteria 6-7; `verification_guideline.rst` | **NOT EXECUTED** — 0 tests run; the retained host run covers 46 stale cases, not this 83-case file |
| Interface / requirements-based / resource test types | `verification_process.rst:38-42`; `verification_plan.rst` | **NOT PERFORMED / applicability not inferred** — no harness; identifier-only tests must not be labelled platform validation |
| Fault-injection and fuzzy techniques | `verification_process.rst:39,48`; `verification_plan.rst` | **NOT EXECUTED** — no harness; no measurement; no technique claimed |
| Boundary / equivalence derivation | `verification_process.rst:46-47` | **SOURCE-ONLY** — cases exist and were mapped (section 4) but were not executed |
| Linking tests to requirements (record properties) | `verification_process.rst` (`gd_req__verification_link_tests_cpp`) | **PARTIAL / NOT DONE** — `DerivationTechnique`/`Description` recorded in `SetUp()` (`service_identifier_tests.cpp:42-65`); `TestType`/`Verifies` cannot be set without inventing identifiers |
| Independence of verification / review by a different committer | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Implementation inspection checklist IMPL_01…IMPL_03 | `inspection_checklist.rst` (`:status: draft`) | **NOT FILLED** — draft template, no inspection |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** — no tool run |
| Obligation collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **ABSENT** — no result files exist in this checkout |
| Native acceptance | `source-index.json` | **not_inferred** for every entry |

**Explicit non-satisfaction statement.** Missing tools (no build/test), the unknown safety class and
un-inferred applicability, the incomplete extraction of host artifacts, the absent
obligation-collection results, and the unanswered human reviews mean **none of the checked obligations
may be treated as satisfied**. A collection node that retained results would only show *retention*, not
passing; here there are no retained results at all. The absence of
`.llm_tmp/overnight/validation/` and `.llm_tmp/overnight/obligations/*/result.json` is **not** evidence
that the corresponding checks passed.

---

## 7. Notice preservation

- `score/socom/test/unit/service_identifier_tests.cpp` retains its Apache-2.0 header; all 83 cases and
  the `SetUp()` record properties are reproduced unchanged. No candidate source path was modified this
  iteration.
- No `NOTICE`, `LICENSE`, or `REUSE.toml` file was created, edited, or deleted.
- All 12 prior reports under `.llm_tmp/overnight/prior-reports/` and the five pre-existing
  `.llm_tmp/overnight/reports/*` (this run's earlier nodes) were preserved; this iteration only added
  `.llm_tmp/overnight/reports/unit_matrix.md`. The earlier `prior-reports/unit_matrix.md` was **not**
  overwritten.
- The key stays an `impl/`-only type; the `testonly` `//score:socom:impl_service_identifier` library
  exposes it to `//score/socom/test/unit` only, so no public header or notice surface changed.

---

## 8. Pending human review checklist

- [ ] Confirm the actual-source inspection in section 2: the header is already brace-balanced (single
      nested close `}  // namespace score::socom`; line 39 blank), so no source correction was needed;
      a repeat of the pre-correction state should be re-checked before any compile.
- [ ] Confirm the intended key semantics: `minor` is **not** part of the duplicate-server registration
      key; identity is `(instance, service id, major)`, consistent with the `Service_database` index and
      issue #84.
- [ ] Confirm the 83-test matrix and its mapping to the five requested dimensions (section 4) is the
      right coverage, and that the equivalence definition (`!(a<b) && !(b<a)`, since the type has no
      `operator==`) is acceptable. The seventh-expansion cases at `:1625`…`:1872` were verified as
      already present rather than duplicated.
- [ ] Confirm `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)` remains the authoritative single-server
      invariant, so the key must be at least as coarse as the record index.
- [ ] Keep the #84 public `Service_interface_identifier` restructure, FindService wildcard handling,
      and config minor-wildcard narrowing out of this bounded slice until separately accepted.
- [ ] Run `bazel test //score/socom/test/unit:socom_test` (and the broader `//score/...` set), including
      `runtime_tests.cpp`, on the native host to turn the source-derived expectations into measurements,
      and record results; schedule independent human review (the approver must differ from the author,
      per `gd_req__verification_independence`).
- [ ] Supply the missing obligation results (`.llm_tmp/overnight/obligations/*/result.json`) and host
      validation feedback (`.llm_tmp/overnight/validation/`), and resolve the
      `engineering_acceptance: pending` / `human_reviews: unanswered` state; do not infer passing from
      absence or from prior reports' retained summaries.
