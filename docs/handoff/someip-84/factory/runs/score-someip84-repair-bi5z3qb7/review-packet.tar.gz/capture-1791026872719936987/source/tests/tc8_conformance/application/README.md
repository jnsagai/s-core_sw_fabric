<!-- ----------------------------------------------------------------------------
  Copyright (c) 2026 Contributors to the Eclipse Foundation

  See the NOTICE file(s) distributed with this work for additional
  information regarding copyright ownership.

  This program and the accompanying materials are made available under the
  terms of the Apache License Version 2.0 which is available at
  https://www.apache.org/licenses/LICENSE-2.0

  SPDX-License-Identifier: Apache-2.0
----------------------------------------------------------------------------- -->

# TC8 Conformance: Application Components

C++ applications used by the TC8 conformance test suite.

## Structure

```
application/
├── shared/          # Shared header: tc8_ets_service constants and event descriptors
└── ets_stub/        # ETS stub binary: offers tc8_service via mw::com skeleton,
                     #   sends periodic event notifications for TC8 test capture
    └── config/      # mw::com manifest (tc8_ets_stub_mw_com_config.json)
```

## See Also

- [Architecture](../../../docs/architecture/tc8_conformance_testing.rst)
- Protocol conformance tests in the parent directory [`tests/tc8_conformance/`](../)
