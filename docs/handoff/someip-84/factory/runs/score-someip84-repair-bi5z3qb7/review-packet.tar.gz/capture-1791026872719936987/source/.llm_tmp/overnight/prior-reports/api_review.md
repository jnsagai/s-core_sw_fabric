<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — ABI / API review of the bounded duplicate-server registration-key slice

**Document type:** review draft (actual-source ABI/API inspection + minor-version representation
review + preserved public-identifier design questions + obligations status)
**Date:** 2026-10-02
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version handling in
socom* (issue #84)
**Run:** branch `fabro/run/01M3YRJEGXNY6CB81T7TKW774B`, latest run commit
`8178879` (`fabro(01M3YRJEGXNY6CB81T7TKW774B): node_c98fbf153206ff550918a772 (success)`) per the
environment.
**Status:** local, unprotected, scoped. **No engineering acceptance exists. Human reviews are
unanswered. Full native runtime tests remain pending.** Every statement below is either a direct
static reading of this checkout at the baseline-bound candidate paths, or an explicitly-labelled
logical consequence, or a record of an artifact present under `.llm_tmp/overnight/`. Nothing here is
published, reviewed, accepted, or a full native run.

> **Tool / write boundary actually observed.** Only `read_file`, `grep`, `glob`, and `write_file`
> were used. No `shell`, no delegation, no web access, no approval, no publishing, and no engineering
> acceptance was performed. The task's explicit final sentence — *"This is a review draft: only that
> report may be written."* — is the operative write boundary, and it resolves the task's other
> direction ("Inspect and correct the actual source before expanding tests") in favour of **inspection
> only**. Accordingly **exactly one file was written: this report**
> (`/workspace/.llm_tmp/overnight/reports/api_review.md`). No source, build, test, config, `NOTICE`,
> `LICENSE`, `REUSE.toml`, or prior-report file was created, edited, or deleted.
>
> **The recorded GCC syntax failure is not present in the actual source (re-verified this
> iteration).** The task records *"a measured GCC syntax failure: an extra closing brace in
> `score/socom/impl/service_identifier.hpp` at line 39."* Direct `read_file` + `grep` on the current
> working tree (§2) show the header is **brace-balanced**: openers at `:19`
> (`namespace score::socom {`) and `:29` (`struct Service_instance_identifier final {`); closers at
> `:32` (`};`) and `:38` (`}  // namespace score::socom`). Line `:39` is **empty**; `:40` is
> `#endif`. Two openers, two closers, net balance `0`. There is no third, unmatched closing brace, so
> there is no actual source to correct; applying the recorded repair would be a no-op at best and a
> regression at worst. The only nonzero compiler exit retained by the obligations is a **clang**
> `-Werror` failure originating in the vendored googletest / libstdc++ 12 headers (outside the six
> candidate paths), not in the flagged header. **No source write was made and none is required.**

---

## 0. Summary

1. **The change is ABI-neutral and confined to an `impl/`-only type.** The duplicate-server key
   `Service_instance_identifier` is not part of the public header surface (`score/socom/BUILD:17-22`
   exposes only top-level `*.hpp`; the key lives at `impl/service_identifier.hpp` and is re-exported
   only through the `testonly` target `//score/socom:impl_service_identifier`,
   `score/socom/BUILD:43-54`, visible to `//score/socom/test/unit:__pkg__`). Its layout is unchanged
   (`impl/service_identifier.hpp:29-32`), its only operator keeps the same signature
   (`impl/service_identifier.hpp:35`, `impl/service_identifier.cpp:20`), and there is still no
   `operator==`/`std::hash` for it. Only the **behaviour** of `operator<` changed (minor excluded):
   identity is now `(instance, service id, major)` (`impl/service_identifier.cpp:28-29`). There is no
   public symbol/layout change, so no source-level ABI break is introduced by the bounded change.
2. **The public API surface is byte-for-byte unchanged.** `Service_interface_identifier` /
   `::Version{major: uint16, minor: uint16}` (`service_interface_identifier.hpp:73-124`, `:80-88`),
   its inline `operator==`/`operator<` (`:130-162`) and its `std::hash` (`:181-190`) are untouched and
   still **minor-aware**. `Service_interface_definition` keeps the same members
   (`service_interface_definition.hpp:42-68`). The IPC wire struct
   `gateway_ipc_binding::Service` still carries the full `Version` and remains
   `std::is_trivially_copyable_v` (`gateway_ipc_binding.hpp:80-85`, `:307`), with a minor-aware
   `operator==`/`Service_hash` (`impl/gateway_ipc_binding.cpp:32-43`). **No IPC / wire-protocol
   change.**
3. **The observable API-behaviour change is at the duplicate gate.** With the minor-excluding key, two
   `Runtime::make_server_connector` calls that share `(instance, id, major)` but differ only in
   `minor` now collide in the key set and the second returns
   `Construction_error::duplicate_service` (`impl/runtime_impl.cpp:449-453`), instead of both being
   constructed and the second *enable* reaching the single-server assert
   (`SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)`, `impl/runtime_impl.cpp:369`). This is a
   behaviour/contract change for callers of a **public** virtual method — recorded, not yet accepted.
4. **A documentation/contract wording gap exists.** `Runtime::make_server_connector`'s doc says
   duplicates are judged by *"the configuration.interface and instance parameters"*
   (`runtime.hpp:176-178`), but `Service_interface_identifier::operator==` includes `minor`
   (`service_interface_identifier.hpp:149-152`) while the registration key does **not**. The comment
   is therefore now imprecise about the version component; the two notions of "same service"
   (public identifier equality vs registration key identity) diverge. Recorded as a review item
   (§4.3), not silently "fixed" (the write boundary permits only this report).
5. **Minor-version representation is inconsistent across layers and is the real open question.**
   Public/`socom` stores `uint16 major` + `uint16 minor`; the SOME/IP config declares
   `service_version_major: uint8` (`score/config/mw_someip_config.fbs:19`) and
   `service_version_minor: uint32 = 0xFFFFFFFF` (a wildcard, `:23`). Config→socom construction
   narrows the minor with `static_cast<std::uint16_t>(...)` at five sites
   (`score/someipd/impl/remote_network_service.cpp:42-45`,
   `score/someipd/impl/local_network_service.cpp:49`,
   `score/gatewayd/impl/local_service_instance.cpp:49`,
   `score/gatewayd/impl/remote_service_instance.cpp:92`,
   `score/gatewayd/main.cpp:229-232`), turning `0xFFFFFFFF` into `0xFFFF` with no range or wildcard
   check. The wildcard is asymmetric in the current compatibility predicate
   (`client.minor <= server.minor`, `runtime_impl.cpp:133-136`). Combined with the new
   minor-ignoring key, a wildcard-derived `0xFFFF` server and a specific-minor server for the same
   `(instance, id, major)` now **collide as duplicates**. This is a representation/semantics question
   for human review (§5).
6. **The future public identifier redesign stays a human design question (§6).** The issue #84 body is
   an unaccepted proposal (`.llm_tmp/context/issue-snapshot.json:5`): service identifier `= id + major`;
   moving `minor` onto the service instance; FindService `optional<minor>`/`optional<instance>`; the
   `major = FF` AUTOSCAN wildcard. Implementing any of it would change the public type, the
   compatibility semantics, and the IPC wire layout, i.e. a designed, versioned API/ABI change — out
   of this bounded slice and deferred to human disposition. `authority.json` records
   `engineering_acceptance: pending`, `human_reviews: unanswered`, `safety_class: unknown`.
7. **No obligation is satisfied.** The host artifacts are now present under
   `.llm_tmp/overnight/validation/` and `.llm_tmp/overnight/obligations/`, but per the task rule a
   successful collection node means results were *retained*, not that checks *passed*. Many retained
   checks failed or are blocked (native `bazel` obligations exit `127`; clang blocked on a dependency;
   tsan `-11`/`66`; valgrind/gitleaks unavailable; clang-tidy config blocker), applicability is
   `not_inferred` for every pinned source, and human reviews are unanswered. The only executed
   measurements cover a **focused identifier translation unit** (85 cases in the retained capture)
   and are **stale** against the 87-case working tree; no Bazel/native build or runtime suite ran.

---

## 1. Binding to the baseline, prior reports, host feedback, and pinned obligations

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` | `.llm_tmp/context/issue-snapshot.json:2-4` |
| Title | *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:3` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` (unchanged) | `.llm_tmp/context/issue-snapshot.json:19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**. It distinguishes three identity use cases — service-instance identifier
`= service id + major + minor + instance id`; service identifier `= service id + major`; FindService
`= service id + major + optional<minor> + optional<instance>` — proposes to "exclude the minor version
and make it a property of the service instance", and calls the FindService `major = FF` AUTOSAR case
theoretically possible but not useful. There is **no comment and no acceptance record**, so none of it
is binding.

### 1.2 Verified baseline and candidate set

| Item | Value | Source |
|------|-------|--------|
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |
| Branch | `fabro/run/01M3YRJEGXNY6CB81T7TKW774B` | environment |
| Latest run commit | `8178879` — `fabro(…): node_c98fbf153206ff550918a772 (success)` | environment |
| Candidate set | 6 paths | `.llm_tmp/context/candidate-files.json:1-25` |

The six candidate paths (the only writable source paths) are: `score/socom/BUILD`,
`score/socom/impl/service_identifier.cpp`, `score/socom/impl/service_identifier.hpp`,
`score/socom/test/unit/BUILD`, `score/socom/test/unit/runtime_tests.cpp`, and
`score/socom/test/unit/service_identifier_tests.cpp`. Binding is **by baseline commit
`f8a196c3…`**, not by run HEAD. `glob **/service_identifier.hpp` returns exactly one path
(`score/socom/impl/service_identifier.hpp`), so there is no second, differently-braced copy.

> **Content-hash caution.** The context snapshot's declared hashes differ from the host-measured
> working tree (e.g. `service_identifier.hpp` context `96b33a1f…`
> (`.llm_tmp/context/candidate-files.json:11`) vs host `bdce3fcb…`
> (`.llm_tmp/overnight/obligations/process_checks/result.json:127`); `service_identifier.cpp` host
> `3c12b3f1…` (`:126`); `runtime_tests.cpp` host `9a2d6a15…` (`:188`);
> `service_identifier_tests.cpp` host `4df2c63c…` (`:190`)). The working tree has moved relative to
> the snapshot, so the snapshot's *description* of a brace defect cannot be assumed to describe the
> current file; the **direct read of the actual file is authoritative** and shows a balanced header
> (§2). (No hashing tool is available in this task; these values are quoted from the artifacts.)

### 1.3 Prior reports read and preserved

`.llm_tmp/overnight/reports/` (all preserved; this document adds `api_review.md`): `scope.md`,
`callsites.md`, `invariants.md`, `reproducer.md`, `key_fix.md`, `unit_matrix.md`, `ordering_tests.md`,
`conversion_tests.md`, `runtime_disabled.md`, `runtime_enabled.md`, `lifetime_tests.md`,
`test_metadata.md`, `coverage_tests_repair.md`, `tool_findings_repair.md`, `compatibility.md`,
`concurrency_review.md`, `lifetime_review.md`. This iteration read `key_fix.md`, `compatibility.md`,
`concurrency_review.md`, `tool_findings_repair.md`, and `invariants.md` directly, and cross-checked the
remainder by `grep`. `.llm_tmp/overnight/prior-reports/` (12 files) was also preserved. The derived
sequence across the reports is `scope.md` → `invariants.md` (R-1…R-15; baseline key included `minor`,
I-4/I-11 gap) → `callsites.md` → `reproducer.md` (header brace correction) → `key_fix.md` /
`unit_matrix.md` (drop `minor` from the key ordering) → `ordering_tests.md` → runtime/lifetime
reports → `conversion_tests.md` → `test_metadata.md` → `compatibility.md` → `concurrency_review.md` →
`tool_findings_repair.md` → `lifetime_review.md`.

### 1.4 Latest host feedback and obligation-collection results (present this iteration)

Host feedback under `.llm_tmp/overnight/validation/` is **present**:

- `check-result` = `0`.
- `measurement.json` (`:2039-2058`): `origin: local_unprotected_measurement`,
  `initiator: Fabro host hook`, `engineering_acceptance: pending`,
  `full_native_tests: not_executed`, compiler `/usr/bin/x86_64-linux-gnu-g++-12`
  (`sha256 88315fd2…`), `baseline_with_agent_tests` = **85 tests / 28 failures / compile exit 0 /
  test exit 1**, `candidate` = **85 tests / 0 failures / compile exit 0 / test exit 0**.
- `before.json` = 85 tests / 28 failures; `after.json` = 85 tests / 0 failures (all under
  `ServiceInstanceIdentifierTest`).
- `after-compile.command.json` / `before-compile.command.json`: `g++-12 -std=c++17 -Wall -Wextra
  -Werror -pthread` over `service_identifier.cpp` + `string_registry.cpp` +
  `service_identifier_tests.cpp` + googletest, exit `0`; `after-compile.stderr` is empty.
- **Scope caveat:** the measurement compiles **only the focused identifier translation unit** and
  runs the identifier tests. It does **not** compile `runtime_tests.cpp`,
  `interface_compatibility_tests.cpp`, `client_tests.cpp`, or any Bazel target. The before/after
  red→green transition is the registration-key implementation difference (`service_identifier.cpp`),
  not a syntax fix.

Obligation-collection results under `.llm_tmp/overnight/obligations/` are **present** (24 checks).
Per the task rule, retention is not passing. Statuses relevant to this slice:

| Check | Retained status |
|-------|-----------------|
| `compiler_diagnostics` | GCC focused compile+tests exit `0`; **clang exit `1`** — googletest/libstdc++ `-Wdeprecated-declarations` under `-Werror`; overall `findings_or_execution_failure` |
| `focused_asan_lsan` | exit `0` (focused identifier TU only) |
| `focused_coverage` | `score/socom/impl/` scope: 100 % line / 78.6 % branch; platform goals QM 85 / safety 100; `safety_class: unknown_requires_authorized_selection`; `complete_target_scope: false` |
| `focused_tsan` | exit `66` / `-11` (environment; identifier TU is single-threaded) |
| `focused_memcheck` | exit `127` — valgrind binary absent |
| `focused_clang_tidy` | exit `1` (config blocker) |
| `focused_cppcheck` | exit `2` — `passedByValue` findings in headers outside the candidate paths |
| `codeql_security` / `codeql_misra` | scan completed; dependency/gtest-macro findings retained; MISRA mapping is `:status: draft` |
| `native_build`, `native_tests`, `native_integration`, `native_sanitizers`, `native_tsan`, `native_lint`, `native_docs`, `native_traceability`, `native_coverage`, `native_performance`, `cross_compilation`, `format_precommit` | exit `127` — `[Errno 2] No such file or directory: '/tmp/s-core-001/bin/bazel'` |
| `secret_dependency_checks` | ran; gitleaks unavailable; lock `sha256 c90b245b…` retained |
| `process_checks` | `completed_with_blockers`; metadata inventory: `runtime_tests.cpp` 33 test macros, `service_identifier_tests.cpp` **87** test macros, each with `DerivationTechnique`/`Description` only |
| `rework_progress` | `completed`, `source_changed_this_round: true`, `rework_requested: false`, blockers `[]` |
| `tool_assurance` | valgrind / gitleaks unavailable; `perf` present |

### 1.5 Pinned obligation sources and authority

All nine entries of `.llm_tmp/context/obligations/source-index.json` are present together with
`authority.json`. Every entry is `"native_acceptance": "not_inferred"` — pinned, but applicability to
this slice is **not inferred**. `authority.json` records `engineering_acceptance: pending`,
`human_reviews: unanswered`, `safety_class: unknown`,
`codeql_scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload"`, and the instruction
"Restart the failed queue for one complete pass through all obligations." `misra_mapping` and
`inspection_checklist` are `:status: draft`.

### 1.6 Host addendum (task context, not acceptance)

The host addendum (available only as quoted by prior reports) states it "is task context, not
engineering acceptance or an approved tailoring decision." It asks the review to cover the
`verification_process` test types and derivation techniques; to keep unknown applicability and
unexecuted applicable checks explicit; to **not** label identifier-only tests as full platform
validation and **not** to claim a fuzzy technique without a measurement; and to record that there is
**no authority to invent native links, select a safety classification, accept risk/deviations, or
answer the independent human gate.** This report honours that in §5–§8.

---

## 2. Premise: the recorded GCC syntax failure (inspection of the actual source)

### 2.1 Finding (direct `read_file` + `grep`)

`score/socom/impl/service_identifier.hpp` is **brace-balanced** and 40 lines. A `grep` for `[{}]`
returns exactly four lines:

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`) and two closers (`:32`, `:38`) give net brace balance `0`. There is **no
third, unmatched closing brace**, and line `:39` contains no text. The task's "extra closing brace …
at line 39" matches a **stale, pre-correction description** consistent with the earliest prior
reports (which quote lines 38-39 as the split form `}  // namespace socom` +
`}  // namespace score`); the `reproducer` iteration applied the correction and left line 39 blank,
exactly as observed here. The sibling `.cpp` uses the same nested form
(`impl/service_identifier.cpp:18`, `:32`).

### 2.2 Measured corroboration present this iteration (retained, not acceptance)

- `.llm_tmp/overnight/validation/after-compile.command.json` (and `before-compile.command.json`)
  compile the header as a transitive include with `g++-12 -std=c++17 -Wall -Wextra -Werror -pthread`,
  exit `0`; `after-compile.stderr` is empty.
- `.llm_tmp/overnight/obligations/compiler_diagnostics/gcc-compile` exits `0` with empty stderr;
  `gcc-tests` exits `0` with 85/85 (`validation/after.json`).
- The only nonzero compiler exit is `clang-compile` exit `1`
  (`'get_temporary_buffer<testing::TestInfo *>' is deprecated [-Werror,-Wdeprecated-declarations]`
  from `bits/stl_tempbuf.h` via googletest). That is a **vendored-dependency** warning outside the six
  candidate paths.

A genuine unmatched brace would make the GCC compiles fail; they do not. This is scoped/unprotected
and is **not** a full native build.

### 2.3 Minimal historical repair (retained for reference only; not applied)

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

Applying this to the already-balanced file is a no-op at best and a regression at worst. **No source
was edited.** The write boundary permits only this report. If the "cancelled draft" is a different
revision that still carries the extra brace (cf. the §1.2 hash caution), it is not the file in this
checkout and must be located and corrected by an authorized iteration; this report records the
discrepancy for human disposition rather than speculating.

### 2.4 Why it would matter if present

The header is compiled into `//score/socom:socom` (`score/socom/BUILD:24-41`; `srcs` globs
`impl/**/*.cpp` and `impl/**/*.hpp`) and re-exposed to `//score/socom/test/unit` through the
`testonly` library `impl_service_identifier` (`score/socom/BUILD:43-54`;
`score/socom/test/unit/BUILD:24`). A syntax error there would fail the library and the whole
`socom_test` target, contradicting S-CORE quality criterion 9, "Freedom from compiler warnings &
errors, 100 %" (`verification_plan.rst`). The current balanced state removes that blocker at the
source level; that is **not** a compile measurement of the changed key (§8).

---

## 3. ABI review

### 3.1 Public vs internal surface (what ABI even means for this change)

| Surface | Location | Public? | Changed by this draft? |
|---------|----------|---------|------------------------|
| `Service_instance_identifier` (registration key) | `score/socom/impl/service_identifier.hpp:29-32` | **No** — `impl/` type, not in the public `headers` filegroup (`score/socom/BUILD:17-22`); re-exported only by `testonly` `impl_service_identifier` (`:43-54`) to `//score/socom/test/unit:__pkg__` | Definition of `operator<` only (behaviour) |
| `operator<` for the key | declaration `impl/service_identifier.hpp:35`; definition `impl/service_identifier.cpp:20-30` | **No** | Body/behaviour only; same signature |
| `Service_interface_identifier` / `::Version` | `score/socom/service_interface_identifier.hpp:73-124` | **Yes** — top-level `*.hpp` | **Unchanged** |
| `Service_interface_definition` / `Server_service_interface_definition` | `score/socom/service_interface_definition.hpp:42-106` | **Yes** | **Unchanged** |
| `Runtime` (incl. `make_server_connector`) | `score/socom/runtime.hpp:118-216` | **Yes** | Declaration unchanged; **behaviour** of the duplicate gate changes |
| `gateway_ipc_binding::Service` / message structs | `score/gateway_ipc_binding/gateway_ipc_binding.hpp:80-325` | **Yes** (IPC wire) | **Unchanged** |

Build-placement evidence for the internal key: the public `headers` filegroup is
`glob(["*.hpp"])` (`score/socom/BUILD:17-22`), while the library `srcs` glob is
`impl/**/*.cpp` + `impl/**/*.hpp` (`:24-30`). The key therefore never appears in a published header;
it is visible to the unit-test package only by explicit `testonly` exposure. This matches
`invariants.md` **R-14** ("the key is internal, with no public/ABI exposure").

### 3.2 Layout and symbol analysis

- **Layout unchanged.** `Service_instance_identifier` is still
  `{ Service_interface_identifier interface; Service_instance instance; }`
  (`impl/service_identifier.hpp:29-32`). No members added, removed, reordered, or retyped. Both
  members' layouts are also unchanged (`Service_interface_identifier` and `Service_instance` are
  untouched public types).
- **Operator signature unchanged.** `bool operator<(Service_instance_identifier const&,
  Service_instance_identifier const&)` keeps the same declaration and definition signature
  (`impl/service_identifier.hpp:35`, `impl/service_identifier.cpp:20`), so the mangled symbol is
  unchanged. The implementation now compares the projection
  `(lhs.instance, lhs.interface.id, lhs.interface.version.major)` (`:28-29`), which uses only
  already-available operators (`Service_instance::operator<`,
  `service_interface_identifier.hpp:69-71`; `Registry_string_view::operator<`).
- **No new operators/overloads.** There is still **no** `operator==` and **no**
  `std::hash<Service_instance_identifier>`; `operator<` remains the single identity rule
  (`invariants.md` R-3/R-14). So the changed type gains no new ABI surface.
- **No public header, no exported symbol in a public header.** Because the type is not published,
  no separately-compiled public consumer can name it or depend on its layout; the symbol is an
  internal linkage-by-convention artifact of `libsocom`. The repo has no version script for `socom`
  (the only `*.lds` in the tree is `score/serializer/exported_symbols.lds`), so no explicit export
  list is affected.

**Conclusion (static):** the bounded change is **ABI-neutral** for every public consumer. The only
ABI-adjacent artifact is the definition of an `impl/`-only free function whose signature and result
type are unchanged; its behaviour change is invisible at the binary-interface level and is only
observable through the public `Runtime` API behaviour described in §4.

**Not established here:** no symbol table was dumped, no ABI checker/comparison tool ran, and no
`bazel` build exists (all `native_*` obligations exit `127`). The statement above is a static reading
of headers, signatures and build placement, not a measured ABI diff.

### 3.3 Public types that could have been affected but were not

- `Service_interface_identifier` ordering and hashing remain `minor`-aware
  (`service_interface_identifier.hpp:130-133`, `:140-143`, `:149-152`, `:159-162`, `:181-190`) and are
  exercised in source by
  `ServiceInstanceIdentifierTest.PublicIdentifierIdentityDistinguishesMajorAndMinorBoundaries`
  (`service_identifier_tests.cpp:784-811`), which explicitly pins that the internal key correction
  "must not leak into the public type".
- `Service_interface_definition::operator==`/`operator<` still delegate to
  `Service_interface_identifier::operator<` and keep the assertion on `num_methods`/`num_events`
  (`impl/service_interface_definition.cpp:30-39`), i.e. configuration equality remains minor-aware.
- `std::hash<Service_interface_identifier>` still mixes `major` **and** `minor`
  (`service_interface_identifier.hpp:184-187`), matching `Service_database`'s
  `Interfaces_instances` map type (`runtime_impl.hpp:99-100`).

---

## 4. API review

### 4.1 The one observable API-behaviour change

Before the draft, the duplicate-server registration key compared the full
`Service_interface_identifier` (including `minor`) — the baseline ordering reported by
`prior-reports/invariants.md` I-4 as `std::tie(lhs.instance, lhs.interface)`. Two server
configurations sharing `(instance, id, major)` but differing only in `minor` therefore produced
distinct keys and could both be constructed; enabling the second then reached
`SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)` in `Service_record::register_server_connector`
(`impl/runtime_impl.cpp:369`) because the minor-ignoring record index had resolved both to one
`Service_record` (`impl/runtime_impl.hpp:116-134`).

With the draft key `(instance, id, major)` (`impl/service_identifier.cpp:28-29`), the second
`Runtime::make_server_connector` now fails **at construction**:

```cpp
if (!m_service_identifiers->data.insert(identifier).second) {
    return MakeUnexpected(Construction_error::duplicate_service);   // runtime_impl.cpp:451-453
}
```

This is an **API-behaviour change** for callers of the public virtual
`Runtime::make_server_connector` (`runtime.hpp:188-206`):

| Aspect | Before (reported baseline) | After (draft) |
|--------|----------------------------|---------------|
| Same `(instance, id, major)`, different `minor` | both construct; second enable hits `ASSERT(!m_server)` | second construction returns `duplicate_service` |
| Error value | none at construction; assert on enable | `Construction_error::duplicate_service` at construction |
| Error timing | later / process-terminating assert (depending on `SCORE_LANGUAGE_FUTURECPP_ASSERT` semantics, which are external and not established here) | earlier, ordinary `Result` error |

The change is **strictly safer** for the single-server precondition and closes the I-11 gap, but it
is not an accepted behaviour change. `SCORE_LANGUAGE_FUTURECPP_ASSERT`'s terminate-vs-compiled-out
semantics live in `score_baselibs` and are **not determined in this checkout**, so the exact
pre-change outcome (terminate vs silent `m_server.emplace` overwrite) remains unknown.

### 4.2 Call-site impact (behaviour only, no signature change)

Existing in-repo consumers call the public `Runtime::make_server_connector` and are affected only in
the duplicate case:

- `score/someipd/impl/remote_network_service.cpp:42-67`
- `score/someipd/impl/local_network_service.cpp` (same construction pattern)
- `score/gatewayd/main.cpp:228-232` and `score/gatewayd/impl/{local,remote}_service_instance.cpp`
- `score/gateway_ipc_binding/**` constructs socom identifiers from the IPC `Service` struct
  (`impl/gateway_ipc_binding.cpp:27-53`, `impl/service_state.hpp:412-417`).

None of these compiles or runs against a native Bazel target here; the impact is a source reading.

### 4.3 Diverging notions of "same service" (documentation/contract gap)

There are now three distinct equivalence notions, two of which are minor-aware and one minor-blind:

| Notion | Definition | Includes `minor`? | Site |
|--------|-----------|-------------------|------|
| Public identifier equality | `(id, major, minor)` | **Yes** | `service_interface_identifier.hpp:149-152`, `:159-162`, `:181-190` |
| Configuration equality | delegates to identifier `<` | **Yes** | `impl/service_interface_definition.cpp:30-39` |
| Duplicate-server registration key | `(instance, id, major)` | **No** | `impl/service_identifier.cpp:28-29` |
| `Service_database` record index | `(id, major)` + instance | **No** | `impl/runtime_impl.hpp:116-134` |
| IPC wire `Service` | `(service_id, major, minor)` | **Yes** | `impl/gateway_ipc_binding.cpp:32-43` |

Consequences and review items:

1. **Doc wording is now imprecise.** `Runtime::make_server_connector` says a duplicate exists if
   *"a service defined by the configuration.interface and instance parameters is already registered"*
   (`runtime.hpp:176-178`). Because `configuration.interface` (`Service_interface_identifier`) equality
   is minor-aware while the gate is minor-blind, the doc text no longer matches the implementation for
   minor-only differences. It should be reworded to state that the identity is
   `(instance, service id, major)` and that `minor` is a compatibility property, not an identity
   component. This is a **documentation** change to a **public** header and would require source-write
   authorization; recorded, not applied.
2. **Client-side duplicate detection is already version-blind** (`register_client_connector` returns
   `duplicate_client` when `m_client` is set, without comparing versions,
   `impl/runtime_impl.cpp:386-388`). So the draft makes server-side detection *consistent* with the
   client side and with the record index; before the draft the server side was the outlier. This
   supports the direction but does not make it accepted.
3. **Error specificity.** `Construction_error::duplicate_service` is commented only "Service
   identifier already exists" (`error.hpp:55`). Whether a collision caused solely by a differing
   `minor` should be `duplicate_service`, a more specific error, or supersede the existing connector
   is unresolved (`invariants.md` §5.5) and is an API-design question for the owner of #84.

### 4.4 API surface that is explicitly unchanged

- No public header was added, removed, or edited.
- No public function signature, default argument, `noexcept` specification, or `virtual` set changed.
- No new public type, alias, operator, or specialisation was introduced.
- The `impl/`-only key still has exactly one operator and no equality/hash, so no new external symbol
  family (e.g. `operator==` or `std::hash`) is added.

---

## 5. Minor-version representation review

### 5.1 Representation across layers

| Layer | Type | Width / default | Site |
|-------|------|-----------------|------|
| Public socom `Version` | `std::uint16_t major; std::uint16_t minor;` | 16 / 16 | `service_interface_identifier.hpp:80-88` |
| IPC wire `Service` | `Service_interface_identifier::Version version;` | 16 / 16 | `gateway_ipc_binding.hpp:80-85` |
| SOME/IP config `ServiceType` | `service_version_major: uint8` | 8 | `score/config/mw_someip_config.fbs:19` |
| SOME/IP config `ServiceType` | `service_version_minor: uint32 = 0xFFFFFFFF` | 32, wildcard default | `score/config/mw_someip_config.fbs:23` |
| JSON sample | `"service_version_minor": 0` | concrete | `score/config/mw_someip_config.json:7`, `:25`, `:87` |

### 5.2 Narrowing / widening sites (no range or wildcard check)

Config→socom construction performs an unchecked narrowing:

- `score/someipd/impl/remote_network_service.cpp:42-45`
  (`{service_version_major(), static_cast<uint16_t>(service_version_minor())}`)
- `score/someipd/impl/local_network_service.cpp:49`
- `score/gatewayd/impl/local_service_instance.cpp:49`
- `score/gatewayd/impl/remote_service_instance.cpp:92`
- `score/gatewayd/main.cpp:229-232`

`service_version_minor` is `uint32` defaulting to the SOME/IP wildcard `0xFFFFFFFF`; the cast yields
`0xFFFF` and silently truncates any value `> 0xFFFF`. `service_version_major` is `uint8` widened
losslessly into `uint16`. This mirrors `invariants.md` §5.3 and is verified in source by
`ServiceInstanceIdentifierTest.ConvertedKeyCollapsesConfigMinorsThatNarrowAlike`
(`service_identifier_tests.cpp:884-909`) and
`ConvertedKeyRetainsConfigWidthMajorBoundaries` (`:1590-1612`). Those tests are **source-only here**
(the focused run covers the 85 earlier cases; the two newest cases are unexecuted, §7.3).

### 5.3 Wildcard semantics are asymmetric today

Compatibility is `client.version.minor <= server.version.minor`
(`is_minor_version_compatible`, `impl/runtime_impl.cpp:133-136`), applied at client bind (`:505-517`)
and server connect (`:534-544`). A server configured with minor `0xFFFF` (or the narrowed wildcard)
accepts every client minor `<= 0xFFFF`; a **client** configured with `0xFFFF` would instead require
the server's minor to be exactly `0xFFFF`. So the wildcard behaves like "accept any" only on the
server side; there is no explicit wildcard flag, only the arithmetic relation. This is a
representation-semantics gap, not a defect claim.

### 5.4 Interaction between the narrowed wildcard and the new minor-ignoring key (review item)

Because the registration key now ignores `minor` (`impl/service_identifier.cpp:28-29`), a server
whose configured minor narrowed to `0xFFFF` (from config `0xFFFFFFFF`) and a server with a concrete
minor (e.g. `3`) for the same `(instance, id, major)` now produce the **same** registration key and
the second is rejected as `duplicate_service`. On the reported baseline (minor included) they were
distinct keys. This is a real behavioural consequence at the intersection of the bounded key change
and the unaccepted wildcard representation:

- If `0xFFFF` is to mean "accept any minor", the duplicate gate may need to treat wildcard and
  concrete minors specially, or the wildcard should be resolved earlier (before key construction).
- If `0xFFFF` is just a coarse concrete minor, the collision is consistent with the minor-ignoring
  record index but should be documented to callers.

Either way this is **design input for the owner of #84**, not something this review may decide. It is
recorded as unresolved and out of the bounded slice.

### 5.5 Tests bearing on minor representation (source, not executed here)

- `PublicIdentifierIdentityDistinguishesMajorAndMinorBoundaries`
  (`service_identifier_tests.cpp:784-811`) pins that the public identity stays `(id, major, minor)`.
- `ConvertedKeyRetainsInstanceServiceIdMajorAndStoresMinor` (`:813-831`) pins that the key stores the
  full public version but compares only `(instance, id, major)`.
- `ConvertedKeyCollapsesConfigMinorsThatNarrowAlike` (`:884-909`) pins that distinct config minors
  narrowing to the same 16-bit value collapse.
- `ConvertedKeyRetainsConfigWidthMajorBoundaries` (`:1590-1612`) pins lossless widening of the 8-bit
  config major.
- Runtime-level: `ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError`
  (`runtime_tests.cpp:402-431`).

None of the runtime-level cases was executed by the retained focused measurement.

---

## 6. Future public identifier redesign — retained human design questions

The following are **proposals only** (`.llm_tmp/context/issue-snapshot.json:5`, 0 comments) and are
explicitly **not** implemented or endorsed by this bounded slice. They are retained here so they are
not mistaken for accepted behaviour, and are handed to human review as design questions:

1. **Move `minor` out of `Service_interface_identifier`.** The issue proposes making `minor` "a
   property of the service instance". That would change the public struct
   (`service_interface_identifier.hpp:73-124`) and therefore its layout, its inline
   `operator==`/`operator<`/`std::hash` (`:130-190`), and every public consumer that stores or
   compares it (IPC `Service`, `Service_interface_definition`, `Service_database`,
   `gateway_ipc_binding`). This is a designed, versioned **API/ABI change**, not a key tweak.
2. **Define the "service identifier" as `id + major`.** The draft already realizes this *only*
   internally (key/record index); the public and IPC layers still distinguish minors
   (`invariants.md` R-13). Deciding whether the public identity should also drop `minor` — and how to
   migrate the IPC wire struct — is a human design question with compatibility impact.
3. **FindService `optional<minor>` / `optional<instance>` and the `major = FF` wildcard.** Neither
   exists today; introducing either would touch discovery semantics (`get_bridge_reported_instances`,
   `bridge_service_requests`, `runtime_impl.cpp:561-612`) and the `Service_database` lookup. Out of
   scope and unaccepted.
4. **Wildcard representation.** Decide whether the config `uint32 0xFFFFFFFF` wildcard is resolved to
   a concrete `uint16` before key construction, carried as a distinct flag, or rejected with an error
   when non-representable (§5.3-5.4). Resolving this changes the API contract of the
   config→socom conversion sites listed in §5.2.
5. **Error semantics for a minor-only collision.** Whether `duplicate_service` should remain the
   result, become a dedicated error, or supersede is an API-contract decision
   (`error.hpp:55`; `invariants.md` §5.5).
6. **Config→socom conversion validation.** Whether the unchecked `static_cast<uint16_t>` narrowings
   should gain range checks or wildcard handling is a public behaviour change to conversion entry
   points and must be authorized separately.

**Recommendation to reviewers:** keep the bounded slice to the `impl/`-only key correction and the
associated tests; do not implement items 1-6 in this slice. If any of them proceeds, it must be
treated as a public API/ABI change with its own compatibility, migration (including the IPC wire
layout) and verification plan.

---

## 7. Verification evidence and gaps

### 7.1 ABI/API evidence used

- Direct readings of the public headers and the `impl/` key: `service_interface_identifier.hpp`,
  `service_interface_definition.hpp`, `runtime.hpp`, `server_connector.hpp`,
  `impl/runtime_impl.hpp`, `impl/runtime_impl.cpp`, `impl/service_identifier.{hpp,cpp}`,
  `impl/service_interface_definition.cpp`, `gateway_ipc_binding.hpp`,
  `impl/gateway_ipc_binding.cpp`, `impl/key.hpp`, `impl/service_state.hpp`.
- Build-placement evidence: `score/socom/BUILD`, `score/socom/test/unit/BUILD`.
- Config representation evidence: `score/config/mw_someip_config.fbs`,
  `score/config/mw_someip_config.json`, and the five narrowing sites in §5.2.
- Host/obligation artifacts: `.llm_tmp/overnight/validation/{check-result,measurement.json,after.json,
  before.json,after-compile.command.json,after-compile.stderr}` and
  `.llm_tmp/overnight/obligations/**/result.json` (as listed in §1.4).

### 7.2 What is NOT established

- No symbol-table dump, `abi-compliance-checker`/`abi-dumper`, or equivalent ABI diff was run; no such
  tool is available in this task, and no `bazel` build exists.
- No full public-header compile: the focused measurement compiles only
  `service_identifier.cpp` + `string_registry.cpp` + `service_identifier_tests.cpp` plus googletest.
  `runtime_tests.cpp`, `interface_compatibility_tests.cpp`, `client_tests.cpp`, the IPC binding, and
  the gateway daemons were **not** compiled.
- No runtime/interaction test was executed, so the §4.1 duplicate-gate behaviour and the §5.4
  wildcard/key collision are source-derived, not observed.
- `SCORE_LANGUAGE_FUTURECPP_ASSERT` semantics (terminate vs compiled out) are external
  (`score_baselibs`) and unknown, so the pre-change outcome of the single-server precondition is not
  determined.

### 7.3 Test inventory and staleness (read, not run)

- `score/socom/test/unit/service_identifier_tests.cpp`: **87 `TEST_F`** under
  `ServiceInstanceIdentifierTest` (counted this iteration by `grep`; `:168`…`:1929`, plus `:1982` and
  `:2012`). The retained `after.json` executed **85**; the two newest cases (`:1982`, `:2012`) are
  **not covered** by any retained measurement — a documented staleness (also reported by
  `concurrency_review.md` and `process_checks/result.json`, `test_macros: 87`).
- `score/socom/test/unit/runtime_tests.cpp`: 31 `TEST_F` + 1 `TEST` + 1 `TEST_P`
  (`process_checks/result.json` `test_macros: 33`); never executed here.
- The 85-case focused capture is `ServiceInstanceIdentifierTest` only and does not exercise the public
  `Runtime` API or the IPC layer.

### 7.4 Reproduction path for a later, authorized iteration (not run here)

```bash
bazel test //score/socom/test/unit:socom_test
# focused key-level:
bazel test //score/socom/test/unit:socom_test --test_filter='ServiceInstanceIdentifierTest.*'
# focused runtime regression:
bazel test //score/socom/test/unit:socom_test \
    --test_filter='RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError'
```

An ABI check would additionally require building the public consumer targets and comparing symbol
tables/public header layouts, which no tool in this task can do.

---

## 8. Obligations status (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Freedom from compiler warnings & errors (100 %) | `verification_plan.rst` (criterion 9) | **PARTIAL, NOT SATISFIED** — GCC focused identifier TU exit `0`; clang leg fails on a googletest/libstdc++ deprecation outside the candidate paths; no Bazel build |
| Static code analysis (clang-tidy / CodeQL), findings classified | `code_analysis.rst`; `verification_process.rst` (SCA classification) | **NOT SATISFIED** — clang-tidy config blocker; CodeQL mapping draft; findings are dependency/gtest-macro hits |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` (`:status: draft`) | **UNKNOWN** — not applied |
| Structural statement / branch coverage goals | `verification_plan.rst` (criteria 1-2) | **NOT SATISFIED** — focused coverage 100 % line / 78.6 % branch, `complete_target_scope: false`, `safety_class: unknown`, below the 85/100 platform goals on branch; native coverage did not run |
| Unit/component testing executed, results recorded | `verification_plan.rst` (criteria 6-7); `verification_guideline.rst` | **PARTIAL, STALE** — 85 identifier cases 0-failure retained; working tree has 87; `runtime_tests.cpp` and all public/IPC consumers never executed |
| Interface / requirements / resource / fault-injection test types | `verification_process.rst`; `verification_plan.rst` | **NOT PERFORMED / applicability not inferred** — no harness; identifier-only tests must not be labelled platform validation |
| Boundary / equivalence derivation | `verification_process.rst` | **SOURCE-ONLY** — cases exist; only the focused identifier TU was executed |
| Fuzzy testing technique | `verification_plan.rst` | **NOT EXECUTED / NOT CLAIMED** — no harness, no measurement |
| Linking tests to requirements (record properties) | `verification_process.rst` (`gd_req__verification_link_tests*`) | **PARTIAL / NOT DONE** — `DerivationTechnique`/`Description` recorded (`service_identifier_tests.cpp:42-65`; `runtime_tests.cpp:264-267`); `TestType`/`Verifies` deliberately unset (no verified identifier exists; inventing one is prohibited) |
| Independence of verification / review | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Implementation inspection checklist IMPL_01…IMPL_03 | `inspection_checklist.rst` (`:status: draft`) | **NOT FILLED** |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** — bazel, valgrind, gitleaks, clang-format, pre-commit, reuse unavailable; clang-tidy config rejected |
| Obligation collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **PRESENT but retention ≠ passing** — many `findings_or_execution_failure` / exit `127` |
| Native acceptance | `source-index.json` | **`not_inferred` for every entry** |

**Explicit non-satisfaction statement.** Missing tools (`bazel`, `valgrind`, `gitleaks`), the failing
or blocked focused checks (clang, TSan, memcheck, clang-tidy, cppcheck), the `not_inferred`
applicability, the incomplete extraction (focused identifier TU only, dependency findings retained),
the stale 85-vs-87 measurement, and the unanswered human reviews mean **none of the checked
obligations may be treated as satisfied**. A successful collection node proves *retention*, not
passing.

---

## 9. Measurement and validation status

- **Tools:** `read_file`, `grep`, `glob`, `write_file` only. No `shell`, delegation, web, approval,
  publishing, or engineering acceptance.
- **Executed measurements by this iteration:** **none**. No build, no test, no runtime. Every ABI/API
  statement above is a static reading of the working tree at the baseline-bound candidate paths, an
  explicitly-labelled logical consequence, or a record of a retained artifact.
- **Retained host measurements (present, scoped, unprotected):** the focused identifier TU is
  `before 85/28` → `after 85/0` (GCC `-Werror`, UBSan per `measurement.json`), compile exit `0`,
  empty `stderr`; `engineering_acceptance: pending`, `full_native_tests: not_executed`. It covers
  **no** public consumer, `runtime_tests.cpp`, or Bazel target.
- **Scope:** local, unprotected, scoped. This draft has not been reviewed, accepted, published, or
  reproduced on a full native runtime. Unit/integration execution and human review remain pending.

---

## 10. Notice preservation

- **Only this report was written.** No source, build, test, config, `NOTICE`, `LICENSE`,
  `REUSE.toml`, or prior-report file was created, edited, or deleted. Every existing Apache-2.0/SPDX
  header on every file read remains untouched.
- The header the task flagged (`score/socom/impl/service_identifier.hpp`) was inspected and left
  unchanged because it is already brace-balanced and well-formed (§2).
- The key remains an `impl/`-only type exposed only through the `testonly`
  `//score/socom:impl_service_identifier` library; **no public notice or header surface changed**.
- This report itself carries the Apache-2.0 header.

---

## 11. Pending human review checklist

- [ ] **Confirm §2:** the header is already brace-balanced (nested close at `:38`; line `:39` blank),
  the GCC focused compile exits `0`, and the recorded "extra closing brace at line 39" is stale; if a
  different "cancelled draft" revision still carries the brace, locate it and authorize its
  correction (it is not this checkout).
- [ ] **Resolve the instruction conflict:** the task directs correcting the source, while the actual
  source contains no defect and the explicit write boundary permits only this report. Confirm that
  inspection-only plus this report is the intended outcome.
- [ ] **Ratify the §3 ABI conclusion:** the bounded change is confined to an `impl/`-only type and is
  source-level ABI-neutral; confirm no public header/layout/symbol change is expected, and authorize
  an ABI-checker run on a real Bazel build before release (not possible in this task).
- [ ] **Decide the §4.1 API-behaviour change:** `Runtime::make_server_connector` now returns
  `duplicate_service` for a minor-only collision instead of constructing a second connector. Confirm
  this is the intended contract and that `SCORE_LANGUAGE_FUTURECPP_ASSERT` semantics make the
  pre-change path safe or that the change is required.
- [ ] **Authorize the §4.3 documentation correction** to `runtime.hpp:176-178` (state identity =
  `(instance, service id, major)`; `minor` is a compatibility property) — a public-header edit that
  this review could not apply.
- [ ] **Resolve the §5 minor-representation questions:** the `uint32 0xFFFFFFFF` config wildcard
  narrowed by `static_cast<uint16_t>` at five sites, the asymmetric server-side wildcard, and the
  §5.4 collision between a wildcard-narrowed `0xFFFF` server and a concrete-minor server under the new
  key. Adjudicate representation, validation and error semantics.
- [ ] **Keep the §6 public identifier redesign as a design question:** service identifier
  `= id + major`, moving `minor` onto the instance, FindService `optional<minor>`/`optional<instance>`,
  `major = FF` wildcard, and the IPC wire migration. Do not implement in this bounded slice; if
  pursued, treat as a versioned public API/ABI change with its own compatibility and verification
  plan.
- [ ] **Confirm the §7.3 staleness:** the retained measurement covers 85 identifier cases while the
  working tree has 87 (`:1982`, `:2012` untouched), and no public/runtime/IPC consumer was compiled
  or run.
- [ ] **Do not infer passing from retained collection nodes** (§8): `native_*`/`cross_compilation`/
  `format_precommit` exit `127`, clang is blocked on a dependency, TSan crashes, memcheck/clang-tidy/
  cppcheck are blocked or out of scope, and applicability is `not_inferred`.
- [ ] **Run the full native suite** (`bazel test //score/socom/test/unit:socom_test` and the broader
  `//score/...` set), including `runtime_tests.cpp` and the interface-compatibility matrix, record the
  results, and schedule independent human review (approver ≠ author, per
  `gd_req__verification_independence`).
