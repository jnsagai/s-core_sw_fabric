<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — integration and Assumptions-of-Use (AoU) review

**Document type:** review draft (component / feature / platform integration review +
interface-test review + external-component Assumptions-of-Use review + QEMU result
status + reference-integration vs integrator-obligation separation + missing
requirement-link register + obligations status)
**Date:** 2026-10-02
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version
handling in socom* (issue #84)
**Run:** branch `fabro/run/01M3YRJEGXNY6CB81T7TKW774B`; latest run commit per the
environment `44264b4`
(`fabro(01M3YRJEGXNY6CB81T7TKW774B): node_1182f4d71399dfbab9f7dc6e (success)`).
Earlier reports of the same run reference `8934e94`, `84ea712`, `56304d4`, `a616495`,
`236f629`, and `8178879`.
**Status:** local, unprotected, scoped. **No engineering acceptance exists. Human
reviews are unanswered. Full native runtime tests remain pending.** Every statement
below is either a direct static reading of this checkout at the baseline-bound
candidate paths, a direct reading of a retained artifact under `.llm_tmp/overnight/`,
or an explicitly-labelled logical consequence. Nothing here is published, reviewed,
accepted, or a full native run.

> **Tool / write boundary actually observed.** Only `read_file`, `grep`, `glob`, and
> `write_file` were used. No `shell`, no delegation, no web access, no approval, no
> publishing, and no engineering acceptance was performed. The task's explicit final
> sentence — *"This is a review draft: only that report may be written."* — is the
> operative write boundary, and it resolves the task's other direction ("Inspect and
> correct the actual source before expanding tests") in favour of **inspection only**.
> Accordingly **exactly one file was written: this report**
> (`/workspace/.llm_tmp/overnight/reports/integration_aou_review.md`). No source,
> build, test, config, `NOTICE`, `LICENSE`, `REUSE.toml`, host-validation, or
> prior-report file was created, edited, or deleted.
>
> **The recorded GCC syntax failure is not present in the actual source
> (re-verified this iteration).** The task records *"a measured GCC syntax failure:
> an extra closing brace in `score/socom/impl/service_identifier.hpp` at line 39."*
> Direct `read_file` + `grep` on the current working tree (§2) show the header is
> **brace-balanced**: openers at `:19` (`namespace score::socom {`) and `:29`
> (`struct Service_instance_identifier final {`); closers at `:32` (`};`) and `:38`
> (`}  // namespace score::socom`). Line `:39` is **empty**; `:40` is `#endif`. Two
> openers, two closers, net balance `0`. `glob **/service_identifier.hpp` returns a
> single path. There is no third, unmatched closing brace and therefore no actual
> source to correct; applying the recorded repair would be a no-op at best and a
> compile break at worst. **No source write was made and none is required.** The
> conflict between "correct the actual source" and "only that report may be written"
> is recorded for human disposition (§2.3, §12).
>
> **Non-satisfaction rule applied throughout.** A successful obligation-collection
> node means the results were **retained**, not that the checks **passed**. Missing
> tools, unknown applicability, incomplete extraction, and unanswered human reviews
> are **not** treated as satisfied. A check that produced **no** finding because it
> **did not run** is recorded as *"not run"*, never as *"clean"*.

---

## 0. Summary

1. **The three integration levels are defined (unit/component, feature, platform)
   but the bounded slice is only present at unit/component level.** S-CORE's plan
   defines Level 1 unit/component, Level 2 feature integration, and Level 3 platform
   integration on reference hardware (`verification_plan.rst:121-150`). The bounded
   registration-key change is a `socom` internal identity change with unit tests and
   identifier-level coverage (Level 1). There is no `socom` feature requirement and
   no feature-integration test for version handling, and no platform-integration
   test that exercises the duplicate gate (§4, §5, §6).
2. **Full platform integration on the final product is the integrator's obligation,
   not S-CORE's.** The plan states the target-device integration and its verification
   "should be considered by the distributor of the platform", with S-CORE running
   reference-hardware tests only as "an optional base for the integrator"
   (`verification_plan.rst:61-67`, `:138-150`, `:604-608`); the guideline repeats this
   for the target-environment safety requirements, which "an integrator … can
   re-execute … in the product environment", while the AoU-linked ones "will not be
   executed on the final product environment as part of the project scope"
   (`verification_guideline.rst:197-203`). This report keeps the two apart everywhere
   (§3).
3. **QEMU integration did not run.** The retained `native_integration` collection
   failed with `exit 127` / `[Errno 2] No such file or directory:
   '/tmp/s-core-001/bin/bazel'` for
   `bazel test --config=qemu-integration //quality/... //tests/integration_test/...`,
   although its prerequisites are present (`kvm_exists: true`,
   `qemu: /usr/bin/qemu-system-x86_64`) (`native_integration/result.json:236-275`).
   No QEMU result exists; KVM/QEMU availability is not a run (§7).
4. **The changed key is exercised only through unit tests, and even those were never
   run natively.** `//score/socom/test/unit:socom_test` (which holds
   `service_identifier_tests.cpp`, `runtime_tests.cpp`,
   `interface_compatibility_tests.cpp`, `client_tests.cpp`) is visible to
   `//tests/integration_test:__pkg__` (`test/unit/BUILD:16-29`) and is packaged into
   the QEMU target `test_score_test_applications`
   (`tests/integration_test/BUILD:65-89`, `score_test_applications.py:19-24`), so the
   QEMU path *would* run it — but it never executed (§7.2). The only executed
   measurement is a focused host `g++-12` identifier translation unit that is
   already stale against the 87-case working tree (§8).
5. **No relevant component requirement and no AoU requirement exist in this
   checkout.** The feature and component requirement indices are empty placeholders
   (`docs/requirements/feature/index.rst:15-32`,
   `docs/requirements/component/index.rst:15-35`); the only populated requirement
   tree is `stkh_req__someip_gw__interoperability`
   (`docs/requirements/stakeholder.rst:23-35`) → `feat_req__tc8_conformance__conformance`
   → eight `comp_req__tc8_conformance__*`
   (`docs/tc8_conformance/requirements.rst:24-270`), none of which concerns `socom`
   identity/version handling. There is therefore **no requirement to link** the
   duplicate-key change to, and no `aou_req__*` register for the external components
   (§9).
6. **External-component Assumptions of Use are not verified.** The obligation
   `gd_req__verification_external_aou` requires external-component AoUs to be
   "verified by integration tests or static analysis tooling"
   (`verification_process.rst:214-226`). In this checkout the integration tests did
   not run (missing `bazel`), the static-analysis tools did not run (clang-tidy
   config blocker; CodeQL focused/dependency-only), and the repo defines no AoU
   requirements for `vsomeip`, `score_baselibs`, `score_communication`/`mw::com`,
   `message_passing`, FlatBuffers, or the QNX/toolchain patched dependencies (§10).
7. **Interface-test metadata is incomplete and cannot satisfy the extended check.**
   `gd_req__verification_checks_extended` requires that an `interface-test` link to
   at least one interface, and `gd_req__verification_checks` requires `TestType` and
   `DerivationTechnique` to be set (`verification_process.rst:178-212`). The
   candidate tests record only `DerivationTechnique` and `Description`
   (`process_checks/result.json:244-262`); `TestType` and all
   `Verifies`/`PartiallyVerifies`/`FullyVerifies` links are deliberately unset, and
   no Python integration test in the repo uses the metadata decorator at all
   (§5, §6.3, §9).
8. **No obligation is satisfied.** Every `source-index.json` entry is
   `native_acceptance: not_inferred`; `authority.json` is
   `engineering_acceptance: pending`, `human_reviews: unanswered`,
   `safety_class: unknown`. The retained `process_checks` blockers explicitly include
   *"External AoU and full integration verification require scoped review"* and
   *"Lexical metadata inventory cannot prove semantic requirement coverage"*
   (`process_checks/result.json:235-240`).

---

## 1. Binding to the baseline, issue, prior reports, host feedback, obligations

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` — *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:2-4` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` (unchanged) | `.llm_tmp/context/issue-snapshot.json:19-20` |
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an
accepted obligation**: service-instance identifier = `service id + major + minor +
instance id`; service identifier = `service id + major`; FindService = `service id +
major + optional<minor> + optional<instance>`; and a proposal to exclude `minor` from
identity and make it a property of the instance. There is **no comment and no
acceptance record**, so none of it binds this review.

### 1.2 In-scope candidate files (the only writable source paths)

From `.llm_tmp/context/candidate-files.json:1-25`, read this iteration:

| File (repo-relative) | Baseline blob | Working-tree state read this iteration |
|----------------------|---------------|----------------------------------------|
| `score/socom/BUILD` | `3477ea08…` | `socom` library `:24-41`; `testonly` `impl_service_identifier` `:46-54` |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e…` | key identity `(instance, id, major)`; `minor` excluded (`:28-29`) |
| `score/socom/impl/service_identifier.hpp` | `c8bae790…` | brace-balanced, 40 lines, `:39` blank |
| `score/socom/test/unit/BUILD` | `3c03a7b1…` | `socom_test` globs `*.cpp`; visibility to `//tests/integration_test` (`:22`) |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab7…` | 31 `TEST_F` + 1 `TEST` + 1 `TEST_P` (33 macros) |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(null — new file)* | **87 `TEST_F`** under `ServiceInstanceIdentifierTest` (`:168`…`:2012`) |

The `null` baseline blob for `service_identifier_tests.cpp` is the manifest's
expectation of a **new** file; it exists only in the un-merged working tree (the
"cancelled draft"). `glob **/service_identifier.hpp` returns exactly one path.

### 1.3 Prior reports read and preserved

`.llm_tmp/overnight/reports/` was read and **preserved unchanged** (this document is
the only new entry): `scope.md`, `invariants.md`, `callsites.md`, `reproducer.md`,
`key_fix.md`, `unit_matrix.md`, `ordering_tests.md`, `conversion_tests.md`,
`runtime_disabled.md`, `runtime_enabled.md`, `lifetime_tests.md`, `test_metadata.md`,
`coverage_tests_repair.md`, `tool_findings_repair.md`, `compatibility.md`,
`api_review.md`, `concurrency_review.md`, `lifetime_review.md`, `coverage_review.md`,
`native_build_review.md`, `finding_classification.md`, `misra_applicability.md`,
`misra_manual_review.md`, `deviation_drafts.md`, `analyzer_plan.md`, `bazel_plan.md`.
`.llm_tmp/overnight/prior-reports/` (12 files) was also preserved. The most relevant
for this review are `api_review.md` (public-surface/AoU-adjacent analysis),
`compatibility.md` (exact-major / minimum-minor and the untested-path register),
`native_build_review.md` (native/QEMU unavailable-tool blockers), and
`callsites.md` (call-site map). No earlier report delivers a dedicated
integration/AoU review; `security_review`, `traceability_review`, and
`verification_report_draft` are also still absent.

### 1.4 Host validation feedback and obligation-collection results (present)

`.llm_tmp/overnight/validation/`: `check-result` = `0`; `measurement.json` records
`origin: local_unprotected_measurement`, `initiator: Fabro host hook`,
`engineering_acceptance: pending`, `full_native_tests: not_executed`, compiler
`/usr/bin/x86_64-linux-gnu-g++-12`, and a `baseline_with_agent_tests` with 28
failures versus a `candidate` with 0 failures over the focused identifier cases
(retained captures show 83 or 85 cases — both stale against the current 87-macro
tree). `after.json` is the parsed gtest JSON of the candidate run.

`.llm_tmp/overnight/obligations/` retains 24 checks. **Retention is not passing.**
The ones that bear on integration/AoU:

| Check | Retained status | Integration/AoU relevance |
|-------|-----------------|---------------------------|
| `native_integration` | `exit 127` (bazel missing); prereqs `kvm_exists: true`, `qemu: /usr/bin/qemu-system-x86_64` | **QEMU integration not run** |
| `native_build`, `native_tests`, `native_sanitizers`, `native_tsan`, `native_lint`, `native_docs`, `native_traceability`, `native_coverage`, `native_performance`, `cross_compilation`, `format_precommit` | `exit 127` (bazel/tools missing) | **No native build/test/lint/trace/coverage/QNX cross run** |
| `compiler_diagnostics` | GCC focused compile/tests `exit 0`; **clang `exit 1`** (googletest/libstdc++ `-Wdeprecated-declarations`) | Focused only; dependency failure |
| `focused_coverage` | `score/socom/impl/` 100 % line / 78.6 % branch; `complete_target_scope: false`; `safety_class: unknown_requires_authorized_selection` | Below 85/100 platform goals on branch; not the integration scope |
| `codeql_security` / `codeql_misra` | scan completed; findings under `.llm_tmp/googletest/**` and gtest macros; MISRA mapping `:status: draft` | **No external-AoU static-analysis verdict** |
| `secret_dependency_checks` | `gitleaks` `exit 127`; lock `sha256 c90b245b…` and 29-entry inventory retained | Inventory is not a vulnerability or AoU check |
| `tool_assurance` | `completed_with_blockers`; `bazel`, `valgrind`, `gitleaks`, `reuse`, `pre-commit`, `clang-format` unavailable | Tool qualification unestablished |
| `process_checks` | `completed_with_blockers`; blockers include **"External AoU and full integration verification require scoped review"**, **"Lexical metadata inventory cannot prove semantic requirement coverage"**, **"Safety/QM applicability and approved tailoring unknown"**, **"Independent inspection and acceptance required"**; metadata inventory `runtime_tests.cpp` 33 macros, `service_identifier_tests.cpp` 87 macros, each with `DerivationTechnique`/`Description` only | **Directly names this review; confirms missing requirement links** |
| `rework_progress` | `completed`, `source_changed_this_round: true`, `rework_requested: false` | One pass; unresolved findings stay pending |

### 1.5 Pinned obligation sources and authority

All nine entries of `.llm_tmp/context/obligations/source-index.json` are present
together with `authority.json`. Every entry is `"native_acceptance": "not_inferred"`.
`authority.json` records `engineering_acceptance: pending`,
`human_reviews: unanswered`, `safety_class: unknown`,
`codeql_scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload"`, and
the instruction *"Restart the failed queue for one complete pass through all
obligations"*. `misra_mapping` and `inspection_checklist` are `:status: draft`. The
requirements most load-bearing for this review are
`verification_process.rst` (`gd_req__verification_link_tests*`,
`gd_req__verification_checks`, `gd_req__verification_checks_extended`,
`gd_req__verification_external_aou`, `gd_req__verification_ci_reference_execution`,
`gd_req__verification_independence`) and `verification_plan.rst` (integration levels,
test types, reference hardware).

### 1.6 Host addendum (task context, not acceptance)

The host addendum (available only as quoted by prior reports) states it "is task
context, not engineering acceptance or an approved tailoring decision". It asks the
review to cover the verification-process test types and derivation techniques; to
keep `security_review`, `traceability_review`, `integration_aou_review`, and
`verification_report_draft` distinguishing configured module tests from any absent
fuzz/fault-injection harness or full feature/platform reference-hardware tests; to
leave unknown applicability and unexecuted checks explicit; to **not** label
identifier-only tests as platform validation and **not** to claim a fuzzy technique
without a measurement; and to record that there is **no authority to invent native
links, select a safety classification, accept risk/deviations, or answer the
independent human gate.** This report honours that in §3–§12.

---

## 2. The recorded syntax failure: inspection of the actual source

### 2.1 Finding (re-verified this iteration by direct `read_file` + `grep`)

`score/socom/impl/service_identifier.hpp` is **brace-balanced**. It is 40 lines; a
`grep` for `[{}]` returns exactly four brace-bearing lines:

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`) and two closers (`:32`, `:38`) give net brace balance `0`.
Line 39 contains no text. The task's "extra closing brace … at line 39" matches the
**stale, pre-correction** description recorded by the earliest prior reports (which
quoted lines 38–39 as the split form `}  // namespace socom` + `}  // namespace score`);
the `reproducer` iteration applied the correction and left line 39 blank, exactly as
observed here. The sibling `impl/service_identifier.cpp` uses the same nested form
(`:18`/`:32`) and is balanced.

### 2.2 Measured corroboration present this iteration (retained, not acceptance)

- `compiler_diagnostics` records a focused GCC `g++-12 -std=c++17 -Wall -Wextra
  -Werror` compile of the candidate translation unit with `exit_code: 0` and empty
  `stderr`, and `gcc-tests` `exit_code: 0`.
- `validation/after-compile.stderr` is empty; `measurement.json` records candidate
  `compile_exit: 0`.
- The only nonzero compiler exit is clang `exit 1`, a googletest/libstdc++
  `-Wdeprecated-declarations` error outside the six candidate paths.

A surviving unmatched brace would break all of these. This is still a **focused,
scoped** reading, not a full native build.

### 2.3 Disposition and instruction conflict

Applying the historical repair to the already-balanced file would be a no-op at best
and a regression at worst. **No source change was made.** The task contains a genuine
conflict: it directs correcting the source, while its explicit final sentence permits
only this report to be written; and on the facts there is nothing to correct. Both
the conflict and the stale description are recorded for human disposition rather than
silently resolved. If a distinct "cancelled draft" revision elsewhere still carries
the extra brace, it is not the file in this checkout and must be located and corrected
by an authorized iteration.

---

## 3. What "integration" means here, and the S-CORE / integrator split

### 3.1 The three levels (from the pinned plan)

S-CORE defines three integration and verification levels
(`verification_plan.rst:121-150`):

| Level | Basis | Who executes |
|-------|-------|--------------|
| 1. Software unit + component verification | detailed design, component architecture, component requirements | S-CORE (unit tests + component tests) |
| 2. Software (feature) integration verification | feature architecture, feature requirements | S-CORE (feature integration tests) |
| 3. Software platform integration testing | stakeholder requirements, on reference hardware | S-CORE runs reference-hardware tests as an *optional base*; **"The full Platform Integration Testing will be executed by the integrator"** (`:145`), and "S-CORE will implement Platform Integration Tests for stakeholder requirements for demonstration, but these are not intended to completely covering all stakeholder requirements" (`:149-150`) |

### 3.2 Reference integration vs final-product integrator obligations

The plan and guideline draw the boundary explicitly and this review preserves it:

- **S-CORE reference integration obligation:** provide the CI reference integration
  execution on a regular basis to guarantee inter-operation of integrated components
  (`verification_process.rst:250-264`, `gd_req__verification_ci_reference_execution`);
  provide Platform Integration Tests on reference hardware as a reusable starting
  point (`verification_plan.rst:604-606`); maintain the POSIX-target simulation
  environments on `aarch64`/`x86_64` with Linux and QNX flavours
  (`verification_plan.rst:590-602`).
- **Final-product integrator obligation (out of project scope):** "The integration of
  the platform on a target device and the respective verification and validation
  should be considered by the distributor of the platform" (`verification_plan.rst:65-67`,
  repeated at `:604-605`); the target-environment safety requirements are ones the
  integrator "can re-execute … in the product environment"
  (`verification_guideline.rst:197-198`), and the AoU-linked requirements "will not be
  executed on the final product environment as part of the project scope"
  (`verification_guideline.rst:201`).
- **Platform AoUs are referenced but not present here:** `verification_plan.rst:608`
  points at `aou_req__platform__testing` and `aou_req__platform__test_completion`.
  Neither is defined in this checkout (`grep` over `docs/**` finds no `aou_req`
  definition; `docs/requirements/component/index.rst:26-27` only documents the AoU
  naming scheme). They are upstream platform assumptions, not module obligations.
- **"The reference hardware is not yet decided."** (`verification_plan.rst:610`), so
  even the S-CORE reference-hardware leg is not yet pinned.

### 3.3 Consequence for this bounded slice

The registration-key correction is confined to the `impl/`-only
`Service_instance_identifier` and its `operator<` (a unit/component-level artifact).
It has no feature requirement and no platform requirement to verify, and the
QEMU/reference-hardware tests that could exercise it at levels 2–3 did not run
(§7). The bounded change therefore currently stands only at Level 1, and even there
only via a stale focused host measurement (§8).

---

## 4. Component integration review (`socom` inside the gateway)

### 4.1 The component boundary

`socom` is the intra-process Service-Oriented-Communication abstraction that the
gateway uses to decouple `gatewayd` (IPC/network-independent logic) from `someipd`
(the SOME/IP stack binding), with an IPC isolation boundary
(`.github/instructions/architecture.md:23-32`; `score/socom/README.adoc:25-32`;
`score/socom/docs/design/30_structural_view.rst:18-44`). The `Runtime` "creates and
connects Client_connectors and Server_connectors" and exposes a plugin interface for
bridges (`30_structural_view.rst:39-44`). Per `score/socom/BUILD:24-41` the library
compiles `impl/**/*.cpp` + `impl/**/*.hpp` and depends on
`@score_baselibs//score/language/futurecpp`, `@score_baselibs//score/mw/log`, and
`@score_baselibs//score/result`.

### 4.2 In-repo consumers of the changed `Runtime::make_server_connector` path

All server-connector registrations flow through the changed duplicate gate. Each
site constructs the key as `(service type name, {major, uint16(minor)})` and the
instance as the **service type name**:

| Consumer | Site | Key construction | Disposition on failure |
|----------|------|------------------|------------------------|
| `someipd` remote services | `score/someipd/impl/remote_network_service.cpp:42-73` | `iface{name,{major, (uint16)minor}}`; `inst{name}` | logs `LogError` and returns an error; `someipd/main.cpp:216-223` logs and `continue`s (**service silently not created**) |
| `someipd` local services (client side) | `score/someipd/impl/local_network_service.cpp:46-108` | `iface{name,{major, (uint16)minor}}`; `inst{name}` | logs and returns error; `someipd/main.cpp:185-190` logs and `continue`s |
| `gatewayd` local services | `score/gatewayd/impl/local_service_instance.cpp:46-80` | `iface{name,{major, (uint16)minor}}`; `inst{name}` | logs `LogError`, returns error; caller (`main.cpp:307-319`) logs and continues |
| `gatewayd` remote services (client side) | `score/gatewayd/impl/remote_service_instance.cpp:89-150` | `iface{name,{major, (uint16)minor}}`; `inst{name}` | n/a for the key (client duplicate path is `duplicate_client`) |
| `gatewayd` shared-memory config | `score/gatewayd/main.cpp:228-272` | same `iface`/`inst` shape, keyed by `shm_config[iface][inst]` | logs and `continue`s |

The `Service_database` record index groups by `id + major` and ignores `minor`
(`runtime_impl.hpp:116-134`), and `Service_record` holds a single `std::optional`
server guarded by `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)`
(`runtime_impl.cpp:366-371`). The changed key makes the duplicate gate as coarse as
the record index, so a second server registration that shares `(instance, id, major)`
but differs only in `minor` is rejected with `Construction_error::duplicate_service`
at the set insert (`runtime_impl.cpp:443`, `:449-454`) rather than reaching the
single-server assert.

### 4.3 Integration-level consequences of the coarsened gate

These are source-derived, not observed (no daemon was built or run):

1. **Failure is non-fatal and silent at the daemon boundary.** At every consumer
   above, a rejected duplicate is logged and the loop continues
   (`someipd/main.cpp:185-190`, `:216-223`; `gatewayd/main.cpp:307-319`). An
   integration-level collision therefore presents as a **service that is not offered**
   rather than a startup abort. No integration test asserts the service is still
   offered after a duplicate-key rejection, and none asserts on `duplicate_service`
   at the daemon boundary.
2. **`instance` is the service type name, not the instance id/specifier.** Every
   consumer builds `socom::Service_instance` from the service type name
   (the `TODO: Handle multiple instances … just use service name again` comments at
   `gatewayd/impl/local_service_instance.cpp:51-53`,
   `gatewayd/main.cpp:233-235`, `someipd/impl/local_network_service.cpp:51-52`). The
   schema permits **arrays** of `local_service_instances`/`remote_service_instances`
   per service type, each with a distinct `instance_id`
   (`score/config/mw_someip_config.fbs:31-46`). Two instances of the same service type
   with different `instance_id` map to the same `(instance, id, major)` key; the
   minor-excluding change widens that collision to include differing-`minor`
   configurations. The shipped sample config uses one instance per service type
   (`score/config/mw_someip_config.json:14-19`, `:76-81`, `:138-143`), so the
   multi-instance path is **not exercised end to end**.
3. **The config wildcard default interacts with the coarsened key.** `service_version_minor`
   is `uint32 = 0xFFFFFFFF` ("SOME/IP wildcard meaning 'accept any minor version'",
   `score/config/mw_someip_config.fbs:21-23`) and is narrowed by
   `static_cast<std::uint16_t>(...)` at every config→socom construction site (the
   four consumers above), turning the unset default into `0xFFFF`. Under the coarsened
   key, a wildcard-narrowed `0xFFFF` server and a concrete-minor server for the same
   `(instance, id, major)` collide as `duplicate_service`, where the baseline key kept
   them distinct. This is the intersection of the bounded key change and the
   unaccepted wildcard representation already recorded by `api_review.md` §5.3-5.4
   and `compatibility.md` §5; it is a design input for the owner of #84, not something
   this review may decide.
4. **Discovery/bridge semantics are untouched.** The key set `m_service_identifiers` is
   read/written only in `Runtime_impl::make_server_connector`
   (`runtime_impl.cpp:443`, `:449-454`, `:456-463`); the `Service_database` index,
   `get_record`, and the bridge/discovery paths (`bridge_service_requests`,
   `get_bridge_reported_instances`) do not consult it. The change must remain so
   confined (`compatibility.md` §7; confirmed by direct reading this iteration).

### 4.4 Component tests that would exercise integration (none ran)

- `//score/socom/test/unit:socom_test` (tag `unit`, `test/unit/BUILD:16-29`) contains
  the key/runtime/interface/client suites; it is visible to the integration package
  (`:22`) and packaged into `score-test-applications-pkg`
  (`tests/integration_test/BUILD:65-77`).
- `//score/gateway_ipc_binding/test:gateway_ipc_binding_test` (tag `component`,
  `score/gateway_ipc_binding/test/BUILD:17-38`) links `//score/socom` and exercises
  the IPC boundary; it is packaged into the same QEMU target
  (`tests/integration_test/BUILD:65-77`, `score_test_applications.py:19-24`).
- Neither was built or run: `native_tests` and `native_integration` are `exit 127`
  (missing `bazel`).

---

## 5. Feature integration review

### 5.1 No feature requirement for `socom` version handling

`docs/requirements/feature/index.rst` is a placeholder whose toctree is empty and
whose note says to "Add feature requirement files … as they are created"
(`:15-32`). The only populated feature requirement in the checkout is
`feat_req__tc8_conformance__conformance`
(`docs/tc8_conformance/requirements.rst:24-39`), which is about wire-level TC8
protocol conformance of `someipd`, not about `socom` identity/version handling.
There is consequently **no feature requirement** against which a feature-integration
test for the duplicate-server registration key could be linked, and no feature
architecture artifact specific to version handling was found.

### 5.2 Feature-level test types not performed

Per `verification_plan.rst:167-207`, `interface-test` and `requirements-based` are
applicable at Level 2 feature integration, and resource-usage "only on reference
environment". None of these was performed for this slice: there is no
feature-integration target for `socom` version handling, no reference-environment
resource evaluation, and no fuzz/fault-injection harness
(`verification_plan.rst:234-236`, `:265-270`; confirmed absent by `glob` over
`tests/**`). Identifier-only unit tests must **not** be labelled feature- or
platform-integration verification.

### 5.3 CI reference integration execution

`gd_req__verification_ci_reference_execution` (`verification_process.rst:250-264`)
requires the CI reference integration to run regularly to guarantee component
inter-operation, and itself carries a TODO to align with
`eclipse-score/reference_integration#190`. In this checkout the native/CI legs did
not run (`native_*` `exit 127`), so this obligation is **not demonstrably satisfied**
for the changed component. The requirement is also marked with an open alignment TODO
in the pinned source, so its applicability to this slice is unresolved.

### 5.4 Open design reuse from prior reports

The feature-scope questions recorded by `scope.md` §4-5 and `api_review.md` §6
(public `Service_interface_identifier` restructure; FindService
`optional<minor>`/`optional<instance>`; `major = FF` wildcard; config wildcard
resolution) remain unaccepted human decisions. None is implemented in this bounded
slice.

---

## 6. Interface-test review

### 6.1 What exists

- `score/socom/test/unit/interface_compatibility_tests.cpp` is a parameterized
  `TEST_P(InterfaceCompatibilityTest, …)` suite (gtest `TEST_P`, `:73`, `:91`) that
  exercises the exact-major / minimum-minor connect–no-connect matrix through the
  real connector factory: `Identifier` parameters (`:179-188`) and `Version`
  parameters (`:190-211`) including client minor lower-than-or-equal (connect),
  client minor greater (no-connect), major mismatch (no-connect), and both
  `max_version` (connect). This is the interface-behaviour suite most relevant to
  the version semantics around the changed key.
- `score/socom/test/unit/client_tests.cpp` carries the client-side minor-version
  cases cited by prior reports (e.g. bigger/smaller interface minor).
- `runtime_tests.cpp:402-431`
  `ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError` and its
  neighbours (`:334`, `:350`, `:440-505`, `:642`, `:694`, `:905`, `:986`) exercise
  the `Runtime::make_server_connector` registration entry point, including duplicate,
  different-major, different-service-id, different-instance, enabled/lifetime, and
  slot-isolation cases.
- The Python integration/ITF tests (`tests/integration_test/*.py`,
  `tests/tc8_conformance/**`) exercise daemon startup, SOME/IP-SD emission, tcpdump
  capture, and TC8 wire conformance; they are network/interface tests, not
  `socom`-identity tests.

### 6.2 Interface-test metadata is absent or incomplete

The C++ obligation `gd_req__verification_checks` requires `TestType` and
`DerivationTechnique` to be set and `Description` non-empty
(`verification_process.rst:189-196`); `gd_req__verification_checks_extended` requires
that a `TestType == interface-test` test links to at least one interface
(`:211-212`). Direct reading of the candidate tests and the retained
`process_checks` metadata inventory shows:

- The candidate tests set only `DerivationTechnique` and `Description`
  (`process_checks/result.json:244-262`). **`TestType` is unset** and **no
  `Verifies`/`PartiallyVerifies`/`FullyVerifies` links exist**.
- `interface_compatibility_tests.cpp` and `client_tests.cpp` carry no record-property
  metadata at all and are not in the candidate set.
- No Python test in the repo uses the metadata decorator:
  `grep 'add_test_properties|test_type=|derivation_technique='` over `tests/**`
  returns **no matches**, so the `gd_req__verification_link_tests_python` metadata
  path is unused.

The reason `TestType`/`Verifies` are unset is legitimate in one respect — no verified
native requirement/interface identity exists for this slice, and inventing one is
prohibited (prior reports; `authority.json` unknowns). But the consequence must be
stated plainly: the C++ metadata checks are **not satisfiable as the tree stands**,
and because there is no interface identity to link, an `interface-test` designation
for this slice cannot satisfy the extended check either.

### 6.3 Interface-test execution status

None of the interface suites was executed. `//score/socom/test/unit:socom_test`
(which contains them) could not be built (`native_tests` `exit 127`), and the focused
host measurement compiles only
`service_identifier.cpp` + `string_registry.cpp` + `service_identifier_tests.cpp`
plus googletest — it does **not** include `interface_compatibility_tests.cpp` or
`client_tests.cpp`. The exact-major/minimum-minor behaviour is therefore
source-read-only in this checkout (also recorded by `compatibility.md` §5-6).

---

## 7. Platform integration and QEMU results

### 7.1 The QEMU integration targets and what they would cover

`tests/integration_test/BUILD` defines six `integration_test` targets
(`:79-163`) that run under the `--config=qemu-integration` configuration on the
POSIX reference environment:

| Target | Coverage |
|--------|----------|
| `test_score_test_applications` | Runs packaged test binaries on the target: `gateway_ipc_binding_test`, `null_serializer_test`, `socom_stress_test`, **`socom_test`** (`score_test_applications.py:19-24`, `:50-59`) |
| `test_gateway_startup` | `gatewayd` starts, stays alive, and terminates (`gatewayd_startup.py:22-45`) |
| `test_someipd_startup` | `someipd` starts, stays alive, prints the expected OFFER line, terminates (`someipd_startup.py:19-43`) |
| `test_someipd_sends_someip-sd_message` | `someipd`+`gatewayd` emit SOME/IP-SD that tcpdump captures (`someipd_sends_someip-sd_message.py:22-26`) |
| `test_tcpdump` | capture infrastructure |
| `test_someipd_started_by_test` | someipd/gatewayd lifecycle |

The relevant point for this slice is that `test_score_test_applications` **would run
`//score/socom/test/unit:socom_test` on the emulated target** — i.e. the
key/runtime/interface suites, including the minor-only duplicate regression, would
execute under QEMU. The other five targets exercise daemon startup / SD emission but
do **not** assert duplicate-server registration semantics.

Additionally, `tests/tc8_conformance/**` is a QEMU ITF suite against `someipd`
(`tc8_itf_conftest.py:13-18`, TC8 requirements at
`docs/tc8_conformance/requirements.rst:24-270`). It is wire-conformance focused and
does not touch `socom` identity.

### 7.2 QEMU results: not run

The retained `native_integration` collection is a failure to run, not a result:

- Command attempted: `bazel test --jobs=2 --config=qemu-integration //quality/...
  //tests/integration_test/...` (`native_integration/result.json:236-265`).
- Cause: `[Errno 2] No such file or directory: '/tmp/s-core-001/bin/bazel'`,
  `exit_code: 127` (`:263-264`).
- Status: `findings_or_execution_failure` (`:267`).
- Prerequisites recorded but not substituted for a run: `kvm_exists: true`,
  `qemu: /usr/bin/qemu-system-x86_64` (`:271-274`).

Therefore there are **no QEMU results** for this slice: no target run of
`socom_test`, no daemon-startup observation, no SOME/IP-SD capture, and no TC8
result. KVM/QEMU availability is not a QEMU run. `native_performance` (benchmarks,
`--config=perf-tests`) likewise exited `127`, so the resource-usage method applicable
at Level 2/3 (`verification_plan.rst:203-207`, `:216-219`) was not performed.

### 7.3 Cross-compilation and target OS

The toolchain configuration pins GCC/Clang for `x86_64`/`aarch64` Linux and QCC for
`x86_64`/`aarch64` QNX (`MODULE.bazel:83-193`), with QNX imagefs toolchains
(`:342-363`). The `cross_compilation` obligation attempted
`--config=x86_64-linux` and `--config=aarch64-linux` and failed `exit 127` (missing
`bazel`) with the blocker *"QNX SDK entitlement and target execution not configured;
no credential acquired"* (`native_*` reports; `native_build_review.md` §4.1). So the
S-CORE reference target matrix (Linux/QNX × x86_64/aarch64) was not exercised.

---

## 8. External-component Assumptions-of-Use (AoU) review

### 8.1 The obligation

`gd_req__verification_external_aou` (`verification_process.rst:214-226`):

> "External components AoUs shall be verified by integration tests or static analysis
> tooling." Note 1: "These external components AoU need to be checked generally for
> the complete platform, so we create a process automation requirement for this."
> Note 2 gives the example "safety components are only using 'safe' functions of the
> operating system".

This satisfies `wf__verification_comp_int_test` and `wf__verification_feat_int_test`.
It is a **platform-wide process obligation**, and the platform AoUs it derives from
(`aou_req__platform__testing`, `aou_req__platform__test_completion`,
`verification_plan.rst:608`) are not defined in this checkout. The module can still
be reviewed for (a) which external-component assumptions its code actually relies on,
and (b) whether any integration test or static-analysis tool verified them. Both are
addressed below.

### 8.2 External components actually pulled in

From `MODULE.bazel` (read this iteration), the dependencies whose behaviour the
gateway assumes are:

| External component | Version / pin | Why the gateway relies on it (AoU surface) |
|--------------------|---------------|--------------------------------------------|
| `vsomeip` (SOME/IP stack) | `3.6.1`, patched `vsomeip-qnx8.patch`, `vsomeip-no-werror.patch` (`MODULE.bazel:303-316`) | `someipd` maps SOCM events to vsomeip `notify`/`subscribe`/`request_service` and reads `get_interface_version`/`get_message_type` (`someipd/impl/remote_network_service.cpp:83-165`); AoU: minor/interface-version handling, eventgroup behaviour, thread-safety, QNX patched behaviour |
| `score_baselibs` | `0.2.13`, patched `restore_qnx8_poll_workaround.patch` (`:249-256`) | `futurecpp` (`SCORE_LANGUAGE_FUTURECPP_ASSERT`), `mw/log`, `result`, `message_passing`; AoU: **assert semantics** (terminate vs compiled-out), poll workaround on QNX8 |
| `score_communication` / `mw::com` | `0.3.0`, git override `d609be92…` (`:239-244`) | `gatewayd` `GenericProxy`/`GenericSkeleton`, `InitializeRuntime` (`gatewayd/main.cpp:206-207`, `remote_service_instance.cpp:245-253`); AoU: find-service lifecycle, shared-memory contract |
| `message_passing` | via `score_baselibs`/`score_communication` | IPC server/client sockets; AoU: QNX `qnx_dispatch` resource exhaustion already documented in `score_test_applications.py:62-72` |
| FlatBuffers | `25.12.19` (`:269`) | config schema/generated accessors; AoU: default `0xFFFFFFFF` minor and `uint8` major widths |
| `boost` | `1.87.0`, patched (`:287-301`) | transitive (via `rules_foreign_cc`/vsomeip); AoU: QNX asio patch |
| `rules_foreign_cc` | `0.15.1`, patched (`:275-283`) | builds vsomeip; AoU: network/`proc_self_cwd` patches |
| `googletest` | `1.18.0` (`:59`) | unit tests; AoU: `-Wdeprecated-declarations` under clang `-Werror` (the only retained nonzero compiler exit) |
| LLVM toolchain | `22.1.7` (`:165-193`) | Bazel C++ toolchain; AoU: sanitizer feature set |
| QNX SDP toolchains / imagefs | QCC 12.2.0, SDP 8.0.4 (`:117-157`, `:342-363`) | target build/run; AoU: SDK entitlement/credentials |
| `score_itf`, `os_images`, `score_rules_imagefs` | `score_itf` git override `38ae9a3d…`; `os_images` git override `6d493760…` (`:321-340`) | QEMU target execution; AoU: /opt mount, QEMU ping timeout patch |

### 8.3 Are the AoUs verified here?

**No.** Concretely:

1. **No integration test ran** that would verify any external-component AoU: the QEMU
   integration legs exited `127` (§7.2), and the daemon/TC8 integration tests are
   startup/SD-focused, not AoU-focused.
2. **No static-analysis tool produced a verdict on the AoU surface**: clang-tidy
   `--verify-config` exited `1` (config blocker, "not run", not "clean");
   `codeql_security`/`codeql_misra` findings are confined to `.llm_tmp/googletest/**`
   and gtest macro expansions with `level: null` and a `:status: draft` MISRA mapping;
   `focused_cppcheck` exited `2` with findings outside the candidate paths.
3. **The most load-bearing AoU for the changed key path — the semantics of
   `SCORE_LANGUAGE_FUTURECPP_ASSERT` — is explicitly undetermined.** The pre-change
   failure mode (terminate vs compiled-out overwrite at
   `runtime_impl.cpp:369`) depends on `score_baselibs` behaviour that is external and
   "not determined in this checkout" (`api_review.md` §4.1, §7.2). The changed key
   removes the minor-only reachability, but the AoU itself remains unverified.
4. **The unset wildcard default is an unverified external-schema AoU**: FlatBuffers
   supplies `service_version_minor = 0xFFFFFFFF` when the JSON omits it
   (`mw_someip_config.fbs:21-23`), and the code narrows it without a range/wildcard
   check. No integration test verifies the resulting collision behaviour (§4.3.3).
5. **No AoU requirement register exists in the repo.** `docs/requirements/index.rst:94-96`
   and `docs/requirements/component/index.rst:26-27` document the
   `aou_req__<component>__<title>` naming scheme but define no AoU, and no
   component requirement file exists. The external-component assumptions the code
   relies on are therefore not captured as reviewable AoU artifacts at all.

### 8.4 Disposition

`gd_req__verification_external_aou` is **not satisfied** for this slice: the external
components' AoUs are neither integration-tested nor statically analysed in this
checkout, the platform AoU requirements it derives from are absent, and the module
does not even define AoU requirements for the components it assumes. This is an
explicit pending item for the human gate and the platform process owner, not a
finding this review may close.

---

## 9. Missing requirement links

### 9.1 Requirement hierarchy actually present

`docs/requirements/index.rst:28-50` defines the three-level hierarchy
(stakeholder → feature → component). The checkout contains:

| Level | Present | Coverage relevant to this slice |
|-------|---------|--------------------------------|
| Stakeholder | `stkh_req__someip_gw__interoperability` (`docs/requirements/stakeholder.rst:23-35`) | SOME/IP wire interoperability; not `socom` identity |
| Feature | `feat_req__tc8_conformance__conformance` (`docs/tc8_conformance/requirements.rst:24-39`) | TC8 wire conformance of `someipd`; not `socom` version handling |
| Component | eight `comp_req__tc8_conformance__*` (`docs/tc8_conformance/requirements.rst:55-223`) | TC8 SD/message/event conformance; not `socom` |
| Component/Feature indices | `docs/requirements/component/index.rst`, `docs/requirements/feature/index.rst` | **empty placeholders (`:15-32`, `:15-35`)** |
| AoU | none defined | naming scheme only (`component/index.rst:26-27`) |

### 9.2 Consequence

- **No `comp_req__socom__*` exists** for the duplicate-server registration key, the
  minor-version exclusion, or the exact-major / minimum-minor rules. There is
  therefore **no component requirement to link** the unit tests to.
- `gd_req__verification_checks` requires that "If Partially/FullyVerifies are set in
  Unit Test these shall link to at least one Component Requirement"
  (`verification_process.rst:196`). Because no such requirement exists and inventing
  one is prohibited, the candidate tests set no link at all.
- `process_checks` states the exact limitation: *"Lexical metadata inventory cannot
  prove semantic requirement coverage"* (`process_checks/result.json:236`), and
  records that the candidate test files carry only `DerivationTechnique` and
  `Description` (`:244-262`).
- `native_traceability` (`bazel test //:unit_tests //:component_tests`; `bazel run
  //:docs`; `bazel run //:traceability_gate -- --need-type=comp_req`) exited `127`
  (missing `bazel`), so no traceability gate ran.
- The Python integration tests carry no metadata (`grep` for the metadata decorator
  returns nothing), so `gd_req__verification_link_tests_python` is unused.

**Bottom line:** the bounded slice has **no requirement links**, no requirement to
link to, and no traceability execution. The missing links are a genuine gap that the
human gate must disposition — either by authoring the `socom` component requirement(s)
and linking the tests, or by recording an approved tailoring/deviation. This review
may not invent the identifiers.

---

## 10. Integration / AoU findings register

Each finding is local, scoped, and unaccepted. None is a closed defect.

| # | Finding | Evidence | Status |
|---|---------|----------|--------|
| I-1 | The QEMU integration suite (including the target run of `socom_test`) did not execute | `native_integration/result.json:236-275` (`exit 127`, bazel missing; KVM/QEMU present) | **NOT RUN** |
| I-2 | A duplicate-key rejection at the daemon boundary is logged and skipped, so a collision surfaces as a silently unoffered service | `someipd/main.cpp:185-190`, `:216-223`; `gatewayd/main.cpp:307-319`; `remote_network_service.cpp:69-74`; `local_service_instance.cpp:75-80` | **UNVERIFIED** (no daemon built/run) |
| I-3 | The `socom` instance is the service type name, not `instance_id`/specifier, so multiple instances of one service type collide; the minor-excluding key widens this to differing-minor configs | `local_service_instance.cpp:51-53`; `gatewayd/main.cpp:233-235`; `local_network_service.cpp:51-52`; schema `mw_someip_config.fbs:31-46`; sample `mw_someip_config.json` uses one instance/type | **KNOWN TODO + widened collision** |
| I-4 | Config minor wildcard `0xFFFFFFFF` narrows to `0xFFFF` and now collides with a concrete minor under the coarsened key | `mw_someip_config.fbs:21-23`; four `static_cast<uint16_t>` sites (`remote_network_service.cpp:44-45`, `local_network_service.cpp:48-49`, `local_service_instance.cpp:48-49`, `remote_service_instance.cpp:91-92`, `main.cpp:231-232`); key `service_identifier.cpp:28-29` | **UNRESOLVED design input** |
| I-5 | No feature requirement, no component requirement, and no AoU requirement exist for this slice | `docs/requirements/feature/index.rst:15-32`; `component/index.rst:15-35`; `stakeholder.rst`; `tc8_conformance/requirements.rst` | **MISSING LINKS** |
| I-6 | Interface-test and link metadata (`TestType`, `Verifies`/`Partially`/`FullyVerifies`) are unset or absent, so the checks cannot pass as the tree stands | `process_checks/result.json:244-262`; `verification_process.rst:189-212`; no `add_test_properties` in `tests/**` | **NOT SATISFIED** |
| I-7 | External-component AoUs (`vsomeip`, `score_baselibs`/assert semantics, `mw::com`, FlatBuffers wildcard, patched deps) are unverified by integration test or static analysis | §8; `verification_process.rst:214-226`; clang-tidy config blocker; CodeQL dependency-only; QEMU not run | **NOT SATISFIED** |
| I-8 | CI reference-integration execution did not run and its pinned requirement carries an open alignment TODO | `verification_process.rst:250-264`; `native_*` `exit 127` | **NOT SATISFIED / unresolved applicability** |
| I-9 | Cross-compilation and the target OS matrix (QNX `x86_64`/`aarch64`) were not exercised | `MODULE.bazel:117-157`, `:342-363`; `cross_compilation` `exit 127` + QNX entitlement blocker | **NOT RUN** |
| I-10 | The only executed measurement is a focused host identifier TU and is stale against the 87-case tree | §8.2; `process_checks/result.json:244-262` (87 macros); retained `after.json` has 85 | **STALE, focused** |

---

## 11. Obligations status (none satisfied)

### 11.1 Pinned state

All nine pinned sources read; every `source-index.json` entry is
`"native_acceptance": "not_inferred"`. `authority.json`: `engineering_acceptance:
pending`, `human_reviews: unanswered`, `safety_class: unknown`.

### 11.2 Status for this slice

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Component (Level 1) integration/verification executed | `verification_plan.rst:121-132` | **NOT RUN** — focused host TU only; `socom_test`/`gateway_ipc_binding_test` not built |
| Feature (Level 2) integration verification | `verification_plan.rst:133-137`; `verification_process.rst:193-195` | **NOT PERFORMED / no feature requirement** |
| Platform (Level 3) integration on reference hardware | `verification_plan.rst:138-150`, `:590-608` | **NOT RUN** — reference hardware "not yet decided"; QEMU leg `exit 127`; final-product integration is the integrator's obligation |
| Interface-test method | `verification_plan.rst:195-198`; `verification_process.rst:211-212` | **SOURCE-ONLY** — `interface_compatibility_tests.cpp` neither executed nor metadata-linked |
| Requirements-based test method | `verification_plan.rst:199-202` | **NOT PERFORMED** — no linked requirement |
| Resource-usage evaluation | `verification_plan.rst:203-207` | **NOT PERFORMED** — `native_performance` `exit 127` |
| Fault injection / fuzz | `verification_plan.rst:234-236`, `:265-270` | **NOT EXECUTED / NOT CLAIMED** — no harness, no measurement |
| External-component AoUs verified | `verification_process.rst:214-226` | **NOT SATISFIED** — no integration test or static-analysis verdict; no AoU register |
| CI reference-integration execution | `verification_process.rst:250-264` | **NOT SATISFIED / applicability TODO** |
| Linking tests to requirements/interface (`TestType`, `Verifies`) | `verification_process.rst:20-54`, `:178-212` | **NOT DONE** — only `DerivationTechnique`/`Description`; no requirement or interface to link to |
| Independence of verification / review | `verification_process.rst:141-152` | **NOT DONE** — human reviews unanswered |
| QEMU / native integration results retained | `.llm_tmp/overnight/obligations/native_integration/result.json` | **FAILED TO RUN** (`exit 127`) — retention ≠ passing |
| Traceability gate | `native_traceability` obligation | **NOT RUN** (`exit 127`) |
| Freedom from compiler warnings & errors (criterion 9) | `verification_plan.rst:332-335` | **PARTIAL** — focused GCC clean; clang blocked on a dependency; no native build |
| Native acceptance | `source-index.json` | **`not_inferred` for every entry** |

**Explicit non-satisfaction statement.** The missing native driver (`bazel`) and
supporting tools, the non-running QEMU integration and cross-compilation, the
non-running static analysis, the absence of any requirement/interface link, the absent
AoU register, the `not_inferred` applicability, the stale focused measurement, and the
unanswered human reviews mean **none of the checked obligations may be treated as
satisfied**. A successful collection node proves *retention*, not passing.

---

## 12. Measurement and validation status

- **Tools used:** `read_file`, `grep`, `glob`, `write_file` only. No `shell`,
  delegation, web, approval, publishing, or engineering acceptance.
- **Executed measurements by this iteration:** **none**. No build, no test, no daemon,
  no QEMU, no static analysis.
- **Genuine retained measurements (present, scoped, unprotected):** focused host
  `g++-12` identifier TU (`before` 28 failures → `candidate` 0 failures over 83–85
  cases, `compile_exit: 0`, UBSan per `measurement.json`); focused ASan/LSan exit `0`;
  focused coverage 100 % line / 78.6 % branch; CodeQL security/MISRA focused
  (dependency/gtest-macro findings, `level: null`); cppcheck exit `2` out of scope.
- **Not run:** every Bazel target and config; QEMU integration; cross-compilation
  (x86_64/aarch64, Linux/QNX); benchmarks/profiling; `valgrind`, `gitleaks`,
  `pre-commit`, `reuse`, `clang-format`; clang-tidy analysis; `runtime_tests.cpp`,
  `interface_compatibility_tests.cpp`, `client_tests.cpp`, and every daemon.
- **Test inventory (read, not run):** `service_identifier_tests.cpp` = **87 `TEST_F`**
  (`:168`…`:2012`, verified this iteration by `grep` and matching
  `process_checks/result.json` `test_macros: 87`); `runtime_tests.cpp` = **31 `TEST_F`
  + 1 `TEST` + 1 `TEST_P`** (`test_macros: 33`); `interface_compatibility_tests.cpp`
  = 2 `TEST_P` instantiations (`Identifier`, `Version`, `:179-211`). The retained
  `after.json` executed 85 identifier cases — stale by two (`:1982`, `:2012`).
- **Scope:** local, unprotected, scoped. This draft has not been reviewed, accepted,
  published, or reproduced on a full native runtime. Unit/integration execution and
  human review remain pending.
- **Reproduction path for a later, authorized iteration (not executed here):**

  ```bash
  bazel build //score/...
  bazel test //score/...
  bazel test //score/socom/test/unit:socom_test
  bazel test --config=qemu-integration //quality/... //tests/integration_test/...
  bazel build --config=x86_64-linux //score/... //tests/...
  bazel build --config=aarch64-linux //score/... //tests/...
  bazel run //:traceability_gate -- --need-type=comp_req
  ```

  Expected (source-derived, not measured): the minor-only key/runtime regressions
  pass on the corrected key and fail on a key that includes `minor`; the daemon
  integration tests still start. These expectations were not observed.

---

## 13. Notice preservation

- **Only this report was written.** No source, build, test, config, `NOTICE`,
  `LICENSE`, `REUSE.toml`, host-validation, or prior-report file was created, edited,
  or deleted. Every report under `.llm_tmp/overnight/reports/` and every file under
  `.llm_tmp/overnight/prior-reports/` was preserved unchanged.
- The header the task flagged (`score/socom/impl/service_identifier.hpp`) retains its
  Apache-2.0/SPDX comment (`:1-12`) and was left unchanged because it is already
  balanced (§2). The sibling `service_identifier.cpp` (`:1-12`), both BUILD files, and
  both candidate test files retain their Apache-2.0/SPDX headers; the integration and
  TC8 test sources read here also carry Apache-2.0 headers.
- The duplicate key remains an `impl/`-only type exposed only through the `testonly`
  `//score/socom:impl_service_identifier` library, so no public header or notice
  surface changed.
- This report itself carries the Apache-2.0 header. No licensed SOME/IP/AUTOSAR/TC8
  text is reproduced; only native requirement/query identifiers and file locations are
  cited.

---

## 14. Pending human review checklist

- [ ] **Confirm §2:** `service_identifier.hpp` is brace-balanced (brace lines
      `:19,:29,:32,:38`; line 39 blank; net balance 0); the recorded "extra closing
      brace at line 39" is stale or refers to a different revision. No correction is
      required in this checkout. If a distinct "cancelled draft" revision still
      carries the brace, locate and correct it by an authorized iteration.
- [ ] **Resolve the instruction conflict:** "Inspect and correct the actual source"
      vs. "this is a review draft: only that report may be written". Confirm that
      writing only this report, with a no-op on already-correct source, is intended.
- [ ] **Decide the S-CORE/integrator split for this slice (§3):** confirm that
      final-product platform integration remains the integrator's obligation, that
      the S-CORE reference-hardware leg is the only in-scope platform activity, and
      that "the reference hardware is not yet decided" is accepted as an open item.
- [ ] **Restore the native driver and tools** (`bazel` at
      `USE_BAZEL_VERSION=8.6.0`, plus `valgrind`/`gitleaks`/`pre-commit`/`reuse`/
      `clang-format`) and run `native_build`, `native_tests`, `native_integration`
      (QEMU), `native_performance`, `cross_compilation` (incl. QNX entitlement), and
      `native_traceability`.
- [ ] **Author the missing requirement links (§9):** add the `socom` component
      requirement(s) (and any feature requirement) for the duplicate-server
      registration key / version handling, then link the candidate tests' `TestType`
      and `Verifies`/`Partially`/`FullyVerifies`; or record an approved
      tailoring/deviation. Do not invent identifiers.
- [ ] **Complete interface-test metadata (§6)** and decide whether
      `interface_compatibility_tests.cpp`/`client_tests.cpp` are in scope for the
      `interface-test` method and its interface link.
- [ ] **Verify the external-component AoUs (§8)** by integration test or static
      analysis, and author the AoU requirements (including the
      `SCORE_LANGUAGE_FUTURECPP_ASSERT` semantics AoU and the FlatBuffers wildcard
      default AoU). Confirm the platform-level `aou_req__platform__testing` /
      `aou_req__platform__test_completion` linkage upstream.
- [ ] **Adjudicate the daemon-boundary behaviour (§4.3):** confirm that a
      `duplicate_service` from a minor-only or wildcard collision should be logged
      and skipped (silently unoffered service), or should be surfaced/failed
      differently; decide the multi-instance-per-service-type and wildcard-minor
      representation questions before the key change can be integration-verified.
- [ ] **Confirm the untested-path register (§6.3, §7):** `runtime_tests.cpp`,
      `interface_compatibility_tests.cpp`, `client_tests.cpp`, and all daemons were
      not built or run; the identifier-only tests must not be presented as feature or
      platform validation.
- [ ] **Do not infer passing from retained collection nodes (§11):** the QEMU,
      native, coverage, sanitizer, lint, docs, traceability, performance, and
      cross-compilation legs all failed to run; retention is not acceptance.
- [ ] **Keep the wider #84 public `Service_interface_identifier` restructure,
      FindService wildcard handling, and the config minor-wildcard narrowing out of
      this bounded slice** until separately accepted, and **do not claim an
      unmeasured fuzzy technique**.
- [ ] **Schedule independent human review** (approver ≠ author, per
      `gd_req__verification_independence`) and record engineering acceptance; no
      compliance claim may be made before that.

---

*End of review draft. Local, unprotected, scoped. No engineering acceptance; human
reviews unanswered; full native runtime tests pending. No QEMU result exists; no
requirement or interface link exists; no external-component AoU was verified; no
finding was filtered and no authorized severity rating exists.*
