<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — line and branch coverage review (`coverage_review`)

**Document type:** review draft (actual-source inspection + measured line/branch
coverage assessment against the pinned platform goals + uncovered-branch
enumeration + concrete follow-up tests + obligations status)
**Date:** 2026-10-02
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise
version handling in socom* (issue #84)
**Run:** `fabro/run/01M3YRJEGXNY6CB81T7TKW774B`
**Status:** local, unprotected, scoped. **No engineering acceptance exists.
Human reviews are unanswered. Full native runtime tests remain pending.** Every
measured number below is quoted from a *retained* `.llm_tmp/overnight`
obligation artifact; every source statement is a direct reading of this
checkout. Nothing here is accepted, approved, published, or a full native run.

> **Tool / write boundary actually observed.** Only `read_file`, `grep`, `glob`
> and `write_file` were available and were the only tools used. No `shell`, no
> delegation, no web access, no approval, no publishing, and no engineering
> acceptance. The task states: *"This is a review draft: only that report may be
> written."* Accordingly **this iteration wrote exactly one file — this report.**
> No source, build, test, config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was
> created, edited, or deleted. Every report under
> `.llm_tmp/overnight/reports/` and every file under
> `.llm_tmp/overnight/prior-reports/` was preserved unchanged.
>
> **Instruction conflict, recorded explicitly.** The task directs *"Inspect and
> correct the actual source before expanding tests"* because *"the cancelled
> draft has a measured GCC syntax failure: an extra closing brace in
> `score/socom/impl/service_identifier.hpp` at line 39."* Direct inspection shows
> the actual source is **already brace-balanced** and line 39 is **blank**
> (§2). There is therefore no defect to correct; and the task's own write
> restriction forbids writing any source path in this review draft anyway. Both
> facts are recorded rather than silently reconciled.

---

## 0. Summary

1. **The recorded "extra closing brace at `service_identifier.hpp:39`" is not
   present in the actual source.** `score/socom/impl/service_identifier.hpp` is
   40 lines and brace-balanced: two openers (line 19 `namespace score::socom {`,
   line 29 `struct Service_instance_identifier final {`) and two closers (line 32
   `};`, line 38 `}  // namespace score::socom`). Net balance `0`; line 39 is
   empty; line 40 is `#endif`. `glob **/service_identifier.hpp` returns exactly
   one path. **No correction was applied and none is required** (§2.3). This is
   independently corroborated by the retained GCC compile, which exited `0`.

2. **Measured line coverage is 100.0 %; measured branch coverage is 78.6 %.**
   The latest retained focused coverage artifact
   (`.llm_tmp/overnight/obligations/focused_coverage/result.json`, epoch
   `1790962635`, run with **87 tests / 0 failures**) records
   **36/36 lines = 100.0 %** and **11/14 branches = 78.6 %**. Against the pinned
   platform goals (`verification_plan.rst` criteria 1–2: **QM 85 % / safety
   100 %** for *both* statement and branch coverage): **line coverage meets
   both goals; branch coverage (78.6 %) meets neither the QM 85 % nor the
   safety 100 % goal.** The repository CI line threshold **73 % is separate**
   and is not the acceptance basis. The safety class is `unknown`; it is not
   chosen here, and no deviation is accepted (§3).

3. **Uncovered changed lines / branches.** The slice's changed *executable*
   production lines (`service_identifier.cpp:20, 28, 29`) are all covered; there
   are **no uncovered changed lines**. The only uncovered **changed branch** is
   the compiler-generated `throw` edge at `service_identifier.cpp:28`
   (count `0`). Within the measured executable but *not* a changed line, two
   further compiler-generated branches are uncovered: the exception edge of the
   function-local static guard at `string_registry.cpp:66` and `:71`
   (one count-`0` branch each). All three uncovered branches are
   compiler-generated and cannot be reached through the public API in normal
   execution (§4).

4. **The earlier reachable gap is now closed.** The two dynamic-insert "not
   found" branches of `String_registry` (`string_registry.cpp:38-42` and
   `:55-59`) that an earlier report flagged are covered in the latest retained
   run (line counts `1,1,2,1` / `1,1,2,1`), driven by the two added tests
   `FreshDynamicServiceIdStringViewRegistersAndCollapses` (`:1982`) and
   `FreshDynamicServiceIdRvalueRegistersAndCollapses` (`:2012`). That run is
   local and unprotected; it is retained evidence, not acceptance (§3.3).

5. **No obligation is satisfied.** A successful collection node means the
   results were *retained*, not that the checks *passed*. Missing tools
   (`bazel`, `valgrind`, `gitleaks`, `clang-format`, `pre-commit`, `reuse`),
   the Clang dependency blocker, the unknown safety class, un-inferred
   applicability, incomplete extraction (focused translation unit only) and
   unanswered human reviews mean none of the checked obligations may be treated
   as satisfied, and the branch goal is measurably unmet (§5, §6).

---

## 1. Binding to the verified baseline, pinned sources and host feedback

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` | `.llm_tmp/context/issue-snapshot.json:2-4` |
| Title | *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:3` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` | `.llm_tmp/context/issue-snapshot.json:19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not
an accepted obligation**. It proposes service-identifier = `service id + major`
and to exclude the minor version from the service identity. There is no comment
and no acceptance record, so none of it is binding.

### 1.2 Baseline and the bounded candidate paths

| Item | Value | Source |
|------|-------|--------|
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json` |

The six candidate source paths (`.llm_tmp/context/candidate-files.json`) — the
only paths this slice may change in an authorized iteration:

1. `score/socom/BUILD`
2. `score/socom/impl/service_identifier.cpp`
3. `score/socom/impl/service_identifier.hpp`
4. `score/socom/test/unit/BUILD`
5. `score/socom/test/unit/runtime_tests.cpp`
6. `score/socom/test/unit/service_identifier_tests.cpp`

The production duplicate-server registration key is
`Service_instance_identifier{Service_interface_identifier interface; Service_instance instance;}`
(`score/socom/impl/service_identifier.hpp:29-32`), whose only operator is the
out-of-line `operator<` (`service_identifier.hpp:35`). Its identity is
`(instance, service id, major)` with `minor` deliberately excluded
(`score/socom/impl/service_identifier.cpp:28-29`).

### 1.3 Pinned obligation sources read

All nine `.llm_tmp/context/obligations/source-index.json` entries are present,
with `authority.json`:

| id | file | status note (this checkout) |
|----|------|-----------------------------|
| `coding_guidelines` | `coding_guidelines.rst` | MISRA C++:2023 with C++17 |
| `code_analysis` | `code_analysis.rst` | clang-tidy + gcc/clang warnings; sanitizers; gcov/gcovr |
| `misra_mapping` | `misra_mapping.rst` | **draft** — not applied |
| `verification_plan` | `verification_plan.rst` | quality criteria 1–9; criteria 1–2 at `:300-307` (line/branch coverage), criterion 9 at `:332-335` |
| `development_plan` | `development_plan.rst` | C++17, GCC host, Bazel |
| `tool_management` | `tool_management.rst` | tools must be identified / evaluated / qualified |
| `verification_process` | `verification_process.rst` | `gd_req__verification_link_tests_cpp`, `gd_req__verification_independence`, SCA classification |
| `verification_guideline` | `verification_guideline.rst` | traceability, independence, documented results |
| `inspection_checklist` | `inspection_checklist.rst` | **draft** — not filled |

Every entry is `"native_acceptance": "not_inferred"`. `authority.json` records
`"engineering_acceptance": "pending"`, `"human_reviews": "unanswered"`,
`"safety_class": "unknown"`, and `"codeql_scope": "Public Apache-2.0
eclipse-score/inc_someip_gateway; no upload"`.

### 1.4 Pinned platform coverage goals (the yardstick used in §3)

`verification_plan.rst:292-307` defines the quality criteria to be reached with
every contribution:

| # | Criterion | Goal QM | Goal Safety |
|---|-----------|---------|-------------|
| 1 | Structural Statement Coverage (represented by Line Coverage) | **85 %** | **100 %** |
| 2 | Structural Branch Coverage | **85 %** | **100 %** |

`verification_plan.rst:340-346` explains that these structural statement/branch
percentages are represented by the reported **Line** and **Branch** coverage
values from the unit-test tooling, and that the confirmation *or any deviation*
must be documented. The safety class for this slice is `unknown` (§1.3), so
**both columns are shown and neither is selected** in this draft.

### 1.5 Prior reports, host feedback, obligation results read

- `.llm_tmp/overnight/prior-reports/` — 12 files present and preserved
  (`callsites.md`, `conversion_tests.md`, `invariants.md`, `key_fix.md`,
  `lifetime_tests.md`, `ordering_tests.md`, `reproducer.md`, `runtime_disabled.md`,
  `runtime_enabled.md`, `scope.md`, `test_metadata.md`, `unit_matrix.md`).
- `.llm_tmp/overnight/reports/` — earlier reports present and preserved
  (`analyzer_plan.md`, `api_review.md`, `bazel_plan.md`, `callsites.md`,
  `compatibility.md`, `concurrency_review.md`, `conversion_tests.md`,
  `coverage_tests_repair.md`, `invariants.md`, `key_fix.md`,
  `lifetime_review.md`, `lifetime_tests.md`, `ordering_tests.md`,
  `reproducer.md`, `runtime_disabled.md`, `runtime_enabled.md`, `scope.md`,
  `test_metadata.md`, `tool_findings_repair.md`, `unit_matrix.md`). This
  document adds `coverage_review.md`.
- `.llm_tmp/overnight/validation/` — present: `check-result` = `0`;
  `measurement.json` (`origin: local_unprotected_measurement`,
  `initiator: Fabro host hook`, `engineering_acceptance: pending`,
  `full_native_tests: not_executed`); `before.json` = **85 tests / 28
  failures**, `after.json` = **85 tests / 0 failures**. The measurement's
  `source_hashes` record `service_identifier_tests.cpp` =
  `65c10517f0afd8fe2ced30c940158d1debec465895f9c154be1eeef1cd0eb675` (the
  85-test state), i.e. the host validation capture **predates** the 87-test
  focused coverage artifact quoted in §3.
- `.llm_tmp/overnight/obligations/*/result.json` — present (24 checks). The two
  used here are `focused_coverage/` (raw coverage, §3) and
  `compiler_diagnostics/` (§2.3). `native_coverage/result.json` is
  `findings_or_execution_failure` because `bazel` is missing
  (`/tmp/s-core-001/bin/bazel`, exit 127); `process_checks/result.json` is
  `completed_with_blockers` and inventories the test metadata (§5.3).

Per the task rule, a successful collection node means results were **retained**,
not that checks **passed**.

---

## 2. The recorded GCC syntax failure — inspection of the actual source

### 2.1 Direct reading (this iteration)

`score/socom/impl/service_identifier.hpp` read from the working tree:

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers and two closers give net brace balance `0`. `glob
**/service_identifier.hpp` returns exactly one path
(`score/socom/impl/service_identifier.hpp`), so there is no second,
differently-braced copy. **There is no third, unmatched closing brace and line
39 contains no text.**

### 2.2 Why the claim is stale

The task's "extra closing brace … at line 39" matches the earliest
pre-correction description recorded by the prior reports (which quote lines
38–39 as the split form `}  // namespace socom` + `}  // namespace score`). The
committed/shared state in this checkout uses the repository's *nested open +
single close* convention, exactly like its sibling `impl/service_identifier.cpp`
(closers at `:32`). The correction is already present.

### 2.3 Retained compiler evidence (read, not produced here)

`.llm_tmp/overnight/obligations/compiler_diagnostics/result.json` (epoch
`1790962624`) records a focused GCC compile of `service_identifier.cpp` +
`string_registry.cpp` + `service_identifier_tests.cpp` with
`g++-12 -std=c++17 -Wall -Wextra -Werror`:

- `gcc-compile` → **exit 0** (`gcc-compile.stderr` is empty);
- `gcc-tests` → exit 0;
- `clang-compile` → exit 1, but **not** on the header: the sole diagnostic is
  `stl_tempbuf.h:263: 'get_temporary_buffer<testing::TestInfo *>' is deprecated
  [-Werror,-Wdeprecated-declarations]` reached through
  `.llm_tmp/googletest/googletest/src/gtest-all.cc` — the known
  googletest/libstdc++ 12 dependency blocker, not a syntax error.

The recorded `service_identifier.hpp` hash in that artifact
(`bdce3fcbc3cd78a8ecaece1ea36107d464011ab81c9bc39932d0be617befaea9`) is the
brace-balanced header read in §2.1.

### 2.4 Minimal repair (retained for reference only; not applied)

Should the imbalance ever reappear, the minimal correction — matching the
sibling `.cpp` — is:

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

Applying this to the already-balanced file would be a no-op at best; removing a
brace from a balanced header would *create* the reported defect. **No source
edit was made, because (a) there is no defect and (b) this review draft may
write only this report.**

---

## 3. Measured line and branch coverage assessment

### 3.1 Basis artifacts

| Artifact | What it records |
|----------|-----------------|
| `.llm_tmp/overnight/obligations/focused_coverage/result.json` | latest focused run; `check_ref: recollect_focused_coverage`; `origin: local_unprotected_measurement`; `engineering_acceptance: pending` |
| `.llm_tmp/overnight/obligations/focused_coverage/coverage-summary.json` | gcovr summary: line 36/36, branch 11/14 |
| `.llm_tmp/overnight/obligations/focused_coverage/coverage.json` | per-line/branch counts used in §4 |
| `.llm_tmp/overnight/obligations/focused_coverage/tests.json` | **87 tests, 0 failures, 0 disabled** (`ServiceInstanceIdentifierTest`, timestamp `18:37:23Z`) |

The focused executable compiles `score/socom/impl/service_identifier.cpp` +
`score/socom/impl/string_registry.cpp` + `service_identifier_tests.cpp` with
`g++-12 -std=c++17 -Wall -Wextra -Werror --coverage`, runs it, then runs
`gcovr --filter score/socom/impl/` (all three commands `exit_code: 0`). The
production filter is `score/socom/impl/`; tests and third-party are excluded.

### 3.2 Result against the platform goals

| Metric | Measured | QM goal | Safety goal | Verdict |
|--------|----------|---------|-------------|---------|
| Line (statement) coverage | **36/36 = 100.0 %** | 85 % | 100 % | **Meets** QM and safety |
| Branch coverage | **11/14 = 78.6 %** | 85 % | 100 % | **Meets neither**; below QM by 6.4 pp, below safety by 21.4 pp |

`coverage-summary.json` confirms the total and the per-file split:

| File | Line | Branch | Note |
|------|------|--------|------|
| `score/socom/impl/service_identifier.cpp` | 3/3 (100 %) | **1/2 (50 %)** | only uncovered branch is the compiler `throw` edge at `:28` |
| `score/socom/impl/string_registry.cpp` | 33/33 (100 %) | **10/12 (83.3 %)** | two uncovered compiler guard branches at `:66`, `:71` |
| **Total** | **36/36 (100 %)** | **11/14 (78.6 %)** | |

**Safety-class handling.** `authority.json` sets `safety_class: unknown` and the
focused result records `safety_class: unknown_requires_authorized_selection`.
This draft does **not** choose QM or safety and does **not** accept a deviation.
Because the branch number is below *both* the QM 85 % and the safety 100 %
goals, branch coverage fails regardless of which class is eventually selected;
only the line metric changes classification (QM met, safety met at 100 %).

**CI threshold is separate.** The repository CI line threshold of 73 %
(recorded as a limit in `native_coverage/result.json`) is a different gate and
is not the platform acceptance basis. Line 100 % passes it; it does not excuse
the branch shortfall.

### 3.3 The earlier reachable gap is closed by the added tests

An earlier retained capture (`focused_coverage/result.json`, epoch ~`1790961914`)
recorded **28/36 lines (77.8 %) and 9/14 branches (64.3 %)**, with the
`String_registry` dynamic-insert "not found" branches at `:38-42` and `:55-59`
never taken. The latest retained run (87 tests) shows those paths covered:

- `insert(std::string_view)` (`:34-46`): `:38` branches both taken
  (`{1 fallthrough, 40 fallthrough}`); `:39,40,41,42` counts `1,1,2,1`.
- `insert(std::string&&)` (`:48-63`): `:55` branches both taken
  (`{1 fallthrough, 31 fallthrough}`); `:56,57,58,59` counts `1,1,2,1`.

The two new tests that drive this are present in the current test source:
`FreshDynamicServiceIdStringViewRegistersAndCollapses`
(`score/socom/test/unit/service_identifier_tests.cpp:1982`) and
`FreshDynamicServiceIdRvalueRegistersAndCollapses` (`:2012`). They insert a
per-run-unique (configuration-shaped) id text through each dynamic overload and
pin that two constructions differing only in `minor` collapse to one
`(instance, service id, major)` key. This is retained, local, unprotected
evidence — **not** acceptance, and the 87-case suite is not executed by the
native Bazel target here.

### 3.4 Native/broader coverage is not measured

`native_coverage/result.json` is `findings_or_execution_failure` because the
coverage command failed to launch `bazel`
(`[Errno 2] ... '/tmp/s-core-001/bin/bazel'`, exit 127). Thus no statement or
branch coverage figure exists for the full `socom_test` / `//score/...` scope;
the §3.2 numbers are the **focused** executable only (`complete_target_scope:
false` in the retained result). The branch shortfall is therefore a *lower
bound on the problem*, not a complete platform-wide measurement.

---

## 4. Uncovered changed lines / branches

### 4.1 Changed production surface of this slice

The slice changes are the registration-key identity and its documentation:

- `score/socom/impl/service_identifier.cpp:20-30` — `operator<`, whose
  executable lines are `:20` (signature), `:28-29` (the `std::tie` comparison);
  `:21-27` are the explanatory comment;
- `score/socom/impl/service_identifier.hpp:21-32` — the `minor`-exclusion
  documentation and the `Service_instance_identifier` declaration
  (declaration-only, no executable lines);
- test-only changes in `service_identifier_tests.cpp` (not production).

**Uncovered changed *lines*: none.** `coverage.json` gives
`service_identifier.cpp:20` count `1091415`, `:28` count `1091415`, `:29` count
`2182830` — all non-zero.

### 4.2 Uncovered branches (exhaustive)

| # | Location | Branch kind | Count | Classification |
|---|----------|-------------|-------|----------------|
| 1 | `score/socom/impl/service_identifier.cpp:28` | `throw` edge of the `std::tie` comparison (`{count: 1091415, fallthrough: true}` vs `{count: 0, throw: true}`) | **0** | **changed branch**, compiler-generated |
| 2 | `score/socom/impl/string_registry.cpp:66` | exception edge of the function-local static guard in `service_id_registry()` (`{1,true},{1805,false},{1,true},{0,false}`) | **0** | in measured scope, not a changed line, compiler-generated |
| 3 | `score/socom/impl/string_registry.cpp:71` | exception edge of the function-local static guard in `instance_id_registry()` (`{1,true},{1763,false},{1,true},{0,false}`) | **0** | in measured scope, not a changed line, compiler-generated |

All three uncovered branches are GCC-generated exception/guard edges. The
comparison components (`Service_instance::operator<` and
`Registry_string_view::operator<` over pointers/`std::uint16_t`/string views)
do not throw in normal use, and the `String_registry` static constructors do not
throw observably; these edges can only be taken if a constructor/comparison
throws, which the public API cannot induce without undefined behaviour or a
fault-injection seam. **There are no reachable logic branches left uncovered in
the changed code**: `:38`/`:55` and their bodies are covered (§3.3), and the
major/service-id/instance ordering branches are exercised by the 87-case matrix.

### 4.3 Why the branch goal is structurally hard to reach with tests alone

`11/14 = 78.57 %`. To reach the QM 85 % branch goal a run needs at least
`ceil(0.85 × 14) = 12/14 = 85.7 %` covered. The three missing branches are
compiler artifacts, not product logic, so closing them via *tests* is not
possible with the current production code; closing the metric requires either a
production change or an approved coverage-exclusion/deviation decision — neither
of which may be self-accepted here.

---

## 5. Concrete follow-up tests and actions

These are concrete and independent of the write restriction (they are for a
later, authorized iteration). No safety classification, deviation, or native
traceability identifier is invented.

1. **Re-run the focused coverage after any code motion** and confirm 36/36 lines
   and 11/14 branches:
   `bazel test //score/socom/test/unit:socom_test` then the focused
   `g++-12 … --coverage` + `gcovr --filter score/socom/impl/` recipe recorded in
   `focused_coverage/result.json`. Keep the two dynamic-registration tests
   (`:1982`, `:2012`); they are what closes `string_registry.cpp:38-42` / `:55-59`.

2. **To lift branch coverage toward QM 85 % (requires review, not chosen here)**
   — pick exactly one policy and record it as an approved decision:
   - Mark the comparison `noexcept`
     (`bool operator<(…) noexcept;` in `service_identifier.hpp:35` /
     `service_identifier.cpp:20`). This removes the compiler `throw` edge at
     `:28`, but the branch count drops with it (13 total, 11 covered = 84.6 %),
     so it is **not sufficient alone**.
   - Exclude the GCC-generated guard/`throw` edges from the metric via an
     approved gcovr exclusion pattern for `string_registry.cpp:66,71` and
     `service_identifier.cpp:28`. This is a **coverage-policy deviation** and
     must be authorized, not self-applied.
   - Accept a documented deviation from criterion 2 for this slice, with
     rationale and module documentation (`verification_plan.rst:345-346`).

3. **Follow-up tests for the three structural branches (if a seam is added).**
   Only reachable with new production seams, which are out of this bounded
   slice:
   - *`service_identifier.cpp:28` throw edge:* a fault-injection test in which a
     comparison component is made to throw, asserting the exception propagates
     (requires an injectable comparator — not present).
   - *`string_registry.cpp:66,71` guard exception edges:* a test forcing
     `String_registry` construction to throw on first access (requires an
     injectable constructor failure — not present, and not desirable for the
     production default).

4. **Close the reachable-test gap in the native suite.** Execute the full
   `socom_test` target (which also compiles `runtime_tests.cpp`, including
   `ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError`
   at `runtime_tests.cpp:402-431`) and the broader `//score/...` set; record
   results. `measurement.json` currently records only `85 tests / 0 failures`
   for the focused unit, `full_native_tests: not_executed`.

5. **Test-linking metadata (no invented links).** Only
   `DerivationTechnique` and `Description` are recorded
   (`process_checks/result.json` metadata inventory; `test_macros: 87` for
   `service_identifier_tests.cpp`, `33` for `runtime_tests.cpp`). Add
   `TestType` and `Verifies`/`FullyVerifies` **only** once a verified native
   requirement/interface identifier exists; otherwise record applicability as
   unresolved.

6. **Do not present these identifier-only tests as platform validation** and do
   not claim a fuzzy technique without a measurement.

---

## 6. Obligations status (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Structural statement (line) coverage goal | `verification_plan.rst:300-303` (criterion 1) | **MET for the focused TU** — 36/36 = 100 % (QM 85 / safety 100). Not measured for the full target. Local/unprotected. |
| Structural branch coverage goal | `verification_plan.rst:304-307` (criterion 2) | **NOT MET** — 11/14 = 78.6 %, below both QM 85 % and safety 100 %; safety class `unknown`; no deviation accepted |
| Full native coverage / broader scope | `native_coverage/result.json` | **NOT MEASURED** — `bazel` missing (exit 127); `findings_or_execution_failure` |
| Unit/component testing executed, results recorded | `verification_plan.rst` criteria 6-7; `verification_guideline.rst` | **PARTIAL** — focused 87/0 green in a retained local capture; full native `socom_test` not executed |
| Freedom from compiler warnings & errors (100 %) | `verification_plan.rst:332-335` (criterion 9) | **PARTIAL** — GCC focused compile exit 0; Clang blocked on a googletest/libstdc++ dependency deprecation |
| Static code analysis (clang-tidy / CodeQL) | `code_analysis.rst`; `verification_process.rst` | **NOT SATISFIED** — clang-tidy config blocker; CodeQL findings dependency-only / MISRA applicability draft |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` | **UNKNOWN** — mapping draft; human deviations pending |
| Interface / requirements-based / resource / fault-injection tests | `verification_process.rst` | **NOT PERFORMED / applicability not inferred** — no harness; identifier-only tests must not be labelled platform validation |
| Boundary / equivalence derivation | `verification_process.rst` | **SOURCE-ONLY** — cases exist and ran locally, but no native execution |
| Linking tests to requirements (record properties) | `verification_process.rst` (`gd_req__verification_link_tests_cpp`) | **PARTIAL / NOT DONE** — only `DerivationTechnique`/`Description` recorded; no invented identifiers |
| Independence of verification | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Implementation inspection checklist IMPL_01…IMPL_03 | `inspection_checklist.rst` (draft) | **NOT FILLED** |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** for this slice — `bazel`, `valgrind`, `gitleaks`, `clang-format`, `pre-commit`, `reuse` unavailable; clang-tidy config rejected |
| Obligation collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **RETAINED, NOT PASSING** — 24 checks present; branch goal unmet and most native checks blocked |
| Native acceptance | `.llm_tmp/context/obligations/source-index.json` | **not_inferred** for every entry |

**Explicit non-satisfaction statement.** The measured branch coverage is below
both platform goals; the full native coverage and test measurements are not
executed; tools are missing; the safety class is unknown and applicability is
not inferred; extraction is focused-TU only; and human reviews are unanswered.
Therefore **none of the checked obligations may be treated as satisfied**, and
a retained collection result shows *retention*, not passing.

---

## 7. Files changed / state of the six candidate paths

| Candidate path | This iteration |
|----------------|----------------|
| `score/socom/impl/service_identifier.hpp` | **Unchanged** — inspected; brace-balanced (closers `:32`,`:38`; line 39 blank) |
| `score/socom/impl/service_identifier.cpp` | **Unchanged** — identity `(instance, service id, major)`; 3/3 lines covered, one compiler `throw` branch uncovered |
| `score/socom/BUILD` | **Unchanged** |
| `score/socom/test/unit/BUILD` | **Unchanged** |
| `score/socom/test/unit/runtime_tests.cpp` | **Unchanged** — minor-only duplicate regression present at `:402-431` |
| `score/socom/test/unit/service_identifier_tests.cpp` | **Unchanged** — 87 cases present, including the two dynamic-registration cases at `:1982`/`:2012` |
| `.llm_tmp/overnight/reports/coverage_review.md` | **New — this report** |

No file outside this report was created, edited, or deleted; no `NOTICE`,
`LICENSE`, or `REUSE.toml` file was touched; all prior reports were preserved.

---

## 8. Notice preservation

- No source, build, test, config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was
  created, edited, or deleted by this iteration. Every existing Apache-2.0 /
  notice header is untouched.
- The header the task flagged (`score/socom/impl/service_identifier.hpp`) was
  inspected and left unchanged because it is already brace-balanced.
- The duplicate key remains an `impl/`-only type exposed to
  `//score/socom/test/unit` only through the `testonly`
  `//score/socom:impl_service_identifier` library, so no public header or notice
  surface changed.
- This report itself carries the Apache-2.0 header.
- All 12 files under `.llm_tmp/overnight/prior-reports/` and all earlier files
  under `.llm_tmp/overnight/reports/` were preserved unchanged.

---

## 9. Pending human review checklist

- [ ] **Confirm §2:** the recorded "extra closing brace at
      `service_identifier.hpp:39`" is not present in this checkout (line 39
      blank; braces at `:19,:29,:32,:38`), so no source edit was made. Re-check
      before any compile if the state ever changes.
- [ ] **Confirm the §3 reading against the retained artifact:** line
      36/36 = 100 %, branch 11/14 = 78.6 %, 87 tests / 0 failures. Confirm that
      the repository CI line threshold 73 is **not** the acceptance basis.
- [ ] **Decide the safety class and the applicable criterion-2 goal** (QM 85 %
      vs safety 100 %), and **document the branch-coverage deviation** (or
      authorize a coverage-exclusion policy). This draft does not choose either
      and does not accept a deviation.
- [ ] **Confirm the three uncovered branches in §4** are compiler-generated and
      not product logic, and choose the follow-up in §5.2 (e.g. `noexcept` +
      approved guard-branch exclusion) — noting that `noexcept` alone leaves
      13-total/11-covered = 84.6 %.
- [ ] **Run the full native suite** (`bazel test //score/socom/test/unit:socom_test`
      and the broader `//score/...` set), including `runtime_tests.cpp`, and
      record results; re-run focused coverage.
- [ ] **Supply the missing tools/results** (`bazel`, `valgrind`, `gitleaks`,
      `clang-format`, `pre-commit`, `reuse`) and resolve the clang-tidy config
      and Clang dependency blockers, or record accepted deviations; do not treat
      retention as passing.
- [ ] **Supply native requirement/interface identifiers** for traceability, or
      record applicability unresolved (no invented links).
- [ ] **Schedule independent human review** (approver must differ from author,
      per `gd_req__verification_independence`).
- [ ] **Keep the wider #84 restructure** (public `Service_interface_identifier`
      change, FindService wildcard handling, config minor-wildcard narrowing)
      out of this bounded slice until separately accepted, and do not present
      the identifier-only tests as platform validation.
