<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — native test-metadata review (`test_metadata`)

**Document type:** review draft — actual-source inspection + S-CORE native
test-metadata review + verified requirement-link inventory + latest
host-measurement reconciliation.

**Date:** 2026-10-03
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling inside *Revise
version handling in socom* (issue #84). This iteration covers the **native test
metadata and verified requirement links** of that work.
**Run / branch:** `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ`; per the run
environment's recent-commit list the current HEAD is `6f7fbe0`
(`fabro(01M3ZRSDK2XQAF1H48VWTPKQNZ): node_752868eb24b56f82737549dd (success)`),
on top of `d247b21` (`node_2436bbce90fbd4c7084c6e9c`), `df21eb5`
(`node_752868eb24b56f82737549dd`, failure), `f3619a0`
(`node_3c836be9f362f38d7263c8da`), etc.
**Verified baseline commit:** `f8a196c3b16d5172d898394ab99b0ed81346d63d`
(`.llm_tmp/context/source-manifest.json:3`).
**Status:** **local, unprotected, scoped. No engineering acceptance exists.
Human reviews are unanswered. Full native runtime tests remain pending.**
Nothing in this document is acceptance, review approval, publication, or a full
native run.

> **Tool / write boundary observed.** Only `read_file`, `grep`, `glob`, and
> `write_file` were used. No `shell`, no delegation, no web access, no approval,
> no publishing, and no engineering acceptance was performed. (An earlier,
> unrelated attempt to use `shell` was refused by the environment
> — "Overnight tool/path boundary" — and produced no output.) The task permits
> changing only the six named candidate source paths and this report. This
> iteration wrote **exactly one file — this report**
> (`/workspace/.llm_tmp/overnight/reports/test_metadata.md`). **No candidate
> source path was changed**, because (a) the recorded brace defect is **not
> present in the actual source** (§2) and (b) the source-supported metadata the
> task asks for is **already present** in the two candidate test files and the
> four other candidates (§4). No `NOTICE`, `LICENSE`, `REUSE.toml`, config,
> production-source, BUILD, or prior-report file was created, edited, or
> deleted; every prior report and every host artifact was preserved (§9).

> **Recorded syntax-failure premise — inspected; the defect is not present.**
> The task states the cancelled draft has "a measured GCC syntax failure: an
> extra closing brace in `score/socom/impl/service_identifier.hpp` at line 39"
> and directs: "Inspect and correct the actual source before expanding tests."
> Direct inspection of the working tree shows the header is **brace-balanced**
> (§2): the only brace-bearing lines are `:19` (`namespace score::socom {`),
> `:29` (`struct Service_instance_identifier final {`), `:32` (`};`) and `:38`
> (the single `}  // namespace score::socom`); line `:39` is **blank** and line
> `:40` is `#endif`. Independently, the retained host `after-compile` compiled
> a translation unit that transitively includes this header with
> `g++-12 -std=c++17 -Wall -Wextra -Werror -fsanitize=undefined` and exited
> `0` with empty stderr, and the resulting binary ran **91 / 0** — behaviour
> incompatible with a surviving syntax error. **No source correction was
> applied and none is required**; deleting or adding a brace would *create* the
> reported defect. The six source paths were writable; the smallest correct
> edit was the empty edit.

---

## 0. Summary

1. **Recorded syntax failure — inspected; not present in the actual source.**
   `score/socom/impl/service_identifier.hpp` is brace-balanced. `grep` for a
   brace character returns exactly four lines (`:19`, `:29`, `:32`, `:38`);
   line `:39` is empty; `glob **/service_identifier.hpp` returns exactly one
   path, so there is no second, differently-braced copy. **No header edit was
   made** (§2).
2. **Native test-metadata convention reviewed.** The pinned
   `verification_process.rst` requires C++ tests to link to requirements via
   gtest **record properties** (`gd_req__verification_link_tests_cpp`,
   `:56-75`); `gd_req__verification_checks` (`:178-196`) requires `TestType`
   and `DerivationTechnique` to be set and `Description` non-empty;
   `gd_req__verification_checks_extended` (`:198-212`) makes a
   `requirements-based` / `interface-test` `TestType` conditional on a real
   requirement/interface link; and `verification_plan.rst` fixes the allowed
   identifier sets (`:167-207`, `:245-268`) (§3).
3. **The source-supported metadata is present in the six candidates and was
   verified this iteration (no change needed).**
   `service_identifier_tests.cpp` records
   `DerivationTechnique = "boundary-values,equivalence-classes"` and a
   non-empty `Description` in the fixture `SetUp()` (`:42-65`);
   `runtime_tests.cpp` records
   `DerivationTechnique = "design-analysis,equivalence-classes"` plus a
   per-case `Description` through `RuntimeTest::record_registration_key_metadata`
   (`:253-267`), called by all **25** duplicate-server registration-key cases.
   The two BUILD files carry their SPDX headers, `testonly` exposure and
   `tags = ["unit"]` build metadata; the production header/`.cpp` carry their
   SPDX headers and semantics documentation. **No additional source-supported
   metadata value exists to record.** `TestType` and the `Verifies` links
   cannot be validly set without inventing a native identifier (§3, §5).
4. **No verified native requirement identifier exists for this slice, and none
   was invented.** The only real requirement `:id:`s in the repository are the
   stakeholder interoperability requirement and the TC8 set
   (`feat_req__tc8_conformance__*`, `comp_req__tc8_conformance__*`); none
   scopes socom registration-key / version handling.
   `docs/requirements/component/index.rst` and
   `docs/requirements/feature/index.rst` are placeholder indexes with no
   requirement directives, and **no `:reqtype: Interface` need exists
   anywhere**. `TestType` and `PartiallyVerifies`/`FullyVerifies` therefore
   remain **deliberately unset and explicit** in both test files; the gap is
   recorded, not fabricated (§5).
5. **Latest host validation is now present, retained, and green for the
   focused identifier translation unit only.**
   `.llm_tmp/overnight/validation/` holds `check-result = 0`,
   `measurement.json` (`check_ref: check_conversion_tests`, `mode: ubsan`,
   `engineering_acceptance: pending`, `full_native_tests: not_executed`;
   candidate `compile_exit 0 / test_exit 0 / 91 tests / 0 failures`;
   `baseline_with_agent_tests 91 tests / 33 failures`), `after.json`
   (91 / 0) and `before.json`, plus the compile/test command and stdout/stderr
   captures (§6). This is a **local, unprotected, scoped** measurement; it does
   **not** compile `runtime_tests.cpp` or the full `socom_test` / `//score/...`
   targets. `check-result = 0` is a retained measurement, not acceptance.
6. **No obligation is satisfied.**
   `.llm_tmp/overnight/obligations/*/result.json` is **absent** from this
   checkout; `authority.json` records `engineering_acceptance: pending`,
   `human_reviews: unanswered`, `safety_class: unknown`. Missing tools, unknown
   applicability, incomplete extraction, and unanswered human reviews are
   **not** treated as satisfied (§7, §8).

---

## 1. Binding to the verified baseline, prior reports, host feedback, obligations

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` | `.llm_tmp/context/issue-snapshot.json:2-4` |
| Title | *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:3` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` (unchanged) | `.llm_tmp/context/issue-snapshot.json:19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not
an accepted obligation**: service-instance identifier = `service id + major +
minor + instance id`; service identifier = `service id + major`; FindService =
`service id + major + optional<minor> + optional<instance>`; and the proposal to
"exclude the minor version and make it a property of the service instance". The
FindService `major = FF` AUTOSAR case is called theoretically possible but not
useful. There is **no comment and no acceptance record** in the snapshot, so
none of it is binding.

### 1.2 Verified baseline

| Item | Value | Source |
|------|-------|--------|
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |
| Current branch | `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ` | run environment |
| Current HEAD | `6f7fbe0` — `node_752868eb24b56f82737549dd (success)` | run environment recent-commit list (no shell available) |

Binding is **by baseline commit**, not by run HEAD. Earlier reports reference
other run IDs on the same baseline commit (e.g.
`01M3YRJEGXNY6CB81T7TKW774B`, `01M3YGTGYFEN406VDEVVTJTRWV`,
`01M3XZAQ65TTE35XSGXC4JAMAH`, `01M3XT7NQ04S4MTFRMTT2401XK`,
`01M3WX09X84XFM5X08QY2944DF`), so all of them describe the same baseline and
remain admissible prior evidence for this slice. No local hashing tool was
available in this task, so the working tree was **not** re-hashed; the direct
source reads in §2–§4 are authoritative for this report.

### 1.3 In-scope candidate files (the only writable source paths)

From `.llm_tmp/context/candidate-files.json:1-25` (baseline blobs cross-checked
against the `files` array of `.llm_tmp/context/source-manifest.json`):

| File (repo-relative) | Baseline git blob | Baseline present | This iteration |
|----------------------|-------------------|------------------|----------------|
| `score/socom/BUILD` | `3477ea0851fdcd82ec6ea9d71424013cbdf41962` | yes | inspected, **unchanged** (SPDX `:1-12`; `socom` `:24-41`; `testonly impl_service_identifier` `:46-54`) |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e22355242009fe20dada2a9a0d0c7a9c7` | yes | inspected, **unchanged** (SPDX `:1-12`; identity `(instance, id, major)`; issue-#84 rationale comment `:21-27`) |
| `score/socom/impl/service_identifier.hpp` | `c8bae7908da9f087c518934f7b9f8d86db9a20ec` | yes | inspected, **unchanged** (already brace-balanced, §2) |
| `score/socom/test/unit/BUILD` | `3c03a7b14286051f97fa5022206564bd63645171` | yes | inspected, **unchanged** (SPDX `:1-12`; `srcs = glob(include = ["*.cpp"])` `:19`; `tags = ["unit"]` `:21`; deps `:23-29`) |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab726db8bf994c960045d6fd7fdf84d7395` | yes | inspected, **unchanged** (record-property metadata present, §4.3) |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(none — `null`)* | no (manifest expects a **new** file) | inspected, **unchanged** (record-property metadata present, §4.2) |

The `null` baseline blob for `service_identifier_tests.cpp` is the manifest's
expectation of a **new** unit-test file; it exists on disk only as part of the
un-merged working tree (the task's "cancelled draft"), never in the baseline.
`glob **/service_identifier.hpp` returns exactly one path and
`glob **/*.{orig,rej,bak,patch,diff}` returns only the unrelated
`third_party/*.patch` files, so there is **no second, differently-braced copy**
of the header and no leftover reject/patch file carrying the defect.

**Manifest-hash note (explicit).** The `sha256` values in
`.llm_tmp/context/candidate-files.json` are a **start-of-task snapshot**; the
working tree has evolved inside the allowed six paths (later nodes added the
dynamic-string / config-narrowing boundary cases and the metadata block), so the
recorded values for `service_identifier_tests.cpp` (`45d07399…`) and
`runtime_tests.cpp` (`5e35e24d…`) no longer match the measured tree. The
retained host `measurement.json.source_hashes` records the measured content
(`service_identifier_tests.cpp` = `de79767c…`, `runtime_tests.cpp` =
`9a2d6a15…`). The candidate set is bound by **path and baseline blob**, not by
the stale start-of-task hash.

### 1.4 Prior reports read and preserved

- `.llm_tmp/overnight/prior-reports/` — **38 files present** (`glob`), all
  preserved. Read/cross-checked: `test_metadata.md` (the earlier review of this
  same topic), plus `scope.md`, `invariants.md`, `callsites.md`, `reproducer.md`,
  `key_fix.md`, `unit_matrix.md`, `ordering_tests.md`, `conversion_tests.md`,
  `runtime_disabled.md`, `runtime_enabled.md`, `lifetime_tests.md`,
  `coverage_review.md`, `coverage_tests_repair.md`, `finding_classification.md`,
  `misra_applicability.md`, `misra_manual_review.md`, `tool_findings_repair.md`,
  `design_inspection_draft.md`, `deviation_drafts.md`, `security_review.md`,
  `tool_assurance_review.md`, `integration_aou_review.md`,
  `traceability_review.md`, `evidence_inventory.md`,
  `independent_review_handoff.md`, `review_packet.md`,
  `verification_report_draft.md`, `api_review.md`, `compatibility.md`,
  `concurrency_review.md`, `cross_target_review.md`, `lifetime_review.md`,
  `performance_review.md`, `sanitizer_review.md`, `native_build_review.md`,
  `analyzer_plan.md`, `bazel_plan.md`. Earlier reports also cite
  `repair_unit_matrix.md`, `coverage_tests_repair.md`, `tool_findings_repair.md`
  and a host addendum `obligation-addendum.md`; of these, the latter three are
  absent here, so their content is available only as quoted by the other
  reports.
- `.llm_tmp/overnight/reports/` (this run's earlier nodes), read and preserved:
  `scope.md`, `callsites.md`, `invariants.md`, `reproducer.md`, `key_fix.md`,
  `unit_matrix.md`, `ordering_tests.md`, `runtime_disabled.md`,
  `runtime_enabled.md`, `lifetime_tests.md`, `conversion_tests.md`,
  `repair_conversion_tests.md`. This document adds `test_metadata.md`; it does
  **not** overwrite the same-named file under `prior-reports/`.

Derived sequence across the preserved reports: `scope.md` (bounded the slice;
identified the key/index identity gap) → `invariants.md` (I-4 baseline key
included `minor`; I-9 record index ignores `minor`; I-11 the resulting gap) →
`callsites.md` → `reproducer.md` (header brace correction + focused red
regression) → `key_fix.md` / `unit_matrix.md` (drop `minor` from the ordering;
expand the key tests) → `ordering_tests.md` → runtime/lifetime reports →
`conversion_tests.md` / `repair_conversion_tests.md` → **this report** (metadata
re-review on the current, host-measured tree).

### 1.5 Pinned obligation sources and authority (all read this iteration)

All nine entries of `.llm_tmp/context/obligations/source-index.json`, together
with `.llm_tmp/context/obligations/authority.json`, were read from
`.llm_tmp/context/obligations/`. Every entry is pinned
`"native_acceptance": "not_inferred"` — pinned, but applicability to this slice
is **not inferred**.

| id | pinned file (id → path) | status (re-read this iteration) |
|----|-------------------------|---------------------------------|
| `coding_guidelines` | `docs/contribute/development/cpp/coding_guidelines.rst` | `:status: valid` (`:20`), `:safety: ASIL_B` (`:22`); MISRA C++:2023 with C++17 |
| `code_analysis` | `docs/contribute/development/cpp/code_analysis.rst` | `:status: valid` (`:20`), `:safety: ASIL_B` (`:22`); clang-tidy + gcc/clang warnings + Coverity; sanitizers; coverage |
| `misra_mapping` | `docs/contribute/development/cpp/misra_2023_rule_mapping.rst` | **`:status: draft`** (`:20`), `:safety: ASIL_B` (`:22`); rule table not a valid obligation |
| `verification_plan` | `docs/platform_management_plan/software_verification.rst` | `:status: valid` (`:17`), `:safety: ASIL_B` (`:19`); TestType table (`:167-207`), DerivationTechnique table (`:245-268`); quality criteria 1-9 |
| `development_plan` | `docs/platform_management_plan/software_development.rst` | `:status: valid` (`:21`), `:safety: ASIL_B` (`:23`); C++17, GCC host compiler, Bazel |
| `tool_management` | `docs/platform_management_plan/tool_management.rst` | `:status: valid` (`:17`), `:safety: ASIL_B` (`:19`); tools identified / evaluated / qualified by a human |
| `verification_process` | `process/process_areas/verification/guidance/verification_process_reqs.rst` | `:status: valid` (`:22`); `gd_req__verification_link_tests_cpp` (`:56-75`), `_independence` (`:141-152`), `_checks` (`:178-196`), `_checks_extended` (`:198-212`), `_external_aou` (`:214-226`), `_sca_classification` (`:228-248`) |
| `verification_guideline` | `process/process_areas/verification/guidance/verification_guideline.rst` | `:status: valid` (`:19`); traceability, independence, documented results |
| `inspection_checklist` | `score/component_example/docs/detailed_design/chklst_impl_inspection.rst` | **`:status: draft`** (`:17`), `:safety: ASIL_B` (`:19`); blank `IMPL_01_01`…`IMPL_03_02` template |

**Authority record** (`.llm_tmp/context/obligations/authority.json:1-7`):

| Field | Value |
|-------|-------|
| `engineering_acceptance` | **pending** |
| `human_reviews` | **unanswered** |
| `safety_class` | **unknown** |
| `codeql_scope` | `Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload` |
| `instruction` | *"Restart the failed queue for one complete pass through all obligations"* |

**Safety-class note (recorded, not resolved).** The pinned platform documents
carry `:safety: ASIL_B`, while `authority.json` records `safety_class: unknown`
and no authorized selection exists. The document attribute is **not** a
selection of the slice's safety class and must not be inferred as one.

### 1.6 Host validation feedback and obligation-collection results

- **Host feedback is present in this checkout** under
  `.llm_tmp/overnight/validation/` (`measurement.json`, `before.json`,
  `after.json`, `check-result`, and the `before`/`after` compile/test command +
  stdout/stderr captures). It is summarised and reconciled in §6.
- **Obligation-collection results are absent.**
  `glob .llm_tmp/overnight/obligations/**` returns nothing and a repository-wide
  `glob **/result.json` returns nothing; no
  `.llm_tmp/overnight/obligations/*/result.json` exists here. Per the task rule,
  a successful collection node means results were **retained**, not that checks
  **passed**; here nothing is retained at all, so **nothing may be treated as
  satisfied on that basis.**

---

## 2. The recorded syntax failure: inspection of the actual source

### 2.1 Finding (direct `read_file` + `grep` this iteration)

`score/socom/impl/service_identifier.hpp` is **brace-balanced**. It is 40 lines:

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

`grep` for a brace character on the file returns exactly four matches — `:19`,
`:29`, `:32`, `:38`. Two openers and two closers give net brace balance `0`;
`:39` contains no text at all. `glob **/service_identifier.hpp` returns exactly
one path, so there is no second, differently-braced copy. The task's "extra
closing brace … at line 39" is therefore a **stale, pre-correction description**
that matches only the earliest prior reports (which quote lines 38-39 as the
split-form `}  // namespace socom` + `}  // namespace score`); the `reproducer`
iteration applied the correction and every later report — and this direct read —
shows the balanced state.

### 2.2 Repository convention (evidence)

The tree uses two internally consistent styles:

- **Nested open + single close:** `namespace score::socom {` … one
  `}  // namespace score::socom`. This is the sibling
  `impl/service_identifier.cpp` (`:18` / `:32`), the public
  `service_interface_identifier.hpp`, and `impl/service_identifier.hpp` itself.
- **Split open + double close:** `namespace score {` + `namespace socom {` …
  `}  // namespace socom` + `}  // namespace score`. This is
  `impl/runtime_impl.hpp`.

`impl/service_identifier.hpp` follows the **nested** form consistently and is
balanced.

### 2.3 Minimal repair (recorded for reference only; not applied because not needed)

Should the imbalance ever reappear, the minimal correction — matching the
sibling `.cpp` and the nested form — is:

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

Applying this to the already-balanced file would be a no-op; deleting a brace to
"fix" the file would *introduce* the reported defect. **No production source was
edited, and the "inspect and correct the actual source before expanding tests"
precondition is met without a write because there is no actual source defect.**

### 2.4 Why it would matter if present

The header is compiled into `//score/socom:socom`
(`score/socom/BUILD:24-41`; its `srcs` globs `impl/**/*.cpp` and
`impl/**/*.hpp`) and re-exposed to `//score/socom/test/unit` through the
`testonly` library `impl_service_identifier` (`score/socom/BUILD:46-54`;
consumed at `score/socom/test/unit/BUILD:24`). A syntax error there would fail
the library and the whole `socom_test` target, contradicting S-CORE quality
criterion 9, "Freedom from compiler warnings & errors, 100 %"
(`verification_plan.rst:332-335`). It is **not** a blocker in the current tree.
That is corroborated by the retained host compile (§6), which is a local,
unprotected, scoped measurement — not acceptance.

---

## 3. Native test conventions and allowed metadata identifiers

The pinned authority is `verification_process.rst` (`:status: valid`):

- `gd_req__verification_link_tests` (`:20-54`) names the metadata — **Verifies**
  (`PartiallyVerifies`, `FullyVerifies`), **Description**, **TestType**,
  **DerivationTechnique** — and fixes their allowed values.
- `gd_req__verification_link_tests_cpp` (`:56-75`) states verbatim: *"For linking
  C++ tests to requirements **record properties** shall be used. Attributes
  which are common for all test cases can be specified in the Setup Function
  (SetUp()), the other attributes which are specific for each test case need to
  be specified within the test case."* The referenced `verification_template_cpp`
  is **not present** in the pinned sources or this repository, so the property
  spelling is derived from the requirement text and from the two candidate files
  that already implement it.
- `gd_req__verification_checks` (`:178-196`) requires `TestType` and
  `DerivationTechnique` to be set and `Description` non-empty; in a Unit Test,
  if `Partially/FullyVerifies` are set they shall link to at least one Component
  Requirement.
- `gd_req__verification_checks_extended` (`:198-212`): a `requirements-based`
  `TestType` requires a requirement link; an `interface-test` `TestType`
  requires an interface link.
- `gd_req__verification_methods_multiple` (`:125-139`): several derivation
  techniques may be combined in one property.
- `verification_plan.rst` fixes the identifiers: `TestType ∈
  {static-code-analysis, structural-statement-coverage,
  structural-branch-coverage, walkthrough, inspection, interface-test,
  requirements-based, resource-usage}` (`:167-207`, plus the optional
  `control-flow-analysis` / `data-flow-analysis` / `fault-injection` /
  `structural-function-coverage` / `structural-call-coverage` at `:228-239`)
  and `DerivationTechnique ∈ {requirements-analysis, design-analysis,
  boundary-values, equivalence-classes, fuzz-testing, error-guessing,
  explorative-testing}` (`:245-268`).

**Native in-repo convention (verified this iteration).** A repository-wide
`grep 'RecordProperty'` (over `score/**`) returns **only** the two candidate test
files: `service_identifier_tests.cpp:50-51` and `runtime_tests.cpp:265-266`. No
other C++ test in this repository uses gtest record properties; the de-facto
convention elsewhere is prose comments plus the Bazel `tags = ["unit"]`. Because
the pinned process mandates record properties for C++ tests, this slice uses them
rather than inventing a comment schema.

---

## 4. Metadata present in the six candidate files (verified; no source-supported addition is missing)

### 4.1 Production and build files — license/build metadata present, no test record properties applicable

| Candidate path | Metadata present (verified this iteration) |
|----------------|--------------------------------------------|
| `score/socom/impl/service_identifier.hpp` | SPDX/Apache-2.0 header (`:1-12`); documentation comment (`:21-28`) states the identity semantics and the intentional minor exclusion. `RecordProperty` is a gtest-only facility and is not applicable to a production header. |
| `score/socom/impl/service_identifier.cpp` | SPDX/Apache-2.0 header (`:1-12`); rationale comment (`:21-27`) links the change to issue #84 and to `is_interface_compatible`. No gtest record properties apply. |
| `score/socom/BUILD` | SPDX/Apache-2.0 header (`:1-12`); the test-only exposure library `impl_service_identifier` carries `testonly = True` and package-scoped visibility (`:46-54`); the production `socom` library carries `features = COMPILER_WARNING_FEATURES` (`:34`). |
| `score/socom/test/unit/BUILD` | SPDX/Apache-2.0 header (`:1-12`); the `socom_test` target carries `size = "small"`, `linkstatic = True`, `tags = ["unit"]` and the required deps (`:16-29`). |

### 4.2 `score/socom/test/unit/service_identifier_tests.cpp` — metadata present and host-confirmed

The SPDX/Apache-2.0 header is at `:1-12`. The `ServiceInstanceIdentifierTest`
fixture (class at `:40`) records, in `SetUp()` (`:42-65`):

```cpp
RecordProperty("DerivationTechnique", "boundary-values,equivalence-classes");
RecordProperty(
    "Description",
    "Deterministic identity, ordering, boundary and equivalence-class checks for the "
    "Service_instance_identifier duplicate-server registration key (issue #84): the key "
    "identity is (instance, service id, major) and the minor version is not part of it.");
```

Placed per `gd_req__verification_link_tests_cpp` (common attributes in `SetUp()`),
using only identifiers allowed by `verification_plan.rst`. The file holds **91
`TEST_F`** cases under that fixture (`:168` … `:2181`, counted this iteration by
`grep`), all concerning the same registration-key contract, so the fixture-wide
attributes correctly describe every case. The block at `:57-64` explicitly
documents why `TestType` and the `Verifies` links are omitted. The file ends at
`}  // namespace score::socom` (`:2211`).

The retained host JUnit report `after.json` independently shows
`DerivationTechnique` and `Description` on **all 91** cases
(e.g. `after.json:28-29`, and the suite total `after.json:2-5`), so this metadata
is **measured/verified for the identifier translation unit** as well as
source-present.

### 4.3 `score/socom/test/unit/runtime_tests.cpp` — metadata present and source-supported

The SPDX/Apache-2.0 header is at `:1-12`. The shared `RuntimeTest` fixture
(class at `:244`) carries a small protected helper (`:264-267`) with its
rationale doc comment (`:253-263`):

```cpp
void record_registration_key_metadata(std::string const& description) {
    RecordProperty("DerivationTechnique", "design-analysis,equivalence-classes");
    RecordProperty("Description", description);
}
```

Its doc comment states both the derivation rationale and the explicit omission of
`TestType` / `Verifies` for the same reason as the key file. A `grep
'record_registration_key_metadata'` returns the definition at `:264` and **25
call sites**: `:335`, `:351`, `:372`, `:403`, `:442`, `:473`, `:507`, `:540`,
`:575`, `:609`, `:643`, `:695`, `:728`, `:765`, `:798`, `:834`, `:871`, `:906`,
`:953`, `:987`, `:1048`, `:1094`, `:1142`, `:1198`, `:1254`. Each call passes a
per-case `Description`, which is exactly the "per-case attributes in the test
case" half of `gd_req__verification_link_tests_cpp`. The `DerivationTechnique`
combines `design-analysis` (the key derives from the `Runtime_impl`
registration-key design and its lifetime) and `equivalence-classes` (the same
`(instance, service id, major)` is a duplicate; a different component is a
distinct key) — both allowed identifiers.

The file structure verified this iteration: **1 `TEST`** (`:239`), **31 `TEST_F`**
(`:279`…`:1253`), **1 `TEST_P`** (`:1311`). The 25 metadata-carrying cases are
the duplicate/lifetime registration-key cases; the unrelated bridge/factory tests
and the `RuntimeBridgeTest` parameterised case deliberately receive **no**
registration-key metadata, because their subject is not the key. This metadata is
**source-derived but unmeasured** here, because the retained host run compiles
only the identifier translation unit (§6).

### 4.4 What was considered for addition, and why nothing was added

The task asks to "add verified metadata … when source-supported". Every candidate
addition was evaluated and rejected as **not source-supported**:

| Candidate addition | Verdict |
|--------------------|---------|
| `DerivationTechnique` / `Description` record properties | **Already present** in both test files (§4.2, §4.3); re-adding would duplicate. |
| `TestType = requirements-based` | **Forbidden** — needs a Component Requirement link; the only real requirement ids scope TC8/stakeholder, not socom registration (§5). `gd_req__verification_checks_extended` explicitly forbids it without a requirement link. |
| `TestType = interface-test` | **Forbidden** — needs an interface link; no `:reqtype: Interface` need exists (§5). |
| `TestType = structural-statement-coverage` / `structural-branch-coverage` | **Not source-supported** — no coverage measurement is retained for this slice in this checkout; the tests are not a coverage-tool artifact. Setting it would be an unmeasured claim. |
| `TestType = static-code-analysis` / `walkthrough` / `inspection` / `resource-usage` / `fault-injection` | **Inapplicable / false** — these unit tests exercise code at runtime; they are not a static analysis, walkthrough, inspection, resource evaluation, or fault-injection harness. |
| `PartiallyVerifies` / `FullyVerifies` link | **Prohibited** — would require inventing a native requirement identifier (§5). |
| License / build metadata on the BUILD and source files | **Already present** (§4.1). |
| A new comment linking the header to issue #84 | **Cosmetic only**, not S-CORE metadata; the semantics are already documented at `:21-28`, and the sibling `.cpp` already carries the explicit issue reference. Not added, to keep the change surgical. |

Consequently **no candidate source file was modified**. The missing `TestType`
and requirement-link identities remain **explicit** rather than filled with an
invented value.

---

## 5. Verified requirement-link inventory and missing identities

### 5.1 Verified requirement-link inventory (nothing applicable to this slice)

A repository-wide search of the `:id:`/`req__` directives yields exactly the
following real requirement identifiers:

| Identifier (verified `:id:`) | Source | `:reqtype:` | Applicable to this slice? |
|------------------------------|--------|-------------|---------------------------|
| `stkh_req__someip_gw__interoperability` | `docs/requirements/stakeholder.rst:24` | Functional | no — wire-level interoperability |
| `feat_req__tc8_conformance__conformance` | `docs/tc8_conformance/requirements.rst:25` | Functional | no — TC8 wire conformance |
| `comp_req__tc8_conformance__sd_offer_format` | `docs/tc8_conformance/requirements.rst:56` | Functional | no |
| `comp_req__tc8_conformance__sd_cyclic_timing` | `docs/tc8_conformance/requirements.rst:76` | Functional | no |
| `comp_req__tc8_conformance__sd_find_response` | `docs/tc8_conformance/requirements.rst:95` | Functional | no |
| `comp_req__tc8_conformance__sd_sub_lifecycle` | `docs/tc8_conformance/requirements.rst:114` | Functional | no |
| `comp_req__tc8_conformance__sd_phases_timing` | `docs/tc8_conformance/requirements.rst:136` | Functional | no |
| `comp_req__tc8_conformance__msg_resp_header` | `docs/tc8_conformance/requirements.rst:159` | Functional | no |
| `comp_req__tc8_conformance__msg_error_codes` | `docs/tc8_conformance/requirements.rst:181` | Functional | no |
| `comp_req__tc8_conformance__evt_subscription` | `docs/tc8_conformance/requirements.rst:205` | Functional | no |

The other `:id:` values in the repository are architecture/decision definitions
rather than requirement directives — `feat__someip_gateway`,
`comp__gatewayd` / `comp__serializer` / `comp__null_serializer` / `comp__someipd`,
`logic_arc_int__someip__serializer`, and the `dec_rec__*` decisions — none of
which is a linkable requirement. `docs/requirements/component/index.rst` and
`docs/requirements/feature/index.rst` are placeholder indexes (naming-scheme
examples only) with no requirement directives; a search of `docs/` for `reqtype`
finds **only `Functional`** needs. Therefore there is **no verified native
requirement identifier** for `PartiallyVerifies`/`FullyVerifies`, and **no
verified interface identifier** for an `interface-test` `TestType`.

### 5.2 Missing identities (explicit)

| Missing identity | Why | Consequence |
|------------------|-----|-------------|
| Component requirement for socom registration-key / version handling | `docs/requirements/component/` holds only a placeholder index; no `comp_req__socom__*` exists | `PartiallyVerifies`/`FullyVerifies` unset; `TestType=requirements-based` unset |
| Interface requirement/identifier for `Service_instance_identifier` | no `:reqtype: Interface` need exists | `TestType=interface-test` unset |
| `TestType` generally | no allowed `TestType` value (`verification_plan.rst:167-207`) is both truthful and link-free for this runtime unit test | `gd_req__verification_checks` unmet — recorded gap, not a pass |
| Human review / independence record | `authority.json`: `human_reviews: "unanswered"` | `gd_req__verification_independence` unmet |
| Obligation-collection `result.json` | `.llm_tmp/overnight/obligations/` absent from this checkout | no obligation retained, so none satisfied on that basis |

Native identifiers must be supplied by a human reviewer before these fields can
be completed; the slice remains metadata-incomplete until then. **No identifier
was invented anywhere in this change.** A `grep` across the two candidate test
files confirms they contain no `comp_req__`, `feat_req__`, or `stkh_req__`
string.

---

## 6. Latest host validation feedback and measurement status

### 6.1 Retained artifacts in this checkout

| Artifact | Content |
|----------|---------|
| `validation/check-result` | `0` (the check reported success for the file it measured) |
| `validation/measurement.json` | `check_ref: check_conversion_tests`, `status: completed`, `mode: ubsan`, `changed_paths: ["score/socom/test/unit/service_identifier_tests.cpp"]`, `origin: local_unprotected_measurement`, `initiator: Fabro host hook`, `engineering_acceptance: pending`, `full_native_tests: not_executed`, compiler `/usr/bin/x86_64-linux-gnu-g++-12` (`compiler_sha256: 88315fd2…c196d3`) |
| `candidate` (`measurement.json:2052-2058`) | `compile_exit: 0`, `test_exit: 0`, `tests: 91`, `failures: 0`, `disabled: 0` |
| `baseline_with_agent_tests` (`measurement.json:2045-2051`) | `compile_exit: 0`, `test_exit: 1`, `tests: 91`, `failures: 33`, `disabled: 0` |
| `validation/after-compile.command.json` | focused `g++-12 -std=c++17 -Wall -Wextra -Werror -pthread -I. … score/socom/impl/service_identifier.cpp score/socom/impl/string_registry.cpp score/socom/test/unit/service_identifier_tests.cpp <gtest>` plus `-fsanitize=undefined -fno-sanitize-recover=all`; `exit_code: 0` |
| `validation/after-compile.stderr` | empty (no diagnostic for the header or the test) |
| `validation/after-test.command.json` | runs the built binary with `--gtest_output=json:…/after.json` |
| `validation/after.json` | JSON report: `ServiceInstanceIdentifierTest`, **91 tests / 0 failures / 0 disabled / 0 errors** (`:2-5`, `:11-14`); every case carries `DerivationTechnique: "boundary-values,equivalence-classes"` and the fixture `Description` (e.g. `:28-29`); **no `TestType` property anywhere** |
| `validation/before.json` | JSON report: same suite against the pre-correction, minor-including key — **33 failures** (per `measurement.json`) |

### 6.2 Interpretation

The focused candidate translation unit compiles (with `-Werror` and UBSan) and
all 91 key cases pass, while the same tests against the baseline-with-agent-tests
key fail 33. The recorded test metadata (`DerivationTechnique`, `Description`) is
observable in the JSON output on every case, so it is **verified by measurement
for the identifier file**. It is **local and unprotected** and is **not**
acceptance. `check-result = 0` means the scoped check for that one file
succeeded; it is not engineering acceptance and does not extend to
`runtime_tests.cpp` or `//score/...`.

### 6.3 Scope caveats

The retained measurement is a **focused, scoped** capture: it exercised only the
identifier translation unit (`service_identifier.cpp` + `string_registry.cpp` +
`service_identifier_tests.cpp` + googletest), **not** `runtime_tests.cpp` and
**not** the full `socom_test` / `//score/...` targets. The metadata present in
`runtime_tests.cpp` is therefore **source-derived but unmeasured** in this
checkout. The full native suite, other sanitizer/coverage runs, and static
analysis remain pending. A `check-result` of `0` is a retained local measurement,
not engineering acceptance.

---

## 7. Files changed / state of the six candidate paths

This iteration wrote **only this report**
(`.llm_tmp/overnight/reports/test_metadata.md`). No candidate source path needed
a change:

| Candidate path | State | This iteration |
|----------------|-------|----------------|
| `score/socom/impl/service_identifier.hpp` | brace-balanced, nested namespace, documents minor exclusion | **unchanged** (verified, §2) |
| `score/socom/impl/service_identifier.cpp` | `operator<` identity `(instance, id, major)`, minor excluded; issue-#84 rationale comment | **unchanged** (verified) |
| `score/socom/BUILD` | `testonly impl_service_identifier` exposure present | **unchanged** (verified) |
| `score/socom/test/unit/BUILD` | `socom_test` globs `*.cpp`, `tags = ["unit"]`, deps wired | **unchanged** (verified) |
| `score/socom/test/unit/runtime_tests.cpp` | record-property metadata present (helper `:264-267`, 25 calls) | **unchanged** (verified, §4.3) |
| `score/socom/test/unit/service_identifier_tests.cpp` | 91 `TEST_F`; `SetUp()` metadata `:42-65`; host-confirmed | **unchanged** (verified, §4.2) |
| `.llm_tmp/overnight/reports/test_metadata.md` | **new — this report** | written |

No file outside the six candidate paths and this report was written; no
`NOTICE`, `LICENSE`, or `REUSE.toml` file was created, edited, or deleted; all
prior reports and host artifacts were preserved.

---

## 8. Obligations status (none satisfied)

### 8.1 Pinned state from `authority.json`

| Field | Value |
|-------|-------|
| `codeql_scope` | Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload |
| `engineering_acceptance` | **pending** |
| `human_reviews` | **unanswered** |
| `safety_class` | **unknown** |
| `instruction` | "Restart the failed queue for one complete pass through all obligations" |

All nine pinned sources in `.llm_tmp/context/obligations/` were read this
iteration (§1.5); every `source-index.json` entry is
`"native_acceptance": "not_inferred"`. `misra_mapping.rst` and
`inspection_checklist.rst` are `:status: draft`.

### 8.2 Status table

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Linking C++ tests to requirements via record properties | `verification_process.rst` (`gd_req__verification_link_tests_cpp`, `:56-75`) | **PARTIAL** — `DerivationTechnique` + `Description` recorded in `service_identifier_tests.cpp:50-55` (host-confirmed on all 91 cases) and in the 25 runtime key cases (`runtime_tests.cpp:264-267`); `TestType` and `Partially/FullyVerifies` unset because no verified native identifier exists (§5) |
| Test-metadata consistency checks | `verification_process.rst` (`gd_req__verification_checks` `:178-196`, `_extended` `:198-212`) | **NOT SATISFIED** — `TestType` cannot be validly set without an invented/unavailable link; the gap is recorded explicitly |
| Freedom from compiler warnings & errors (100 %) | `verification_plan.rst:332-335` (criterion 9) | **PARTIALLY MEASURED** — the focused candidate TU compiles with `g++-12 -Wall -Wextra -Werror -fsanitize=undefined` and passes (91/0); but only the focused TU, not the full `//score/...` build, and `runtime_tests.cpp` is not compiled by that run |
| Static code analysis (clang-tidy / CodeQL), findings classified | `code_analysis.rst`; `gd_req__verification_sca_classification` | **NOT PERFORMED** — no tool, no build in this iteration |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` (`:status: draft`) | **UNKNOWN** — mapping not applied |
| Structural statement / branch coverage goals | `verification_plan.rst` (criteria 1-2) | **NOT MEASURED** — no coverage run retained here |
| Unit/component testing executed, results recorded | `verification_plan.rst` (criteria 6-7); `verification_guideline.rst` | **PARTIAL / FOCUSED ONLY** — the retained host run executes 91 focused key cases (0 failures) against a baseline of 91/33; it does not build `//score/socom/test/unit:socom_test` or `//score/...` |
| Interface / requirements-based / resource / fault-injection test types | `verification_process.rst:20-54`; `verification_plan.rst:167-240` | **NOT PERFORMED / applicability not inferred** — identifier-only tests are not platform validation |
| Boundary / equivalence derivation | `verification_process.rst:43-50` | **METADATA-TAGGED / EXECUTED FOR THE KEY FILE ONLY** — tagged `boundary-values,equivalence-classes` and green in the focused run; the runtime cases are tagged `design-analysis,equivalence-classes` but are unmeasured |
| Fuzzy testing technique | `verification_plan.rst:265-270` | **NOT EXECUTED / NOT CLAIMED** — no harness, no measurement |
| Independence of verification / review by a different committer | `gd_req__verification_independence` (`:141-152`) | **NOT DONE** — human reviews unanswered |
| Implementation inspection checklist IMPL_01…IMPL_03 | `inspection_checklist.rst` (`:status: draft`) | **NOT FILLED** — draft template, no inspection |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** for this slice |
| Obligation-collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **ABSENT** — no result files in this checkout |
| Native acceptance | `source-index.json` | **not_inferred** for every entry |

**Explicit non-satisfaction statement.** Missing tools (no full build/test by this
iteration), the unknown safety class and un-inferred applicability, the
incomplete extraction of host artifacts, the absent obligation-collection
results, and the unanswered human reviews mean **none of the checked obligations
may be treated as satisfied**. The presence of `.llm_tmp/overnight/validation/`
is a **local, unprotected, scoped** measurement of one focused translation unit;
the absence of `.llm_tmp/overnight/obligations/*/result.json` is likewise **not**
evidence that the corresponding checks passed. In particular, `TestType` being
unset is a **known, recorded gap**, not a pass.

### 8.3 Honesty boundaries

This report does **not** label the identifier-only tests as full platform
validation and does **not** claim that a fuzzy or fault-injection technique was
executed. No fuzz/fault-injection harness and no full feature/platform
reference-hardware tests exist in this workspace; those remain explicit pending
work. No native requirement identifier was invented. No
`structural-*-coverage` `TestType` was claimed because no coverage measurement is
retained here. The `:safety: ASIL_B` document attribute is recorded but not
adopted as the slice's safety class.

---

## 9. Notice preservation

- No source, build, test, config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was
  created, edited, or deleted by this iteration; only this report was written.
  Every existing Apache-2.0 / SPDX notice header in the candidate set is
  untouched: the two `.cpp` test files, `service_identifier.cpp`,
  `service_identifier.hpp`, and both BUILD files all retain their `:1-12`
  headers.
- The header the task flagged (`score/socom/impl/service_identifier.hpp`) was
  inspected and left unchanged because it is already brace-balanced and
  otherwise well-formed (§2).
- This report itself carries the Apache-2.0 header.
- The duplicate-server registration key remains an `impl/`-only type exposed
  only to `//score/socom/test/unit` through the `testonly`
  `//score/socom:impl_service_identifier` library, so no public header or notice
  surface changed.
- Every prior report under `.llm_tmp/overnight/prior-reports/` and
  `.llm_tmp/overnight/reports/`, and every host artifact under
  `.llm_tmp/overnight/validation/`, was preserved; the host artifacts were read
  only.

---

## 10. Pending human review checklist

- [ ] **Confirm §2:** `score/socom/impl/service_identifier.hpp` is already
      brace-balanced (`:19`, `:29`, `:32`, `:38`; line 39 blank); the "extra
      closing brace at line 39" is the stale pre-correction description, so no
      header edit was made. Re-check before any compile if the state ever
      changes.
- [ ] **Confirm the metadata already present** in
      `service_identifier_tests.cpp:42-65` and `runtime_tests.cpp:253-267` is
      the intended interpretation of `gd_req__verification_link_tests_cpp`
      (record properties; common attributes in `SetUp()`, per-case attributes in
      the test case), and that leaving `TestType`/`Verifies` unset pending a
      verified native link is acceptable (§4.4).
- [ ] **Supply the native requirement/interface identifiers** for this slice (a
      socom `comp_req__*` and, if `interface-test` is intended, an interface
      need), or record applicability as unresolved, so that `TestType` and
      `PartiallyVerifies`/`FullyVerifies` can be completed without invention
      (§5).
- [ ] **Confirm the metadata placement/format** against the
      `verification_template_cpp`, which is not available in the pinned sources
      or this repository.
- [ ] **Compile and run `runtime_tests.cpp`**
      (`bazel test //score/socom/test/unit:socom_test`) — the record properties
      there are unmeasured — and record results; run the broader `//score/...`
      set, including the native runtime tests.
- [ ] **Supply the missing obligation results**
      (`.llm_tmp/overnight/obligations/*/result.json`) and resolve the
      `engineering_acceptance: pending` / `human_reviews: unanswered` state.
- [ ] **Schedule independent human review** (the approver must differ from the
      author, per `gd_req__verification_independence`).
- [ ] **Do not treat the identifier-only/registration-key tests as platform
      validation**; provide a fuzz/fault-injection harness and full
      feature/platform reference-hardware tests separately, and do not claim an
      unmeasured fuzzy technique.
- [ ] **Keep the #84 public `Service_interface_identifier` restructure,
      FindService wildcard handling, and the config minor-wildcard narrowing out
      of this bounded slice** until separately accepted.

---

*End of native test-metadata review draft. Local, unprotected, scoped. No
engineering acceptance; human reviews unanswered; full native runtime tests
pending. Every statement is a local reading of the working tree, a prior
report's recorded reading, or an explicitly-labelled logical consequence — none
is acceptance, review approval, publication, or a full native run.*
