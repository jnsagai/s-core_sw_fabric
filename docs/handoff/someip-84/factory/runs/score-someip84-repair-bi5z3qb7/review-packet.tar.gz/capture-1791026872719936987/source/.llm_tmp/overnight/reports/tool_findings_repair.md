<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — tool-findings repair (duplicate-server registration key)

**Document type:** tool-diagnostics repair report (readings of the retained collected
artifacts + actual-source inspection + no-safe-correction determination + remaining-findings
record)

**Date:** 2026-10-03
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version
handling in socom* (issue #84)
**Run / branch:** `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ`
**Verified baseline commit:** `f8a196c3b16d5172d898394ab99b0ed81346d63d`
(`.llm_tmp/context/source-manifest.json:3`)
**Status:** **local, unprotected, scoped.** No engineering acceptance exists. Human reviews
are unanswered. Full native runtime tests are pending. Every statement below is either a
direct reading of the working tree, a direct reading of a *retained* tool artifact, or an
explicitly-labelled logical consequence. Nothing here is acceptance, review, publication,
or a full native run.

> **Non-satisfaction rule applied throughout.** A successful collection node means results
> were **retained**, not that the checks **passed**. Missing tools, unknown applicability,
> incomplete extraction (e.g. focused translation-unit runs, dependency findings retained),
> draft rule mappings, and unanswered human reviews are **not** treated as satisfied. A
> tool that produced **no** finding because it did not run is recorded as *"not run"*, never
> as *"clean"*. Every unexecuted applicable check and every unaccepted deviation remains a
> **blocker**.

> **Tool / write boundary observed.** This iteration used only `read_file`, `grep`, `glob`,
> and `write_file`. No `shell`, no delegation, no web access, no approval, no publishing,
> and no engineering acceptance. The task permits changing only the six named candidate
> source paths and this report. Of those, **exactly one file was written — this report**
> (`/workspace/.llm_tmp/overnight/reports/tool_findings_repair.md`). No source, build, test,
> config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was created, edited, or deleted, and
> every prior report under `.llm_tmp/overnight/prior-reports/` and
> `.llm_tmp/overnight/reports/` was preserved.

---

## 0. Summary

1. **The recorded GCC syntax failure is not present in the actual source and no correction
   is supported.** `score/socom/impl/service_identifier.hpp` is brace-balanced: a `grep`
   for `[{}]` returns exactly four lines — `:19` (`namespace score::socom {`), `:29`
   (`struct Service_instance_identifier final {`), `:32` (`};`), `:38`
   (`}  // namespace score::socom`) — two openers and two closers, net balance `0`. Line
   `:39` is blank and `:40` is `#endif`. Deleting a brace from the balanced file would
   *create* the reported defect. The collected GCC focused compile is exit `0` with empty
   stderr and its 91-case binary runs `91 / 0` (green). The description matches the stale,
   pre-correction split-namespace form quoted by the earliest prior reports, not this
   checkout. **No source edit was made.**
2. **The collected diagnostics contain no safe in-scope source correction either.** Every
   concrete analyzer / sanitizer / security finding either points outside the six candidate
   paths, or is an unavoidable gtest-macro expansion artifact that the task forbids
   suppressing. Each is recorded, not silenced, in §3–§5.
3. **The candidate registration-key slice is green in the collected captures.** The retained
   host validation (`check_conversion_tests`, UBSan) records the candidate compiling at exit
   `0` and the focused 91-case identifier suite passing `91 / 0`; the `native_test`
   `unit-component-tests` leg (Bazel `//:unit_tests //:component_tests`) is exit `0`; GCC and
   Clang focused compiles are both exit `0`; ASan/LSan/UBSan and Valgrind memcheck focused
   runs are exit `0`. These are **retained local, unprotected captures**, not native
   acceptance.
4. **No obligation is satisfied.** `authority.json` records `engineering_acceptance:
   pending`, `human_reviews: unanswered`, `safety_class: unknown`; every `source-index.json`
   entry is `native_acceptance: not_inferred`; full native runtime tests are
   `not_executed`; coverage is below the safety/QM branch goals; the MISRA mapping is draft.

---

## 1. Binding and scope

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` | `.llm_tmp/context/issue-snapshot.json:2-4` |
| Title | *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:3` |
| State | `open`, **0 comments**, no milestone / assignee / labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` | `.llm_tmp/context/issue-snapshot.json:19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**: service-instance identifier = `service id + major + minor + instance id`;
service identifier = `service id + major`; FindService = `service id + major +
optional<minor> + optional<instance>`; with a proposal to *exclude the minor version and
make it a property of the service instance*. There is **no comment and no acceptance
record** in the snapshot. Binding is **by baseline commit**, not by run HEAD.

### 1.2 The only writable source paths (`.llm_tmp/context/candidate-files.json:1-25`)

1. `score/socom/BUILD`
2. `score/socom/impl/service_identifier.cpp`
3. `score/socom/impl/service_identifier.hpp`
4. `score/socom/test/unit/BUILD`
5. `score/socom/test/unit/runtime_tests.cpp`
6. `score/socom/test/unit/service_identifier_tests.cpp`

`glob **/service_identifier*.{hpp,cpp}` returns exactly three paths
(`impl/service_identifier.cpp`, `impl/service_identifier.hpp`,
`test/unit/service_identifier_tests.cpp`), so there is **no second, differently-braced copy**
of the header in this checkout. The `null` baseline blob for
`service_identifier_tests.cpp` in the manifest is the expectation of a **new** test file; it
exists only in the un-merged working tree (the task's *"cancelled draft"*).

### 1.3 Prior reports read and preserved

- **`.llm_tmp/overnight/prior-reports/` — 38 files** (all preserved; the earlier
  `tool_findings_repair.md` there was read in full).
- **`.llm_tmp/overnight/reports/` — 13 files** of this run, read and preserved:
  `scope.md`, `invariants.md`, `callsites.md`, `reproducer.md`, `key_fix.md`,
  `unit_matrix.md`, `ordering_tests.md`, `conversion_tests.md`,
  `repair_conversion_tests.md`, `runtime_disabled.md`, `runtime_enabled.md`,
  `lifetime_tests.md`, `test_metadata.md`. This document adds
  `tool_findings_repair.md`; no prior report was overwritten.

Derived sequence: `scope.md` → `invariants.md` → `callsites.md` → `reproducer.md` (header
brace correction; key-level red regression) → `key_fix.md` / `unit_matrix.md` (drop `minor`
from the key ordering) → `ordering_tests.md` / `conversion_tests.md` →
`repair_conversion_tests.md` (root-cause fix of one failing conversion case) →
`runtime_disabled.md` / `runtime_enabled.md` / `lifetime_tests.md` → `test_metadata.md`.

### 1.4 Latest host feedback and collected obligations (read this iteration)

The `.llm_tmp/overnight/validation/` and `.llm_tmp/overnight/obligations/` trees are
**present** in this checkout and were read:

- `validation/measurement.json` — `check_ref: check_conversion_tests`, `status: completed`,
  `mode: ubsan`, `changed_paths: ["score/socom/test/unit/service_identifier_tests.cpp"]`,
  `origin: local_unprotected_measurement`, `initiator: Fabro host hook`,
  `engineering_acceptance: pending`, `full_native_tests: not_executed`, compiler
  `/usr/bin/x86_64-linux-gnu-g++-12`. Candidate: `compile_exit 0`, `test_exit 0`,
  `tests 91`, `failures 0` (`:2052-2058`). Baseline-with-agent-tests: `compile_exit 0`,
  `test_exit 1`, `tests 91`, `failures 33` (`:2045-2051`). This is the red→green transition
  of the key change + conversion-case repair.
- `validation/after.json` — 91 tests, 0 failures; `validation/after-compile.stderr` empty;
  `validation/check-result` = `0` (retention marker, not a pass marker).
- `validation/before.json` / `before-compile.stderr` — the pre-correction key: 33 failures
  (e.g. `KeysDifferingOnlyInMinorVersionAreDuplicates` inserts `true`; `MinorVersionNever…
  Ordering` orders a low/high minor). These are the baseline expectations, not the current
  tree.
- `obligations/*/result.json` and per-command captures for 24 checks (compiler, cppcheck,
  clang-tidy, CodeQL security + MISRA, ASan/LSan/UBSan, TSan, Valgrind, coverage, native
  build/tests/integration/lint/docs/traceability/sanitizers/tsan/coverage/performance,
  cross-compilation, format/pre-commit, secret/dependency, process, tool assurance).

Pinned authority (`.llm_tmp/context/obligations/authority.json`):
`engineering_acceptance: pending`; `human_reviews: unanswered`; `safety_class: unknown`;
`codeql_scope: Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload`. Every
`source-index.json` entry is `native_acceptance: not_inferred`. The pinned platform
documents carry `:safety: ASIL_B`, but the document attribute is **not** an authorized
selection of this slice's safety class and is not inferred as one.

---

## 2. The recorded GCC syntax failure — inspection of the actual source

`score/socom/impl/service_identifier.hpp` (read this iteration) is **brace-balanced**; it is
40 lines. A `grep` for `[{}]` returned exactly four matches:

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers and two closers give a net brace balance of `0`; there is **no third, unmatched
closing brace**, and line 39 contains no text. The sibling
`score/socom/impl/service_identifier.cpp` is balanced the same way (braces at `:18`, `:20`,
`:30`, `:32`).

**Independent corroboration from the retained artifacts.** The focused GCC compile of
`service_identifier.cpp` + `string_registry.cpp` + `service_identifier_tests.cpp` is
`exit_code 0` with an empty stderr
(`obligations/compiler_diagnostics/result.json:1152`,
`compiler_diagnostics/gcc-compile.stderr` empty); the follow-on `gcc-tests` run is
`exit_code 0` (`:1174`), and the retained host validation repeats candidate
`compile_exit 0` / `test_exit 0` / `91` / `0`. A surviving unmatched brace in a header
compiled into that translation unit would have failed those compiles, not passed them.

**Disposition: no correction applied and none is supported.** Applying the historical
split-namespace repair to the already-balanced file would be a no-op; deleting a brace would
*introduce* the reported syntax error. The smallest correct change to already-correct source
is **no change**. (The `reports/reproducer.md` §2 repair diff is retained for reference
only.)

---

## 3. Original diagnostics read this iteration (per tool, with raw artifact)

All paths are relative to `/workspace`. "In scope?" asks whether the flagged location is one
of the six writable candidate paths.

| Tool / check | Raw artifact read | Result | In-scope location? |
|--------------|-------------------|--------|--------------------|
| GCC compile + tests (focused) | `obligations/compiler_diagnostics/result.json:1152,1174`; `gcc-compile.stderr` (empty) | compile exit 0; tests exit 0 | yes — **clean** |
| Clang compile + tests (focused) | `obligations/compiler_diagnostics/result.json:1274,1296`; `clang-compile.stderr` (empty) | compile exit 0; tests exit 0 | yes — **clean** |
| cppcheck (focused) | `obligations/focused_cppcheck/cppcheck.stderr`; `result.json` (exit 2) | 19 `id="passedByValue"`, severity performance | **no** — all in headers (`registry_string_view.hpp`, `service_interface_identifier.hpp`) |
| clang-tidy (focused) | `obligations/focused_clang_tidy/native-config.stderr`; `result.json:1077` | exit 1; 15 "unknown check" warnings on the repo `.clang-tidy` | **no** — config blocker |
| CodeQL security | `obligations/codeql_security/result.json` (exit 0) | findings only under `.llm_tmp/googletest/**` | **no** — dependency only |
| CodeQL MISRA | `obligations/codeql_misra/result.json` (exit 0) | googletest self-assignment; `external-linkage-not-declared-in-header-file-misra` on `service_identifier_tests.cpp` `TEST_F` lines | **partly** — gtest-macro artifact only |
| ASan / LSan / UBSan (focused) | `obligations/focused_asan_lsan/result.json:1091,1115`; `tests.stderr` (empty) | compile exit 0; tests exit 0 | yes — **pass** |
| TSan (focused) | `obligations/focused_tsan/result.json:1114`; `tests.stderr` | compile exit 0; tests exit 66; `FATAL: ThreadSanitizer: unexpected memory mapping` | **no** — kernel/ASLR environment |
| Valgrind memcheck (focused) | `obligations/focused_memcheck/result.json:1089,1116`; `memcheck.stderr` (empty) | compile exit 0; memcheck exit 0 | yes — **pass** |
| Coverage (focused) | `obligations/focused_coverage/coverage-summary.json` | line 36/36 = **100 %**; branch 11/14 = **78.6 %** | yes but below goal |
| native build | `obligations/native_build/result.json:1078` | `bazel build //...` exit 0 | yes — **compiled** |
| native tests | `obligations/native_tests/result.json:1079` | `bazel test //... --build_tests_only` exit 0 (builds only) | yes — **compiled** |
| native sanitizers | `obligations/native_sanitizers/result.json:1083` | `bazel test … --build_tests_only --features=asan,lsan,ubsan_clang` exit 0 (builds only) | yes — **built** |
| native unit/component tests | `obligations/native_traceability/result.json:1079` | `bazel test //:unit_tests //:component_tests` exit 0 | yes — **ran green** |
| native integration | `obligations/native_integration/result.json:1080` | exit 1 (QEMU leg) | n/a — tool/infra |
| native lint | `obligations/native_lint/result.json:1079,1105` | clang-tidy exit 124 (timeout); ruff exit 0 | n/a — tool |
| native docs | `obligations/native_docs/result.json:1078` | `//:docs` exit 2 | n/a — docs/infra |
| native traceability | `obligations/native_traceability/result.json:1105,1135` | `//:docs` exit 2; `//:traceability_gate` exit 1 | n/a — traceability/infra |
| native coverage | `obligations/native_coverage/result.json:1080,1110` | exit 0 / exit 0 | partial — see focused coverage |
| native performance | `obligations/native_performance/result.json:1081,1110` | exit 124 / exit 124 (timeouts) | n/a — tool |
| native tsan | `obligations/native_tsan/result.json:1081` | exit 0 (build/limited leg) | partial |
| cross compilation | `obligations/cross_compilation/result.json:1082,1110` | x86 exit 0; arm exit 0 | yes — **cross-compiles** |
| format / pre-commit | `obligations/format_precommit/result.json:1076,1101,1128,1173,1198,1224`; `reuse.stdout`; `precommit.stdout` | git-init 0, git-add 0; pre-commit 124 (timeout); reuse lint 1; module-tidy 0; lockfile 0; retained precommit stdout shows hooks Passed | **no** for reuse (`.bazel_config`, `third_party/…patch`) |
| secret / dependency scan | `obligations/secret_dependency_checks/result.json:1080`; `secret-findings.json`; `gitleaks.stderr` | gitleaks exit 1; 92 leaks | **no** (see §3.6) |
| process checks | `obligations/process_checks/result.json:1052-1081` | `completed_with_blockers`; metadata inventory: `runtime_tests.cpp` 33 macros, `service_identifier_tests.cpp` 91 macros, both with `DerivationTechnique`+`Description` | yes — metadata only |
| tool assurance | `obligations/tool_assurance/result.json` (15 version commands) | all exit 0 | n/a |

**Note on the prior report's Clang blocker.** The earlier
`prior-reports/tool_findings_repair.md` §4.2 recorded a Clang `-Wdeprecated-declarations`
error reached from `.llm_tmp/googletest`. The current collected Clang focused compile is
**exit 0** (`clang-compile.stderr` empty). The environment/toolchain differs between runs;
the earlier reading is superseded by the retained artifact for this checkout. No Clang
in-scope defect remains.

---

## 4. Concrete source-defect assessment (per tool)

### 4.1 Compiler — GCC and Clang (focused): clean, and the named defect is absent

Both focused GCC and Clang compiles of `service_identifier.cpp` + `string_registry.cpp` +
`service_identifier_tests.cpp` are exit 0 with empty stderr; the retained host validation
adds candidate `test_exit 0 / 91 / 0`. **No in-scope compiler defect. No correction.**

### 4.2 cppcheck — findings in headers outside the six paths

`obligations/focused_cppcheck/cppcheck.stderr` exit 2; all 19 findings are
`id="passedByValue"` (severity `performance`, CWE-398). `file0` is the candidate
`service_identifier.cpp`, but every `<location>` is an included header outside the six paths:

- `score/socom/registry_string_view.hpp` lines 127, 134, 141, 148, 155, 162 (lhs/rhs) and
  173 (`v`) — 13 findings;
- `score/socom/service_interface_identifier.hpp` lines 37, 41, 48, 99, 105, 113 (`new_id`)
  — 6 findings.

These are performance style suggestions on small view/value types, are not correctness
defects, and lie outside the writable paths. Fixing them would require editing headers the
task forbids changing. **Remaining finding (out of scope); no correction.**

### 4.3 clang-tidy — configuration rejected, so no run

`obligations/focused_clang_tidy/native-config.stderr` shows `clang-tidy --verify-config`
rejecting the repository `.clang-tidy` with 15 "unknown check" warnings (e.g.
`bugprone-use-after-move`, `modernize-type-traits`,
`modernize-use-integer-sign-comparison`). The recorded blocker is *"Native analyzer
configuration incompatible; no replacement called MISRA"*; the `native_lint` clang-tidy leg
additionally timed out (exit 124). The repo config must not be edited here and no rule may
be suppressed. **Remaining finding; blocker; no in-scope correction.**

### 4.4 CodeQL security — dependency only

Every finding in `obligations/codeql_security/result.json` (`cpp/fixme-comment`,
`cpp/commented-out-code`, `cpp/large-parameter`, `cpp/equality-on-floats`,
`cpp/unused-static-*`, `cpp/rule-of-two`, `cpp/include-non-header`, `cpp/trivial-switch`,
`cpp/loop-variable-changed`, `cpp/path-injection`) has a `uri` under
`.llm_tmp/googletest/**`. **No finding in any of the six candidate paths; no correction.**

### 4.5 CodeQL MISRA — dependency finding + gtest-macro artifact on the test file

`obligations/codeql_misra/result.json` contains:

- `cpp/misra/copy-and-move-assignments-shall-handle-self-assignment` located in
  `.llm_tmp/googletest/googletest/include/gtest/internal/gtest-filepath.h` (dependency), and
- `cpp/misra/external-linkage-not-declared-in-header-file-misra` located in
  `score/socom/test/unit/service_identifier_tests.cpp` at many `TEST_F` lines
  (e.g. `:2181`, `:2150`, `:2103`, …, all `startColumn 8`). This is the **`TEST_F` macro
  expansion**: gtest synthesizes an externally-linked test-registration
  object/function whose declaration is not in a header. **No finding is located in
  `service_identifier.cpp`, `service_identifier.hpp` or `runtime_tests.cpp`.**
- The authored helpers in the file are `static` member functions of the fixture
  (`identity_of`, `make_identifier`, `equivalent`, the domain builders —
  `service_identifier_tests.cpp:86-155`), so the finding is not about the authored bodies.

The collector's own blockers are *"MISRA applicability/mapping draft and incomplete"*,
*"Default suite omits manual/audit obligations"*, and *"Compiled query qualification and
human deviations pending"*; `misra_mapping.rst` is `:status: draft`. A fix would require
suppressing the rule, editing the test framework, or an accepted human deviation — the
first two are prohibited and the third is unavailable. **Remaining finding; needs human
deviation; no in-scope correction.**

### 4.6 Sanitizers and memory checking — focused runs pass; TSan is an environment failure

- `focused_asan_lsan`: compile exit 0 and tests exit 0, stderr empty. **Pass (focused
  identifier scope only).**
- `focused_memcheck`: compile exit 0 and memcheck exit 0 (Valgrind present in the tool
  root), stderr empty. **Pass (focused scope only).**
- `focused_tsan`: compile exit 0, tests exit 66, stderr
  `FATAL: ThreadSanitizer: unexpected memory mapping 0x…`. This is the known TSan/ASLR
  kernel-mmapping incompatibility, not a reported data race; the focused identifier tests
  are single-threaded. **Remaining environment blocker; no source correction.**

### 4.7 Coverage — measured, below the platform branch goal

`obligations/focused_coverage/coverage-summary.json` (focused `service_identifier.cpp` +
`string_registry.cpp` executable): overall **36/36 lines = 100 %**, **11/14 branches =
78.6 %**; `service_identifier.cpp` 3/3 lines (100 %) and 1/2 branches (50 %);
`string_registry.cpp` 33/33 lines (100 %) and 10/12 branches (83.3 %). The line goal is met
for these files, but branch coverage is below the platform safety 100 % goal (and below a
QM 85 % branch reading). This is a **scoped** reading, not full native coverage, and it is
not a source defect. **Not satisfied; no in-scope correction follows.**

### 4.8 Native / cross / perf / docs / traceability legs

- `native_build` (`bazel build //...`) exit 0; `native_tests` and `native_sanitizers`
  (`--build_tests_only`) exit 0; the `unit-component-tests` leg
  (`bazel test //:unit_tests //:component_tests`) exit 0; `cross_compilation` x86 and arm
  exit 0. These are strong *build* and *unit/component* signals for the candidate.
- `native_integration` (QEMU) exit 1, `native_lint` clang-tidy exit 124 (timeout),
  `native_docs` `//:docs` exit 2, `native_traceability` docs exit 2 / traceability-gate
  exit 1, `native_performance` timeouts (exit 124): all are **tool / infrastructure /
  documentation-gate failures**, not candidate-source defects. **Blockers; no in-scope
  correction.**

### 4.9 Format / pre-commit / reuse

`obligations/format_precommit/`: git-init 0, git-add 0, module-tidy 0, lockfile 0; the
pre-commit leg timed out (exit 124) but the retained `precommit.stdout` shows the hooks
that did run all *Passed* (`fix end of files`, `trim trailing whitespace`, executable/shebang
checks, `cr_checker` copyright headers, `reuse lint-file`, `bazel mod tidy`, lockfile,
`shellcheck`, `yamlfmt`). The separate `reuse lint` leg (exit 1) reports the project is not
REUSE-compliant for exactly two files — `.bazel_config` and
`third_party/score_baselibs/restore_qnx8_poll_workaround.patch` — **both outside the six
paths** (`reuse.stdout`). No formatting or licensing defect exists in the six candidate
paths. **Out-of-scope findings; no correction.**

### 4.10 Secret / dependency scan — false positives from the collected artifacts + a QNX build file

`obligations/secret_dependency_checks/` (gitleaks exit 1; 92 reported leaks). Every
`generic-api-key` finding's `File` is one of the collected `.llm_tmp/overnight/obligations/*/
result.json` artifacts themselves (the tool-path hash strings such as `lackey-x86-linux`),
and the single `private-key` finding is
`quality/integration_testing/environments/qnx8_qemu/init_x86_64.build` (a pre-existing QNX
test configuration, outside the six paths). **No secret finding is in any of the six
candidate paths; no correction.** The collector's own limit notes the absence of an adopted
vulnerability database / dependency-scan receipt.

### 4.11 Process / traceability metadata

`obligations/process_checks/result.json` is `completed_with_blockers`; its metadata inventory
records `runtime_tests.cpp` (33 test macros) and `service_identifier_tests.cpp` (91 test
macros), each carrying `DerivationTechnique` and `Description` (no `TestType`/`Verifies`,
deliberately, because no verified native requirement identifier exists and inventing one is
prohibited). Its blockers are *"Lexical metadata inventory cannot prove semantic requirement
coverage"*, *"Safety/QM applicability and approved tailoring unknown"*, *"Independent
inspection and acceptance required"*, and *"External AoU and full integration verification
require scoped review"*. **Metadata present; traceability linkage and `TestType` not
established.**

---

## 5. Conclusion on source corrections

**No safe in-scope source correction is supported by any of the retained diagnostics.**
Specifically:

1. The named GCC syntax failure is **not present**; the header is brace-balanced and both
   focused compilers (GCC, Clang) compile the candidate at exit 0 with the focused suite
   green (91 / 0) in the retained captures (§2, §4.1).
2. Every concrete cppcheck / CodeQL / reuse / secret finding either points outside the six
   candidate paths or is an unavoidable gtest-macro expansion artifact on the test file
   (§4.2, §4.4, §4.5, §4.9, §4.10).
3. Where an in-scope location is flagged (the `TEST_F` `external-linkage` MISRA hits), the
   only "fixes" available are suppressing the rule, editing the test framework, or an
   accepted human deviation — all prohibited or unavailable here (§4.5).
4. The remaining checks are blocked by missing/unstable tooling (clang-tidy config and
   timeout, docs / traceability gates, performance timeouts, QEMU integration), a
   kernel-environment incompatibility (TSan mmapping), or are below a coverage goal — none
   is a candidate-source defect (§4.6–§4.8).
5. The current key behaviour is the intended, green one: `operator<` compares
   `(instance, service id, major)` with `minor` excluded
   (`score/socom/impl/service_identifier.cpp:28-29`), and the retained captures show the
   pre-correction baseline red (33 failures) and the candidate green (0).

Accordingly this iteration changed the six candidate paths **not at all**, and wrote only
this report.

---

## 6. Files changed / state of the six candidate paths

| Candidate path | This iteration |
|----------------|----------------|
| `score/socom/BUILD` | inspected, **unchanged** |
| `score/socom/impl/service_identifier.cpp` | inspected, **unchanged** (key identity `(instance, id, major)`, `:28-29`) |
| `score/socom/impl/service_identifier.hpp` | inspected, **unchanged** (brace-balanced, §2) |
| `score/socom/test/unit/BUILD` | inspected, **unchanged** |
| `score/socom/test/unit/runtime_tests.cpp` | inspected, **unchanged** |
| `score/socom/test/unit/service_identifier_tests.cpp` | inspected, **unchanged** (91 `TEST_F`) |
| `.llm_tmp/overnight/reports/tool_findings_repair.md` | **new — this report** |

No file outside the six candidate paths and this report was written; no `NOTICE`, `LICENSE`,
or `REUSE.toml` file was created, edited, or deleted; all prior reports were preserved.

---

## 7. Obligations status (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Freedom from compiler warnings & errors (100 %) | `verification_plan.rst` (criterion 9) | **PARTIAL, LOCAL** — focused GCC and Clang compiles exit 0; candidate 91/0 in the retained host capture; not a native `-Werror` run of the full tree |
| Static code analysis (clang-tidy / CodeQL), findings classified | `code_analysis.rst`; `verification_process.rst` (`gd_req__verification_sca_classification`) | **NOT SATISFIED** — clang-tidy config rejected / timed out; cppcheck findings out of scope; CodeQL security dependency-only; CodeQL MISRA draft applicability + gtest-macro hits needing human deviation |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` (draft) | **UNKNOWN — NOT CLAIMED** — mapping is `:status: draft`; human deviations pending |
| Structural statement / branch coverage goals | `verification_plan.rst` (criteria 1–2) | **NOT MEASURED TO GOAL** — focused 100 % line / 78.6 % branch, below the safety branch goal; not full native coverage |
| Unit/component testing executed, results recorded | `verification_plan.rst` (criteria 6–7); `verification_guideline.rst` | **PARTIAL, LOCAL** — `unit-component-tests` exit 0; focused candidate 91/0; `full_native_tests: not_executed` |
| Interface / requirements-based / resource / fault-injection test types | `verification_process.rst`; `verification_plan.rst` | **NOT PERFORMED / applicability not inferred** — no harness; identifier-only tests must not be labelled platform validation |
| Boundary / equivalence derivation | `verification_process.rst` | **SOURCE + FOCUSED RUN ONLY** — cases exist; focused TU executed; full native suite not run |
| Fuzzy testing technique | `verification_plan.rst` | **NOT EXECUTED / NOT CLAIMED** — no harness, no measurement |
| Linking tests to requirements (record properties) | `verification_process.rst` (`gd_req__verification_link_tests_cpp`) | **PARTIAL / NOT DONE** — `DerivationTechnique`/`Description` recorded; `TestType`/`Verifies` cannot be set without inventing identifiers |
| External-component AoUs verified | `verification_process.rst` (`gd_req__verification_external_aou`) | **NOT SATISFIED** — no integration/static verdict; no AoU register |
| Independence of verification / review by a different committer | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Implementation inspection checklist IMPL_01…IMPL_03 | `inspection_checklist.rst` (draft) | **NOT FILLED** |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** — clang-tidy unusable (config / timeout); docs/traceability/perf legs failing; tool-chain pins not demonstrated |
| Obligation collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **RETAINED, NOT PASSING** — 24 checks present; blockers above and in §4 |
| Native acceptance | `source-index.json` | **`not_inferred` for every entry** |

**Explicit non-satisfaction statement.** Missing/unstable tooling, the unknown safety class
and un-inferred applicability, incomplete extraction (focused translation units; dependency
findings retained), below-goal focused branch coverage, the draft MISRA mapping, and the
unanswered human reviews mean **none of the checked obligations may be treated as
satisfied**. A retained collection result shows *retention*, not passing.

---

## 8. Measurement and validation status

- **Tools:** `read_file`, `grep`, `glob`, `write_file` only. No `shell`, delegation, web,
  approval, publishing, or engineering acceptance.
- **Executed measurements this iteration:** none. All results above are readings of the
  retained tool artifacts and of the working tree.
- **Scope of the retained runs:** the focused compile/analyze/sanitize/memcheck/coverage
  runs cover the **focused identifier translation unit** (`service_identifier.cpp` +
  `string_registry.cpp` + `service_identifier_tests.cpp`). The native legs build the broader
  tree; `unit-component-tests` ran `//:unit_tests //:component_tests`. Full native runtime
  tests are `full_native_tests: not_executed`.
- **Regression target (retained capture, not re-run here):**
  `RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError`
  (`runtime_tests.cpp:402-431`) and the key-level minor-collapse cases assert that a second
  registration differing only in `minor` is rejected as `duplicate_service`; the retained
  baseline capture is red (33 failures) and the candidate capture is green (0).
- **Scope statement:** local, unprotected, scoped. This report is not acceptance, review,
  publication, or a full native run.
- **Reproduction path for a later, permitted iteration (not executed here):**

  ```bash
  bazel build //score/...
  bazel test //score/socom/test/unit:socom_test
  bazel test //score/socom/test/unit:socom_test --test_filter='ServiceInstanceIdentifierTest.*'
  bazel test //score/socom/test/unit:socom_test \
      --test_filter='RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError'
  bazel test --config=qemu-integration //tests/integration_test/...
  ```

---

## 9. Notice preservation

- No source, build, test, config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was created,
  edited, or deleted by this iteration; only this report was written. Every existing
  Apache-2.0 / SPDX notice header is untouched.
- All 38 files under `.llm_tmp/overnight/prior-reports/` and all 13 earlier files under
  `.llm_tmp/overnight/reports/` were preserved unchanged; in particular the earlier
  `prior-reports/tool_findings_repair.md` was not overwritten.
- The header the task flagged (`score/socom/impl/service_identifier.hpp`) was inspected and
  left unchanged because it is already brace-balanced and otherwise well-formed (§2).
- This report carries the Apache-2.0 header. No licensed MISRA rule text is reproduced; only
  native rule/query identifiers, file locations, and retained-artifact readings are cited.

---

## 10. Pending human review checklist

- [ ] **Confirm §2:** the header is brace-balanced (braces at `:19`, `:29`, `:32`, `:38`;
      line 39 blank), and the focused GCC/Clang compiles are exit 0, so the recorded syntax
      failure is stale and no source edit is required. If the *"cancelled draft"* is a
      different revision that still carries the extra brace, locate it and authorize its
      correction; no such file exists in this checkout.
- [ ] **Disposition the CodeQL MISRA `external-linkage` findings** on
      `service_identifier_tests.cpp` (§4.5): confirm they are gtest-macro artifacts and
      record an accepted deviation, or provide tooling that models the macro; do not
      suppress the rule silently.
- [ ] **Restore a working clang-tidy configuration / tool version** (§4.3) so a real run can
      be collected; do not edit the repo `.clang-tidy` inside this slice.
- [ ] **Disposition the cppcheck `passedByValue` findings** (§4.2) — they are in
      `registry_string_view.hpp` and `service_interface_identifier.hpp`, out of scope;
      confirm acceptable or open a separate change.
- [ ] **Provide a TSan-capable environment or an accepted exclusion** (§4.6), and stabilize
      the docs / traceability / performance / QEMU legs (§4.8) so the remaining blockers
      become results.
- [ ] **Raise branch coverage to the selected goal** (§4.7) and run the full native suite
      (`bazel test //score/socom/test/unit:socom_test` and the broader `//score/...` set),
      recording results including `runtime_tests.cpp`.
- [ ] **Select a safety class** via the authorized role; do not infer the slice's class from
      the `:safety: ASIL_B` attribute on the pinned platform documents.
- [ ] **Resolve authority:** `engineering_acceptance: pending`, `human_reviews: unanswered`;
      schedule independent human review (`gd_req__verification_independence`).
- [ ] **Keep the #84 public `Service_interface_identifier` restructure, FindService wildcard
      handling, and the config minor-wildcard narrowing out of this bounded slice** until
      separately accepted, and do not present the identifier-only tests as platform
      validation or claim an unmeasured fuzzy technique.

---

*End of tool-findings repair report. Local, unprotected, scoped. No engineering acceptance;
human reviews unanswered; full native runtime tests pending. Every statement is a local
reading of the working tree, a retained local tool artifact, or an explicitly-labelled
logical consequence — none is acceptance, review approval, publication, or a full native
run.*
