<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — sanitizer review (ASan / LSan / UBSan / TSan) review draft

**Document type:** review draft (retained sanitizer-artifact audit + scope analysis +
runtime-startup-vs-source-defect discrimination + runtime connector teardown / slot-reuse
coverage assessment + obligations status).

**Date:** 2026-10-03
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version
handling in socom* (issue #84)
**Run / branch:** `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ`
**Verified baseline commit:** `f8a196c3b16d5172d898394ab99b0ed81346d63d`
(`.llm_tmp/context/source-manifest.json:3`)
**Status:** **local, unprotected, scoped.** No engineering acceptance exists. Human
reviews are unanswered. Full native runtime tests are pending. Every statement below is a
direct reading of the working tree, a direct reading of a *retained* artifact under
`.llm_tmp/overnight/`, or an explicitly-labelled logical consequence. Nothing here is
acceptance, review approval, publication, or a full native run.

> **Tool / write boundary observed.** This iteration used only `read_file`, `grep`,
> `glob`, and `write_file`. No `shell`, no delegation, no web access, no approval, no
> publishing, and no engineering acceptance was performed. The task's final sentence —
> *"This is a review draft: only that report may be written."* — is the operative write
> boundary. **This iteration wrote exactly one file — this report.** No source, build,
> test, config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was created, edited, or deleted,
> and every prior report under `.llm_tmp/overnight/reports/` and
> `.llm_tmp/overnight/prior-reports/` was preserved unchanged.

> **Instruction conflict (recorded, not silently resolved).** The task records *"a measured
> GCC syntax failure: an extra closing brace in `score/socom/impl/service_identifier.hpp`
> at line 39"* and directs *"Inspect and correct the actual source before expanding tests"*,
> while its explicit and more specific final sentence says *"This is a review draft: only
> that report may be written."* Direct inspection of the **actual** source (§2) shows the
> header is **already brace-balanced** — there is no extra closing brace to remove, and the
> focused GCC/Clang/ASan/TSan compiles of the same translation unit all exit `0`. Applying
> the historical repair would be a no-op; deleting a brace would *create* the reported
> defect. The write boundary forbids a source write in any case. **No source was edited and
> no test was expanded.** The conflict is recorded for human disposition (§11).

> **Non-satisfaction rule applied throughout.** A successful obligation-collection node
> means the results were **retained**, not that the checks **passed**. Missing tools,
> unknown applicability, incomplete/extracted evidence (focused translation units;
> dependency findings retained), a draft/inactive rule mapping, and unanswered human
> reviews are **not** treated as satisfied. A tool that produced **no** finding because it
> **did not run** is recorded as *"not run"*, never as *"clean"*.

---

## 0. Summary

1. **The recorded GCC syntax failure is not present in the actual source (§2).**
   `score/socom/impl/service_identifier.hpp` is a 40-line, brace-balanced header; line 39
   is blank. The retained focused **GCC** compile (`gcc-compile`) and the focused **ASan**
   and **TSan** compiles of the same translation unit each exit `0` with empty stderr. No
   source correction was applied and none is required.
2. **ASan + LSan + UBSan pass, but only on the focused identifier translation unit (§3).**
   `focused_asan_lsan` compiles `service_identifier.cpp` + `string_registry.cpp` +
   `service_identifier_tests.cpp` + gtest with
   `-fsanitize=address,leak,undefined -fno-sanitize-recover=all` (compile exit `0`), runs
   them with `ASAN_OPTIONS=detect_leaks=1:halt_on_error=1` and
   `UBSAN_OPTIONS=halt_on_error=1` (tests exit `0`), and reports **91/91 passed** with empty
   `stderr`. The host `validation` UBSan measurement reproduces the candidate at **91 / 0**
   against a baseline of **91 / 33**. This is a genuine *focused* pass for the changed key
   unit and the linked string registry — **not** a runtime/connector sanitizer result and
   **not** a full `//score/...` run.
3. **The focused TSan check is an infrastructure/startup failure, not a source defect (§4).**
   `focused_tsan` compiles the same focused TU (`-fsanitize=thread -g`, compile exit `0`)
   but the test process exits **`66`** with `stderr` =
   `FATAL: ThreadSanitizer: unexpected memory mapping 0x648d7a092000-0x648d7a0a5000`.
   That is the known TSan / kernel-ASLR mmapping incompatibility. It aborts before gtest's
   `Running main()` line (stdout empty), the same code passes ASan/LSan/UBSan, and the
   focused tests are single-threaded. **No data race is reported; no source defect is
   indicated; freedom from races is not established.**
4. **The *native* sanitizer legs did run tests and passed, superseding an earlier
   "build-only" reading (§5).** `native_sanitizers`
   (`bazel test //score/... //tests/... --features=asan --features=lsan --features=ubsan_clang`,
   exit `0`) records `Executed 19 out of 27 tests: 19 tests pass and 8 were skipped`, with
   `//score/socom/test/unit:socom_test` **PASSED in 0.6s** fresh (not cached).
   `native_tsan` (`--features=tsan`, exit `0`) records `Executed 5 out of 27 tests: 19 tests
   pass and 8 were skipped`, with `socom_test` **PASSED in 1.1s** fresh and
   `//score/socom/test/stress:socom_stress_test` **PASSED in 15.9s** fresh. The eight
   skipped targets are the integration/benchmark suites. The prior
   `prior-reports/sanitizer_review.md` and `finding_classification.md` recorded these legs
   as "not run" / "build-only"; the retained artifacts for this run record executed tests,
   so the current artifacts govern.
5. **Runtime connector teardown / slot reuse is now covered by the native legs, but not by
   the focused ones (§6).** The focused sanitizer executables do **not** contain
   `runtime_tests.cpp` or `runtime_impl.cpp`. The native Bazel legs *do* include
   `//score/socom/test/unit:socom_test` (which links `runtime_impl.cpp` and contains the 33
   teardown/slot-reuse runtime test macros) and it passed under both the sanitizer and TSan
   feature runs. Instrumentation strength is requested via feature flags but not
   independently proven from the captured output; the native sanitizer evidence therefore
   remains **partial/local**, not acceptance.
6. **Memcheck now runs and passes, focused scope only (§3.4).** `focused_memcheck` compiles
   the focused TU (exit `0`) and `valgrind --tool=memcheck --leak-check=full
   --error-exitcode=42` exits `0` with empty stderr. The prior report's `exit 127`,
   "valgrind unavailable" reading is superseded.
7. **No obligation is satisfied (§9).** Every `source-index.json` entry is
   `native_acceptance: not_inferred`; `authority.json` records `engineering_acceptance:
   pending`, `human_reviews: unanswered`, `safety_class: unknown`. The focused runs cover
   only the identifier TU; the native runs are partial, partly cached, skip the eight
   integration/benchmark targets, and are local/unprotected. Missing native coverage,
   unknown applicability, and unanswered human reviews are all treated as blockers.

---

## 1. Binding, scope, and evidence

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` — *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:2-4` |
| State | `open`, **0 comments**, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` | `.llm_tmp/context/issue-snapshot.json:19-20` |
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**: service-instance identifier = `service id + major + minor + instance id`;
service identifier = `service id + major`; FindService = `service id + major +
optional<minor> + optional<instance>`; and the proposal to exclude `minor` from identity and
make it an instance property. There is no comment and no acceptance record, so none of it is
binding. Binding is **by baseline commit**, not by run HEAD.

### 1.2 The six writable candidate source paths

From `.llm_tmp/context/candidate-files.json` (cross-checked against the `files` array of
`.llm_tmp/context/source-manifest.json`):

| File (repo-relative) | Baseline git blob | Working tree (read this iteration) |
|----------------------|-------------------|-------------------------------------|
| `score/socom/BUILD` | `3477ea0851fdcd82ec6ea9d71424013cbdf41962` | `testonly` `impl_service_identifier` exposure present |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e22355242009fe20dada2a9a0d0c7a9c7` | key identity `(instance, id, major)`; `minor` excluded (`:28-29`) |
| `score/socom/impl/service_identifier.hpp` | `c8bae7908da9f087c518934f7b9f8d86db9a20ec` | brace-balanced, 40 lines, `:39` blank (§2) |
| `score/socom/test/unit/BUILD` | `3c03a7b14286051f97fa5022206564bd63645171` | `socom_test` globs `*.cpp`; deps wired |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab726db8bf994c960045d6fd7fdf84d7395` | 33 test macros; teardown/slot-reuse suite (§6) |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(none — `null`)* | 91 `TEST_F`; metadata `SetUp()` |

The `null` baseline blob is the manifest's expectation of a **new** unit-test file; it
exists on disk only in the un-merged working tree (the task's *"cancelled draft"*). The
changed implementation is the registration-key comparator only:

```cpp
// score/socom/impl/service_identifier.cpp:20-30
bool operator<(Service_instance_identifier const& lhs, Service_instance_identifier const& rhs) {
    return std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major) <
           std::tie(rhs.instance, rhs.interface.id, rhs.interface.version.major);
}
```

i.e. identity is `(instance, service id, major)`; `minor` is deliberately excluded, matching
the minor-ignoring `Service_database` index (`score/socom/impl/runtime_impl.hpp:116-134`).

### 1.3 Retained sanitizer artifacts read this iteration

Paths are relative to `/workspace`; the files were **read**, not produced, here. Line
references are to the retained JSON unless a separate capture file is named.

| Artifact | What it records | Reading |
|----------|-----------------|---------|
| `.llm_tmp/overnight/obligations/focused_asan_lsan/result.json` | `check_ref: recollect_focused_asan_lsan`; focused TU; `compile` exit `0` (`:1091`), `tests` exit `0` (`:1115`), `status: completed` (`:1118`); limit *"Focused identifier executable; full native runtime scope measured separately"* (`:1121`) | **pass (focused)** |
| `.llm_tmp/overnight/obligations/focused_asan_lsan/tests.stdout` | `Running 91 tests from 1 test suite.` (`:2`); `[  PASSED  ] 91 tests.` (`:191`) | **91/91** |
| `.llm_tmp/overnight/obligations/focused_asan_lsan/compile.stderr`, `tests.stderr` | empty | no sanitizer diagnostic |
| `.llm_tmp/overnight/obligations/focused_tsan/result.json` | `check_ref: recollect_focused_tsan`; focused TU; `compile` exit `0` (`:1090`), `tests` exit **`66`** (`:1114`), `status: findings_or_execution_failure` (`:1117`); limit (`:1120`) | **no usable result (startup failure)** |
| `.llm_tmp/overnight/obligations/focused_tsan/tests.stderr` | `FATAL: ThreadSanitizer: unexpected memory mapping 0x648d7a092000-0x648d7a0a5000` (`:1`) | environment/startup failure |
| `.llm_tmp/overnight/obligations/focused_tsan/tests.stdout` | empty | process died before `main()` |
| `.llm_tmp/overnight/obligations/focused_memcheck/result.json` | `compile` exit `0` (`:1089`), `memcheck` exit `0` (`:1116`), `status: completed` (`:1119`); limit *"Optional complementary focused memory analysis"* (`:1122`) | **pass (focused)** |
| `.llm_tmp/overnight/obligations/focused_memcheck/memcheck.stderr` | empty | no memcheck error |
| `.llm_tmp/overnight/obligations/native_sanitizers/result.json` | `bazel test --jobs=2 //score/... //tests/... --build_tests_only --features=asan --features=lsan --features=ubsan_clang` (`:1055-1068`); exit `0` (`:1083`); `status: completed` (`:1086`) | **tests executed, pass (partial/minimal)** |
| `.llm_tmp/overnight/obligations/native_sanitizers/sanitizers.stdout` | `//score/socom/test/unit:socom_test PASSED in 0.6s` (`:14`); `Executed 19 out of 27 tests: 19 tests pass and 8 were skipped.` (`:29`) | 19 pass / 8 skipped |
| `.llm_tmp/overnight/obligations/native_tsan/result.json` | `bazel test --jobs=2 //score/... //tests/... --build_tests_only --features=tsan` (`:1055-1065`); exit `0` (`:1081`); `status: completed` (`:1084`) | **tests executed, pass (partial/minimal)** |
| `.llm_tmp/overnight/obligations/native_tsan/tsan.stdout` | `socom_stress_test PASSED in 15.9s` (`:25`); `socom_test PASSED in 1.1s` (`:26`); `Executed 5 out of 27 tests: 19 tests pass and 8 were skipped.` (`:29`) | 5 executed, 19 pass (14 cached), 8 skipped |
| `.llm_tmp/overnight/obligations/native_tests/tests.stdout` | `Executed 21 out of 29 tests: 21 tests pass and 8 were skipped.` (`:31`) | corroborates that `--build_tests_only` did not suppress execution |
| `.llm_tmp/overnight/obligations/compiler_diagnostics/result.json` | focused GCC TU; `gcc-compile` exit `0` (`:1152`); stderr empty | no compiler diagnostic |
| `.llm_tmp/overnight/obligations/process_checks/result.json` | metadata: `runtime_tests.cpp` `test_macros: 33` (`:1065`); `service_identifier_tests.cpp` `test_macros: 91` (`:1074`); status `completed_with_blockers` (`:1059`) | inventory |

### 1.4 Host validation feedback under `.llm_tmp/overnight/validation/`

- `check-result` = `0` — a **retention** marker, not a pass marker.
- `measurement.json` — `check_ref: check_conversion_tests`, `mode: ubsan`, `status:
  completed`, `changed_paths: ["score/socom/test/unit/service_identifier_tests.cpp"]`,
  `origin: local_unprotected_measurement`, `initiator: Fabro host hook`,
  `engineering_acceptance: pending`, `full_native_tests: not_executed`, compiler
  `/usr/bin/x86_64-linux-gnu-g++-12` (sha256 `88315fd2…`); `baseline_with_agent_tests`
  **91 / 33 / compile 0**, `candidate` **91 / 0 / compile 0**.
- `after.json` = **91 tests / 0 failures**; `before.json` = **91 tests / 33 failures**;
  `after-compile.command.json` builds the focused identifier TU with
  `-fsanitize=undefined -fno-sanitize-recover=all` (UBSan-only) and exits `0`;
  `after-compile.stderr`, `after-test.stderr` empty. This is the UBSan red→green of the key
  change, **focused on the identifier TU only**.

### 1.5 Pinned obligation sources and authority (all read this iteration)

All nine entries of `.llm_tmp/context/obligations/source-index.json` were read together with
`authority.json`. Every entry is pinned `"native_acceptance": "not_inferred"`.

| id | Pinned file | Status / content used here |
|----|-------------|----------------------------|
| `coding_guidelines` | `coding_guidelines.rst` | `:status: valid`; MISRA C++:2023, C++17 |
| `code_analysis` | `code_analysis.rst` | `:status: valid`; **Dynamic Code Analysis §53-104**: *"A dynamic code analysis is not explicitly required by any S-CORE related standards. However … following tools should be used"* — ASAN/LSAN, TSAN, UBSAN, Memcheck |
| `misra_mapping` | `misra_2023_rule_mapping.rst` | **`:status: draft`**; rule table not an active obligation |
| `verification_plan` | `software_verification.rst` | `:status: valid`; quality criteria incl. criterion 9 "Freedom from compiler warnings & errors" |
| `development_plan` | `software_development.rst` | `:status: valid`; C++17, GCC host compiler, Bazel |
| `tool_management` | `tool_management.rst` | `:status: valid`; tools identified / evaluated / qualified by a human |
| `verification_process` | `verification_process_reqs.rst` | `:status: valid`; test types, independence, SCA classification |
| `verification_guideline` | `verification_guideline.rst` | `:status: valid`; traceability, independence, documented results |
| `inspection_checklist` | `chklst_impl_inspection.rst` | **`:status: draft`**; blank template |

**Authority record** (`.llm_tmp/context/obligations/authority.json`):
`engineering_acceptance: pending`; `human_reviews: unanswered`; `safety_class: unknown`;
`codeql_scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload"`; instruction
*"Restart the failed queue for one complete pass through all obligations"*.

**Applicability nuance recorded for honesty.** `code_analysis.rst:53-55` states dynamic code
analysis (hence the sanitizers) is **not explicitly required by any S-CORE standard** but
that ASAN/LSAN, TSAN, UBSAN and Memcheck *"should be used"* to catch common errors. The
sanitizers are therefore a **guideline-level quality measure**, not a hard standards mandate;
per the non-satisfaction rule they are still **not treated as satisfied** where evidence is
partial or absent. The pinned platform documents carry `:safety: ASIL_B`, but
`authority.json` records `safety_class: unknown` and no authorized selection exists; the
document attribute is **not** a selection of this slice's safety class.

---

## 2. The recorded GCC syntax failure — inspection of the actual source

`score/socom/impl/service_identifier.hpp` read from the working tree is a 40-line,
**brace-balanced** header with its Apache-2.0/SPDX header intact (`:1-12`):

| Line | Content | Role |
|------|---------|------|
| 14 | `#ifndef SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard begin |
| 17 | `#include "score/socom/service_interface_identifier.hpp"` | include |
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 34–36 | `/// \cond` / `bool operator<(…)` / `/// \endcond` | the single operator declaration |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`) and two closers (`:32`, `:38`) give net brace balance `0`. There
is **no third, unmatched closing brace**, and line 39 contains no text. The sibling
`score/socom/impl/service_identifier.cpp` uses the same nested form (closer at `:32`) and is
balanced.

**Independent corroboration from the retained artifacts.** `compiler_diagnostics/result.json`
records the focused **GCC** `gcc-compile` **exit 0** (`:1152`) and `gcc-tests` **exit 0**
with empty `gcc-*.stderr`; `focused_asan_lsan` and `focused_tsan` each record **compile exit
0**. A surviving unmatched brace in a header compiled into those translation units would have
failed the compiles, not passed them. The connected host `validation` candidate is also
`compile 0` (§1.4).

**Disposition.** The described defect is a **stale, pre-correction description** matching the
earliest prior reports (split-form `}  // namespace socom` + `}  // namespace score`), not the
file in this checkout. Re-applying the historical repair to the already-balanced file would
be a no-op; deleting a brace would *create* the reported defect. **No correction was applied
and none is required**; the review-draft write boundary would have forbidden a source write
in any case. If a distinct *"cancelled draft"* revision still carries the extra brace, it is
not the file in this checkout and must be located and corrected by an authorized iteration.

Minimal historical repair, retained for reference **only** (not applied):

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

---

## 3. ASan / LSan / UBSan review

### 3.1 What was built and run (focused)

`focused_asan_lsan` (`result.json:1053-1116`):

- **Compile** — `g++-12 -std=c++17 -Wall -Wextra -Werror -pthread -I.` over
  `score/socom/impl/service_identifier.cpp`, `score/socom/impl/string_registry.cpp`,
  `score/socom/test/unit/service_identifier_tests.cpp`, plus the vendored `gtest-all.cc` /
  `gtest_main.cc`, linked with
  `-fsanitize=address,leak,undefined -fno-sanitize-recover=all -g`. **exit `0`**;
  `compile.stderr` empty.
- **Tests** — the focused binary with `ASAN_OPTIONS=detect_leaks=1:halt_on_error=1` and
  `UBSAN_OPTIONS=halt_on_error=1`. **exit `0`**; `tests.stderr` empty.
- **Result** — `Running 91 tests from 1 test suite.` and `[  PASSED  ] 91 tests.`
  (`tests.stdout:2,191`). All 91 are `ServiceInstanceIdentifierTest`.

### 3.2 Reading and scope (focused ASan/LSan/UBSan)

| Aspect | Value |
|--------|-------|
| Sanitizers active | ASan (`address`), **LSan** (`leak`; `detect_leaks=1`), UBSan (`undefined`; `halt_on_error=1`) |
| Findings | **none emitted** (no ASan/LSan/UBSan report; `stderr` empty) |
| Tests | 91/91, all `ServiceInstanceIdentifierTest` |
| Production units exercised | `service_identifier.cpp` (the changed comparator) and `string_registry.cpp` |
| **Not** exercised | `runtime_impl.cpp`, `runtime_tests.cpp`, all other `//score/...` units, the threaded stress suite |
| Self-declared limit | *"Focused identifier executable; full native runtime scope measured separately"* (`result.json:1121`) |

This is a real pass for the changed key unit and the string registry. It is **not** evidence
about the runtime connector, the service database, or threaded code, and it is **not** a
full-target sanitizer result.

### 3.3 Host UBSan measurement (`validation`, mode `ubsan`)

`validation/after-compile.command.json` builds the focused identifier TU with
`-fsanitize=undefined -fno-sanitize-recover=all` (exit `0`); `after-test.stdout` exits `0`;
`after.json` records **91 / 0 / disabled 0**, against `before.json` **91 / 33**. This is the
red→green of the key change under UBSan on the focused TU, with `after-compile.stderr` /
`after-test.stderr` empty. `check-result` = `0` is a *retention* marker only. Scope is again
the identifier TU; `runtime_tests.cpp` is not compiled here. `full_native_tests:
not_executed` and `engineering_acceptance: pending` remain.

### 3.4 Memcheck (`focused_memcheck`)

`focused_memcheck` compiles the focused TU (exit `0`) and runs
`valgrind --tool=memcheck --leak-check=full --error-exitcode=42 --xml=yes …`; the memcheck
command exits `0` with empty `memcheck.stderr` (`result.json:1089,1116`). Its own limit calls
it *"Optional complementary focused memory analysis"*, so it is complementary, focused
evidence only. **This supersedes the prior report's `exit 127` "valgrind unavailable"
reading** — valgrind is present in this run.

### 3.5 What "no finding" does not mean

Because the focused runs are single-threaded and cover only the identifier TU, they cannot
detect runtime connector construction/teardown, slot reuse and key erasure, the `std::set`
mutex discipline, bridge/client/server locking, or any data race. Those are the subject of
§6.

---

## 4. TSan review

### 4.1 Focused TSan — startup failure, no result

`focused_tsan` compiled the **same focused translation unit** with `-fsanitize=thread -g`
(**compile exit `0`**). The test process then exited **`66`**
(`result.json:1114`, `status: findings_or_execution_failure` `:1117`) with:

```
FATAL: ThreadSanitizer: unexpected memory mapping 0x648d7a092000-0x648d7a0a5000
```

(`focused_tsan/tests.stderr:1`). `tests.stdout` is empty: the process died before gtest's
`Running main() from …` banner, which the ASan run of the identical source set does emit
(`focused_asan_lsan/tests.stdout:1`).

**Classification: runtime/sanitizer-startup (environment) failure, not a data race and not a
source defect.** Reasons:

1. The failure message is the known TSan vs. kernel address-space-layout-randomization
   (`vm.mmap_rnd_bits` / mmap layout) incompatibility, and it occurs at sanitizer runtime
   initialization, before `main()`.
2. The identical code compiles clean and passes ASan/LSan/UBSan 91/91; a source-level memory
   defect capable of a runtime abort would have been reported by ASan (strictly more
   sensitive to illegal access).
3. The focused tests spawn no threads, so there is no concurrency in the compiled program for
   TSan to diagnose; a TSan data-race report would also print
   `WARNING: ThreadSanitizer: data race …`, not a bare `FATAL` mapping message.
4. The compile itself is exit `0`, so the translation unit is syntactically and semantically
   well-formed at the point TSan failed.

Consequences: the focused TSan run establishes **nothing** about data races and does **not**
satisfy a concurrency check. The right instrument for concurrency is the threaded stress
suite, which is exercised by the native leg below (and would need the suite's `tsan.supp`).

### 4.2 Native TSan — Bazel run executed and passed (partial)

`native_tsan` ran `bazel test --jobs=2 //score/... //tests/... --build_tests_only
--features=tsan`, exit `0`, `status: completed` (`result.json:1055-1084`). The retained
`tsan.stdout` records:

- `//score/socom/test/stress:socom_stress_test PASSED in 15.9s` (fresh, not cached),
- `//score/socom/test/unit:socom_test PASSED in 1.1s` (fresh),
- `Executed 5 out of 27 tests: 19 tests pass and 8 were skipped.`

The 14 `(cached) PASSED` entries and the 8 `SKIPPED` targets mean this is **partial**: the
integration/benchmark targets were not exercised in this run, and the TSan feature effects
are not independently demonstrated from the captured text. It is nevertheless a substantially
stronger TSan signal than the focused run, and it is the only retained TSan execution that
includes the threaded stress suite. It is local, unprotected, and **not** acceptance.

---

## 5. Native sanitizer legs — correction of the earlier "build-only" reading

### 5.1 What the retained artifacts show

| Check | Command (from `result.json`) | Exit | Retained stdout reading |
|-------|------------------------------|------|--------------------------|
| `native_sanitizers` | `bazel test --jobs=2 //score/... //tests/... --build_tests_only --features=asan --features=lsan --features=ubsan_clang` | `0` | `Executed 19 out of 27 tests: 19 tests pass and 8 were skipped.`; `socom_test` **PASSED in 0.6s** fresh |
| `native_tsan` | `bazel test --jobs=2 //score/... //tests/... --build_tests_only --features=tsan` | `0` | `Executed 5 out of 27 tests: 19 tests pass and 8 were skipped.`; `socom_test` **PASSED in 1.1s**, `socom_stress_test` **PASSED in 15.9s** fresh |

The same flag pattern appears in `native_tests` (`bazel test //... --build_tests_only`, exit
`0`), whose stdout also records a test execution summary
(`Executed 21 out of 29 tests: 21 tests pass and 8 were skipped.`,
`native_tests/tests.stdout:31`). **A `--build_tests_only` flag is therefore present in the
recorded argv while tests were nevertheless executed** in this harness/Bazel version — the
flag is filtering the target set and/or is not suppressing execution here.

### 5.2 Superseding the prior reading

Both `prior-reports/sanitizer_review.md` (§5.2) and
`.llm_tmp/overnight/reports/finding_classification.md` (§3.7) recorded `native_sanitizers` and
`native_tsan` as **exit `127`, "bazel missing", build-only / not a run**. The retained
artifacts for the current run show Bazel present, exit `0`, and an executed-tests summary with
`socom_test` and `socom_stress_test` passing fresh. **The current artifacts govern.** A
reviewer should still confirm (a) that the retained `stdout` corresponds to the same
invocation as the recorded `--build_tests_only` argv, and (b) that the `asan`, `lsan`,
`ubsan_clang` and `tsan` toolchain features are actually defined and instrument the C++
targets — the captured output only shows the Python aspect rejecting those feature names,
which is not evidence about the C++ toolchain.

### 5.3 The eight skipped targets

The eight `SKIPPED` entries are environmental, not sanitizer failures:
`//tests/benchmarks:e2e_benchmarks`, `:e2e_benchmarks_profiling`,
`//tests/integration_test:test_gateway_startup`, `:test_score_test_applications`,
`:test_someipd_sends_someip-sd_message`, `:test_someipd_started_by_test`,
`:test_someipd_startup`, `:test_tcpdump`. These require the QEMU/KVM integration environment
and are out of the sanitizer scope. They are **not** passes.

---

## 6. Runtime connector teardown / slot-reuse coverage

The task asks whether connector teardown and slot reuse are covered, and notes that the
focused identifier tests do not cover the runtime suite. That is correct for the focused runs;
the native legs partly close the gap.

### 6.1 What the focused sanitizer executables include

Both `focused_asan_lsan` and `focused_tsan` compile exactly:

```
score/socom/impl/service_identifier.cpp
score/socom/impl/string_registry.cpp
score/socom/test/unit/service_identifier_tests.cpp
.llm_tmp/googletest/.../gtest-all.cc
.llm_tmp/googletest/.../gtest_main.cc
```

`runtime_tests.cpp` is **not** in the argument list, and `runtime_impl.cpp` is not compiled
in. All 91 executed tests are `ServiceInstanceIdentifierTest` (per `tests.stdout:187-191`).
So neither the connector teardown path nor the registration-key erase path is linked into any
**focused** sanitizer binary.

### 6.2 The source path under review

| Element | Location | Behaviour |
|---------|----------|-----------|
| `Runtime_impl::make_server_connector` | `score/socom/impl/runtime_impl.cpp:440-467` | builds `Service_instance_identifier const identifier{configuration.get_interface(), instance}` (`:443`); under `m_service_identifiers->mutex` inserts it (`:449-454`) and returns `Construction_error::duplicate_service` if the insert fails (`:452`); installs a `Final_action` that captures a `weak_ptr` to the identifiers set and **erases the identifier** on destruction (`:456-463`) |
| `Service_record::register_server_connector` | `score/socom/impl/runtime_impl.cpp:366-382` | asserts `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)` (`:369`); emplaces the server (`:371`); returns a `Server_registration` whose `Final_action` resets `m_server` under `m_runtime_mutex` (`:372-381`) |
| `Service_database::get_record` | `score/socom/impl/runtime_impl.cpp:313-324` | emplace-only records keyed by `(instance, id, major)`; records are never erased |
| `Service_identifiers` / record index | `score/socom/impl/runtime_impl.hpp:56`, `:116-134` | `std::set<Service_instance_identifier>` under a mutex; `Minor_version_ignoring_key_equal/hash` |

So the "slot" is the `std::set` element `(instance, service id, major)`: it is held from
connector construction to connector destruction and erased by the captured `Final_action`.
Reuse after destruction is the behaviour the focused runs cannot observe.

### 6.3 What the runtime unit suite covers (read; executed by the native legs)

`score/socom/test/unit/runtime_tests.cpp` contains **33 test macros** (per
`process_checks/result.json:1065`). The teardown / slot-reuse contract is pinned by:

| Test | Line | Contract exercised |
|------|------|---------------------|
| `CreatingServerConnectorDeletingItAndRecreatingReturnsValidServerConnector` | `:371` | disabled destroy erases the key; the same slot registers again |
| `ConstructDuplicateWhileFirstConnectorEnabledReturnsDuplicateServiceError` | `:694` | key held while the first connector is enabled |
| `ConstructDuplicateRepeatedlyWhileBothConnectorsDisabledKeepsSlotHeld` | `:642` | repeated duplicates refused; different instance accepted |
| `ConstructDuplicateRepeatedlyWhileFirstConnectorEnabledKeepsSlotHeld` | `:905` | same, enabled state |
| `ConstructDuplicateAfterEnabledConnectorDestroyedReturnsValidServerConnector` | `:986` | enabled destroy (which disables) erases the key and frees the slot |
| `ConnectorDestroyedAfterRuntimeDoesNotCrash` | `:1021` | connector lifetime vs. runtime; the key's `weak_ptr` guard path |
| `ConstructDuplicateAfterDisabledConnectorDestroyedWithChangedMinorVersionReturnsValidServerConnector` | `:1045` | freed disabled slot reusable with a changed minor |
| `ConstructDuplicateAfterEnabledConnectorDestroyedWithChangedMinorVersionReturnsValidServerConnector` | `:1091` | freed enabled slot reusable with a changed minor |
| `DestroyingOneMajorSlotKeepsOtherMajorSlotOccupied` | `:1141` | destruction frees only its own major slot |
| `DestroyingOneInstanceSlotKeepsOtherInstanceSlotOccupied` | `:1197` | instance-slot isolation |
| `DestroyingOneServiceIdSlotKeepsOtherServiceIdSlotOccupied` | `:1253` | service-id-slot isolation |
| `ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError` | `:402` | the issue-#84 minor-excluding key regression |
| boundary/equivalence cases | `:440`, `:471`, `:505`, `:538`, `:573`, `:607`, `:726`, `:951` | disabled/enabled distinct major/instance/service-id and minor boundaries |

These exercise the public `Runtime::make_server_connector` path and the key-erasing
`Final_action` lifetime. They are single-threaded at the unit level (the threaded behaviour
lives in the separate stress suite).

### 6.4 The actual coverage gap

| Behaviour | Unit-tested? | Covered by a **focused** sanitizer run? | Covered by the **native** sanitizer legs? |
|-----------|--------------|------------------------------------------|--------------------------------------------|
| Key comparator / string registry | yes (`service_identifier_tests.cpp`, 91) | **yes** — ASan/LSan/UBSan pass; TSan fails at startup | yes (`socom_test` fresh, native_sanitizers/native_tsan) |
| Connector destroy → key erase → slot reuse | yes (`runtime_tests.cpp`) | **no** — not in the focused TU | **yes** — `socom_test` ran fresh and passed under both feature runs |
| Enabled destroy → disable → key erase | yes (`:986`, `:1091`) | **no** | **yes** (via `socom_test`) |
| Slot isolation across major/instance/service-id | yes (`:1141`, `:1197`, `:1253`) | **no** | **yes** (via `socom_test`) |
| Connector outliving runtime (`weak_ptr` guard) | yes (`:1021`) | **no** | **yes** (via `socom_test`) |
| Concurrent register/teardown races | stress suite only | **no** | **partly** — `socom_stress_test` ran fresh under native_tsan (15.9s) and native_sanitizers |

Consequences:

- The focused ASan/LSan/UBSan pass and the host UBSan measurement **must not** be presented as
  evidence for connector teardown or slot reuse; those files are not linked in.
- The teardown / slot-reuse path **is** executed by the native `socom_test` runs under the
  requested sanitizer features, so the gap the earlier report described is **narrower than
  stated** — but the native evidence remains partial (feature instrumentation not
  independently shown; eight integration/benchmark targets skipped; local/unprotected).
- The concurrency-relevant stress suite is executed under the native TSan leg, but the
  focused TSan run is the wrong instrument and failed at startup; freedom from races is still
  **not established** at acceptance level.

---

## 7. Distinguishing runtime startup / infrastructure failures from source defects

The task asks for this discrimination explicitly. The retained sanitizer signals separate
cleanly:

| Signal | Evidence | Classification | Source defect? |
|--------|----------|----------------|----------------|
| Focused ASan/LSan/UBSan | compile `0`, tests `0`, 91/91, empty `stderr` (`focused_asan_lsan`) | **genuine focused pass** | none reported |
| Host UBSan measurement | compile `0`, tests `0`, 91/0 (vs. 91/33 before), empty `stderr` | **genuine focused pass** | none reported |
| Focused memcheck | compile `0`, memcheck `0`, empty `stderr` | **genuine focused pass** | none reported |
| Focused TSan | compile `0`, tests `66`, `FATAL: ThreadSanitizer: unexpected memory mapping 0x…`, empty stdout | **sanitizer-runtime / environment startup failure** | **no** — died before `main`; same TU passes ASan; single-threaded |
| Native `native_sanitizers` | exit `0`, 19 executed/19 pass, 8 skipped (integration/bench) | **executed, partial** | none reported |
| Native `native_tsan` | exit `0`, 5 executed, 19 pass (14 cached), 8 skipped | **executed, partial** | none reported |

**Rule applied:** a non-zero exit is attributed to a source defect only when the tool actually
executed the code and reported a finding. A sanitizer that fails to start (focused TSan) or
targets that are skipped (integration/benchmarks) yield **no verdict** — recorded as *"not
run"* / *"blocked"*, never as *"clean"* and never as a source bug. Only the focused
ASan/LSan/UBSan/memcheck and host UBSan runs report actual (passing) results, and only for the
identifier translation unit.

---

## 8. Sanitizer coverage matrix (current state)

| Check | Scope actually built | Scope actually run | Result | Satisfies the check? |
|-------|----------------------|--------------------|--------|----------------------|
| `focused_asan_lsan` (ASan+LSan+UBSan) | identifier TU + string_registry + gtest | 91 identifier tests | **pass** | only for the focused identifier scope |
| `focused_tsan` | identifier TU + string_registry + gtest | none (startup abort, exit 66) | **no result** | **no** |
| `focused_memcheck` | identifier TU + string_registry + gtest | focused memcheck | **pass** | only complementary/focused |
| host `validation` (mode `ubsan`) | identifier TU + string_registry + gtest | 91 identifier tests | **pass** | only focused UBSan |
| `native_sanitizers` (asan/lsan/ubsan_clang) | `//score/... //tests/...` | 19/27 tests (8 skipped) | **pass, partial** | **no** — not full, not acceptance |
| `native_tsan` (tsan) | `//score/... //tests/...` | 5 fresh + 14 cached (8 skipped) | **pass, partial** | **no** — not full, not acceptance |
| `native_tests` | `//...` | 21/29 tests (8 skipped) | **pass, partial** | **no** — unrelated to sanitizer features |

---

## 9. Obligations status (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Dynamic code analysis / sanitizers used | `code_analysis.rst:53-104` | **PARTIAL / NOT SATISFIED** — focused ASan/LSan/UBSan + memcheck pass; focused TSan failed at startup; native legs partial and unverified for instrumentation strength |
| ASan/LSan (memory errors, leaks) | `code_analysis.rst:100-103` | **PARTIAL** — focused identifier pass; runtime path only via partial native `socom_test` |
| UBSan (undefined behaviour) | `code_analysis.rst:91-98` | **PARTIAL** — focused identifier pass (focused + host measurement); runtime only via partial native run |
| TSan (data races) | `code_analysis.rst:85-89` | **NOT SATISFIED** — focused run abort; native TSan partial (8 skipped, 14 cached); freedom from races not established |
| Memcheck (complementary) | `code_analysis.rst:76-83` | **PARTIAL** — focused pass only; not whole-target |
| Freedom from compiler warnings & errors (100 %) | `verification_plan.rst` (criterion 9) | **PARTIAL** — focused GCC compile `-Werror` exit `0`; no full-native warnings-as-errors run |
| Relative amount of executed tests (100 %) | `verification_plan.rst` (criterion 6) | **NOT SATISFIED** — full native suite partial; 8 integration/benchmark targets skipped |
| Relative amount of passed tests (100 %) | `verification_plan.rst` (criterion 7) | **NOT SATISFIED** — partial runs only |
| Static code analysis classified | `verification_process.rst`; `code_analysis.rst` | **NOT SATISFIED** — outside this report's scope; see `finding_classification.md` |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` | **UNKNOWN — NOT CLAIMED** — mapping `:status: draft` |
| Fault-injection / interface / requirements / resource test types | `verification_process.rst`; `verification_plan.rst` | **NOT PERFORMED / applicability not inferred** |
| Linking tests to requirements (record properties) | `verification_process.rst` | **PARTIAL** — `DerivationTechnique`/`Description` recorded; `TestType`/`Verifies` unset (no invented links) |
| Independence of verification / review | `verification_process.rst` | **NOT DONE** — human reviews unanswered |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** for this slice |
| Obligation collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **RETAINED, NOT PASSING** |
| Native acceptance | `source-index.json` | **`not_inferred` for every entry** |

**Explicit non-satisfaction statement.** The focused ASan/LSan/UBSan/memcheck and host UBSan
results are real but cover only the identifier translation unit; the focused TSan run produced
no result (startup/environment failure); the native sanitizer and TSan legs ran partially
(8 integration/benchmark targets skipped, 14 TSan targets cached, instrumentation strength not
independently shown) and are local/unprotected; `engineering_acceptance` is `pending`,
`human_reviews` are `unanswered`, and `safety_class` is `unknown`. Therefore **none of the
checked sanitizer or verification obligations may be treated as satisfied.** A retained
collection result shows *retention*, not passing.

---

## 10. Notice preservation

- **Only this report was written.** No source, build, test, config, `NOTICE`, `LICENSE`,
  `REUSE.toml`, or prior-report file was created, edited, or deleted. All prior reports under
  `.llm_tmp/overnight/reports/` and `.llm_tmp/overnight/prior-reports/` are preserved
  unchanged (including `prior-reports/sanitizer_review.md`, whose stale "not run" readings are
  superseded by §5 but not overwritten).
- The header the task flagged (`score/socom/impl/service_identifier.hpp`) was inspected and
  left unchanged because it is already brace-balanced (§2); its Apache-2.0/SPDX header
  (`:1-12`) is intact. The sibling `service_identifier.cpp`, both BUILD files, and both
  candidate test files likewise retain their Apache-2.0/SPDX headers.
- This report carries the Apache-2.0 header. No licensed MISRA rule text is reproduced; only
  native rule/tool identifiers, file locations, and retained-artifact readings are cited.

---

## 11. Pending human review checklist

- [ ] **Confirm §2:** `service_identifier.hpp` is brace-balanced (`:19,:29,:32,:38`; line 39
      blank) and the focused GCC/ASan/TSan compiles exit `0`; the recorded "extra closing
      brace at line 39" is stale or refers to a different revision. No source correction is
      required in this checkout.
- [ ] **Resolve the instruction conflict:** "inspect and correct the actual source" vs "only
      that report may be written"; confirm that a no-op report was intended because no defect
      is present.
- [ ] **Ratify §3:** focused ASan/LSan/UBSan pass 91/91 on the identifier TU with empty
      `stderr`; `-fsanitize=address,leak,undefined` plus `ASAN_OPTIONS=detect_leaks=1`
      genuinely includes LSan; the host UBSan measurement reproduces 91/0.
- [ ] **Ratify §4.1:** the focused TSan `exit 66` with `FATAL: ThreadSanitizer: unexpected
      memory mapping …` is a sanitizer-runtime/OS-mmapping startup failure, not a data race
      and not a source defect. Decide remediation (relax kernel address-space randomization
      on the run host, or pin a TSan-compatible toolchain/kernel).
- [ ] **Confirm the §5 correction:** the native `native_sanitizers` and `native_tsan` legs
      exit `0` and executed tests (19 and 5 fresh respectively), superseding the earlier
      "build-only / bazel missing" reading. Verify that the retained `stdout` corresponds to
      the recorded `--build_tests_only` invocation and that the requested sanitizer features
      are honored by the C++ toolchain.
- [ ] **Confirm the §6 coverage statement:** the focused sanitizer binaries do not include
      `runtime_tests.cpp`/`runtime_impl.cpp`; the native `socom_test` legs do, and they passed
      fresh. Decide whether that native evidence is acceptable for the teardown/slot-reuse
      path or whether a dedicated sanitized run of the runtime suite is required.
- [ ] **Do not treat TSan as passed.** If concurrency must be evidenced at acceptance level,
      run the stress suite under TSan (`//score/socom/test/stress:socom_stress_test` with
      `--features=tsan` and its `tsan.supp`) and record it; the single-threaded focused TU is
      the wrong instrument.
- [ ] **Do not present the identifier-only sanitizer pass as platform/runtime validation.**
- [ ] **Refresh the measurement:** run the full native suite
      (`bazel test //score/socom/test/unit:socom_test` and `//score/...`) including the eight
      skipped integration/benchmark targets where the environment allows, so `runtime_tests.cpp`
      and the current 91-case identifier suite are actually executed under the intended
      configurations.
- [ ] **Schedule independent human review** (approver ≠ author, per
      `gd_req__verification_independence`) and record engineering acceptance; no compliance
      claim may be made before that.
- [ ] **Keep the wider #84 public `Service_interface_identifier` restructure, FindService
      wildcard handling, and the config minor-wildcard narrowing out of this bounded slice**
      until separately accepted.

---

*End of sanitizer review draft. Local, unprotected, scoped. No engineering acceptance; human
reviews unanswered; full native runtime tests pending. Focused ASan/LSan/UBSan and memcheck
pass on the identifier translation unit; the focused TSan run failed at sanitizer startup;
the native sanitizer and TSan legs ran partially and passed; the runtime connector teardown and
slot-reuse path is exercised only by those partial native legs, not by the focused runs.*
