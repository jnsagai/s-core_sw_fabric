<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — bounded duplicate-server registration-key slice (review draft)

**Document type:** review draft (scope binding + actual-source inspection + accepted-draft scope +
open design questions + obligations status)
**Date:** 2026-10-02
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** duplicate-server registration-key handling within *Revise version handling in socom*
**Run:** `fabro/run/01M3YRJEGXNY6CB81T7TKW774B`, HEAD `8934e94`
(`fabro(01M3YRJEGXNY6CB81T7TKW774B): start (success)`)
**Status:** local, unprotected, scoped. **No engineering acceptance exists. Human reviews are
unanswered. Full native runtime tests are pending.** Every statement here is a local, unprotected,
scoped reading of the working tree at the baseline-bound candidate paths, or a prior report's record
of one; none of it is acceptance, review, publication, or a full native run.

> **Tool / write boundary observed.** This iteration used only `read_file`, `grep`, `glob`, and
> `write_file`. No `shell`, no `edit_file`, no delegation, no web access, no approval, no publishing,
> and no engineering acceptance was performed. The task's instructions contain a conflict: they say to
> *"Inspect and correct the actual source before expanding tests"*, while the explicit, more specific
> final sentence says *"This is a review draft: only that report may be written."* Following the
> explicit write boundary, **only this report was written.** No source, build, test, config, `NOTICE`,
> `LICENSE`, `REUSE.toml`, or prior-report file was created, edited, or deleted. All prior reports are
> preserved.
>
> **The conflict is moot on the facts.** The described defect — *"a measured GCC syntax failure: an
> extra closing brace in `score/socom/impl/service_identifier.hpp` at line 39"* — is **not present in
> the current working tree** (§2). The header is already brace-balanced (four brace lines: `:19`,
> `:29`, `:32`, `:38`; line 39 blank), so there is no actual source to correct. The exact minimal
> repair is retained in §2.3 for the event the imbalance ever reappears; applying it now would be a
> no-op at best and a regression at worst. No test was expanded in this iteration, because the draft's
> expanded suites already exist on disk (§4).
>
> **Directory note.** The earlier reports in this checkout live under
> `.llm_tmp/overnight/prior-reports/` — **12 files present** (verified this iteration;
> §6.1). `glob` over `.llm_tmp/overnight/reports/**` returned **no files** before this write; this
> document is that directory's first entry in this checkout, even though earlier reports reference a
> host-side `reports/` tree. `glob` over `.llm_tmp/overnight/validation/**`,
> `.llm_tmp/overnight/obligations/**`, and `**/result.json` all returned **nothing**; those host
> artifacts are **absent from this checkout** (§6), and an absent artifact is not a passed check.

---

## 1. Binding issue #84 to the verified baseline

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` | `.llm_tmp/context/issue-snapshot.json:2-4` |
| Title | *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:3` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` (unchanged) | `.llm_tmp/context/issue-snapshot.json:19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted
obligation**. It distinguishes three use cases:

- *service-instance identifier* = `service id + major + minor + instance id`;
- *service identifier* = `service id + major`;
- *FindService* = `service id + major + optional<minor> + optional<instance>`;

and proposes to "exclude the minor version and make it a property of the service instance to be able
to better compare and index compatible service instances." It notes the FindService `major = FF`
AUTOSAR case as theoretically possible but not useful. There is **no comment and no acceptance record**
in the snapshot, so none of the proposal is binding.

### 1.2 Verified baseline

| Item | Value | Source |
|------|-------|--------|
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |
| Current branch | `fabro/run/01M3YRJEGXNY6CB81T7TKW774B` | environment |
| Current HEAD | `8934e94` — `fabro(01M3YRJEGXNY6CB81T7TKW774B): start (success)` | environment |

Earlier reports reference other run IDs on the same baseline commit
(`01M3YGTGYFEN406VDEVVTJTRWV`, `01M3XZAQ65TTE35XSGXC4JAMAH`, `01M3XT7NQ04S4MTFRMTT2401XK`,
`01M3WX09X84XFM5X08QY2944DF`, and before them `01M3WSTF1DAJA248NQ5QQGQG52` / `a282596` and
`01M3WWRQWT262FTYS52X80YPTP` / `e12e7cb`). The binding is **by baseline commit `f8a196c3…`**, not by
run HEAD, so all of those reports describe the same baseline and remain admissible prior evidence for
this run's slice.

### 1.3 In-scope candidate files (`.llm_tmp/context/candidate-files.json`)

| File (repo-relative) | Baseline git blob | Baseline present | Current working tree (read this iteration) |
|----------------------|-------------------|------------------|--------------------------------------------|
| `score/socom/BUILD` | `3477ea0851fdcd82ec6ea9d71424013cbdf41962` | yes | `testonly` `impl_service_identifier` exposure present (`:46-54`) |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e22355242009fe20dada2a9a0d0c7a9c7` | yes | key identity `(instance, service id, major)`; `minor` excluded (`:28-29`) |
| `score/socom/impl/service_identifier.hpp` | `c8bae7908da9f087c518934f7b9f8d86db9a20ec` | yes | **brace-balanced**, 40 lines; line 39 blank (§2) |
| `score/socom/test/unit/BUILD` | `3c03a7b14286051f97fa5022206564bd63645171` | yes | `socom_test` globs `*.cpp`; deps wired (`:16-29`) |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab726db8bf994c960045d6fd7fdf84d7395` | yes | **31 `TEST_F` + 1 `TEST` + 1 `TEST_P`**; focused minor-only regression at `:402-431` |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(none — `null`)* | **no** (manifest expects a **new** file) | **83 `TEST_F`** matrix present; metadata `SetUp()` at `:42-65` |

The `null` baseline blob for `service_identifier_tests.cpp` is the manifest's expectation of a **new**
unit-test file; it exists on disk only as part of the un-merged working tree (the "cancelled draft"),
never in the baseline. The five present baseline blobs also appear in the `files` array of
`.llm_tmp/context/source-manifest.json`, binding the candidate set to the baseline commit. The
`glob`s `**/service_identifier.hpp` and `**/service_identifier_tests.cpp` each return **exactly one**
path, so there is no second, differently-braced copy of either file in this checkout.

### 1.4 Pinned obligation sources read this iteration

All nine entries of `.llm_tmp/context/obligations/source-index.json` were read from
`.llm_tmp/context/obligations/`, together with `authority.json`:

| id | file | status (re-read this iteration) |
|----|------|---------------------------------|
| `coding_guidelines` | `coding_guidelines.rst` | `:status: valid` (`:20`); MISRA C++:2023 with C++17 |
| `code_analysis` | `code_analysis.rst` | `:status: valid` (`:20`); clang-tidy + gcc/clang warnings + Coverity; sanitizers; gcov/gcovr |
| `misra_mapping` | `misra_mapping.rst` | **`:status: draft`** (`:20`); the rule table is commented out |
| `verification_plan` | `verification_plan.rst` | `:status: valid` (`:17`); TestType/DerivationTechnique tables; quality criteria 1–9 (criterion 9 = freedom from compiler warnings & errors, 100 %) |
| `development_plan` | `development_plan.rst` | `:status: valid` (`:21`); C++17, GCC host compiler, QCC target, Bazel, clang-tidy, CodeQL |
| `tool_management` | `tool_management.rst` | `:status: valid` (`:17`); tools identified / evaluated / qualified |
| `verification_process` | `verification_process.rst` | `:status: valid` (`:22`); `gd_req__verification_link_tests_cpp` (`:57`), `gd_req__verification_independence` (`:142`), `gd_req__verification_checks_extended` (`:199`), `gd_req__verification_sca_classification` (`:229`) |
| `verification_guideline` | `verification_guideline.rst` | `:status: valid` (`:19`); traceability, independence, reporting |
| `inspection_checklist` | `inspection_checklist.rst` | **`:status: draft`** (`:17`); blank IMPL_01_01…IMPL_03_02 template |

Every entry in `source-index.json` is pinned with `"native_acceptance": "not_inferred"` — pinned, but
its applicability to this slice is **not inferred**. `authority.json` records
`"engineering_acceptance": "pending"`, `"human_reviews": "unanswered"`, `"safety_class": "unknown"`,
`"codeql_scope": "Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload"`, and the instruction
`"Restart the failed queue for one complete pass through all obligations"`.

---

## 2. The recorded syntax failure: inspection of the actual source

### 2.1 Finding (re-verified this iteration by direct `read_file` + `grep`)

`score/socom/impl/service_identifier.hpp` is **brace-balanced**. It is exactly 40 lines; `grep` for
`[{}]` on the file returns exactly four matches:

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

Two openers (`:19`, `:29`) and two closers (`:32`, `:38`): net brace balance is `0`. There is **no
third, unmatched closing brace**, and line 39 contains no text at all. `grep` for `namespace` returns
only `:19` and `:38` (the matched nested form, not a split `namespace socom` / `namespace score`
pair). The task's "extra closing brace … at line 39" is therefore a **stale, pre-correction
description**. It matches the earliest prior reports, which quote lines 38–39 as the split-form
`}  // namespace socom` + `}  // namespace score`. The `reproducer` iteration is the one that records
the correction (`prior-reports/reproducer.md`), and every later prior report records the header as
already balanced — which is what the actual source shows in this checkout today.

### 2.2 Repository convention

The tree uses two internally-consistent styles:

- **Nested open + single close:** `namespace score::socom {` … a single `}  // namespace score::socom`.
  This is the sibling `impl/service_identifier.cpp` (`:18` / `:32`), the public
  `service_interface_identifier.hpp`, and `error.hpp`.
- **Split open + double close:** `namespace score {` + `namespace socom {` … `}  // namespace socom` +
  `}  // namespace score`. This is `impl/runtime_impl.hpp` (`:32-33` / `:232-233`).

`impl/service_identifier.hpp` follows the **nested** form consistently and is balanced.

### 2.3 Correction status

**No correction was applied, and none is required.** The minimal repair — retained for reference only,
in the event the imbalance ever reappears — matches the sibling `.cpp`:

```diff
-}  // namespace socom
-}  // namespace score
+}  // namespace score::socom
```

Applying this to the already-balanced file would be a no-op; re-introducing a broken state merely to
"fix" it would be a regression. Because the actual source is already correct, the instruction's
precondition ("inspect and correct the actual source before expanding tests") is satisfied without a
source write: there is nothing to correct, and the write boundary ("only that report may be written")
would have forbidden the write in any case. **If the "cancelled draft" is a different revision that
still carries the extra brace, it is not the file in this checkout** and must be located and corrected
by an authorized iteration; this report records the discrepancy for human disposition rather than
speculating.

### 2.4 Independent corroboration (retained by prior reports; not re-measured here)

Earlier reports retain a host measurement that compiled this header as a transitive include of
`service_identifier.cpp` / `service_identifier_tests.cpp` with
`g++-12 -std=c++17 -Wall -Wextra -Werror`, exiting `0` with empty `stderr`
(`prior-reports/test_metadata.md` §2.2 and §6; `prior-reports/ordering_tests.md` §2.2). A surviving
extra closing brace would make that compile fail. **Note:** the measurement artifacts themselves are
**absent from this checkout** (§6.2); only the prior reports' records of them are available, and those
are local, unprotected, scoped captures — not acceptance.

### 2.5 Why it would matter if present

The header is compiled into `//score/socom:socom` (`score/socom/BUILD:24-41`; its `srcs` globs
`impl/**/*.cpp` and `impl/**/*.hpp`) and re-exposed to `//score/socom/test/unit` through the
`testonly` library `impl_service_identifier` (`score/socom/BUILD:46-54`;
`score/socom/test/unit/BUILD:24`). A syntax error there would fail the library and the whole
`socom_test` target, contradicting S-CORE quality criterion 9, "Freedom from compiler warnings &
errors, 100 %" (`verification_plan.rst`). It is **not** a blocker in the current tree; that is a static
brace-balance reading, **not** a compile measurement.

---

## 3. As-is source state of the duplicate-server registration key

All line references are readings of the current working tree at the baseline-bound candidate paths.

- **Key type.** `Service_instance_identifier` is
  `{ Service_interface_identifier interface; Service_instance instance; }`
  (`score/socom/impl/service_identifier.hpp:29-32`), with an out-of-line `operator<` declaration
  (`:35`) and **no** `operator==`/`std::hash` (ordering-only identity).
- **Key role.** It is the duplicate-server registration key only:
  `using Service_identifiers = Mutexed_variable<std::set<Service_instance_identifier>>`
  (`impl/runtime_impl.hpp:56`), stored as `Runtime_impl::m_service_identifiers`
  (`impl/runtime_impl.hpp:228-229`, a `std::shared_ptr`).
- **Current identity.** `impl/service_identifier.cpp:20-30` orders by
  `std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major) <
  std::tie(rhs.instance, rhs.interface.id, rhs.interface.version.major)`, i.e. **minor is excluded**;
  identity is `(instance, service id, major)`. The header comment (`:21-28`) and the `.cpp` comment
  (`:21-27`) document that exclusion and tie it to issue #84.
- **Baseline identity (pre-draft).** Per `prior-reports/invariants.md` I-4, the baseline ordering was
  `std::tie(lhs.instance, lhs.interface)`, delegating to `Service_interface_identifier::operator<` /
  `Version::operator<`, so the baseline key identity was `(instance, service id, major, minor)`.
- **Insertion / duplicate rejection.** `Runtime_impl::make_server_connector` builds
  `Service_instance_identifier const identifier{configuration.get_interface(), instance}`
  (`runtime_impl.cpp:443`), then, under the key mutex, inserts
  (`:449-454`, insert at `:451`) and returns `Construction_error::duplicate_service` when
  `insert(...).second` is false (`:452`). A `Final_action` capturing the identifier and a
  `weak_ptr` erases it (`:456-463`).
- **Record index.** `Service_database` indexes records by `id + major` and ignores minor, via
  `Minor_version_ignoring_key_equal` / `Minor_version_ignoring_hash`
  (`runtime_impl.hpp:116-134`), consumed by `get_record` (`runtime_impl.cpp:313-324`).
- **Single-server precondition.** `Service_record::register_server_connector` asserts
  `SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)` then `m_server.emplace(...)`
  (`runtime_impl.cpp:366-382`; assert `:369`, emplace `:371`).
- **Compatibility rule (separate from identity).** `is_minor_version_compatible` is
  `client.minor <= server.minor`; `is_interface_compatible` requires equal `id`, equal `major`, then
  the minor rule (`runtime_impl.cpp:133-146`). These are not part of the key.
- **Public interface representation (unchanged).** `Service_interface_identifier{Id id; Version{major,
  minor}}`, both version fields `std::uint16_t` (`service_interface_identifier.hpp:74-88`), with
  full-version `operator<`/`operator==`/`std::hash`.
- **Build wiring.** `score/socom/BUILD:46-54` defines the `testonly` `impl_service_identifier` library
  exposing `impl/service_identifier.hpp` to `//score/socom/test/unit:__pkg__`;
  `score/socom/test/unit/BUILD:16-29` defines `socom_test` with `srcs = glob(include = ["*.cpp"])`
  and depends on it. No BUILD change is needed for new/expanded test files.

### 3.1 The static mismatch (invariant gap I-11)

On the baseline, the key included `minor` while the record index ignores it. Two server connectors for
the same `id + major + instance` with different minor versions then produced distinct keys (both
passing the duplicate gate) but resolved to the same `Service_record` on enable, reaching
`SCORE_LANGUAGE_FUTURECPP_ASSERT(!m_server)` (undefined behaviour where the assert does not terminate).
The working-tree key change (ordering excluding minor) closes this gap at the key level by making the
key as coarse as the record index. This is a **source-derived reading, not a reproduced runtime
result**, and reachability depends on the open questions in §5. It is recorded as an invariant gap, not
an accepted defect.

---

## 4. Accepted draft scope (local only)

**No acceptance record exists locally.** `.llm_tmp/context/obligations/authority.json` records
`"engineering_acceptance": "pending"` and `"human_reviews": "unanswered"` (with
`"safety_class": "unknown"`). Every entry in `.llm_tmp/context/obligations/source-index.json` is marked
`"native_acceptance": "not_inferred"`. The scope below is therefore the draft **accepted for this
local iteration only**; it is **not** an engineering acceptance and must be confirmed by human review
before implementation is treated as done.

### 4.1 In scope for this bounded slice

1. **Key semantics for duplicate server connectors.** Decide and implement whether
   `Service_instance_identifier` keeps or ignores `minor`, aligning with the `Service_database`
   minor-ignoring index and the #84 "service identifier = id + major" use case. Current draft state:
   **minor excluded**, identity `(instance, service id, major)`.
2. **Ordering/identity contract.** Keep `operator<` as the single, unambiguous ordering used by the
   `std::set`; no companion equality/hash.
3. **Key-level unit tests** in `score/socom/test/unit/service_identifier_tests.cpp` (new file, no
   baseline blob). The current draft carries **83 `TEST_F` cases** under `ServiceInstanceIdentifierTest`
   (verified this iteration by `grep`; `:168`…`:1851`), covering irreflexivity; minor-only collapse and
   16-bit minor boundaries; major/id/instance distinctness; combined matrices; equivalence
   ↔ `(instance, id, major)`; strict-weak-ordering properties over deterministic 36-key and 64-key
   domains; empty/prefix/high-bit boundaries; and text/registry → public-identifier → internal-key
   conversion boundaries. The file records `DerivationTechnique =
   "boundary-values,equivalence-classes"` and a `Description` in `SetUp()` (`:42-65`).
4. **Runtime-level duplicate tests** in `score/socom/test/unit/runtime_tests.cpp` —
   **31 `TEST_F` + 1 `TEST` + 1 `TEST_P`** in the current draft (verified by `grep`; `TEST` at `:239`,
   `TEST_F` `:279`…`:1253`, `TEST_P` at `:1311`). The focused minor-only regression is
   `ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError` (`:402-431`); the file
   also carries same-configuration disabled duplicate, enabled duplicate, lifetime/reuse,
   differing-service-id/instance/major, and slot-isolation cases (e.g.
   `DestroyingOneServiceIdSlotKeepsOtherServiceIdSlotOccupied` at `:1253`).
5. **Build wiring** for the new test file / test-only header exposure (already present; no BUILD change
   required).
6. **Test metadata** for the key suite (`DerivationTechnique`, `Description`) per
   `gd_req__verification_link_tests_cpp`; `TestType` and `Verifies` links are deliberately left unset
   because no verified native requirement/interface identity exists for this slice (no invented links).
7. **Notice preservation** — Apache-2.0 headers on every touched file; no `NOTICE`/`LICENSE` changes.

### 4.2 Explicitly out of scope for this bounded slice

- Reshaping the public `Service_interface_identifier` type or moving `minor` onto `Service_instance`
  (the reporter's longer-term proposal).
- FindService wildcard (`major = FF`) handling and the SD/wire mapping.
- The `Service_database` minor-ignoring index and the client/server minor-compatibility algorithm
  beyond what the key decision forces.
- `score/config` minor wildcard (`0xFFFFFFFF`) semantics and the config→socom `uint32→uint16`
  narrowing (pinned only as a boundary in the tests, not decided).
- Fuzz/fault-injection harnesses and full feature/platform reference-hardware validation.

---

## 5. Open design questions

These must be resolved by an accepted human decision before the slice is considered done.

1. **Minor in the duplicate key, or not?** The draft excludes `minor` (consistent with
   `Service_database` and #84), so two servers sharing `id + major + instance` collide as
   `duplicate_service`. If the key must keep `minor`, the `Service_database` index must stop ignoring
   minor (or `register_server_connector` must tolerate replacement) to remove the assert/UB path. Which
   is authoritative?
2. **Two servers, one `id + major + instance`, different minor.** Reject as duplicate, let the later
   minor replace the earlier, or allow both with negotiation? The current code cannot express the last
   option (`m_server` is a single `std::optional`).
3. **Is the assert path reachable and intended?** Is `ASSERT(!m_server)` a genuine invariant (so the
   duplicate gate must cover every collision the record index can produce), or a defensive check that
   should tolerate re-registration?
4. **Scope of the #84 restructure.** Introduce `Service_identifier = id + major` plus
   minor-as-instance-property (large public API change), or keep
   `Service_interface_identifier{major, minor}` and only fix the internal key? This draft assumes the
   latter; confirm.
5. **Version field widths and wildcard.** socom uses `uint16 major` / `uint16 minor`
   (`service_interface_identifier.hpp:83,87`), while the SOME/IP config declares
   `service_version_major: uint8` (`score/config/mw_someip_config.fbs:19`) / `service_version_minor:
   uint32 = 0xFFFFFFFF` (`score/config/mw_someip_config.fbs:23`). Every config→socom conversion
   narrows `uint32→uint16`, turning `0xFFFFFFFF` into `0xFFFF`
   (e.g. `score/someipd/impl/remote_network_service.cpp:45`,
   `score/someipd/impl/local_network_service.cpp:49`). How is the wildcard mapped, and does it
   interact with duplicate detection?
6. **Ordering vs. identity.** `operator<` is used only for `std::set` membership; the type declares no
   `operator==`/hash. Is a total order meaningful, or should the internal key be an equality/hash key?
7. **Public vs. internal placement.** The key is `impl/`-only, compiled via the `impl/**` glob, not the
   public `*.hpp` filegroup. Confirm it stays internal and that changing its ordering is not an
   ABI/API concern.
8. **Error semantics.** Should a minor-only collision report `duplicate_service`, or a more specific
   error? The `error.hpp` comment ("Service identifier already exists", `error.hpp:55`) is narrower
   than the actual key.
9. **Test expectations.** Confirm the intended coverage and that a new `service_identifier_tests.cpp`
   is preferred over extending `service_interface_identifier_tests.cpp`, given the manifest treats it
   as new.
10. **Runtime regression acceptance.** Confirm the runtime-level cases (especially the minor-only
    duplicate regression and the service-id slot-isolation case) are wanted and that using the public
    `Runtime::make_server_connector()` path is acceptable, given none of them has been compiled or
    executed in a full native run in this checkout (§7).

Derived-form questions carried from `prior-reports/invariants.md` §5 remain equivalent: Q-A
reachability of the minor-only collision; Q-B which equivalence is authoritative; Q-C
duplicate-vs-supersede; Q-D the status of `ASSERT(!m_server)`; Q-E whether the public-interface
restructure is pursued.

---

## 6. Prior reports, host feedback, and obligation-collection results

### 6.1 Prior reports (read and preserved)

- `.llm_tmp/overnight/prior-reports/` — **12 files present**, all read and preserved:
  `scope.md`, `invariants.md`, `callsites.md`, `reproducer.md`, `key_fix.md`, `unit_matrix.md`,
  `ordering_tests.md`, `conversion_tests.md`, `runtime_disabled.md`, `runtime_enabled.md`,
  `lifetime_tests.md`, `test_metadata.md`. Earlier prior reports describe a **13th** sibling,
  `repair_unit_matrix.md`, and also cite `coverage_tests_repair.md`, `tool_findings_repair.md`, and a
  host addendum `prior-reports/obligation-addendum.md`; **none of those four files is present in this
  checkout** (`glob` returns no entries), so their content is available only as quoted by the other
  prior reports.
- `.llm_tmp/overnight/reports/`: **absent** in this checkout before this write (glob returned no
  entries), although earlier reports reference a host-side `reports/` tree containing `scope.md`,
  `callsites.md`, `invariants.md`, `reproducer.md`, `test_metadata.md`, and others. This document is
  that directory's first entry here.
- `.llm_tmp/overnight/prior-replacement-reports/`: **absent** (glob returned no entries).

Derived sequence across the preserved reports: `scope.md` (bounded the slice) → `invariants.md`
(I-1…I-16; I-4 baseline key included minor, I-9 record index ignores minor, I-11 the resulting gap) →
`callsites.md` (call-site map) → `reproducer.md` (key-level regression + test-only header exposure +
header brace correction) → `key_fix.md` / `unit_matrix.md` (drop minor from the ordering; expand key
tests) → `ordering_tests.md` (property tests) → `runtime_disabled.md` / `lifetime_tests.md` /
`runtime_enabled.md` (runtime regressions) → `conversion_tests.md` (conversion boundaries) →
`test_metadata.md` (record properties) → `repair_unit_matrix.md` / `coverage_tests_repair.md` /
`tool_findings_repair.md` (later host-side iterations; the last three are not present here).

### 6.2 Host validation feedback

`glob .llm_tmp/overnight/validation/**` and `glob **/validation/**` both returned **nothing**: the
validation directory is **absent from this checkout**, and `glob **/result.json` also returned
nothing. Earlier reports record its contents (`prior-reports/test_metadata.md` §6, `ordering_tests.md`
§5, `runtime_enabled.md` §5):

- `check-result`: `0`; `measurement.json`: `origin: local_unprotected_measurement`,
  `initiator: Fabro host hook`, `mode: ubsan`, `engineering_acceptance: pending`,
  `full_native_tests: not_executed`, compiler `/usr/bin/x86_64-linux-gnu-g++-12`,
  `check_ref: check_conversion_tests`; `candidate` = **83 tests / 0 failures / compile exit 0**;
  `baseline_with_agent_tests` = **83 tests / 28 failures / compile exit 0**.
- An even earlier retained capture recorded `candidate` = 46 tests / 0 failures and
  `baseline_with_agent_tests` = 46 / 15.
- Scope caveat: the measurement compiled **only the focused identifier translation unit**
  (`service_identifier.cpp` + `string_registry.cpp` + `service_identifier_tests.cpp`) with
  `g++-12 -std=c++17 -Wall -Wextra -Werror` (plus `-fsanitize=undefined -fno-sanitize-recover=all`);
  it did **not** compile `runtime_tests.cpp` or the full `socom_test` / `//score/...` targets.

Because the artifacts are absent here, this report does **not** treat any host check as passed; it
records only what prior reports retained.

### 6.3 Obligation-collection results

`glob .llm_tmp/overnight/obligations/**` and `glob **/result.json` both returned **nothing**: the
obligations-result directory is **absent from this checkout**. No
`.llm_tmp/overnight/obligations/*/result.json` exists here. Earlier reports record collector results:
`compiler_diagnostics` GCC focused compile+tests exit 0 (clang compile blocked on a googletest /
libstdc++ `-Wdeprecated-declarations` dependency error outside the six paths); `focused_coverage`
`service_identifier.cpp` 100 % line / 50 % branch, `string_registry.cpp` 75.8 % / 66.7 %, overall
77.8 % / 64.3 %; `focused_asan_lsan` / `focused_memcheck` pass; `focused_tsan` environment failure;
`focused_clang_tidy` config blocker; CodeQL security no candidate-path findings; CodeQL MISRA only
googletest-macro `external-linkage-…` hits in the candidate test file with draft/unestablished
applicability; `native_*` / `cross_compilation` / `native_performance` failed while fetching toolchains
/ an Ubuntu image with `No space left on device`. Per the task rule, a successful collection node means
results were **retained**, not that checks **passed**; here the results are not even present in this
checkout, so **nothing may be treated as satisfied on that basis**.

### 6.4 Host addendum (task context, not acceptance)

The host addendum (present only as quoted by prior reports) states, in its own words: "This is task
context, not engineering acceptance or an approved tailoring decision." It asks the review to cover the
`verification_process.rst` test types (fault injection, interface, requirements, resource) and
derivation techniques (requirements/design/boundary/equivalence/fuzzy/error-guessing/explorative); to
keep `security_review`, `traceability_review`, `integration_aou_review`, and
`verification_report_draft` distinguishing configured module tests from any absent fuzz/fault-injection
harness or full feature/platform reference-hardware tests; to leave unknown applicability and
unexecuted applicable checks explicit; to **not** label identifier-only tests as full platform
validation and **not** to claim a fuzzy technique without a measurement; permits concrete missing
boundary/equivalence regression cases within the six source paths; and states there is no authority to
invent native links, select a safety classification, accept risk/deviations, or answer the independent
human gate. This report honours that in §4, §5, and §7.

---

## 7. Obligations status (none satisfied)

### 7.1 Pinned state from `authority.json`

| Field | Value |
|-------|-------|
| `codeql_scope` | Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload |
| `engineering_acceptance` | **pending** |
| `human_reviews` | **unanswered** |
| `safety_class` | **unknown** |
| `instruction` | "Restart the failed queue for one complete pass through all obligations" |

All nine pinned sources in `.llm_tmp/context/obligations/` were read this iteration (§1.4); every
`source-index.json` entry is `"native_acceptance": "not_inferred"`.

### 7.2 Obligation status for this slice (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Freedom from compiler warnings & errors (100 %) | `verification_plan.rst` (criterion 9) | **NOT MEASURED** — header is brace-balanced (§2), but nothing was compiled in this iteration; no host artifact is present here |
| Static code analysis (clang-tidy / CodeQL), findings classified | `code_analysis.rst`; `verification_process.rst` (`gd_req__verification_sca_classification`) | **NOT PERFORMED** — no tool, no build; prior clang-tidy attempt blocked on config; CodeQL MISRA applicability unestablished (draft mapping) |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` | **UNKNOWN** — mapping document is `:status: draft`; not applied |
| Structural statement / branch coverage goals | `verification_plan.rst` (criteria 1–2) | **NOT MEASURED** — no test execution in this iteration; prior coverage capture is out of this checkout and below platform goals |
| Unit/component testing executed, results recorded | `verification_plan.rst` (criteria 6–7); `verification_guideline.rst` | **NOT EXECUTED** — 0 tests run this iteration; prior key-TU run is stale/out-of-checkout and does not cover `runtime_tests.cpp` |
| Interface / requirements-based / resource / fault-injection test types | `verification_process.rst`; `verification_plan.rst` | **NOT PERFORMED / applicability not inferred** — no harness; identifier-only tests must not be labelled platform validation |
| Boundary / equivalence derivation | `verification_process.rst` | **SOURCE-ONLY** — cases exist in source but were not executed |
| Fuzzy testing technique | `verification_plan.rst` | **NOT EXECUTED / NOT CLAIMED** — no harness and no measurement |
| Linking tests to requirements (record properties) | `verification_process.rst` (`gd_req__verification_link_tests_cpp`) | **PARTIAL / NOT DONE** — `DerivationTechnique`/`Description` recorded (`service_identifier_tests.cpp:42-65`; `runtime_tests.cpp:264-266`); `TestType` and `Verifies` cannot be set without inventing identifiers |
| Independence of verification / review by a different committer | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Implementation inspection checklist IMPL_01…IMPL_03 | `inspection_checklist.rst` | **NOT FILLED** — draft template, no inspection |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** for this slice; no tool run here |
| Obligation collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **ABSENT in this checkout** — directory not present |
| Native acceptance | `source-index.json` | **not_inferred** for every entry |

**Explicit non-satisfaction statement.** Missing tools (no `shell`/build/test in this task), the unknown
safety class and un-inferred applicability, the incomplete extraction of host artifacts, the
already-delivered-but-absent obligation-collection results, and the unanswered human reviews mean
**none of the checked obligations may be treated as satisfied**. A collection node that retained
results would only show *retention*, not passing; here the results are not present at all. In
particular, the absence of `.llm_tmp/overnight/validation/` and
`.llm_tmp/overnight/obligations/*/result.json` is **not** evidence that the corresponding checks
passed.

---

## 8. Measurement and validation status

- **Tools:** `read_file`, `grep`, `glob`, `write_file` only. No `shell`, delegation, web, approval,
  publishing, or engineering acceptance.
- **Executed measurements:** **none** this iteration. No build, no `bazel test`, no runtime. Every
  statement is a static reading of the working tree at the baseline-bound candidate paths, or an
  explicitly-labelled logical consequence (e.g. the §3.1 gap and the expected red/green behaviour).
- **Test inventory (read, not run):** `score/socom/test/unit/service_identifier_tests.cpp` has
  **83 `TEST_F`** cases under `ServiceInstanceIdentifierTest` (verified this iteration by `grep`;
  `:168`…`:1851`); `score/socom/test/unit/runtime_tests.cpp` has **31 `TEST_F` + 1 `TEST` + 1 `TEST_P`**
  (verified by `grep`; `TEST` at `:239`, `TEST_F` at `:279`…`:1253`, `TEST_P` at `:1311`). These counts
  are static readings; the suites were not executed here. (Earlier prior reports recorded 73 and then
  83 key cases and 24–25 runtime `TEST_F`; the current tree is the larger 83 / 31 state, so those
  earlier counts are superseded by this reading. The prior reports remain preserved.)
- **Regression target (source-derived, not executed):**
  `RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError`
  (`runtime_tests.cpp:402-431`) and the key-level minor-collapse cases
  (`service_identifier_tests.cpp:174`, `:182`, `:192`, `:203`, …) assert that a second registration
  differing only in `minor` is rejected as `duplicate_service`. On a key that includes `minor` they
  would fail; on the working-tree key they should pass. This is a `std::set`/strict-weak-ordering
  consequence, not an observed result.
- **Scope:** local, unprotected, scoped. This draft has not been reviewed, accepted, published, or
  reproduced on a full native runtime. Unit/integration execution and human review remain pending.
- **Reproduction path for the next authorized iteration (not run here):**

  ```bash
  bazel test //score/socom/test/unit:socom_test
  # focused key-level:
  bazel test //score/socom/test/unit:socom_test --test_filter='ServiceInstanceIdentifierTest.*'
  # focused runtime regression:
  bazel test //score/socom/test/unit:socom_test \
      --test_filter='RuntimeTest.ConstructDuplicateDifferingOnlyInMinorVersionReturnsDuplicateServiceError'
  ```

- **No correction was needed for the recorded syntax failure** (§2), and **no test was expanded** in
  this iteration. The current draft's 83-case key suite and 31-case runtime suite are as described in
  §4 but remain natively unmeasured in this checkout; the only recorded host runs cover the key
  translation unit only and are absent here.

---

## 9. Notice preservation

- No source, build, test, config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was created, edited, or
  deleted by this iteration; only this report was written. Every existing Apache-2.0 / notice header is
  untouched, and all 12 prior-report files under `.llm_tmp/overnight/prior-reports/` were preserved.
- The header that the task flagged (`score/socom/impl/service_identifier.hpp`) was inspected and left
  unchanged because it is already brace-balanced and otherwise well-formed (§2). The sibling
  `service_identifier.cpp`, both BUILD files, and both candidate test files likewise retain their
  Apache-2.0 / SPDX headers (`:1-12`).
- This report itself carries the Apache-2.0 header.
- Any future implementation in this slice must carry the Apache-2.0 header on new files, including
  `service_identifier_tests.cpp`, per `.github/instructions/code-style.md` and `REUSE.toml`.

---

## 10. Pending human review checklist

- [ ] **Confirm the source inspection in §2**: the header is already brace-balanced (single nested close
      `}  // namespace score::socom`; line 39 blank), so the recorded syntax failure is stale and no
      correction is required. If the "cancelled draft" is a different revision that still carries the
      extra brace, locate it and authorize its correction; it is not the file in this checkout.
- [ ] **Resolve the instruction conflict**: was a review-only iteration intended (report only, as done
      here), or was source correction expected? The write boundary forbade the latter, and it was moot
      because no defect was present.
- [ ] **Confirm the baseline binding** in §1.2–1.3 (issue #84 ↔ commit `f8a196c3…`) and confirm that
      `prior-reports/invariants.md` I-4's baseline ordering (`minor` included) is still the correct
      description of the committed baseline.
- [ ] **Confirm or amend the accepted draft scope** in §4 (it is local-only; no acceptance exists) and
      the out-of-scope list in §4.2.
- [ ] **Answer the open design questions** in §5, in particular Q1/Q2 (minor-version key semantics),
      Q3 (status of `ASSERT(!m_server)`), and Q5 (config wildcard/narrowing).
- [ ] **Confirm whether the §3.1 invariant gap is a real defect** and, if so, treat it as the slice's
      regression target.
- [ ] **Decide the runtime-level test coverage** (two connectors differing only in minor, the service-id
      slot-isolation case, and the disabled/enabled/lifetime cases) and confirm the public
      `Runtime::make_server_connector()` path is acceptable.
- [ ] **Supply the missing obligation results** (`.llm_tmp/overnight/obligations/*/result.json`) and host
      validation feedback (`.llm_tmp/overnight/validation/`) into this checkout; do not infer passing
      from absence or from prior reports' retained summaries.
- [ ] **Run the full native suite** (`bazel test //score/socom/test/unit:socom_test` and the broader
      `//score/...` set) and record results, including `runtime_tests.cpp`; schedule independent human
      review (the approver must differ from the author, per `gd_req__verification_independence`).
- [ ] **Keep the #84 public `Service_interface_identifier` restructure, FindService wildcard handling,
      and the config minor-wildcard narrowing out of this bounded slice** until separately accepted,
      and do not present the identifier-only tests as platform validation or claim an unmeasured fuzzy
      technique.
