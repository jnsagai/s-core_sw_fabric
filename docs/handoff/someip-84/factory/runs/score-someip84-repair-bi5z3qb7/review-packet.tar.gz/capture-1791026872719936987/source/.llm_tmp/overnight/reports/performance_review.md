<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — performance / resource-usage review draft

**Document type:** review draft (performance/resource-usage scope + actual-source inspection + source-defined expectation register + retained benchmark/profiling output review against those expectations + unmeasured-limit register + prerequisite register + obligations status).

**Date:** 2026-10-03
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version handling in socom* (issue #84)
**Run / branch:** `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ`; the run environment supplied with this task reports HEAD `94005f3` (`fabro(01M3ZRSDK2XQAF1H48VWTPKQNZ): node_82c502590eb9336054c30bc3 (success)`).
**Verified baseline commit:** `f8a196c3b16d5172d898394ab99b0ed81346d63d` (`.llm_tmp/context/source-manifest.json:3`).
**Status:** **local, unprotected, scoped.** No engineering acceptance exists. Human reviews are unanswered. Full native runtime tests and performance/profiling runs are pending. **No performance/resource acceptance threshold exists and none is invented here.** Every statement below is a direct reading of the working tree, a direct reading of a retained artifact under `.llm_tmp/overnight/`, or an explicitly-labelled logical consequence. Nothing here is published, reviewed, accepted, or a full native run.

> **Tool / write boundary actually observed.** Only `read_file`, `grep`, `glob`, and `write_file` were used. No `shell`, delegation, web access, approval, publishing, or engineering acceptance was performed. The task's final sentence — *"This is a review draft: only that report may be written."* — is the controlling write boundary. Accordingly **exactly one file was written: this report** (`/workspace/.llm_tmp/overnight/reports/performance_review.md`). No source, build, test, config, `NOTICE`, `LICENSE`, `REUSE.toml`, validation, obligation, or prior-report file was created, edited, or deleted.
>
> **Instruction conflict, recorded not silently resolved.** The task records *"a measured GCC syntax failure: an extra closing brace in `score/socom/impl/service_identifier.hpp` at line 39"* and directs *"Inspect and correct the actual source before expanding tests."* Direct inspection of the **actual** source (§2) shows the header is **already brace-balanced** (brace lines `:19,:29,:32,:38`; line `:39` blank), and the retained focused GCC/Clang `-Werror` compiles exit `0`. There is no unmatched brace to remove. The explicit write boundary forbids a source write in any case. **No source was edited and no test was expanded.** The conflict is recorded for the human reviewer (§11).
>
> **Non-satisfaction rule applied throughout.** A successful obligation-collection node means the results were **retained**, not that the checks **passed**. Missing tools, unknown applicability, an undecided reference platform, incomplete extraction, and unanswered human reviews are **not** treated as satisfied. In particular, a benchmark/profiler that produced **no** output because it **did not complete** is recorded as *"not run / timed out"*, never as *"fast"*, *"clean"*, or *"within budget"*. No numeric latency/throughput/memory limit is asserted as an obligation, because no pinned source defines one.

---

## 0. Summary

1. **The named GCC syntax failure is not present in the actual source (§2).** `score/socom/impl/service_identifier.hpp` is a 40-line, brace-balanced header; `grep '[{}]'` returns exactly `:19`, `:29`, `:32`, `:38` (two openers, two closers, net balance `0`) and line `:39` is blank. The described defect matches the *earliest* prior reports (split-form double close), not this checkout. **No correction is required or applied**, per the write boundary.
2. **There are no numeric performance/resource acceptance thresholds in the pinned sources (§4).** The pinned verification plan states only the *objective* ("response time and throughput", `verification_plan.rst:54-55`), makes resource-usage evaluation a **Level 2 "Feature Integration" method, "only on reference environment"** (`:203-206`, `:216-219`), and records **"The reference hardware is not yet decided."** (`:610`). The selection rule at `:115` ties `resource-usage` to requirements that address resource management; none is identified for this slice. No budget for latency, throughput, CPU, or memory is defined. Nothing is invented here.
3. **No benchmark or profiling result was produced for this slice (§5.1).** The retained `native_performance` collection now starts a real Bazel driver (`…/score-someip84-tools-0ptca_j_/bin/bazel`) but both legs **time out** — `benchmarks` exit **124** after its 300 s cap and `profiling` exit **124** after its 200 s cap (`obligations/native_performance/result.json`; `benchmarks.command.json`; `profiling.command.json`). `benchmarks.stdout` and `profiling.stdout` are **empty**; `benchmarks.stderr` stops mid-build at `Testing //tests/benchmarks:e2e_benchmarks` (`benchmarks.stderr:1084`). Both legs also still pass `--build_tests_only`. The retained node is therefore a **failure-to-complete**, not a latency/throughput/profile result.
4. **The one retained memory-analysis measurement finished and is scoped, not a performance number (§5.4).** `focused_memcheck` is now `completed` with both the focused compile and the `valgrind --tool=memcheck` run exiting `0` (valgrind 3.18.1 is present this iteration), limited to the focused identifier translation unit ("Optional complementary focused memory analysis"). It yields no heap/stack/throughput figures and is **not** a Massif/`memusage` profile.
5. **The retained performance *documentation* is draft, stale, and internally inconsistent with the actual benchmark source (§5.3).** `tests/benchmarks/benchmarks_analysis.md` is `Document Version 0.2 (Draft)` (`:22`), attributes its ~50 ms latency floor to `MAIN_LOOP_SLEEP{50}` in `echo_server.cpp`, while the actual source defines `constexpr auto MAIN_LOOP_SLEEP{10us};` (`tests/benchmarks/echo_server.cpp:35`); and its embedded SOME/IP raw output carries `***WARNING*** Library was built as DEBUG. Timings may be affected.` (`:653`, `:920`), contradicting the source-defined requirement that profiling/benchmarks use an optimized release build (`.github/skills/memory-profiling/SKILL.md:51-59,114`; `.bazelrc:96`). Its §7.1 column is headed **"Typical Requirement"**, not a project requirement (`:358-364`). It is a **descriptive artifact, not measured here and not an acceptance input**.
6. **Prerequisites have changed relative to the prior report and are now mostly present (§7).** The retained `tool_assurance` inventory records `bazel`, `perf`, `valgrind`, QEMU, CodeQL, clang-tidy, cppcheck, gcovr, clang-format, `pre-commit`, `reuse`, and `gitleaks` all `available: true`; `native_integration` records `kvm_exists: true` and `/usr/bin/qemu-system-x86_64`. They are **present but not sufficient**: the performance legs did not complete, they were build-only, the unprivileged-userns wrapper requirement is unverified, and no reference hardware is selected.
7. **No obligation is satisfied (§8).** Every `source-index.json` entry is `native_acceptance: not_inferred`; `authority.json` is `engineering_acceptance: pending`, `human_reviews: unanswered`, `safety_class: unknown`. The native test/sanitizer/tsan legs are `--build_tests_only` (compiled, not executed); `native_integration` exited `1`; focused TSan tests exited `66`; CodeQL retained findings; tool assurance is `completed_with_blockers`.

---

## 1. Binding, scope, and evidence

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` — *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:2-4` |
| State | `open`, 0 comments, no milestone / assignee / labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` | `.llm_tmp/context/issue-snapshot.json:19-20` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an accepted obligation**, and it contains **no performance requirement**: service-instance identifier = `service id + major + minor + instance id`; service identifier = `service id + major`; FindService = `service id + major + optional<minor> + optional<instance>`; plus the proposal to exclude `minor` from identity. There is no comment and no acceptance record, so none of it is binding, and none of it defines a timing or memory budget.

### 1.2 Baseline and current tree

| Item | Value | Source |
|------|-------|--------|
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |
| Branch | `fabro/run/01M3ZRSDK2XQAF1H48VWTPKQNZ` | run environment |
| HEAD | `94005f3` — `node_82c502590eb9336054c30bc3 (success)` | run environment supplied with this task |

Binding is **by baseline commit `f8a196c3…`**, not by run HEAD. No local hashing or git tool was available to this report (write boundary), so the working tree was **not** re-hashed and the direct source reads in §2–§3 are authoritative for this report. Earlier reports on the same baseline remain admissible prior evidence.

### 1.3 Candidate source paths (`.llm_tmp/context/candidate-files.json`)

| File (repo-relative) | Baseline git blob | Baseline present | Working tree (read this iteration) |
|----------------------|-------------------|------------------|------------------------------------|
| `score/socom/BUILD` | `3477ea0851fdcd82ec6ea9d71424013cbdf41962` | yes | `testonly` `impl_service_identifier` exposure |
| `score/socom/impl/service_identifier.cpp` | `6c7e7a4e22355242009fe20dada2a9a0d0c7a9c7` | yes | key identity `(instance, service id, major)`; `minor` excluded (`:20-30`) |
| `score/socom/impl/service_identifier.hpp` | `c8bae7908da9f087c518934f7b9f8d86db9a20ec` | yes | brace-balanced, 40 lines; line 39 blank (§2) |
| `score/socom/test/unit/BUILD` | `3c03a7b14286051f97fa5022206564bd63645171` | yes | `socom_test` globs `*.cpp`; deps wired |
| `score/socom/test/unit/runtime_tests.cpp` | `8ecf5ab726db8bf994c960045d6fd7fdf84d7395` | yes | 33 test macros; minor-only regression `:402-431` |
| `score/socom/test/unit/service_identifier_tests.cpp` | *(none — `null`)* | **no** (manifest expects a **new** file) | 91 `TEST_F` under `ServiceInstanceIdentifierTest` |

The `null` baseline blob for `service_identifier_tests.cpp` is the manifest's expectation of a **new** unit-test file; it exists on disk only as part of the un-merged working tree (the task's "cancelled draft"), never in the baseline. `glob **/service_identifier*` returns exactly three paths, so there is **no second, differently-braced copy** of the header. **None of these six paths contains a benchmark, profiler harness, or performance requirement.**

### 1.4 Prior reports and this iteration's reads

- **`.llm_tmp/overnight/prior-reports/` — 38 files present**, all preserved; notably `performance_review.md` (the earlier performance review on the same baseline), `scope.md`, `invariants.md`, `callsites.md`, `reproducer.md`, `key_fix.md`, `unit_matrix.md`, `ordering_tests.md`, `conversion_tests.md`, `runtime_disabled.md`, `runtime_enabled.md`, `lifetime_tests.md`, `test_metadata.md`, `coverage_review.md`, `sanitizer_review.md`, `finding_classification.md`, `native_build_review.md`, `integration_aou_review.md`, `security_review.md`, `tool_assurance_review.md`, `review_packet.md`, `verification_report_draft.md`.
- **`.llm_tmp/overnight/reports/`** — read this iteration (among others): `scope.md`, `key_fix.md`, `api_review.md`, plus the other entries present. This document adds `performance_review.md` to `reports/`.
- The preserved sequence is unchanged: `scope.md` (bounded the slice; identified the key/index identity gap) → `invariants.md` (I-4 baseline key included `minor`; I-9 record index ignores it; I-11 the resulting gap) → `callsites.md` → `reproducer.md` (header brace correction; focused red regression) → `key_fix.md` / `unit_matrix.md` (drop `minor` from the key ordering) → test expansions → `test_metadata.md` → review artifacts.

### 1.5 Host validation feedback present this iteration

`.llm_tmp/overnight/validation/` is **present** and was read:

- `check-result` = `0`; `collection-result` = `0`.
- `measurement.json`: `check_ref: check_conversion_tests`, `mode: ubsan`, `changed_paths: ["score/socom/test/unit/service_identifier_tests.cpp"]`, `origin: local_unprotected_measurement`, `initiator: Fabro host hook`, `engineering_acceptance: pending`, `full_native_tests: not_executed`, compiler `/usr/bin/x86_64-linux-gnu-g++-12` (`sha256 88315fd2…`). `baseline_with_agent_tests` = **91 tests / 33 failures / compile exit 0 / test exit 1**; `candidate` = **91 tests / 0 failures / compile exit 0 / test exit 0**.
- `before.json` / `after.json` encode the same 91/33 → 91/0 transition; `before-compile.*` / `after-compile.*` are the focused GCC/UBSan compiles (empty `after-compile.stderr`).

**Scope caveat:** this measurement compiles **only the focused identifier translation unit** (`service_identifier.cpp` + `string_registry.cpp` + `service_identifier_tests.cpp` + googletest) and runs the identifier tests. It does **not** compile `runtime_tests.cpp`, the interface-compatibility matrix, the IPC binding, the gateway daemons, or any Bazel target. It is a correctness/sanitizer red→green on the key TU, **not** a performance measurement.

### 1.6 Obligation-collection results present this iteration (performance-relevant)

All results are under `.llm_tmp/overnight/obligations/*/` and were read this iteration. Per the task rule, **retention is not passing**.

| Check | Retained status / evidence |
|-------|----------------------------|
| `native_performance` | `findings_or_execution_failure`; `benchmarks` exits **124** (300 s timeout), `profiling` exits **124** (200 s timeout); both use `--config=perf-tests[-flamegraphs] … //tests/benchmarks/... --build_tests_only`; `benchmarks.stdout`/`profiling.stdout` empty; `benchmarks.stderr:1084` stops at `Testing //tests/benchmarks:e2e_benchmarks` |
| `native_integration` | `findings_or_execution_failure`; qemu leg `exit_code: 1` (actually executed); `prerequisites: { kvm_exists: true, qemu: "/usr/bin/qemu-system-x86_64" }` |
| `focused_memcheck` | `completed`; focused compile exit `0`; `valgrind --tool=memcheck --leak-check=full --error-exitcode=42 --xml` exit `0`; limit *"Optional complementary focused memory analysis"* |
| `tool_assurance` | `completed_with_blockers`; all 15 inventoried tools `available: true` (g++-12, clang++, clang-tidy, bazel, CodeQL, gcov-12, gcovr, cppcheck, clang-format, pre-commit, reuse, qemu-system-x86_64, perf, valgrind, gitleaks); blockers: authorized-human tool confidence/qualification, Coverity not adopted, memcheck is optional |
| `native_build` | `completed`; `bazel build //...` exit `0` |
| `native_tests`, `native_sanitizers`, `native_tsan` | `completed`; each runs `bazel test … --build_tests_only` exit `0` — **tests built, not executed** |
| `native_coverage` | `completed`; `--build_tests_only` with `COVERAGE_THRESHOLD: 73`; limit *"Repository CI threshold 73 is not platform 85/100 line-and-branch acceptance"* |
| `cross_compilation` | `completed_with_blockers`; x86_64-linux and aarch64-linux `bazel build` exit `0` |
| `focused_coverage` | `completed`; `line_total 36 / line_covered 36` (100 %), `branch_total 14 / branch_covered 11` (78.6 %), `platform_goals { QM: 85, safety: 100 }`, `safety_class: unknown_requires_authorized_selection`, `complete_target_scope: false` |
| `focused_tsan` | `findings_or_execution_failure`; build exit `0`, tests exit `66` |
| `focused_clang_tidy`, `focused_cppcheck` | `findings_or_execution_failure`; clang-tidy `--verify-config` exit `1`; cppcheck exit `2` |
| `codeql_security`, `codeql_misra` | `findings_or_execution_failure`; scans completed, dependency/gtest-macro findings retained; MISRA mapping `:status: draft` |
| `secret_dependency_checks` | `findings_or_execution_failure`; gitleaks exit `1` |
| `process_checks` | `completed_with_blockers`; `metadata_inventory`: `runtime_tests.cpp` 33 macros, `service_identifier_tests.cpp` **91** macros, each with only `DerivationTechnique` + `Description`; blockers include *"Independent inspection and acceptance required"* |
| `rework_progress` | `completed`; `source_changed_this_round: false`, `rework_requested: false` |

Two reading rules: (a) the `native_tests` / `native_sanitizers` / `native_tsan` / `native_coverage` legs pass `--build_tests_only`, so exit `0` means the test targets were **compiled**, not that tests **executed** — consistent with `full_native_tests: not_executed`; (b) the `native_integration` qemu leg **actually executed** and exited `1`.

### 1.7 Pinned authority and obligation sources

`.llm_tmp/context/obligations/authority.json`: `engineering_acceptance: pending`; `human_reviews: unanswered`; `safety_class: unknown`; `codeql_scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway; no upload"`; instruction *"Restart the failed queue for one complete pass through all obligations"*. Every one of the nine `.llm_tmp/context/obligations/source-index.json` entries is `"native_acceptance": "not_inferred"` — pinned, but applicability to this slice is not inferred. The pinned performance-relevant source is `verification_plan.rst` (read to the extent relevant: `:54-55`, `:115`, `:203-206`, `:216-219`, `:610`). The pinned platform documents carry `:safety: ASIL_B`, but that attribute is **not** a selection of this slice's safety class and is not inferred as one.

---

## 2. Actual-source inspection of the recorded syntax failure

### 2.1 Verdict: the header is brace-balanced

`score/socom/impl/service_identifier.hpp`, read directly this iteration:

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

`grep '[{}]'` on the file returns exactly `:19`, `:29`, `:32`, `:38` — two openers, two closers, net brace balance `0`. Line `:39` contains no text. `glob **/service_identifier.hpp` returns exactly one path, so there is **no second, differently-braced copy** in this checkout. The sibling `service_identifier.cpp` uses the same nested form (`:18` / `:32`) and is balanced.

### 2.2 Tool corroboration (retained, not re-measured here)

The retained focused GCC **and** Clang compile legs of the candidate translation unit exit `0` with `-Werror` (`obligations/compiler_diagnostics/result.json`), and the candidate focused test run is `91 tests / 0 failures / compile exit 0` (`validation/measurement.json`; `validation/after.json`), against `baseline_with_agent_tests` `91 tests / 33 failures / compile exit 0` (`validation/before.json`). A surviving extra closing brace would have broken all of these. (Scope caveat: these are **focused single-translation-unit** runs, not a full Bazel build; §9.)

### 2.3 Disposition

The described defect is a **stale, pre-correction description** that matches the earliest prior reports (split-form `}  // namespace socom` + `}  // namespace score`). The correction recorded by the `reproducer` iteration left line `:39` blank — exactly the state observed here. Applying the historical repair to the already-balanced file would be a no-op at best and a compile break at worst. **No correction is applied; none is required**, and the explicit write boundary ("only that report may be written") would have forbidden a source write in any case. Consistent with that boundary, no test was expanded either. If a distinct "cancelled draft" revision still carries the extra brace, it is not the file in this checkout and must be located and corrected by an authorized iteration.

---

## 3. What "performance" can mean for this bounded slice

The slice changes only the ordering operator of the internal duplicate-server registration key (`score/socom/impl/service_identifier.cpp:20-30`): `minor` is dropped from `std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major)`. Source-derived, not measured:

- **No new allocation, lock, or I/O** is introduced. The key is stored in `std::set<Service_instance_identifier>` under an existing mutex (`runtime_impl.hpp:56`, `runtime_impl.cpp:443,449-454`); the change only removes one `std::uint16_t` component from each tuple comparison. Key construction is unchanged in type and size (`impl/service_identifier.hpp:29-32`).
- **Set cardinality cannot increase.** Excluding `minor` collapses previously distinct minor variants into one element, so the number of registration-key elements is weakly reduced. Whether this is observable is not measurable here.
- **No resource-management requirement** is attached to this type or to this change in any pinned or repository requirement source. The pinned `resource-usage` method is scoped to **Level 2 (Feature Integration) / Level 3 platform** on a **reference environment** (`verification_plan.rst:203-206`, `:216-219`), while this slice is a unit-level change; the same document states **"The reference hardware is not yet decided."** (`:610`).

Therefore the honest performance verdict for this slice is: **not measurable in this checkout, and not required by any definition-of-record to be measured at unit level.** The remainder of this report reviews what performance evidence *does* exist in the tree and why none of it is a result for this slice.

---

## 4. Source-defined performance / resource expectations (register)

### 4.1 Normative / pinned expectations

| # | Source | Expectation | Threshold? |
|---|--------|-------------|-----------|
| E-1 | `verification_plan.rst:54-55` | Verification objective *"Performance — Assess the software's performance to ensure it meets the required performance criteria, such as response time and throughput."* | **No number defined** |
| E-2 | `verification_plan.rst:115,203-206` | Test type `resource-usage` — *"Resource Usage Evaluation (only on reference environment)"*, applicable on *"-, 2 Feature Integration, -"*, QM & ASIL B; selected when requirements address resource management. | **No number defined; not applicable to unit level** |
| E-3 | `verification_plan.rst:216-219` | `resource-usage` *"should also be considered for level 3 (software platform level) testing … on reference hardware"*. | **No number defined** |
| E-4 | `verification_plan.rst:610` | *"The reference hardware is not yet decided."* | Blocking precondition |
| E-5 | `verification_plan.rst:300-335` (criteria 1-9) | Coverage / warnings / etc. goals. | **None is a latency/throughput/memory goal** |

**Conclusion:** the pinned obligation set defines an *objective* to assess response time and throughput, but **no acceptance budget**, and it locates resource-usage evaluation on a reference environment/level that does not exist yet.

### 4.2 Benchmark-harness expectations (repository source)

| # | Source | Expectation | Threshold? |
|---|--------|-------------|-----------|
| E-6 | `.bazelrc:93-96` | `test:perf-tests` = `--run_under=//tests/benchmarks:setup_network`, `--define=perf_tests=true`, `--compilation_mode=opt`. | Optimized build required; no number |
| E-7 | `.bazelrc:98-106` | `test:perf-tests-flamegraphs` adds `-fno-omit-frame-pointer -g --strip=never`, `--define=flamegraphs=true`; comment *"Requires perf; FlameGraph scripts are downloaded by Bazel."* | Prerequisite, no number |
| E-8 | `tests/benchmarks/README.md:18-51` | Run e2e over `127.0.0.2`/`127.0.0.3` in an isolated namespace; result written as `benchmarks.json` under `bazel-testlogs/...`; *"Unprivileged user namespaces must be enabled so the Bazel `--run_under` wrapper can configure the isolated loopback addresses…"* | Prerequisite, no number |
| E-9 | `tests/benchmarks/BUILD.bazel:21-36,50-59` | `perf_tests`/`flamegraphs` config settings; `setup_network` `sh_binary`; `flamegraph_scripts` select. | No number |
| E-10 | `tests/benchmarks/README.md:35-48` | Profiling filter `IpcBenchmark/Throughput/3/.*`; `.perf.data`/`.perf.svg` written beside `benchmarks.json`. | No number |

**Conclusion:** the harness defines *how* to measure (opt build, isolated network, perf/flamegraph prerequisites) but defines **no pass/fail number**.

### 4.3 Memory / CPU profiling expectations (repository source)

| # | Source | Expectation | Threshold? |
|---|--------|-------------|-----------|
| E-11 | `.github/skills/memory-profiling/SKILL.md:51-59,114` | Profiling requires **release-optimized** binaries with **no sanitizers**; *"Do NOT run profiling with debug builds or sanitizers — results will be misleading."* | Method requirement |
| E-12 | `score/gateway_ipc_binding/benchmark/README.md:99-112` | *"Expected results for a healthy build":* peak heap (memusage) ≈ 172 KB; peak heap (Massif useful) ≈ 172 KB; peak stack ≈ 11 KB; total malloc ≈ 373; allocations all during initialization (zero per-iteration); no heap growth; no leaks. | **Guide expectations, not pinned requirements** |
| E-13 | `score/gateway_ipc_binding/benchmark/README.md:193-204` | Typical profile composition: syscall/kernel ≈74 %, poll ≈26 %, recv ≈31 %, send ≈9 %, mutex ≈10 %, shared-memory ≈5 %. | Typical, not a threshold |

**Conclusion:** the profiling guide provides *expected values of a healthy build*, but these are documentation examples, and the affected `gateway_ipc_binding` components are **outside** the six candidate paths and this slice.

### 4.4 Retained descriptive analysis (not a requirement)

`tests/benchmarks/benchmarks_analysis.md` is a **draft** document (`:22`, "Document Version 0.2 (Draft)"; `:23`, last updated 2026-03-23) reporting an older measurement campaign (`:20`, "Test Date: November 18, 2025"). Its §7.1 "Automotive Industry Context" table (`:358-364`) lists "typical requirement" values (p99 < 100 ms, CV < 5 %, 10-50 MB/s, CPU < 10 %) in a column explicitly headed **"Typical Requirement"**, not "project requirement". **These are not obligations and are not adopted as thresholds here.** Its own internal caveats are discussed in §5.3.

### 4.5 Explicit statement on thresholds

**No pinned source and no repository requirement defines a numeric latency, throughput, CPU, heap, or stack limit for this slice or for the benchmark targets.** This review therefore records the limits as **unmeasured/unavailable** (§6) and **invents none**. The E-12 and E-13 values remain labelled as a profiling guide's examples/typicals, not acceptance criteria.

---

## 5. Retained benchmark/profiling outputs vs source-defined expectations

### 5.1 `native_performance`: a failure to complete, not a benchmark result

`obligations/native_performance/result.json` records two attempted commands, both with the (now-present) pinned driver `…/score-someip84-tools-0ptca_j_/bin/bazel`, and status `findings_or_execution_failure`:

| Label | Attempted argv (abridged) | Cap | Exit | Reason |
|-------|---------------------------|-----|------|--------|
| `benchmarks` | `…/bin/bazel --batch --output_user_root=… test --jobs=2 --config=perf-tests //tests/benchmarks/... --build_tests_only` | 300 s | **124** | *"Command timed out; owned process group stopped"* |
| `profiling` | `…/bin/bazel --batch --output_user_root=… test --jobs=2 --config=perf-tests-flamegraphs //tests/benchmarks/... --build_tests_only` | 200 s | **124** | *"Command timed out; owned process group stopped"* |

Two independent issues are recorded here:

1. **The legs did not finish.** `benchmarks.stdout` and `profiling.stdout` are **empty** (no captured benchmark output). `benchmarks.stderr` shows the build analysing 6 targets and progressing through compilation, stopping at `[1,564 / 1,566] … Testing //tests/benchmarks:e2e_benchmarks; … (2 actions running)` (`benchmarks.stderr:1084`) when the process group was stopped at the timeout. No `benchmarks.json`, `.perf.data`, `.perf.svg`, or test-output directory exists in this checkout (`glob` over `**/benchmarks.json`, `**/*.perf.*`, `**/{memory_profile,profiling}/**` returns nothing).
2. **Even had it finished, the command could not produce a benchmark.** Both legs pass `--build_tests_only`, which builds test targets but does not execute them; the `perf-tests` config's `--run_under=//tests/benchmarks:setup_network` (`.bazelrc:94`) is therefore not the measurement path for these invocations. So this collection node, by construction, is a **build-oriented** check that cannot yield latency, throughput, or profiling data, and must not be cited as one.

**Verdict:** no benchmark and no profiling result exists for this slice; the retained node is a **timeout/build-only blocker** (a change from the prior report, whose retained legs exited `127` on a missing driver).

### 5.2 `native_integration` (KVM/QEMU): prerequisites present, run failed

`obligations/native_integration/result.json` attempts `…/bin/bazel … test --jobs=2 --config=qemu-integration //quality/... //tests/integration_test/...` and records `exit_code: 1` (`:1080`) and status `findings_or_execution_failure` (`:1083`), with `prerequisites: { "kvm_exists": true, "qemu": "/usr/bin/qemu-system-x86_64" }` (`:1087-1090`). The qemu leg **did execute** (a change from the prior report's exit `127`), but it **failed**. **KVM/QEMU availability is a prerequisite, not a measurement**: there is no resource-usage data and no reference-environment result. This matters for `resource-usage`, which the pinned plan scopes to the reference environment (§4.1).

### 5.3 `tests/benchmarks/benchmarks_analysis.md` vs the actual benchmark source

The retained analysis document is inconsistent with the current benchmark source and cannot be treated as a current result:

- **Sleep-constant contradiction.** The document repeatedly attributes its ~50 ms latency floor to a *"50 ms polling sleep (`MAIN_LOOP_SLEEP{50}`) in `echo_server.cpp`"* (`benchmarks_analysis.md:37-41`, `:60-64`). The **actual** source defines `constexpr auto MAIN_LOOP_SLEEP{10us};` (`tests/benchmarks/echo_server.cpp:35`). The document's central timeline narrative (a ~50 ms floor, and a doubled ~100 ms gateway round trip) therefore **does not match the current source-defined harness**; the document is stale relative to the tree or refers to a different revision. No replacement latency figure is derived here (that would be inventing a measurement).
- **Debug-build timing.** The embedded SOME/IP raw output states `***WARNING*** Library was built as DEBUG. Timings may be affected.` (`benchmarks_analysis.md:653`, `:920`). That directly conflicts with the source-defined profiling method, which requires a release-optimized build (`.github/skills/memory-profiling/SKILL.md:114`; `.bazelrc:96` `--compilation_mode=opt`). Timings from a DEBUG artifact are not valid under those expectations.
- **No artifact for the current tree.** No `benchmarks.json`, `.perf.data`, `.perf.svg`, `memory_profile/`, or `profiling/` output exists in this checkout. The numbers in the document are prose/tables, not a reproducible artifact retained here.

**Verdict:** the document is a descriptive draft with its own documented caveats; it is **not** a current, reproducible benchmark result for this slice and is not used as one.

### 5.4 Memory / profiling expectations vs available outputs

| Expectation | Where defined | Evidence available here | Status |
|-------------|---------------|-------------------------|--------|
| Release-optimized, no-sanitizer profiling build | `SKILL.md:51-59,114` | `native_performance` legs are `--config=perf-tests*` (opt) but timed out and were build-only | **NOT RUN** |
| Peak heap ≈172 KB, peak stack ≈11 KB, ≈373 mallocs, zero per-iteration, no leaks | `gateway_ipc_binding/benchmark/README.md:99-112` | no `memusage`/Massif output retained | **NOT MEASURED** |
| Typical profile mix (syscall/poll/recv/send/mutex/shm) | `gateway_ipc_binding/benchmark/README.md:193-204` | no `perf.data`/flamegraph retained | **NOT MEASURED** |
| Focused memcheck of the key TU | `obligations/focused_memcheck/result.json` | focused compile exit `0`; `valgrind --tool=memcheck` exit `0` (valgrind 3.18.1 present); status `completed`; limit *"Optional complementary focused memory analysis"* | **RAN, scoped to the focused identifier TU**; no Massif/heap/stack numbers |

`tool_assurance/result.json` confirms `valgrind` (`…/bin/valgrind`, sha256 `4652774b…`, version `valgrind-3.18.1`) is available this iteration — a change from the prior report, where it was absent and the memcheck leg exited `127`. The focused memcheck now **executed and passed** its `--error-exitcode=42` gate, but it is scoped to a single translation unit, is *"optional complementary"*, and produces **no** latency/throughput/memory-size numbers.

### 5.5 The one retained "resource-adjacent" measurement is not performance evidence

`focused_coverage` records `line_total 36 / line_covered 36` (100 %) and `branch_total 14 / branch_covered 11` (78.6 %), `platform_goals { QM: 85, safety: 100 }`, `complete_target_scope: false`, `safety_class: unknown_requires_authorized_selection`. This is structural coverage of the focused key executable, **not** a timing/throughput/memory measurement. The validation `measurement.json` (`candidate 91/0`, `baseline 91/33`, `full_native_tests: not_executed`, `mode: ubsan`) is likewise a focused correctness/sanitizer run, **not** a performance result.

---

## 6. Unmeasured resource limits (register)

Nothing in this row was measured for this slice in this checkout. "Source-defined expectation" means an expectation exists in a source file; "No number" means no acceptance threshold is defined anywhere and none is invented.

| Metric | Source-defined expectation | Status for this slice |
|--------|----------------------------|-----------------------|
| Round-trip latency (p50/p90/p99) | Objective only (`verification_plan.rst:54-55`); descriptive ranges in draft `benchmarks_analysis.md` | **UNMEASURED** — `native_performance` legs timed out (exit 124); no artifact |
| Tail-latency jitter (CV, spread) | None beyond the objective | **UNMEASURED** |
| Throughput (msg/s) | Objective only | **UNMEASURED** |
| Bandwidth (MB/s) | Described as "typical requirement" only (`benchmarks_analysis.md:358-364`) | **UNMEASURED** |
| CPU time / utilization | Profiling guide "typical" mix only (`gateway_ipc_binding/benchmark/README.md:193-204`) | **UNMEASURED** — no `perf.data`/flamegraph retained |
| Heap peak / stack peak | Guide "expected for a healthy build" (`:99-112`) | **UNMEASURED** — no `memusage`/Massif output |
| Allocation count / per-iteration allocations / leaks | Guide expectations (`:99-112`) | **UNMEASURED** |
| Focused key-TU memory errors | `focused_memcheck` collector (`--error-exitcode=42`) | **RAN (exit 0), scoped** — not a latency/throughput/size figure |
| Registration-key comparison cost / set cardinality effect | Source-derived: weakly reduced; no threshold | **SOURCE-ONLY**, not measured (§3) |
| Reference-environment (Level 2/3) resource usage | `verification_plan.rst:203-206,216-219` | **NOT APPLICABLE / NOT RUN** — reference hardware undecided (`:610`) |

**No acceptance threshold is asserted for any row.** The E-12 and E-13 numbers remain labelled as profiling-guide examples/typicals.

---

## 7. Prerequisites (perf / KVM / build / profiling) — recorded

This iteration's artifacts **changed** the prerequisite picture relative to the prior performance review: the pinned Bazel driver, `perf`, `valgrind`, QEMU and KVM are now present, but the measurement legs still did not produce results.

| Prerequisite | Evidence | Consequence |
|--------------|----------|-------------|
| Bazel driver | `tool_assurance/result.json:1408-1410` `…/score-someip84-tools-0ptca_j_/bin/bazel` `available: true` (sha256 `9860da9c…`); `USE_BAZEL_VERSION=8.6.0` | Present; `native_performance` now times out rather than exiting 127, but still yields **no** measurement |
| `perf` | `tool_assurance/result.json:1452-1455` `/usr/bin/perf` `available: true` (sha256 `2d095308…`) | Binary present, **but** flamegraph profiling needs the `setup_network` wrapper, FlameGraph download and a completed run; **not achieved** |
| `valgrind` | `tool_assurance/result.json:1457-1460` `…/bin/valgrind` `available: true` (sha256 `4652774b…`); `version-13.stdout:1` `valgrind-3.18.1` | Present; focused memcheck ran and passed; **no** Massif/heap/stack profiling run |
| QEMU + KVM | `native_integration/result.json:1087-1090` `kvm_exists: true`, `qemu: /usr/bin/qemu-system-x86_64` (sha256 `55862c76…`) | Present and **executed**, but the qemu leg exited `1`; no reference-environment data |
| Unprivileged user namespaces | required by `tests/benchmarks/README.md:50` for the `setup_network` `--run_under` wrapper | **Not recorded as verified** by any retained artifact; a hidden prerequisite of `perf-tests` |
| Reference hardware | `verification_plan.rst:610` *"The reference hardware is not yet decided."* | Level 2/3 `resource-usage` cannot be executed or bounded |
| `gnuplot` (for `memusage.png`) | `gateway_ipc_binding/benchmark/README.md` | Not present in the tool inventory; the memory timeline graph cannot be produced |
| Bazel `--build_tests_only` scope | `native_performance/result.json:1064,1093`; `benchmarks.command.json:11`; `profiling.command.json:11` | Even with Bazel present, these legs build tests only and cannot measure; and they timed out at that |
| `native_performance` time caps | `benchmarks.command.json:26` (300 s), `profiling.command.json:26` (200 s) | The `--jobs=2` build did not finish within the caps (`exit_code: 124`), so the benchmark/profiler never produced output |

**Recording rule.** `perf` and KVM/QEMU being present is **not** evidence of a measurement; both remain **unexercised for this slice** (the profiling leg did not complete, and the integration leg failed). No prerequisite is treated as satisfied by its mere presence.

---

## 8. Obligations status (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Performance objective: response time & throughput assessed | `verification_plan.rst:54-55` | **NOT MEASURED** — no benchmark completed; no threshold defined |
| `resource-usage` evaluation (reference environment) | `verification_plan.rst:115,203-206,216-219` | **NOT APPLICABLE / NOT RUN** — Level 2/3; reference hardware undecided (`:610`); no resource-management requirement identified for this slice |
| Native performance check (`--config=perf-tests`) | `.bazelrc:93-96`; `tests/benchmarks/README.md` | **NOT RUN** — exit 124 (timeout); command was `--build_tests_only` |
| Profiling / flamegraphs (`--config=perf-tests-flamegraphs`) | `.bazelrc:98-106` | **NOT RUN** — exit 124 (timeout); no `.perf.data`/`.perf.svg` |
| Memory profiling (Massif/memusage) | `SKILL.md`; `gateway_ipc_binding/benchmark/README.md` | **NOT RUN** — no Massif/`memusage` artifact |
| Focused memcheck of the key TU | `focused_memcheck` collector | **RAN, exit 0, scoped** — optional complementary; not a resource figure |
| QEMU/reference integration (resource context) | `verification_plan.rst`; `.bazelrc` qemu config | **FAILED** — qemu leg exit 1; KVM/QEMU prerequisites present only |
| Benchmark outputs reviewed against source expectations | this task | **DONE (documentary)** — the only retained performance document is draft/stale/inconsistent (§5.3); no current artifact exists |
| Tools identified / evaluated / qualified | `tool_management.rst` | **NOT ESTABLISHED** — inventory present, but `tool_assurance` is `completed_with_blockers` (*tool confidence/qualification require authorized humans*; Coverity not adopted) |
| Freedom from compiler warnings & errors (100 %) | `verification_plan.rst` (criterion 9) | **NOT SATISFIED** — focused GCC/Clang `-Werror` legs exit 0, but full native/toolchain builds and warnings across `//score/...` were not exercised as a warning gate by this report |
| Static code analysis (clang-tidy / CodeQL), findings classified | `code_analysis.rst`; `verification_process.rst` (SCA classification) | **NOT SATISFIED** — clang-tidy `--verify-config` exit 1; cppcheck exit 2; CodeQL retained findings; MISRA mapping draft |
| Unit/component testing executed, results recorded | `verification_plan.rst` (criteria 6-7); `verification_guideline.rst` | **PARTIAL** — focused identifier run is 91/91; native test legs are `--build_tests_only`, and `full_native_tests: not_executed` |
| Independence of verification / review | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED** |
| External-component AoUs verified | `verification_process.rst` (`gd_req__verification_external_aou`) | **NOT SATISFIED** — native integration failed; no AoU register |
| Obligation collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **PRESENT, retention ≠ passing** — see §1.6 |
| Native acceptance | `source-index.json` | **`not_inferred` for every entry** |

**Explicit non-satisfaction statement.** The present-but-incomplete tools, the timed-out benchmark/profiling legs, the `--build_tests_only` scope, the failed integration leg, the undecided reference hardware, the missing benchmark/profiling artifacts, the below-goal/scoped coverage, the draft MISRA mapping, and the unanswered human reviews mean **none of the checked obligations may be treated as satisfied**. A retained collection result shows *retention*, not passing; an empty or truncated output is **not** evidence of good performance. In particular, `native_build`/`cross_compilation` exiting `0`, the focused 91/91 run being green, and the focused memcheck exiting `0` are **not** independent verification, acceptance, or a full native runtime pass.

---

## 9. Measurement and validation status

- **Tools used:** `read_file`, `grep`, `glob`, `write_file` only. No `shell`, delegation, web, approval, publishing, or engineering acceptance.
- **Measurements executed by this iteration:** **none**. No build, no `bazel test`, no benchmark, no profiler.
- **Genuine executed results available in the checkout (not performance):** focused GCC/UBSan key-TU compile+tests (candidate 91/0; baseline 91/33), focused ASan/LSan/UBSan, focused Clang/GCC `-Werror` compiles, focused coverage (100 % line / 78.6 % branch), focused memcheck (exit 0), CodeQL security/MISRA focused scans, cppcheck (exit 2), and the qemu integration leg (exit 1). None of these measures latency, throughput, CPU, or memory size.
- **Not run / not completed / unavailable in practice:** every Bazel benchmark/profiling config (`perf-tests`, `perf-tests-flamegraphs`) — the legs timed out; `valgrind`/Massif profiling; `perf`/flamegraph generation; QEMU/reference-environment resource evaluation; the native test/sanitizer/tsan legs as *executed* tests (`--build_tests_only`); the unprivileged-userns network wrapper (unverified).
- **Scope:** local, unprotected, scoped. This is not acceptance, review, publication, or a full native run; no performance claim is made.
- **Reproduction path for a later, authorized iteration (not executed here):**

  ```bash
  # Requires the pinned Bazel driver, network-namespace privileges, and (for flamegraphs) perf + FlameGraph,
  # with enough time for the opt build to finish; remove --build_tests_only so the benchmark actually runs.
  /path/to/pinned/bazel test --config=perf-tests        //tests/benchmarks:e2e_benchmarks           --test_output=streamed
  /path/to/pinned/bazel test --config=perf-tests-flamegraphs //tests/benchmarks:e2e_benchmarks_profiling --test_output=streamed
  # Focused key-level correctness (not a performance measurement):
  bazel test //score/socom/test/unit:socom_test --test_filter='ServiceInstanceIdentifierTest.*'
  # Memory profiling (requires valgrind; release/no-sanitizer build):
  bazel build -c opt --features=-tsan //score/gateway_ipc_binding/benchmark:gateway_ipc_binding_memory
  ```

  Any value produced must be compared to a **human-approved** budget; none exists today (§4.5).

---

## 10. Notice preservation

- No source, build, test, config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was created, edited, or deleted by this iteration; **only this report was written.**
- The header the task flagged (`score/socom/impl/service_identifier.hpp`) retains its Apache-2.0/SPDX comment (`:1-12`) and was left unchanged because it is already brace-balanced (§2). The sibling `service_identifier.cpp` (`:1-12`), both BUILD files, both candidate test files, and the benchmark/profile source files retain their Apache-2.0/SPDX headers.
- All files under `.llm_tmp/overnight/reports/`, `.llm_tmp/overnight/prior-reports/`, `.llm_tmp/overnight/validation/`, and `.llm_tmp/overnight/obligations/` were preserved unchanged; this document is a new `reports/` entry.
- This report itself carries the Apache-2.0 header. No licensed MISRA rule text is reproduced; only rule/query identifiers and file locations are cited.

---

## 11. Pending human review checklist

- [ ] **Confirm §2:** `service_identifier.hpp` is brace-balanced (brace lines `:19,:29,:32,:38`; line 39 blank; net balance 0); the recorded "extra closing brace at line 39" is stale or refers to a different revision. No source correction is required in this checkout; if a distinct "cancelled draft" revision still carries the brace, locate and correct it by an authorized iteration.
- [ ] **Resolve the instruction conflict:** "Inspect and correct the actual source" vs. "this is a review draft: only that report may be written"; confirm that writing only this report was intended and that the no-op on already-correct source is acceptable.
- [ ] **Confirm §4.5:** no numeric latency/throughput/CPU/memory acceptance threshold exists in the pinned sources, and none should be inferred; treat `benchmarks_analysis.md` §7.1 "Typical Requirement" values and `gateway_ipc_binding/benchmark/README.md` "Memory Profiling Results" as documentation examples, not obligations.
- [ ] **Make the performance legs actually measure:** raise the `native_performance` time caps (the 300 s/200 s limits were hit; `exit_code: 124`) and **remove `--build_tests_only`** so `--config=perf-tests`/`perf-tests-flamegraphs` execute the benchmark and write `benchmarks.json`/`.perf.data`/`.perf.svg`.
- [ ] **Confirm/record the unprivileged-userns prerequisite** (`tests/benchmarks/README.md:50`) and re-run `native_integration`, which **executed and failed** (exit `1`) despite `kvm_exists: true` and QEMU presence.
- [ ] **Decide the reference hardware / resource-usage applicability** (`verification_plan.rst:203-206,216-219,610`) and either schedule Level 2/3 `resource-usage` evaluation or record it as out of scope for this unit-level slice; `resource-usage` is selected only when requirements address resource management (`:115`).
- [ ] **Reconcile the stale analysis with source:** update or retire `tests/benchmarks/benchmarks_analysis.md` (the `MAIN_LOOP_SLEEP{50}` vs source `10us` mismatch, and the DEBUG-build timing warning at `:653`/`:920`), and regenerate benchmark/profile artifacts from a release (`-c opt`) build.
- [ ] **Disposition the slice's own performance posture** (§3): confirm the source-derived reading that the key change adds no allocation/lock and weakly reduces set cardinality, and either accept the absence of a unit-level performance requirement or define one.
- [ ] **Treat the present tools as prerequisites only** (§7): `bazel`, `perf`, `valgrind`, QEMU and KVM being `available: true` is not a measurement; do not infer passing from their presence or from the retained-but-incomplete nodes.
- [ ] **Select the safety class**, schedule independent human review (approver ≠ author per `gd_req__verification_independence`), and record engineering acceptance; no performance compliance claim may be made before that.
- [ ] **Supply/refresh artifacts** (`.llm_tmp/overnight/obligations/*/result.json`, benchmark/profiling outputs, an updated `.llm_tmp/overnight/validation/`) into this checkout; do not infer performance from absence or from a failed-to-complete node.

---

*End of performance review draft. Local, unprotected, scoped. No engineering acceptance; human reviews unanswered; full native runtime and performance/profiling runs pending. The retained benchmark/profiling nodes did not produce results (`native_performance` timed out at exit 124 with `--build_tests_only`; `native_integration` failed at exit 1); the focused memcheck ran but is optional and scoped to one translation unit. No latency, throughput, CPU, heap, or stack limit is measured, and no acceptance threshold is invented.*
