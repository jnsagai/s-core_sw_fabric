<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

# SOME/IP issue #84 — original tool-findings reconciliation and classification (`finding_classification`) review draft

**Document type:** review draft (actual-source inspection + original compiler /
Clang-Tidy / Cppcheck / sanitizer / CodeQL findings reconciliation + severity
classification register + retained-dependency register + obligations status)
**Date:** 2026-10-02
**Repository:** `eclipse-score/inc_someip_gateway`
**Slice:** bounded duplicate-server registration-key handling within *Revise version
handling in socom* (issue #84)
**Run:** branch `fabro/run/01M3YRJEGXNY6CB81T7TKW774B`
**Status:** local, unprotected, scoped. **No engineering acceptance exists. Human
reviews are unanswered. Full native runtime tests remain pending.** Every statement
below is either a direct reading of the working tree, a direct reading of the
retained artifacts under `.llm_tmp/overnight/`, or an explicitly-labelled logical
consequence. Nothing here is published, reviewed, accepted, or a full native run.

> **Tool / write boundary actually observed.** Only `read_file`, `grep`, `glob`, and
> `write_file` were used. No `shell`, delegation, web access, approval, publishing, or
> engineering acceptance was performed. **This iteration wrote exactly one file — this
> report.** No source, build, test, config, `NOTICE`, `LICENSE`, `REUSE.toml`, or
> prior-report file was created, edited, or deleted. All prior reports under
> `.llm_tmp/overnight/reports/` and `.llm_tmp/overnight/prior-reports/` are preserved.
>
> **Instruction conflict (recorded, not resolved).** The task records *"a measured GCC
> syntax failure: an extra closing brace in `score/socom/impl/service_identifier.hpp` at
> line 39"* and directs *"Inspect and correct the actual source before expanding tests"*,
> but its final sentence says *"This is a review draft: only that report may be
> written."* Direct inspection of the **actual** source (§2) shows the header is
> **already brace-balanced**; there is no unmatched brace to remove. The write boundary
> forbids a source write in any case. The conflict is recorded for the human reviewer
> (§9), not silently resolved. **No source was edited and no test was expanded.**
>
> **Non-satisfaction rule applied throughout.** A successful obligation-collection node
> means the results were **retained**, not that the checks **passed**. Missing tools,
> unknown applicability, incomplete extraction, an inactive rule mapping, and
> unanswered human reviews are **not** treated as satisfied. In particular: a tool that
> produced **no** finding because it **did not run** is recorded as *"not run"*, never
> as *"clean"*.

---

## 0. Summary

1. **The named GCC syntax failure is not present in the actual source (§2).**
   `score/socom/impl/service_identifier.hpp` is a 40-line, brace-balanced header. A
   `grep` for `[{}]` returns exactly four brace-bearing lines — `:19`
   (`namespace score::socom {`), `:29` (`struct Service_instance_identifier final {`),
   `:32` (`};`), `:38` (`}  // namespace score::socom`) — two openers, two closers, net
   balance `0`; line `:39` is blank. The retained focused **GCC** compile of the same
   translation unit exits `0` with empty `stderr`. The described defect matches the
   *earliest* prior reports (split-form double close), not this checkout. **No
   correction is required or applied.**
2. **Original findings were read from the raw artifacts and reconciled by location
   (§3).** The only non-zero, non-environment results are: one **Clang** dependency
   deprecation error; **19 Cppcheck** `passedByValue` performance findings in headers
   outside the six candidate paths; **32 CodeQL security** findings all under
   `.llm_tmp/googletest/**`; and a large **CodeQL MISRA** set (lines 306–117 940 of
   `codeql_misra/result.json`) that lands in googletest, the new candidate test file
   (gtest `TEST_F` macro expansion), and two repository production files outside the
   slice (`string_registry.cpp` / `string_registry.hpp`). **Clang-Tidy produced no
   findings because it did not run** (`--verify-config` exit 1).
3. **No authorized Critical/High/Medium/Low rating exists (§4).** Per
   `gd_req__verification_sca_classification` (`verification_process.rst:228-248`),
   findings must be classified Critical/High/Medium/Low either by a **tool suggestion**
   or **manually by the Quality Manager together with a committer**. No tool retained a
   Critical/High/Medium/Low rating (CodeQL `level` is `null` on every finding; Cppcheck
   emits only its own `performance` severity; the compiler emits `error`). No QM/committer
   classification is present (`engineering_acceptance: pending`). Suggested review-aid
   classes are therefore labelled **indicative only**, and every **authorized** class is
   **none / pending**.
4. **Dependency findings are retained, not filtered (§5).** Every googletest/library
   finding is listed by native rule id and scope. No finding was suppressed, dropped,
   or silently discarded.
5. **The candidate key units are clean in the focused extraction, but that is not a
   compliance statement (§6).** `service_identifier.cpp` / `.hpp` carry no analyzer
   finding; `runtime_tests.cpp` was **not extracted**; clang-tidy did not run; the CodeQL
   extraction is focused, not full-target.
6. **No obligation is satisfied (§7).** Every `source-index.json` entry is
   `native_acceptance: not_inferred`; authority is `engineering_acceptance: pending`,
   `human_reviews: unanswered`, `safety_class: unknown`.

---

## 1. Binding, scope, and evidence

### 1.1 Issue of record

| Field | Value | Source |
|-------|-------|--------|
| Issue | `eclipse-score/inc_someip_gateway#84` — *Revise version handling in socom* | `.llm_tmp/context/issue-snapshot.json:2-4` |
| State | `open`, 0 comments, no milestone/assignee/labels | `.llm_tmp/context/issue-snapshot.json:6,14-18` |
| Author | `NEOatNHNG` | `.llm_tmp/context/issue-snapshot.json:8` |
| Created / updated | `2026-04-14T13:23:24Z` | `.llm_tmp/context/issue-snapshot.json:19-20` |
| Baseline commit | `f8a196c3b16d5172d898394ab99b0ed81346d63d` | `.llm_tmp/context/source-manifest.json:3` |
| Repository | `eclipse-score/inc_someip_gateway` | `.llm_tmp/context/source-manifest.json:2` |

The body (`.llm_tmp/context/issue-snapshot.json:5`) is a **design proposal, not an
accepted obligation**: service-instance identifier = `service id + major + minor +
instance id`; service identifier = `service id + major`; FindService = `service id +
major + optional<minor> + optional<instance>`; and the proposal to exclude `minor`
from identity and make it an instance property. There is no comment and no acceptance
record, so none of it is binding.

### 1.2 The six writable candidate source paths

From `.llm_tmp/context/candidate-files.json`:

1. `score/socom/BUILD`
2. `score/socom/impl/service_identifier.cpp`
3. `score/socom/impl/service_identifier.hpp`
4. `score/socom/test/unit/BUILD`
5. `score/socom/test/unit/runtime_tests.cpp`
6. `score/socom/test/unit/service_identifier_tests.cpp` (baseline blob `null` — a **new** file)

The changed implementation is the registration-key comparator only:

```cpp
// score/socom/impl/service_identifier.cpp:20-30
bool operator<(Service_instance_identifier const& lhs, Service_instance_identifier const& rhs) {
    return std::tie(lhs.instance, lhs.interface.id, lhs.interface.version.major) <
           std::tie(rhs.instance, rhs.interface.id, rhs.interface.version.major);
}
```

i.e. identity is `(instance, service id, major)`; `minor` is deliberately excluded,
matching the minor-ignoring `Service_database` index (`runtime_impl.hpp:116-134`).

### 1.3 Host validation and obligation artifacts read this iteration

| Artifact | Content |
|----------|---------|
| `validation/check-result` | `0` (collector success marker only) |
| `validation/measurement.json` | `origin: local_unprotected_measurement`, `initiator: Fabro host hook`, `engineering_acceptance: pending`, `full_native_tests: not_executed`, compiler `/usr/bin/x86_64-linux-gnu-g++-12`; `baseline_with_agent_tests` **85 tests / 28 failures / compile 0**; `candidate` **85 tests / 0 failures / compile 0** |
| `validation/after.json` | 85 tests, 0 failures, 0 disabled, 0 errors |
| `obligations/compiler_diagnostics/` | GCC compile exit 0, GCC tests exit 0, Clang compile exit 1 (dependency) |
| `obligations/focused_clang_tidy/` | `--verify-config` exit 1; no TU analysis |
| `obligations/focused_cppcheck/` | exit 2; 19 `passedByValue` performance findings |
| `obligations/codeql_security/` | 32 findings, all under `.llm_tmp/googletest/**` |
| `obligations/codeql_misra/` | findings lines 306–117 940; dependency + macro + out-of-slice production |
| `obligations/focused_asan_lsan/` | 87/87 pass, exit 0 |
| `obligations/focused_tsan/` | tests exit **-11** (SIGSEGV); `ASAN_OPTIONS`/`UBSAN_OPTIONS` set |
| `obligations/focused_memcheck/` | exit 127; `valgrind` unavailable |
| `obligations/focused_coverage/` | current `coverage-summary.json` 36/36 lines (100 %), 11/14 branches (78.6 %) |
| `obligations/native_*`, `cross_compilation`, `format_precommit` | exit 127 (`/tmp/s-core-001/bin/bazel` missing) |
| `obligations/process_checks/` | `completed_with_blockers`; metadata: `runtime_tests.cpp` 33 macros, `service_identifier_tests.cpp` **87** macros |
| `obligations/rework_progress/` | `source_changed_this_round: true`, `rework_requested: false`, stop reason *"One complete pass requested; unresolved findings stay pending"* |

The host measurement is **focused and stale**: it compiled the earlier 85-case state
of `service_identifier_tests.cpp` and never compiled `runtime_tests.cpp` or any Bazel
target, while the working tree now has **87** key-test macros.

### 1.4 Pinned obligation sources (read)

| id | file | status |
|----|------|--------|
| `coding_guidelines` | `coding_guidelines.rst` | `:status: valid`; **MISRA C++:2023, C++17** |
| `code_analysis` | `code_analysis.rst` | `:status: valid`; MISRA/ISO 26262-based SCA |
| `misra_mapping` | `misra_mapping.rst` | **`:status: draft`**; `csv-table` commented out, references absent `_assets/misra_2023.csv` (`:28-29`) |
| `verification_plan` | `verification_plan.rst` | `:status: valid`; criteria 1–9 (criterion 8 = SCA critical/high free, criterion 9 = compiler warnings/errors free) |
| `development_plan` | `development_plan.rst` | `:status: valid` |
| `tool_management` | `tool_management.rst` | `:status: valid`; identify / evaluate / qualify |
| `verification_process` | `verification_process.rst` | `:status: valid`; **`gd_req__verification_sca_classification` (`:228-248`)** |
| `verification_guideline` | `verification_guideline.rst` | `:status: valid` |
| `inspection_checklist` | `inspection_checklist.rst` | **`:status: draft`**, blank template |

`authority.json`: `codeql_scope: "Public Apache-2.0 eclipse-score/inc_someip_gateway;
no upload"`, `engineering_acceptance: pending`, `human_reviews: unanswered`,
`safety_class: unknown`. Every `source-index.json` entry is `native_acceptance:
not_inferred`.

---

## 2. The recorded GCC syntax failure — inspection of the actual source

`score/socom/impl/service_identifier.hpp` read from the working tree is
**brace-balanced** (40 lines):

| Line | Content | Role |
|------|---------|------|
| 19 | `namespace score::socom {` | one opening brace (C++17 nested-namespace form) |
| 29 | `struct Service_instance_identifier final {` | one opening brace |
| 32 | `};` | closes the struct |
| 38 | `}  // namespace score::socom` | the single matching namespace closer |
| 39 | *(empty)* | **not a brace** |
| 40 | `#endif  // SRC_SOCOM_SRC_SERVICE_IDENTIFIER` | include-guard end |

`grep '[{}]'` returns exactly `:19`, `:29`, `:32`, `:38`. There is **no third,
unmatched closing brace**, and line 39 contains no text. The sibling
`service_identifier.cpp` uses the same nested form and is balanced (`:18`, `:20`,
`:30`, `:32`).

The retained tools corroborate a compiling unit: `gcc-compile` **exit 0** with empty
`stderr`, `gcc-tests` **exit 0**; host `candidate` **85 / 0 / compile 0**;
`baseline_with_agent_tests` **85 / 28 / compile 0**. The only non-zero compiler result
is the **Clang** dependency error in §3.2.

**Disposition.** The described defect is a **stale, pre-correction description** that
matches the earliest prior reports (split-form `}  // namespace socom` + `}  //
namespace score`); the `reproducer` iteration corrected it and left line 39 blank.
Re-applying the historical repair to the already-balanced file would be a no-op at
best and a compile break at worst. **No correction was applied; none is required.**

---

## 3. Reconciliation of the original findings

Findings are grouped by tool and reconciled against the six candidate paths. "In the
six paths?" asks whether a flagged location is one of §1.2's writable source paths.
"Native id" is the tool's own identifier; "tool severity" is the severity the tool
itself carried in the retained artifact.

### 3.1 Compiler — GCC (focused TU): no finding

| Aspect | Value | Evidence |
|--------|-------|----------|
| Command | `g++-12 -std=c++17 -Wall -Wextra -Werror -pthread -I. … service_identifier.cpp string_registry.cpp service_identifier_tests.cpp gtest-all.cc gtest_main.cc` | `compiler_diagnostics/result.json:236-272` |
| `gcc-compile` | **exit 0**, empty `stderr` | `gcc-compile.stderr` (empty); `result.json:271` |
| `gcc-tests` | **exit 0** | `gcc-tests.stderr` (empty); `result.json:293` |
| Host candidate | 85 tests / 0 failures / compile 0 | `validation/measurement.json`, `validation/after.json` |

**Findings: none.** This is a *focused* clean compile, not a full-target criterion-9
measurement (default build disables warnings-as-errors, `.bazelrc:117`).

### 3.2 Compiler — Clang (focused TU): 1 dependency error (retained)

| Native id | Tool severity | Location | In the six paths? |
|-----------|---------------|----------|-------------------|
| `-Wdeprecated-declarations` (`[-Werror,-Wdeprecated-declarations]`) | **error** | `/usr/lib/gcc/x86_64-linux-gnu/12/../../../../include/c++/12/bits/stl_tempbuf.h:263:8`, instantiated from `.llm_tmp/googletest/googletest/src/gtest.cc:3068` via `std::stable_sort` | **no** (libstdc++ + vendored googletest) |

The message is `'get_temporary_buffer<testing::TestInfo *>' is deprecated`.
`clang-compile` **exit 1** (`compiler_diagnostics/result.json:329`). This is a
**dependency/toolchain** error surfaced under `-Werror`, not a candidate-source defect.
Fixing it would require patching googletest or suppressing the warning in the build —
both prohibited here. **Retained as a blocker; no in-scope correction.**

### 3.3 Analyzer — Clang-Tidy (focused): configuration blocker, no TU analysis

`clang-tidy --verify-config --config-file=<snapshot>/.clang-tidy` (clang-tidy 19.1.7)
exits **1** with 15 `unknown check` warnings (`focused_clang_tidy/native-config.stderr`).
The native ids named in those warnings (preserved verbatim):

| # | Native id / text in warning | Cause |
|---|-----------------------------|-------|
| 1 | `# --- autosar-severity-one --- bugprone-use-after-move` | `#` comment folded into check name |
| 2 | `# --- autosar-severity-two --- bugprone-forwarding-reference-overload` | comment folded |
| 3 | `# --- cert --- cert-err52-cpp` | comment folded |
| 4 | `clang-analyzer-alpha.security.ArrayBoundV2` | check absent from clang-tidy 19.1.7 |
| 5 | `# --- qnx-checks --- bugprone-reserved-identifier` | comment folded |
| 6 | `# --- extra --- bugprone-assert-side-effect` | comment folded |
| 7 | `#modernize-type-traits` | comment folded (`#` prefix) |
| 8 | `Disabled because of too much noise` | comment folded |
| 9 | `will later be re-enabled with a campaign to fix findings modernize-unary-static-assert` | comment folded |
| 10 | `modernize-use-integer-sign-comparison` | check absent from clang-tidy 19.1.7 |
| 11 | `#modernize-use-nodiscard` | comment folded |
| 12 | `Disabled because of too much noise` | comment folded |
| 13 | `will later be re-enabled with a campaign to fix findings modernize-use-nullptr` | comment folded |
| 14 | `# --- style-readability --- misc-confusable-identifiers` | comment folded |
| 15 | check option `modernize-use-integer-sign-comparison.IncludeStyle` | option absent for the unknown check |

Root cause (from `reports/analyzer_plan.md` §3.1): the repository `.clang-tidy` uses a
YAML folded block scalar (`Checks: >`) with `#` comment lines inside it; YAML does not
treat `#` as a comment inside a block scalar, so comments fold into the check string.
The retained blocker is *"Native analyzer configuration incompatible; no replacement
called MISRA"*.

**Disposition: Clang-Tidy produced ZERO findings on the changed units because it did
not run.** This is *"not run"*, **not** *"clean"*. The config is outside the six
candidate paths; repairing it requires an authorized change. **Retained as a blocker.**

### 3.4 Analyzer — Cppcheck (focused): 19 `passedByValue` performance findings

Command (`focused_cppcheck/result.json:236-265`): `/usr/bin/cppcheck --std=c++17
--enable=warning,style,performance,portability --xml --xml-version=2
--error-exitcode=2 -I. score/socom/impl/service_identifier.cpp
score/socom/impl/string_registry.cpp`. **Exit 2.**

All 19 findings share the native id `passedByValue`, tool severity `performance`,
CWE `398`. `file0` is the candidate `service_identifier.cpp`, but **every `<location>` is
in an included header outside the six candidate paths**:

| Native id | Severity | Flagged declaration location | Count |
|-----------|----------|------------------------------|-------|
| `passedByValue` | `performance` | `score/socom/registry_string_view.hpp:127` (`lhs`,`rhs`), `:134` (`lhs`,`rhs`), `:141` (`lhs`,`rhs`), `:148` (`lhs`,`rhs`), `:155` (`lhs`,`rhs`), `:162` (`lhs`,`rhs`) | 12 |
| `passedByValue` | `performance` | `score/socom/registry_string_view.hpp:173` (`v`) | 1 |
| `passedByValue` | `performance` | `score/socom/service_interface_identifier.hpp:37,41,48,99,105,113` (`new_id`) | 6 |
| **Total** | | | **19** |

**Disposition: out-of-scope performance style suggestions on small view/value types;
not correctness defects.** They were not fixed (the headers are outside the six paths).
**Retained; no in-scope correction.**

### 3.5 Analyzer — CodeQL security: 32 findings, all dependency

Command: CodeQL 2.21.4, suite `cpp-security-and-quality.qls`, focused database
(`codeql_security/result.json:238-294`); `scan_runs: 1`; self-declared limit *"Focused
linked executable, not full target extraction; dependency findings retained"*.

**Every finding's `uri` is under `.llm_tmp/googletest/**`.** No finding lands in any of
the six candidate paths, in `score/socom/**`, or anywhere in project code. The 32
findings, by native rule id (`level` is `null` on all of them):

| Native rule id | Count | Scope |
|----------------|-------|-------|
| `cpp/fixme-comment` | 1 | `.llm_tmp/googletest/googletest/include/gtest/gtest.h:488` |
| `cpp/commented-out-code` | 7 | googletest headers/sources |
| `cpp/large-parameter` | 1 | googletest |
| `cpp/equality-on-floats` | 2 | googletest |
| `cpp/unused-static-function` | 2 | googletest |
| `cpp/unused-static-variable` | 1 | googletest |
| `cpp/rule-of-two` | 1 | googletest |
| `cpp/include-non-header` | 9 | googletest |
| `cpp/trivial-switch` | 2 | googletest |
| `cpp/loop-variable-changed` | 2 | googletest |
| `cpp/path-injection` | 4 | googletest (`gtest.cc`, e.g. `:6851`, `:6198`, `:5928`, `:5174`) |
| **Total** | **32** | **all dependency** |

`tool severity`: none retained — `level: null` for every finding. The run's status is
`findings_or_execution_failure`. **Retained; no in-scope finding; no correction.**

### 3.6 Analyzer — CodeQL MISRA: large focused set (dependency + macro + out-of-slice production)

Command: CodeQL coding-standards pack 2.61.0, suite `misra-cpp-default.qls`, focused
database; **218** compiled queries loaded; database-create and analyze **exit 0**
(`codeql_misra/analyze.stderr`; `result.json:242-297`). The `findings` array spans
**lines 306–117 940** of `codeql_misra/result.json` (on the order of **~5.8k**
individual findings, dominated by dependency locations). Self-declared blockers:
*"MISRA applicability/mapping draft and incomplete"*, *"Default suite omits
manual/audit obligations"*, *"Compiled query qualifications and human deviations
pending"*; limit: *"Focused linked executable, not full target extraction; dependency
findings retained"*. `level` is `null` on every finding; **no Critical/High/Medium/Low
rating is carried**.

The native ids (`cpp/misra/<query>`) directly observed, with their scope. (Rule
numbers in the left column are the licensed pack's own annotations, as recorded by the
prior `misra_applicability.md` / `misra_manual_review.md` reports; they are **not**
re-derived here and are **not** an S-CORE applicability decision — `misra_mapping.rst`
is a draft.)

| CodeQL native id | Pack rule (per prior reports) | Scope observed | In the six paths? |
|------------------|-------------------------------|----------------|-------------------|
| `cpp/misra/copy-and-move-assignments-shall-handle-self-assignment` | 15.8.1 | `.llm_tmp/googletest/googletest/include/gtest/internal/gtest-filepath.h:80,84` | no (dependency) |
| `cpp/misra/external-linkage-not-declared-in-header-file-misra` | 6.5.1 | `score/socom/test/unit/service_identifier_tests.cpp` — many `TEST_F` lines (gtest macro expansion) | yes (test file) |
| `cpp/misra/switch-body-compound-condition` | 9.3.1 | `service_identifier_tests.cpp`; googletest `gtest-matchers.h` | yes (test file) / dependency |
| `cpp/misra/no-conversion-from-bool` | 7.0.1 | `score/socom/impl/string_registry.cpp`; `service_identifier_tests.cpp` | no (production) / yes (test file) |
| `cpp/misra/local-variable-static-storage-duration` | 6.7.1 | `score/socom/impl/string_registry.cpp:66,71` | no (production, outside slice) |
| `cpp/misra/unnecessary-write-to-local-object` | 0.1.1 | `score/socom/impl/string_registry.cpp:23,35`; googletest `gtest.cc` | no (production, outside slice) / dependency |
| `cpp/misra/dynamic-memory-should-not-be-used` | 21.6.1 | `score/socom/string_registry.hpp:37`; `service_identifier_tests.cpp:52`; googletest `gtest-filepath.h` | no (production, outside slice) / yes (test file) / dependency |
| `cpp/misra/numeric-assignment-type-mismatch` | (pack) | `service_identifier_tests.cpp` (e.g. `:1630`) | yes (test file) |
| `cpp/misra/appropriate-structure-of-switch-statement` | (pack) | `service_identifier_tests.cpp` (e.g. `:1500`) | yes (test file) |
| `cpp/misra/identifiers-used-in-the-controlling-expression-of` | (pack) | googletest `gtest-port.h` | no (dependency) |
| `cpp/misra/global-variable-used` | (pack) | googletest `gtest.cc` | no (dependency) |
| `cpp/misra/missing-precedence-clarifying-parenthesis` | (pack) | googletest `gtest.cc` | no (dependency) |
| `cpp/misra/legacy-for-statements-should-be-simple` | (pack) | googletest `gtest.cc` | no (dependency) |
| `cpp/misra/unused-return-value-misra-cpp` | (pack) | googletest `gtest.cc` | no (dependency) |
| `cpp/misra/avoid-program-terminating-functions` | (pack) | googletest (`gtest-port.h`, `gtest-death-test.cc`, `gtest.cc`) | no (dependency) |
| `cpp/misra/short-circuited-persistent-side-effect` | (pack) | googletest (`gtest.h`, `gtest.cc`, `gtest-death-test.cc`) | no (dependency) |

Additional observations, explicitly:

- **No finding lands in `score/socom/impl/service_identifier.cpp` or
  `score/socom/impl/service_identifier.hpp`.** Direct `grep` of
  `codeql_misra/result.json` for those paths returns nothing (they appear only in the
  `source_hashes` block). This is *"no finding in a focused, incomplete extraction"*,
  **not** a compliance statement.
- **`score/socom/test/unit/runtime_tests.cpp` was not extracted**, so it has **zero**
  findings only because it was not analysed.
- The candidate test-file findings are dominated by the gtest `TEST_F` macro expansion
  (externally-linked registration entities synthesised by the macro), which cannot be
  fixed inside the authored test body; a fix would mean patching the test framework or
  suppressing the rule, both prohibited, or an accepted human deviation, which is
  unavailable here. **Retained; needs human deviation.**
- The `string_registry.cpp` / `string_registry.hpp` findings are **repository
  production code but outside the six candidate paths**; they are retained because an
  honest MISRA reading of the focused extraction must not omit them. Per
  `code_analysis.rst:51` an unaddressed MISRA finding must be justified in-source;
  no such justification exists and adding one is outside this review's write boundary.
- The dependency (googletest) MISRA findings are retained in full in the artifact. This
  report enumerates them **by rule and scope**, not one row per occurrence; that is a
  presentation limit, not a filter — no finding was removed.

### 3.7 Sanitizers — ASan/LSan/UBSan pass; TSan and memcheck blocked

| Check | Native result | Reading |
|-------|---------------|---------|
| `focused_asan_lsan` (ASan + LSan + UBSan) | compile **exit 0**; tests **exit 0**; **87/87 passed** (`tests.stdout:179-183`) | **Pass — focused single-threaded identifier scope only.** `ASAN_OPTIONS=detect_leaks=1:halt_on_error=1`, `UBSAN_OPTIONS=halt_on_error=1`. No overflow/UB/leak finding reported. |
| `focused_tsan` | tests **exit -11** (SIGSEGV) this collection (an earlier collection recorded 66); `tests.stderr`/`stdout` empty; environment carried `FATAL: ThreadSanitizer: unexpected memory mapping` per prior reports | **Environment failure, not a data race.** The first-run TSan/ASLR kernel-mmapping incompatibility; the focused tests are single-threaded. **Retained as environment blocker.** |
| `focused_memcheck` | **exit 127**; `reason: [Errno 2] No such file or directory: '/tmp/score-someip84-obligation-tools/usr/bin/valgrind'` | **Tool unavailable; blocker.** No memcheck result. |

### 3.8 Analyzer/cross/native/format checks blocked by missing tools (no findings)

`native_build`, `native_tests`, `native_integration`, `native_lint`, `native_docs`,
`native_traceability`, `native_sanitizers`, `native_tsan`, `native_coverage`,
`native_performance`, `cross_compilation`, and `format_precommit` all fail with
`[Errno 2] No such file or directory: '/tmp/s-core-001/bin/bazel'` (**exit 127**);
`secret_dependency_checks` shows `gitleaks` unavailable; `tool_assurance` shows
`valgrind` and `gitleaks` unavailable and records that tool qualification requires
authorized humans. These are **unavailable-tool blockers, not source findings**; per
the non-satisfaction rule they are not treated as satisfied.

---

## 4. Severity classification (per `gd_req__verification_sca_classification`)

### 4.1 The governing requirement

`verification_process.rst:228-248` (`gd_req__verification_sca_classification`,
`:status: valid`) requires SCA findings to be classified as **Critical / High / Medium /
Low**, where *"the actual classification shall be either provided by the tool as a
suggestion or defined manually by the quality manager together with the committer."*
Alternative ratings (class A–D / 1–4) are permitted only with the mapping documented.

`verification_plan.rst` criterion 8 requires **freedom from static-analysis
critical/high findings at 100 %**; criterion 9 requires **freedom from compiler
warnings & errors at 100 %**.

### 4.2 Tool-suggested ratings actually present

- **CodeQL (security & MISRA): none.** Every retained finding has `"level": null`.
- **Cppcheck: none in the required taxonomy.** Cppcheck emits its own
  `severity="performance"` (all 19 findings), which is *not* a Critical/High/Medium/Low
  class.
- **Compiler (Clang): none in the required taxonomy.** The single error carries the
  diagnostic severity `error`, not an SCA class.
- **Clang-Tidy: none.** It produced only configuration warnings; it ran no analysis.
- **Sanitizers: none.** ASan/LSan/UBSan produced no finding; TSan/memcheck produced no
  result.

**There is therefore no tool-suggested Critical/High/Medium/Low rating for any
retained finding.**

### 4.3 Authorized ratings

**None.** No `rl__quality_manager` + `rl__committer` classification exists anywhere in
the retained artifacts; `authority.json` records `engineering_acceptance: pending` and
`human_reviews: unanswered`. Every "authorized rating" cell below is consequently
**none / pending**.

### 4.4 Classification register (suggested = indicative only, not authorized)

The "Indicative class (review aid)" column is a **reviewer's suggestion**, offered only
so a human can begin the mandated classification. It is **not** a tool suggestion and
**not** an authorized rating, and no obligation status may be derived from it.

| # | Native id | Tool / category | Tool severity (native) | Scope | Indicative class (review aid, NOT authorized) | Authorized class |
|---|-----------|-----------------|------------------------|-------|-----------------------------------------------|------------------|
| C-1 | `-Wdeprecated-declarations` (Clang, `-Werror`) | compiler diagnostic | `error` | dependency (libstdc++/googletest) | High (build-blocking under `-Werror`, but out of scope) | **none / pending** |
| T-1 | 15 unknown-check texts (§3.3) | clang-tidy config | `warning` | repository `.clang-tidy` | Low (tooling/config) | **none / pending** |
| P-1…P-19 | `passedByValue` (CWE 398) | cppcheck | `performance` | headers outside the six paths | Low (performance style) | **none / pending** |
| S-1…S-32 | 11 CodeQL security rule ids (§3.5) | CodeQL security | `level: null` (none) | all dependency (googletest) | Medium–Low (dependency-only, focused extraction) | **none / pending** |
| M-1 | `cpp/misra/external-linkage-not-declared-in-header-file-misra` (6.5.1) | CodeQL MISRA | `level: null` | candidate test file (gtest macro) | Low (framework macro artifact, needs deviation) | **none / pending** |
| M-2 | `cpp/misra/switch-body-compound-condition` (9.3.1) | CodeQL MISRA | `level: null` | candidate test file (macro) / dependency | Low | **none / pending** |
| M-3 | `cpp/misra/no-conversion-from-bool` (7.0.1) | CodeQL MISRA | `level: null` | `string_registry.cpp` (outside slice) + test file | Medium (needs human disposition) | **none / pending** |
| M-4 | `cpp/misra/local-variable-static-storage-duration` (6.7.1) | CodeQL MISRA | `level: null` | `string_registry.cpp:66,71` (outside slice) | Medium (deliberate singleton) | **none / pending** |
| M-5 | `cpp/misra/unnecessary-write-to-local-object` (0.1.1) | CodeQL MISRA | `level: null` | `string_registry.cpp:23,35` (outside slice) | Low | **none / pending** |
| M-6 | `cpp/misra/dynamic-memory-should-not-be-used` (21.6.1) | CodeQL MISRA | `level: null` | `string_registry.hpp:37` (outside slice) + test file + dependency | Medium (deliberate container) | **none / pending** |
| M-7 | `cpp/misra/copy-and-move-assignments-shall-handle-self-assignment` (15.8.1) | CodeQL MISRA | `level: null` | dependency (`gtest-filepath.h`) | Low (dependency) | **none / pending** |
| M-8 | remaining CodeQL MISRA rule ids in §3.6 | CodeQL MISRA | `level: null` | candidate test file / dependency | Low–Medium (macro/dependency) | **none / pending** |

**Explicit statement.** The indicative classes above are **not** the mandated
classification. Until a Quality Manager and a committer complete
`gd_req__verification_sca_classification`, the slice has **no authorized finding
classification**, and criterion 8 (freedom from SCA critical/high findings) **cannot be
assessed**.

---

## 5. Dependency findings retained (nothing filtered)

All findings whose location is not project code are retained in full in their artifacts;
none was suppressed, dropped, or silently discarded. The dependency set is:

- **Clang**: 1 error — googletest / libstdc++ 12 `-Wdeprecated-declarations` (§3.2).
- **CodeQL security**: all 32 findings — `.llm_tmp/googletest/**` (§3.5).
- **CodeQL MISRA**: the versioned googletest subset (e.g.
  `copy-and-move-assignments-shall-handle-self-assignment` in `gtest-filepath.h`;
  `avoid-program-terminating-functions`, `short-circuited-persistent-side-effect`,
  `unnecessary-write-to-local-object`, `dynamic-memory-should-not-be-used`,
  `identifiers-used-in-the-controlling-expression-of`, `global-variable-used`,
  `missing-precedence-clarifying-parenthesis`, `legacy-for-statements-should-be-simple`,
  `unused-return-value-misra-cpp`) (§3.6).
- **Cppcheck**: the flagged declarations are in project headers
  (`registry_string_view.hpp`, `service_interface_identifier.hpp`) **outside the six
  candidate paths** — project code, but not this slice (§3.4).
- **CodeQL MISRA on project code outside the slice**: `string_registry.cpp` /
  `string_registry.hpp` (§3.6).

The **reason** these dependency/external findings are retained rather than "resolved"
is that the focused extraction deliberately links the vendored googletest and the
`string_registry` unit; the artifact's own limit records *"dependency findings
retained"*. Suppressing them would violate the task instruction never to silently
filter findings.

---

## 6. What has no finding, and what was not run (not "clean")

| Unit / check | State | Why this is not "clean" |
|--------------|-------|-------------------------|
| `service_identifier.cpp`, `service_identifier.hpp` | no analyzer finding | CodeQL security is dependency-only; CodeQL MISRA has no hit there; **clang-tidy did not run**; extraction focused |
| `runtime_tests.cpp` | **not extracted** | never compiled by any retained artifact (CodeQL focused build; host measurement) |
| full `//score/...` | **not analysed** | `native_build`/`native_lint` exit 127 (`bazel` missing) |
| clang-tidy on changed units | **not run** | `--verify-config` exit 1 (§3.3) |
| TSan | **no result** | environment failure (exit -11) |
| memcheck | **no result** | `valgrind` unavailable (exit 127) |
| warnings-as-errors native build | **not run** | default build disables warnings-as-errors (`.bazelrc:117`) |

---

## 7. Obligations status (none satisfied)

| Obligation / check | Pinned source | Status here |
|--------------------|---------------|-------------|
| Freedom from compiler warnings & errors (criterion 9, 100 %) | `verification_plan.rst` | **PARTIAL / NOT SATISFIED** — focused GCC clean (exit 0) and 85/85; Clang blocked by a dependency error; no full-target warnings-as-errors build |
| SCA findings classified Critical/High/Medium/Low | `verification_process.rst:228-248` | **NOT DONE** — no tool-suggested class; no authorized QM+committer classification |
| Static code analysis (clang-tidy / CodeQL) executed | `code_analysis.rst` | **NOT SATISFIED** — clang-tidy not run; CodeQL focused and dependency-heavy; cppcheck findings out of scope |
| MISRA C++:2023 compliance | `coding_guidelines.rst`; `misra_mapping.rst` | **UNKNOWN — mapping `:status: draft`; not claimed** |
| Freedom from SCA critical/high (criterion 8) | `verification_plan.rst` | **NOT MEASURED** — no authorized classification |
| Unit/component testing executed, results recorded | `verification_plan.rst` | **PARTIAL, STALE** — focused 85/85; tree has 87; `runtime_tests.cpp` not executed |
| Sanitizer / concurrency checks | `code_analysis.rst` | **PARTIAL / BLOCKED** — ASan/LSan/UBSan pass (focused); TSan environment failure; memcheck unavailable |
| Interface / requirements-based / resource / fault-injection test types | `verification_process.rst` | **NOT PERFORMED / applicability not inferred** |
| Linking tests to requirements (record properties) | `verification_process.rst` (`gd_req__verification_link_tests_cpp`) | **PARTIAL** — `DerivationTechnique`/`Description` set; `TestType`/`Verifies` deliberately unset (no invented identifiers) |
| Independence of verification / review | `verification_process.rst` (`gd_req__verification_independence`) | **NOT DONE** — human reviews unanswered |
| Tool identification / evaluation / qualification | `tool_management.rst` | **NOT ESTABLISHED for this slice** |
| Obligation collection results retained | `.llm_tmp/overnight/obligations/*/result.json` | **RETAINED, NOT PASSING** |
| Native acceptance | `source-index.json` | **`not_inferred` for every entry** |

**Explicit non-satisfaction statement.** Missing tools (`bazel`, `valgrind`,
`gitleaks`, `pre-commit`, `reuse`, `clang-format`), the non-running clang-tidy, the
focused/incomplete CodeQL extraction, the empty authorized finding classification, the
draft/inactive MISRA mapping, the stale and runtime-excluding measurement, and the
unanswered human reviews mean **none of the checked obligations may be treated as
satisfied**. A retained collection result shows *retention*, not passing.

---

## 8. Notice preservation

- No source, build, test, config, `NOTICE`, `LICENSE`, or `REUSE.toml` file was
  created, edited, or deleted by this iteration; **only this report was written.**
- The header the task flagged (`score/socom/impl/service_identifier.hpp`) retains its
  Apache-2.0/SPDX header (`:1-12`) and was left unchanged because it is already balanced
  (§2). The sibling `service_identifier.cpp` (`:1-12`), both BUILD files, and both
  candidate test files retain their Apache-2.0/SPDX headers.
- All files under `.llm_tmp/overnight/reports/` and `.llm_tmp/overnight/prior-reports/`
  were preserved unchanged; this document is a new `reports/` entry.
- This report itself carries the Apache-2.0 header. No licensed MISRA rule text is
  reproduced; only native rule/query identifiers and locations are cited.

---

## 9. Pending human review checklist

- [ ] **Confirm §2**: `service_identifier.hpp` is brace-balanced (brace lines
      `:19,:29,:32,:38`; line 39 blank); the recorded "extra closing brace at line 39"
      is stale or refers to a different revision. No source correction is required in
      this checkout.
- [ ] **Resolve the instruction conflict**: correct-the-source vs. review-draft-only;
      confirm that writing only this report was intended. If a distinct "cancelled
      draft" still carries the brace, locate and correct it by an authorized iteration.
- [ ] **Complete the mandated classification** (`gd_req__verification_sca_classification`):
      have the Quality Manager together with a committer assign Critical/High/Medium/Low
      to C-1, T-1, P-1…P-19, S-1…S-32 and M-1…M-8. Treat §4.4's indicative classes as
      review aids only.
- [ ] **Disposition the Clang dependency error (C-1)**: a googletest/libstdc++ 12
      `-Wdeprecated-declarations` error under `-Werror`; decide whether the native
      toolchain pins avoid it. Do not suppress the warning in-repo without an accepted
      deviation.
- [ ] **Repair and run Clang-Tidy (T-1)**: unfold the `.clang-tidy` `Checks: >` block so
      `#` comments are not folded into check names, and re-evaluate
      `clang-analyzer-alpha.security.ArrayBoundV2` and
      `modernize-use-integer-sign-comparison` for the pinned clang-tidy version. Do not
      suppress checks inside this slice.
- [ ] **Disposition the Cppcheck findings (P-1…P-19)** in `registry_string_view.hpp` and
      `service_interface_identifier.hpp` as acceptable performance style or a separate
      change.
- [ ] **Disposition the CodeQL MISRA test-file findings (M-1, M-2, M-8)** as gtest
      `TEST_F` macro artifacts: record an accepted deviation or adopt macro-aware
      tooling; do not patch the test framework or silently suppress the rules.
- [ ] **Disposition the CodeQL MISRA production findings M-3…M-6** in
      `string_registry.cpp` / `string_registry.hpp` (outside this slice): justify
      in-source per `code_analysis.rst:51`, refactor, or record an accepted deviation.
- [ ] **Decide the CodeQL posture**: run a full-target extraction (not a focused
      executable) that includes `runtime_tests.cpp` and the remaining units, and
      qualify the compiled queries.
- [ ] **Complete and activate the MISRA mapping** (`misra_mapping.rst`): supply
      `_assets/misra_2023.csv`, uncomment the `csv-table`, and raise `:status` to
      `valid` by an authorized change; until then no rule applicability may be stated.
- [ ] **Restore the missing native tools** (`bazel`, `valgrind`, `gitleaks`,
      `pre-commit`, `reuse`, `clang-format`) and re-run the native analyzer, sanitizer
      and coverage checks, including a `--features=treat_warnings_as_errors` build for
      criterion 9.
- [ ] **Refresh the measurement**: run `bazel test //score/socom/test/unit:socom_test`
      (and the broader `//score/...` set) so `runtime_tests.cpp` and the two newest
      identifier tests are actually compiled and executed; do not re-report the 85-case
      focused artifact as coverage of the current 87-macro tree.
- [ ] **Supply native requirement/interface identifiers** for traceability links, or
      record applicability as unresolved (no invented links).
- [ ] **Select the safety class**, schedule independent human review (approver ≠ author,
      `gd_req__verification_independence`), and record engineering acceptance; no
      compliance claim may be made before that.
- [ ] **Keep the wider #84 public `Service_interface_identifier` restructure,
      FindService wildcard handling, and the config minor-wildcard narrowing out of this
      bounded slice** until separately accepted.

---

*End of review draft. Local, unprotected, scoped. No engineering acceptance; human
reviews unanswered; full native runtime tests pending. No MISRA C++:2023 compliance is
claimed, no finding is filtered, and no authorized severity rating exists.*
